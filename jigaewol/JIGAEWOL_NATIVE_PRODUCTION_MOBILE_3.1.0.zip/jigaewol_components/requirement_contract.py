from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .intent_fidelity import IntentFidelityProjector
from .source_directive_compiler import explicit_request_present

_ACCOUNTED = {"satisfied", "blocked", "not_applicable", "deferred_by_user"}
_EVIDENCE_REQUIRED_KINDS = {"action"}


@dataclass(frozen=True)
class RequirementAtom:
    atom_id: str
    text: str
    kind: str
    critical: bool
    source_index: int
    parent_message_sha256: str
    tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class RequirementContract:
    message_sha256: str
    atoms: tuple[RequirementAtom, ...]
    anti_compression: bool
    semantic_coverage_required: bool
    contract_sha256: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CoverageVerdict:
    ok: bool
    accounted_ids: tuple[str, ...]
    missing_ids: tuple[str, ...]
    invalid_ids: tuple[str, ...]
    findings: tuple[str, ...]


class RequirementCompiler:
    """Compiles free-form user language into a loss-resistant release contract.

    This is deliberately separate from execution verification: a turn can require no
    external tools and still have many user requirements that must not disappear.
    """

    CRITICAL_MARKERS = (
        "반드시", "무조건", "꼭", "절대", "빼먹", "누락", "하지 마", "하지말",
        "축소하지", "다운그레이드", "끝까지", "전부", "모두", "must", "never",
        "do not", "don't", "all of", "every", "without dropping",
    )
    CONSTRAINT_MARKERS = (
        # "하지" alone also matched "하지만", turning ordinary contrast into a
        # constraint. The negative imperative is the "~지 마/말/않" ending itself, which
        # catches 빼먹지 마 and 줄이지 말 without catching 하지만.
        "지 마", "지마", "지 말", "지말", "지 않", "말고", "없이",
        "기준", "전제", "조건", "제한", "유지", "보존",
        "must", "never", "without", "only", "preserve", "keep",
    )
    QUESTION_MARKERS = ("왜", "뭐", "무엇", "어떻게", "가능", "맞", "?", "why", "how", "what")
    # Atomization splits on "?", so it never reaches _kind. Interrogative intent has to
    # be readable from the words themselves, which for Korean means the verb ending.
    INTERROGATIVE_MARKERS = (
        "왜", "뭐", "뭘", "무엇", "무슨", "어떻게", "어떤", "어디", "언제", "누가", "몇",
        "어때", "어떠", "인가", "일까", "을까", "ㄹ까", "는가", "나요", "가요", "는지",
        "될까", "되나", "맞아", "맞나", "있나", "있어", "가능", "?",
        "why", "how", "what", "which", "when", "where", "who", "whether", "should i",
    )
    # Korean marks a question in the final ending rather than with a leading word, so
    # substring markers alone miss "좋아질까" / "쓸만한가". Over-reading a question only
    # raises uncertainty, which widens the search — the cheap direction to be wrong in.
    INTERROGATIVE_SUFFIXES = (
        "까", "까요", "나", "나요", "니", "냐", "죠", "가요", "는지", "런지", "래", "래요",
    )
    ACTION_MARKERS = (
        # "~줘/주세요" is the ordinary Korean request ending; without it "써줘"/"보여줘"
        # read as bare preferences and never reach execution_pressure.
        "해줘", "줘", "주세요", "해보자", "찾아", "검색", "조사", "봐", "보고", "읽어", "확인", "고쳐", "수정", "설계", "만들", "실행",
        "붙여", "가져", "연결", "검증", "구현", "학습", "기록", "저장", "업데이트", "커밋", "푸시",
        "remove", "build", "search", "run", "fix",
        "design", "implement", "modify", "create", "capture", "track", "connect", "use",
    )
    PERSISTENT_ACTION_MARKERS = ("기록", "저장", "노션", "파일에", "업데이트", "커밋", "푸시", "설치", "연결")
    ANTI_COMPRESSION_MARKERS = (
        "빼먹", "누락", "개무시", "몇개만", "몇 개만", "축약", "축소", "전부", "싹 다",
        "하나하나", "조목조목", "모든 요구", "all requirements", "don't skip", "do not skip",
    )
    # A control-plane message can describe what to do on *future* task turns while
    # naming many tools/actions. Those names are requirements to preserve, not an
    # instruction to dispatch every named body right now. Keep the atoms in the
    # contract, but tag them so current-turn execution planning can project them out.
    @classmethod
    def _kind(cls, text: str) -> str:
        low = text.casefold()
        # Request morphology outranks incidental question/condition/topic words.
        # Direct prohibitions still remain constraints rather than positive effects.
        if explicit_request_present(text) and not re.search(
            r"(?:하지\s*마|하지\s*말|지\s*마|지\s*말|\bdo\s+not\b|\bdon['’]?t\b|\bnever\b)", text, re.I
        ):
            return "action"
        if any(x in low for x in cls.CONSTRAINT_MARKERS):
            return "constraint"
        # Questions are tested before actions: most real questions also carry a common
        # verb ("만들", "찾아", "해줘"), so checking actions first made the question
        # branch unreachable and drove every question into execution_pressure instead
        # of the uncertainty that should widen the search.
        stripped = low.rstrip(" \t?!.~")
        if any(x in low for x in cls.INTERROGATIVE_MARKERS) or stripped.endswith(cls.INTERROGATIVE_SUFFIXES):
            return "question"
        if any(x in low for x in cls.ACTION_MARKERS):
            return "action"
        return "preference"

    # Korean chains requests with a connective ending rather than a delimiter, so
    # "비교해주고 각각 단점도 알려줘" arrives as one sentence carrying two asks and the
    # delimiter split leaves it as a single atom. Measured across eight real requests,
    # five collapsed this way — and a merged atom is exactly the omission the contract
    # exists to catch, because satisfying half of it still reads as satisfied.
    _CONJUNCTIVE = re.compile(r"(?<=주)고\s+|(?<=하)고\s+|(?<=치)고\s+")
    _NUMBERED_ITEM = re.compile(r"(?<!\S)(\d{1,3})[.)]\s+")

    @classmethod
    def _split_numbered_items(cls, text: str) -> list[str]:
        """Split inline numbered asks only when a real list is present.

        Long mobile-chat requests often arrive as a single sentence with
        ``1) ... 2) ... 3) ...``.  Treating that as one atom defeats the anti-shrink
        contract.  Requiring at least two numbered markers avoids splitting ordinary
        version/decimal prose.  A textual prefix ("Implement P0 fixes immediately:")
        is preserved on the first item so the list's governing intent is not lost.
        """

        matches = list(cls._NUMBERED_ITEM.finditer(text))
        if len(matches) < 2:
            return [text]
        pieces: list[str] = []
        for index, match in enumerate(matches):
            end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
            start = 0 if index == 0 else match.start()
            piece = text[start:end].strip(" \t,;")
            if not piece:
                continue
            pieces.append(piece)
        return pieces or [text]

    @classmethod
    def _split_conjunctive(cls, text: str) -> list[str]:
        """Split chained requests, but only where both halves actually ask for something.

        The same ending appears where nothing is being chained — "친구하고 같이",
        "참고하고 싶어" — and splitting those is wrong. The reliable signal is the right
        half: a real second request carries a request word, a false one does not.
        """
        # A prohibition governs its own clause, not the positive request after 말고.
        contrast = re.search(r"말고\s+", text)
        if contrast and (explicit_request_present(text[contrast.end():]) or any(x in text[contrast.end():].casefold() for x in cls.ACTION_MARKERS)):
            return [text[:contrast.start() + 2].strip(), *cls._split_conjunctive(text[contrast.end():].strip())]
        # Keep each prohibition attached only to its own exact source clause.
        # These boundaries consume whitespace, never rewrite atom text.
        scoped = re.search(r"(?<=마)\s*,?\s+(?=.+)|(?<=말아)\s*,?\s+(?=.+)|\s+(?:but|and)\s+", text, re.I)
        if scoped and re.search(r"(?:지\s*마|지\s*말|\bdo\s+not\b|\bdon['’]?t\b|\bnever\b)", text[:scoped.start()], re.I) and explicit_request_present(text[scoped.end():]):
            return [text[:scoped.start()].strip(), *cls._split_conjunctive(text[scoped.end():].strip())]
        parts = [p.strip() for p in cls._CONJUNCTIVE.split(text) if p and p.strip()]
        if len(parts) < 2:
            return [text]
        # The split consumes the connective's last syllable, so restore it before
        # judging the fragments: a middle link reads as "정리해주", which carries no
        # request word, while the "정리해주고" it actually is plainly does.
        restored = [p if index == len(parts) - 1 else p + "고" for index, p in enumerate(parts)]
        for part in restored[1:]:
            low = part.casefold()
            if not (any(marker in low for marker in cls.ACTION_MARKERS)
                    or part.endswith(("주고", "하고", "치고"))):
                return [text]
        return restored

    @classmethod
    def compile(cls, message: str) -> RequirementContract:
        exact = str(message)
        raw = exact.strip()
        message_sha = hashlib.sha256(exact.encode("utf-8")).hexdigest()
        rows = []
        for row in IntentFidelityProjector._atomize_text(raw):
            for numbered_piece in cls._split_numbered_items(str(row["text"])):
                for piece in cls._split_conjunctive(numbered_piece):
                    rows.append({"atom_id": "req_" + hashlib.sha256(piece.encode("utf-8")).hexdigest()[:16],
                                 "text": piece})
        atoms: list[RequirementAtom] = []
        for index, row in enumerate(rows, start=1):
            text = str(row["text"]).strip()
            low = text.casefold()
            critical = any(marker in low for marker in cls.CRITICAL_MARKERS)
            tags: list[str] = []
            if critical:
                tags.append("critical")
            if any(marker in low for marker in cls.ANTI_COMPRESSION_MARKERS):
                tags.append("anti_compression")
            if any(marker in low for marker in cls.PERSISTENT_ACTION_MARKERS) and cls._kind(text) == "action":
                tags.append("persistent_action")
            atoms.append(RequirementAtom(
                atom_id=str(row["atom_id"]), text=text, kind=cls._kind(text),
                critical=critical, source_index=index, parent_message_sha256=message_sha,
                tags=tuple(tags),
            ))
        anti = any("anti_compression" in atom.tags for atom in atoms)
        # Coverage remains observable, but it is not a permission gate.
        body = "\n".join(f"{a.atom_id}:{a.kind}:{int(a.critical)}:{a.text}" for a in atoms)
        semantic_coverage_required = bool(anti or any(a.critical for a in atoms) or len(atoms) >= 3)
        # Coverage is truth annotation, never response permission. Every atom remains
        # visible to current planning regardless of durable/standing scope.
        contract_sha = hashlib.sha256((message_sha + "\n" + body + f"\nsemantic:{int(semantic_coverage_required)}").encode("utf-8")).hexdigest()
        return RequirementContract(
            message_sha256=message_sha, atoms=tuple(atoms), anti_compression=anti,
            semantic_coverage_required=semantic_coverage_required, contract_sha256=contract_sha,
        )


    @staticmethod
    def from_mapping(raw: Mapping[str, Any]) -> RequirementContract:
        atoms = tuple(RequirementAtom(
            atom_id=str(row.get("atom_id") or ""),
            text=str(row.get("text") or ""),
            kind=str(row.get("kind") or "preference"),
            critical=bool(row.get("critical")),
            source_index=int(row.get("source_index") or index),
            parent_message_sha256=str(row.get("parent_message_sha256") or raw.get("message_sha256") or ""),
            tags=tuple(row.get("tags") or ()),
        ) for index, row in enumerate(raw.get("atoms") or (), start=1))
        return RequirementContract(
            message_sha256=str(raw.get("message_sha256") or ""),
            atoms=atoms,
            anti_compression=bool(raw.get("anti_compression")),
            semantic_coverage_required=bool(raw.get("semantic_coverage_required", raw.get("anti_compression", False))),
            contract_sha256=str(raw.get("contract_sha256") or ""),
        )

    @staticmethod
    def release_manifest_template(contract: RequirementContract) -> dict[str, Any]:
        return {
            "requirement_contract_sha256": contract.contract_sha256,
            "requirement_coverage": [
                {"atom_id": atom.atom_id, "status": "planned", "evidence_refs": [], "note": "", "response_excerpt": ""}
                for atom in contract.atoms
            ],
        }


    _COVERAGE_STOPWORDS = {
        "그리고", "그런데", "하지만", "그러니까", "그냥", "정말", "진짜", "나는", "내가", "너는", "네가",
        "이게", "그게", "저게", "이런", "그런", "저런", "하게", "해서", "하는", "하면", "말해", "해줘",
        "the", "and", "that", "this", "with", "from", "have", "will", "just", "really", "please",
    }

    @staticmethod
    def _coverage_tokens(text: str) -> tuple[str, ...]:
        raw_tokens = [x.casefold() for x in re.findall(r"[0-9A-Za-z가-힣_]+", str(text))]
        tokens: list[str] = []
        korean_particles = (
            "에게서", "한테서", "으로부터", "에서부터",
            "으로", "에게", "한테", "에서", "까지", "부터",
            "처럼", "보다", "하고", "이며", "이고",
            "은", "는", "이", "가", "을", "를", "의", "에", "로", "와", "과", "도", "만",
        )
        for token in raw_tokens:
            variants = [token]
            # Coverage is semantic anchoring, not exact Korean surface matching.
            # Strip only common grammatical particles while preserving the original
            # token too, so `사과의` and `사과는` can meet on the content stem
            # without turning arbitrary substrings into evidence.
            if re.fullmatch(r"[가-힣]+", token):
                for suffix in korean_particles:
                    if token.endswith(suffix) and len(token) - len(suffix) >= 2:
                        variants.append(token[: -len(suffix)])
                        break
            for variant in variants:
                if len(variant) >= 2 and variant not in RequirementCompiler._COVERAGE_STOPWORDS:
                    tokens.append(variant)
        return tuple(dict.fromkeys(tokens))

    @staticmethod
    def _char_ngrams(text: str, n: int = 2) -> set[str]:
        compact = re.sub(r"[^0-9A-Za-z가-힣]+", "", str(text).casefold())
        if len(compact) < n:
            return {compact} if compact else set()
        return {compact[i:i+n] for i in range(len(compact) - n + 1)}

    @staticmethod
    def _excerpt_semantically_anchors(atom_text: str, excerpt: str) -> bool:
        atom_tokens = RequirementCompiler._coverage_tokens(atom_text)
        excerpt_tokens = set(RequirementCompiler._coverage_tokens(excerpt))
        if atom_tokens:
            shared = [tok for tok in atom_tokens if tok in excerpt_tokens or any(
                (len(tok) >= 3 and (tok in et or et in tok)) for et in excerpt_tokens
            )]
            if len(shared) >= min(2, len(atom_tokens)):
                return True
            if len(atom_tokens) <= 2 and shared:
                return True
        a = RequirementCompiler._char_ngrams(atom_text)
        b = RequirementCompiler._char_ngrams(excerpt)
        if not a:
            return bool(str(excerpt).strip())
        return len(a & b) / max(1, len(a)) >= 0.18

    @staticmethod
    def assess_response_coverage(contract: RequirementContract, response_text: str) -> CoverageVerdict:
        """Deterministically check that a multi-requirement answer actually touches every atom.

        This is not a truth verifier. It prevents the weaker failure where the ledger says
        every requirement was handled while the final prose simply omits one. Semantic
        verifiers and execution receipts remain separate gates for correctness and effects.
        """
        if not contract.semantic_coverage_required:
            return CoverageVerdict(True, tuple(a.atom_id for a in contract.atoms), (), (), ())
        body = str(response_text or "")
        missing: list[str] = []
        accounted: list[str] = []
        findings: list[str] = []
        # Paragraphs/sentences are the candidate trace spans. A response must contain at
        # least one span that shares real semantic anchors with each atom.
        spans = [x.strip() for x in re.split(r"(?:\n{2,}|(?<=[.!?。！？])\s+)", body) if x.strip()]
        if not spans and body.strip():
            spans = [body.strip()]
        token_sets = [set(RequirementCompiler._coverage_tokens(atom.text)) for atom in contract.atoms]
        token_frequency: dict[str, int] = {}
        for toks in token_sets:
            for tok in toks:
                token_frequency[tok] = token_frequency.get(tok, 0) + 1

        for index, atom in enumerate(contract.atoms):
            distinctive = tuple(tok for tok in token_sets[index] if token_frequency.get(tok, 0) == 1)

            def _covers(span: str) -> bool:
                if not RequirementCompiler._excerpt_semantically_anchors(atom.text, span):
                    return False
                if not distinctive:
                    return True
                span_tokens = set(RequirementCompiler._coverage_tokens(span))
                return any(
                    tok in span_tokens or any(
                        len(tok) >= 2 and (tok in st or st in tok) for st in span_tokens
                    )
                    for tok in distinctive
                )

            if any(_covers(span) for span in spans):
                accounted.append(atom.atom_id)
            else:
                missing.append(atom.atom_id)
                findings.append(
                    f"final_response_omits_requirement_occurrence:{index + 1}:{atom.atom_id}:{atom.text}"
                )
        return CoverageVerdict(not missing, tuple(sorted(accounted)), tuple(sorted(missing)), (), tuple(findings))

    @staticmethod
    def validate_coverage(
        contract: RequirementContract,
        manifest: Mapping[str, Any] | None,
        *,
        response_text: str | None = None,
    ) -> CoverageVerdict:
        # Coverage is optional diagnostic metadata. Absence of a manifest never
        # withholds or vetoes a user-facing response.
        if not manifest:
            return CoverageVerdict(True, (), (), (), ())
        coverage_keys = {
            "requirement_contract_sha256",
            "requirement_coverage",
            "addressed_requirement_atom_ids",
        }
        if not any(key in manifest for key in coverage_keys):
            # Generation metadata (request ids, origin refs, model receipts, etc.) is
            # not a requirement-coverage claim merely because it is a nonempty mapping.
            # Treat coverage as absent unless the producer actually emitted one of the
            # coverage protocol fields.
            return CoverageVerdict(True, (), (), (), ())
        findings: list[str] = []
        supplied_contract = str(manifest.get("requirement_contract_sha256") or "")
        if supplied_contract and supplied_contract != contract.contract_sha256:
            findings.append("requirement_contract_hash_mismatch")

        rows = manifest.get("requirement_coverage") or ()
        by_id: dict[str, Mapping[str, Any]] = {}
        for row in rows:
            if isinstance(row, Mapping) and str(row.get("atom_id") or ""):
                by_id[str(row["atom_id"])] = row
        for atom_id in manifest.get("addressed_requirement_atom_ids") or ():
            by_id.setdefault(str(atom_id), {"atom_id": str(atom_id), "status": "satisfied", "evidence_refs": []})

        expected = {a.atom_id: a for a in contract.atoms}
        missing: list[str] = []
        invalid: list[str] = []
        accounted: list[str] = []
        for atom_id, atom in expected.items():
            row = by_id.get(atom_id)
            if row is None:
                missing.append(atom_id)
                continue
            status = str(row.get("status") or "").casefold()
            if status not in _ACCOUNTED:
                invalid.append(atom_id)
                continue
            evidence_refs = tuple(str(x).strip() for x in (row.get("evidence_refs") or ()) if str(x).strip())
            note = str(row.get("note") or "").strip()
            if status == "blocked" and not note:
                invalid.append(atom_id)
                findings.append(f"blocked_without_reason:{atom_id}")
                continue
            if status == "satisfied" and atom.kind in _EVIDENCE_REQUIRED_KINDS and not evidence_refs:
                invalid.append(atom_id)
                findings.append(f"satisfied_action_without_evidence:{atom_id}")
                continue
            if status == "satisfied" and "anti_compression" in atom.tags and not (evidence_refs or note):
                invalid.append(atom_id)
                findings.append(f"anti_compression_atom_without_trace:{atom_id}")
                continue
            # Semantic response tracing is observational; it never controls response permission.
            if status == "satisfied" and contract.semantic_coverage_required and atom.kind != "action" and response_text is not None:
                excerpt = str(row.get("response_excerpt") or "").strip()
                if not excerpt:
                    invalid.append(atom_id)
                    findings.append(f"satisfied_atom_without_response_trace:{atom_id}")
                    continue
                if excerpt not in str(response_text):
                    invalid.append(atom_id)
                    findings.append(f"response_trace_not_in_final_response:{atom_id}")
                    continue
                if not RequirementCompiler._excerpt_semantically_anchors(atom.text, excerpt):
                    invalid.append(atom_id)
                    findings.append(f"response_trace_lacks_atom_anchor:{atom_id}")
                    continue
            accounted.append(atom_id)
        unknown = sorted(set(by_id) - set(expected))
        if unknown:
            findings.append("unknown_requirement_atoms:" + ",".join(unknown))
        if missing:
            findings.append("missing_requirement_atoms:" + ",".join(missing))
        if invalid:
            findings.append("unaccounted_requirement_atoms:" + ",".join(invalid))
        return CoverageVerdict(not findings, tuple(sorted(accounted)), tuple(sorted(missing)), tuple(sorted(invalid)), tuple(findings))
