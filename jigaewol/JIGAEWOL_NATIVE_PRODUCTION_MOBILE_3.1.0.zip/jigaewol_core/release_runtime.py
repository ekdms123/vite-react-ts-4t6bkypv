from __future__ import annotations
from jigaewol_components.snapshot_store import load_snapshot, save_snapshot

import json
import hashlib
from pathlib import Path
from typing import Any, Mapping

from jigaewol_components.turn_audit import TurnAuditLedger
from jigaewol_components.directive_invariant import verify_atom_conservation, verify_destination
from jigaewol_components.requirement_contract import RequirementCompiler
from jigaewol_components.requirement_anti_shrink import RequirementAntiShrinkLedger
from jigaewol_components.repair_momentum import RepairMomentum
from jigaewol_components.cumulative_intent import CumulativeIntentLedger
from jigaewol_components.scope_integrity import ScopeIntegrityGuard
from jigaewol_components.image_quality_governor import ImageQualityGovernor
from jigaewol_components.image_sovereignty import ImageSovereigntyPolicy

from .canonical_finalizer import CanonicalTurnFinalizer
from .constants import CHARTER_ID, PUBLIC_RUNTIME_ID
from .evidence_attestation import ExecutionReceiptLedger

PACKAGE_ROOT = Path(__file__).resolve().parents[1]


class CanonicalReleaseRuntime:
    """Minimal host-evidence/finalizer runtime for the pre-release hot path.

    Finalizing a response does not require constructing the full cognition engine.
    This adapter reuses the exact same release ledger, execution-receipt format and
    canonical finalizer while avoiding unrelated planner, memory and world-model
    initialization.
    """

    def __init__(
        self,
        root: str | Path,
        *,
        session_id: str = "chat",
        ledger: TurnAuditLedger | None = None,
        execution_receipts: ExecutionReceiptLedger | None = None,
        finalizer: CanonicalTurnFinalizer | None = None,
        trace: Any | None = None,
    ) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.session_id = str(session_id)
        if ledger is None:
            ledger = TurnAuditLedger(
                self.root / "turn_audit",
                runtime_identity=PUBLIC_RUNTIME_ID,
                charter_id=CHARTER_ID,
                canonical_artifact_path=PACKAGE_ROOT / "CANONICAL_ARTIFACT.json",
            )
        self.ledger = ledger
        self.execution_receipts = execution_receipts or ExecutionReceiptLedger(
            self.root / "execution_receipts.jsonl", session_id=self.session_id
        )
        self.finalizer = finalizer or CanonicalTurnFinalizer(self.root / "canonical_finalizer")
        self.repair_momentum = RepairMomentum(self.root / "repair_momentum")
        self.trace = trace

    def bind_external_host_execution(self, release_turn_id: str, evidence: Mapping[str, Any]) -> dict[str, Any]:
        release_turn_id = str(release_turn_id).strip()
        turn_path = self.root / "core_turns" / f"{release_turn_id}.json"
        if not release_turn_id or not turn_path.is_file():
            raise KeyError(release_turn_id)
        item = dict(evidence or {})
        nested_evidence = item.get("evidence")
        if isinstance(nested_evidence, Mapping):
            for key in ("image_quality_observation", "quality_iteration", "parent_action_id"):
                if key not in item and key in nested_evidence:
                    item[key] = nested_evidence[key]
        action_id = str(item.get("action_id") or "").strip()
        if action_id:
            from jigaewol_components.canonical_host_bridge import CanonicalHostBridge
            bridge = CanonicalHostBridge(self.root / "canonical_host_bridge")
            action = bridge._read().get("actions", {}).get(action_id)
            if not action or str(action.get("release_turn_id") or "") != release_turn_id:
                raise PermissionError("external host result action does not belong to this release turn")
            if str(item.get("request_sha256") or "") != str(action.get("request_sha256") or ""):
                raise PermissionError("external host result request hash mismatch")
            payload = dict(action.get("payload") or {})
            for key in ("requirement_ids", "requirement_message_sha256", "quality_iteration", "parent_action_id"):
                if key not in item and key in payload:
                    item[key] = payload[key]
        turn_snapshot = load_snapshot(turn_path)
        provider = str(item.get("provider") or item.get("executor") or "external_host")
        operation = str(item.get("operation") or "host_tool")
        capability = str(item.get("capability") or "").strip()
        image_governance = dict(turn_snapshot.get("image_generation_governance") or {})
        image_action = bool(
            ImageSovereigntyPolicy.is_image_capability(capability)
            or ImageSovereigntyPolicy.is_image_capability(operation)
            or str(operation).casefold().startswith("image_gen")
            or (image_governance.get("should_invoke") is True and provider.casefold() in {"image_gen", "higgsfield", "canva"})
        )
        if image_action and not (
            image_governance.get("should_invoke") is True
            and ImageSovereigntyPolicy.validate(
                image_governance.get("sovereignty_contract"),
                source_text=str(image_governance.get("prompt_source_text") or ""),
                mode=str(image_governance.get("mode") or "none"), should_invoke=True,
            )
            and str(image_governance.get("source_message_sha256") or "") == str(turn_snapshot.get("command_sha256") or dict(turn_snapshot.get("requirement_contract") or {}).get("message_sha256") or "")
        ):
            raise PermissionError("external image execution requires the current-turn image contract")
        origin_ref = str(item.get("origin_ref", "")).strip()
        if not origin_ref:
            raise ValueError("external host execution evidence requires host origin_ref")
        if item.get("success") is not True:
            raise ValueError("only successful observed host execution can be bound as proven evidence")
        result = item.get("result", item)

        class _ExternalWork:
            work_id = f"external::{release_turn_id}::{origin_ref}"
            executor = provider
            parameters = {"origin_ref": origin_ref}

        work = _ExternalWork()
        work.operation = operation
        receipt = self.execution_receipts.record(
            work=work,
            result=result,
            success=True,
            provider=provider,
            operation=operation,
            read_back_verified=item.get("read_back_verified"),
        )
        if not self.execution_receipts.verify(receipt.receipt_id):
            raise RuntimeError("external host execution receipt verification failed")
        bound = {
            "origin_ref": origin_ref,
            "status": "proven",
            "success": True,
            "provider": provider,
            "operation": operation,
            "execution_receipt_id": receipt.receipt_id,
            "receipt_sha256": receipt.receipt_sha256,
            "release_turn_id": release_turn_id,
        }
        repair_contract = self.repair_momentum.from_mapping(turn_snapshot.get("repair_momentum_contract") or {})
        if repair_contract.required:
            corrective = self.repair_momentum.record_action(
                turn_id=release_turn_id,
                action_kind="execution",
                target=f"{provider}:{operation}:observed_host_execution",
                evidence_ref=origin_ref,
                note="observed successful host execution bound to a repeated-failure repair turn",
                addressed_terms=repair_contract.issue_terms,
            )
            bound["repair_momentum_receipt_id"] = corrective.receipt_id
            bound["repair_momentum_receipt_sha256"] = corrective.receipt_sha256
        requirement_message_sha256 = str(item.get("requirement_message_sha256") or "").strip()
        requirement_ids = tuple(str(x) for x in item.get("requirement_ids") or () if str(x).strip())
        bound["capability"] = "media:image_generate" if image_action else capability
        bound["requirement_message_sha256"] = requirement_message_sha256
        bound["requirement_ids"] = list(requirement_ids)
        completion_allowed = True
        if image_action:
            quality_contract = dict(image_governance.get("quality_contract") or ImageQualityGovernor.compile_contract(""))
            observation = item.get("image_quality_observation")
            if isinstance(observation, Mapping):
                verdict = ImageQualityGovernor.review_observation(observation, contract=quality_contract)
                bound["image_quality_verdict"] = verdict
                bound["image_quality_review_required"] = True
                if verdict.get("review_required") is True:
                    result_payload = item.get("result") if isinstance(item.get("result"), Mapping) else {}
                    bound["image_quality_review_request"] = ImageQualityGovernor.compile_review_request(
                        generated_ref=str(dict(result_payload or {}).get("image_ref") or origin_ref),
                        contract=quality_contract, parent_action_id=str(item.get("action_id") or ""),
                        requirement_ids=requirement_ids,
                    )
                if verdict.get("accepted") is not True:
                    render_directive = dict(image_governance.get("render_directive") or ImageQualityGovernor.compile_render_directive(quality_contract))
                    rerender_directive = ImageQualityGovernor.rerender_directive(render_directive, verdict)
                    bound["image_rerender_directive"] = rerender_directive
                    iteration = max(0, int(item.get("quality_iteration") or 0))
                    max_iterations = max(1, int(image_governance.get("max_quality_iterations") or 3))
                    bound["image_quality_iteration"] = iteration
                    bound["image_quality_max_iterations"] = max_iterations
                    if item.get("image_rerender_action_id"):
                        bound["image_rerender_action_id"] = str(item["image_rerender_action_id"])
                    elif rerender_directive.get("rerender_required") is True and iteration < max_iterations:
                        from jigaewol_components.canonical_host_bridge import CanonicalHostBridge
                        bridge = CanonicalHostBridge(self.root / "canonical_host_bridge")
                        rerender_action = bridge.route_effect(
                            release_turn_id=release_turn_id,
                            capability="media:image_generate",
                            payload={
                                "objective": str(quality_contract.get("objective") or image_governance.get("prompt_source_text") or ""),
                                "image_generation_governance": image_governance,
                                "image_sovereignty_contract": dict(image_governance.get("sovereignty_contract") or {}),
                                "image_sovereignty_token": str(dict(image_governance.get("sovereignty_contract") or {}).get("authority_token") or ""),
                                "mode": str(image_governance.get("mode") or "generate"),
                                "requirement_ids": list(requirement_ids),
                                "requirement_message_sha256": requirement_message_sha256,
                                "image_rerender_directive": rerender_directive,
                                "quality_iteration": iteration + 1,
                                "parent_action_id": str(item.get("parent_action_id") or item.get("action_id") or ""),
                                "parent_quality_receipt_id": receipt.receipt_id,
                                "parent_origin_ref": origin_ref,
                                "observed_host_receipt_required": True,
                                "reobserve_output_required": True,
                                "generator_role": "render_only",
                                "zip_final_review_required": True,
                            },
                            required=True,
                            preferred_executors=tuple(image_governance.get("preferred_executors") or ("image_gen", "Higgsfield", "Canva")),
                        )
                        bound["image_rerender_action_id"] = rerender_action.action_id
                    else:
                        bound["image_rerender_action_id"] = ""
                        bound["image_quality_retry_exhausted"] = bool(iteration >= max_iterations)
                completion_allowed = bool(verdict.get("accepted") is True)
            else:
                bound["image_quality_review_required"] = True
                result_payload = item.get("result") if isinstance(item.get("result"), Mapping) else {}
                generated_ref = str(dict(result_payload or {}).get("image_ref") or origin_ref)
                bound["image_quality_review_request"] = ImageQualityGovernor.compile_review_request(
                    generated_ref=generated_ref, contract=quality_contract,
                    parent_action_id=str(item.get("action_id") or ""),
                    requirement_ids=requirement_ids,
                )
                bound["image_quality_verdict"] = {
                    "accepted": False,
                    "rerender_required": False,
                    "reason": "zip_post_generation_quality_observation_missing",
                    "final_aesthetic_acceptance_owner": "JIGAEWOL",
                    "generation_actuator_role": "render_only",
                }
                completion_allowed = False
        if requirement_message_sha256 and requirement_ids and completion_allowed:
            anti_shrink = RequirementAntiShrinkLedger(self.root)
            satisfied_ids: list[str] = []
            pending_ids: list[str] = []
            action_id = str(item.get("action_id") or "").strip()
            parent_action_id = str(item.get("parent_action_id") or "").strip()
            for atom_id in requirement_ids:
                if action_id:
                    outcome = anti_shrink.record_action_outcome(
                        requirement_message_sha256,
                        atom_id,
                        action_id,
                        success=True,
                        evidence_refs=(f"execution_receipt:{receipt.receipt_id}", origin_ref),
                        obligation_action_id=parent_action_id or action_id,
                    )
                    if outcome.get("requirement_complete") is True:
                        satisfied_ids.append(atom_id)
                    else:
                        pending_ids.append(atom_id)
                else:
                    anti_shrink.mark(
                        requirement_message_sha256, atom_id, "satisfied",
                        evidence_refs=(f"execution_receipt:{receipt.receipt_id}", origin_ref),
                        note=f"observed external host execution: {provider}/{operation}",
                    )
                    satisfied_ids.append(atom_id)
            bound["satisfied_requirement_ids"] = satisfied_ids
            bound["pending_requirement_ids"] = pending_ids
        elif requirement_message_sha256 and requirement_ids and image_action:
            bound["satisfied_requirement_ids"] = []
            bound["pending_requirement_ids"] = list(requirement_ids)
        self.ledger.attach_runtime(
            release_turn_id, run_id=receipt.receipt_id,
            subsystem="external_host_execution_attestation", success=True, evidence=bound,
        )
        if self.trace is not None:
            self.trace.emit(
                turn_id=release_turn_id,
                phase="EXECUTION",
                status="SUCCEEDED",
                component="EXTERNAL_HOST",
                action=operation,
                provider=provider,
                receipt_id=receipt.receipt_id,
                details=bound,
            )
        return bound

    def _observed_host_failure_evidence(self, release_turn_id: str) -> list[dict[str, Any]]:
        """Return current-turn observed failures from the verified audit chain.

        Failure truth is intentionally separate from successful execution evidence.
        It may justify a scoped failure report, but never completion or a global
        impossibility claim by itself.
        """
        state = self.ledger.read_verified_turn(str(release_turn_id))
        rows: list[dict[str, Any]] = []
        for traversal0 in state.get("traversals", ()):
            if not isinstance(traversal0, Mapping):
                continue
            traversal = dict(traversal0)
            if traversal.get("success") is not False:
                continue
            attached = dict(traversal.get("evidence") or {})
            subsystem = str(traversal.get("subsystem") or "")
            rows.append({
                "origin_ref": f"traversal:{str(traversal.get('receipt_id') or '')}",
                "receipt_id": str(traversal.get("receipt_id") or ""),
                "status": "failed",
                "success": False,
                "terminal": bool(attached.get("terminal") is True),
                "subsystem": subsystem,
                "provider": str(attached.get("provider") or ""),
                "operation": str(attached.get("operation") or subsystem or "host_work"),
                "execution_receipt_id": str(attached.get("execution_receipt_id") or ""),
                "release_turn_id": str(release_turn_id),
            })
        for failure0 in state.get("failures", ()):
            if not isinstance(failure0, Mapping):
                continue
            failure = dict(failure0)
            attached = dict(failure.get("evidence") or {})
            rows.append({
                "origin_ref": f"turn_failure:{str(failure.get('created_at') or '')}",
                "status": "failed",
                "success": False,
                "terminal": bool(attached.get("terminal") is True),
                "subsystem": "turn_failure",
                "provider": str(attached.get("provider") or ""),
                "operation": str(attached.get("operation") or "turn_failure"),
                "detail": str(failure.get("reason") or ""),
                "release_turn_id": str(release_turn_id),
            })
        return rows

    def _verified_host_execution_evidence(self, release_turn_id: str) -> tuple[list[dict[str, Any]], list[str]]:
        state = self.ledger.read_verified_turn(str(release_turn_id))
        accepted_subsystems = {"external_host_execution_attestation", "attested_host_execution"}
        evidence: list[dict[str, Any]] = []
        receipt_ids: list[str] = []
        for traversal in state.get("traversals", ()):
            if traversal.get("success") is not True:
                continue
            if str(traversal.get("subsystem")) not in accepted_subsystems:
                continue
            attached = dict(traversal.get("evidence") or {})
            receipt_id = str(attached.get("execution_receipt_id") or "").strip()
            if not receipt_id:
                continue
            try:
                row = self.execution_receipts.get(receipt_id)
                verified = self.execution_receipts.verify(receipt_id)
            except (KeyError, ValueError, json.JSONDecodeError):
                continue
            if verified is not True or row.get("success") is not True:
                continue
            attached_sha = str(attached.get("receipt_sha256") or "").strip()
            if attached_sha and attached_sha != str(row.get("receipt_sha256") or ""):
                continue
            origin_ref = str(attached.get("origin_ref") or f"execution_receipt:{receipt_id}").strip()
            evidence.append({
                "origin_ref": origin_ref,
                "status": "proven",
                "success": True,
                "provider": str(attached.get("provider") or row.get("provider") or "host"),
                "operation": str(attached.get("operation") or row.get("operation") or "host_work"),
                "execution_receipt_id": receipt_id,
                "receipt_sha256": str(row.get("receipt_sha256") or ""),
                "release_turn_id": str(release_turn_id),
                "capability": str(attached.get("capability") or ""),
                "requirement_message_sha256": str(attached.get("requirement_message_sha256") or ""),
                "requirement_ids": list(attached.get("requirement_ids") or ()),
                "image_quality_verdict": attached.get("image_quality_verdict"),
            })
            receipt_ids.append(receipt_id)
        return evidence, receipt_ids

    def finalize_canonical_turn(
        self,
        release_turn_id: str,
        *,
        ingress_verified: bool,
        control_checkpoint_id: str,
        final_response_sha256: str,
        expected_response_sha256: str | None = None,
        expected_previous_finalizer_receipt_id: str | None = None,
        requirement_manifest: Mapping[str, Any] | None = None,
        final_response_text: str | None = None,
        persist_receipt: bool = True,
    ) -> dict[str, Any]:
        release_turn_id = str(release_turn_id).strip()
        self.ledger.read_verified_turn(release_turn_id)
        turn_path = self.root / "core_turns" / f"{release_turn_id}.json"
        snapshot = load_snapshot(turn_path)
        predecessor = (
            str(expected_previous_finalizer_receipt_id).strip()
            if expected_previous_finalizer_receipt_id is not None
            else str(snapshot.get("expected_previous_finalizer_receipt_id") or "").strip()
        )
        evidence, receipt_ids = self._verified_host_execution_evidence(release_turn_id)
        requirement_contract = RequirementCompiler.from_mapping(dict(snapshot.get("requirement_contract") or {}))
        # Final destination authority is the original exact user message, not a
        # semantic projection, scoped action text, or restored continuation objective.
        # The cumulative ledger stores that body once per message SHA.
        intent_ledger = CumulativeIntentLedger(self.root / "intent" / "cumulative_intent.json")
        exact_user_text = intent_ledger.exact_message(requirement_contract.message_sha256)
        if not exact_user_text:
            raise RuntimeError("canonical_raw_user_message_missing_at_finalization")
        verify_destination(
            raw_user_text=exact_user_text,
            original_user_directive_sha256=requirement_contract.message_sha256,
        )
        verify_atom_conservation(
            raw_user_text=exact_user_text,
            active_atom_ids=(a.atom_id for a in requirement_contract.atoms),
        )

        response_text = str(final_response_text or "")
        response_sha = hashlib.sha256(response_text.encode("utf-8")).hexdigest()
        if response_sha != str(final_response_sha256).strip().lower():
            raise ValueError("final response text does not match its declared SHA-256")
        manifest_coverage = RequirementCompiler.validate_coverage(
            requirement_contract, requirement_manifest, response_text=response_text if response_text else None
        )
        response_coverage = RequirementCompiler.assess_response_coverage(requirement_contract, response_text)
        # Planning coverage and delivery completion are intentionally different.
        # A non-action requirement may be delivered by the final response itself; an
        # action requirement may only become satisfied through observed execution
        # binding (CanonicalHostBridge / bind_external_host_execution).
        anti_shrink = RequirementAntiShrinkLedger(self.root)
        anti_shrink.ensure_contract(requirement_contract)
        response_accounted = set(response_coverage.accounted_ids)
        response_sha_ref = f"final_response_sha256:{final_response_sha256}"
        response_delivery_ids = tuple(atom.atom_id for atom in requirement_contract.atoms
                                      if atom.kind != "action" and atom.atom_id in response_accounted)
        anti_shrink_completion = anti_shrink.completion_coverage(
            requirement_contract.message_sha256, proposed_response_ids=response_delivery_ids
        )
        coverage_ok = bool(
            manifest_coverage.ok
            and response_coverage.ok
            and anti_shrink_completion.get("complete") is True
        )
        failure_evidence = self._observed_host_failure_evidence(release_turn_id)
        scope_integrity = ScopeIntegrityGuard.evaluate(
            response_text=response_text, work_program=dict(snapshot.get("work_program") or {}),
            observations=tuple([*evidence, *failure_evidence]),
            source_text=exact_user_text,
        )
        image_governance = dict(snapshot.get("image_generation_governance") or {})
        image_contract_ok = ImageSovereigntyPolicy.validate(
            image_governance.get("sovereignty_contract"), source_text=exact_user_text,
            mode=str(image_governance.get("mode") or "none"),
            should_invoke=image_governance.get("should_invoke") is True,
        )
        image_requested = image_governance.get("should_invoke") is True
        accepted_image_evidence = [
            row for row in evidence if row.get("capability") == "media:image_generate"
            and row.get("requirement_message_sha256") == requirement_contract.message_sha256
            and dict(row.get("image_quality_verdict") or {}).get("accepted") is True
        ]
        accepted_image_ids = {str(atom_id) for row in accepted_image_evidence for atom_id in row.get("requirement_ids") or ()}
        image_completion_proven = bool(
            not image_requested or accepted_image_evidence
            and set(str(x) for x in image_governance.get("requirement_ids") or ()) <= accepted_image_ids
        )
        coverage_ok = bool(coverage_ok and image_completion_proven)
        frontier = dict(snapshot.get("frontier_control") or {})
        open_execution = dict(snapshot.get("open_execution_state") or {})
        semantic_ceiling = frontier.get("semantic_ceiling")
        alternatives_remaining = bool(open_execution.get("active_frontier_obligation_ids")) or semantic_ceiling is None or semantic_ceiling == ""
        # Removed duplicate speculative-ceiling classifier from finalization.
        # ScopeIntegrityGuard already handles unrequested prefatory claims; the
        # essential remaining checks are exact user scope and actual-effect truth.
        ceiling_ok = True
        ceiling_findings: tuple[str, ...] = ()
        coverage_accounted = tuple(sorted(set(manifest_coverage.accounted_ids) | set(response_coverage.accounted_ids)))
        coverage_missing = tuple(sorted(
            set(manifest_coverage.missing_ids)
            | set(response_coverage.missing_ids)
            | set(anti_shrink_completion.get("missing") or ())
        ))
        coverage_findings = tuple(dict.fromkeys((
            *manifest_coverage.findings,
            *response_coverage.findings,
            *(
                ("anti_shrink_delivery_incomplete:" + ",".join(anti_shrink_completion.get("missing") or ()),)
                if anti_shrink_completion.get("missing") else ()
            ),
        )))
        repair_momentum_contract = self.repair_momentum.from_mapping(snapshot.get("repair_momentum_contract") or {})
        repair_momentum_verdict = self.repair_momentum.verify(
            turn_id=release_turn_id, contract=repair_momentum_contract
        )
        from jigaewol_components.work_program import WorkProgramRuntime
        historical_work_completion = WorkProgramRuntime.objective_completion_evidence(
            WorkProgramRuntime.from_mapping(dict(snapshot.get("work_program") or {}))
        )
        current_requirement_completion = anti_shrink.completion_evidence(
            requirement_contract.message_sha256, proposed_response_ids=response_delivery_ids,
            response_evidence_ref=response_sha_ref,
        )
        # Current-turn finalization is scoped to the exact current user message. Older
        # unfinished goals remain durable work, but they do not veto a later turn whose
        # own requirements carry explicit completion evidence.
        work_completion = current_requirement_completion
        if not image_completion_proven:
            work_completion["proven"] = False
            work_completion["unresolved_goal_refs"] = tuple(dict.fromkeys((
                *tuple(work_completion.get("unresolved_goal_refs") or ()),
                "current_turn_image_quality_review",
            )))
        work_completion["historical_open_work_preserved"] = tuple(
            historical_work_completion.get("unresolved_goal_refs") or ()
        )
        semantic_authority = dict(snapshot.get("semantic_authority") or {})
        objective_completion_required = bool(semantic_authority.get("source_effect_authorized") is True)
        host_execution_required = bool(snapshot.get("host_execution_required") or objective_completion_required)
        finalizer_receipt = self.finalizer.finalize(
            turn_id=release_turn_id,
            ingress_verified=ingress_verified,
            control_checkpoint_id=control_checkpoint_id,
            host_execution_evidence=evidence,
            host_execution_required=host_execution_required,
            final_response_sha256=final_response_sha256,
            expected_response_sha256=expected_response_sha256,
            execution_receipt_ids=receipt_ids,
            expected_previous_finalizer_receipt_id=predecessor,
            gateway_required=bool(snapshot.get("gateway_required")),
            gateway_turn_id=str(snapshot.get("gateway_turn_id") or ""),
            gateway_sequence=int(snapshot.get("gateway_sequence") or 0),
            gateway_token_sha256=str(snapshot.get("gateway_token_sha256") or ""),
            previous_gateway_token_sha256=str(snapshot.get("previous_gateway_token_sha256") or ""),
            gateway_chain_verified=bool(snapshot.get("gateway_chain_verified")),
            gateway_scope_sha256=str(snapshot.get("gateway_scope_sha256") or ""),
            requirement_contract_sha256=requirement_contract.contract_sha256,
            requirement_coverage_ok=coverage_ok,
            requirement_accounted_ids=coverage_accounted,
            requirement_missing_ids=coverage_missing,
            requirement_findings=coverage_findings,
            repair_momentum_required=repair_momentum_contract.required,
            repair_momentum_ok=repair_momentum_verdict.ok,
            repair_momentum_receipt_ids=repair_momentum_verdict.receipt_ids,
            repair_momentum_findings=repair_momentum_verdict.findings,
            directive_fidelity_ok=bool(scope_integrity.ok and ceiling_ok and image_contract_ok),
            directive_fidelity_findings=tuple([*scope_integrity.findings, *ceiling_findings,
                                              *(("image_sovereignty_contract_invalid",) if not image_contract_ok else ())]),
            directive_fidelity_live_requirement_count=scope_integrity.live_requirement_count,
            objective_completion_required=objective_completion_required,
            objective_completion_proven=bool(work_completion.get("proven")),
            objective_completion_evidence_refs=tuple(work_completion.get("evidence_refs") or ()),
            objective_completion_unresolved_goal_refs=tuple(work_completion.get("unresolved_goal_refs") or ()),
            persist_receipt=bool(persist_receipt),
        )
        if persist_receipt and (
            finalizer_receipt.get("final_response_allowed") is True
            or finalizer_receipt.get("progress_response_allowed") is True
        ):
            for atom_id in response_delivery_ids:
                anti_shrink.mark(
                    requirement_contract.message_sha256, atom_id, "satisfied",
                    evidence_refs=(response_sha_ref, str(finalizer_receipt.get("receipt_id") or "")),
                    note="exact response approved by the canonical finalizer",
                )
        return finalizer_receipt
