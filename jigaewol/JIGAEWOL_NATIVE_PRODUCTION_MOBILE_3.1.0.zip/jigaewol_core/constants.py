"""Canonical public identity constants for 지개월.

Public identity is single-source: 지개월 / JIGAEWOL.
"""

VERSION = "3.1.0"
PUBLIC_RUNTIME_NAME = "지개월"
PUBLIC_RUNTIME_ID = "JIGAEWOL_PERSONAL_RUNTIME"
CHARTER_ID = "jigaewol-user-authority-truth-kernel"
