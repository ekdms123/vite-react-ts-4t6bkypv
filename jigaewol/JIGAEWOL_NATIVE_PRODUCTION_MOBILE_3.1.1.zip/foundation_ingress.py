from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

from jigaewol_components.runtime_foundation import RuntimeFoundation
from jigaewol_core.canonical_entrypoint import admit_exact_user_message


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--user", default="user")
    parser.add_argument("--project", default="project")
    parser.add_argument("--session", default="chat")
    parser.add_argument("--command-file", required=True)
    parser.add_argument("--artifact-sha256", default="")
    parser.add_argument("--runtime-identity", default="JIGAEWOL")
    parser.add_argument("--persistent-root")
    parser.add_argument("--output-file", required=True)
    parser.add_argument("--skip-computer-prepare", action="store_true")
    args = parser.parse_args()
    command_bytes = Path(args.command_file).read_bytes()
    command = command_bytes.decode("utf-8")
    canonical_admission = admit_exact_user_message(
        state_root=Path(args.persistent_root) if args.persistent_root else Path(args.project_root) / ".jigaewol_foundation_state",
        raw_message_bytes=command_bytes, user_id=args.user, project_id=args.project, session_id=args.session,
        origin_ref="local:foundation_ingress:new_user_message",
    )
    foundation = RuntimeFoundation(
        Path(args.project_root),
        runtime_identity=args.runtime_identity,
        persistent_root=args.persistent_root,
    )
    snapshot = foundation.ingest(
        command,
        artifact_sha256=args.artifact_sha256,
        prepare_computer=not args.skip_computer_prepare,
    )
    payload = asdict(snapshot)
    payload["canonical_gateway_admission"] = {
        "gateway_turn_id": canonical_admission["gateway_envelope"]["gateway_turn_id"],
        "gateway_sequence": canonical_admission["gateway_envelope"]["gateway_sequence"],
        "exact_message_sha256": canonical_admission["exact_message_sha256"],
    }
    Path(args.output_file).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
