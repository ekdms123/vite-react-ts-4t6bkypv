# Third-party notes

## rank_bm25 BM25+ subset

JIGAEWOL 10.1.2 includes a small modified BM25+ subset derived from `dorianbrown/rank_bm25` at commit `47aa3ddf8dc1ebeb7ef4e65f2b4536af44594099`. The upstream project is Apache License 2.0. The retained license text is packaged at `jigaewol_runtime/vendor/LICENSE.rank_bm25.txt`. JIGAEWOL modifications remove multiprocessing and NumPy from the scorer, define empty-corpus behavior, and keep only the BM25+ mechanics needed for deterministic capability ranking.

## Optional packages

NetworkX, when installed, may be used for Weisfeiler–Lehman graph hashing; JIGAEWOL remains functional without it through its fallback implementation.

## Optional Pyodide addon
Browser/WASM execution files are retained under jigaewol_runtime/wasm_assets. Full upstream license texts remain bundled with those files.

