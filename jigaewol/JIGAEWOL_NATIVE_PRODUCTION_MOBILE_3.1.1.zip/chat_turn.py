from __future__ import annotations

import argparse
import hashlib
import json
import re
import uuid
from dataclasses import asdict
from pathlib import Path
from typing import Any

from jigaewol_components.mobile_exokernel import MobileExokernelController, TurnPlan
from jigaewol_core.canonical_entrypoint import admit_exact_user_message
from jigaewol_core.turn_gateway import TurnGateway
from jigaewol_components.intent_fidelity import IntentFidelityProjector, GhostVerdict
from jigaewol_components.intent_deep_analyzer import IntentDeepAnalyzer
from jigaewol_components.requirement_contract import RequirementCompiler
from jigaewol_components.requirement_anti_shrink import RequirementAntiShrinkLedger
from jigaewol_components.image_generation_governance import ImageGenerationGovernance
from jigaewol_components.image_quality_governor import ImageQualityGovernor
from jigaewol_components.image_sovereignty import ImageSovereigntyPolicy
from jigaewol_components.canonical_host_bridge import CanonicalHostBridge
from jigaewol_components.scope_integrity import ScopeIntegrityGuard
from jigaewol_components.no_premature_ceiling import NoPrematureCeilingPolicy
from jigaewol_components.response_language import observed_failure_rows
from jigaewol_components.ambition_preserver import AmbitionPreserver
from jigaewol_components.strategy_topology import StrategyTopologySelector
from jigaewol_components.capability_federation import CapabilityFederation
from jigaewol_components.response_protocol import (
    CandidateResponse, CandidateBundle, HypothesisCandidate, ReleasedResponse, ReleasedResponseGroup
)
from jigaewol_components.response_sink import ResponseSink
from jigaewol_components.completion_claim_guard import detect_unproven_completion_claim
from jigaewol_components.runtime_foundation import RuntimeFoundation
from jigaewol_components.turn_audit import TurnAuditLedger
from jigaewol_components.resident_cognition import ResidentCognitionLoop, ResidentHypothesis
from jigaewol_components.deep_open_cognition import OpenCognitionEngine, MetaConstitutionLab, EpistemicMode, QualitativeTension
from jigaewol_core.canonical_finalizer import CanonicalTurnFinalizer


class ChatTurnRuntime:
    """Mobile chat ingress + adaptive exokernel + exact candidate release interface.

    The old V9.3 fast bind is kept as the low-latency floor, but it is no longer the
    whole traversal.  Each turn now binds an explicit route plan.  When the plan says
    the objective requires deep cognition, search, signed-in browser observation, or
    external capability acquisition, durable host syscalls are emitted and required
    host results must be returned before the runtime may claim a successful traversal.
    """

    def __init__(
        self,
        root: Path,
        *,
        project_root: Path | None = None,
        persistent_root: Path | None = None,
        canonical_artifact_path: Path | None = None,
        runtime_identity: str = "JIGAEWOL_PERSONAL_RUNTIME",
        charter_id: str = "frontier-charter-v15-adaptive-fidelity",
        require_gateway_turn: bool = False,
        gateway_envelope: dict[str, Any] | None = None,
        gateway_user_id: str = "user",
        gateway_project_id: str = "project",
        gateway_session_id: str = "chat",
    ) -> None:
        self.root = Path(root)
        self.require_gateway_turn = bool(require_gateway_turn)
        self.gateway_envelope = dict(gateway_envelope or {})
        self.gateway_user_id = str(gateway_user_id)
        self.gateway_project_id = str(gateway_project_id)
        self.gateway_session_id = str(gateway_session_id)
        if self.require_gateway_turn and not self.gateway_envelope:
            raise PermissionError("chat_turn canonical gateway envelope required")
        self.project_root = Path(project_root or Path(__file__).resolve().parent).resolve()
        if canonical_artifact_path is None:
            raise ValueError("canonical_artifact_path is required; caller-supplied artifact SHA is not authoritative")
        self.canonical_artifact_path = Path(canonical_artifact_path).resolve()
        self.foundation = RuntimeFoundation(
            self.project_root,
            runtime_identity=runtime_identity,
            persistent_root=persistent_root,
        )
        self.controller = MobileExokernelController(self.foundation)
        self.intent_deep_analyzer = IntentDeepAnalyzer()
        self.audit = TurnAuditLedger(
            self.root / "turn_audit",
            runtime_identity=runtime_identity,
            charter_id=charter_id,
            canonical_artifact_path=self.canonical_artifact_path,
        )
        # There is no legacy publication bypass in the chat runtime.  Every direct
        # body or response group must bind to the same strong canonical finalizer
        # receipt used by the core runtime before the CAS sink will publish it.
        self.finalizer = CanonicalTurnFinalizer(self.root / "canonical_finalizer")
        self.sink = ResponseSink(self.root / "response_sink", require_finalization_permit=True)
        self.resident = ResidentCognitionLoop(self.foundation.root / "resident_cognition")
        self.open_cognition = OpenCognitionEngine(self.foundation.root / "open_cognition")
        self.meta_constitution = MetaConstitutionLab(
            self.foundation.root / "meta_constitution",
            bootstrap_invariants={
                "single_candidate_required": False,
                "formal_evidence_required_for_idea_admission": False,
                "pareto_is_only_survival_basis": False,
                "resident_requires_external_stimulus": True,
                "host_model_is_generative_substrate": True,
            },
        )

    def admit_divergent_spark(
        self,
        body: str,
        *,
        source: str = "host_model",
        epistemic_mode: str = EpistemicMode.SPECULATIVE.value,
        evidence_refs: tuple[str, ...] = (),
        qualitative_tensions: tuple[QualitativeTension, ...] = (),
        metadata: dict[str, Any] | None = None,
    ):
        """Admit an intuition-like idea without requiring evidence at admission time."""
        return self.open_cognition.admit_spark(
            body, source=source, epistemic_mode=epistemic_mode, evidence_refs=evidence_refs,
            qualitative_tensions=qualitative_tensions, metadata=metadata,
        )

    def ingest_generative_substrate_output(
        self, raw_output: str, *, substrate_id: str = "host-model", context: dict[str, Any] | None = None,
        epistemic_mode: str = EpistemicMode.SPECULATIVE.value,
        qualitative_tensions: tuple[QualitativeTension, ...] = (),
    ):
        """Preserve raw host-model divergence before schema/ranking compression."""
        return self.open_cognition.ingest_substrate_output(
            raw_output, substrate_id=substrate_id, prompt_or_context=context or {},
            epistemic_mode=epistemic_mode, tensions=qualitative_tensions,
        )

    def prepare_turn(
        self,
        *,
        user_command: str,
        traversal_run_id: str,
        turn_plan: dict[str, Any] | None = None,
        host_surfaces: list[dict[str, Any]] | tuple[dict[str, Any], ...] = (),
    ) -> dict[str, Any]:
        gateway = TurnGateway(
            self.root / "turn_gateway",
            user_id=self.gateway_user_id, project_id=self.gateway_project_id, session_id=self.gateway_session_id,
        )
        if self.require_gateway_turn:
            gateway_envelope = dict(self.gateway_envelope)
        else:
            # Programmatic/legacy callers no longer form a second ingress authority
            # path.  They are admitted through the same exact-byte canonical entrypoint
            # locally before any semantic planning or host-route derivation occurs.
            admission = admit_exact_user_message(
                state_root=self.root,
                raw_message_bytes=str(user_command).encode("utf-8"),
                user_id=self.gateway_user_id,
                project_id=self.gateway_project_id,
                session_id=self.gateway_session_id,
                origin_ref="local:chat_turn:programmatic_user_message",
            )
            gateway_envelope = dict(admission["gateway_envelope"])
        gateway_proof = gateway.verify_for_ingress(gateway_envelope, message=user_command)
        enriched_plan, intent_deep_analysis = self.intent_deep_analyzer.enrich_plan_mapping(
            user_command,
            turn_plan,
            observations=self.foundation.live_context.recent(64),
            active_requirements=self.foundation.intent.active(),
        )
        requirement_contract = RequirementCompiler.compile(user_command)
        goal_anchor = AmbitionPreserver.anchor(user_command)
        preliminary_topology = StrategyTopologySelector.select(
            user_command, requirement_contract,
            search_required=bool(enriched_plan.get("search_required", False)),
            external_capability_required=bool(enriched_plan.get("external_capability_required", False)),
            signed_in_browser_preferred=bool(enriched_plan.get("signed_in_browser_preferred", False)),
            deep_reasoning_required=enriched_plan.get("deep_reasoning_required"),
        )
        facets = AmbitionPreserver.bind_facets(enriched_plan.get("facets"), goal_anchor)
        facets["requirement_contract"] = requirement_contract.as_mapping()
        image_governance = ImageGenerationGovernance.compile(
            user_command, requirements=[asdict(atom) for atom in requirement_contract.atoms],
            attachments=tuple((turn_plan or {}).get("attachments") or ()),
        ).as_mapping()
        facets["image_generation_governance"] = image_governance
        facets["image_sovereignty_contract"] = image_governance["sovereignty_contract"]
        facets["strategy_topology"] = preliminary_topology.as_mapping()
        recurrence_added = self.foundation.anti_recurrence.observe(user_command)
        facets["anti_recurrence_invariants"] = [asdict(x) for x in self.foundation.anti_recurrence.active()]
        facets["anti_recurrence_new_ids"] = [x.invariant_id for x in recurrence_added]
        enriched_plan["facets"] = facets
        # Bind the exact command hash only when the caller omitted it.  A supplied
        # mismatched hash is intentionally left intact so TurnPlan rejects it; the
        # analyzer must never "repair" evidence of a plan bound to another command.
        expected_command_sha256 = hashlib.sha256(user_command.encode("utf-8")).hexdigest()
        if not enriched_plan.get("command_sha256"):
            enriched_plan["command_sha256"] = expected_command_sha256
        plan = TurnPlan.from_mapping(user_command, enriched_plan)
        snapshot, task_id = self.controller.prepare(
            user_command,
            artifact_sha256=self.audit.current_artifact_identity()[0],
            plan=plan,
            host_surfaces=host_surfaces,
            turn_key=traversal_run_id,
        )
        federation = CapabilityFederation.from_host_surfaces(host_surfaces)
        image_dispatch = None
        if image_governance.get("should_invoke") is True:
            bridge = CanonicalHostBridge(self.root / "canonical_host_bridge")
            anti_shrink = RequirementAntiShrinkLedger(self.root)
            image_action = bridge.route_effect(
                release_turn_id=str(traversal_run_id), capability="media:image_generate",
                payload={"objective": user_command, "image_generation_governance": image_governance,
                         "image_sovereignty_contract": image_governance["sovereignty_contract"],
                         "image_sovereignty_token": image_governance["sovereignty_contract"]["authority_token"],
                         "mode": image_governance["mode"],
                         "requirement_ids": list(image_governance["requirement_ids"]),
                         "requirement_message_sha256": requirement_contract.message_sha256,
                         "generator_role": "render_only", "zip_final_review_required": True},
                preferred_executors=tuple(image_governance["preferred_executors"]),
            )
            anti_shrink.plan_from_runtime(requirement_contract, host_actions=(image_action,))
            image_dispatch = bridge.export_dispatch_batch(str(traversal_run_id))
        return {
            "exact_user_text": user_command,
            "image_generation_governance": image_governance,
            "canonical_image_dispatch_batch": image_dispatch,
            "turn_plan": asdict(plan),
            "intent_deep_analysis": intent_deep_analysis.as_facet(),
            "requirement_contract": requirement_contract.as_mapping(),
            "requirement_manifest_template": RequirementCompiler.release_manifest_template(requirement_contract),
            "goal_anchor": asdict(goal_anchor),
            "strategy_topology": preliminary_topology.as_mapping(),
            "capability_federation": [asdict(x) for x in federation],
            "control_snapshot": asdict(snapshot),
            "gateway_envelope": gateway_envelope,
            "gateway_proof": gateway_proof,
            "continuity_task_id": task_id,
            "host_execution_required": bool(snapshot.required_host_request_ids),
        }

    @staticmethod
    def _snapshot_from_mapping(control_raw: dict[str, Any]):
        from jigaewol_components.mobile_exokernel import TurnControlSnapshot
        return TurnControlSnapshot(
            **{
                **control_raw,
                "local_stages": tuple(control_raw.get("local_stages", ())),
                "host_requests": tuple(control_raw.get("host_requests", ())),
                "primary_required_host_request_ids": tuple(control_raw.get("primary_required_host_request_ids", control_raw.get("required_host_request_ids", ()))),
                "ghost_host_request_ids": tuple(control_raw.get("ghost_host_request_ids", ())),
                "required_host_request_ids": tuple(control_raw.get("required_host_request_ids", ())),
                "requirement_atoms": tuple(control_raw.get("requirement_atoms", ())),
                "missing_required_host_results": tuple(control_raw.get("missing_required_host_results", ())),
                "failed_required_host_results": tuple(control_raw.get("failed_required_host_results", ())),
            }
        )

    def advance_turn(
        self,
        *,
        user_command: str,
        traversal_run_id: str,
        turn_plan: dict[str, Any] | None = None,
        host_surfaces: list[dict[str, Any]] | tuple[dict[str, Any], ...] = (),
        host_results: list[dict[str, Any]] | tuple[dict[str, Any], ...] = (),
    ) -> dict[str, Any]:
        prepared = self.prepare_turn(
            user_command=user_command,
            traversal_run_id=traversal_run_id,
            turn_plan=turn_plan,
            host_surfaces=host_surfaces,
        )
        control = self._snapshot_from_mapping(prepared["control_snapshot"])
        applied: tuple[dict[str, Any], ...] = ()
        if host_results:
            pending_ids = {x.syscall_id for x in self.controller.pump.pending()}
            fresh_host_results = [
                dict(x) for x in host_results
                if str(x.get("syscall_id") or "") in pending_ids
            ]
            if fresh_host_results:
                applied, control = self.controller.apply_host_results_with_fidelity(
                    fresh_host_results,
                    snapshot=control,
                    user_command=user_command,
                    turn_key=traversal_run_id,
                    continuity_task_id=prepared["continuity_task_id"],
                )
        control = self.controller.refresh_contract(control)
        pending = [
            asdict(x) for x in self.controller.pump.pending()
            if x.syscall_id in set(control.required_host_request_ids)
        ]
        return {
            "turn_plan": prepared["turn_plan"],
            "control_snapshot": asdict(control),
            "continuity_task_id": prepared["continuity_task_id"],
            "host_results_applied": list(applied),
            "pending_required_host_requests": pending,
            "host_execution_required": bool(pending),
        }

    @staticmethod
    def _normalize_release_body(body: str, *, runtime_footer: bool = False) -> str:
        """Preserve generated text verbatim. Keep the keyword for existing callers."""
        return str(body)

    @staticmethod
    def _strong_host_evidence(
        *, control, applied: tuple[dict[str, Any], ...]
    ) -> tuple[tuple[dict[str, Any], ...], tuple[str, ...]]:
        """Project only observed successful *primary required* host effects as proof."""
        required = set(map(str, control.primary_required_host_request_ids or ()))
        rows: list[dict[str, Any]] = []
        refs: list[str] = []
        for raw in applied:
            item = dict(raw)
            sid = str(item.get("syscall_id") or "")
            if not sid or sid not in required or item.get("success") is not True:
                continue
            rows.append({
                "origin_ref": f"host_syscall:{sid}",
                "status": "proven",
                "success": True,
                "syscall_id": sid,
                "operation": str(item.get("operation") or ""),
                "executor": str(item.get("executor") or ""),
                "evidence": dict(item.get("evidence") or {}),
            })
            refs.append(f"host_syscall:{sid}")
        return tuple(rows), tuple(refs)

    def _strong_finalize_and_permit(
        self,
        *,
        ingress_turn_id: str,
        response_sha256: str,
        response_text: str,
        traversal_run_id: str,
        requirement_contract,
        requirement_coverage_ok: bool,
        requirement_accounted_ids: tuple[str, ...],
        requirement_missing_ids: tuple[str, ...],
        requirement_findings: tuple[str, ...],
        control,
        applied: tuple[dict[str, Any], ...],
        objective_completed: bool,
        prepared: dict[str, Any],
    ):
        host_evidence, host_refs = self._strong_host_evidence(control=control, applied=applied)
        host_execution_required = bool(control.primary_required_host_request_ids)
        objective_completion_proven = bool(
            host_execution_required
            and objective_completed
            and requirement_coverage_ok
            and not control.missing_required_host_results
            and not control.failed_required_host_results
            and len(host_refs) >= len(tuple(control.primary_required_host_request_ids or ()))
        )
        primary_host_complete = (
            set(str(x) for x in control.primary_required_host_request_ids or ())
            <= {str(row.get("syscall_id") or "") for row in host_evidence}
        )
        gateway_proof = dict(prepared.get("gateway_proof") or {})
        exact_text = str(prepared.get("exact_user_text") or "")
        scope_work = {"nodes": [{
            "node_id": "chat_release", "state": "ready",
            "goal_refs": [atom.atom_id for atom in requirement_contract.atoms],
            "effect_request": {"source_text": exact_text, "source_kind": "user", "source_critical": True},
        }]}
        failures = observed_failure_rows(applied)
        scope = ScopeIntegrityGuard.evaluate(
            response_text=response_text, work_program=scope_work,
            observations=failures, source_text=exact_text,
        )
        ceiling = NoPrematureCeilingPolicy.evaluate(
            response_text, observed_failures=failures, source_text=exact_text, alternatives_remaining=True,
        )
        image_governance = dict(prepared.get("image_generation_governance") or {})
        image_contract_ok = ImageSovereigntyPolicy.validate(
            image_governance.get("sovereignty_contract"), source_text=exact_text,
            mode=str(image_governance.get("mode") or "none"),
            should_invoke=image_governance.get("should_invoke") is True,
        )
        image_requested = image_governance.get("should_invoke") is True
        if image_requested:
            image_evidence = tuple(
                row for row in CanonicalHostBridge(self.root / "canonical_host_bridge").successful_evidence(str(traversal_run_id))
                if row.get("capability") == "media:image_generate"
                and dict(row.get("image_quality_verdict") or {}).get("accepted") is True
                and row.get("requirement_message_sha256") == requirement_contract.message_sha256
            )
            host_evidence = (*host_evidence, *image_evidence)
            host_refs = (*host_refs, *(str(row["origin_ref"]) for row in image_evidence))
            host_execution_required = True
            objective_completion_proven = bool(
                image_evidence and image_contract_ok and primary_host_complete
                and objective_completed and requirement_coverage_ok
                and not control.missing_required_host_results and not control.failed_required_host_results
            )
        directive_findings = (*requirement_findings, *scope.findings,
                              *(f"premature_ceiling:{match}" for match in ceiling.matches if not ceiling.ok),
                              *(("image_sovereignty_contract_invalid",) if not image_contract_ok else ()))
        strong = self.finalizer.finalize(
            turn_id=str(ingress_turn_id),
            ingress_verified=bool(gateway_proof.get("gateway_verified")),
            control_checkpoint_id=str(traversal_run_id),
            host_execution_evidence=host_evidence,
            host_execution_required=host_execution_required,
            final_response_sha256=str(response_sha256),
            expected_response_sha256=str(response_sha256),
            execution_receipt_ids=host_refs,
            expected_previous_finalizer_receipt_id=(self.finalizer.latest_applied_full_receipt_id() or None),
            gateway_required=True,
            gateway_turn_id=str(gateway_proof.get("gateway_turn_id") or ""),
            gateway_sequence=int(gateway_proof.get("gateway_sequence") or 0),
            gateway_token_sha256=str(gateway_proof.get("gateway_token_sha256") or ""),
            previous_gateway_token_sha256=str(gateway_proof.get("previous_gateway_token_sha256") or ""),
            gateway_chain_verified=bool(gateway_proof.get("gateway_verified")),
            gateway_scope_sha256=str(gateway_proof.get("gateway_scope_sha256") or ""),
            requirement_contract_sha256=str(requirement_contract.contract_sha256),
            requirement_coverage_ok=bool(requirement_coverage_ok),
            requirement_accounted_ids=tuple(requirement_accounted_ids),
            requirement_missing_ids=tuple(requirement_missing_ids),
            requirement_findings=tuple(requirement_findings),
            # Lexical/style/boundary detectors are diagnostics, not publication vetoes.
            # Only source requirement coverage and relevant observed artifact checks
            # can affect finality; wording heuristics must not overrule the user.
            directive_fidelity_ok=bool(requirement_coverage_ok and image_contract_ok),
            directive_fidelity_findings=directive_findings,
            directive_fidelity_live_requirement_count=len(tuple(requirement_contract.atoms)),
            objective_completion_required=host_execution_required,
            objective_completion_proven=objective_completion_proven,
            objective_completion_evidence_refs=host_refs if objective_completion_proven else (),
            objective_completion_unresolved_goal_refs=(
                () if (not host_execution_required or objective_completion_proven)
                else (str(prepared.get("continuity_task_id") or "current_user_objective"),)
            ),
        )
        if strong.get("final_response_allowed") is True:
            semantics = "SOLVED"
        elif strong.get("progress_response_allowed") is True:
            if host_execution_required:
                claim = detect_unproven_completion_claim(response_text)
                if claim.blocked:
                    raise PermissionError(
                        "release integrity: unproven completion claim in progress response: "
                        + "; ".join(claim.matches)
                    )
            semantics = "INCOMPLETE"
        else:
            raise PermissionError("canonical finalizer denied both final and progress publication")
        chain_sha = hashlib.sha256(json.dumps({
            "turn_id": str(ingress_turn_id),
            "traversal_run_id": str(traversal_run_id),
            "response_sha256": str(response_sha256),
            "strong_finalizer_receipt_id": str(strong.get("receipt_id") or ""),
        }, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        permit = self.finalizer.prepare(
            turn_id=str(ingress_turn_id),
            response_sha256=str(response_sha256),
            loop_chain_sha256=chain_sha,
            requirement_contract_sha256=str(requirement_contract.contract_sha256),
            observation_chain_sha256=(
                hashlib.sha256(json.dumps(list(host_evidence), ensure_ascii=False, sort_keys=True, default=str,
                                           separators=(",", ":")).encode("utf-8")).hexdigest()
                if host_evidence else ""
            ),
            terminal_semantics=semantics,
            strong_finalizer_receipt_id=str(strong.get("receipt_id") or ""),
        )
        return strong, permit, chain_sha, objective_completion_proven

    @staticmethod
    def _should_seed_resident(*, mode: str, hypothesis_count: int, unresolved_frontier: bool) -> bool:
        normalized = str(mode or "frontier").strip().lower()
        if normalized == "always":
            return True
        if normalized == "never":
            return False
        # Any other label is treated as a caller-defined frontier policy rather than
        # rejected by a closed mode enum. The default remains evidence of unresolved
        # work, not a ritual attached to every turn.
        return bool(unresolved_frontier or hypothesis_count > 1)

    def _enqueue_resident_frontier(
        self,
        *,
        source_turn_id: str,
        task_id: str,
        objective: str,
        hypotheses: tuple[HypothesisCandidate, ...],
        release_group_id: str | None = None,
        max_cycles: int | None = None,
    ) -> str:
        rows = tuple(
            ResidentHypothesis(
                hypothesis_id=str(x.candidate_id),
                body=str(x.body),
                generation=0,
                assumptions=tuple(x.assumptions),
                evidence_refs=tuple(x.evidence_refs),
                counterevidence_refs=tuple(x.counterevidence_refs),
                uncertainty=float(x.uncertainty),
                epistemic_mode=str(x.epistemic_mode),
                preservation_basis=tuple(x.preservation_basis),
                qualitative_tensions=tuple(x.qualitative_tensions),
                raw_spark_sha256=str(x.raw_spark_sha256),
                metadata={
                    **dict(x.metadata),
                    "resident_seed_id": "",
                    "release_group_id": str(release_group_id or ""),
                    "source": "released_hypothesis",
                },
                created_at=0.0,
            )
            for x in hypotheses
        )
        seed = self.resident.enqueue(
            task_id=str(task_id),
            source_turn_id=str(source_turn_id),
            objective=str(objective),
            hypotheses=rows,
            context={"release_group_id": str(release_group_id or ""), "source_turn_id": str(source_turn_id)},
            max_cycles=max_cycles,
            metadata={
                "trigger": "post_release",
                "release_group_id": str(release_group_id or ""),
                "require_external_stimulus": True,
                "continuation_policy": "observe_then_continue_when_information_changes",
            },
        )
        return seed.seed_id

    def seal_and_release(
        self,
        *,
        user_command: str,
        candidate_body: str,
        traversal_run_id: str,
        traversal_subsystem: str,
        traversal_success: bool,
        traversal_evidence: dict,
        producer: str = "chat-host-candidate",
        objective_completed: bool = False,
        turn_plan: dict[str, Any] | None = None,
        host_surfaces: list[dict[str, Any]] | tuple[dict[str, Any], ...] = (),
        host_results: list[dict[str, Any]] | tuple[dict[str, Any], ...] = (),
        candidate_manifest: dict[str, Any] | None = None,
        resident_continuation: str = "frontier",
        unresolved_frontier: bool = False,
        runtime_footer: bool = False,
    ) -> ReleasedResponse:
        prepared = self.prepare_turn(
            user_command=user_command,
            traversal_run_id=traversal_run_id,
            turn_plan=turn_plan,
            host_surfaces=host_surfaces,
        )
        control_raw = prepared["control_snapshot"]
        control = self._snapshot_from_mapping(control_raw)
        applied: tuple[dict[str, Any], ...] = ()
        if host_results:
            pending_ids = {x.syscall_id for x in self.controller.pump.pending()}
            fresh_host_results = [
                dict(x) for x in host_results
                if str(x.get("syscall_id") or "") in pending_ids
            ]
            if fresh_host_results:
                applied, control = self.controller.apply_host_results_with_fidelity(
                    fresh_host_results,
                    snapshot=control,
                    user_command=user_command,
                    turn_key=traversal_run_id,
                    continuity_task_id=prepared["continuity_task_id"],
                )
        control = self.controller.refresh_contract(control)

        requirement_contract = RequirementCompiler.compile(user_command)
        requirement_coverage = RequirementCompiler.validate_coverage(requirement_contract, candidate_manifest)
        candidate_manifest_ok = requirement_coverage.ok
        candidate_manifest_findings: tuple[str, ...] = tuple(requirement_coverage.findings)
        if control.primary_required_host_request_ids:
            if not control.ghost_verified or not control.ghost_bundle_sha256 or not control.ghost_worlds_sha256:
                candidate_manifest_ok = False
                candidate_manifest_findings = ("adaptive_fidelity_verification_not_complete",)
            else:
                verdict = GhostVerdict(
                    bundle_sha256=control.ghost_bundle_sha256,
                    verified=control.ghost_verified,
                    world_count=0,
                    requirement_atoms=tuple(control.requirement_atoms),
                    covered_syscall_ids=tuple(control.primary_required_host_request_ids),
                    covered_marker_ids=(),
                    findings=(),
                    verified_at=0.0,
                    worlds_sha256=control.ghost_worlds_sha256,
                )
                host_manifest_ok, host_manifest_findings = IntentFidelityProjector.validate_candidate_manifest(
                    candidate_body=str(candidate_body),
                    manifest=candidate_manifest,
                    verdict=verdict,
                    primary_required_syscall_ids=control.primary_required_host_request_ids,
                )
                candidate_manifest_ok = candidate_manifest_ok and host_manifest_ok
                candidate_manifest_findings = tuple(candidate_manifest_findings) + tuple(host_manifest_findings)
        contract_success = bool(traversal_success and control.contract_satisfied and candidate_manifest_ok)

        ingress = self.audit.begin(user_command)
        evidence = dict(traversal_evidence)
        evidence.pop("artifact_sha256", None)
        def _sha_json(value: Any) -> str:
            raw = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
            return hashlib.sha256(raw.encode("utf-8")).hexdigest()

        cumulative_intent = self.foundation.intent.compose(user_command)
        host_requests = list(control.host_requests)
        host_results_applied = list(applied)
        evidence["persistent_runtime_root"] = str(self.foundation.root)
        evidence["cumulative_requirement_count"] = len(self.foundation.intent.active())
        evidence["cumulative_intent_attached"] = True
        evidence["cumulative_intent_sha256"] = _sha_json(cumulative_intent)
        evidence["turn_plan_sha256"] = _sha_json(prepared["turn_plan"])
        evidence["foundation_snapshot_sha256"] = _sha_json(control.foundation)
        evidence["turn_contract_version"] = control.contract_version
        evidence["turn_contract_sha256"] = control.contract_sha256
        evidence["turn_contract_satisfied"] = contract_success
        evidence["exact_user_command_bound"] = control.command_sha256 == ingress.command_sha256
        evidence["cumulative_intent_bound"] = "cumulative_intent_bound" in control.local_stages
        evidence["continuity_bound"] = "continuity_bound" in control.local_stages
        evidence["route_plan_bound"] = "route_plan_bound" in control.local_stages
        evidence["host_request_count"] = len(host_requests)
        evidence["host_request_ids"] = [str(x.get("syscall_id", "")) for x in host_requests]
        evidence["host_result_count"] = len(host_results_applied)
        evidence["host_result_ids"] = [str(x.get("syscall_id", "")) for x in host_results_applied]
        evidence["primary_required_host_request_ids"] = list(control.primary_required_host_request_ids)
        evidence["ghost_host_request_ids"] = list(control.ghost_host_request_ids)
        evidence["required_host_request_ids"] = list(control.required_host_request_ids)
        evidence["missing_required_host_results"] = list(control.missing_required_host_results)
        evidence["failed_required_host_results"] = list(control.failed_required_host_results)
        evidence["fidelity_mode"] = control.fidelity_mode
        evidence["ghost_bundle_sha256"] = control.ghost_bundle_sha256
        evidence["ghost_verified"] = control.ghost_verified
        evidence["ghost_worlds_sha256"] = control.ghost_worlds_sha256
        evidence["requirement_atom_ids"] = [str(x.get("atom_id", "")) for x in control.requirement_atoms]
        evidence["candidate_manifest_ok"] = candidate_manifest_ok
        evidence["candidate_manifest_findings"] = list(candidate_manifest_findings)
        evidence["requirement_contract_sha256"] = requirement_contract.contract_sha256
        evidence["requirement_accounted_ids"] = list(requirement_coverage.accounted_ids)
        evidence["requirement_missing_ids"] = list(requirement_coverage.missing_ids)

        self.audit.attach_runtime(
            ingress.turn_id,
            run_id=traversal_run_id,
            subsystem=traversal_subsystem,
            success=contract_success,
            evidence=evidence,
        )
        if not contract_success:
            self.audit.fail_turn(
                ingress.turn_id,
                reason="adaptive turn contract not satisfied",
                evidence={
                    "missing_required_host_results": list(control.missing_required_host_results),
                    "failed_required_host_results": list(control.failed_required_host_results),
                    "ghost_verified": control.ghost_verified,
                    "candidate_manifest_findings": list(candidate_manifest_findings),
                },
            )
            raise RuntimeError(
                "JIGAEWOL turn contract not satisfied; required host execution is missing or failed: "
                f"missing={list(control.missing_required_host_results)} failed={list(control.failed_required_host_results)}"
            )

        body = self._normalize_release_body(candidate_body, runtime_footer=runtime_footer)
        candidate = CandidateResponse(
            turn_id=ingress.turn_id,
            body=body,
            producer=str(producer),
            evidence=evidence,
        )
        self.audit.bind_candidate(ingress.turn_id, candidate)
        strong_finalizer, permit, chain_sha, objective_completion_proven = self._strong_finalize_and_permit(
            ingress_turn_id=ingress.turn_id,
            response_sha256=candidate.response_sha256,
            response_text=candidate.body,
            traversal_run_id=traversal_run_id,
            requirement_contract=requirement_contract,
            requirement_coverage_ok=bool(requirement_coverage.ok),
            requirement_accounted_ids=tuple(requirement_coverage.accounted_ids),
            requirement_missing_ids=tuple(requirement_coverage.missing_ids),
            requirement_findings=tuple(requirement_coverage.findings),
            control=control,
            applied=applied,
            objective_completed=bool(objective_completed),
            prepared=prepared,
        )
        evidence["objective_completion_requested"] = bool(objective_completed)
        evidence["objective_completion_proven"] = objective_completion_proven
        evidence["strong_finalizer_receipt_id"] = str(strong_finalizer.get("receipt_id") or "")
        evidence["finalization_permit_sha256"] = str(permit.permit_sha256)
        released = self.sink.commit(
            candidate=candidate,
            permit=permit,
            user_command=user_command,
            permit_verifier=lambda value: self.finalizer.verify_permit(
                value, expected_loop_chain_sha256=chain_sha
            ),
        )
        self.foundation.mark_response_release(
            release_receipt=released.integrity_receipt_id,
            response_sha256=released.body_sha256,
            objective_completed=objective_completion_proven,
            task_id=prepared["continuity_task_id"],
        )
        if self._should_seed_resident(
            mode=resident_continuation, hypothesis_count=1, unresolved_frontier=unresolved_frontier
        ):
            self._enqueue_resident_frontier(
                source_turn_id=released.turn_id,
                task_id=prepared["continuity_task_id"],
                objective=user_command,
                hypotheses=(HypothesisCandidate(
                    candidate_id=f"hyp_{uuid.uuid4().hex[:16]}",
                    body=body,
                    producer=str(producer),
                    uncertainty=0.5,
                    metadata={"single_release_seed": True, "unresolved_frontier": bool(unresolved_frontier)},
                ),),
            )
        if control.primary_required_host_request_ids:
            self.controller.purge_ghost_state(traversal_run_id, control)
        return released


    def seal_and_release_superposed(
        self,
        *,
        user_command: str,
        hypotheses: list[dict[str, Any]] | tuple[dict[str, Any], ...],
        traversal_run_id: str,
        traversal_subsystem: str,
        traversal_success: bool,
        traversal_evidence: dict,
        release_group_id: str | None = None,
        objective_completed: bool = False,
        turn_plan: dict[str, Any] | None = None,
        host_surfaces: list[dict[str, Any]] | tuple[dict[str, Any], ...] = (),
        host_results: list[dict[str, Any]] | tuple[dict[str, Any], ...] = (),
        candidate_manifests: dict[str, dict[str, Any]] | None = None,
        resident_max_cycles: int | None = None,
        resident_continuation: str = "frontier",
        runtime_footer: bool = False,
    ) -> ReleasedResponseGroup:
        if len(tuple(hypotheses)) < 2:
            raise ValueError("superposed release requires at least two materially distinct hypotheses")
        prepared = self.prepare_turn(
            user_command=user_command,
            traversal_run_id=traversal_run_id,
            turn_plan=turn_plan,
            host_surfaces=host_surfaces,
        )
        control = self._snapshot_from_mapping(prepared["control_snapshot"])
        applied: tuple[dict[str, Any], ...] = ()
        if host_results:
            pending_ids = {x.syscall_id for x in self.controller.pump.pending()}
            fresh_host_results = [dict(x) for x in host_results if str(x.get("syscall_id") or "") in pending_ids]
            if fresh_host_results:
                applied, control = self.controller.apply_host_results_with_fidelity(
                    fresh_host_results,
                    snapshot=control,
                    user_command=user_command,
                    turn_key=traversal_run_id,
                    continuity_task_id=prepared["continuity_task_id"],
                )
        control = self.controller.refresh_contract(control)

        manifests = dict(candidate_manifests or {})
        requirement_contract = RequirementCompiler.compile(user_command)
        manifest_findings: list[str] = []
        manifest_ok = True
        requirement_coverage_by_candidate: dict[str, dict[str, Any]] = {}
        requirement_accounted_ids: set[str] = set()
        requirement_missing_ids: set[str] = set()
        for row in hypotheses:
            cid = str(row.get("candidate_id") or "")
            coverage = RequirementCompiler.validate_coverage(requirement_contract, manifests.get(cid))
            requirement_coverage_by_candidate[cid] = asdict(coverage)
            requirement_accounted_ids.update(map(str, coverage.accounted_ids))
            requirement_missing_ids.update(map(str, coverage.missing_ids))
            manifest_ok = manifest_ok and coverage.ok
            manifest_findings.extend(f"{cid}:{finding}" for finding in coverage.findings)
        verdict = None
        if control.primary_required_host_request_ids:
            if not control.ghost_verified or not control.ghost_bundle_sha256 or not control.ghost_worlds_sha256:
                manifest_ok = False
                manifest_findings.append("adaptive_fidelity_verification_not_complete")
            else:
                verdict = GhostVerdict(
                    bundle_sha256=control.ghost_bundle_sha256,
                    verified=control.ghost_verified,
                    world_count=0,
                    requirement_atoms=tuple(control.requirement_atoms),
                    covered_syscall_ids=tuple(control.primary_required_host_request_ids),
                    covered_marker_ids=(),
                    findings=(),
                    verified_at=0.0,
                    worlds_sha256=control.ghost_worlds_sha256,
                )
                for row in hypotheses:
                    cid = str(row.get("candidate_id") or "")
                    ok, findings = IntentFidelityProjector.validate_candidate_manifest(
                        candidate_body=str(row.get("body") or ""),
                        manifest=manifests.get(cid),
                        verdict=verdict,
                        primary_required_syscall_ids=control.primary_required_host_request_ids,
                    )
                    manifest_ok = manifest_ok and ok
                    manifest_findings.extend(f"{cid}:{finding}" for finding in findings)
        contract_success = bool(traversal_success and control.contract_satisfied and manifest_ok)

        ingress = self.audit.begin(user_command)
        evidence = dict(traversal_evidence)
        evidence.pop("artifact_sha256", None)
        def _sha_json(value: Any) -> str:
            raw = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
            return hashlib.sha256(raw.encode("utf-8")).hexdigest()
        cumulative_intent = self.foundation.intent.compose(user_command)
        host_requests = list(control.host_requests)
        host_results_applied = list(applied)
        evidence.update({
            "persistent_runtime_root": str(self.foundation.root),
            "cumulative_requirement_count": len(self.foundation.intent.active()),
            "cumulative_intent_attached": True,
            "cumulative_intent_sha256": _sha_json(cumulative_intent),
            "turn_plan_sha256": _sha_json(prepared["turn_plan"]),
            "foundation_snapshot_sha256": _sha_json(control.foundation),
            "turn_contract_version": control.contract_version,
            "turn_contract_sha256": control.contract_sha256,
            "turn_contract_satisfied": contract_success,
            "exact_user_command_bound": control.command_sha256 == ingress.command_sha256,
            "cumulative_intent_bound": "cumulative_intent_bound" in control.local_stages,
            "continuity_bound": "continuity_bound" in control.local_stages,
            "route_plan_bound": "route_plan_bound" in control.local_stages,
            "host_request_count": len(host_requests),
            "host_request_ids": [str(x.get("syscall_id", "")) for x in host_requests],
            "host_result_count": len(host_results_applied),
            "host_result_ids": [str(x.get("syscall_id", "")) for x in host_results_applied],
            "primary_required_host_request_ids": list(control.primary_required_host_request_ids),
            "ghost_host_request_ids": list(control.ghost_host_request_ids),
            "required_host_request_ids": list(control.required_host_request_ids),
            "missing_required_host_results": list(control.missing_required_host_results),
            "failed_required_host_results": list(control.failed_required_host_results),
            "fidelity_mode": control.fidelity_mode,
            "ghost_bundle_sha256": control.ghost_bundle_sha256,
            "ghost_verified": control.ghost_verified,
            "ghost_worlds_sha256": control.ghost_worlds_sha256,
            "requirement_atom_ids": [str(x.get("atom_id", "")) for x in control.requirement_atoms],
            "candidate_manifest_ok": manifest_ok,
            "candidate_manifest_findings": list(manifest_findings),
            "requirement_contract_sha256": requirement_contract.contract_sha256,
            "requirement_coverage_by_candidate": requirement_coverage_by_candidate,
            "superposed_release": True,
            "superposed_candidate_count": len(tuple(hypotheses)),
        })
        self.audit.attach_runtime(
            ingress.turn_id,
            run_id=traversal_run_id,
            subsystem=traversal_subsystem,
            success=contract_success,
            evidence=evidence,
        )
        if not contract_success:
            self.audit.fail_turn(
                ingress.turn_id,
                reason="adaptive superposed turn contract not satisfied",
                evidence={
                    "missing_required_host_results": list(control.missing_required_host_results),
                    "failed_required_host_results": list(control.failed_required_host_results),
                    "ghost_verified": control.ghost_verified,
                    "candidate_manifest_findings": list(manifest_findings),
                },
            )
            raise RuntimeError("JIGAEWOL turn contract not satisfied")

        group_id = str(release_group_id or f"release_group_{uuid.uuid4().hex[:16]}")
        candidate_rows = []
        for index, raw in enumerate(hypotheses):
            cid = str(raw.get("candidate_id") or f"hypothesis_{index+1}_{uuid.uuid4().hex[:8]}")
            candidate_rows.append(
                HypothesisCandidate(
                    candidate_id=cid,
                    body=self._normalize_release_body(str(raw.get("body") or ""), runtime_footer=runtime_footer),
                    producer=str(raw.get("producer") or "chat-host-hypothesis"),
                    assumptions=tuple(map(str, raw.get("assumptions") or ())),
                    evidence_refs=tuple(map(str, raw.get("evidence_refs") or ())),
                    counterevidence_refs=tuple(map(str, raw.get("counterevidence_refs") or ())),
                    uncertainty=float(raw.get("uncertainty", 0.5)),
                    epistemic_mode=str(raw.get("epistemic_mode") or EpistemicMode.EVIDENCED.value),
                    preservation_basis=tuple(map(str, raw.get("preservation_basis") or ())),
                    qualitative_tensions=tuple(map(str, raw.get("qualitative_tensions") or ())),
                    raw_spark_sha256=str(raw.get("raw_spark_sha256") or ""),
                    metadata=dict(raw.get("metadata") or {}),
                )
            )
        bundle = CandidateBundle(
            turn_id=ingress.turn_id,
            release_group_id=group_id,
            candidates=tuple(candidate_rows),
            rationale="Preserve incompatible, speculative, paradoxical, or qualitatively irreducible hypotheses without forced convergence or Pareto-only reduction.",
            evidence=evidence,
        )
        self.audit.bind_candidate_group(ingress.turn_id, bundle)
        joined_body = "\n\n".join(str(x.body) for x in bundle.candidates)
        strong_finalizer, permit, chain_sha, objective_completion_proven = self._strong_finalize_and_permit(
            ingress_turn_id=ingress.turn_id,
            response_sha256=bundle.bundle_sha256,
            response_text=joined_body,
            traversal_run_id=traversal_run_id,
            requirement_contract=requirement_contract,
            requirement_coverage_ok=bool(manifest_ok),
            requirement_accounted_ids=tuple(sorted(requirement_accounted_ids)),
            requirement_missing_ids=tuple(sorted(requirement_missing_ids)),
            requirement_findings=tuple(manifest_findings),
            control=control,
            applied=applied,
            objective_completed=bool(objective_completed),
            prepared=prepared,
        )
        evidence["objective_completion_requested"] = bool(objective_completed)
        evidence["objective_completion_proven"] = objective_completion_proven
        evidence["strong_finalizer_receipt_id"] = str(strong_finalizer.get("receipt_id") or "")
        evidence["finalization_permit_sha256"] = str(permit.permit_sha256)
        released = self.sink.commit_group(
            bundle=bundle,
            permit=permit,
            user_command=user_command,
            permit_verifier=lambda value: self.finalizer.verify_permit(
                value, expected_loop_chain_sha256=chain_sha
            ),
        )
        self.foundation.mark_response_release(
            release_receipt=released.release_group_id,
            response_sha256=released.bundle_sha256,
            objective_completed=objective_completion_proven,
            task_id=prepared["continuity_task_id"],
        )
        if self._should_seed_resident(
            mode=resident_continuation, hypothesis_count=len(bundle.candidates), unresolved_frontier=True
        ):
            self._enqueue_resident_frontier(
                source_turn_id=released.turn_id,
                task_id=prepared["continuity_task_id"],
                objective=user_command,
                hypotheses=bundle.candidates,
                release_group_id=released.release_group_id,
                max_cycles=resident_max_cycles,
            )
        if control.primary_required_host_request_ids:
            self.controller.purge_ghost_state(traversal_run_id, control)
        return released


def _read_json_file(path: str | None, default):
    if not path:
        return default
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--user", default="user")
    parser.add_argument("--project", default="project")
    parser.add_argument("--session", default="chat")
    parser.add_argument("--project-root", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--persistent-root")
    parser.add_argument("--command-file", required=True)
    parser.add_argument("--candidate-file")
    parser.add_argument("--candidate-group-file", help="JSON with multiple materially distinct hypotheses for superposed release")
    parser.add_argument("--release-group-id")
    parser.add_argument("--resident-max-cycles", type=int, default=3)
    parser.add_argument("--resident-continuation", choices=("frontier", "always", "never"), default="always")
    parser.add_argument("--unresolved-frontier", action="store_true")
    parser.add_argument("--canonical-zip", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--subsystem", default="chat_turn")
    parser.add_argument("--evidence-json", default="{}")
    parser.add_argument("--turn-plan-file")
    parser.add_argument("--host-surfaces-file")
    parser.add_argument("--host-results-file")
    parser.add_argument("--candidate-manifest-file")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--advance-only", action="store_true")
    parser.add_argument("--output-file", required=True)
    parser.add_argument("--objective-completed", action="store_true", help="Mark the full user objective complete only when its work is finished")
    args = parser.parse_args()

    command_bytes = Path(args.command_file).read_bytes()
    command = command_bytes.decode("utf-8")
    canonical_admission = admit_exact_user_message(
        state_root=Path(args.workspace), raw_message_bytes=command_bytes,
        user_id=args.user, project_id=args.project, session_id=args.session,
        origin_ref="local:chat_turn:new_user_message",
    )
    turn_plan = _read_json_file(args.turn_plan_file, None)
    host_surfaces_raw = _read_json_file(args.host_surfaces_file, [])
    host_surfaces = host_surfaces_raw.get("surfaces", []) if isinstance(host_surfaces_raw, dict) else host_surfaces_raw
    runtime = ChatTurnRuntime(
        Path(args.workspace),
        project_root=Path(args.project_root),
        persistent_root=Path(args.persistent_root) if args.persistent_root else None,
        canonical_artifact_path=Path(args.canonical_zip),
        require_gateway_turn=True,
        gateway_envelope=canonical_admission["gateway_envelope"],
        gateway_user_id=args.user, gateway_project_id=args.project, gateway_session_id=args.session,
    )

    host_results_raw = _read_json_file(args.host_results_file, [])
    host_results = host_results_raw.get("results", []) if isinstance(host_results_raw, dict) else host_results_raw

    if args.prepare_only and args.advance_only:
        parser.error("use only one of --prepare-only or --advance-only")
    if args.prepare_only:
        prepared = runtime.prepare_turn(
            user_command=command,
            traversal_run_id=args.run_id,
            turn_plan=turn_plan,
            host_surfaces=host_surfaces,
        )
        Path(args.output_file).write_text(json.dumps(prepared, ensure_ascii=False, indent=2), encoding="utf-8")
        return 0
    if args.advance_only:
        advanced = runtime.advance_turn(
            user_command=command,
            traversal_run_id=args.run_id,
            turn_plan=turn_plan,
            host_surfaces=host_surfaces,
            host_results=host_results,
        )
        Path(args.output_file).write_text(json.dumps(advanced, ensure_ascii=False, indent=2), encoding="utf-8")
        return 0

    if not args.candidate_file and not args.candidate_group_file:
        parser.error("--candidate-file or --candidate-group-file is required unless --prepare-only/--advance-only is used")
    if args.candidate_file and args.candidate_group_file:
        parser.error("choose one of --candidate-file or --candidate-group-file")
    evidence = json.loads(args.evidence_json)
    candidate_manifest = _read_json_file(args.candidate_manifest_file, None)
    if args.candidate_group_file:
        raw_group = json.loads(Path(args.candidate_group_file).read_text(encoding="utf-8"))
        hypotheses = raw_group.get("hypotheses") if isinstance(raw_group, dict) else raw_group
        manifests = raw_group.get("candidate_manifests", {}) if isinstance(raw_group, dict) else {}
        released = runtime.seal_and_release_superposed(
            user_command=command,
            hypotheses=hypotheses,
            traversal_run_id=args.run_id,
            traversal_subsystem=args.subsystem,
            traversal_success=True,
            traversal_evidence=evidence,
            release_group_id=args.release_group_id,
            objective_completed=args.objective_completed,
            turn_plan=turn_plan,
            host_surfaces=host_surfaces,
            host_results=host_results,
            candidate_manifests=manifests,
            resident_max_cycles=args.resident_max_cycles,
            resident_continuation=args.resident_continuation,
            runtime_footer=False,
        )
    else:
        candidate = Path(args.candidate_file).read_text(encoding="utf-8")
        released = runtime.seal_and_release(
            user_command=command,
            candidate_body=candidate,
            traversal_run_id=args.run_id,
            traversal_subsystem=args.subsystem,
            traversal_success=True,
            traversal_evidence=evidence,
            objective_completed=args.objective_completed,
            turn_plan=turn_plan,
            host_surfaces=host_surfaces,
            host_results=host_results,
            candidate_manifest=candidate_manifest,
            resident_continuation=args.resident_continuation,
            unresolved_frontier=args.unresolved_frontier,
            runtime_footer=False,
        )
    Path(args.output_file).write_text(
        json.dumps(asdict(released), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
