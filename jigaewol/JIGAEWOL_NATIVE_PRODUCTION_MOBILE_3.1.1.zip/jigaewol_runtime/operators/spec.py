from dataclasses import dataclass


@dataclass(frozen=True)
class OperatorSpec:
    operator_id: str
    input_schema: str
    output_schema: str
    applicability: tuple[str, ...]
    transformation_claim: str
    verifier: str
    cost_hint: float
    origin: str
    steps: tuple[dict, ...] = ()
