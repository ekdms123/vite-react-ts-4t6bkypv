from __future__ import annotations
from jigaewol_runtime.kernel.errors import JigaewolError


class OperatorRegistry:
    def __init__(self):
        self._operators: dict[str, object] = {}

    def register(self, spec) -> None:
        if spec.operator_id in self._operators:
            raise JigaewolError("operator_registration", spec.operator_id)
        if not spec.input_schema or not spec.output_schema or not spec.verifier:
            raise JigaewolError("operator_invalid", spec.operator_id)
        self._operators[spec.operator_id] = spec

    def get(self, operator_id: str):
        return self._operators[operator_id]

    def all(self) -> tuple[object, ...]:
        return tuple(self._operators[k] for k in sorted(self._operators))
