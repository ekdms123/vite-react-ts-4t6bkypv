"""Known and generated cognitive/action operators."""
