"""Data edits of proposed structures; usefulness remains a host judgment."""
from copy import deepcopy
import math
from .spec import OperatorSpec


def validate_generated_operator(spec: OperatorSpec) -> OperatorSpec:
    if not isinstance(spec, OperatorSpec):
        raise ValueError("generated operator must be an OperatorSpec")
    text_fields = (spec.operator_id, spec.input_schema, spec.output_schema, spec.transformation_claim, spec.verifier)
    if any(not isinstance(value, str) or not value.strip() for value in text_fields):
        raise ValueError("operator id, schemas, transformation claim and verifier must be nonempty text")
    if isinstance(spec.cost_hint, bool) or not isinstance(spec.cost_hint, (int, float)) or not math.isfinite(spec.cost_hint) or spec.cost_hint < 0 or not spec.steps:
        raise ValueError("operator requires finite nonnegative numeric cost and actual data-edit steps")
    for step in spec.steps:
        if not isinstance(step, dict) or step.get("op") not in {"set", "delete", "append", "insert", "merge", "exchange", "move"}:
            raise ValueError("data edit must use set/delete/append/insert/merge/exchange/move")
        path = step.get("path")
        if not isinstance(path, (list, tuple)) or not path:
            raise ValueError("edit needs a path within the proposed structure")
        if any(not (isinstance(part, str) or (isinstance(part, int) and not isinstance(part, bool) and part >= 0)) for part in path):
            raise ValueError("edit path segments must be strings or nonnegative integer indices")
        op = step["op"]
        if op in {"set", "append", "insert", "merge"} and "value" not in step:
            raise ValueError(f"{op} requires a value")
        if op == "insert":
            index = step.get("index")
            if isinstance(index, bool) or not isinstance(index, int) or index < 0:
                raise ValueError("insert requires a nonnegative integer index")
        if op == "move":
            if any(isinstance(step.get(key), bool) or not isinstance(step.get(key), int) or step.get(key) < 0
                   for key in ("from_index", "to_index")):
                raise ValueError("move requires nonnegative integer from_index and to_index")
        if op == "exchange" and "indices" in step:
            indices = step["indices"]
            if (not isinstance(indices, (list, tuple)) or len(indices) != 2 or
                    any(isinstance(index, bool) or not isinstance(index, int) or index < 0 for index in indices)):
                raise ValueError("exchange indices must contain exactly two nonnegative integers")
        if op == "merge" and not isinstance(step.get("value"), dict):
            raise ValueError("merge requires an object value")
    return spec


def apply_generated_operator(spec: OperatorSpec, structure: dict) -> dict:
    validate_generated_operator(spec)
    if not isinstance(structure, dict):
        raise ValueError("operator input must be a proposed structure")
    result = deepcopy(structure)
    for step in spec.steps:
        parent = result
        try:
            for key in step["path"][:-1]:
                parent = parent[key]
        except (KeyError, IndexError, TypeError) as exc:
            raise ValueError("edit path does not exist in the proposed structure") from exc
        key, op = step["path"][-1], step["op"]
        try:
            if op == "set":
                if isinstance(parent, list) and (not isinstance(key, int) or isinstance(key, bool) or not 0 <= key < len(parent)):
                    raise ValueError("set list index must address an existing element")
                parent[key] = deepcopy(step["value"])
            elif op == "delete":
                if isinstance(parent, list) and (not isinstance(key, int) or isinstance(key, bool) or not 0 <= key < len(parent)):
                    raise ValueError("delete list index must address an existing element")
                if isinstance(parent, dict) and key not in parent:
                    raise ValueError("delete object key must exist")
                del parent[key]
            else:
                target = parent[key]
                if op == "append":
                    if not isinstance(target, list):
                        raise ValueError("append target must be a list")
                    target.append(deepcopy(step["value"]))
                elif op == "insert":
                    if not isinstance(target, list):
                        raise ValueError("insert target must be a list")
                    index = step["index"]
                    if index > len(target):
                        raise ValueError("insert index must be within list insertion bounds")
                    target.insert(index, deepcopy(step["value"]))
                elif op == "merge":
                    if not isinstance(target, dict):
                        raise ValueError("merge target must be an object")
                    target.update(deepcopy(step["value"]))
                elif op == "move":
                    if not isinstance(target, list):
                        raise ValueError("move target must be a list")
                    left, right = step["from_index"], step["to_index"]
                    if not 0 <= left < len(target) or not 0 <= right <= len(target):
                        raise ValueError("move indices must address the list")
                    item = target.pop(left)
                    target.insert(right, item)
                else:
                    if not isinstance(target, list):
                        raise ValueError("exchange target must be a list")
                    left, right = step.get("indices", (0, 1))
                    if left >= len(target) or right >= len(target):
                        raise ValueError("exchange indices must address the list")
                    target[left], target[right] = target[right], target[left]
        except (KeyError, IndexError, TypeError, AttributeError) as exc:
            raise ValueError("edit path or target is incompatible with the requested operation") from exc
    return {"structure": result, "changed": result != structure,
            "operator_id": spec.operator_id, "basis": "executed_data_edits"}

