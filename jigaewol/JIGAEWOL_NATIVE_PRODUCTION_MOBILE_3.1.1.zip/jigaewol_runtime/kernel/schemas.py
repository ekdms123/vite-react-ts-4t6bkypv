from __future__ import annotations

from collections.abc import Callable

from .errors import JigaewolError


class SchemaRegistry:
    def __init__(self) -> None:
        self._validators: dict[str, Callable] = {}

    def register(self, name: str, validator: Callable) -> None:
        if not name:
            raise JigaewolError("schema_registration", "schema name is empty")
        if name in self._validators:
            raise JigaewolError("schema_registration", f"schema already registered: {name}")
        self._validators[name] = validator

    def validate(self, name: str, value):
        if name not in self._validators:
            raise JigaewolError("schema_missing", name)
        try:
            return self._validators[name](value)
        except JigaewolError:
            raise
        except Exception as exc:
            raise JigaewolError("schema_validation", f"{name}: {exc}") from exc

    def names(self) -> tuple[str, ...]:
        return tuple(self._validators)
