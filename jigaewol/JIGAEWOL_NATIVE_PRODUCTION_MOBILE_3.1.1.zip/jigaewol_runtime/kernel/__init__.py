"""Invariant kernel."""
