from __future__ import annotations

import json
import uuid


def new_id(prefix: str) -> str:
    clean = prefix.strip().rstrip("_")
    if not clean:
        raise ValueError("prefix must be non-empty")
    return f"{clean}_{uuid.uuid4().hex[:16]}"


def strict_json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
