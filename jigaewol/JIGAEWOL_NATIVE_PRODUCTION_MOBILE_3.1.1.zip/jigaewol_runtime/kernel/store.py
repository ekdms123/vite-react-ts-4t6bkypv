from __future__ import annotations

from dataclasses import dataclass
from contextlib import contextmanager
from pathlib import Path
import hashlib
import json
import math
import sqlite3

def _unit_score(value, default=0.0):
    if isinstance(value, bool):
        return float(default)
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    if not math.isfinite(number):
        return float(default)
    return max(0.0, min(1.0, number))


def _bounded_limit(value, *, label="limit", maximum=10000):
    if isinstance(value, bool) or not isinstance(value, int) or value < 1 or value > maximum:
        raise ValueError(f"{label} must be an integer between 1 and {maximum}")
    return value


def _optional_limit(value, *, label="limit", maximum=10000):
    """Like _bounded_limit, but `None` means "no ceiling".

    Silently truncating recall can shrink the user's request. `None` means
    intentionally unbounded recall; malformed explicit limits remain errors.
    """
    if value is None:
        return None
    return _bounded_limit(value, label=label, maximum=maximum)


from .ids import new_id, strict_json
from .errors import JigaewolError


@dataclass(frozen=True)
class TurnRecord:
    turn_id: str
    task_id: str
    session_id: str
    message_sha256: str


class StateStore:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.db_path = self.root / "state.sqlite3"
        self._init_schema()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS turns (
                    turn_id TEXT PRIMARY KEY,
                    task_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    message TEXT NOT NULL,
                    message_sha256 TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE INDEX IF NOT EXISTS turns_task_idx ON turns(task_id, created_at);
                CREATE TABLE IF NOT EXISTS revisions (
                    revision_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id TEXT NOT NULL,
                    request_id TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(task_id, request_id)
                );
                CREATE TABLE IF NOT EXISTS runtimes (
                    turn_id TEXT PRIMARY KEY,
                    payload_json TEXT NOT NULL,
                    revision INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS requests (
                    scope_id TEXT NOT NULL,
                    request_id TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(scope_id, request_id)
                );
                CREATE TABLE IF NOT EXISTS generated_methods (
                    session_id TEXT NOT NULL,
                    method_hash TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(session_id, method_hash)
                );
                CREATE TABLE IF NOT EXISTS cognitive_operators (
                    session_id TEXT NOT NULL,
                    operator_id TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(session_id, operator_id)
                );
                CREATE TABLE IF NOT EXISTS generated_integrations (
                    session_id TEXT NOT NULL,
                    integration_id TEXT NOT NULL,
                    manifest_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(session_id, integration_id)
                );
                CREATE TABLE IF NOT EXISTS adaptation_profiles (
                    session_id TEXT NOT NULL,
                    id TEXT NOT NULL,
                    task_terms_json TEXT NOT NULL,
                    profile_json TEXT NOT NULL,
                    parent_ids_json TEXT NOT NULL,
                    revisions_json TEXT NOT NULL,
                    score REAL NOT NULL DEFAULT 0,
                    observations INTEGER NOT NULL DEFAULT 1,
                    helpful INTEGER NOT NULL DEFAULT 0,
                    unhelpful INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'candidate',
                    execution_fitness REAL NOT NULL DEFAULT 0,
                    fitness_json TEXT NOT NULL DEFAULT '{}',
                    revision_report_json TEXT NOT NULL DEFAULT '[]',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(session_id, id)
                );
                CREATE TABLE IF NOT EXISTS adaptation_profile_turns (
                    session_id TEXT NOT NULL,
                    profile_id TEXT NOT NULL,
                    turn_id TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(session_id, profile_id, turn_id)
                );
                CREATE TABLE IF NOT EXISTS turn_ingress (
                    receipt_id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    turn_id TEXT,
                    message_sha256 TEXT NOT NULL,
                    capability_fingerprint TEXT,
                    capabilities_rebound INTEGER NOT NULL DEFAULT 0,
                    recovered_turn_ids_json TEXT NOT NULL DEFAULT '[]',
                    status TEXT NOT NULL,
                    error_type TEXT,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE INDEX IF NOT EXISTS turn_ingress_session_idx
                    ON turn_ingress(session_id, created_at);
                """
            )
            columns = {row[1] for row in conn.execute("PRAGMA table_info(runtimes)").fetchall()}
            if "revision" not in columns:
                conn.execute("ALTER TABLE runtimes ADD COLUMN revision INTEGER NOT NULL DEFAULT 0")
            profile_columns = {row[1] for row in conn.execute("PRAGMA table_info(adaptation_profiles)").fetchall()}
            profile_migrations = {
                "status": "TEXT NOT NULL DEFAULT 'candidate'",
                "execution_fitness": "REAL NOT NULL DEFAULT 0",
                "fitness_json": "TEXT NOT NULL DEFAULT '{}'",
                "revision_report_json": "TEXT NOT NULL DEFAULT '[]'",
            }
            for name, declaration in profile_migrations.items():
                if name not in profile_columns:
                    conn.execute(f"ALTER TABLE adaptation_profiles ADD COLUMN {name} {declaration}")

    @staticmethod
    def _decode_ingress_row(row):
        if row is None:
            return None
        return {
            "receipt_id": row[0],
            "session_id": row[1],
            "turn_id": row[2],
            "message_sha256": row[3],
            "capability_fingerprint": row[4],
            "capabilities_rebound": bool(row[5]),
            "recovered_turn_ids": tuple(json.loads(row[6])),
            "status": row[7],
            "error_type": row[8],
            "created_at": row[9],
            "updated_at": row[10],
        }

    @staticmethod
    def _validate_sha256(value, label):
        if not isinstance(value, str) or len(value) != 64 or any(ch not in "0123456789abcdef" for ch in value.lower()):
            raise ValueError(f"{label} must be a 64-character hexadecimal SHA-256 digest")
        return value.lower()

    def record_ingress_received(self, *, session_id: str, message_sha256: str, receipt_id: str | None = None):
        if not isinstance(session_id, str) or not session_id:
            raise ValueError("session_id must be nonempty text")
        digest = self._validate_sha256(message_sha256, "message_sha256")
        rid = receipt_id or new_id("ingress")
        if not isinstance(rid, str) or not rid:
            raise ValueError("receipt_id must be nonempty text")
        with self._connect() as conn:
            try:
                conn.execute(
                    "INSERT INTO turn_ingress(receipt_id,session_id,message_sha256,status) VALUES(?,?,?,'received')",
                    (rid, session_id, digest),
                )
            except sqlite3.IntegrityError as exc:
                raise JigaewolError("ingress_conflict", rid) from exc
        return self.get_ingress_receipt(rid)

    def record_ingress_admitted(
        self, receipt_id: str, *, turn_id: str, capability_fingerprint: str,
        capabilities_rebound: bool, recovered_turn_ids=(),
    ):
        if not isinstance(turn_id, str) or not turn_id:
            raise ValueError("turn_id must be nonempty text")
        fingerprint = self._validate_sha256(capability_fingerprint, "capability_fingerprint")
        if not isinstance(capabilities_rebound, bool):
            raise ValueError("capabilities_rebound must be boolean")
        if isinstance(recovered_turn_ids, (str, bytes)) or not isinstance(recovered_turn_ids, (list, tuple)):
            raise ValueError("recovered_turn_ids must be a list or tuple")
        recovered = tuple(recovered_turn_ids)
        if any(not isinstance(item, str) or not item for item in recovered):
            raise ValueError("recovered_turn_ids must contain nonempty text ids")
        with self._connect() as conn:
            row = conn.execute("SELECT status FROM turn_ingress WHERE receipt_id=?", (receipt_id,)).fetchone()
            if row is None:
                raise KeyError(receipt_id)
            if row[0] != "received":
                raise ValueError(f"ingress receipt is already {row[0]}")
            conn.execute(
                "UPDATE turn_ingress SET turn_id=?,capability_fingerprint=?,capabilities_rebound=?,"
                "recovered_turn_ids_json=?,status='admitted',error_type=NULL,updated_at=CURRENT_TIMESTAMP "
                "WHERE receipt_id=?",
                (turn_id, fingerprint, int(capabilities_rebound), strict_json(list(recovered)), receipt_id),
            )
        return self.get_ingress_receipt(receipt_id)

    def record_ingress_failed(
        self, receipt_id: str, error, *, capability_fingerprint: str | None = None,
        capabilities_rebound: bool = False, recovered_turn_ids=(),
    ):
        if capability_fingerprint is not None:
            capability_fingerprint = self._validate_sha256(capability_fingerprint, "capability_fingerprint")
        if not isinstance(capabilities_rebound, bool):
            raise ValueError("capabilities_rebound must be boolean")
        if isinstance(recovered_turn_ids, (str, bytes)) or not isinstance(recovered_turn_ids, (list, tuple)):
            raise ValueError("recovered_turn_ids must be a list or tuple")
        recovered = tuple(recovered_turn_ids)
        if any(not isinstance(item, str) or not item for item in recovered):
            raise ValueError("recovered_turn_ids must contain nonempty text ids")
        error_type = type(error).__name__
        with self._connect() as conn:
            row = conn.execute("SELECT status FROM turn_ingress WHERE receipt_id=?", (receipt_id,)).fetchone()
            if row is None:
                raise KeyError(receipt_id)
            if row[0] != "received":
                raise ValueError(f"ingress receipt is already {row[0]}")
            conn.execute(
                "UPDATE turn_ingress SET capability_fingerprint=?,capabilities_rebound=?,recovered_turn_ids_json=?,"
                "status='failed',error_type=?,updated_at=CURRENT_TIMESTAMP WHERE receipt_id=?",
                (capability_fingerprint, int(capabilities_rebound), strict_json(list(recovered)), error_type, receipt_id),
            )
        return self.get_ingress_receipt(receipt_id)

    def get_ingress_receipt(self, receipt_id: str):
        if not isinstance(receipt_id, str) or not receipt_id:
            raise ValueError("receipt_id must be nonempty text")
        with self._connect() as conn:
            row = conn.execute(
                "SELECT receipt_id,session_id,turn_id,message_sha256,capability_fingerprint,capabilities_rebound,"
                "recovered_turn_ids_json,status,error_type,created_at,updated_at FROM turn_ingress WHERE receipt_id=?",
                (receipt_id,),
            ).fetchone()
        return self._decode_ingress_row(row)

    def list_ingress_receipts(self, session_id: str, limit=50):
        if not isinstance(session_id, str) or not session_id:
            raise ValueError("session_id must be nonempty text")
        limit = _bounded_limit(limit, label="ingress receipt limit", maximum=1000)
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT receipt_id,session_id,turn_id,message_sha256,capability_fingerprint,capabilities_rebound,"
                "recovered_turn_ids_json,status,error_type,created_at,updated_at FROM turn_ingress "
                "WHERE session_id=? ORDER BY created_at DESC,rowid DESC LIMIT ?",
                (session_id, limit),
            ).fetchall()
        return tuple(self._decode_ingress_row(row) for row in rows)

    def open_turn(self, session_id: str, turn_id: str, message: str, task_id: str | None = None) -> TurnRecord:
        if not turn_id or not session_id:
            raise JigaewolError("turn_invalid", "turn_id and session_id are required")
        resolved_task = task_id or new_id("task")
        digest = hashlib.sha256(message.encode("utf-8")).hexdigest()
        with self._connect() as conn:
            try:
                conn.execute(
                    "INSERT INTO turns(turn_id,task_id,session_id,message,message_sha256) VALUES(?,?,?,?,?)",
                    (turn_id, resolved_task, session_id, message, digest),
                )
            except sqlite3.IntegrityError as exc:
                row = conn.execute(
                    "SELECT task_id,session_id,message_sha256 FROM turns WHERE turn_id=?", (turn_id,)
                ).fetchone()
                if row == (resolved_task, session_id, digest):
                    return TurnRecord(turn_id, resolved_task, session_id, digest)
                raise JigaewolError("turn_conflict", turn_id) from exc
        return TurnRecord(turn_id, resolved_task, session_id, digest)

    def write_revision(self, task_id: str, snapshot, request_id: str) -> int:
        payload = strict_json(snapshot)
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT revision_id,payload_json FROM revisions WHERE task_id=? AND request_id=?",
                (task_id, request_id),
            ).fetchone()
            if existing:
                if existing[1] != payload:
                    raise JigaewolError("idempotency_conflict", request_id)
                return int(existing[0])
            cur = conn.execute(
                "INSERT INTO revisions(task_id,request_id,payload_json) VALUES(?,?,?)",
                (task_id, request_id, payload),
            )
            return int(cur.lastrowid)

    def record_request(self, scope_id: str, request_id: str, payload):
        encoded = strict_json(payload)
        with self._connect() as conn:
            row = conn.execute(
                "SELECT payload_json FROM requests WHERE scope_id=? AND request_id=?", (scope_id, request_id)
            ).fetchone()
            if row:
                if row[0] != encoded:
                    raise JigaewolError("idempotency_conflict", request_id)
                return json.loads(row[0])
            conn.execute(
                "INSERT INTO requests(scope_id,request_id,payload_json) VALUES(?,?,?)",
                (scope_id, request_id, encoded),
            )
        return json.loads(encoded)


    def save_runtime(self, turn_id: str, payload, *, expected_revision=None) -> int:
        """Persist runtime state with optional compare-and-swap protection.

        JIGAEWOL runtime instances always supply the revision they restored. A stale writer
        therefore fails instead of silently overwriting a newer runtime.
        """
        encoded = strict_json(payload)
        with self._connect() as conn:
            if expected_revision in (None, 0):
                # None/0 is create-only, never an unconstrained overwrite.  This
                # keeps the first write inside the same CAS discipline as later
                # revisions and closes the two-creators race.
                revision = 1
                try:
                    conn.execute(
                        "INSERT INTO runtimes(turn_id,payload_json,revision,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)",
                        (turn_id, encoded, revision),
                    )
                except sqlite3.IntegrityError as exc:
                    raise JigaewolError(
                        "stale_runtime",
                        "runtime was already created; reload before writing",
                    ) from exc
            else:
                if not isinstance(expected_revision, int) or isinstance(expected_revision, bool) or expected_revision < 1:
                    raise ValueError("expected_revision must be None, 0, or a positive integer")
                revision = expected_revision + 1
                cur = conn.execute(
                    "UPDATE runtimes SET payload_json=?,revision=?,updated_at=CURRENT_TIMESTAMP "
                    "WHERE turn_id=? AND revision=?",
                    (encoded, revision, turn_id, expected_revision),
                )
                if cur.rowcount != 1:
                    raise JigaewolError(
                        "stale_runtime",
                        f"runtime revision is not {expected_revision}; reload before writing",
                    )
            session = conn.execute("SELECT session_id FROM turns WHERE turn_id=?", (turn_id,)).fetchone()
            if not session:
                raise JigaewolError("turn_missing", turn_id)
            extensions = payload.get("extensions", {})
            for method_hash, record in extensions.get("retained_methods", {}).items():
                conn.execute("INSERT INTO generated_methods(session_id,method_hash,payload_json) VALUES(?,?,?) "
                    "ON CONFLICT(session_id,method_hash) DO NOTHING",
                    (session[0], method_hash, strict_json(record)))
            staged_integrations = extensions.get("installed_integrations", {})
            for integration_id, manifest in staged_integrations.items():
                encoded_manifest = strict_json(manifest)
                existing = conn.execute(
                    "SELECT manifest_json FROM generated_integrations WHERE session_id=? AND integration_id=?",
                    (session[0], integration_id),
                ).fetchone()
                if existing and existing[0] != encoded_manifest:
                    previous = json.loads(existing[0])
                    current = json.loads(encoded_manifest)
                    for item in (previous, current):
                        item.pop("origin", None)
                        item.pop("manifest_sha256", None)
                    if previous != current:
                        raise JigaewolError("integration_conflict", integration_id)
                    conn.execute(
                        "UPDATE generated_integrations SET manifest_json=?, updated_at=CURRENT_TIMESTAMP "
                        "WHERE session_id=? AND integration_id=?",
                        (encoded_manifest, session[0], integration_id),
                    )
                else:
                    conn.execute(
                        "INSERT OR IGNORE INTO generated_integrations(session_id,integration_id,manifest_json) VALUES(?,?,?)",
                        (session[0], integration_id, encoded_manifest),
                    )

            profile = extensions.get("adaptation_profile_record")
            if isinstance(profile, dict) and profile.get("id"):
                profile_id = str(profile["id"])
                profile_json = strict_json(profile.get("profile", {}))
                row = conn.execute(
                    "SELECT observations,profile_json,status,execution_fitness FROM adaptation_profiles "
                    "WHERE session_id=? AND id=?",
                    (session[0], profile_id),
                ).fetchone()
                row_existed = row is not None
                if row and row[1] != profile_json:
                    raise JigaewolError("adaptation_profile_conflict", profile_id)
                status = str(profile.get("status", "candidate"))
                if status not in {"available", "candidate", "promoted"}:
                    raise JigaewolError("adaptation_profile_status_invalid", status)
                execution_fitness = _unit_score(profile.get("execution_fitness", 0.0))
                fitness_json = strict_json(profile.get("fitness", {}))
                revision_report_json = strict_json(profile.get("revision_report", []))
                if not row:
                    conn.execute(
                        "INSERT INTO adaptation_profiles(session_id,id,task_terms_json,profile_json,parent_ids_json,revisions_json,"
                        "status,execution_fitness,fitness_json,revision_report_json) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (session[0], profile_id, strict_json(profile.get("task_terms", [])), profile_json,
                         strict_json(profile.get("parent_ids", [])), strict_json(profile.get("revisions", [])),
                         status, execution_fitness, fitness_json, revision_report_json),
                    )
                    row = (1, profile_json, status, execution_fitness)
                assoc = conn.execute(
                    "INSERT OR IGNORE INTO adaptation_profile_turns(session_id,profile_id,turn_id) VALUES(?,?,?)",
                    (session[0], profile_id, turn_id),
                )
                first_for_turn = assoc.rowcount == 1
                if row_existed and first_for_turn:
                    conn.execute(
                        "UPDATE adaptation_profiles SET observations=observations+1 WHERE session_id=? AND id=?",
                        (session[0], profile_id),
                    )
                current_status = str(row[2])
                next_status = "promoted" if current_status == "promoted" and status in {"available", "candidate"} else status
                conn.execute(
                    "UPDATE adaptation_profiles SET execution_fitness=max(execution_fitness,?),fitness_json=?,"
                    "revision_report_json=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE session_id=? AND id=?",
                    (execution_fitness, fitness_json, revision_report_json, next_status, session[0], profile_id),
                )
        return revision

    def method_library(self, session_id, limit=None):
        limit = _optional_limit(limit, label="method library limit", maximum=10000)
        sql = "SELECT payload_json FROM generated_methods WHERE session_id=? ORDER BY rowid DESC"
        with self._connect() as conn:
            rows = (conn.execute(sql, (session_id,)).fetchall() if limit is None
                    else conn.execute(sql + " LIMIT ?", (session_id, limit)).fetchall())
        records = [json.loads(row[0]) for row in rows]
        return [{"method_hash": r["method_hash"], "id": r["method"]["id"],
                 "purpose": r["method"]["purpose"], "representation": r["method"]["representation"],
                 "reuse_condition": r["reuse_condition"], "basis": r["basis"]} for r in records]

    def method_by_hash(self, session_id, method_hash):
        with self._connect() as conn:
            row = conn.execute("SELECT payload_json FROM generated_methods WHERE session_id=? AND method_hash=?", (session_id, method_hash)).fetchone()
        return json.loads(row[0]) if row else None

    def record_cognitive_operator(self, session_id, operator):
        if (not isinstance(operator, dict) or not isinstance(operator.get("id"), str)
                or not operator["id"].strip()):
            raise ValueError("cognitive operator needs a nonempty text id")
        encoded = strict_json(operator)
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO cognitive_operators(session_id,operator_id,payload_json,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) "
                "ON CONFLICT(session_id,operator_id) DO UPDATE SET payload_json=excluded.payload_json,updated_at=CURRENT_TIMESTAMP",
                (session_id, operator["id"], encoded),
            )

    def cognitive_operator_library(self, session_id, limit=None):
        limit = _optional_limit(limit, label="cognitive operator limit", maximum=10000)
        sql = "SELECT payload_json FROM cognitive_operators WHERE session_id=? ORDER BY updated_at DESC,rowid DESC"
        with self._connect() as conn:
            rows = (conn.execute(sql, (session_id,)).fetchall() if limit is None
                    else conn.execute(sql + " LIMIT ?", (session_id, limit)).fetchall())
        return [json.loads(row[0]) for row in rows]

    def record_integration(self, session_id, integration_id, manifest):
        encoded = strict_json(manifest)
        with self._connect() as conn:
            row = conn.execute(
                "SELECT manifest_json FROM generated_integrations WHERE session_id=? AND integration_id=?",
                (session_id, integration_id),
            ).fetchone()
            if row and row[0] != encoded:
                previous = json.loads(row[0])
                current = json.loads(encoded)
                for item in (previous, current):
                    item.pop("origin", None)
                    item.pop("manifest_sha256", None)
                if previous != current:
                    raise JigaewolError("integration_conflict", integration_id)
                conn.execute(
                    "UPDATE generated_integrations SET manifest_json=?, updated_at=CURRENT_TIMESTAMP "
                    "WHERE session_id=? AND integration_id=?",
                    (encoded, session_id, integration_id),
                )
                return
            conn.execute(
                "INSERT OR IGNORE INTO generated_integrations(session_id,integration_id,manifest_json) VALUES(?,?,?)",
                (session_id, integration_id, encoded),
            )

    def integration_by_id(self, session_id, integration_id):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT manifest_json FROM generated_integrations WHERE session_id=? AND integration_id=?",
                (session_id, integration_id),
            ).fetchone()
        return json.loads(row[0]) if row else None

    def integration_catalog(self, session_id, limit=32):
        limit = _optional_limit(limit, label="integration catalog limit", maximum=256)
        sql = "SELECT manifest_json FROM generated_integrations WHERE session_id=? ORDER BY updated_at DESC,rowid DESC"
        with self._connect() as conn:
            rows = (conn.execute(sql, (session_id,)).fetchall() if limit is None
                    else conn.execute(sql + " LIMIT ?", (session_id, limit)).fetchall())
        return [json.loads(row[0]) for row in rows]

    def adaptation_profile_rows(self, session_id, limit=400):
        limit = _optional_limit(limit, label="adaptation profile limit", maximum=5000)
        sql = ("SELECT id,task_terms_json,profile_json,parent_ids_json,revisions_json,score,observations,helpful,unhelpful,"
               "status,execution_fitness,fitness_json,revision_report_json "
               "FROM adaptation_profiles WHERE session_id=? ORDER BY updated_at DESC,rowid DESC")
        with self._connect() as conn:
            return (conn.execute(sql, (session_id,)).fetchall() if limit is None
                    else conn.execute(sql + " LIMIT ?", (session_id, limit)).fetchall())

    def adaptation_profile_by_id(self, session_id, profile_id):
        with self._connect() as conn:
            return conn.execute(
                "SELECT id,task_terms_json,profile_json,parent_ids_json,revisions_json,score,observations,helpful,unhelpful,"
                "status,execution_fitness,fitness_json,revision_report_json "
                "FROM adaptation_profiles WHERE session_id=? AND id=?", (session_id, profile_id),
            ).fetchone()

    def record_adaptation_profile(self, session_id, record):
        profile_id = str(record["id"])
        profile_json = strict_json(record.get("profile", {}))
        status = str(record.get("status", "candidate"))
        if status not in {"available", "candidate", "promoted"}:
            raise JigaewolError("adaptation_profile_status_invalid", status)
        execution_fitness = _unit_score(record.get("execution_fitness", 0.0))
        fitness_json = strict_json(record.get("fitness", {}))
        report_json = strict_json(record.get("revision_report", []))
        with self._connect() as conn:
            row = conn.execute(
                "SELECT observations,profile_json,status FROM adaptation_profiles WHERE session_id=? AND id=?",
                (session_id, profile_id),
            ).fetchone()
            if row and row[1] != profile_json:
                raise JigaewolError("adaptation_profile_conflict", profile_id)
            if row:
                current_status = str(row[2])
                next_status = "promoted" if current_status == "promoted" and status in {"available", "candidate"} else status
                conn.execute(
                    "UPDATE adaptation_profiles SET observations=observations+1,execution_fitness=max(execution_fitness,?),"
                    "fitness_json=?,revision_report_json=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE session_id=? AND id=?",
                    (execution_fitness, fitness_json, report_json, next_status, session_id, profile_id),
                )
            else:
                conn.execute(
                    "INSERT INTO adaptation_profiles(session_id,id,task_terms_json,profile_json,parent_ids_json,revisions_json,"
                    "status,execution_fitness,fitness_json,revision_report_json) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (session_id, profile_id, strict_json(record.get("task_terms", [])), profile_json,
                     strict_json(record.get("parent_ids", [])), strict_json(record.get("revisions", [])),
                     status, execution_fitness, fitness_json, report_json),
                )

    def adaptation_feedback(self, session_id, profile_id, helpful):
        if not isinstance(helpful, bool):
            raise ValueError("helpful must be boolean")
        with self._connect() as conn:
            row = conn.execute(
                "SELECT helpful,unhelpful,status FROM adaptation_profiles WHERE session_id=? AND id=?",
                (session_id, profile_id),
            ).fetchone()
            if not row:
                raise KeyError(profile_id)
            hp = row[0] + (1 if helpful else 0)
            up = row[1] + (0 if helpful else 1)
            score = (hp - up) / max(1, hp + up)
            status = "promoted" if hp >= up else "candidate"
            conn.execute(
                "UPDATE adaptation_profiles SET helpful=?,unhelpful=?,score=?,status=?,updated_at=CURRENT_TIMESTAMP "
                "WHERE session_id=? AND id=?",
                (hp, up, score, status, session_id, profile_id),
            )
        return {"id": profile_id, "helpful": hp, "unhelpful": up, "score": score, "status": status}

    def load_runtime_record(self, turn_id: str):
        with self._connect() as conn:
            row = conn.execute("SELECT payload_json,revision FROM runtimes WHERE turn_id=?", (turn_id,)).fetchone()
        return (json.loads(row[0]), int(row[1])) if row else (None, None)

    def load_runtime(self, turn_id: str):
        payload, _ = self.load_runtime_record(turn_id)
        return payload

    def latest_task_for_session(self, session_id: str) -> str | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT task_id FROM turns WHERE session_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1", (session_id,)
            ).fetchone()
        return row[0] if row else None

    def latest_runtime_for_task(self, task_id, session_id, exclude_turn_id=None):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT r.payload_json FROM runtimes r JOIN turns t ON t.turn_id=r.turn_id "
                "WHERE t.task_id=? AND t.session_id=? AND t.turn_id<>? ORDER BY t.created_at DESC,t.rowid DESC LIMIT 1",
                (task_id, session_id, exclude_turn_id or ""),
            ).fetchone()
        return json.loads(row[0]) if row else None

    def runtime_history_for_task(self, task_id, session_id, exclude_turn_id=None, limit=None):
        """Return persisted runtimes for a task, newest first.

        Runtime history is source evidence. The runtime may request an explicit bounded
        view for a particular calculation, but the default recall path does not silently
        drop older task state.
        """
        limit = _optional_limit(limit, label="runtime history limit", maximum=10000)
        sql = (
            "SELECT r.payload_json FROM runtimes r JOIN turns t ON t.turn_id=r.turn_id "
            "WHERE t.task_id=? AND t.session_id=? AND t.turn_id<>? "
            "ORDER BY t.created_at DESC,t.rowid DESC"
        )
        args = (task_id, session_id, exclude_turn_id or "")
        with self._connect() as conn:
            rows = (conn.execute(sql, args).fetchall() if limit is None
                    else conn.execute(sql + " LIMIT ?", (*args, limit)).fetchall())
        return [json.loads(row[0]) for row in rows]

    def discard_turn(self, turn_id: str, session_id: str) -> None:
        """Remove a turn that failed before begin() could commit successfully."""
        with self._connect() as conn:
            row = conn.execute("SELECT 1 FROM turns WHERE turn_id=? AND session_id=?", (turn_id, session_id)).fetchone()
            if not row:
                return
            conn.execute("DELETE FROM runtimes WHERE turn_id=?", (turn_id,))
            conn.execute("DELETE FROM turns WHERE turn_id=? AND session_id=?", (turn_id, session_id))

    def rebind_turn_task(self, turn_id: str, session_id: str, task_id: str) -> None:
        if not isinstance(task_id, str) or not task_id:
            raise ValueError("task_id must be nonempty")
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE turns SET task_id=? WHERE turn_id=? AND session_id=?",
                (task_id, turn_id, session_id),
            )
            if cur.rowcount != 1:
                raise JigaewolError("turn_missing", turn_id)

    def latest_persisted_turn_for_session(self, session_id: str):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT t.turn_id,t.message,t.message_sha256 "
                "FROM turns t JOIN runtimes r ON r.turn_id=t.turn_id "
                "WHERE t.session_id=? ORDER BY t.created_at DESC,t.rowid DESC LIMIT 1",
                (session_id,),
            ).fetchone()
        return row

    def latest_resumable_turn_for_session(self, session_id: str):
        """Return the newest persisted nonterminal turn without an arbitrary scan cap."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT t.turn_id,r.payload_json FROM turns t JOIN runtimes r ON r.turn_id=t.turn_id "
                "WHERE t.session_id=? ORDER BY t.created_at DESC,t.rowid DESC",
                (session_id,),
            )
            for turn_id, payload_json in rows:
                payload = json.loads(payload_json)
                phase = (payload.get("extensions") or {}).get("phase")
                if phase not in {"finished", "partial"}:
                    return turn_id
        return None

    def persisted_turn_by_id(self, turn_id: str, session_id: str | None = None):
        with self._connect() as conn:
            if session_id is None:
                row = conn.execute(
                    "SELECT t.turn_id,t.message,t.message_sha256 FROM turns t JOIN runtimes r ON r.turn_id=t.turn_id WHERE t.turn_id=?",
                    (turn_id,),
                ).fetchone()
            else:
                row = conn.execute(
                    "SELECT t.turn_id,t.message,t.message_sha256 FROM turns t JOIN runtimes r ON r.turn_id=t.turn_id WHERE t.turn_id=? AND t.session_id=?",
                    (turn_id, session_id),
                ).fetchone()
        return row

    def turn_in_session(self, turn_id, session_id):
        with self._connect() as conn:
            return conn.execute("SELECT 1 FROM turns WHERE turn_id=? AND session_id=?", (turn_id, session_id)).fetchone() is not None
