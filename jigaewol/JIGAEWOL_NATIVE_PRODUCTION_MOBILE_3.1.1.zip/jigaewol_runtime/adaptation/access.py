from __future__ import annotations

"""Optional keyed access contract.

The key authenticates an explicit access state only. Only a salted scrypt
digest is persisted. ``JIGAEWOL::PRIORITY`` remains a portable legacy marker name
for compatibility, not a resource-policy token.
"""

from pathlib import Path
import hashlib, hmac, json, os

_FILENAME = "access_gate.json"
PORTABLE_PRIORITY_MARKER = "JIGAEWOL::PRIORITY"


def marker_matches(message: str) -> bool:
    if not isinstance(message, str):
        return False
    text = message.casefold(); marker = PORTABLE_PRIORITY_MARKER.casefold()
    return marker in text and (marker + " off") not in text


def _derive(secret: str, salt: bytes) -> bytes:
    return hashlib.scrypt(secret.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)


class AccessGateStore:
    def __init__(self, state_dir):
        root = Path(state_dir); root.mkdir(parents=True, exist_ok=True)
        self.path = root / _FILENAME

    def configure(self, secret: str, *, enabled=True):
        if not isinstance(secret, str) or not secret:
            raise ValueError("access key must be nonempty text")
        if not isinstance(enabled, bool):
            raise ValueError("enabled must be boolean")
        salt = os.urandom(16); digest = _derive(secret, salt)
        self.path.write_text(json.dumps({"version": 3, "enabled": enabled, "armed": False,
            "salt_hex": salt.hex(), "digest_hex": digest.hex(), "mode": "keyed_access"}, sort_keys=True), encoding="utf-8")
        return self.status()

    def bootstrap(self, payload):
        if self.path.exists(): return self.status()
        if not isinstance(payload, dict): raise ValueError("JIGAEWOL bootstrap must be an object")
        salt_hex, digest_hex = str(payload.get("salt_hex", "")), str(payload.get("digest_hex", ""))
        if len(salt_hex) != 32 or len(digest_hex) != 64: raise ValueError("JIGAEWOL bootstrap digest is malformed")
        bytes.fromhex(salt_hex); bytes.fromhex(digest_hex)
        self.path.write_text(json.dumps({"version": 3, "enabled": True, "armed": False,
            "salt_hex": salt_hex, "digest_hex": digest_hex, "mode": "keyed_access"}, sort_keys=True), encoding="utf-8")
        return self.status()

    def status(self):
        if not self.path.exists(): return {"configured": False, "enabled": False, "armed": False, "mode": "keyed_access"}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        enabled = data.get("enabled")
        armed = data.get("armed")
        if not isinstance(enabled, bool) or not isinstance(armed, bool):
            raise ValueError("access gate enabled/armed fields must be boolean")
        salt_hex = data.get("salt_hex")
        digest_hex = data.get("digest_hex")
        configured = False
        if isinstance(salt_hex, str) and isinstance(digest_hex, str) and len(salt_hex) == 32 and len(digest_hex) == 64:
            try:
                configured = len(bytes.fromhex(salt_hex)) == 16 and len(bytes.fromhex(digest_hex)) == 32
            except ValueError:
                configured = False
        version = data.get("version", 3)
        if isinstance(version, bool) or not isinstance(version, int) or version < 1:
            raise ValueError("access gate version must be a positive integer")
        return {"configured": configured, "enabled": enabled,
                "armed": armed, "version": version, "mode": "keyed_access"}

    def verify(self, secret):
        if not isinstance(secret, str) or not secret or not self.path.exists(): return False
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if data.get("enabled") is not True: return False
        try:
            return hmac.compare_digest(_derive(secret, bytes.fromhex(data["salt_hex"])), bytes.fromhex(data["digest_hex"]))
        except (KeyError, TypeError, ValueError):
            return False

    def arm(self, secret):
        if not self.verify(secret): return False
        data = json.loads(self.path.read_text(encoding="utf-8")); data["armed"] = True
        self.path.write_text(json.dumps(data, sort_keys=True), encoding="utf-8"); return True

    def disarm(self):
        if not self.path.exists(): return self.status()
        data=json.loads(self.path.read_text(encoding="utf-8")); data["armed"]=False
        self.path.write_text(json.dumps(data,sort_keys=True),encoding="utf-8"); return self.status()

    def disable(self):
        if not self.path.exists(): return self.status()
        data=json.loads(self.path.read_text(encoding="utf-8")); data.update(enabled=False,armed=False)
        self.path.write_text(json.dumps(data,sort_keys=True),encoding="utf-8"); return self.status()


def active_contract(goal_gravity, *, activation_source="armed_state"):
    return {"active": True, "mode": "keyed_access", "activation_source": str(activation_source),
            "goal_signature": (goal_gravity or {}).get("signature"),
            "goal_anchor_ids": list((goal_gravity or {}).get("anchor_ids", [])),
            "resource_rule": "authorization_scope_only_no_resource_boost"}
