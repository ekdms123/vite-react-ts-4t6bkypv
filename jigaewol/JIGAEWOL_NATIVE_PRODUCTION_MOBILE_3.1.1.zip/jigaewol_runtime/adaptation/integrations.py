from __future__ import annotations

from contextlib import closing
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import sqlite3

from jigaewol_runtime.methods import prepare_job

_NATIVE_KIND_VALIDATORS = {"capability", "python_method", "semantic_contract"}


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def validate_integration_manifest(value):
    if not isinstance(value, dict):
        raise ValueError("integration manifest must be an object")
    out = deepcopy(value)
    gid = _text(out.get("id"), "integration id")
    if not gid.replace("-", "").replace(".", "").replace("_", "").isalnum():
        raise ValueError("integration id must use letters, digits, dot, dash or underscore")
    _text(out.get("version", "1"), "integration version")
    kind = _text(out.get("kind"), "integration kind")
    # Integration kinds are an open set.  Native kinds receive specialized
    # validation below; emergent kinds remain representable and may be bound by
    # a generated adapter/protocol at execution time.
    out["kind_interpretation"] = "native" if kind in _NATIVE_KIND_VALIDATORS else "open_set_pending_adapter"
    _text(out.get("purpose"), "integration purpose")
    applicability = out.get("applicability", ["*"])
    if not isinstance(applicability, list) or not applicability or any(not isinstance(x, str) or not x.strip() for x in applicability):
        raise ValueError("integration applicability must be a nonempty text list")
    effects = out.get("effect_contract")
    if not isinstance(effects, dict):
        raise ValueError("integration effect_contract must be an object")
    produces = effects.get("produces")
    if not isinstance(produces, list) or not produces or any(not isinstance(x, str) or not x.strip() for x in produces):
        raise ValueError("integration effect_contract.produces must be nonempty text")
    origin = out.get("origin")
    if not isinstance(origin, dict):
        raise ValueError("integration origin must be an object")
    _text(origin.get("kind"), "integration origin kind")
    _text(origin.get("ref"), "integration origin ref")
    if "source_sha256" in origin:
        digest = str(origin["source_sha256"]).lower()
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("integration origin source_sha256 must be a SHA-256 hex digest")
    if kind == "capability":
        _text(out.get("capability_id"), "capability integration capability_id")
        defaults = out.get("default_parameters", {})
        if not isinstance(defaults, dict):
            raise ValueError("capability integration default_parameters must be an object")
    elif kind == "python_method":
        method = out.get("method")
        # prepare_job performs AST validation without executing source.
        prepare_job(method, {})
    elif kind == "semantic_contract":
        _text(out.get("instruction"), "semantic integration instruction")
    else:
        # Do not reject a never-before-seen capability ontology.  Preserve any
        # adapter/protocol hint when present; later execution evidence determines
        # whether the emergent kind actually works.
        adapter = out.get("adapter_contract")
        if adapter is not None and not isinstance(adapter, dict):
            raise ValueError("open-set integration adapter_contract must be an object when supplied")
    base = deepcopy(out)
    base.pop("manifest_sha256", None)
    out["manifest_sha256"] = hashlib.sha256(_canonical(base).encode("utf-8")).hexdigest()
    return out


class IntegrationStore:
    """Persistent content-addressed upstream mechanism registry.

    Installing an extension does not claim that it executed. Execution is recorded
    only when a corresponding JIGAEWOL work item crosses a host_tool boundary or a
    semantic_contract work item is explicitly completed by the host.
    """
    def __init__(self, root, session_id=None):
        self.shared_store = root if hasattr(root, "record_integration") else None
        self.session_id = session_id or "chat"
        if self.shared_store is not None:
            self.db_path = self.shared_store.db_path
            return
        root = Path(root)
        root.mkdir(parents=True, exist_ok=True)
        self.db_path = root / "integrations.sqlite3"
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS integrations(
                id TEXT PRIMARY KEY, manifest_json TEXT NOT NULL,
                installed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""")

    def prepare(self, manifest, *, observed_source=None):
        checked = validate_integration_manifest(manifest)
        origin = checked.get("origin", {})
        origin_kind = str(origin.get("kind", "")).strip().casefold()
        remote_kinds = {"github", "remote", "url", "web", "http", "https", "repository"}
        if origin_kind in remote_kinds and observed_source is None:
            raise ValueError("remote integration installation requires the actually observed upstream content")
        if origin_kind in remote_kinds and not origin.get("source_sha256"):
            raise ValueError("remote integration installation requires origin.source_sha256 to bind the observed upstream bytes")
        expected = origin.get("source_sha256")
        if expected is not None:
            if observed_source is None:
                raise ValueError("hash-pinned integration installation needs the actually observed upstream content")
            if isinstance(observed_source, str):
                upstream_bytes = observed_source.encode("utf-8")
            else:
                upstream_bytes = _canonical(observed_source).encode("utf-8")
            actual = hashlib.sha256(upstream_bytes).hexdigest()
            if actual != expected:
                raise ValueError("integration upstream content does not match origin.source_sha256")
        return checked

    def install(self, manifest, *, observed_source=None):
        checked = self.prepare(manifest, observed_source=observed_source)
        if self.shared_store is not None:
            self.shared_store.record_integration(self.session_id, checked["id"], checked)
            return checked
        encoded = _canonical(checked)
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            row = conn.execute("SELECT manifest_json FROM integrations WHERE id=?", (checked["id"],)).fetchone()
            if row and row[0] != encoded:
                raise ValueError("integration id already exists with different content; use a new versioned id")
            conn.execute("INSERT OR IGNORE INTO integrations(id,manifest_json) VALUES(?,?)", (checked["id"], encoded))
        return checked

    def get(self, integration_id):
        if self.shared_store is not None:
            return self.shared_store.integration_by_id(self.session_id, integration_id)
        with closing(sqlite3.connect(self.db_path)) as conn:
            row = conn.execute("SELECT manifest_json FROM integrations WHERE id=?", (integration_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def catalog(self, limit=None):
        if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit < 1):
            raise ValueError("integration catalog limit must be a positive integer or None")
        if self.shared_store is not None:
            return self.shared_store.integration_catalog(self.session_id, limit)
        with closing(sqlite3.connect(self.db_path)) as conn:
            if limit is None:
                rows = conn.execute("SELECT manifest_json FROM integrations ORDER BY updated_at DESC,rowid DESC").fetchall()
            else:
                rows = conn.execute("SELECT manifest_json FROM integrations ORDER BY updated_at DESC,rowid DESC LIMIT ?", (limit,)).fetchall()
        return [json.loads(row[0]) for row in rows]
