"""Adaptive-runtime primitives used by the current Jigaewol runtime."""
from .goal_gravity import build_goal_gravity, goal_signature
from .search_strategy import empty_search_strategy, normalize_search_plan, bind_search_observation, compact_search_strategy
from .integrations import IntegrationStore, validate_integration_manifest
from .archive import AdaptationArchive, extract_runtime_profile
from .revision import cognition_profile, witness_revisions, revision_report_ok, runtime_execution_fitness
from .runtime import AdaptationMixin
from .access import AccessGateStore, active_contract, PORTABLE_PRIORITY_MARKER, marker_matches

__all__ = [
    "build_goal_gravity", "goal_signature", "empty_search_strategy", "normalize_search_plan",
    "bind_search_observation", "compact_search_strategy", "IntegrationStore", "validate_integration_manifest",
    "AdaptationArchive", "extract_runtime_profile", "cognition_profile", "witness_revisions",
    "revision_report_ok", "runtime_execution_fitness", "AdaptationMixin", "AccessGateStore",
    "active_contract", "PORTABLE_PRIORITY_MARKER", "marker_matches",
]
