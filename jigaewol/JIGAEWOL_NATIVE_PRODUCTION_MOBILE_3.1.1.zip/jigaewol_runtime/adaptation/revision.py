from __future__ import annotations
import math

"""Small cross-turn mechanism revision.

JIGAEWOL revises reusable execution structure, not named thinking personas. A
revision is promoted only when the addressed structural dimension actually
changes and the resulting turn has observable utility.
"""

from copy import deepcopy
import hashlib, json


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def cognition_profile(payload):
    payload = payload if isinstance(payload, dict) else {}
    return {
        "frame": deepcopy(payload.get("frame", {})),
        "routes": deepcopy(payload.get("route_candidates", [])),
        "steps": deepcopy(payload.get("steps", [])),
        "open_variables": deepcopy(payload.get("open_variables", [])),
        "stop_condition": str(payload.get("stop_condition", "")),
    }


def _dimension(profile, target):
    if not isinstance(profile, dict): return None
    if target in profile: return deepcopy(profile[target])
    # Open target names may address nested dimensions with dot notation.
    cur=profile
    for part in str(target or "").split("."):
        if not part: continue
        if not isinstance(cur,dict) or part not in cur: return None
        cur=cur[part]
    return deepcopy(cur)


def witness_revisions(adaptation_trace, parent_records, current_profile, *, allow_deferred=True):
    trace=adaptation_trace or {}; revisions=trace.get("revisions",[]) or []
    parents={str(p.get("id")):p for p in parent_records or () if isinstance(p,dict) and p.get("id")}
    selected=[str(x) for x in trace.get("parent_profile_ids",[]) or []]
    if any(x not in parents for x in selected):
        raise ValueError("revision references unavailable parent profile")
    report=[]
    for revision in revisions:
        if not isinstance(revision,dict): raise ValueError("revision must be an object")
        mid=str(revision.get("id","")).strip()
        target=str(revision.get("target","")).strip()
        if not mid or not target: raise ValueError("revision needs id and target")
        after=_dimension(current_profile,target)
        if after is None:
            report.append({"id":mid,"target":target,"status":"deferred" if allow_deferred else "unverified",
                           "reason":"target dimension unavailable"})
            continue
        if not selected:
            status="verified" if after not in (None,"",[],{}) else "unverified"
            report.append({"id":mid,"target":target,"status":status,"after_sha256":_hash(after),
                           "reason":"genesis target materialized" if status=="verified" else "empty target"})
            continue
        changed=[]; before=[]
        for pid in selected:
            value=_dimension(parents[pid].get("profile",{}),target)
            before.append({"parent_id":pid,"sha256":_hash(value)})
            if _canonical(value)!=_canonical(after): changed.append(pid)
        report.append({"id":mid,"target":target,"status":"verified" if changed else "unverified",
                       "before":before,"after_sha256":_hash(after),"changed_from_parent_ids":changed,
                       "reason":"structural delta observed" if changed else "identical to selected parents"})
    return report


def revision_report_ok(report, *, deferred_ok=False):
    allowed={"verified"} | ({"deferred"} if deferred_ok else set())
    return all(x.get("status") in allowed for x in report or ())


def runtime_execution_fitness(runtime, revision_report):
    """Score observed outcome quality; keep execution volume as telemetry only."""
    tools=len(runtime.extensions.get("tool_submissions",[]) or [])
    deltas=sum(1 for x in runtime.extensions.get("semantic_epochs",[]) or [] if isinstance(x,dict) and x.get("kind")=="delta")
    observed_search=sum(1 for x in (runtime.extensions.get("search_strategy",{}).get("nodes",{}) or {}).values()
                        if isinstance(x,dict) and x.get("status") in {"observed","interpreted"})
    integrations=len(runtime.extensions.get("integration_execution_history",[]) or [])
    verified=sum(1 for x in revision_report or () if x.get("status")=="verified")
    failed=sum(1 for x in revision_report or () if x.get("status") not in {"verified"})
    resolved=bool(runtime.answer is not None and not runtime.extensions.get("unresolved"))
    assessment=runtime.extensions.get("quality_assessment",{}) or {}

    def q(name, default=0.0):
        raw = assessment.get(name, default)
        if isinstance(raw, bool):
            return max(0.0, min(1.0, float(default)))
        try:
            value = float(raw if raw is not None else 0.0)
        except (TypeError, ValueError, OverflowError):
            value = float(default)
        if not math.isfinite(value):
            value = float(default)
        return max(0.0, min(1.0, value))

    evidence_gain=q("evidence_binding")
    novelty_gain=q("novelty")
    observed_causal=q("mechanism_effect")
    causal_gain=max(observed_causal, min(1.0, .35*verified))
    goal_coverage=max(q("goal_coverage"), 1.0 if resolved else 0.0)
    score=.40*goal_coverage + .25*evidence_gain + .20*causal_gain + .15*novelty_gain
    if failed:
        score*=.35

    recompile_count = getattr(runtime, "recompile_count", 0)
    if type(recompile_count) is not int or recompile_count < 0:
        raise ValueError("runtime recompile_count must be a nonnegative integer")
    interaction_tax=min(.45,.025*max(0,tools-2)+.018*max(0,deltas-2)+.02*max(0,recompile_count-2))
    activity={
        "tool_observations":tools, "delta_epochs":deltas,
        "observed_search_branches":observed_search, "integration_executions":integrations,
        "recompile_count":recompile_count,
    }
    return {
        "score":round(max(0.0,min(1.0,score)),6),
        "evidence_gain":round(evidence_gain,6), "causal_gain":round(causal_gain,6),
        "novelty_gain":round(novelty_gain,6), "goal_coverage":round(goal_coverage,6),
        "cost_efficiency":round(max(0.0,1.0-interaction_tax),6), "interaction_tax":round(interaction_tax,6),
        "quality_basis":"outcome_observations_not_activity_volume",
        "activity":activity,
        # Compatibility counters remain readable but are explicitly telemetry.
        "tool_observations":tools,"delta_epochs":deltas,"observed_search_branches":observed_search,
        "integration_executions":integrations,"verified_revisions":verified,"unverified_revisions":failed,
        "scope":"observed outcome quality; execution volume is telemetry and never a quality reward",
    }
