from __future__ import annotations

"""Advisory source-perspective expansion hints.

These are prompts for exploration, not a closed ontology and not a required
checklist. The host/cognition layer may invent, merge, ignore, or replace any
route when another perspective or mechanism is more decision-relevant.
"""


def suggest_source_perspectives(request: str, *, novelty_pressure=0.0):
    if not isinstance(request, str) or not request.strip():
        raise ValueError("request must be nonempty text")
    if isinstance(novelty_pressure, bool) or not isinstance(novelty_pressure, (int, float)):
        raise ValueError("novelty_pressure must be numeric")
    text = request.casefold()
    rows = [
        {"perspective": "primary_official", "mechanism": "official releases, docs, changelogs and first-party claims"},
        {"perspective": "developer_communities", "mechanism": "GitHub issues, Hacker News, Stack Overflow, dev forums and implementation chatter"},
        {"perspective": "community_experience", "mechanism": "Reddit-like user experience, complaints, workarounds and counterexamples"},
    ]
    trendish = any(x in text for x in ("trend", "emerging", "popular", "viral", "prompt", "유행", "요즘", "뜨는", "트렌드"))
    feedish = any(x in text for x in (
        "instagram", "tiktok", "twitter", " x ", "추천 피드", "추천피드", "릴스", "reels", "쇼츠", "shorts",
        "인스타", "틱톡", "트위터", "소셜", "social feed", "recommendation feed",
    ))
    if trendish or float(novelty_pressure) >= 0.5:
        rows += [
            {"perspective": "social_video", "mechanism": "YouTube/video creator demonstrations, keywords and workflow diffusion"},
            {"perspective": "social_streams", "mechanism": "public social posts, live discussion and recommendation-adjacent observation where accessible"},
            {"perspective": "cross_language_tech", "mechanism": "non-English technical communities and region-specific product ecosystems"},
            {"perspective": "open_source_frontier", "mechanism": "new repositories, forks, issues, releases and developer adoption signals"},
        ]
    if feedish:
        rows += [
            {"perspective": "authenticated_recommendation_streams", "mechanism": "user-controlled signed-in recommendation/feed observation through an actually connected browser session; distinguish sensed feed from public search"},
            {"perspective": "interaction_gated_social_knowledge", "mechanism": "comments, replies, profile links or interaction-gated material when the live goal needs it and the HOST exposes the required interaction; external side effects remain explicit observations/actions"},
        ]
    if float(novelty_pressure) >= 0.8:
        rows += [
            {"perspective": "academic_frontier", "mechanism": "recent papers and preprints for mechanisms not yet mainstream"},
            {"perspective": "adjacent_domain_transfer", "mechanism": "mechanisms imported from unrelated disciplines rather than paraphrased same-domain search"},
        ]
    return tuple({**row, "advisory": True} for row in rows)
