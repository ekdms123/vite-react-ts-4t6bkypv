from __future__ import annotations

from contextlib import closing
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import math
import re
import sqlite3


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _unit_score(value, default=0.0):
    if isinstance(value, bool):
        return float(default)
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    if not math.isfinite(number):
        return float(default)
    return max(0.0, min(1.0, number))


def _terms(text):
    return sorted({x.casefold() for x in re.findall(r"\w+", str(text)) if len(x) >= 2})


def extract_runtime_profile(runtime):
    """Extract reusable mechanisms while omitting answer prose and user text."""
    search=runtime.extensions.get("search_adaptation",{}) or {}
    search_mechanisms=[]
    for node in (search.get("nodes",{}) or {}).values() if isinstance(search.get("nodes",{}),dict) else ():
        if isinstance(node,dict):
            search_mechanisms.append({k:deepcopy(node.get(k)) for k in (
                "mechanism","discriminator","surface","language","source_perspective","representation_shift"
            ) if node.get(k) not in (None,"")})
    steps=[]
    for n in runtime.program.nodes:
        if n.executor=="local" or n.operation in {"intents.extract","closure.check"}: continue
        steps.append({"operation":n.operation,"executor":n.executor,
                      "operator_ids":list(getattr(n,"operator_ids",())),
                      "parameters":dict(getattr(n,"parameters",()) or ())})
    epochs=[]
    for item in runtime.extensions.get("semantic_epochs",[]) or []:
        if not isinstance(item,dict): continue
        epochs.append({k:deepcopy(item.get(k)) for k in ("kind","route_ids","frame_changed","material_delta") if item.get(k) not in (None,[])})
    return {
        "version":5,
        "decision_frame":deepcopy(runtime.extensions.get("cognition_frame",{})),
        "semantic_epochs":epochs,
        "search_mechanisms":search_mechanisms,
        "integration_ids":sorted(set(runtime.extensions.get("integration_ids_used",[]))),
        "judgment_plane":deepcopy(runtime.extensions.get("judgment_plane",{})),
        "steps":steps,
        "open_variables":deepcopy(runtime.extensions.get("open_variables",[])),
    }



def _pareto_front(items):
    """Return nondominated records over stored multi-objective fitness axes."""
    axes=("causal_gain","evidence_gain","novelty_gain","goal_coverage","cost_efficiency")
    def vec(item):
        f=item.get("fitness",{}) if isinstance(item,dict) else {}
        return tuple(_unit_score(f.get(a, 0.0)) for a in axes)
    out=[]
    for i,item in enumerate(items):
        vi=vec(item); dominated=False
        for j,other in enumerate(items):
            if i==j: continue
            vj=vec(other)
            if all(b>=a for a,b in zip(vi,vj)) and any(b>a for a,b in zip(vi,vj)):
                dominated=True; break
        if not dominated: out.append(item)
    return out


class AdaptationArchive:
    """Cross-turn mechanism archive with content-addressed promotion.

    In runtime use this shares the StateStore database so a finished turn and its
    promoted configuration-lineage commit atomically. Standalone path mode remains available
    for development probes.
    """

    def __init__(self, root, session_id=None):
        self.shared_store = root if hasattr(root, "record_adaptation_profile") else None
        self.session_id = session_id or "chat"
        if self.shared_store is not None:
            self.db_path = self.shared_store.db_path
            return
        root = Path(root)
        root.mkdir(parents=True, exist_ok=True)
        self.db_path = root / "adaptation.sqlite3"
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS profiles(
                id TEXT PRIMARY KEY, task_terms_json TEXT NOT NULL, profile_json TEXT NOT NULL,
                parent_ids_json TEXT NOT NULL, revisions_json TEXT NOT NULL,
                score REAL NOT NULL DEFAULT 0, observations INTEGER NOT NULL DEFAULT 1,
                helpful INTEGER NOT NULL DEFAULT 0, unhelpful INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'candidate', execution_fitness REAL NOT NULL DEFAULT 0,
                fitness_json TEXT NOT NULL DEFAULT '{}', revision_report_json TEXT NOT NULL DEFAULT '[]',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
            cols = {row[1] for row in conn.execute("PRAGMA table_info(profiles)").fetchall()}
            migrations = {
                "status": "TEXT NOT NULL DEFAULT 'candidate'",
                "execution_fitness": "REAL NOT NULL DEFAULT 0",
                "fitness_json": "TEXT NOT NULL DEFAULT '{}'",
                "revision_report_json": "TEXT NOT NULL DEFAULT '[]'",
            }
            for name, decl in migrations.items():
                if name not in cols:
                    conn.execute(f"ALTER TABLE profiles ADD COLUMN {name} {decl}")

    def prepare_record(self, message, profile, *, parent_ids=(), revisions=(), revision_report=(), fitness=None,
                       status="candidate"):
        if status not in {"available", "candidate", "promoted"}:
            raise ValueError("adaptation profile status must be available, candidate, or promoted")
        if not isinstance(profile, dict):
            raise ValueError("adaptation profile must be an object")
        if not isinstance(parent_ids, (list, tuple)) or any(not isinstance(x, str) or not x.strip() for x in parent_ids):
            raise ValueError("adaptation parent_ids must be a list of nonempty text ids")
        if not isinstance(revisions, (list, tuple)) or any(not isinstance(x, dict) for x in revisions):
            raise ValueError("adaptation revisions must be a list of objects")
        if revision_report is None:
            revision_report = ()
        if not isinstance(revision_report, (list, tuple)) or any(not isinstance(x, dict) for x in revision_report):
            raise ValueError("adaptation revision_report must be a list of objects")
        if fitness is None:
            fitness = {}
        if not isinstance(fitness, dict):
            raise ValueError("adaptation fitness must be an object")
        payload = deepcopy(profile)
        raw = _canonical(payload)
        gid = "profile_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]
        fitness = deepcopy(fitness)
        execution_fitness = _unit_score(fitness.get("score", 0.0))
        return {
            "id": gid,
            "task_terms": _terms(message),
            "profile": payload,
            "parent_ids": list(parent_ids),
            "revisions": [deepcopy(x) for x in revisions],
            "status": status,
            "execution_fitness": execution_fitness,
            "fitness": fitness,
            "revision_report": [deepcopy(x) for x in revision_report],
        }

    def record(self, message, profile, *, parent_ids=(), revisions=(), revision_report=(), fitness=None,
               status="candidate"):
        record = self.prepare_record(message, profile, parent_ids=parent_ids, revisions=revisions,
                                     revision_report=revision_report, fitness=fitness, status=status)
        gid = record["id"]
        if self.shared_store is not None:
            self.shared_store.record_adaptation_profile(self.session_id, record)
            return gid
        raw = _canonical(record["profile"])
        report_json = _canonical(record["revision_report"])
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            row = conn.execute("SELECT observations,execution_fitness,status,profile_json FROM profiles WHERE id=?", (gid,)).fetchone()
            if row and row[3] != raw:
                raise ValueError("adaptation profile id collision with different content")
            if row:
                current_status = str(row[2])
                incoming_status = str(record["status"])
                next_status = (
                    "promoted"
                    if current_status == "promoted" and incoming_status in {"available", "candidate"}
                    else incoming_status
                )
                conn.execute("""UPDATE profiles SET observations=observations+1,
                    execution_fitness=max(execution_fitness,?),fitness_json=?,revision_report_json=?,
                    status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                    (record["execution_fitness"], _canonical(record["fitness"]), report_json, next_status, gid))
            else:
                conn.execute("""INSERT INTO profiles(
                    id,task_terms_json,profile_json,parent_ids_json,revisions_json,status,
                    execution_fitness,fitness_json,revision_report_json)
                    VALUES(?,?,?,?,?,?,?,?,?)""",
                    (gid, _canonical(record["task_terms"]), raw, _canonical(record["parent_ids"]),
                     _canonical(record["revisions"]), record["status"], record["execution_fitness"],
                     _canonical(record["fitness"]), report_json))
        return gid

    @staticmethod
    def _decode_row(row):
        if not row:
            return None
        return {
            "id": row[0], "task_terms": json.loads(row[1]), "profile": json.loads(row[2]),
            "parent_ids": json.loads(row[3]), "revisions": json.loads(row[4]), "score": float(row[5]),
            "observations": int(row[6]), "helpful": int(row[7]), "unhelpful": int(row[8]),
            "status": row[9], "execution_fitness": float(row[10]), "fitness": json.loads(row[11]),
            "revision_report": json.loads(row[12]),
        }

    def get(self, profile_id):
        if self.shared_store is not None:
            return self._decode_row(self.shared_store.adaptation_profile_by_id(self.session_id, profile_id))
        with closing(sqlite3.connect(self.db_path)) as conn:
            row = conn.execute("""SELECT id,task_terms_json,profile_json,parent_ids_json,revisions_json,
                score,observations,helpful,unhelpful,status,execution_fitness,fitness_json,revision_report_json
                FROM profiles WHERE id=?""", (profile_id,)).fetchone()
        return self._decode_row(row)

    def feedback(self, profile_id, helpful):
        if not isinstance(helpful, bool):
            raise ValueError("helpful must be boolean")
        if self.shared_store is not None:
            return self.shared_store.adaptation_feedback(self.session_id, profile_id, helpful)
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            row = conn.execute("SELECT helpful,unhelpful,status FROM profiles WHERE id=?", (profile_id,)).fetchone()
            if not row:
                raise KeyError(profile_id)
            hp = row[0] + (1 if helpful else 0)
            up = row[1] + (0 if helpful else 1)
            score = (hp - up) / max(1, hp + up)
            # Negative feedback lowers the score but does not erase the candidate.
            status = "promoted" if hp >= up else "candidate"
            conn.execute("UPDATE profiles SET helpful=?,unhelpful=?,score=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                         (hp, up, score, status, profile_id))
        return {"id": profile_id, "helpful": hp, "unhelpful": up, "score": score, "status": status}

    def recall(self, message, limit=None, causal_query=None):
        if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit < 1):
            raise ValueError("adaptation recall limit must be a positive integer or None")
        target = set(_terms(message))
        if self.shared_store is not None:
            rows = list(self.shared_store.adaptation_profile_rows(self.session_id, None))
        else:
            with closing(sqlite3.connect(self.db_path)) as conn:
                rows = conn.execute("""SELECT id,task_terms_json,profile_json,parent_ids_json,revisions_json,
                    score,observations,helpful,unhelpful,status,execution_fitness,fitness_json,revision_report_json
                    FROM profiles ORDER BY updated_at DESC,rowid DESC""").fetchall()
        ranked = []
        for row in rows:
            terms = set(json.loads(row[1]))
            overlap = len(target & terms) / max(1, len(target | terms))
            feedback = float(row[5])
            execution_fitness = float(row[10])
            structural = 0.0
            if causal_query is not None:
                try:
                    from jigaewol_runtime.judgment.causal_memory import CausalMechanism, graph_hash, _edge_features, _jaccard
                    q = causal_query if isinstance(causal_query, CausalMechanism) else CausalMechanism(**causal_query)
                    topo = json.loads(row[2]).get("causal_topology")
                    if isinstance(topo, dict):
                        m = CausalMechanism(**{**topo,
                            "nodes": tuple(tuple(x) for x in topo.get("nodes", ())),
                            "edges": tuple(tuple(x) for x in topo.get("edges", ())),
                            "preconditions": tuple(topo.get("preconditions", ())),
                            "failure_modes": tuple(topo.get("failure_modes", ()))})
                        structural = 1.0 if graph_hash(q) == graph_hash(m) else _jaccard(_edge_features(q), _edge_features(m))
                except (TypeError, ValueError, KeyError, json.JSONDecodeError):
                    structural = 0.0
            if overlap <= 0 and structural <= 0 and row[7] <= 0:
                # Keep unmatched material available; ranking determines order, not existence.
                pass
            item={
                "id": row[0], "profile": json.loads(row[2]),
                "parent_ids": json.loads(row[3]), "revisions": json.loads(row[4]),
                "score": feedback, "observations": int(row[6]), "status": row[9],
                "execution_fitness": execution_fitness, "fitness": json.loads(row[11]),
                "selection_basis": {
                    "causal_structure_score": structural,
                    "term_overlap": overlap,
                    "user_feedback_score": feedback,
                    "mechanical_execution_fitness": execution_fitness,
                },
                "revision_report": json.loads(row[12]),
            }
            rank = (structural, overlap, max(0.0, feedback), execution_fitness)
            ranked.append((rank,item))
        # JIGAEWOL 10: relevance chooses the neighborhood; Pareto survival prevents a
        # single scalar from erasing unusual high-novelty/high-evidence parents.
        front_ids={x["id"] for x in _pareto_front([item for _,item in ranked])}
        # JIGAEWOL 10: a single scalar relevance score must not erase a Pareto-surviving
        # causal lineage.  Relevance orders candidates *within* the survivor tier;
        # dominated candidates remain available only after nondominated parents.
        ranked.sort(key=lambda x: (x[1]["id"] in front_ids, *x[0]), reverse=True)
        out, shapes = [], set()
        for _, item in ranked:
            shape = _canonical((item["profile"].get("kernel_shape") or {}).get("representation"))
            shapes.add(shape)
            out.append(item)
            if limit is not None and len(out) >= limit:
                break
        return out
