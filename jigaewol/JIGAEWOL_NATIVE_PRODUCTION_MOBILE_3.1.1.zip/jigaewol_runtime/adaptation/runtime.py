from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math

from jigaewol_runtime.methods import prepare_job
from jigaewol_runtime.adaptation.archive import extract_runtime_profile
from jigaewol_runtime.adaptation.revision import witness_revisions, revision_report_ok, runtime_execution_fitness


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


class AdaptationMixin:
    """Runtime hooks that make the adaptation causal rather than documentary."""

    def install_integration(self, manifest, *, observed_source=None):
        """Install a reusable mechanism into this runtime state.

        This records a mechanism only. It does not claim execution; executions
        are created later as actual work items by ``integration.<id>`` cognition steps.
        """
        checked = self.integrations.install(manifest, observed_source=observed_source)
        return deepcopy(checked)

    def integration_catalog(self):
        return self.integrations.catalog()

    def adaptation_archive(self, message="", limit=None):
        return self.adaptation.recall(message, limit=limit)

    def _integration_step_node(self, runtime, step, intents):
        operation = str(step.get("operation", ""))
        if not operation.startswith("integration."):
            return None
        gid = operation.split(".", 1)[1]
        manifest = (runtime.extensions.get("installed_integrations", {}) or {}).get(gid) or self.integrations.get(gid)
        if manifest is None:
            raise ValueError("cognition requested an uninstalled integration: " + gid)
        params = step.get("parameters", {}) or {}
        if not isinstance(params, dict):
            raise ValueError("integration step parameters must be an object")
        runtime.extensions.setdefault("integration_ids_used", [])
        if gid not in runtime.extensions["integration_ids_used"]:
            runtime.extensions["integration_ids_used"].append(gid)
        kind = manifest["kind"]
        if kind == "capability":
            cap = manifest["capability_id"]
            merged = dict(manifest.get("default_parameters", {}))
            merged.update(params)
            merged["integration_id"] = gid
            merged["integration_manifest_sha256"] = manifest["manifest_sha256"]
            return self._cap_node(runtime, cap, merged, intents,
                operator_ids=tuple(step.get("operator_ids", ()) or ()),
                language_refs=tuple(step.get("language_refs", ()) or ()),
                trigger_refs=tuple(step.get("trigger_refs", ()) or ()),
                visibility_scope=step.get("visibility_scope"))
        if kind == "python_method":
            data = deepcopy(params.get("input", {}))
            job = prepare_job(manifest["method"], data)
            compute = next((c for c in runtime.extensions.get("capability_specs", [])
                            if c.get("role") == "compute"), None)
            if compute is None:
                raise ValueError("python_method integration needs an actual connected compute capability")
            runtime.extensions.setdefault("integration_runs", {})[job["job_id"]] = {
                "integration_id": gid, "job": deepcopy(job), "status": "queued",
                "effect_contract": deepcopy(manifest["effect_contract"]),
            }
            return self._cap_node(runtime, compute["id"], {
                "integration_job": job, "integration_id": gid,
                "integration_manifest_sha256": manifest["manifest_sha256"],
            }, intents,
                operator_ids=tuple(step.get("operator_ids", ()) or ()),
                language_refs=tuple(step.get("language_refs", ()) or ()),
                trigger_refs=tuple(step.get("trigger_refs", ()) or ()),
                visibility_scope=step.get("visibility_scope"))
        instruction = manifest["instruction"]
        local = dict(params)
        local["instruction"] = instruction + "\nPortable semantic integration id: " + gid
        local["integration_id"] = gid
        local["integration_execution_scope"] = "host_semantic_contract_not_external_code"
        return self._node(runtime, "host_semantic", "semantic.integration." + gid,
            intents=intents, parameters=local,
            operator_ids=tuple(step.get("operator_ids", ()) or ()),
            language_refs=tuple(step.get("language_refs", ()) or ()),
            trigger_refs=tuple(step.get("trigger_refs", ()) or ()),
            visibility_scope=step.get("visibility_scope"))

    def _integration_install_result(self, runtime, node, payload):
        manifest = payload.get("manifest")
        source_ref = payload.get("source_ref")
        if not isinstance(source_ref, str) or not source_ref:
            raise ValueError("integration.install requires a recorded source_ref")
        entry = runtime.ledger.get(source_ref)
        if entry.kind not in {"source", "material"} or not entry.tool_origin_refs:
            raise ValueError("integration.install source_ref must come from an actually submitted tool result")
        checked = self.integrations.prepare(manifest, observed_source=entry.content)
        persistent = self.integrations.get(checked["id"])
        if persistent is not None and persistent != checked:
            raise ValueError("integration id already exists with different content; use a new versioned id")
        staged = runtime.extensions.setdefault("installed_integrations", {})
        if checked["id"] in staged and staged[checked["id"]] != checked:
            raise ValueError("current turn already staged this integration id with different content")
        staged[checked["id"]] = deepcopy(checked)
        catalog = {x["id"]: x for x in self.integrations.catalog(limit=None)}
        catalog[checked["id"]] = checked
        runtime.extensions["integration_catalog"] = list(catalog.values())
        return runtime.ledger.add_observation({
            "integration_id": checked["id"],
            "manifest_sha256": checked["manifest_sha256"],
            "source_ref": source_ref,
            "status": "installed_not_yet_executed",
        }, world_refs=node.world_refs)

    def _integration_tool_result(self, runtime, node, payload, source_ref, result_sha256):
        params = dict(node.parameters)
        gid = params.get("integration_id")
        if not gid:
            return None
        manifest = (runtime.extensions.get("installed_integrations", {}) or {}).get(gid) or self.integrations.get(gid)
        if manifest is None:
            raise ValueError("tool result names an uninstalled integration")
        record = {
            "integration_id": gid, "kind": manifest["kind"], "source_ref": source_ref,
            "origin_ref": payload.get("origin_ref"), "result_sha256": result_sha256,
            "effect_contract": deepcopy(manifest["effect_contract"]),
            "verification": "actual_runtime_host_tool_work_received_a_result",
        }
        if manifest["kind"] == "python_method":
            job = params.get("integration_job")
            if not isinstance(job, dict):
                raise ValueError("python integration tool node lost its prepared job")
            output = payload.get("output")
            if not isinstance(output, dict):
                raise ValueError("python integration needs the actual run_job result object")
            expected = prepare_job(manifest["method"], job.get("input"))
            for key in ("job_id", "method_hash", "input_hash"):
                if output.get(key) != expected.get(key) or job.get(key) != expected.get(key):
                    raise ValueError("python integration result does not match its prepared job")
            status = output.get("status")
            if status not in {"ok", "error", "timeout"}:
                raise ValueError("python integration result status is invalid")
            elapsed = output.get("elapsed_seconds")
            if type(elapsed) not in (int, float) or not math.isfinite(elapsed) or elapsed < 0:
                raise ValueError("python integration result needs actual elapsed_seconds")
            if status == "ok":
                raw = _canonical(output.get("output"))
                if hashlib.sha256(raw.encode("utf-8")).hexdigest() != output.get("output_hash"):
                    raise ValueError("python integration result output hash does not match")
            record["execution_scope"] = "restricted_python_subprocess"
            record["status"] = status
            runtime.extensions.setdefault("integration_runs", {}).setdefault(job["job_id"], {}).update(deepcopy(record))
        else:
            record["execution_scope"] = "connected_host_capability"
            record["status"] = "observed"
        runtime.extensions.setdefault("integration_execution_history", []).append(record)
        return record


    def _integration_semantic_result(self, runtime, node, payload, result_ref, result_sha256):
        """Record completion of a portable semantic extension without overstating execution.

        A semantic extension is an actual host-semantic transition in the portable
        rail, but it is not external code/tool execution. The distinction is
        persisted so later selection can use the mechanism without rewriting
        provenance history.
        """
        params = dict(node.parameters)
        gid = params.get("integration_id")
        if not gid or not str(node.operation).startswith("semantic.integration."):
            return None
        manifest = (runtime.extensions.get("installed_integrations", {}) or {}).get(gid) or self.integrations.get(gid)
        if manifest is None:
            raise ValueError("semantic integration result names an uninstalled integration")
        if manifest.get("kind") != "semantic_contract":
            raise ValueError("only semantic_contract integrations may complete on the portable semantic rail")
        record = {
            "integration_id": gid,
            "kind": "semantic_contract",
            "result_ref": result_ref,
            "result_sha256": result_sha256,
            "effect_contract": deepcopy(manifest["effect_contract"]),
            "execution_scope": "portable_host_semantic_transition",
            "status": "completed",
            "verification": "actual_host_semantic_work_item_completed_and_result_bound",
            "external_code_execution": False,
        }
        runtime.extensions.setdefault("integration_execution_history", []).append(record)
        return record

    def _record_adaptation_profile(self, runtime):
        """Persist a compact, evidence-linked cognition configuration for later reuse.

        Adaptation credit is earned only from observable execution deltas. Merely
        naming a new strategy never promotes a stored configuration.
        """
        if runtime.extensions.get("profile_id"):
            return runtime.extensions["profile_id"]

        epochs = runtime.extensions.get("semantic_epochs") or []
        submissions = runtime.extensions.get("tool_submissions") or []
        integration_history = runtime.extensions.get("integration_execution_history") or []
        if not (epochs or submissions or integration_history):
            return None

        profile = extract_runtime_profile(runtime)
        seeds = [x for x in (runtime.extensions.get("adaptation_seed", []) or []) if isinstance(x, dict)]
        available_seed_ids = {str(x.get("id")) for x in seeds if x.get("id")}
        selected_parent_ids = []
        for pid in runtime.extensions.get("selected_parent_profile_ids", []) or []:
            pid = str(pid)
            if pid in available_seed_ids and pid not in selected_parent_ids:
                selected_parent_ids.append(pid)

        revisions = []
        for row in runtime.extensions.get("mechanism_revisions", []) or []:
            if isinstance(row, dict):
                revisions.append(deepcopy(row))

        selected_seeds = [x for x in seeds if str(x.get("id")) in set(selected_parent_ids)]
        report = witness_revisions(
            {"parent_profile_ids": selected_parent_ids, "revisions": revisions},
            selected_seeds, profile, allow_deferred=False,
        )
        fitness = runtime_execution_fitness(runtime, report)
        # Every profile stays available; negative feedback changes ranking evidence, not existence.
        # The previous implementation removed a profile whose
        # claimed mechanism change had no observable structural witness, which killed
        # the idea instead of labelling it. The judgement is kept — as an annotation.
        status = "available"
        witness_ok = revision_report_ok(report, deferred_ok=False)
        structural_witness_missing = bool(revisions) and not witness_ok
        if structural_witness_missing:
            runtime.extensions.setdefault("notices", []).append(
                "adaptation profile kept available with an open witness obligation: a claimed "
                "mechanism change has no observable structural witness yet"
            )
        runtime.extensions["adaptation_structural_witness_missing"] = structural_witness_missing
        task_text = runtime.raw.message + " " + " ".join(
            str(x.get("meaning", "")) for x in runtime.extensions.get("task_requirements", [])
            if isinstance(x, dict)
        )
        record = self.adaptation.prepare_record(
            task_text, profile, parent_ids=selected_parent_ids, revisions=revisions,
            revision_report=report, fitness=fitness, status=status,
        )
        gid = record["id"]
        runtime.extensions["adaptation_profile_record"] = deepcopy(record)
        runtime.extensions["profile_id"] = gid
        runtime.extensions["adaptation_revision_report"] = deepcopy(report)
        runtime.extensions["adaptation_fitness"] = deepcopy(fitness)
        runtime.extensions["adaptation_profile_status"] = status
        return gid

