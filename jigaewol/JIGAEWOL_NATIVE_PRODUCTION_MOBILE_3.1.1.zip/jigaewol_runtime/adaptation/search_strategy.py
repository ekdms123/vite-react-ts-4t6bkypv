from __future__ import annotations

"""Observation-parented open search lineage.

Mechanism/source/language labels are descriptive, not an ontology.  A branch is
useful only when it names a discriminator that can change a decision or next
execution step.  No fixed number of languages, surfaces or branch families is
required.
"""

from copy import deepcopy
import hashlib, json


def empty_search_strategy():
    return {"version": 2, "epoch": 0, "nodes": {}, "frontier_ids": [], "history": []}


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def _bool(value, label):
    if not isinstance(value, bool):
        raise ValueError(label + " must be boolean")
    return value


def _branch_id(query, mechanism, parent_ids, epoch):
    raw=json.dumps([query,mechanism,sorted(parent_ids),epoch],ensure_ascii=False,separators=(",",":"))
    return "search_"+hashlib.sha256(raw.encode()).hexdigest()[:16]


def normalize_search_plan(payload, strategy=None, *, max_branches=None, required_diversity=False, required_lane_ids=()):
    if not isinstance(payload, dict): raise ValueError("research plan must be an object")
    if max_branches is not None and (isinstance(max_branches, bool) or not isinstance(max_branches, int) or max_branches < 1):
        raise ValueError("max_branches must be a positive integer or None")
    if not isinstance(required_diversity, bool):
        raise ValueError("required_diversity must be boolean")
    state=deepcopy(strategy or empty_search_strategy()); state.setdefault("nodes",{}); state.setdefault("history",[])
    raw_epoch=state.get("epoch",0)
    if isinstance(raw_epoch, bool) or not isinstance(raw_epoch, int) or raw_epoch < 0:
        raise ValueError("search strategy epoch must be a nonnegative integer")
    epoch=raw_epoch+1
    supplied=payload.get("branches")
    if supplied is None:
        queries=payload.get("queries")
        if not isinstance(queries,list) or not queries: raise ValueError("research plan needs branches or queries")
        supplied=[{"query":q,"mechanism":"unspecified probe","discriminator":"result changes the next decision","parent_ids":[]} for q in queries]
    if not isinstance(supplied,list) or not supplied: raise ValueError("research plan branches must be a nonempty list")
    scheduling_window = None if max_branches is None else int(max_branches)

    prior=state["nodes"]
    observed={bid for bid,row in prior.items() if row.get("status") in {"observed","interpreted"}}
    prior_queries={str(row.get("query","")).strip().casefold() for row in prior.values()}
    batch_queries=set(); batch_ids=set(); branches=[]
    for branch_index, raw in enumerate(supplied):
        if not isinstance(raw,dict): raise ValueError("each search branch must be an object")
        query=_text(raw.get("query"),"search branch query")
        mechanism=_text(raw.get("mechanism", raw.get("mechanism", "unspecified probe")),"search branch mechanism")
        discriminator=_text(raw.get("discriminator", raw.get("expected_discriminator","result changes the next decision")),"search branch discriminator")
        parents=raw.get("parent_ids",[]) or []
        if not isinstance(parents,list) or any(not isinstance(x,str) or not x for x in parents): raise ValueError("parent_ids must be text ids")
        hashes=raw.get("parent_observation_sha256",[]) or []
        if isinstance(hashes,str): hashes=[hashes]
        if not isinstance(hashes,list) or any(not isinstance(x,str) or not x for x in hashes): raise ValueError("parent_observation_sha256 must be hashes")
        if parents:
            if not set(parents)<=observed: raise ValueError("search branches can inherit only from observed parents")
            actual=[str(prior[x].get("result_sha256","")) for x in parents]
            if not all(actual) or sorted(actual)!=sorted(hashes): raise ValueError("search lineage must bind exact parent observation hashes")
        independent_restart = _bool(raw.get("independent_restart", False), "independent_restart")
        if not parents and observed and not independent_restart:
            # After evidence exists, make ancestry explicit unless this is an
            # intentional independent probe. This preserves causal lineage while
            # allowing genuinely orthogonal restarts without a closed family list.
            raise ValueError("post-observation branch needs observed parents or independent_restart=true")
        key=query.casefold()
        if key in prior_queries or key in batch_queries: raise ValueError("duplicate query lineage")
        batch_queries.add(key)
        bid=str(raw.get("id","")).strip() or _branch_id(query,mechanism,parents,epoch)
        if bid in prior or bid in batch_ids: raise ValueError("search branch ids must be unique")
        batch_ids.add(bid)
        hypothesis=str(raw.get("hypothesis","")).strip()
        decision_effect=str(raw.get("decision_effect","")).strip()
        capability_role=str(raw.get("capability_role","")).strip()
        capability_id=str(raw.get("capability_id","")).strip()
        capability_need=str(raw.get("capability_need","")).strip()
        capability_parameters=raw.get("capability_parameters", {}) or {}
        if not isinstance(capability_parameters, dict): raise ValueError("capability_parameters must be an object")
        branch={
            "id":bid,"query":query,"mechanism":mechanism,"discriminator":discriminator,
            "hypothesis":hypothesis,"decision_effect":decision_effect,
            "capability_role":capability_role,"capability_id":capability_id,
            "capability_need":capability_need,
            "capability_parameters":deepcopy(capability_parameters),
            "parent_ids":list(parents),"parent_observation_sha256":list(hashes),
            "surface":str(raw.get("surface","web")).strip() or "web",
            "language":str(raw.get("language","auto")).strip() or "auto",
            "source_perspective":str(raw.get("source_perspective","")).strip(),
            "representation_shift":str(raw.get("representation_shift","")).strip(),
            "independent_restart": independent_restart,
            "epoch":epoch,"status":"planned",
            "activation_state": "scheduled" if scheduling_window is None or branch_index < scheduling_window else "reserve",
            "selection_is_scheduling_not_pruning": True,
        }
        prior[bid]=deepcopy(branch); branches.append(branch)

    # Optional diversity request is consequence-based rather than count-based.
    if required_diversity and len(branches)>1:
        sigs={(
            b["mechanism"].casefold(), b["discriminator"].casefold(),
            b["surface"].casefold(), b["language"].casefold(),
            b.get("source_perspective", "").casefold(),
            b.get("capability_role", "").casefold(),
            b.get("capability_id", "").casefold(),
            b.get("capability_need", "").casefold(),
            b.get("representation_shift", "").casefold(),
        ) for b in branches}
        if len(sigs)<len(branches): raise ValueError("search branches differ only in wording, not in mechanism/discriminator/source route")
    scheduled = [b for b in branches if b.get("activation_state") == "scheduled"]
    reserve = [b for b in branches if b.get("activation_state") != "scheduled"]
    state["epoch"]=epoch
    state["frontier_ids"]=[b["id"] for b in scheduled]
    state["reserve_frontier_ids"]=[b["id"] for b in reserve]
    state["history"].append({
        "event":"plan","epoch":epoch,
        "branch_ids":list(state["frontier_ids"]),
        "reserve_branch_ids":list(state["reserve_frontier_ids"]),
        "selection_semantics":"scheduling_not_pruning",
    })
    return state,scheduled


def bind_search_observation(strategy, branch_ids, *, source_ref, origin_ref, result_sha256=None):
    state=deepcopy(strategy or empty_search_strategy()); nodes=state.setdefault("nodes",{})
    ids=list(branch_ids or ())
    for bid in ids:
        if bid not in nodes: raise ValueError("tool observation references unknown search branch: "+str(bid))
        nodes[bid].update(status="observed",source_ref=str(source_ref),origin_ref=str(origin_ref))
        if result_sha256: nodes[bid]["result_sha256"]=str(result_sha256)
    if ids:
        state["frontier_ids"]=ids; state.setdefault("history",[]).append({"event":"observation","epoch":state.get("epoch",0),"branch_ids":ids,"source_ref":str(source_ref)})
    return state


def mark_interpreted(strategy, branch_ids):
    state=deepcopy(strategy or empty_search_strategy())
    for bid in branch_ids or ():
        if bid in state.get("nodes",{}): state["nodes"][bid]["status"]="interpreted"
    return state


def compact_search_strategy(strategy, limit=None):
    state=strategy or empty_search_strategy(); nodes=list(state.get("nodes",{}).values())
    if limit is not None:
        nodes = nodes[-max(1, int(limit)):]
    keys=("id","query","hypothesis","mechanism","discriminator","decision_effect","capability_role","capability_id","capability_need","capability_parameters","parent_ids","surface","language","source_perspective","representation_shift","epoch","status","source_ref","activation_state","selection_is_scheduling_not_pruning")
    return {"version":state.get("version",2),"epoch":state.get("epoch",0),"frontier_ids":list(state.get("frontier_ids",[])),
            "reserve_frontier_ids":list(state.get("reserve_frontier_ids",[])),
            "nodes":[{k:x.get(k) for k in keys if x.get(k) not in (None,"")} for x in nodes],
            "rule":"new branches bind observed parents unless explicitly independent"}
