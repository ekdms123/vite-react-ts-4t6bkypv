from __future__ import annotations

import hashlib
import json
import re


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _aid(turn_id, meaning, quote):
    raw = f"{turn_id}\x1f{meaning}\x1f{quote}".encode("utf-8")
    return "anchor_" + hashlib.sha256(raw).hexdigest()[:16]


def goal_signature(goal_gravity):
    anchors = [
        {"id": a.get("id"), "meaning": a.get("meaning"), "quote_sha256": a.get("quote_sha256")}
        for a in goal_gravity.get("anchors", []) if isinstance(a, dict)
    ]
    return hashlib.sha256(_canonical(anchors).encode("utf-8")).hexdigest()


def build_goal_gravity(task_requirements, current_intents=(), current_turn_id=None):
    """Build a compact, source-addressed objective field.

    This is intentionally deterministic. The model can reinterpret the problem,
    but it cannot silently replace the user's source-grounded objectives: every
    downstream compile receives stable anchor ids and source hashes.
    """
    anchors, seen = [], set()
    for item in task_requirements or ():
        if not isinstance(item, dict):
            continue
        meaning = str(item.get("meaning", "")).strip()
        quote = str(item.get("quote", item.get("quote_preview", ""))).strip()
        turn_id = str(item.get("turn_id", current_turn_id or "current"))
        if not meaning:
            continue
        key = (meaning, quote, turn_id)
        if key in seen:
            continue
        seen.add(key)
        status = str(item.get("status", "active"))
        if status in {"withdrawn", "superseded", "resolved"}:
            continue
        anchors.append({
            "id": _aid(turn_id, meaning, quote),
            "meaning": meaning,
            "source_turn_id": turn_id,
            "quote_sha256": hashlib.sha256(quote.encode("utf-8")).hexdigest() if quote else None,
            "source": "task_requirement",
            "priority": 100 if turn_id == str(current_turn_id or "current") else 60,
            "status": "active",
            "supersedes": list(item.get("supersedes", []) or []),
        })
    for item in current_intents or ():
        if isinstance(item, dict):
            meaning = str(item.get("meaning", "")).strip()
            intent_id = str(item.get("id", item.get("intent_id", ""))).strip()
        else:
            meaning = str(getattr(item, "meaning", "")).strip()
            intent_id = str(getattr(item, "intent_id", "")).strip()
        if not meaning:
            continue
        key = (meaning, intent_id, str(current_turn_id or "current"))
        if any(a.get("meaning") == meaning and a.get("source_turn_id") == str(current_turn_id or "current") for a in anchors):
            continue
        anchors.append({
            "id": "anchor_" + hashlib.sha256((str(current_turn_id) + "\x1f" + intent_id + "\x1f" + meaning).encode("utf-8")).hexdigest()[:16],
            "meaning": meaning,
            "source_turn_id": str(current_turn_id or "current"),
            "intent_id": intent_id or None,
            "quote_sha256": None,
            "source": "current_intent",
            "priority": 100,
            "status": "active",
            "supersedes": [],
        })
    field = {
        "version": 1,
        "anchors": anchors,
        "anchor_ids": [a["id"] for a in anchors],
        "rule": "Keep every source-grounded user objective addressable. The latest explicit user instruction receives first interpretive priority when inherited goals are ambiguous or revised; mutate the route freely around the live destination.",
        "priority_policy": "latest_explicit_user_instruction_first",
    }
    field["signature"] = goal_signature(field)
    return field


def terms_for_goal(goal_gravity):
    text = " ".join(str(a.get("meaning", "")) for a in goal_gravity.get("anchors", []))
    return sorted({m.casefold() for m in re.findall(r"\w+", text) if len(m) >= 2})
