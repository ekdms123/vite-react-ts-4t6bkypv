from __future__ import annotations

"""Runtime-enforced structural guarantees for JIGAEWOL generative state.

These validators deliberately enforce only properties the runtime can actually
check. Semantic quality remains a host/model responsibility and is never
upgraded into a runtime attestation.
"""

from copy import deepcopy
import json
import math
import re


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def _finite_json(value, label):
    """Validate storage-safe JSON without imposing a semantic field whitelist."""
    try:
        json.dumps(value, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError, RecursionError) as exc:
        raise ValueError(label + " must be finite, acyclic JSON") from exc
    pending = [value]
    while pending:
        item = pending.pop()
        if item is None or type(item) in (str, bool, int):
            continue
        if type(item) is float and math.isfinite(item):
            continue
        if type(item) is list:
            pending.extend(item)
            continue
        if type(item) is dict and all(type(key) is str for key in item):
            pending.extend(item.values())
            continue
        raise ValueError(label + " must contain only finite JSON values with string object keys")
    return value


def _text_list(value, label, *, allow_empty=True):
    if not isinstance(value, list):
        raise ValueError(label + " must be a list")
    if any(not isinstance(x, str) or not x.strip() for x in value):
        raise ValueError(label + " must contain nonempty text")
    if not allow_empty and not value:
        raise ValueError(label + " must not be empty")
    return value


def _unique_ids(items, label):
    seen = set()
    for item in items:
        iid = _text(item.get("id"), label + " id")
        if iid in seen:
            raise ValueError(label + " ids must be unique")
        seen.add(iid)
    return seen


def validate_world_language(value, *, required=False):
    if value is None and not required:
        return None
    if not isinstance(value, dict):
        raise ValueError("world_language must be an object")
    units = value.get("units")
    if not isinstance(units, list) or (required and not units):
        raise ValueError("world_language.units must be a list" + (" and nonempty" if required else ""))
    for unit in units:
        if not isinstance(unit, dict):
            raise ValueError("each world_language unit must be an object")
        _text(unit.get("id"), "world_language unit id")
        semantic = next((unit.get(k) for k in ("meaning", "definition", "semantics")
                         if isinstance(unit.get(k), str) and unit.get(k).strip()), None)
        if semantic is None:
            raise ValueError("each world_language unit needs meaning, definition, or semantics")
    _unique_ids(units, "world_language unit")
    return value


def validate_action_species(value, *, required=False):
    if not isinstance(value, list):
        raise ValueError("action_species must be a list")
    if required and not value:
        raise ValueError("action_species must be nonempty for generative deep/frontier cognition")
    required_fields = ("preconditions", "consumes", "mutates", "trace", "unlocks")
    for action in value:
        if not isinstance(action, dict):
            raise ValueError("each action species must be an object")
        _text(action.get("id"), "action species id")
        for field in required_fields:
            _text_list(action.get(field), "action species " + field)
    _unique_ids(value, "action species")
    return value


def validate_open_variables(value):
    if not isinstance(value, list):
        raise ValueError("open_variables must be a list")
    for item in value:
        if not isinstance(item, dict):
            raise ValueError("each open variable must be an object")
        _text(item.get("id"), "open variable id")
        if "status" in item:
            _text(item.get("status"), "open variable status")
        if "alternatives" in item and not isinstance(item.get("alternatives"), list):
            raise ValueError("open variable alternatives must be a list")
    _unique_ids(value, "open variable")
    return value


def validate_visibility_partitions(value):
    if not isinstance(value, list):
        raise ValueError("visibility_partitions must be a list")
    for item in value:
        if not isinstance(item, dict):
            raise ValueError("each visibility partition must be an object")
        _text(item.get("id"), "visibility partition id")
        visible = item.get("visible", ["*"])
        hidden = item.get("hidden", [])
        redact = item.get("redact_literals", [])
        _text_list(visible, "visibility partition visible")
        _text_list(hidden, "visibility partition hidden")
        _text_list(redact, "visibility partition redact_literals")
    _unique_ids(value, "visibility partition")
    return value


def validate_trigger_condition(condition):
    if not isinstance(condition, dict):
        raise ValueError("artifact trigger condition must be an object")
    _finite_json(condition, "artifact trigger condition")
    kind = _text(condition.get("type"), "artifact trigger condition type")
    if kind in {"answer_contains", "answer_equals"}:
        _text(condition.get("value"), "artifact trigger condition value")
    elif kind == "answer_regex":
        pattern = _text(condition.get("pattern"), "artifact trigger regex pattern")
        if len(pattern) > 256:
            raise ValueError("artifact trigger regex pattern is too long")
        # Python's backtracking regex engine has no native execution timeout.
        # Keep trigger regexes in a deliberately conservative bounded subset:
        # no unbounded repetition, counted repetition, lookaround, or backrefs.
        if any(token in pattern for token in ("*", "+", "{", "(?")) or re.search(r"\\[1-9]", pattern):
            raise ValueError("artifact trigger regex uses an unbounded construct; use contains/equals or a bounded regex")
        try:
            re.compile(pattern)
        except re.error as exc:
            raise ValueError("artifact trigger regex is invalid") from exc
    elif kind == "field_present":
        path = condition.get("path")
        if (not isinstance(path, list) or not path or
                any(not (type(x) is str or (type(x) is int and x >= 0)) for x in path)):
            raise ValueError("artifact trigger field_present path must use nonempty string keys or nonnegative integer indices")
    elif kind == "field_equals":
        path = condition.get("path")
        if (not isinstance(path, list) or not path or
                any(not (type(x) is str or (type(x) is int and x >= 0)) for x in path)):
            raise ValueError("artifact trigger field_equals path must use nonempty string keys or nonnegative integer indices")
        if "value" not in condition:
            raise ValueError("artifact trigger field_equals needs value")
    elif kind == "always":
        pass
    else:
        raise ValueError("unsupported artifact trigger condition type: " + kind)
    return condition


def validate_artifact_triggers(value):
    if not isinstance(value, list):
        raise ValueError("artifact_triggers must be a list")
    for item in value:
        if not isinstance(item, dict):
            raise ValueError("each artifact trigger must be an object")
        _text(item.get("id"), "artifact trigger id")
        _text(item.get("when"), "artifact trigger when")
        _text(item.get("spawn"), "artifact trigger spawn")
        if "condition" in item:
            validate_trigger_condition(item["condition"])
    _unique_ids(value, "artifact trigger")
    return value


def validate_kernel_shape(value):
    if not isinstance(value, dict):
        raise ValueError("kernel_shape must be an object")
    _text(value.get("representation"), "kernel_shape representation")
    if "reason" in value and value["reason"] is not None:
        _text(value["reason"], "kernel_shape reason")
    return value


def validate_step_references(payload):
    """Validate only references a step actually chooses to bind.

    Declaring a language unit, action species, trigger, or visibility partition
    does not force the current epoch to consume it. That keeps the generative
    vocabulary open across epochs while still rejecting dangling references.
    """
    wl = payload.get("world_language") or {}
    language_ids = {x["id"] for x in wl.get("units", []) if isinstance(x, dict) and isinstance(x.get("id"), str)}
    trigger_ids = {x["id"] for x in payload.get("artifact_triggers", []) if isinstance(x, dict) and isinstance(x.get("id"), str)}
    action_ids = {x["id"] for x in payload.get("action_species", []) if isinstance(x, dict) and isinstance(x.get("id"), str)}
    scope_ids = {x["id"] for x in payload.get("visibility_partitions", []) if isinstance(x, dict) and isinstance(x.get("id"), str)}
    steps = payload.get("steps", [])
    if not isinstance(steps, list):
        raise ValueError("cognition steps must be a list")
    for step in steps:
        if not isinstance(step, dict):
            raise ValueError("each cognition step must be an object")
        reference_fields = (
            ("language_refs", language_ids, "world_language"),
            ("trigger_refs", trigger_ids, "artifact trigger"),
            ("action_species_ids", action_ids, "action species"),
        )
        for field, known, label in reference_fields:
            refs = step.get(field, []) or []
            if not isinstance(refs, (list, tuple)):
                raise ValueError(field + " must be a list of ids")
            for ref in refs:
                if not isinstance(ref, str) or not ref.strip():
                    raise ValueError(field + " must contain nonempty text ids")
                if ref not in known:
                    raise ValueError("cognition step references unknown " + label + " id: " + ref)
        scope = step.get("visibility_scope")
        if scope is not None and scope not in scope_ids:
            raise ValueError("cognition step references unknown visibility scope: " + str(scope))
    return payload


def merge_generative_world(previous, update):
    """Validate and merge an optional open-set generative-world update.

    Known executable fields receive structural validation. Unknown fields are
    preserved rather than rejected so this state can evolve without a runtime
    vocabulary whitelist. Supplying no update leaves prior state unchanged.
    """
    if update is None:
        return deepcopy(previous) if isinstance(previous, dict) else {}
    if not isinstance(update, dict):
        raise ValueError("generative_world must be an object")
    _finite_json(update, "generative_world")
    merged = deepcopy(previous) if isinstance(previous, dict) else {}
    validators = {
        "world_language": validate_world_language,
        "action_species": validate_action_species,
        "open_variables": validate_open_variables,
        "visibility_partitions": validate_visibility_partitions,
        "artifact_triggers": validate_artifact_triggers,
        "kernel_shape": validate_kernel_shape,
    }
    for key, value in update.items():
        validator = validators.get(key)
        if validator is not None:
            validator(value)
        merged[key] = deepcopy(value)
    return merged


def _read_path(value, path):
    current = value
    for key in path:
        if isinstance(current, dict) and type(key) is str and key in current:
            current = current[key]
        elif isinstance(current, list) and type(key) is int and 0 <= key < len(current):
            current = current[key]
        else:
            raise KeyError(key)
    return current


def evaluate_trigger_condition(spec, material_payload):
    """Evaluate a trigger against the *actual submitted material payload*.

    Descriptive ``when`` text is never treated as executable truth. A trigger
    event can schedule work only when a machine-checkable ``condition`` exists
    and evaluates true here.
    """
    condition = spec.get("condition")
    if condition is None:
        raise ValueError(
            "artifact trigger has descriptive 'when' text but no runtime-checkable condition"
        )
    validate_trigger_condition(condition)
    kind = condition["type"]
    answer = material_payload.get("answer")
    if answer is None:
        answer = material_payload.get("output")
    if kind == "answer_contains":
        return isinstance(answer, str) and condition["value"] in answer
    if kind == "answer_equals":
        return isinstance(answer, str) and answer == condition["value"]
    if kind == "answer_regex":
        if not isinstance(answer, str):
            return False
        if len(answer) > 65536:
            raise ValueError("artifact trigger regex input is too large for bounded evaluation")
        return re.search(condition["pattern"], answer) is not None
    if kind == "field_present":
        try:
            _read_path(material_payload, condition["path"])
            return True
        except KeyError:
            return False
    if kind == "field_equals":
        try:
            actual = _read_path(material_payload, condition["path"])
        except KeyError:
            return False
        return json.dumps(actual, sort_keys=True, ensure_ascii=False, allow_nan=False) == json.dumps(
            condition["value"], sort_keys=True, ensure_ascii=False, allow_nan=False
        )
    if kind == "always":
        return True
    return False


def partition_for(generative_world, scope_id):
    if scope_id is None:
        return None
    parts = generative_world.get("visibility_partitions", []) if isinstance(generative_world, dict) else []
    for part in parts:
        if isinstance(part, dict) and part.get("id") == scope_id:
            return deepcopy(part)
    raise ValueError("unknown visibility_scope at dispatch: " + str(scope_id))
