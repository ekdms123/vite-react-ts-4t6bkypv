from __future__ import annotations

"""Runtime policy validation for JIGAEWOL.

The validator is intentionally thin.  It checks executable structure and
provenance bindings, not whether a host has produced impressive-looking prose.
"""

from copy import deepcopy
import math
from jigaewol_runtime.cognition.epoch import route_pressure, validate_routes, normalize_tool_batches

_DEFAULT_POLICY = {
    "dynamic_program_required": True,
    "observation_recompile_mode": "batched_delta",
    "tool_interposition_mode": "every_turn_when_host_supports_it",
    "route_space_mode": "task_native_open_set",
    "search_lineage_mode": "observation_parented",
    "verification_mode": "thin_truth_membrane",
    "external_component_mode": "content_pinned_executable_when_capability_exists",
}


def _as_dict(value):
    return value if isinstance(value, dict) else {}


def runtime_policy(external=None):
    policy = deepcopy(_DEFAULT_POLICY)
    if isinstance(external, dict):
        manifest = external.get("manifest", external)
        if isinstance(manifest, dict):
            policy.update(_as_dict(manifest.get("runtime_policy")))
    return policy


def compiled_kernel_packet(external, *, domain="general", depth_class="standard"):
    manifest = None
    source_sha256 = None
    source = "bundled"
    if isinstance(external, dict):
        manifest = external.get("manifest") if isinstance(external.get("manifest"), dict) else external
        source_sha256 = external.get("source_sha256")
        source = external.get("source", source)
    return {
        "version": 10,
        "domain_hint": str(domain),
        "depth_class": str(depth_class),
        "runtime_policy": runtime_policy(external),
        "manifest": deepcopy(manifest) if isinstance(manifest, dict) else None,
        "source": source,
        "source_sha256": source_sha256,
        "active_operators": deepcopy((manifest or {}).get("operators", [])) if isinstance(manifest, dict) else [],
    }


def _validate_step(step):
    if not isinstance(step, dict):
        raise ValueError("every cognition step must be an object")
    op = str(step.get("operation", "")).strip()
    if not op:
        raise ValueError("cognition step operation must be nonempty")
    if op in {"chat.respond", "material.realize", "creative.realize", "code.realize", "deliver", "closure.check"}:
        raise ValueError("delivery/closure is owned by the runtime, not cognition steps")
    params = step.get("parameters", {})
    if params is not None and not isinstance(params, dict):
        raise ValueError("cognition step parameters must be an object")
    for key in ("operator_ids", "language_refs", "trigger_refs", "action_species_ids"):
        if key in step and (not isinstance(step[key], list) or any(not isinstance(x, str) or not x.strip() for x in step[key])):
            raise ValueError(f"cognition step {key} must be a list of nonempty ids")
    if "expected_gain" in step:
        eg = step["expected_gain"]
        fields = ("information_gain", "action_space_gain", "interaction_cost", "compute_cost")
        if not isinstance(eg, dict):
            raise ValueError("expected_gain must be an object")
        for key in fields:
            value = eg.get(key, 0.0)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                raise ValueError("expected_gain gain/cost fields must be finite numbers")
            if float(value) < 0.0:
                raise ValueError("expected_gain gain/cost fields must be nonnegative")
    return step


def validate_cognitive_program(payload, kernel_packet=None):
    if not isinstance(payload, dict):
        raise ValueError("cognition.compile result must be an object")
    frame = payload.get("frame", {})
    if frame is not None and not isinstance(frame, dict):
        raise ValueError("cognition frame must be an object when supplied")
    raw_steps = payload.get("steps", [])
    if not isinstance(raw_steps, list):
        raise ValueError("cognition steps must be a list")
    steps = [_validate_step(x) for x in raw_steps]

    depth = str((kernel_packet or {}).get("depth_class", "standard"))
    task_model = payload.get("task_model") if isinstance(payload.get("task_model"), dict) else {}
    pressure = route_pressure(depth_class=depth, task_model=task_model, open_variables=payload.get("open_variables", []))
    routes = validate_routes(payload.get("route_candidates", []))
    # External operator contracts count only if an executable step binds them.
    known = {str(x.get("id")) for x in (kernel_packet or {}).get("active_operators", []) if isinstance(x, dict) and x.get("id")}
    selected = payload.get("selected_operator_ids", []) or []
    if not isinstance(selected, list) or any(not isinstance(x, str) or not x.strip() for x in selected):
        raise ValueError("selected_operator_ids must be a list of ids")
    unknown = set(selected) - known
    if unknown:
        raise ValueError("cognition selected unknown external operators: " + ",".join(sorted(unknown)))
    bound = {oid for step in steps for oid in step.get("operator_ids", [])}
    missing = set(selected) - bound
    if missing:
        raise ValueError("selected external operators must bind to executable steps")

    out = deepcopy(payload)
    out["frame"] = deepcopy(frame or {})
    out["route_candidates"] = routes
    out["steps"] = normalize_tool_batches(steps)
    out["route_pressure"] = pressure
    # Identity statements are ordinary revisable cognition output. They may be
    # inspected like any other field but are not rejected merely for changing the
    # runtime's current self-representation.
    return out


def should_recompile_after_tool(kernel_packet, node_parameters):
    """Compatibility shim: JIGAEWOL no longer full-recompiles after each tool.

    Callers should use ``cognition.impact.observation_policy`` and schedule one
    ``cognition.delta`` after the relevant observation batch.
    """
    return False
