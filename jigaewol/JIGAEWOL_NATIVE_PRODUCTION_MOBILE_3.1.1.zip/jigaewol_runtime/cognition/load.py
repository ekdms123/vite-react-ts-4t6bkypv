from __future__ import annotations

"""Observable task-load estimation without persona or hype triggers."""

from dataclasses import dataclass
import math
import re

_TOKEN = re.compile(r"[\w가-힣]+", re.UNICODE)


def _tokens(text):
    normalized = str(text or "").replace("_", " ").replace("-", " ")
    return [x.casefold() for x in _TOKEN.findall(normalized) if x.strip()]


@dataclass(frozen=True)
class LoadProfile:
    chars: int
    token_count: int
    unique_ratio: float
    segment_count: int
    question_count: int
    attachment_count: int
    capability_count: int
    structural_pressure: float


def _count(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a nonnegative integer")
    return value


def _tail(count, threshold, *, step, cap):
    """Keep old low-count behavior while preserving signal beyond old hard caps."""
    return min(cap, max(0, count - threshold) * step)


def structural_pressure(message, *, intent_count=1, attachment_count=0, capability_count=0):
    text = str(message or "")
    intent_count = _count(intent_count, "intent_count")
    attachment_count = _count(attachment_count, "attachment_count")
    capability_count = _count(capability_count, "capability_count")
    toks = _tokens(text)
    unique_ratio = (len(set(toks)) / len(toks)) if toks else 0.0
    segment_count = max(1, len([x for x in re.split(r"[\n;]+|(?<=[.!?。！？])\s+", text) if x.strip()]))
    question_count = text.count("?") + text.count("？")
    raw_size = min(1.6, math.log2(max(len(text), 32) / 32) / 3.2)
    size_term = raw_size * min(1.0, 0.12 + unique_ratio * 2.8)

    intent_extra = max(0, intent_count - 1)
    segment_extra = max(0, segment_count - 1)
    attachment_term = 0.0 if attachment_count == 0 else 0.55 + _tail(attachment_count, 1, step=0.05, cap=0.25)
    capability_term = min(capability_count, 4) * 0.10 + _tail(capability_count, 4, step=0.02, cap=0.20)
    pressure = max(0.0,
        size_term
        + min(1.8, intent_extra * 0.22) + _tail(intent_extra, 9, step=0.03, cap=0.30)
        + min(1.2, segment_extra * 0.12) + _tail(segment_extra, 10, step=0.02, cap=0.30)
        + min(1.2, attachment_term + capability_term) + _tail(capability_count, 12, step=0.01, cap=0.12)
        + min(.4, question_count * .05) + _tail(question_count, 8, step=0.01, cap=0.10)
        + min(.4, unique_ratio * .4))
    return LoadProfile(len(text), len(toks), round(unique_ratio, 4), segment_count, question_count,
                       attachment_count, capability_count, round(pressure, 4))
