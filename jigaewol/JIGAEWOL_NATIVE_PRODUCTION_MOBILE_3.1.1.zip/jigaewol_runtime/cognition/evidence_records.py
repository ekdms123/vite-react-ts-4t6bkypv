from __future__ import annotations

"""Typed evidence records with shared provenance and explicit entailment.

The model separates:
- EvidenceEvent: one observation/provenance root.
- EvidenceClaim: a proposition extracted from that event.
- EvidenceAttribution: a typed claim-to-decision-surface binding.

Semantic decomposition never invents evidential independence: claims from one event
share the event's provenance_root unless an independent observation is created.
"""

from dataclasses import dataclass, field
from typing import Any, Mapping
import hashlib
import json
import math


def _clamp01(value: float) -> float:
    if isinstance(value, bool):
        raise ValueError("evidence strength/confidence must be a finite number")
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("evidence strength/confidence must be a finite number") from exc
    if not math.isfinite(number):
        raise ValueError("evidence strength/confidence must be a finite number")
    return max(0.0, min(1.0, number))


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


@dataclass(frozen=True)
class EvidenceEvent:
    event_id: str
    source_kind: str
    source_ref: str | None = None
    provenance_root: str | None = None
    minimal_provenance_hash: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.event_id.strip():
            raise ValueError("event_id is required")
        if not self.source_kind.strip():
            raise ValueError("source_kind is required")
        object.__setattr__(self, "provenance_root", self.provenance_root or self.event_id)

    @staticmethod
    def provenance_hash(payload: Any) -> str:
        return hashlib.sha256(_canonical(payload)).hexdigest()


@dataclass(frozen=True)
class EntailmentLink:
    from_claim_id: str
    relation_type: str = "defeasible"
    rule_id: str | None = None
    strength: float = 1.0
    context: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        allowed = {"strict", "policy", "definitional", "causal", "defeasible"}
        if self.relation_type not in allowed:
            raise ValueError("unsupported entailment relation_type")
        object.__setattr__(self, "strength", _clamp01(self.strength))


@dataclass(frozen=True)
class EvidenceClaim:
    claim_id: str
    event_id: str
    proposition: Any
    extraction_confidence: float = 1.0
    entailed_by: tuple[EntailmentLink, ...] = ()

    def __post_init__(self):
        if not self.claim_id.strip() or not self.event_id.strip():
            raise ValueError("claim_id and event_id are required")
        object.__setattr__(self, "extraction_confidence", _clamp01(self.extraction_confidence))
        object.__setattr__(self, "entailed_by", tuple(self.entailed_by))


@dataclass(frozen=True)
class EvidenceAttribution:
    attribution_id: str
    claim_id: str
    target_node_id: str
    scope: str
    effect: float
    binding_confidence: float = 1.0
    role: str = "primary"

    def __post_init__(self):
        if not self.attribution_id.strip() or not self.claim_id.strip() or not self.target_node_id.strip():
            raise ValueError("attribution_id, claim_id and target_node_id are required")
        if self.scope not in {"route", "assumption", "goal", "global"}:
            raise ValueError("unsupported attribution scope")
        if isinstance(self.effect, bool):
            raise ValueError("effect must be a finite number between -1 and 1")
        try:
            effect = float(self.effect)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("effect must be a finite number between -1 and 1") from exc
        if not math.isfinite(effect) or effect < -1.0 or effect > 1.0:
            raise ValueError("effect must be a finite number between -1 and 1")
        object.__setattr__(self, "effect", effect)
        if self.role not in {"primary", "consequence", "alternative_hypothesis", "contextual"}:
            raise ValueError("unsupported attribution role")
        object.__setattr__(self, "binding_confidence", _clamp01(self.binding_confidence))


@dataclass(frozen=True)
class EvidenceBundle:
    event: EvidenceEvent
    claims: tuple[EvidenceClaim, ...]
    attributions: tuple[EvidenceAttribution, ...]

    def __post_init__(self):
        claims = tuple(self.claims)
        attrs = tuple(self.attributions)
        object.__setattr__(self, "claims", claims)
        object.__setattr__(self, "attributions", attrs)
        claim_map = {c.claim_id: c for c in claims}
        if len(claim_map) != len(claims):
            raise ValueError("duplicate claim_id")
        for claim in claims:
            if claim.event_id != self.event.event_id:
                raise ValueError("claim event_id must match bundle event")
            for link in claim.entailed_by:
                if link.from_claim_id not in claim_map:
                    raise ValueError("entailment references unknown claim")
        for attr in attrs:
            if attr.claim_id not in claim_map:
                raise ValueError("attribution references unknown claim")

    def graph_delta(self) -> dict[str, Any]:
        """Convert typed attributions into EvidenceGraph evidence rows.

        Every derived evidence row carries the same provenance_root for the source
        event. The graph therefore may propagate each attribution separately while
        aggregating shared-root contributions conservatively rather than treating
        decomposition as independent observations.
        """
        claim_map = {c.claim_id: c for c in self.claims}
        rows = []
        for attr in self.attributions:
            claim = claim_map[attr.claim_id]
            magnitude = abs(float(attr.effect)) * claim.extraction_confidence * attr.binding_confidence
            effect = magnitude if float(attr.effect) >= 0 else -magnitude
            rows.append({
                "id": attr.attribution_id,
                "provenance_root": self.event.provenance_root,
                "source_refs": [self.event.source_ref] if self.event.source_ref else [],
                "scope": attr.scope,
                "targets": [{"node_id": attr.target_node_id, "effect": effect}],
                "content": {
                    "event_id": self.event.event_id,
                    "claim_id": claim.claim_id,
                    "role": attr.role,
                },
            })
        return {"evidence": rows}
