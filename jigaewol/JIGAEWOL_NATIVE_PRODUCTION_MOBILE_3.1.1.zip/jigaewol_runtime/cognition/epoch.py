from __future__ import annotations

"""Compact adaptive cognition epochs.

JIGAEWOL does not equate more named stages with better reasoning.  A semantic
*epoch* is one host inference that must expose only the parts that can change
execution: a working frame, materially distinct route candidates, unresolved
switch points, executable steps, and a stop condition.  Tool observations are
batched when possible and return through a delta epoch rather than restarting
the entire cognition program after every result.
"""

from copy import deepcopy
import hashlib
import json
import math
import re

_TOKEN = re.compile(r"[\w가-힣]+", re.UNICODE)


def _tokens(value):
    return {x.casefold() for x in _TOKEN.findall(str(value or "")) if x.strip()}


def _jaccard(a, b):
    aa, bb = _tokens(a), _tokens(b)
    if not aa or not bb:
        return 1.0 if aa == bb else 0.0
    return len(aa & bb) / len(aa | bb)


def _finite_metric(value, default=0.0):
    if isinstance(value, bool):
        return default
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    return number if math.isfinite(number) else default


def route_pressure(*, depth_class: str, task_model: dict | None = None, open_variables=()) -> dict:
    """Expose route-relevant signals without collapsing them into a route gate.

    Missing ambiguity is represented as unknown rather than fabricated certainty.
    Other absent leverage signals remain neutral zeros because they describe
    requested pressure, where absence itself is a usable zero-pressure signal.
    """
    tm = task_model or {}
    ambiguity_supplied = "ambiguity" in tm
    ambiguity = _finite_metric(tm.get("ambiguity"), None) if ambiguity_supplied else None
    if ambiguity is None:
        ambiguity_basis = "pending_semantic_task_model"
    else:
        ambiguity_basis = "semantic_task_model"
    return {
        "signals": {
            "novelty_target": _finite_metric(tm.get("novelty_target", 0)),
            "ambiguity": ambiguity,
            "ambiguity_basis": ambiguity_basis,
            "research_value": _finite_metric(tm.get("research_value", 0)),
            "structural_pressure": _finite_metric(tm.get("structural_pressure", 0)),
            "exploration_leverage": _finite_metric(tm.get("exploration_leverage", tm.get("breadth_target", 0))),
            "intent_fidelity": _finite_metric(tm.get("intent_fidelity", 0)),
            "reasoning_intensity": _finite_metric(tm.get("reasoning_intensity", tm.get("requested_intensity", 0))),
        },
        "open_switch_points": len(tuple(open_variables or ())),
        "semantic_ceiling": None,
        "expansion_rule": "routes are runtime-owned working state and may be created, revised, merged or discarded freely",
    }

def validate_routes(routes):
    """Normalize an open-set route collection without imposing a route ontology.

    A route is any substantive object the runtime wants to keep as a distinct
    working alternative. Known fields are preserved when present, but no fixed
    representation/next_action/falsifier tuple is required. Exact duplicate
    content is collapsed without using lexical-similarity thresholds.
    """
    if routes is None:
        routes = []
    if not isinstance(routes, list):
        raise ValueError("route_candidates must be a list")
    normalized = []
    signatures = set()
    for idx, row in enumerate(routes):
        if not isinstance(row, dict):
            raise ValueError("route candidate must be an object")
        item = deepcopy(row)
        rid = str(item.get("id", "")).strip()
        substantive = {k: v for k, v in item.items() if k != "id" and v not in (None, "", [], {})}
        if not substantive:
            raise ValueError("route candidate needs substantive working state")
        canonical = json.dumps(substantive, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
        sig = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        if sig in signatures:
            continue
        signatures.add(sig)
        if not rid:
            rid = "route_" + hashlib.sha256((canonical + "\x1f" + str(idx)).encode("utf-8")).hexdigest()[:12]
        item["id"] = rid
        normalized.append(item)
    return normalized


def normalize_tool_batches(steps):
    """Annotate sibling tool steps that can be executed before one delta join.

    The host may set ``parallel_group`` explicitly.  Search/file/repository
    siblings with the same non-empty group are safe to batch; the runtime keeps
    deterministic state writes by submitting results sequentially afterwards.
    """
    out = []
    for step in steps or ():
        item = deepcopy(step)
        params = dict(item.get("parameters", {}) or {})
        group = str(item.pop("parallel_group", params.pop("parallel_group", "")) or "").strip()
        if group:
            params["_jigaewol_parallel_safe"] = True
            params["_jigaewol_parallel_group"] = group
            params["_jigaewol_delta_join_planned"] = True
        item["parameters"] = params
        out.append(item)
    return out


def delta_instruction() -> str:
    return (
        "Integrate the new observed result refs with the current decision state. "
        "Any frame, route, representation or prior decision may be retained, revised, replaced or reopened as the runtime forms the next work state. "
        "When a claimed change is caused by specific observations, bind those observations by exact refs. "
        "Return the decision delta, any new executable steps, evidence state, and any new frame or representation that is useful."
    )
