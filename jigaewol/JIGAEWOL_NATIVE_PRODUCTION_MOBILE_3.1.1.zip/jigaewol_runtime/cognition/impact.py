from __future__ import annotations

"""Observation batching and delta-recompile policy."""

from copy import deepcopy


def observation_policy(node_parameters, *, is_search=False, is_repository=False):
    params = dict(node_parameters or {})
    explicit = str(params.get("observation_policy", "")).strip().casefold()
    if explicit in {"none", "delta", "frame"}:
        return explicit
    if params.get("jigaewol_external_kernel") or params.get("method_job") or params.get("feedback_job"):
        return "none"
    if is_search or is_repository:
        return "delta"
    # Connected HOST capabilities are observations, not terminal side effects.
    # Unless a caller explicitly opts out (or the operation is an internal
    # housekeeping job above), feed the real result back through cognition so
    # the next action can change because of what actually happened.
    return "delta"


def add_pending_observation(runtime_extensions, *, source_ref, result_sha256, operation, policy, group=None):
    out = runtime_extensions.setdefault("pending_observation_deltas", [])
    row = {
        "source_ref": str(source_ref),
        "result_sha256": str(result_sha256),
        "operation": str(operation),
        "policy": str(policy),
        "group": str(group or ""),
    }
    if row not in out:
        out.append(row)
    return row


def consume_pending_observations(runtime_extensions, *, group=None, source_refs=None):
    """Consume only the observations owned by one delta epoch.

    Unrelated pending observations stay queued so parallel or nested tool flows
    cannot steal each other's evidence.
    """
    rows = deepcopy(runtime_extensions.get("pending_observation_deltas", []) or [])
    wanted_refs = {str(x) for x in (source_refs or []) if str(x)}
    take, keep = [], []
    for row in rows:
        by_group = group is not None and str(row.get("group", "")) == str(group)
        by_ref = bool(wanted_refs) and str(row.get("source_ref", "")) in wanted_refs
        selected = by_group or by_ref if (group is not None or wanted_refs) else True
        (take if selected else keep).append(row)
    runtime_extensions["pending_observation_deltas"] = keep
    return take
