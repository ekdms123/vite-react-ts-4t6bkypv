from __future__ import annotations

"""Content-pinned external component bridge.

Packaged snapshots make portable operation deterministic.  GitHub copies can be
refreshed and hash-verified.  ``python_method`` components contain executable,
restricted data-computation code; semantic contracts remain available only for
mechanisms whose substance must be supplied by the host model.
"""

from copy import deepcopy
import hashlib
import json
import pkgutil


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def _text_list(value, label):
    if not isinstance(value, list) or not value or any(not isinstance(x, str) or not x.strip() for x in value):
        raise ValueError(label + " must be a nonempty text list")
    return [x.strip() for x in value]


def _descriptor_map(manifest):
    if not isinstance(manifest, dict):
        raise ValueError("kernel manifest must be an object")
    rows = manifest.get("external_components", [])
    if not isinstance(rows, list):
        raise ValueError("kernel external_components must be a list")
    out = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("each external component descriptor must be an object")
        oid = _text(row.get("id"), "external component descriptor id")
        if oid in out:
            raise ValueError("duplicate external component descriptor id: " + oid)
        out[oid] = deepcopy(row)
    return out


def _load_packaged_text(descriptor):
    if not isinstance(descriptor, dict):
        raise ValueError("external component descriptor must be an object")
    name = _text(descriptor.get("path"), "external component descriptor path").rsplit("/", 1)[-1]
    raw = pkgutil.get_data("jigaewol_runtime.cognition", "components/" + name)
    if raw is None:
        raise ValueError("packaged external component is missing: " + name)
    actual = hashlib.sha256(raw).hexdigest()
    expected = _text(descriptor.get("sha256"), "external component descriptor sha256").lower()
    if len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected):
        raise ValueError("external component descriptor sha256 must be 64 hex")
    if actual != expected:
        raise ValueError(f"packaged component hash mismatch for {descriptor.get('id')}: {actual} != {expected}")
    return raw.decode("utf-8")


def component_binding_manifest(descriptor, source_text):
    if not isinstance(descriptor, dict):
        raise ValueError("external component descriptor must be an object")
    if not isinstance(source_text, str):
        raise ValueError("external component source must be UTF-8 text")
    actual = hashlib.sha256(source_text.encode("utf-8")).hexdigest()
    expected = _text(descriptor.get("sha256"), "external component descriptor sha256").lower()
    if len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected):
        raise ValueError("external component descriptor sha256 must be 64 hex")
    if actual != expected:
        raise ValueError("external component content does not match its pinned sha256")
    try:
        doc = json.loads(source_text)
    except json.JSONDecodeError as exc:
        raise ValueError("external component must be a JSON manifest") from exc
    if not isinstance(doc, dict):
        raise ValueError("external component manifest must be an object")
    oid = _text(descriptor.get("id"), "external component descriptor id")
    kind = _text(descriptor.get("kind", "semantic_contract"), "external component descriptor kind")
    doc_id = _text(doc.get("id"), "external component id")
    if doc_id != oid:
        raise ValueError("external component id differs from kernel descriptor")
    if _text(doc.get("kind"), "external component kind") != kind:
        raise ValueError("external component kind differs from kernel descriptor")
    effects = deepcopy(doc.get("effect_contract", {}))
    if not isinstance(effects, dict):
        raise ValueError("external component effect_contract must be an object")
    produces = effects.get("produces") or effects.get("unlocks") or effects.get("mutates") or effects.get("trace")
    effects["produces"] = _text_list(produces, "external component effect products")
    repository = _text(descriptor.get("repository_full_name"), "external component repository_full_name")
    path = _text(descriptor.get("path"), "external component path")
    ref = _text(descriptor.get("ref", "main"), "external component ref")
    version = _text(doc.get("version", "1.0.0"), "external component version")
    purpose = _text(doc.get("purpose", descriptor.get("purpose", "external cognition mechanism")), "external component purpose")
    applicability = _text_list(doc.get("applicability", ["*"]), "external component applicability")
    origin_ref = f"{repository}@{ref}:{path}"
    binding = {
        "id": oid,
        "version": version,
        "kind": kind,
        "purpose": purpose,
        "applicability": applicability,
        "effect_contract": effects,
        "origin": {
            "kind": "repository", "ref": origin_ref, "source_sha256": expected,
            "repository_full_name": repository, "path": path, "ref_name": ref,
        },
    }
    if kind == "semantic_contract":
        binding["instruction"] = _text(doc.get("instruction"), "semantic component instruction")
    elif kind == "python_method":
        method = doc.get("method")
        if not isinstance(method, dict):
            raise ValueError("python_method component needs a method object")
        binding["method"] = deepcopy(method)
    elif kind == "capability":
        binding["capability_id"] = _text(doc.get("capability_id"), "capability component capability_id")
        defaults = doc.get("default_parameters", {})
        if not isinstance(defaults, dict):
            raise ValueError("capability component default_parameters must be an object")
        binding["default_parameters"] = deepcopy(defaults)
    else:
        # Preserve an unknown component ontology instead of collapsing it to
        # unsupported. A generated adapter may later bind its executable meaning.
        binding["adapter_state"] = "open_set_pending_adapter"
        binding["component_payload"] = deepcopy(doc.get("component_payload") or doc.get("payload") or {})
        if not isinstance(binding["component_payload"], dict):
            binding["component_payload"] = {"value": binding["component_payload"]}
    return binding


def bootstrap_packaged_components(integrations, kernel_manifest):
    reports = []
    for descriptor in _descriptor_map(kernel_manifest).values():
        text = _load_packaged_text(descriptor)
        binding = component_binding_manifest(descriptor, text)
        checked = integrations.install(binding, observed_source=text)
        reports.append({
            "id": checked["id"], "kind": checked["kind"],
            "source_sha256": descriptor["sha256"], "manifest_sha256": checked["manifest_sha256"],
            "state": "installed_from_content_pinned_packaged_snapshot",
            "remote_ref": checked["origin"]["ref"],
        })
    return reports


def remote_fetch_plan(kernel_manifest, *, only_ids=()):
    if isinstance(only_ids, str) or not isinstance(only_ids, (list, tuple, set, frozenset)):
        raise ValueError("only_ids must be a collection of external component ids")
    if any(not isinstance(x, str) or not x.strip() for x in only_ids):
        raise ValueError("only_ids must contain nonempty text ids")
    wanted = {x.strip() for x in only_ids}
    out = []
    for descriptor in _descriptor_map(kernel_manifest).values():
        if wanted and descriptor["id"] not in wanted:
            continue
        out.append({
            "id": descriptor["id"], "action": "fetch_file",
            "args": {"repository_full_name": descriptor["repository_full_name"], "path": descriptor["path"],
                     "ref": descriptor.get("ref", "main"), "encoding": "utf-8"},
            "expected_sha256": descriptor["sha256"],
        })
    return out


def extract_fetched_text(value):
    if isinstance(value, str):
        return value
    if not isinstance(value, dict):
        raise ValueError("external component fetch did not return text")
    for key in ("content", "text", "body", "output"):
        if key in value:
            item = value[key]
            if isinstance(item, str):
                return item
            if isinstance(item, dict):
                try:
                    return extract_fetched_text(item)
                except ValueError:
                    pass
    result = value.get("result")
    if isinstance(result, dict):
        return extract_fetched_text(result)
    raise ValueError("external component fetch result has no UTF-8 content")


def verify_remote_component(kernel_manifest, component_id, fetched_text):
    descriptors = _descriptor_map(kernel_manifest)
    if component_id not in descriptors:
        raise KeyError(component_id)
    descriptor = descriptors[component_id]
    return descriptor, component_binding_manifest(descriptor, fetched_text)
