from __future__ import annotations

"""Evidence propagation graph for decision-surface updates.

The graph keeps evidence *scope* separate from evidence *priority*.

- The evidence allocator may decide which probe is worth observing first.
- This module decides where an observed piece of evidence is allowed to matter.
- Cycles are not broken by mutating edge weights. Strongly-connected components
  are detected for diagnostics and the propagation itself uses a monotone,
  provenance-deduplicated fixed point: one evidence item may contribute at most
  once to a node, using the strongest reachable effect for that node.

This prevents route-local failures from silently becoming goal-level failures,
while still allowing evidence that directly targets a shared assumption to
reach every decision surface that explicitly depends on that assumption.
"""

from copy import deepcopy
import hashlib
import json
import math
from math import prod


_NODE_KINDS = {"goal", "route", "assumption", "decision"}
_SCOPES = {"route", "assumption", "goal", "global"}
_RELATIONS = {"depends_on", "supports", "requires"}

# Route-local evidence is intentionally unable to mutate shared assumptions or
# source-grounded goals. If an observation truly bears on a shared assumption,
# the semantic delta must target that assumption directly.
_SCOPE_ALLOWED_KINDS = {
    "route": {"route", "decision"},
    "assumption": {"assumption", "route", "decision", "goal"},
    "goal": {"goal"},
    "global": set(_NODE_KINDS),
}


def _clamp(value, low=0.0, high=1.0):
    if isinstance(value, bool):
        return low
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return low
    if not math.isfinite(number):
        return low
    return max(low, min(high, number))


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _edge_id(src, dst, relation):
    raw = f"{src}\x1f{dst}\x1f{relation}".encode("utf-8")
    return "edge_" + hashlib.sha256(raw).hexdigest()[:16]


def empty_evidence_graph():
    return {
        "version": 1,
        "nodes": {},
        "edges": [],
        "evidence": {},
        "node_evidence": {},
        "components": [],
        "component_of": {},
        "propagation_receipts": [],
    }


def _node(node_id, kind, **extra):
    row = {"id": str(node_id), "kind": str(kind), "state": "open"}
    row.update({k: deepcopy(v) for k, v in extra.items() if v is not None})
    return row


def _normalize_node(row):
    if not isinstance(row, dict):
        raise ValueError("evidence graph node must be an object")
    node_id = str(row.get("id", "")).strip()
    kind = str(row.get("kind", "")).strip()
    if not node_id:
        raise ValueError("evidence graph node id is required")
    if kind not in _NODE_KINDS:
        raise ValueError("unsupported evidence graph node kind: " + kind)
    out = deepcopy(row)
    out["id"] = node_id
    out["kind"] = kind
    out.setdefault("state", "open")
    if "source_grounded" in out:
        if not isinstance(out["source_grounded"], bool):
            raise ValueError("source_grounded must be boolean")
    return out


def _normalize_edge(row, known_nodes):
    if not isinstance(row, dict):
        raise ValueError("evidence graph edge must be an object")
    src = str(row.get("from", "")).strip()
    dst = str(row.get("to", "")).strip()
    relation = str(row.get("relation", "depends_on")).strip() or "depends_on"
    if src not in known_nodes or dst not in known_nodes:
        raise ValueError("evidence graph edge references an unknown node")
    if relation not in _RELATIONS:
        raise ValueError("unsupported evidence graph relation: " + relation)
    strength = _clamp(row.get("dependency_strength", row.get("transmission", 1.0)))
    out = deepcopy(row)
    out.update({
        "id": str(row.get("id") or _edge_id(src, dst, relation)),
        "from": src,
        "to": dst,
        "relation": relation,
        "dependency_strength": strength,
    })
    # "transmission" is retained only as a compatibility/readability alias.
    out["transmission"] = strength
    return out


def build_evidence_graph(*, goal_nodes=(), route_candidates=(), decision_graph=None):
    """Build a typed decision graph from source-grounded goals and live routes."""
    graph = empty_evidence_graph()

    for item in goal_nodes or ():
        if isinstance(item, dict):
            gid = str(item.get("id") or item.get("goal_id") or "").strip()
            label = item.get("meaning") or item.get("label")
        else:
            gid = str(item).strip()
            label = None
        if not gid:
            continue
        graph["nodes"][gid] = _node(gid, "goal", source_grounded=True, label=label)

    for route in route_candidates or ():
        if not isinstance(route, dict):
            continue
        rid = str(route.get("id", "")).strip()
        if not rid:
            continue
        graph["nodes"][rid] = _node(
            rid, "route",
            label=route.get("representation") or route.get("next_action"),
            source_grounded=False,
        )
        refs = route.get("shared_assumption_refs", route.get("assumption_refs", [])) or []
        if isinstance(refs, str):
            refs = [refs]
        for aid in refs:
            aid = str(aid).strip()
            if not aid:
                continue
            graph["nodes"].setdefault(aid, _node(aid, "assumption", source_grounded=False))
            graph["edges"].append(_normalize_edge({
                "from": aid, "to": rid, "relation": "depends_on",
                "dependency_strength": route.get("dependency_strength", 1.0),
            }, graph["nodes"]))

    declared = decision_graph if isinstance(decision_graph, dict) else {}
    for row in declared.get("nodes", []) or []:
        node = _normalize_node(row)
        existing = graph["nodes"].get(node["id"])
        if existing and existing.get("kind") != node.get("kind"):
            raise ValueError("decision graph redeclared a node with a different kind")
        merged = deepcopy(existing or {})
        merged.update(node)
        graph["nodes"][node["id"]] = merged

    # Declared edges are applied after all nodes are known.
    seen = {x.get("id") for x in graph["edges"]}
    for row in declared.get("edges", []) or []:
        edge = _normalize_edge(row, graph["nodes"])
        if edge["id"] not in seen:
            graph["edges"].append(edge)
            seen.add(edge["id"])

    _refresh_components(graph)
    _refresh_node_states(graph)
    return graph


def _tarjan(nodes, edges):
    adjacency = {node_id: [] for node_id in nodes}
    for edge in edges:
        adjacency.setdefault(edge["from"], []).append(edge["to"])

    index = 0
    stack = []
    on_stack = set()
    indices = {}
    low = {}
    components = []

    def visit(v):
        nonlocal index
        indices[v] = index
        low[v] = index
        index += 1
        stack.append(v)
        on_stack.add(v)
        for w in adjacency.get(v, ()):
            if w not in indices:
                visit(w)
                low[v] = min(low[v], low[w])
            elif w in on_stack:
                low[v] = min(low[v], indices[w])
        if low[v] == indices[v]:
            comp = []
            while True:
                w = stack.pop()
                on_stack.remove(w)
                comp.append(w)
                if w == v:
                    break
            components.append(tuple(sorted(comp)))

    for node_id in sorted(nodes):
        if node_id not in indices:
            visit(node_id)
    return components


def _refresh_components(graph):
    components = _tarjan(graph["nodes"], graph["edges"])
    edge_pairs = {(e["from"], e["to"]) for e in graph["edges"]}
    rows = []
    component_of = {}
    for idx, members in enumerate(components, start=1):
        cid = f"scc_{idx}"
        cyclic = len(members) > 1 or any((m, m) in edge_pairs for m in members)
        rows.append({"id": cid, "members": list(members), "cyclic": cyclic})
        for member in members:
            component_of[member] = cid
    graph["components"] = rows
    graph["component_of"] = component_of


def _prob_union(values):
    vals = [_clamp(abs(v)) for v in values if abs(float(v)) > 0]
    if not vals:
        return 0.0
    return 1.0 - prod(1.0 - v for v in vals)


def _provenance_grouped_strengths(graph, bucket):
    """Conservatively aggregate contributions by immutable provenance root.

    Multiple semantic claims/attributions may originate from one observation.
    They remain separately traceable, but at a single decision node the shared
    observation is not counted as multiple independent evidence sources.
    """
    grouped = {}
    for evidence_id, value in (bucket or {}).items():
        evidence = graph.get("evidence", {}).get(evidence_id, {})
        root = str(evidence.get("provenance_root") or evidence_id)
        grouped[root] = max(grouped.get(root, 0.0), _clamp(abs(value)))
    return grouped.values()


def _refresh_node_states(graph):
    for node_id, node in graph["nodes"].items():
        row = graph["node_evidence"].get(node_id, {})
        supporting = row.get("supporting", {}) if isinstance(row, dict) else {}
        contradicting = row.get("contradicting", {}) if isinstance(row, dict) else {}
        support = _prob_union(_provenance_grouped_strengths(graph, supporting))
        contradiction = _prob_union(_provenance_grouped_strengths(graph, contradicting))
        if support >= 0.2 and contradiction >= 0.2:
            state = "conflicted"
        elif contradiction >= 0.2:
            state = "contradicted"
        elif support >= 0.2:
            state = "supported"
        else:
            state = "open"
        node["state"] = state
        node["support_strength"] = round(support, 6)
        node["contradiction_strength"] = round(contradiction, 6)


def _allowed(scope, node_kind):
    return node_kind in _SCOPE_ALLOWED_KINDS[scope]


def _outgoing(graph):
    out = {node_id: [] for node_id in graph["nodes"]}
    for edge in graph["edges"]:
        out.setdefault(edge["from"], []).append(edge)
    return out


def _normalize_evidence(item, observed_refs):
    if not isinstance(item, dict):
        raise ValueError("evidence graph evidence item must be an object")
    eid = str(item.get("id", "")).strip()
    if not eid:
        raise ValueError("evidence graph evidence id is required")
    refs = [str(x) for x in item.get("source_refs", []) if str(x)]
    if refs and not set(refs) <= set(observed_refs):
        raise ValueError("evidence graph source_refs must name actually observed refs")
    scope = str(item.get("scope", "route")).strip() or "route"
    if scope not in _SCOPES:
        raise ValueError("unsupported evidence scope: " + scope)
    targets = item.get("targets", item.get("direct_targets", [])) or []
    if not isinstance(targets, list) or not targets:
        raise ValueError("evidence graph evidence needs direct targets")
    norm_targets = []
    for target in targets:
        if isinstance(target, str):
            target = {"node_id": target, "effect": item.get("effect")}
        if not isinstance(target, dict):
            raise ValueError("evidence graph target must be an object")
        node_id = str(target.get("node_id", target.get("node", ""))).strip()
        raw_effect = target.get("effect", target.get("strength"))
        if raw_effect is None:
            effect = None
        else:
            if isinstance(raw_effect, bool):
                raise ValueError("evidence graph effect must be a finite number between -1 and 1 or unknown")
            try:
                effect = float(raw_effect)
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError("evidence graph effect must be a finite number between -1 and 1 or unknown") from exc
            if not math.isfinite(effect) or effect < -1 or effect > 1:
                raise ValueError("evidence graph effect must be a finite number between -1 and 1 or unknown")
        norm_targets.append({"node_id": node_id, "effect": effect})
    route_ids = item.get("route_ids", []) or []
    if isinstance(route_ids, str):
        route_ids = [route_ids]
    assumption_refs = item.get("assumption_refs", []) or []
    if isinstance(assumption_refs, str):
        assumption_refs = [assumption_refs]
    if not isinstance(route_ids, list) or any(not isinstance(x, str) or not x.strip() for x in route_ids):
        raise ValueError("route_ids must be text ids")
    if not isinstance(assumption_refs, list) or any(not isinstance(x, str) or not x.strip() for x in assumption_refs):
        raise ValueError("assumption_refs must be text ids")
    conditions = item.get("context_conditions", []) or []
    if not isinstance(conditions, list) or any(not isinstance(x, dict) for x in conditions):
        raise ValueError("context_conditions must be a list of objects")
    if scope == "route" and not route_ids:
        route_ids = [t["node_id"] for t in norm_targets if t["node_id"].startswith("route:")]
    return {
        "id": eid,
        "provenance_root": str(item.get("provenance_root") or eid),
        "source_refs": refs,
        "scope": scope,
        "route_ids": [str(x).strip() for x in route_ids],
        "assumption_refs": [str(x).strip() for x in assumption_refs],
        "context_conditions": deepcopy(conditions),
        "representation_version": str(item.get("representation_version", "")).strip(),
        "failure_kind": str(item.get("failure_kind", "")).strip(),
        "targets": norm_targets,
        "content": deepcopy(item.get("content")),
    }


def _condition_applicability(evidence, evaluation_context):
    """Check conditional evidence against an explicitly supplied runtime context.

    Conditions are exact-match predicates. A list value in the context matches
    when it contains the required value. For backward-compatible evidence that
    predates contextual evaluation, omitting ``evaluation_context`` leaves the
    evidence applicable but records that no contextual check was performed.
    """
    conditions = evidence.get("context_conditions") or []
    version = str(evidence.get("representation_version", "") or "").strip()
    if evaluation_context is None:
        return True, "condition:context_not_supplied_legacy_applicability"
    if not isinstance(evaluation_context, dict):
        return False, "condition:evaluation_context_not_object"
    for clause in conditions:
        for key, required in clause.items():
            actual = evaluation_context.get(key)
            if isinstance(actual, (list, tuple, set)):
                if required not in actual:
                    return False, f"condition:{key}_mismatch"
            elif actual != required:
                return False, f"condition:{key}_mismatch"
    if version:
        actual_version = str(evaluation_context.get("representation_version", "") or "").strip()
        if actual_version and actual_version != version:
            return False, "condition:representation_version_mismatch"
    return True, "condition:matched"


def _scope_allows_evidence(evidence, node_id, node):
    if not _allowed(evidence["scope"], node.get("kind")):
        return False
    if evidence["scope"] != "route":
        return True
    owners = set(evidence.get("route_ids") or ())
    if not owners:
        return True
    kind = node.get("kind")
    if kind == "route":
        return node_id in owners
    if kind == "decision":
        decision_owners = set(node.get("route_ids") or ())
        return not decision_owners or bool(owners & decision_owners)
    return False


def _propagate_one(graph, evidence):
    """Monotone strongest-path propagation with provenance de-duplication."""
    adjacency = _outgoing(graph)
    # strongest[node] is the strongest absolute effect from this evidence that
    # has reached the node. Re-visiting a cycle without improving magnitude is a no-op.
    strongest = {}
    queue = []
    blocked = []

    for target in evidence["targets"]:
        node_id = target["node_id"]
        if node_id not in graph["nodes"]:
            raise ValueError("evidence target references an unknown node: " + node_id)
        node = graph["nodes"][node_id]
        kind = node["kind"]
        if not _scope_allows_evidence(evidence, node_id, node):
            raise ValueError(
                f"{evidence['scope']} evidence cannot directly target {kind} node {node_id} outside its owned route/condition scope"
            )
        if target.get("effect") is None:
            blocked.append({"from": None, "to": node_id, "reason": "effect:unknown"})
            continue
        effect = float(target["effect"])
        prior = strongest.get(node_id)
        if prior is None or abs(effect) > abs(prior):
            strongest[node_id] = effect
            queue.append(node_id)

    cursor = 0
    while cursor < len(queue):
        src = queue[cursor]
        cursor += 1
        src_effect = strongest[src]
        for edge in adjacency.get(src, ()):
            dst = edge["to"]
            dst_node = graph["nodes"][dst]
            dst_kind = dst_node["kind"]
            if not _scope_allows_evidence(evidence, dst, dst_node):
                reason = f"scope:{evidence['scope']}_blocks_{dst_kind}"
                if evidence["scope"] == "route" and evidence.get("route_ids") and dst_kind in {"route", "decision"}:
                    reason = "route_scope:outside_owned_route"
                blocked.append({"from": src, "to": dst, "reason": reason})
                continue
            candidate = src_effect * float(edge["dependency_strength"])
            prior = strongest.get(dst)
            # Strict improvement makes the worklist a monotone fixed point even
            # in SCCs. Equal-strength cycles do not re-enqueue.
            if prior is None or abs(candidate) > abs(prior) + 1e-12:
                strongest[dst] = candidate
                queue.append(dst)

    applied = []
    for node_id, effect in strongest.items():
        ledger = graph["node_evidence"].setdefault(
            node_id, {"supporting": {}, "contradicting": {}}
        )
        bucket = "supporting" if effect >= 0 else "contradicting"
        opposite = "contradicting" if effect >= 0 else "supporting"
        ledger[opposite].pop(evidence["id"], None)
        ledger[bucket][evidence["id"]] = round(abs(effect), 12)
        applied.append({
            "node_id": node_id,
            "effect": round(effect, 12),
            "component_id": graph["component_of"].get(node_id),
        })
    return sorted(applied, key=lambda x: x["node_id"]), blocked


def apply_evidence_graph_delta(graph, delta, *, observed_refs=()):
    """Apply structural and evidence changes, then converge evidence propagation.

    The operation is deterministic and does not delete weak dependency edges.
    ``dependency_strength`` affects how strongly evidence travels across a real
    dependency; it is not a cycle-breaking heuristic.
    """
    current = deepcopy(graph) if isinstance(graph, dict) else empty_evidence_graph()
    current.setdefault("nodes", {})
    current.setdefault("edges", [])
    current.setdefault("evidence", {})
    current.setdefault("node_evidence", {})
    current.setdefault("propagation_receipts", [])

    if not isinstance(delta, dict):
        raise ValueError("evidence_graph_delta must be an object")

    for row in delta.get("nodes", []) or []:
        node = _normalize_node(row)
        existing = current["nodes"].get(node["id"])
        if existing and existing.get("kind") != node["kind"]:
            raise ValueError("evidence graph node kind cannot change implicitly")
        merged = deepcopy(existing or {})
        merged.update(node)
        current["nodes"][node["id"]] = merged

    edge_map = {str(e.get("id")): deepcopy(e) for e in current["edges"] if isinstance(e, dict)}
    for row in delta.get("edges", []) or []:
        edge = _normalize_edge(row, current["nodes"])
        edge_map[edge["id"]] = edge
    current["edges"] = sorted(edge_map.values(), key=lambda x: x["id"])

    _refresh_components(current)

    receipts = []
    for raw in delta.get("evidence", []) or []:
        evidence = _normalize_evidence(raw, observed_refs)
        # Evidence ids are immutable provenance identities. Re-submission with
        # different content is rejected rather than silently rewriting history.
        existing = current["evidence"].get(evidence["id"])
        if existing is not None and _canonical(existing) != _canonical(evidence):
            raise ValueError("evidence id was already bound to different provenance/content")
        current["evidence"][evidence["id"]] = deepcopy(evidence)
        applicable, condition_reason = _condition_applicability(evidence, delta.get("evaluation_context"))
        if applicable:
            applied, blocked = _propagate_one(current, evidence)
        else:
            applied, blocked = [], [{
                "from": None, "to": None, "reason": condition_reason,
            }]
        receipts.append({
            "evidence_id": evidence["id"],
            "scope": evidence["scope"],
            "condition_applicable": bool(applicable),
            "condition_evaluation": condition_reason,
            "applied": applied,
            "blocked": blocked,
            "converged": True,
        })

    _refresh_node_states(current)
    current["propagation_receipts"].extend(deepcopy(receipts))

    goal_impacts = []
    for node_id, node in current["nodes"].items():
        if node.get("kind") == "goal":
            goal_impacts.append({
                "node_id": node_id,
                "state": node.get("state"),
                "support_strength": node.get("support_strength", 0.0),
                "contradiction_strength": node.get("contradiction_strength", 0.0),
                # This is permission to revise the *decision surface*, never to
                # overwrite the user's source-grounded goal text.
                "surface_update_eligible": node.get("state") in {"contradicted", "conflicted"},
                "source_grounded_goal_text_preserved": node.get("source_grounded", False) is True,
            })

    return current, {
        "evidence_count": len(delta.get("evidence", []) or []),
        "component_count": len(current.get("components", [])),
        "cyclic_components": [
            x["id"] for x in current.get("components", []) if x.get("cyclic")
        ],
        "goal_impacts": goal_impacts,
        "converged": True,
    }


def graph_summary(graph):
    graph = graph if isinstance(graph, dict) else empty_evidence_graph()
    return {
        "version": graph.get("version", 1),
        "nodes": [
            {
                "id": n.get("id"),
                "kind": n.get("kind"),
                "state": n.get("state", "open"),
                "support_strength": n.get("support_strength", 0.0),
                "contradiction_strength": n.get("contradiction_strength", 0.0),
                "source_grounded": n.get("source_grounded", False) is True,
                "component_id": graph.get("component_of", {}).get(n.get("id")),
            }
            for n in graph.get("nodes", {}).values()
        ],
        "edges": deepcopy(graph.get("edges", [])),
        "components": deepcopy(graph.get("components", [])),
    }
