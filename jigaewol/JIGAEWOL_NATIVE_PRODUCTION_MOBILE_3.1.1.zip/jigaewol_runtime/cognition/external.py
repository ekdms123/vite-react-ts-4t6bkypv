from __future__ import annotations

"""Versioned external kernel support.

The GitHub kernel is a compact control overlay, not a persona or hidden model
replacement.  Remote bytes are content-addressed and remain distinguishable
from the effective merged manifest.
"""

from copy import deepcopy
from pathlib import Path
import hashlib
import json
import pkgutil
import time

DEFAULT_REPOSITORY = "ekdms123/fhvs"
DEFAULT_PATH = "jigaewol/kernel.json"
DEFAULT_REF = "main"
# Filled by release tooling after the canonical GitHub kernel is generated.
DEFAULT_EXPECTED_SHA256 = "336ddb5a56d7037090d90f61ecefde994e970cb14ea494476864edfb9c3bfb2c"

_NATIVE_COMPONENT_KINDS = {"semantic_contract", "python_method", "capability"}


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def manifest_sha256(manifest) -> str:
    value = deepcopy(manifest)
    if isinstance(value, dict):
        value.pop("manifest_sha256", None)
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _extract_content(value):
    if isinstance(value, str):
        return value
    if not isinstance(value, dict):
        raise ValueError("external kernel fetch did not return text or an object")
    for key in ("content", "text", "body", "output"):
        if key in value:
            item = value[key]
            if isinstance(item, str):
                return item
            if isinstance(item, dict):
                try:
                    return _extract_content(item)
                except ValueError:
                    pass
    result = value.get("result")
    if isinstance(result, dict):
        return _extract_content(result)
    raise ValueError("external kernel fetch result has no UTF-8 content")


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def _text_list(value, label):
    if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
        raise ValueError(label + " must be a text list")
    return value


def validate_manifest(value):
    if not isinstance(value, dict):
        raise ValueError("external kernel manifest must be a JSON object")
    schema_version = value.get("schema_version")
    if isinstance(schema_version, bool) or not isinstance(schema_version, int) or schema_version != 10:
        raise ValueError("JIGAEWOL kernel schema_version must be integer 10")
    _text(value.get("kernel_id"), "kernel_id")
    _text(value.get("compiler_directive"), "compiler_directive")
    _text_list(value.get("principles", []), "principles")
    policy = value.get("runtime_policy", {})
    if not isinstance(policy, dict):
        raise ValueError("runtime_policy must be an object")
    for key in (
        "observation_recompile_mode", "tool_interposition_mode",
        "route_space_mode", "search_lineage_mode", "verification_mode", "external_component_mode",
    ):
        if key in policy:
            _text(policy[key], "runtime_policy." + key)
    if "dynamic_program_required" in policy and type(policy["dynamic_program_required"]) is not bool:
        raise ValueError("runtime_policy.dynamic_program_required must be boolean")

    components = value.get("external_components", [])
    if not isinstance(components, list):
        raise ValueError("external_components must be a list")
    seen = set()
    for item in components:
        if not isinstance(item, dict):
            raise ValueError("each external component must be an object")
        cid = _text(item.get("id"), "external component id")
        if cid in seen:
            raise ValueError("external component ids must be unique")
        seen.add(cid)
        _text(item.get("repository_full_name"), "external component repository_full_name")
        _text(item.get("path"), "external component path")
        _text(item.get("ref", "main"), "external component ref")
        digest = _text(item.get("sha256"), "external component sha256").lower()
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("external component sha256 must be 64 hex")
        kind = str(item.get("kind", "semantic_contract")).strip() or "semantic_contract"
        # Component ontology is open. Unknown kinds are content-addressed exactly
        # like native kinds and can later acquire a generated adapter.
        if kind not in _NATIVE_COMPONENT_KINDS and isinstance(item.get("adapter_contract"), object):
            pass

    operators = value.get("operators", [])
    if not isinstance(operators, list):
        raise ValueError("operators must be a list")
    op_ids = set()
    for item in operators:
        if not isinstance(item, dict):
            raise ValueError("each external operator must be an object")
        oid = _text(item.get("id"), "external operator id")
        _text(item.get("instruction"), "external operator instruction")
        if oid in op_ids:
            raise ValueError("external operator ids must be unique")
        op_ids.add(oid)

    out = deepcopy(value)
    policy = out.get("runtime_policy")
    out["manifest_sha256"] = manifest_sha256(out)
    return out


def _raw_bundled_manifest():
    data = pkgutil.get_data("jigaewol_runtime.cognition", "bundled_kernel.json")
    if not data:
        raise ValueError("bundled cognition kernel is unavailable")
    return json.loads(data.decode("utf-8"))


def bundled_manifest():
    return validate_manifest(_raw_bundled_manifest())


def resolve_external_manifest(value):
    if not isinstance(value, dict):
        raise ValueError("external kernel manifest must be a JSON object")
    extends_bundled = value.get("extends_bundled", False)
    if not isinstance(extends_bundled, bool):
        raise ValueError("extends_bundled must be boolean")
    source_sha = manifest_sha256(value)
    if not extends_bundled:
        return validate_manifest(value), source_sha
    base = _raw_bundled_manifest()
    schema_version = value.get("schema_version")
    base_schema_version = base.get("schema_version")
    if (isinstance(schema_version, bool) or not isinstance(schema_version, int) or
            isinstance(base_schema_version, bool) or not isinstance(base_schema_version, int) or
            schema_version != base_schema_version):
        raise ValueError("external kernel overlay schema must match bundled schema")
    if value.get("kernel_id") != base.get("kernel_id"):
        raise ValueError("external kernel overlay kernel_id must match bundled kernel")
    allowed = {
        "schema_version", "kernel_id", "extends_bundled", "overlay_version",
        "runtime_policy", "compiler_directive", "principles", "external_components", "operators",
    }
    unknown = set(value) - allowed
    if unknown:
        raise ValueError("unsupported external kernel overlay keys: " + ", ".join(sorted(unknown)))
    merged = deepcopy(base)
    for key in ("compiler_directive", "principles", "external_components", "operators"):
        if key in value:
            merged[key] = deepcopy(value[key])
    if "runtime_policy" in value:
        if not isinstance(value["runtime_policy"], dict):
            raise ValueError("runtime_policy overlay must be an object")
        merged.setdefault("runtime_policy", {}).update(deepcopy(value["runtime_policy"]))
    return validate_manifest(merged), source_sha


class ExternalKernelStore:
    def __init__(self, state_root, *, auto_configure=True):
        self.root = Path(state_root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.config_path = self.root / "external_kernel_config.json"
        self.cache_path = self.root / "external_kernel_cache.json"
        if auto_configure and not self.config_path.exists():
            self.configure(DEFAULT_REPOSITORY, DEFAULT_PATH, DEFAULT_REF,
                           expected_sha256=DEFAULT_EXPECTED_SHA256, enabled=True)

    def configure(self, repository_full_name, path=DEFAULT_PATH, ref=None, expected_sha256=None,
                  enabled=True, allow_schema_downgrade=False, refresh_ttl_seconds=3600):
        if not isinstance(enabled, bool):
            raise ValueError("enabled must be boolean")
        if not isinstance(allow_schema_downgrade, bool):
            raise ValueError("allow_schema_downgrade must be boolean")
        if isinstance(refresh_ttl_seconds, bool) or not isinstance(refresh_ttl_seconds, int):
            raise ValueError("refresh_ttl_seconds must be a nonnegative integer")
        if refresh_ttl_seconds < 0:
            raise ValueError("refresh_ttl_seconds must be a nonnegative integer")
        if not isinstance(repository_full_name, str) or "/" not in repository_full_name:
            raise ValueError("repository_full_name must be owner/name")
        if not isinstance(path, str) or not path.strip():
            raise ValueError("path must be a repository file path")
        if ref is not None and (not isinstance(ref, str) or not ref.strip()):
            raise ValueError("ref must be a nonempty branch/tag/commit when supplied")
        if expected_sha256 is not None:
            expected_sha256 = str(expected_sha256).lower()
            if len(expected_sha256) != 64 or any(c not in "0123456789abcdef" for c in expected_sha256):
                raise ValueError("expected_sha256 must be a 64-character hex digest")
        data = {
            "enabled": enabled, "repository_full_name": repository_full_name,
            "path": path, "ref": ref, "expected_sha256": expected_sha256,
            "allow_schema_downgrade": allow_schema_downgrade,
            "refresh_ttl_seconds": refresh_ttl_seconds,
        }
        self.config_path.write_text(_canonical(data), encoding="utf-8")
        return deepcopy(data)

    def config(self):
        if not self.config_path.exists():
            return None
        value = json.loads(self.config_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("external kernel config must be an object")
        for key in ("enabled", "allow_schema_downgrade"):
            if key in value and not isinstance(value[key], bool):
                raise ValueError("external kernel config " + key + " must be boolean")
        ttl = value.get("refresh_ttl_seconds", 3600)
        if isinstance(ttl, bool) or not isinstance(ttl, int) or ttl < 0:
            raise ValueError("external kernel config refresh_ttl_seconds must be a nonnegative integer")
        if not isinstance(value.get("repository_full_name"), str) or "/" not in value["repository_full_name"]:
            raise ValueError("external kernel config repository_full_name must be owner/name")
        if not isinstance(value.get("path"), str) or not value["path"].strip():
            raise ValueError("external kernel config path must be a repository file path")
        enabled = value.get("enabled", True)
        return value if enabled is True else None

    def fetch_parameters(self, *, force=False):
        if not isinstance(force, bool):
            raise ValueError("force must be boolean")
        cfg = self.config()
        if not cfg:
            return None
        ttl = cfg.get("refresh_ttl_seconds", 3600)
        if not force and ttl > 0 and self.cache_path.exists():
            try:
                if (time.time() - self.cache_path.stat().st_mtime) < ttl:
                    return None
            except OSError:
                pass
        args = {"repository_full_name": cfg["repository_full_name"], "path": cfg["path"], "encoding": "utf-8"}
        if cfg.get("ref"):
            args["ref"] = cfg["ref"]
        return {"action": "fetch_file", "args": args, "jigaewol_external_kernel": True}

    def ingest(self, fetched):
        text = _extract_content(fetched)
        raw_manifest = json.loads(text)
        manifest, source_sha = resolve_external_manifest(raw_manifest)
        cfg = self.config() or {}
        expected = cfg.get("expected_sha256")
        if expected and source_sha != expected:
            raise ValueError("external kernel source hash differs from configured expected_sha256")
        record = {
            "source": {
                "kind": "github", "repository_full_name": cfg.get("repository_full_name"),
                "path": cfg.get("path"), "ref": cfg.get("ref"),
                "source_manifest_sha256": source_sha,
                "overlay": raw_manifest.get("extends_bundled", False),
            },
            "manifest": manifest,
        }
        self.cache_path.write_text(_canonical(record), encoding="utf-8")
        return deepcopy(record)

    def cached(self):
        if not self.cache_path.exists():
            return None
        return json.loads(self.cache_path.read_text(encoding="utf-8"))

    def _validated_cached(self):
        cached, cfg = self.cached(), self.config()
        if not cached or not cfg:
            return None, "external kernel is disabled or cache is absent"
        source = cached.get("source") if isinstance(cached, dict) else None
        if not isinstance(source, dict):
            return None, "external kernel cache has invalid shape"
        for key in ("repository_full_name", "path", "ref"):
            if source.get(key) != cfg.get(key):
                return None, "cached external kernel source no longer matches current configuration"
        try:
            manifest = validate_manifest(cached.get("manifest"))
        except (TypeError, ValueError, KeyError) as exc:
            return None, "cached external kernel failed validation: " + str(exc)
        expected = cfg.get("expected_sha256")
        if expected and source.get("source_manifest_sha256") != expected:
            return None, "cached external kernel source hash no longer matches expected_sha256"
        record = deepcopy(cached)
        record["manifest"] = manifest
        return record, None

    def effective(self):
        cached, _ = self._validated_cached()
        return cached or {"source": {"kind": "bundled"}, "manifest": bundled_manifest()}

    def status(self):
        cached, cache_error = self._validated_cached()
        effective = cached or {"source": {"kind": "bundled"}, "manifest": bundled_manifest()}
        return {
            "configured": self.config() is not None,
            "config": self.config(),
            "cached": self.cached(),
            "cache_valid": cached is not None,
            "cache_error": cache_error,
            "effective_source": effective.get("source"),
            "effective_kernel_id": effective.get("manifest", {}).get("kernel_id"),
            "effective_sha256": effective.get("manifest", {}).get("manifest_sha256"),
        }
