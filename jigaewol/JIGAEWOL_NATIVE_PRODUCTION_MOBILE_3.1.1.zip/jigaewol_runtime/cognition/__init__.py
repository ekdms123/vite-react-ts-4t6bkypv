"""Adaptive cognition compiler, typed evidence records, and external kernel support."""

from .external import ExternalKernelStore, manifest_sha256, bundled_manifest
from .policy import compiled_kernel_packet, runtime_policy, validate_cognitive_program, should_recompile_after_tool
from .evidence_records import EvidenceEvent, EvidenceClaim, EvidenceAttribution, EvidenceBundle, EntailmentLink

__all__ = [
    "ExternalKernelStore", "manifest_sha256", "bundled_manifest", "compiled_kernel_packet",
    "runtime_policy", "validate_cognitive_program", "should_recompile_after_tool",
    "EvidenceEvent", "EvidenceClaim", "EvidenceAttribution", "EvidenceBundle", "EntailmentLink",
]
