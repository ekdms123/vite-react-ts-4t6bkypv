from __future__ import annotations

"""Compile open-set creative mechanisms into a realization contract.

The compiler does not prescribe a style taxonomy. A mechanism is admitted when
it names an actual state change and a concrete instruction that can alter the
material artifact; the host model performs the language realization.
"""

from copy import deepcopy
from dataclasses import asdict

from .creative import creative_state_from, apply_creative_choice


def _text(value, name):
    value = str(value or "").strip()
    if not value:
        raise ValueError(f"creative move needs {name}")
    return value


def compile_creative_program(program):
    if not isinstance(program, dict):
        raise ValueError("creative_program must be an object")
    state = creative_state_from(program.get("state", {}))
    before = asdict(state)
    moves = program.get("moves") or []
    if not isinstance(moves, list) or not moves:
        raise ValueError("creative_program needs at least one material move")
    compiled = []
    seen = set()
    for raw in moves:
        if not isinstance(raw, dict):
            raise ValueError("creative moves must be objects")
        mid = _text(raw.get("id"), "id")
        if mid in seen:
            raise ValueError("creative move ids must be unique")
        seen.add(mid)
        mechanism = _text(raw.get("mechanism"), "mechanism")
        directive = _text(raw.get("realization_directive"), "realization_directive")
        expected = _text(raw.get("expected_effect"), "expected_effect")
        falsifier = _text(raw.get("falsifier"), "falsifier")
        changes = raw.get("state_changes") or {}
        if not isinstance(changes, dict) or not changes:
            raise ValueError("creative move needs actual state_changes")
        state = apply_creative_choice(state, mechanism, changes=changes)
        compiled.append({
            "id": mid,
            "mechanism": mechanism,
            "state_changes": deepcopy(changes),
            "realization_directive": directive,
            "expected_effect": expected,
            "falsifier": falsifier,
        })
    return {
        "version": 2,
        "state_before": before,
        "state_after": asdict(state),
        "moves": compiled,
        "selection_rule": "material effect and goal fit; prefer causal novelty over random surface novelty",
        "compiler_role": "causal lens and optional rewrite diagnostic; not a mandatory pre-generation gate",
    }
