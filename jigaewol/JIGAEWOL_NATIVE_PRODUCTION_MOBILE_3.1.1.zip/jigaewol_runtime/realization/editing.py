"""Literal, non-overlapping edits of an existing draft."""
def apply_text_edits(text, edits):
    if not isinstance(text, str) or not isinstance(edits, list) or not edits:
        raise ValueError("literal edits require an existing text and nonempty edits")
    spans = []
    for item in edits:
        if not isinstance(item, dict):
            raise ValueError("each edit must be an object")
        before, after = item.get("before"), item.get("after")
        if not isinstance(before, str) or not before or not isinstance(after, str):
            raise ValueError("each edit needs before and after text")
        positions, cursor = [], 0
        while True:
            pos = text.find(before, cursor)
            if pos < 0:
                break
            positions.append(pos)
            cursor = pos + 1
        occurrence = item.get("occurrence")
        if occurrence is None:
            if len(positions) != 1:
                raise ValueError("ambiguous edit: supply occurrence")
            occurrence = 0
        if isinstance(occurrence, bool) or not isinstance(occurrence, int) or not 0 <= occurrence < len(positions):
            raise ValueError("edit does not match current draft")
        start = positions[occurrence]
        spans.append((start, start + len(before), after))
    spans.sort()
    if any(a[1] > b[0] for a, b in zip(spans, spans[1:])):
        raise ValueError("combine overlapping edits")
    for start, end, after in reversed(spans):
        text = text[:start] + after + text[end:]
    return text
