"""Material realization adapters."""
