from __future__ import annotations
from dataclasses import dataclass, field, replace


def _tuple_map(value) -> dict[str, tuple[str, ...]]:
    out: dict[str, tuple[str, ...]] = {}
    for key, rows in dict(value or {}).items():
        if isinstance(rows, str):
            rows = (rows,)
        out[str(key)] = tuple(str(row) for row in (rows or ()))
    return out


@dataclass(frozen=True)
class CreativeState:
    scene_pressure: tuple[str, ...]
    character_private_state: dict[str, str]
    unsayable_facts: tuple[str, ...]
    narrator_objective: str
    reader_information_state: tuple[str, ...]
    reveal_withhold_graph: tuple[tuple[str, str], ...]
    rhythm_drivers: tuple[str, ...]
    image_motifs: tuple[str, ...]
    causal_choices: tuple[str, ...]
    resulting_text_refs: tuple[str, ...]
    # Reader-model layers: knowing, suspecting, believing wrongly, attending, and
    # emotionally expecting are deliberately separate. A twist can therefore repair
    # a reader model instead of merely dumping new information.
    reader_suspicions: tuple[str, ...] = ()
    reader_misbeliefs: tuple[str, ...] = ()
    reader_attention: tuple[str, ...] = ()
    reader_emotional_expectations: tuple[str, ...] = ()
    # Longitudinal state. These are histories rather than current labels so a long
    # work can preserve change instead of silently resetting character/motif meaning.
    character_trajectories: dict[str, tuple[str, ...]] = field(default_factory=dict)
    motif_history: dict[str, tuple[str, ...]] = field(default_factory=dict)
    # Separate authorial truth from what characters believe. This prevents a
    # consistency pass from flattening unreliable narration or intentional misbelief.
    authorial_truth: tuple[str, ...] = ()
    character_beliefs: dict[str, tuple[str, ...]] = field(default_factory=dict)
    # Novelty is most useful when it changes causality, not when it merely adds an
    # unusual surface object. These links are optional and open-set.
    causal_novelty_links: tuple[str, ...] = ()
    facets: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class CreativeEffect:
    intent_refs: tuple[str, ...]
    state_before_ref: str
    state_after_ref: str
    output_refs: tuple[str, ...]
    causal_changes: tuple[str, ...]

    def is_material(self) -> bool:
        return bool(self.output_refs and self.causal_changes and self.state_before_ref != self.state_after_ref)


def apply_creative_choice(state: CreativeState, choice: str, output_ref: str | None = None, changes: dict | None = None) -> CreativeState:
    if not choice.strip():
        raise ValueError("creative choice must be non-empty")
    refs = state.resulting_text_refs + ((output_ref,) if output_ref else ())
    updates = {}
    facet_updates = dict(state.facets)
    protected = {"causal_choices", "resulting_text_refs", "facets"}
    tuple_map_fields = {"character_trajectories", "motif_history", "character_beliefs"}
    for name, value in (changes or {}).items():
        if name in protected:
            raise ValueError("derived creative field cannot be assigned directly: " + name)
        if name not in CreativeState.__dataclass_fields__:
            # Open-set creative dimensions are preserved verbatim as named facets.
            # Unknown does not mean invalid: only core/derived state integrity is protected.
            facet_updates[name] = value
            continue
        if name == "character_private_state":
            updates[name] = {**state.character_private_state, **dict(value)}
        elif name in tuple_map_fields:
            current = dict(getattr(state, name))
            current.update(_tuple_map(value))
            updates[name] = current
        elif name == "narrator_objective":
            updates[name] = str(value)
        else:
            updates[name] = tuple(tuple(x) if isinstance(x, list) else x for x in value)
    updates["facets"] = facet_updates
    return replace(state, **updates, causal_choices=state.causal_choices + (choice,), resulting_text_refs=refs)


def creative_state_from(value=None) -> CreativeState:
    data = dict(value or {})
    fields = {}
    core_names = set(CreativeState.__dataclass_fields__) - {"facets"}
    explicit_facets = dict(data.get("facets", {})) if isinstance(data.get("facets", {}), dict) else {}
    inferred_facets = {k: v for k, v in data.items() if k not in core_names and k != "facets"}
    tuple_map_fields = {"character_trajectories", "motif_history", "character_beliefs"}
    for name in core_names:
        if name == "character_private_state":
            fields[name] = dict(data.get(name, {}))
        elif name in tuple_map_fields:
            fields[name] = _tuple_map(data.get(name, {}))
        elif name == "narrator_objective":
            fields[name] = str(data.get(name, ""))
        else:
            fields[name] = tuple(tuple(x) if isinstance(x, list) else x for x in data.get(name, ()))
    fields["facets"] = {**explicit_facets, **inferred_facets}
    return CreativeState(**fields)


def compile_creative_program(state: CreativeState | dict) -> dict:
    """Compile creative state into operations the next realization may materialize.

    These are causal lenses, not a mandatory style taxonomy. Generation is allowed to
    produce unplanned useful material first; this program names mechanisms that can be
    used before generation or as a post-generation diagnostic/rewrite pass.
    """
    state = state if isinstance(state, CreativeState) else creative_state_from(state)
    operations = []

    if state.character_private_state or state.unsayable_facts:
        operations.append({
            "id": "attention.private_state",
            "op": "attention_bias",
            "mechanism": "private state changes what the speaker notices before it changes what the speaker explicitly says",
            "private_state": dict(state.character_private_state),
            "unsayable_facts": list(state.unsayable_facts),
            "material_test": "observable detail selection carries the private pressure without merely naming the emotion",
        })

    for fact, timing in state.reveal_withhold_graph:
        operations.append({
            "id": "reveal." + str(len(operations) + 1),
            "op": "withhold_reveal",
            "mechanism": "information order changes the interpretation of earlier material",
            "fact": str(fact),
            "timing": str(timing),
            "material_test": "the fact is withheld and its later reveal retroactively changes prior meaning",
        })

    if state.narrator_objective and state.unsayable_facts:
        operations.append({
            "id": "leak.objective",
            "op": "objective_leakage",
            "mechanism": "the narrator pursues an objective while involuntarily leaking information that complicates it",
            "objective": state.narrator_objective,
            "pressure_facts": list(state.unsayable_facts),
            "material_test": "the objective and leaked information pull in different directions in the artifact",
        })

    if state.rhythm_drivers:
        operations.append({
            "id": "rhythm.pressure",
            "op": "rhythm_pressure",
            "mechanism": "sentence/beat structure changes as scene pressure changes",
            "drivers": list(state.rhythm_drivers),
            "material_test": "rhythmic change corresponds to a state transition rather than decorative variation",
        })

    if state.image_motifs or state.motif_history:
        operations.append({
            "id": "motif.recurrence",
            "op": "motif_recurrence",
            "mechanism": "recurring concrete images accumulate changed meaning across appearances",
            "motifs": list(state.image_motifs),
            "motif_history": {k: list(v) for k, v in state.motif_history.items()},
            "material_test": "a repeated image returns with altered contextual meaning rather than as decorative repetition",
        })

    if any((state.reader_information_state, state.reader_suspicions, state.reader_misbeliefs,
            state.reader_attention, state.reader_emotional_expectations)):
        operations.append({
            "id": "reader.model",
            "op": "reader_model_management",
            "mechanism": "manage what the reader knows, suspects, falsely believes, attends to, and emotionally expects as separate states",
            "known": list(state.reader_information_state),
            "suspected": list(state.reader_suspicions),
            "misbeliefs": list(state.reader_misbeliefs),
            "attention": list(state.reader_attention),
            "emotional_expectations": list(state.reader_emotional_expectations),
            "material_test": "new material changes at least one reader-state layer without pretending all five layers are the same thing",
        })

    if state.character_trajectories:
        operations.append({
            "id": "character.trajectory",
            "op": "longitudinal_character_state",
            "mechanism": "current choices inherit and transform prior belief/desire/fear states instead of resetting the character each scene",
            "trajectories": {k: list(v) for k, v in state.character_trajectories.items()},
            "material_test": "a current action is legible as a transition from an earlier state, not only as a local mood",
        })

    if state.authorial_truth or state.character_beliefs:
        operations.append({
            "id": "belief.layers",
            "op": "belief_layer_separation",
            "mechanism": "authorial truth, character belief, and reader belief may intentionally disagree",
            "authorial_truth": list(state.authorial_truth),
            "character_beliefs": {k: list(v) for k, v in state.character_beliefs.items()},
            "material_test": "intentional misbelief or unreliable narration survives consistency checking without being flattened into authorial truth",
        })

    if state.causal_novelty_links:
        operations.append({
            "id": "novelty.causal",
            "op": "causal_novelty",
            "mechanism": "novelty comes from an unexpected causal relation between otherwise familiar elements rather than random surface decoration",
            "causal_links": list(state.causal_novelty_links),
            "material_test": "removing the causal link makes the artifact structurally more conventional, not merely less quirky",
        })

    for name, value in state.facets.items():
        operations.append({
            "id": "facet." + str(name),
            "op": "creative_facet",
            "dimension": str(name),
            "value": value,
            "mechanism": "open-set creative dimension supplied by live cognition",
            "material_test": "the named facet remains independently addressable and materially influences realization",
        })

    return {
        "version": 2,
        "operations": operations,
        "generation_contract": {
            "must_materialize_operations": bool(operations),
            "do_not_replace_with_style_advice": True,
            "assessment_basis": "actual artifact differences caused by operations",
            "schema_is_lens_not_generator_gate": True,
            "generation_may_precede_optional_diagnosis": True,
        },
    }
