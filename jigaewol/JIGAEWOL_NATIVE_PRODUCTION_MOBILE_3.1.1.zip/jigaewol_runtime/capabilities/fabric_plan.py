from __future__ import annotations

"""One truth-preserving execution plan for the ordinary-chat surface.

The plan composes whatever real HOST components currently exist into a workstation-like execution surface and reports the gaps instead of
silently shrinking the user's destination.
"""
from copy import deepcopy

from .execution_routes import compose_execution_routes, infer_required_traits, trait_discovery_query
from .workstation import virtual_workstation_plan
from .agent_pool import agent_pool_plan
from .terminal import terminal_backplane_plan
from .perception import signed_in_perception_status


def build_execution_fabric_plan(task: str, capabilities, *, execution_handles=(), required_traits=None):
    required=tuple(infer_required_traits(task) if required_traits is None else (str(x) for x in required_traits if str(x)))
    routes=compose_execution_routes(task,capabilities,required_traits=required)
    workstation=virtual_workstation_plan(capabilities)
    delegates=agent_pool_plan(task,capabilities)
    terminal=terminal_backplane_plan(capabilities, execution_handles)
    perception=signed_in_perception_status(capabilities)
    handles=[deepcopy(x) for x in (execution_handles or ()) if isinstance(x,dict)]
    alive=[x for x in handles if x.get("status")=="observed_alive"]
    stale=[x for x in handles if x.get("status") in {"registered","stale_unprobed"}]

    if workstation.get("slots",{}).get("remote_computer",{}).get("available"):
        computer_mode="authorized_remote_computer_surface"
    elif workstation.get("full_external_workstation_ready"):
        computer_mode="composed_virtual_workstation"
    elif workstation.get("persistent_machine_backing_available"):
        computer_mode="persistent_compute_backplane"
    elif workstation.get("slots",{}).get("interactive_browser_actuator",{}).get("available"):
        computer_mode="interactive_browser_backplane"
    else:
        computer_mode="chat_surface_with_partial_components"

    missing=list(routes.get("missing_traits") or ())
    return {
        "task":str(task or ""),
        "runtime_surface":"ordinary_chat_mobile_or_desktop",
        "computer_mode":computer_mode,
        "required_traits":list(required),
        "route_composition":deepcopy(routes),
        "workstation":deepcopy(workstation),
        "agent_pool":deepcopy(delegates),
        "terminal_backplane":deepcopy(terminal),
        "signed_in_perception":deepcopy(perception),
        "execution_handles":{
            "observed_alive":alive,
            "requires_reprobe":stale,
            "truth":"handle persistence does not imply process/session liveness",
        },
        "missing_traits":missing,
        "acquisition_query":trait_discovery_query(missing) if missing else "",
        "destination_preserved":True,
        "truth_boundary":"plan_is_not_execution; execution requires actual HOST tool observations",
    }
