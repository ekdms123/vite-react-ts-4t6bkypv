from __future__ import annotations

"""Truth-preserving planner for *real* external delegates.

JIGAEWOL cognition branches are representations realized by the current HOST model;
they are not independent model sessions.  This module only reports an external
agent candidate when that capability is present on the current callable HOST
surface with explicit agent/delegate evidence.  It never upgrades an internal
``worlds.realize`` branch into a fake subagent.
"""

from copy import deepcopy

from .manifest import normalize_capabilities, capability_is_callable
from .execution_routes import capability_traits
from .ranker import rank_capabilities


def external_delegate_candidates(task: str, capabilities):
    specs = [spec for spec in normalize_capabilities(capabilities or ()) if capability_is_callable(spec)]
    lexical = {spec["id"]: score for spec, score in rank_capabilities(str(task or ""), specs)}
    rows = []
    for index, spec in enumerate(specs):
        # Real delegation authority must be explicit. Do not infer an external
        # agent from generic words such as "agentic" or "agent" in prose/tags.
        explicit = (
            spec.get("role") == "agent_delegate"
            or spec.get("operation") == "agent_delegate"
            or "agent_delegate" in set(spec.get("tags", ()) or ())
        )
        if not explicit:
            continue
        rows.append({
            "capability_id": spec["id"],
            "role": spec.get("role"),
            "provider": spec.get("provider"),
            "plugin": spec.get("plugin"),
            "operation": spec.get("operation"),
            "description": spec.get("description", ""),
            "score": float(lexical.get(spec["id"], 0.0)),
            "permission": spec.get("permission", "none"),
            "truth_state": "callable_external_delegate_candidate_not_started",
            "manifest_index": index,
        })
    rows.sort(key=lambda row: (-row["score"], row["manifest_index"], row["capability_id"]))
    return tuple(deepcopy(rows))


def agent_pool_plan(task: str, capabilities):
    candidates = list(external_delegate_candidates(task, capabilities))
    return {
        "task": str(task or ""),
        "external_delegate_candidates": candidates,
        "real_external_delegate_available": bool(candidates),
        "internal_cognition_branches_are_external_agents": False,
        "worlds_realize_truth": (
            "isolated_representation_branch_realized_by_current_host_model_not_independent_agent_session"
        ),
        "execution_truth": (
            "candidate callability is not delegation evidence; executed requires a real host delegate invocation/result"
        ),
    }
