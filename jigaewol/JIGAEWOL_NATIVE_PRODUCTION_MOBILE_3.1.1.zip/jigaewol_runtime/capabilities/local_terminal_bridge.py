from __future__ import annotations

"""On-demand persistent local terminal for the ordinary ChatGPT cockpit.

The shell itself is intentionally process-scoped.  The *workspace* is the
continuity primitive: a new daemon can be re-created after the previous daemon
exits and will start in the same owner-local workspace without pretending that
volatile shell state (exports, jobs, in-memory processes) survived.
"""

from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import signal
import shlex
import socket
import subprocess
import sys
import time


CAPABILITY_ID = "JIGAEWOL_Local_Terminal"


def capability_spec() -> dict:
    return {
        "capability_id": CAPABILITY_ID,
        "role": "compute",
        "provider": "jigaewol_local_bridge",
        "state": "callable",
        "description": (
            "Owner-local persistent bash behind an owner-only Unix socket with a durable "
            "workspace plus a checkpointed cwd/safe environment subset that is rehydrated after daemon restart. "
            "Background jobs and full shell process state remain truthfully process-scoped."
        ),
        "permission": "none",
        "cost": 0.0,
        "tags": [
            "terminal",
            "shell",
            "code execution",
            "filesystem",
            "persistent workspace",
            "rehydratable workspace",
            "checkpointed shell subset",
            "local",
            "zero-spend",
        ],
        "actions": ["exec", "ping", "checkpoint", "close"],
        "truth_state": "callable_local_rehydratable_workspace_checkpointed_shell_subset_process_scoped_jobs",
    }


class LocalTerminalBridge:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.workspace_path = self.directory / "workspace"
        self.workspace_path.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256(str(self.directory.resolve()).encode("utf-8")).hexdigest()[:20]
        self.socket_path = Path("/tmp") / ("jigaewol-term-" + digest + ".sock")
        self.token_path = self.directory / "token"
        self.meta_path = self.directory / "meta.json"
        self.log_path = self.directory / "server.log"
        self.rehydration_path = self.directory / "rehydration.jsonl"
        self.shell_checkpoint_path = self.directory / "shell_checkpoint.json"

    @property
    def server_script(self) -> Path:
        return Path(__file__).with_name("local_terminal_server.py")

    @staticmethod
    def _load_json(path: Path) -> dict:
        try:
            raw = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return {}
        except (OSError, UnicodeError) as exc:
            raise RuntimeError(f"LOCAL_TERMINAL_STATE_READ_FAILED:{path}:{type(exc).__name__}:{exc}") from exc
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"LOCAL_TERMINAL_STATE_CORRUPT:{path}:{exc}") from exc
        if not isinstance(value, dict):
            raise RuntimeError(f"LOCAL_TERMINAL_STATE_INVALID_TYPE:{path}:{type(value).__name__}")
        return value

    def _append_rehydration(self, event: dict) -> None:
        payload = dict(event)
        payload.setdefault("at", time.time())
        payload.setdefault("workspace", str(self.workspace_path.resolve()))
        with self.rehydration_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        try:
            os.chmod(self.rehydration_path, 0o600)
        except OSError:
            # Permission hardening can be unsupported on some filesystems.  The
            # event itself is still retained; caller-visible truth stays in the
            # returned lifecycle metadata rather than being silently discarded.
            pass

    def _write_shell_checkpoint(self, snapshot: dict, *, session_id: str = "") -> dict:
        row = {
            "schema": "jigaewol_local_shell_checkpoint_v1",
            "checkpoint_id": "shellcp_" + hashlib.sha256(
                json.dumps([snapshot.get("cwd_relative"), snapshot.get("dynamic_env"), time.time_ns()], sort_keys=True).encode()
            ).hexdigest()[:20],
            "source_session_id": str(session_id),
            "cwd_within_workspace": bool(snapshot.get("cwd_within_workspace")),
            "cwd_relative": str(snapshot.get("cwd_relative") or ""),
            "dynamic_env": dict(snapshot.get("dynamic_env") or {}),
            "excluded_sensitive_env_count": int(snapshot.get("excluded_sensitive_env_count") or 0),
            "shell_process_state_preserved": False,
            "background_jobs_preserved": False,
            "created_at": time.time(),
        }
        tmp = self.shell_checkpoint_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(row, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(self.shell_checkpoint_path)
        return row

    def checkpoint_shell_state(self) -> dict:
        response = self._request("snapshot", timeout=3)
        row = self._write_shell_checkpoint(dict(response.get("snapshot") or {}), session_id=str((response.get("meta") or {}).get("session_id") or ""))
        return {
            "checkpoint_id": row["checkpoint_id"],
            "cwd_relative": row["cwd_relative"],
            "cwd_within_workspace": row["cwd_within_workspace"],
            "dynamic_env_keys": sorted(row["dynamic_env"]),
            "excluded_sensitive_env_count": row["excluded_sensitive_env_count"],
            "shell_process_state_preserved": False,
            "background_jobs_preserved": False,
        }

    def _restore_shell_checkpoint(self) -> dict:
        row = self._load_json(self.shell_checkpoint_path)
        if not row:
            return {"attempted": False, "restored": False, "reason": "no_checkpoint"}
        commands = []
        rel = str(row.get("cwd_relative") or "")
        target = (self.workspace_path / rel).resolve() if rel else self.workspace_path.resolve()
        try:
            target.relative_to(self.workspace_path.resolve())
        except ValueError:
            target = self.workspace_path.resolve()
            rel = ""
        if not target.is_dir():
            target = self.workspace_path.resolve()
            rel = ""
        commands.append("cd -- " + shlex.quote(str(target)))
        restored_keys = []
        for key, value in sorted(dict(row.get("dynamic_env") or {}).items()):
            if not key.startswith("JIGAEWOL_PERSIST_") and key not in {"PATH","PYTHONPATH","VIRTUAL_ENV","NODE_ENV","NVM_DIR","CONDA_PREFIX","CONDA_DEFAULT_ENV"}:
                continue
            if not __import__("re").fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
                continue
            commands.append("export " + key + "=" + shlex.quote(str(value)))
            restored_keys.append(key)
        observed = self._request("exec", command=" && ".join(commands), timeout=5)
        return {
            "attempted": True, "restored": int(observed.get("exit_code", 1)) == 0,
            "checkpoint_id": row.get("checkpoint_id"), "cwd_relative": rel,
            "restored_env_keys": restored_keys,
            "shell_process_state_preserved": False, "background_jobs_preserved": False,
        }

    @staticmethod
    def _pid_exists(pid) -> bool:
        try:
            pid = int(pid)
            if pid <= 0:
                return False
            os.kill(pid, 0)
            return True
        except (TypeError, ValueError, ProcessLookupError):
            return False
        except PermissionError:
            return True

    @staticmethod
    def _verified_old_bash(pid) -> bool:
        """Return true only when /proc proves *pid* is our expected bash shape.

        PID reuse is why a stale metadata PID must never be killed blindly.
        Platforms without /proc simply skip orphan retirement.
        """
        try:
            pid = int(pid)
            raw = (Path("/proc") / str(pid) / "cmdline").read_bytes()
        except (TypeError, ValueError, FileNotFoundError, PermissionError, OSError):
            return False
        parts = [part.decode("utf-8", "replace") for part in raw.split(b"\0") if part]
        if not parts:
            return False
        exe = Path(parts[0]).name
        return exe == "bash" and "--noprofile" in parts and "--norc" in parts

    def _retire_stale_bash(self, previous_meta: dict) -> dict:
        pid = previous_meta.get("bash_pid")
        result = {"attempted": False, "verified": False, "terminated": False, "pid": pid}
        if not self._pid_exists(pid):
            return result
        result["verified"] = self._verified_old_bash(pid)
        if not result["verified"]:
            result["reason"] = "pid_alive_but_identity_not_proven"
            return result
        result["attempted"] = True
        try:
            os.kill(int(pid), signal.SIGTERM)
        except ProcessLookupError:
            return result
        deadline = time.monotonic() + 1.0
        while time.monotonic() < deadline:
            if not self._pid_exists(pid):
                result["terminated"] = True
                return result
            time.sleep(0.02)
        result["reason"] = "verified_stale_bash_did_not_exit_after_sigterm"
        return result

    def _request(self, operation: str, *, command=None, timeout=30.0) -> dict:
        if not self.token_path.exists() or not self.socket_path.exists():
            raise ConnectionError("local terminal bridge is not running")
        token = self.token_path.read_text(encoding="utf-8").strip()
        request = {"token": token, "op": operation, "timeout": float(timeout)}
        if command is not None:
            request["command"] = command
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.settimeout(max(1.0, float(timeout) + 2.0))
        client.connect(str(self.socket_path))
        try:
            client.sendall((json.dumps(request, ensure_ascii=False) + "\n").encode("utf-8"))
            data = bytearray()
            while b"\n" not in data:
                chunk = client.recv(65536)
                if not chunk:
                    break
                data.extend(chunk)
            if not data:
                raise ConnectionError("local terminal bridge returned no response")
            response = json.loads(bytes(data).split(b"\n", 1)[0].decode("utf-8"))
            if response.get("ok") is not True:
                raise RuntimeError(
                    f"{response.get('error_type','TerminalError')}: "
                    f"{response.get('error','unknown error')}"
                )
            return response
        finally:
            client.close()

    def ping(self) -> dict:
        return self._request("ping", timeout=2)

    def is_alive(self) -> bool:
        try:
            return bool(self.ping().get("bash_alive"))
        except (ConnectionError, FileNotFoundError, OSError, RuntimeError, json.JSONDecodeError):
            return False

    def start(self, *, startup_timeout=5.0) -> dict:
        if self.is_alive():
            return self.ping()

        previous_meta = self._load_json(self.meta_path)
        orphan_retirement = self._retire_stale_bash(previous_meta) if previous_meta else {}
        self.workspace_path.mkdir(parents=True, exist_ok=True)
        for path in (self.socket_path, self.token_path):
            try:
                path.unlink()
            except FileNotFoundError:
                pass

        log = open(self.log_path, "ab", buffering=0)
        proc = subprocess.Popen(
            [
                sys.executable,
                str(self.server_script),
                "--socket",
                str(self.socket_path),
                "--token-file",
                str(self.token_path),
                "--meta-file",
                str(self.meta_path),
                "--workspace",
                str(self.workspace_path),
            ],
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=log,
            start_new_session=True,
            close_fds=True,
        )
        log.close()
        deadline = time.monotonic() + startup_timeout
        last_error = None
        while time.monotonic() < deadline:
            try:
                response = self.ping()
                current_meta = dict(response.get("meta") or {})
                shell_checkpoint_restore = self._restore_shell_checkpoint()
                event = {
                    "event": "server_restart" if previous_meta.get("session_id") else "initial_start",
                    "previous_session_id": previous_meta.get("session_id"),
                    "new_session_id": current_meta.get("session_id"),
                    "previous_server_pid": previous_meta.get("pid"),
                    "new_server_pid": current_meta.get("pid"),
                    "previous_bash_pid": previous_meta.get("bash_pid"),
                    "new_bash_pid": current_meta.get("bash_pid"),
                    "workspace_preserved": self.workspace_path.exists(),
                    "shell_state_preserved": False,
                    "cwd_rehydrated_to_workspace_root": not bool(shell_checkpoint_restore.get("restored")),
                    "checkpointed_shell_subset_restored": bool(shell_checkpoint_restore.get("restored")),
                    "dynamic_environment_preserved": bool(shell_checkpoint_restore.get("restored_env_keys")),
                    "dynamic_environment_scope": "checkpoint_allowlist_only",
                    "background_jobs_preserved": False,
                    "shell_checkpoint_restore": shell_checkpoint_restore,
                    "orphan_retirement": orphan_retirement,
                }
                self._append_rehydration(event)
                response["rehydration"] = event
                return response
            except (ConnectionError, FileNotFoundError, OSError, RuntimeError, json.JSONDecodeError) as exc:
                last_error = exc
                time.sleep(0.05)
        self._append_rehydration(
            {
                "event": "start_failed",
                "previous_session_id": previous_meta.get("session_id"),
                "spawned_server_pid": proc.pid,
                "error_type": type(last_error).__name__ if last_error else None,
                "error": str(last_error) if last_error else "unknown startup failure",
            }
        )
        raise RuntimeError(f"local terminal bridge failed to start: {last_error}")

    def execute(self, command: str, *, timeout=30.0) -> dict:
        if not isinstance(command, str) or not command.strip():
            raise ValueError("terminal command must be nonempty text")
        startup = self.start()
        result = self._request("exec", command=command, timeout=timeout)
        try:
            result["shell_checkpoint"] = self.checkpoint_shell_state()
        except (ConnectionError, FileNotFoundError, OSError, RuntimeError, json.JSONDecodeError) as exc:
            self._append_rehydration({
                "event": "shell_checkpoint_failed", "error_type": type(exc).__name__, "error": str(exc),
                "shell_process_state_preserved": False, "background_jobs_preserved": False,
            })
            result["shell_checkpoint"] = {"checkpointed": False, "error_type": type(exc).__name__}
        if startup.get("rehydration"):
            result["rehydration"] = startup["rehydration"]
        return result

    def close(self) -> dict | None:
        if not self.is_alive():
            return None
        return self._request("close", timeout=2)

    def rehydration_history(self) -> list[dict]:
        if not self.rehydration_path.exists():
            return []
        rows = []
        for line in self.rehydration_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                rows.append({"event": "journal_parse_failure", "raw_sha256": hashlib.sha256(line.encode()).hexdigest()})
                continue
            if isinstance(value, dict):
                rows.append(value)
        return rows

    def handle(self, *, origin_ref: str, observed_alive=True) -> dict:
        response = self.ping() if observed_alive else None
        meta = deepcopy((response or {}).get("meta") or {})
        handle_id = str(meta.get("session_id") or self.meta_path)
        return {
            "kind": "terminal_session",
            "provider": CAPABILITY_ID,
            "handle_id": handle_id,
            "origin_ref": origin_ref,
            "observed_alive": bool(observed_alive),
            "metadata": {
                "socket": str(self.socket_path),
                "session_directory": str(self.directory),
                "workspace": str(self.workspace_path),
                "bash_pid": meta.get("bash_pid"),
                "server_pid": meta.get("pid"),
                "rehydration_journal": str(self.rehydration_path),
                "shell_state_process_scoped": True,
                "background_jobs_process_scoped": True,
                "workspace_survives_server_restart": True,
                "checkpointed_shell_subset_survives_server_restart": self.shell_checkpoint_path.is_file(),
                "cwd_rehydrate_policy": "checkpointed_workspace_relative_else_workspace_root",
                "dynamic_environment_survives_server_restart": "checkpoint_allowlist_only",
                "persistence": "durable_workspace_plus_checkpointed_cwd_env_subset_with_process_scoped_jobs",
            },
        }

    def action_handler(self, work):
        params = dict(getattr(work, "parameters", {}) or {})
        action = params.pop("host_action", params.pop("provider_action", params.pop("action", None)))
        if action == "ping":
            response = self.start()
            return {
                "output": response,
                "origin_ref": "jigaewol-local-terminal:ping",
                "execution_handles": [self.handle(origin_ref="jigaewol-local-terminal:ping")],
            }
        if action == "exec":
            command = params.get("command")
            if command is None and isinstance(params.get("cmd"), list):
                # Action-level semantic plans may express a shell argv as
                # ["bash", "-lc", command]. Preserve the exact command only.
                cmd = params["cmd"]
                if len(cmd) >= 3 and cmd[0] in {"bash", "/bin/bash", "sh", "/bin/sh"} and cmd[1] == "-lc":
                    command = cmd[2]
            result = self.execute(command, timeout=float(params.get("timeout", 30)))
            return {
                "output": result,
                "origin_ref": "jigaewol-local-terminal:exec",
                "execution_handles": [self.handle(origin_ref="jigaewol-local-terminal:exec")],
            }
        if action == "checkpoint":
            return {"output": self.checkpoint_shell_state(), "origin_ref": "jigaewol-local-terminal:checkpoint"}
        if action == "close":
            result = self.close() or {"ok": True, "already_closed": True}
            return {"output": result, "origin_ref": "jigaewol-local-terminal:close"}
        raise LookupError(f"LOCAL_TERMINAL_PROTOCOL_ACTION_UNBOUND:{action!r}")
