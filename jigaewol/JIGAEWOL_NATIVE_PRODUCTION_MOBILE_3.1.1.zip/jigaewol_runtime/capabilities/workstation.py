from __future__ import annotations

"""Truth-preserving virtual workstation composition over callable HOST components.

The chat is the interaction surface. Machine/browser/workspace state lives in the
connected execution components; this module only describes which callable components can
fill each workstation slot. It never claims that a remote computer or browser is
attached merely because a template/plugin exists.
"""
from copy import deepcopy

from .manifest import normalize_capabilities, capability_is_callable
from .execution_routes import capability_traits

_SLOT_RULES = {
    "terminal_filesystem": ({"terminal", "filesystem"},),
    "persistent_compute": ({"code_execution", "persistent_workspace"},),
    "repository": ({"repository"},),
    "web_retrieval": ({"web_search"},),
    "authenticated_browser_sensor": ({"browser", "authenticated_session"},),
    "interactive_browser_actuator": ({"browser", "interaction"},),
    "authenticated_interactive_browser": ({"browser", "authenticated_session", "interaction"},),
    "social_publish_actuator": ({"web_write"},),
    "knowledge_persistence": ({"knowledge_base"},),
    "external_agent_delegate": ({"agent_delegate"},),
    "remote_computer": ({"remote_computer", "terminal", "filesystem"},),
}

def _slot_candidates(specs, alternatives):
    rows=[]
    for spec in specs:
        traits=set(capability_traits(spec))
        matched=[sorted(req) for req in alternatives if set(req) <= traits]
        if not matched:
            continue
        rows.append({
            "capability_id": spec["id"],
            "role": spec.get("role"),
            "provider": spec.get("provider"),
            "plugin": spec.get("plugin"),
            "traits": sorted(traits),
            "matched_rule": matched[0],
            "truth_state": "callable_slot_candidate_not_execution_evidence",
        })
    return rows

def virtual_workstation_plan(capabilities):
    specs=tuple(spec for spec in normalize_capabilities(capabilities or ()) if capability_is_callable(spec))
    slots={}
    for name, alternatives in _SLOT_RULES.items():
        candidates=_slot_candidates(specs, alternatives)
        slots[name]={"available": bool(candidates), "candidates": candidates}
    persistent_machine = slots["remote_computer"]["available"] or slots["persistent_compute"]["available"]
    browser_pair = slots["authenticated_browser_sensor"]["available"] and slots["interactive_browser_actuator"]["available"]
    authenticated_interactive = slots["authenticated_interactive_browser"]["available"] or browser_pair
    knowledge = slots["knowledge_persistence"]["available"]
    full = bool(persistent_machine and authenticated_interactive and knowledge)
    if full:
        level = "full_external_workstation_composition"
    elif persistent_machine and slots["interactive_browser_actuator"]["available"]:
        level = "compute_plus_browser"
    elif persistent_machine:
        level = "persistent_compute_only"
    elif slots["interactive_browser_actuator"]["available"]:
        level = "interactive_web_only"
    else:
        level = "chat_interaction_surface_only"
    return {
        "runtime_surface": "ordinary_chat_mobile_or_desktop",
        "state_plane": "connected_host_components_not_the_chat_model",
        "slots": deepcopy(slots),
        "persistent_machine_backing_available": bool(persistent_machine),
        "authenticated_browser_pair_available": bool(browser_pair),
        "authenticated_interactive_browser_available": bool(authenticated_interactive),
        "knowledge_persistence_available": bool(knowledge),
        "full_external_workstation_ready": full,
        "mobile_cockpit_level": level,
        "mobile_cockpit_ready": bool(persistent_machine or slots["interactive_browser_actuator"]["available"]),
        "external_execution_truth": "chat coordinates external execution state; it does not become the external process itself",
    }
