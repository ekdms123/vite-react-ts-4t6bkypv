from __future__ import annotations

"""Lexical ranking for already-connected capability manifests.

The ranker is intentionally advisory. It cannot create connectivity, infer
provider authorization, or replace explicit capability ids/roles. It ranks the
connected specs the host already supplied and returns no recommendation when
there is no positive lexical evidence.
"""

import re
from typing import Iterable

from jigaewol_runtime.vendor.rank_bm25_plus import BM25Plus

_TOKEN_RE = re.compile(r"[^\W_]+", flags=re.UNICODE)


def _tokens(value: str) -> list[str]:
    return [x.casefold() for x in _TOKEN_RE.findall(value)]


def _text_parts(spec: dict) -> Iterable[str]:
    for key in ("id", "plugin", "provider", "operation", "role", "description"):
        value = spec.get(key)
        if isinstance(value, str) and value.strip():
            yield value
    for key in ("tags", "modalities_in", "modalities_out"):
        value = spec.get(key, ())
        if isinstance(value, (list, tuple, set, frozenset)):
            for item in value:
                if isinstance(item, str) and item.strip():
                    yield item


def rank_capabilities(need: str, specs) -> list[tuple[dict, float]]:
    if not isinstance(need, str):
        raise ValueError("capability need must be text")
    need = need.strip()
    if not need:
        return []
    if isinstance(specs, (str, bytes)) or not isinstance(specs, (list, tuple)):
        raise ValueError("capability specs must be a list or tuple")

    checked: list[dict] = []
    corpus: list[list[str]] = []
    for spec in specs:
        if not isinstance(spec, dict) or not isinstance(spec.get("id"), str) or not spec["id"].strip():
            raise ValueError("each capability spec needs a nonempty text id")
        checked.append(spec)
        corpus.append(_tokens(" ".join(_text_parts(spec))))
    if not checked:
        return []

    query = _tokens(need)
    if not query:
        return []
    scores = BM25Plus(corpus).get_scores(query)
    if not scores or max(scores, default=0.0) <= 0.0:
        return []

    query_tokens = set(query)
    ranked = sorted(
        enumerate(scores),
        key=lambda item: (-float(item[1]), item[0]),
    )
    return [
        (checked[idx], float(score))
        for idx, score in ranked
        if score > 0.0 and query_tokens.intersection(corpus[idx])
    ]
