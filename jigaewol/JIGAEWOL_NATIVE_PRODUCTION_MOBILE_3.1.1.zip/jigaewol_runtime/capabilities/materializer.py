from __future__ import annotations

"""Open-set materialization planning for unfamiliar capability sources.

The planner deliberately separates discovery, source retrieval, static inspection,
isolated execution and integration.  A plan is not execution evidence.  It uses
only actions that the current HOST has explicitly declared callable and keeps
unknown source kinds open rather than treating a fixed provider list as ontology.
"""

from copy import deepcopy
from dataclasses import asdict, dataclass
from typing import Any
from urllib.parse import urlparse
import re

from .action_router import declared_actions
from .manifest import capability_is_callable, normalize_capabilities
from .execution_routes import capability_traits


@dataclass(frozen=True)
class MaterializationStep:
    stage: str
    capability_id: str | None
    host_action: str | None
    arguments: dict[str, Any]
    truth_transition: str
    isolation: str
    depends_on: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _candidate_dict(candidate) -> dict[str, Any]:
    if isinstance(candidate, dict):
        return deepcopy(candidate)
    if hasattr(candidate, "__dataclass_fields__"):
        return asdict(candidate)
    raise ValueError("candidate must be a mapping or dataclass")


def _surface(capabilities) -> dict[str, dict[str, Any]]:
    out = {}
    for spec in normalize_capabilities(capabilities or ()):
        if not capability_is_callable(spec):
            continue
        out[str(spec["id"]).casefold()] = spec
    return out


def _has(spec: dict[str, Any] | None, action: str) -> bool:
    return bool(spec and action in declared_actions(spec))


def _github_repo(source_ref: str) -> tuple[str, str] | None:
    try:
        u = urlparse(source_ref)
    except Exception:
        return None
    if u.netloc.casefold() not in {"github.com", "www.github.com"}:
        return None
    parts = [p for p in u.path.split("/") if p]
    if len(parts) < 2:
        return None
    owner, repo = parts[0], re.sub(r"\.git$", "", parts[1])
    return owner, repo


def _container_isolated_command(source_ref: str) -> list[str]:
    # The source URL is passed as argv rather than interpolated into shell syntax.
    script = r'''set -euo pipefail
src="$1"
root="$(mktemp -d)"
trap 'rm -rf "$root"' EXIT
repo="$root/repo"
git clone --depth 1 -- "$src" "$repo"
cd "$repo"
printf 'JIGAEWOL_MATERIALIZE_ROOT=%s\n' "$repo"
printf 'FILES=%s\n' "$(find . -type f | wc -l | tr -d ' ')"
for f in pyproject.toml requirements.txt package.json package-lock.json pnpm-lock.yaml yarn.lock Cargo.toml go.mod Gemfile README.md LICENSE LICENSE.md COPYING; do
  [ -f "$f" ] && printf 'FOUND=%s\n' "$f"
done
if [ -f package.json ]; then node -e 'const p=require("./package.json"); console.log("PACKAGE_SCRIPTS="+JSON.stringify(p.scripts||{})); console.log("PACKAGE_ENGINES="+JSON.stringify(p.engines||{}))'; fi
if [ -f pyproject.toml ]; then python3 - <<'PY2'
from pathlib import Path
print('PYPROJECT_HEAD='+Path('pyproject.toml').read_text(errors='replace')[:3000].replace('\n','\\n'))
PY2
fi
'''
    return ["bash", "-lc", script, "jigaewol-materializer", source_ref]


def _floot_isolated_code(source_ref: str) -> str:
    repo = _github_repo(source_ref)
    if not repo:
        return "console.log(JSON.stringify({ok:false,reason:'source_ref_not_supported_by_floot_archive_probe'}))"
    owner, name = repo
    archive = f"https://codeload.github.com/{owner}/{name}/zip/HEAD"
    # No credentials are read and the archive is inspected only in Floot's isolated temp dir.
    return f'''const {{execFileSync}}=await import('node:child_process');
const fs=await import('node:fs');
const url={archive!r};
const r=await fetch(url,{{redirect:'follow'}});
if(!r.ok) throw new Error('archive fetch '+r.status);
const b=Buffer.from(await r.arrayBuffer()); fs.writeFileSync('repo.zip',b);
execFileSync('python3',['-m','zipfile','-e','repo.zip','repo'],{{stdio:'ignore'}});
const top=fs.readdirSync('repo')[0]; const root='repo/'+top;
const names=[]; const walk=(p)=>{{for(const n of fs.readdirSync(p)){{const q=p+'/'+n; const st=fs.statSync(q); if(st.isDirectory()) walk(q); else names.push(q.slice(root.length+1));}}}}; walk(root);
console.log(JSON.stringify({{ok:true,source:url,file_count:names.length,manifests:names.filter(n=>/^(package\\.json|pyproject\\.toml|requirements\\.txt|Cargo\\.toml|go\\.mod|Gemfile|README(?:\\.md)?|LICENSE(?:\\.md)?)$/i.test(n)).slice(0,50)}}));'''


def plan_open_source_materialization(candidate, capabilities, *, execution_handles=()) -> dict[str, Any]:
    row = _candidate_dict(candidate)
    source_ref = str(row.get("source_ref") or "").strip()
    if not source_ref:
        raise ValueError("candidate source_ref is required")
    source_kind = str(row.get("source_kind") or row.get("source_type") or "unknown").strip()
    inspection = deepcopy(row.get("inspection") or {})
    placement = str(inspection.get("recommended_placement") or "isolated_execution_first")
    caps = _surface(capabilities)
    steps: list[MaterializationStep] = []

    github = caps.get("github")
    tinyfish = caps.get("tinyfish")
    firecrawl = caps.get("firecrawl")
    container = caps.get("container")
    floot = caps.get("floot")

    if _has(github, "fetch") and ("github" in source_kind.casefold() or _github_repo(source_ref)):
        steps.append(MaterializationStep(
            "retrieve_source_metadata", github["id"], "fetch", {"url": source_ref},
            "source_observed_not_executed", "read_only_connector",
        ))
    elif _has(tinyfish, "fetch_content") and source_ref.startswith(("https://", "http://")):
        steps.append(MaterializationStep(
            "retrieve_source_metadata", tinyfish["id"], "fetch_content",
            {"urls": [source_ref], "purpose": "Inspect capability source before isolated materialization", "format": "markdown", "links": True, "image_links": False, "page_metadata": True, "ttl": 0},
            "source_observed_not_executed", "read_only_browser_fetch",
        ))
    elif _has(firecrawl, "firecrawl_scrape") and source_ref.startswith(("https://", "http://")):
        steps.append(MaterializationStep(
            "retrieve_source_metadata", firecrawl["id"], "firecrawl_scrape",
            {"url": source_ref, "formats": ["markdown", "links"], "maxAge": 0},
            "source_observed_not_executed", "read_only_web_fetch",
        ))

    steps.append(MaterializationStep(
        "static_preflight", None, None,
        {"candidate_id": row.get("candidate_id"), "inspection_required": True, "source_ref": source_ref},
        "static_signals_only_not_malware_clearance", "no_execution",
        tuple(x.stage for x in steps[-1:]),
    ))

    # A remote clone requires network evidence. Merely having a shell is not enough.
    container_traits = set(capability_traits(container)) if container else set()
    remote_source = source_ref.startswith(("https://", "http://"))
    container_can_retrieve = bool(_has(container, "exec") and (not remote_source or "network" in container_traits))
    if container_can_retrieve and _github_repo(source_ref):
        steps.append(MaterializationStep(
            "isolated_materialize", container["id"], "exec",
            {"cmd": _container_isolated_command(source_ref)},
            "materialized_in_ephemeral_sandbox_not_integrated", placement,
            ("static_preflight",),
        ))
    elif _has(floot, "run_code_in_vm") and _github_repo(source_ref):
        project_id = None
        for handle in execution_handles or ():
            if not isinstance(handle, dict):
                continue
            if str(handle.get("capability_id") or "").casefold() == "floot":
                project_id = handle.get("project_id") or handle.get("projectId") or handle.get("handle_id")
                if project_id:
                    break
        if project_id:
            steps.append(MaterializationStep(
                "isolated_materialize", floot["id"], "run_code_in_vm",
                {"projectId": str(project_id), "code": _floot_isolated_code(source_ref), "timeout_seconds": 120},
                "materialized_in_isolated_remote_vm_not_integrated", placement,
                ("static_preflight",),
            ))

    executable = any(x.stage == "isolated_materialize" for x in steps)
    gaps = []
    if not executable:
        gaps.append("no_schema_correct_isolated_materialization_action_currently_callable")
    if not any(x.stage == "retrieve_source_metadata" for x in steps):
        gaps.append("no_source_retrieval_action_currently_callable")

    return {
        "candidate_id": row.get("candidate_id"),
        "source_kind": source_kind,
        "source_ref": source_ref,
        "recommended_placement": placement,
        "steps": [x.to_dict() for x in steps],
        "materialization_route_available": executable,
        "gaps": gaps,
        "integration_gate": "requires_real_execution_evidence_then_task_specific_probe",
        "unknown_source_policy": "open_intake_with_observed_execution_isolation",
        "secret_policy": "untrusted_source_receives_no_host_secrets_by_default",
        "truth_boundary": "plan_is_not_execution_and_static_preflight_is_not_malware_clearance",
    }
