from __future__ import annotations

"""Conservative handle extraction for known callable HOST providers.

Only providers with stable, explicit identifiers are recognized.  Unknown
providers never gain a fabricated persistent-session claim from generic prose.
"""
from copy import deepcopy


def _first(mapping, *keys):
    if not isinstance(mapping, dict):
        return None
    for key in keys:
        value=mapping.get(key)
        if isinstance(value,(str,int)) and str(value).strip():
            return str(value).strip()
    return None


def _nested_dicts(value):
    if not isinstance(value,dict):
        return ()
    rows=[value]
    for key in ("result","data","project","task","run","session"):
        item=value.get(key)
        if isinstance(item,dict): rows.append(item)
    return tuple(rows)


def _find(value,*keys):
    for row in _nested_dicts(value):
        found=_first(row,*keys)
        if found is not None: return found
    return None


def derive_known_execution_handles(work, output, origin_ref: str) -> tuple[dict, ...]:
    operation=str(getattr(work,"operation","") or "")
    capability=operation.removeprefix("capability.")
    params=deepcopy(getattr(work,"parameters",{}) or {})
    cap=capability.casefold()
    op=operation.casefold()
    handles=[]

    if cap == "floot":
        project_id=_first(params,"projectId","project_id") or _find(output,"projectId","project_id")
        if project_id is None and "create_project" in op:
            project_id=_find(output,"id","projectId","project_id")
        if project_id:
            handles.append({
                "kind":"vm_workspace","provider":"Floot","handle_id":project_id,
                "origin_ref":origin_ref,"observed_alive":True,
                "metadata":{"operation":operation,"project_id":project_id,"persistence":"provider_workspace"},
            })
    elif cap == "tinyfish":
        run_id=_find(output,"runId","run_id")
        if run_id:
            handles.append({
                "kind":"browser_session","provider":"TinyFish","handle_id":run_id,
                "origin_ref":origin_ref,"observed_alive":True,
                "metadata":{"operation":operation,"run_id":run_id,"interaction_surface":"live_browser_automation"},
            })
    elif cap == "manus":
        task_id=_find(output,"task_id","taskId")
        if task_id:
            handles.append({
                "kind":"agent_job","provider":"Manus","handle_id":task_id,
                "origin_ref":origin_ref,"observed_alive":True,
                "metadata":{"operation":operation,"task_id":task_id,"delegate":"external_agent"},
            })
    elif cap == "opera_browser_connector":
        tab_id=_first(params,"tabId","tab_id") or _find(output,"tabId","tab_id")
        if tab_id:
            handles.append({
                "kind":"browser_session","provider":"Opera_Browser_Connector","handle_id":"tab:"+tab_id,
                "origin_ref":origin_ref,"observed_alive":True,
                "metadata":{"operation":operation,"tab_id":tab_id,"session_scope":"user_browser_tab"},
            })
    # Remote Desktop Commander is intentionally not inferred until its actual
    # callable action schema is visible in this host.  Installed metadata alone
    # must never fabricate a device/session identifier.
    return tuple(handles)
