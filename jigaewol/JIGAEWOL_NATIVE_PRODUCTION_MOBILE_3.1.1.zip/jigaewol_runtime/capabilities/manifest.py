"""Rich observed capability manifests.

JIGAEWOL never executes providers directly.  A manifest only describes an
available HOST execution interface well enough for cognition to choose among tools and to
form schema-correct arguments.  The actual invocation remains in HOST.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field, asdict
import math
from typing import Any


ROLE_ALIASES = {
    "python": "compute", "py": "compute", "compute": "compute",
    "github": "code_repository", "repository": "code_repository", "repo": "code_repository",
    "web": "search", "web_search": "search", "browser": "search", "research": "search",
    "academic": "academic_search", "scholar": "academic_search", "literature": "academic_search",
    "image": "image_generation", "image_gen": "image_generation", "image_generation": "image_generation",
    "vision": "image_analysis", "image_analysis": "image_analysis",
    "analytics": "analytics", "knowledge_base": "knowledge_base", "docs": "documentation",
    # Current host namespaces may arrive as bare callable ids after bootstrap.
    # These aliases only describe a capability that HOST already declared
    # callable; they never turn an installed/unseen plugin into a callable one.
    "floot": "compute",
    "tinyfish": "search",
    "firecrawl": "search",
    "exa": "search",
    "parallel_search": "search",
    "tavily_ai": "search",
    "notion": "knowledge_base",
    "google_drive": "knowledge_base",
    "manus": "agent_delegate",
    "opera_browser_connector": "browser",
    "metricool_for_social_media": "analytics",
}


KNOWN_CALLABLE_HINTS = {
    "floot": {
        "description": "Persistent hosted project/VM surface with code execution, tests, network access, files and deployment.",
        "tags": ("code execution", "persistent workspace", "vm", "network access", "deploy"),
    },
    "tinyfish": {
        "description": "Live browser search and user-directed web automation with navigation, click, forms, optional login flows and dynamic page state. A signed-in profile must be observed separately before authenticated-feed capability is claimed.",
        "tags": ("browser", "interaction", "web search"),
    },
    "opera_browser_connector": {
        "description": "Connected user browser sensor for open tabs, authenticated page content, screenshots, history and navigation.",
        "tags": ("browser", "authenticated session", "tabs"),
    },
    "notion": {
        "description": "Persistent connected knowledge workspace with searchable pages/databases and write actions exposed by HOST.",
        "tags": ("knowledge base", "persistent workspace"),
    },
    "google_drive": {
        "description": "Persistent connected files/documents workspace with search, read and file actions exposed by HOST.",
        "tags": ("knowledge base", "files", "persistent workspace"),
    },
    "github": {
        "description": "Connected source repository surface for files, branches, commits, pull requests and repository evidence.",
        "tags": ("repository", "commit", "branch", "pull request"),
    },
    "manus": {
        "description": "External delegate surface for autonomous multi-step projects when its task actions are callable.",
        "tags": ("agent_delegate", "external agent delegate"),
    },
    "firecrawl": {"description": "Web search, extraction and crawling surface.", "tags": ("web search", "crawl")},
    "exa": {"description": "Semantic web search and retrieval surface.", "tags": ("web search", "retrieval")},
    "parallel_search": {"description": "Parallel web search and content extraction surface.", "tags": ("web search", "retrieval")},
    "tavily_ai": {"description": "Current web search, extraction and research surface.", "tags": ("web search", "research")},
    "metricool_for_social_media": {
        "description": "Connected social analytics, planning and scheduling surface; not a public social firehose.",
        "tags": ("social analytics", "schedule posts"),
    },
    "container": {
        "description": "Ephemeral local shell/filesystem execution surface supplied by HOST.",
        "tags": ("terminal", "filesystem", "code execution", "run commands"),
    },
    "python": {
        "description": "Stateful Python execution surface supplied by HOST.",
        "tags": ("code execution", "python snippet"),
    },
}


def _callable_hint_key(capability_id: str) -> str:
    return capability_id.strip().casefold().replace(" ", "_").replace("-", "_")


def _text(value, label, *, optional=False, allow_empty=False):
    if value is None and optional:
        return None
    if not isinstance(value, str):
        raise ValueError(label + " must be text" + (" or None" if optional else ""))
    value = value.strip()
    if not allow_empty and not value:
        raise ValueError(label + " must be nonempty text")
    return value


def _text_list(value, label):
    if value is None:
        return []
    if not isinstance(value, (list, tuple)) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError(label + " must be a list of nonempty text values")
    return [item.strip() for item in value]


def _schema(value):
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("capability input_schema must be an object")
    return deepcopy(value)


def _cost(value) -> float:
    if isinstance(value, bool):
        raise ValueError("capability cost must be a finite nonnegative number")
    try:
        cost = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("capability cost must be a finite nonnegative number") from exc
    if not math.isfinite(cost) or cost < 0:
        raise ValueError("capability cost must be a finite nonnegative number")
    return cost


def canonical_role(capability_id: str, role: str | None) -> str | None:
    if not isinstance(capability_id, str):
        raise ValueError("capability_id must be text")
    if role is not None and not isinstance(role, str):
        raise ValueError("capability role must be text or None")
    raw = (role or "").strip().lower()
    cid = capability_id.strip().lower()
    return ROLE_ALIASES.get(raw, ROLE_ALIASES.get(cid, raw or None))


@dataclass(frozen=True)
class CapabilityManifest:
    capability_id: str
    role: str | None = None
    description: str = ""
    permission_class: str = "none"
    cost_latency_hint: float = .5
    provider: str | None = None
    plugin: str | None = None
    operation: str | None = None
    input_schema: dict[str, Any] = field(default_factory=dict)
    output_schema: str = "capability.result"
    modalities_in: tuple[str, ...] = ()
    modalities_out: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    feedback_kind: str = "tool_observation"
    evaluator_id: str | None = None

    def to_spec(self) -> dict[str, Any]:
        return _normalize_capability_dict(asdict(self))


def _normalize_capability_dict(cap: dict[str, Any]) -> dict[str, Any]:
    cid = cap.get("id", cap.get("capability_id", cap.get("name")))
    cid = _text(cid, "capability id")
    hint = KNOWN_CALLABLE_HINTS.get(_callable_hint_key(cid), {})
    permission = cap.get("permission", cap.get("permission_class", "none"))
    permission = _text(permission, "capability permission")
    feedback_kind = _text(cap.get("feedback_kind", "tool_observation"), "capability feedback_kind")
    evaluator_id = _text(cap.get("evaluator_id"), "capability evaluator_id", optional=True)
    description = cap.get("description", hint.get("description", ""))
    if not isinstance(description, str):
        raise ValueError("capability description must be text")
    provider = _text(cap.get("provider"), "capability provider", optional=True)
    plugin = _text(cap.get("plugin"), "capability plugin", optional=True)
    operation = _text(cap.get("operation"), "capability operation", optional=True)
    output_schema = _text(cap.get("output_schema", "capability.result"), "capability output_schema")
    known = {
        "id": cid,
        "role": canonical_role(cid, cap.get("role")),
        "permission": permission,
        "cost": _cost(cap.get("cost", cap.get("cost_latency_hint", .5))),
        "feedback_kind": feedback_kind,
        "evaluator_id": evaluator_id,
        "description": description,
        "provider": provider,
        "plugin": plugin,
        "operation": operation,
        "input_schema": _schema(cap.get("input_schema")),
        "output_schema": output_schema,
        "modalities_in": _text_list(cap.get("modalities_in", ()), "capability modalities_in"),
        "modalities_out": _text_list(cap.get("modalities_out", ()), "capability modalities_out"),
        "tags": list(dict.fromkeys(
            _text_list(hint.get("tags", ()), "capability hint tags")
            + _text_list(cap.get("tags", ()), "capability tags")
        )),
    }
    # HOST integrations may attach extra descriptive fields. Preserve them;
    # executable authority still comes only from the connected handler.
    for key, value in cap.items():
        if key not in known and key not in {"capability_id", "permission_class", "cost_latency_hint"}:
            known[key] = deepcopy(value)
    return {k: v for k, v in known.items() if v not in (None, "", [], {}) or k in {"id", "permission", "cost"}}




_CALLABLE_STATES = frozenset({
    "callable", "ready", "live", "available", "observed_callable",
    "connected_callable", "executed_successfully", "proven_callable",
})
_NONCALLABLE_STATES = frozenset({
    "catalog_visible", "installed", "connected", "disconnected", "unavailable",
    "unknown", "pending", "not_connected", "stale_unprobed", "stale_revalidation_required", "registered",
})

def capability_is_callable(spec: dict[str, Any]) -> bool:
    """Return whether a manifest row belongs on the executable surface.

    Executability is evidence-bound. A row without an explicit observed callable state
    is catalog information only and cannot become execution authority by omission.
    """
    if not isinstance(spec, dict):
        return False
    state = spec.get("state")
    if state is None:
        return False
    if not isinstance(state, str) or not state.strip():
        return False
    state = state.strip().casefold().replace("-", "_").replace(" ", "_")
    if state in _CALLABLE_STATES:
        return True
    if state in _NONCALLABLE_STATES:
        return False
    # Unknown explicit states are evidence, not authority.
    return False

def normalize_capability(cap) -> dict[str, Any]:
    if isinstance(cap, CapabilityManifest):
        return cap.to_spec()
    if isinstance(cap, dict):
        return _normalize_capability_dict(cap)

    cid = getattr(cap, "capability_id", None)
    if cid is None:
        raise ValueError("capability object needs an explicit capability_id; explicit text capability_id required")
    data = {
        "capability_id": cid,
        "role": getattr(cap, "role", None),
        "permission_class": getattr(cap, "permission_class", "none"),
        "cost_latency_hint": getattr(cap, "cost_latency_hint", .5),
        "feedback_kind": getattr(cap, "feedback_kind", "tool_observation"),
        "evaluator_id": getattr(cap, "evaluator_id", None),
        "description": getattr(cap, "description", ""),
        "provider": getattr(cap, "provider", None),
        "plugin": getattr(cap, "plugin", None),
        "operation": getattr(cap, "operation", None),
        "input_schema": getattr(cap, "input_schema", {}),
        "output_schema": getattr(cap, "output_schema", "capability.result"),
        "modalities_in": getattr(cap, "modalities_in", ()),
        "modalities_out": getattr(cap, "modalities_out", ()),
        "tags": getattr(cap, "tags", ()),
    }
    return _normalize_capability_dict(data)


def normalize_capabilities(capabilities) -> list[dict[str, Any]]:
    if capabilities is None:
        return []
    if isinstance(capabilities, (str, bytes)) or not isinstance(capabilities, (list, tuple)):
        raise ValueError("capabilities must be a list or tuple of connected capability descriptors")
    normalized = [normalize_capability(cap) for cap in capabilities]
    ids = [cap["id"] for cap in normalized]
    if len(ids) != len(set(ids)):
        raise ValueError("connected capability ids must be unique")
    return normalized


def _matches_type(value, expected: str) -> bool:
    return {
        "object": isinstance(value, dict),
        "array": isinstance(value, (list, tuple)),
        "string": isinstance(value, str),
        "number": isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value)),
        "integer": isinstance(value, int) and not isinstance(value, bool),
        "boolean": isinstance(value, bool),
        "null": value is None,
    }.get(expected, True)


JIGAEWOL_CONTROL_PARAMETER_KEYS = frozenset({
    "observation_policy", "search_branch_ids", "search_cycle_epoch",
    "research_route_basis", "always_run", "jigaewol_github_pulse",
    "decision_relevant", "method_job", "feedback_job", "integration_job",
    "jigaewol_external_kernel",
    # Research lineage belongs to the cognition kernel, not the provider API.
    "hypothesis", "mechanism", "discriminator", "decision_effect",
    "source_culture", "language", "representation_shift",
})


def provider_arguments(spec: dict[str, Any], parameters: dict[str, Any]) -> dict[str, Any]:
    """Return provider-owned arguments without leaking JIGAEWOL control metadata.

    Full parameters remain on HostWork so the runtime can route observations and
    reassess them. Only the provider-facing invocation is filtered. A strict
    manifest (``additionalProperties: false``) additionally receives only fields
    declared by its schema.
    """
    if not isinstance(spec, dict):
        raise ValueError("capability spec must be an object")
    if not isinstance(parameters, dict):
        raise ValueError("capability parameters must be an object")
    if any(not isinstance(key, str) for key in parameters):
        raise ValueError("capability parameter names must be text")
    values = deepcopy(parameters)
    values = {
        key: value for key, value in values.items()
        if key not in JIGAEWOL_CONTROL_PARAMETER_KEYS and not key.startswith("_jigaewol_")
    }
    schema = spec.get("input_schema") or {}
    if not isinstance(schema, dict):
        raise ValueError("capability input_schema must be an object")
    props = schema.get("properties") or {}
    if schema.get("additionalProperties") is False and isinstance(props, dict):
        values = {key: value for key, value in values.items() if key in props}
    return values


def validate_parameters(spec: dict[str, Any], parameters: dict[str, Any]) -> None:
    """Validate the small JSON-Schema subset needed at the HOST execution interface.

    Complex provider schemas are still enforced by the real HOST tool.  This
    catches the common planning errors early without pretending JIGAEWOL owns tool
    permissions or provider validation.
    """
    if not isinstance(spec, dict):
        raise ValueError("capability spec must be an object")
    schema = spec.get("input_schema") or {}
    if not isinstance(schema, dict):
        raise ValueError("capability input_schema must be an object")
    if not schema:
        return
    schema_type = schema.get("type")
    if schema_type is not None and not isinstance(schema_type, str):
        raise ValueError("capability input_schema type must be text when locally validated")
    if schema_type and not _matches_type(parameters, schema_type):
        raise ValueError(f"capability {spec['id']} parameters do not match input_schema type")
    if not isinstance(parameters, dict):
        return
    for name in schema.get("required", ()) or ():
        if name not in parameters:
            raise ValueError(f"capability {spec['id']} missing required parameter: {name}")
    props = schema.get("properties") or {}
    if isinstance(props, dict):
        for name, rule in props.items():
            if name not in parameters or not isinstance(rule, dict) or not rule.get("type"):
                continue
            expected = rule["type"]
            types = expected if isinstance(expected, list) else [expected]
            if not types or any(not isinstance(t, str) for t in types):
                raise ValueError(f"capability {spec['id']} parameter {name} schema type must be text")
            if not any(_matches_type(parameters[name], t) for t in types):
                raise ValueError(f"capability {spec['id']} parameter {name} has invalid type")
