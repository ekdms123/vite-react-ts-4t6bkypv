from dataclasses import dataclass

from jigaewol_runtime.capabilities.provider_handles import derive_known_execution_handles
from jigaewol_runtime.capabilities.execution_envelope import (
    normalize_execution_handles,
    normalize_execution_probes,
)


@dataclass(frozen=True)
class ToolInvocationResult:
    output: object
    origin_ref: str
    effect_refs: tuple[str, ...] = ()
    source_urls: tuple[str, ...] = ()
    execution_handles: tuple[dict, ...] = ()
    execution_probes: tuple[dict, ...] = ()

    def as_payload(self) -> dict:
        return {
            "output": self.output,
            "origin_ref": self.origin_ref,
            "effect_refs": list(self.effect_refs),
            "source_urls": list(self.source_urls),
            "execution_handles": [dict(x) for x in self.execution_handles],
            "execution_probes": [dict(x) for x in self.execution_probes],
        }


def _text_refs(value, label):
    if value is None:
        return ()
    if isinstance(value, str) or not isinstance(value, (list, tuple)):
        raise ValueError(label + " must be a list/tuple of text refs")
    if any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError(label + " must contain nonempty text refs")
    return tuple(item.strip() for item in value)


class HostToolAdapter:
    def invoke(self, work, host_call):
        result = host_call(work.operation, work)
        if isinstance(result, ToolInvocationResult):
            if not isinstance(result.origin_ref, str) or not result.origin_ref.strip():
                raise ValueError("tool result requires text origin_ref")
            effects = _text_refs(result.effect_refs, "tool result effect_refs")
            urls = _text_refs(result.source_urls, "tool result source_urls")
            handles = normalize_execution_handles(result.execution_handles, default_origin_ref=result.origin_ref)
            probes = normalize_execution_probes(result.execution_probes, default_origin_ref=result.origin_ref)
            return ToolInvocationResult(result.output, result.origin_ref.strip(), effects, urls, handles, probes)
        if isinstance(result, dict):
            origin_ref = result.get("origin_ref")
            if not isinstance(origin_ref, str) or not origin_ref.strip() or "output" not in result:
                raise ValueError("tool result requires actual output and text origin_ref")
            origin_ref = origin_ref.strip()
            handles = normalize_execution_handles(result.get("execution_handles", ()), default_origin_ref=origin_ref)
            if not handles:
                handles = normalize_execution_handles(
                    derive_known_execution_handles(work, result["output"], origin_ref), default_origin_ref=origin_ref
                )
            return ToolInvocationResult(
                result["output"], origin_ref,
                _text_refs(result.get("effect_refs", ()), "tool result effect_refs"),
                _text_refs(result.get("source_urls", ()), "tool result source_urls"),
                handles,
                normalize_execution_probes(result.get("execution_probes", ()), default_origin_ref=origin_ref),
            )
        if not isinstance(result, tuple) or len(result) < 2:
            raise ValueError("host_call must return (output, origin_ref[, effect_refs[, source_urls[, execution_handles[, execution_probes]]]])")
        output, origin_ref, *rest = result
        if not isinstance(origin_ref, str) or not origin_ref.strip():
            raise ValueError("tool result requires text origin_ref")
        if len(rest) > 4:
            raise ValueError("host_call tuple supports output, origin_ref, optional effect_refs, source_urls, execution_handles and execution_probes")
        effects = _text_refs(rest[0], "tool result effect_refs") if rest else ()
        source_urls = _text_refs(rest[1], "tool result source_urls") if len(rest) > 1 else ()
        handles = normalize_execution_handles(rest[2], default_origin_ref=origin_ref) if len(rest) > 2 else ()
        if not handles:
            handles = normalize_execution_handles(
                derive_known_execution_handles(work, output, origin_ref), default_origin_ref=origin_ref
            )
        probes = normalize_execution_probes(rest[3], default_origin_ref=origin_ref) if len(rest) > 3 else ()
        return ToolInvocationResult(output, origin_ref.strip(), effects, source_urls, handles, probes)
