"""Capability adapters."""
