from __future__ import annotations

import re

# Public-web search is an actuator request, so it is intentionally inferred narrowly.
# Generic discovery words such as "찾아/find/research" are not enough by themselves:
# they may refer to code, files, a supplied document, a private corpus, or reasoning.
_PUBLIC_SCOPE_MARKERS = (
    "웹", "인터넷", "온라인", "공개 웹", "검색엔진", "구글", "google",
    "뉴스", "최신", "요즘", "유행", "트렌드", "최신 웹", "웹에서", "인터넷에서", "온라인에서", "외부 자료", "외부 출처", "외부 소스",
    "web", "internet", "online", "search engine", "news", "external sources", "external material",
    "reddit", "레딧", "커뮤니티", "포럼", "forum", "twitter", "트위터",
    "x.com", "instagram", "인스타", "tiktok", "틱톡", "github", "깃허브",
)
_LOCAL_SCOPE_MARKERS = (
    "이 파일", "그 파일", "파일에서", "코드에서", "이 코드", "그 코드", "코드베이스",
    "저장소", "repo 안", "repository 안", "zip", "압축파일", "첨부", "업로드",
    "문서에서", "이 문서", "폴더", "로컬", "runtime", "런타임", "패키지 안",
)
_STRONG_WEB_PHRASES = (
    "웹 검색", "인터넷 검색", "온라인 검색", "구글 검색", "검색엔진에서",
    "search the web", "web search", "search online", "browse the web", "look up online",
)
_NEGATION_RE = re.compile(
    r"(?:하지\s*마|하지말|보지\s*마|말고|말아|않고|않아|금지|제외|빼고|"
    r"(?:할\s*)?필요(?:는|가)?\s*(?:없|없습니다|없어요)|"
    r"\bdo\s+not\b|\bdon['’]?t\b|\bwithout\b|\bno\s+need\s+to\b)",
    re.IGNORECASE,
)
_QUOTED_PATTERNS = (r"```.*?```", r"`[^`]*`", r'"[^"\n]*"', r"“[^”\n]*”", r"‘[^’\n]*’")


def _mask_quoted(text: str) -> str:
    out = str(text or "")
    for pattern in _QUOTED_PATTERNS:
        out = re.sub(pattern, lambda m: " " * len(m.group(0)), out, flags=re.DOTALL)
    return out


def _live_occurrence(text: str, marker: str) -> bool:
    folded = _mask_quoted(text).casefold()
    needle = marker.casefold()
    start = 0
    while True:
        idx = folded.find(needle, start)
        if idx < 0:
            return False
        end = idx + len(needle)
        window = folded[max(0, idx - 16): min(len(folded), end + 18)]
        if not _NEGATION_RE.search(window):
            return True
        start = end


def explicit_public_search_requested(text: str) -> bool:
    """Return True only for a deterministic, explicit public/external search request.

    Rules are deliberately narrow and testable:
    * strong web phrases always count unless negated/quoted;
    * bare `검색`/standalone English `search` counts unless the user clearly scoped it
      to local code/files/documents;
    * generic discovery verbs (`찾아`, `조사`, `research`, `find`, `look up`) count only
      when a public/external source is explicitly named.
    """
    raw = str(text or "")
    folded = _mask_quoted(raw).casefold()
    if not folded.strip():
        return False

    if any(_live_occurrence(raw, phrase) for phrase in _STRONG_WEB_PHRASES):
        return True

    public_scope = any(marker.casefold() in folded for marker in _PUBLIC_SCOPE_MARKERS)
    local_scope = any(marker.casefold() in folded for marker in _LOCAL_SCOPE_MARKERS)

    # `검색` may be mentioned as a word/concept ("검색이라는 표현") rather than
    # requested as an action. Only command-like morphology activates the actuator.
    korean_search = bool(re.search(
        r"검색\s*(?:해(?:줘|주세요|라)?|하(?:자|고|여|면|는|도록|세요)?|좀)",
        folded,
    )) and _live_occurrence(raw, "검색")
    english_search = bool(re.search(
        r"\b(?:search\s+(?:for|the|on|online|web)|please\s+search|search\s+please)\b",
        folded,
    ))
    if (korean_search or english_search) and not (local_scope and not public_scope):
        return True

    discovery = (
        _live_occurrence(raw, "찾아")
        or _live_occurrence(raw, "뒤져")
        or _live_occurrence(raw, "조사")
        or bool(re.search(r"\bresearch\b", folded))
        or bool(re.search(r"\bfind\b", folded))
        or bool(re.search(r"\blook\s+up\b", folded))
    )
    return bool(public_scope and discovery)
