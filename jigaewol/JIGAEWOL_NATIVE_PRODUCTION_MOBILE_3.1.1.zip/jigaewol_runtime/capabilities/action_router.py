from __future__ import annotations

"""Action-level routing inside a callable provider namespace.

JIGAEWOL previously knew that a provider (for example Floot) was callable but not
which concrete provider action (run_code_in_vm, run_tests, ...) should execute a
step.  This module keeps provider discovery open-set while giving HOST a strict,
truth-preserving action dispatch contract.
"""

from copy import deepcopy
from dataclasses import dataclass
from typing import Callable, Any


_RESERVED_ACTION_KEYS = ("host_action", "provider_action", "action")


def _text(value, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def declared_actions(capability_spec: dict) -> tuple[str, ...]:
    if not isinstance(capability_spec, dict):
        return ()
    value = capability_spec.get("actions", ())
    if isinstance(value, str):
        value = (value,)
    if not isinstance(value, (list, tuple, set, frozenset)):
        return ()
    return tuple(dict.fromkeys(str(x).strip() for x in value if isinstance(x, str) and x.strip()))


def requested_action(parameters: dict | None, *, default: str | None = None) -> str | None:
    params = parameters or {}
    if not isinstance(params, dict):
        raise ValueError("action parameters must be an object")
    for key in _RESERVED_ACTION_KEYS:
        value = params.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return default.strip() if isinstance(default, str) and default.strip() else None


def provider_arguments_without_action(parameters: dict | None) -> dict:
    params = deepcopy(parameters or {})
    if not isinstance(params, dict):
        raise ValueError("action parameters must be an object")
    for key in _RESERVED_ACTION_KEYS:
        params.pop(key, None)
    return params


@dataclass(frozen=True)
class HostActionInvocation:
    capability_id: str
    action: str
    arguments: dict
    work_id: str
    turn_id: str
    task_id: str
    context: dict


class HostActionRouter:
    """Dispatch one JIGAEWOL capability namespace to concrete HOST actions.

    HOST registers the *actual callable actions* it exposes.  JIGAEWOL may request
    an action only by explicit name.  No fuzzy/substring dispatch is allowed.
    This prevents "provider is callable" from being mistaken for "every action
    described by its marketing page is callable".
    """

    def __init__(self):
        self._handlers: dict[str, dict[str, Callable[[HostActionInvocation], Any]]] = {}

    def register(self, capability_id: str, action: str, handler: Callable[[HostActionInvocation], Any]):
        capability_id = _text(capability_id, "capability_id")
        action = _text(action, "action")
        if not callable(handler):
            raise ValueError("action handler must be callable")
        bucket = self._handlers.setdefault(capability_id, {})
        if action in bucket:
            raise ValueError(f"action already registered: {capability_id}.{action}")
        bucket[action] = handler
        return self

    def actions(self, capability_id: str) -> tuple[str, ...]:
        capability_id = _text(capability_id, "capability_id")
        return tuple(sorted(self._handlers.get(capability_id, {})))

    def capability_handler(self, capability_id: str):
        capability_id = _text(capability_id, "capability_id")

        def handler(work):
            parameters = dict(getattr(work, "parameters", {}) or {})
            action = requested_action(parameters)
            if action is None:
                available = self.actions(capability_id)
                raise ValueError(
                    f"capability {capability_id} requires explicit host_action; available={available}"
                )
            fn = self._handlers.get(capability_id, {}).get(action)
            if fn is None:
                raise LookupError(f"HOST action not registered: {capability_id}.{action}")
            invocation = HostActionInvocation(
                capability_id=capability_id,
                action=action,
                arguments=provider_arguments_without_action(parameters),
                work_id=str(getattr(work, "work_id", "")),
                turn_id=str(getattr(work, "turn_id", "")),
                task_id=str(getattr(work, "task_id", "")),
                context=deepcopy(getattr(work, "context", {}) or {}),
            )
            return fn(invocation)

        return handler

    def tool_handlers(self) -> dict[str, Callable]:
        return {capability_id: self.capability_handler(capability_id) for capability_id in self._handlers}


def action_surface_snapshot(capabilities) -> tuple[dict, ...]:
    """Compact action-level view of the verified callable capability manifest."""
    from .manifest import normalize_capabilities, capability_is_callable
    rows=[]
    for spec in normalize_capabilities(capabilities or ()):
        if not capability_is_callable(spec):
            continue
        actions=declared_actions(spec)
        if not actions:
            continue
        rows.append({
            "capability_id":spec["id"],
            "role":spec.get("role"),
            "provider":spec.get("provider"),
            "plugin":spec.get("plugin"),
            "actions":actions,
            "truth_state":"declared_by_current_callable_host_manifest",
        })
    return tuple(rows)
