from __future__ import annotations

"""Authenticated-browser perception planning without conflating read and write authority."""


from dataclasses import asdict, dataclass
from typing import Any

from .action_router import declared_actions
from .manifest import capability_is_callable, normalize_capabilities


@dataclass(frozen=True)
class PerceptionStep:
    stage: str
    capability_id: str
    host_action: str
    arguments: dict[str, Any]
    action_class: str
    truth_transition: str
    continuation_from: str | None = None

    def to_dict(self):
        return asdict(self)


def _callable_specs(capabilities):
    return [x for x in normalize_capabilities(capabilities or ()) if capability_is_callable(x)]


def signed_in_perception_status(capabilities) -> dict[str, Any]:
    rows=[]
    for spec in _callable_specs(capabilities):
        actions=set(declared_actions(spec))
        cid=str(spec["id"])
        if "run_web_automation" in actions:
            rows.append({"capability_id":cid,"mode":"interactive_profile_browser","actions":sorted(actions),"truth":"callable_action_surface_not_logged_in_state"})
        elif {"list_tabs","tab_content"} <= actions:
            rows.append({"capability_id":cid,"mode":"attached_user_browser_sensor","actions":sorted(actions),"truth":"callable_connector_not_authenticated_tab_evidence"})
    return {
        "available": bool(rows),
        "routes": rows,
        "read_write_separated": True,
        "login_truth": "profile_or_tab_authentication_must_be_observed_by_real_host_call",
    }


def plan_signed_in_perception(objective: str, url: str, capabilities, *, profile_id: str | None = None, allow_account_mutation: bool = False) -> dict[str, Any]:
    objective=str(objective or "").strip()
    url=str(url or "").strip()
    if not objective or not url:
        raise ValueError("objective and url are required")
    specs=_callable_specs(capabilities)
    steps=[]

    for spec in specs:
        actions=set(declared_actions(spec)); cid=str(spec["id"])
        if "run_web_automation" in actions:
            goal=(
                "Observe the requested site for research. Read and navigate only: do not like, follow, "
                "comment, post, message, purchase, submit account changes, or alter settings. "
                "Inspect recommendation/feed/reply/repost signals where visible, scroll enough to gather "
                "multiple items, and return creators, timestamps, engagement signals, linked URLs, graph "
                "relationships, repeated phrases, slang and novel terms relevant to this objective: " + objective
            )
            # Keep provider tuning minimal on the first route. Optional beta knobs
            # are not assumed callable merely because the schema advertises them.
            args={
                "url":url,"goal":goal,"use_profile":True,"use_vault":False,
                "browser_profile":"stealth",
                "capture_config":{"elements":True,"snapshots":True,"screenshots":True,"recording":False,"html":False},
            }
            if profile_id:
                args["profile_id"]=profile_id
            steps.append(PerceptionStep(
                "observe_authenticated_surface",cid,"run_web_automation",args,"read_only_perception",
                "browser_run_started_not_completed",
            ))
            if "wait_for_run" in actions:
                steps.append(PerceptionStep(
                    "collect_observation",cid,"wait_for_run",{"run_id":"$previous.run_id"},"read_only_perception",
                    "terminal_browser_observation_required_for_evidence","observe_authenticated_surface",
                ))
            break

    if not steps:
        for spec in specs:
            actions=set(declared_actions(spec)); cid=str(spec["id"])
            if {"list_tabs","tab_content"} <= actions:
                steps.extend([
                    PerceptionStep("enumerate_user_tabs",cid,"list_tabs",{},"read_only_perception","tab_ids_observed"),
                    PerceptionStep("read_selected_tab",cid,"tab_content",{"tabId":"$selected_tab_id"},"read_only_perception","page_state_observed","enumerate_user_tabs"),
                ])
                break

    return {
        "objective":objective,"url":url,
        "steps":[x.to_dict() for x in steps],
        "route_available":bool(steps),
        "account_mutation_allowed":bool(allow_account_mutation),
        "default_action_class":"read_only_perception",
        "mutation_policy":"separate_explicit_action_path" if not allow_account_mutation else "explicitly_enabled_for_this_plan",
        "feed_to_search_loop":{
            "extract_novel_terms":True,"extract_creators":True,"extract_links":True,
            "extract_reply_repost_graph":True,"requery_observed_terms":True,"generate_counter_queries":True,
        },
        "truth_boundary":"callable_browser_is_not_logged_in_evidence_and_started_run_is_not_completed_observation",
    }
