from __future__ import annotations

"""Route a research probe to an actually connected HOST capability."""

from jigaewol_runtime.capabilities.manifest import canonical_role
from jigaewol_runtime.capabilities.ranker import rank_capabilities

_OBSERVATION_ROLES = {
    "search", "academic_search", "code_repository", "documentation", "compute",
    "analytics", "knowledge_base", "image_analysis", "image_generation",
}


def _heuristic_role(branch):
    parts = []
    for key in ("source_culture", "surface", "query", "mechanism"):
        value = branch.get(key, "")
        if value is not None and not isinstance(value, str):
            raise ValueError(f"research branch {key} must be text when provided")
        parts.append(value or "")
    text = " ".join(parts).casefold()
    if any(x in text for x in ("paper", "academic", "peer review", "citation", "scholar", "pubmed", "arxiv", "논문", "학술")):
        return "academic_search"
    if any(x in text for x in ("github", "repository", "repo", "source code", "open source", "오픈소스", "코드")):
        return "code_repository"
    if any(x in text for x in ("documentation", "library docs", "api docs", "reference manual", "문서")):
        return "documentation"
    if any(x in text for x in ("analytics", "experiment", "feature flag", "event telemetry", "product metric", "분석")):
        return "analytics"
    if any(x in text for x in ("workspace", "knowledge base", "notes", "notion", "coda", "지식베이스", "노트")):
        return "knowledge_base"
    if any(x in text for x in ("calculate", "equation", "symbolic", "exact numeric", "wolfram", "계산", "방정식")):
        return "compute"
    return "search"


def select_branch_capability(branch, specs, *, offset=0):
    if not isinstance(branch, dict):
        raise ValueError("research branch must be an object")
    if isinstance(offset, bool) or not isinstance(offset, int) or offset < 0:
        raise ValueError("research capability offset must be a nonnegative integer")
    if isinstance(specs, (str, bytes)) or not isinstance(specs, (list, tuple)):
        raise ValueError("connected capability specs must be a list or tuple")
    connected = []
    for spec in specs:
        if not isinstance(spec, dict) or not isinstance(spec.get("id"), str) or not spec["id"].strip():
            raise ValueError("connected capability specs must contain nonempty text ids")
        connected.append(spec)
    if not connected:
        raise ValueError("research branch requires an actually connected capability")

    requested_id = branch.get("capability_id", "")
    if requested_id is not None and not isinstance(requested_id, str):
        raise ValueError("research branch capability_id must be text")
    requested_id = (requested_id or "").strip()
    if requested_id:
        exact = next((x for x in connected if x["id"] == requested_id), None)
        if exact is not None:
            return exact, "exact_connected_capability"

    requested_role_value = branch.get("capability_role")
    if requested_role_value is not None and not isinstance(requested_role_value, str):
        raise ValueError("research branch capability_role must be text")
    requested_role = canonical_role(requested_id, requested_role_value.strip() if requested_role_value else None)
    if requested_role:
        candidates = [x for x in connected if canonical_role(x["id"], x.get("role")) == requested_role]
        if candidates:
            return candidates[offset % len(candidates)], "role_fallback_requested"

    need_value = branch.get("capability_need")
    if need_value is not None and not isinstance(need_value, str):
        raise ValueError("research branch capability_need must be text")
    if isinstance(need_value, str) and need_value.strip():
        ranked = rank_capabilities(need_value, connected)
        if ranked:
            return ranked[offset % len(ranked)][0], "need_ranked_connected_capability"

    role = _heuristic_role(branch)
    candidates = [x for x in connected if canonical_role(x["id"], x.get("role")) == role]
    if candidates:
        return candidates[offset % len(candidates)], "role_inferred_from_probe"

    generic_search = [x for x in connected if canonical_role(x["id"], x.get("role")) == "search"]
    if generic_search:
        return generic_search[offset % len(generic_search)], "generic_search_fallback"

    observational = [x for x in connected if canonical_role(x["id"], x.get("role")) in _OBSERVATION_ROLES]
    if observational:
        return observational[offset % len(observational)], "connected_observation_fallback"
    raise ValueError("no connected capability can execute this observation branch")
