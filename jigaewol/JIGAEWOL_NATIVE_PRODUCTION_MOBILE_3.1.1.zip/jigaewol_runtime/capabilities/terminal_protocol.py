from __future__ import annotations

"""Executable terminal action planning for the ordinary-chat cockpit."""

from copy import deepcopy
import json

from .execution_routes import capability_traits
from .manifest import normalize_capabilities


def _specs(capabilities):
    return {spec["id"]: spec for spec in normalize_capabilities(capabilities or ())}


def _actions(spec):
    values = spec.get("actions", ()) if isinstance(spec, dict) else ()
    if isinstance(values, str):
        values = (values,)
    if not isinstance(values, (list, tuple, set, frozenset)):
        return set()
    return {str(x).strip() for x in values if isinstance(x, str) and x.strip()}


def _shell_js(command: str) -> str:
    """Wrap an exact shell command for Floot's Node VM without string interpolation."""
    if not isinstance(command, str) or not command.strip():
        raise ValueError("terminal command must be nonempty text")
    encoded = json.dumps(command)
    return (
        'import { execFileSync } from "node:child_process";\n'
        f'const command = {encoded};\n'
        'try {\n'
        '  const out = execFileSync("/bin/sh", ["-lc", command], {encoding:"utf8", stdio:["ignore","pipe","pipe"]});\n'
        '  console.log(out);\n'
        '} catch (err) {\n'
        '  if (err.stdout) process.stdout.write(String(err.stdout));\n'
        '  if (err.stderr) process.stderr.write(String(err.stderr));\n'
        '  process.exit(Number.isInteger(err.status) ? err.status : 1);\n'
        '}\n'
    )


def terminal_command_plan(command: str, capabilities, execution_handles=(), *, prefer_persistent=True) -> dict:
    """Return the strongest truthful terminal action recipe available now.

    The result is a HOST execution recipe, not a claim that execution happened.
    A live provider handle is preferred over a namespace-only candidate.
    """
    if not isinstance(command, str) or not command.strip():
        raise ValueError("terminal command must be nonempty text")
    specs = _specs(capabilities)
    live = [deepcopy(x) for x in (execution_handles or ()) if isinstance(x, dict) and x.get("status") == "observed_alive"]

    # Authorized real-computer routes outrank hosted VMs only when the current
    # host exposes an explicit action schema. Never invent one from plugin prose.
    for row in live:
        if row.get("kind") != "remote_computer":
            continue
        spec = specs.get(str(row.get("provider", ""))) or specs.get("Remote_Desktop_Commander") or specs.get("remote_desktop_commander")
        actions = _actions(spec or {})
        terminal_action = next((x for x in ("run_command", "exec", "terminal_exec") if x in actions), None)
        if terminal_action:
            return {
                "status":"ready", "route":"remote_computer", "capability_id":spec["id"],
                "host_action":terminal_action, "handle":row,
                "arguments":{"handle_id":row["handle_id"], "command":command},
                "truth_state":"planned_from_observed_alive_handle_and_declared_action",
            }

    # Persistent Floot VM backplane.
    floot = specs.get("Floot") or specs.get("plugin.floot")
    floot_actions = _actions(floot or {})
    floot_handle = next((x for x in live if x.get("provider") == "Floot" and x.get("kind") == "vm_workspace"), None)
    if floot and floot_handle and "run_code_in_vm" in floot_actions:
        return {
            "status":"ready", "route":"persistent_vm", "capability_id":floot["id"],
            "host_action":"run_code_in_vm", "handle":floot_handle,
            "arguments":{"projectId":floot_handle["handle_id"], "code":_shell_js(command)},
            "truth_state":"planned_from_observed_alive_handle_and_declared_action",
        }

    # Session-local shell is still a real terminal, just not a durable backplane.
    local = specs.get("container")
    if local and "terminal" in set(capability_traits(local)):
        actions = _actions(local)
        action = "exec" if not actions or "exec" in actions else None
        if action:
            return {
                "status":"ready", "route":"session_local_terminal", "capability_id":"container",
                "host_action":action,
                "arguments":{"cmd":["bash","-lc",command]},
                "truth_state":"callable_session_local_terminal_not_persistent",
            }

    # Floot can create a durable workspace, but project id does not exist yet.
    if floot and {"create_project", "run_code_in_vm"}.issubset(floot_actions):
        return {
            "status":"bootstrap_required", "route":"persistent_vm", "capability_id":floot["id"],
            "steps":[
                {"host_action":"create_project", "arguments":{"name":"JIGAEWOL Terminal Backplane", "initial_prompt":"Persistent execution backplane for the current JIGAEWOL cockpit."}, "bind":"project"},
                {"host_action":"run_code_in_vm", "arguments":{"projectId":{"$ref":"project.projectId"}, "code":_shell_js(command)}},
            ],
            "truth_state":"workspace_creation_required_before_command",
        }

    return {
        "status":"unavailable", "route":None,
        "missing":["callable terminal action or persistent VM action schema"],
        "truth_state":"no executable terminal route proven on current host surface",
    }


def terminal_backplane_status(capabilities, execution_handles=()) -> dict:
    """Inventory usable terminal routes without inventing a command."""
    specs=_specs(capabilities)
    handles=[deepcopy(x) for x in (execution_handles or ()) if isinstance(x,dict)]
    live=[x for x in handles if x.get("status")=="observed_alive" and x.get("kind") in {"terminal_session","vm_workspace","remote_computer","workspace"}]
    stale=[x for x in handles if x.get("status") in {"stale_unprobed","registered"} and x.get("kind") in {"terminal_session","vm_workspace","remote_computer","workspace"}]
    candidates=[]
    for cid,spec in specs.items():
        traits=set(capability_traits(spec))
        actions=sorted(_actions(spec))
        if "terminal" in traits or "code_execution" in traits or "remote_computer" in traits:
            candidates.append({"capability_id":cid,"traits":sorted(traits),"actions":actions})
    preferred=None
    if any(x.get("kind")=="remote_computer" for x in live): preferred="remote_computer"
    elif any(x.get("provider")=="Floot" and x.get("kind")=="vm_workspace" for x in live): preferred="persistent_vm"
    elif "container" in specs: preferred="session_local_terminal"
    return {
        "preferred_route":preferred,
        "live_handles":live,
        "stale_handles":stale,
        "candidates":candidates,
        "truth_rule":"only observed_alive handles are reusable without reprobe; namespace callability alone is not a live terminal session",
    }
