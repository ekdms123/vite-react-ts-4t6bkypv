from __future__ import annotations

"""Truth-preserving host execution envelopes.

Host tools live outside the portable JIGAEWOL runtime.  This module standardizes
what a real host invocation may hand back so external state (terminal/VM/browser
sessions, delegated jobs, remote computers) can be persisted without confusing
"a locator was returned" with "that external process will stay alive forever".
"""

from copy import deepcopy


_HANDLE_KINDS = {
    "terminal_session",
    "vm_workspace",
    "browser_session",
    "remote_computer",
    "agent_job",
    "deployment",
    "workspace",
}


def _text(value, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def normalize_execution_handle(value, *, default_origin_ref: str | None = None) -> dict:
    if not isinstance(value, dict):
        raise ValueError("execution handle must be an object")
    kind = _text(value.get("kind"), "execution handle kind")
    provider = _text(value.get("provider"), "execution handle provider")
    handle_id = _text(value.get("handle_id"), "execution handle handle_id")
    if kind not in _HANDLE_KINDS:
        # Open set by design, but unknown kinds must be explicit and namespaced
        # rather than silently collapsing into a known semantic class.
        if ":" not in kind and "." not in kind:
            raise ValueError("unknown execution handle kind must be namespaced")
    origin = value.get("origin_ref", default_origin_ref)
    origin_ref = _text(origin, "execution handle origin_ref")
    metadata = value.get("metadata") or {}
    if not isinstance(metadata, dict):
        raise ValueError("execution handle metadata must be an object")
    observed_alive = value.get("observed_alive")
    if observed_alive is not None and type(observed_alive) is not bool:
        raise ValueError("execution handle observed_alive must be boolean when supplied")
    out = {
        "kind": kind,
        "provider": provider,
        "handle_id": handle_id,
        "origin_ref": origin_ref,
        "metadata": deepcopy(metadata),
    }
    if observed_alive is not None:
        out["observed_alive"] = observed_alive
    return out


def normalize_execution_handles(value, *, default_origin_ref: str | None = None) -> tuple[dict, ...]:
    if value is None:
        return ()
    if isinstance(value, dict):
        value = [value]
    if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
        raise ValueError("execution_handles must be an object or list/tuple of objects")
    return tuple(normalize_execution_handle(item, default_origin_ref=default_origin_ref) for item in value)


def normalize_execution_probe(value, *, default_origin_ref: str | None = None) -> dict:
    if not isinstance(value, dict):
        raise ValueError("execution probe must be an object")
    alive = value.get("alive")
    if type(alive) is not bool:
        raise ValueError("execution probe alive must be boolean")
    origin_ref = _text(value.get("origin_ref", default_origin_ref), "execution probe origin_ref")
    key = value.get("key")
    if key is not None:
        return {"key": _text(key, "execution probe key"), "alive": alive, "origin_ref": origin_ref}
    # Provider/kind/id form is useful to host adapters that do not know the
    # ledger's compound key yet.
    return {
        "provider": _text(value.get("provider"), "execution probe provider"),
        "kind": _text(value.get("kind"), "execution probe kind"),
        "handle_id": _text(value.get("handle_id"), "execution probe handle_id"),
        "alive": alive,
        "origin_ref": origin_ref,
    }


def normalize_execution_probes(value, *, default_origin_ref: str | None = None) -> tuple[dict, ...]:
    if value is None:
        return ()
    if isinstance(value, dict):
        value = [value]
    if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
        raise ValueError("execution_probes must be an object or list/tuple of objects")
    return tuple(normalize_execution_probe(item, default_origin_ref=default_origin_ref) for item in value)


def envelope_payload(*, output, origin_ref: str, effect_refs=(), source_urls=(), execution_handles=(), execution_probes=()) -> dict:
    origin_ref = _text(origin_ref, "origin_ref")
    return {
        "output": output,
        "origin_ref": origin_ref,
        "effect_refs": list(effect_refs or ()),
        "source_urls": list(source_urls or ()),
        "execution_handles": [deepcopy(x) for x in normalize_execution_handles(execution_handles, default_origin_ref=origin_ref)],
        "execution_probes": [deepcopy(x) for x in normalize_execution_probes(execution_probes, default_origin_ref=origin_ref)],
    }
