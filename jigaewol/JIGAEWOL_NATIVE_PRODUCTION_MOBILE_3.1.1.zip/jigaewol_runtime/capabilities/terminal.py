from __future__ import annotations

"""Terminal/backplane planning for the ordinary-chat cockpit.

This is intentionally a routing layer, not a shell implementation.  The actual
shell remains a HOST capability (local container, Floot VM, authorized remote
computer, etc.).  JIGAEWOL keeps the handle/state and chooses the strongest truthful
backplane available for the task.
"""

from copy import deepcopy

from .manifest import normalize_capabilities
from .execution_routes import capability_traits


def _terminal_candidates(capabilities):
    rows=[]
    for spec in normalize_capabilities(capabilities or ()):
        traits=set(capability_traits(spec))
        if "terminal" not in traits and "code_execution" not in traits:
            continue
        persistence = "persistent_workspace" in traits or "remote_computer" in traits
        rows.append({
            "capability_id": spec["id"],
            "role": spec.get("role"),
            "provider": spec.get("provider"),
            "traits": sorted(traits),
            "persistent": bool(persistence),
            "remote_computer": "remote_computer" in traits,
            "truth_state": "callable_candidate_not_live_session",
        })
    rows.sort(key=lambda row: (
        not row["remote_computer"],
        not row["persistent"],
        row["capability_id"],
    ))
    return rows


def terminal_backplane_plan(capabilities, execution_handles=()):
    candidates=_terminal_candidates(capabilities)
    handles=[deepcopy(x) for x in (execution_handles or ()) if isinstance(x,dict)]
    live=[]
    stale=[]
    for row in handles:
        if row.get("kind") not in {"terminal_session","vm_workspace","remote_computer","workspace"}:
            continue
        if row.get("status")=="observed_alive":
            live.append(row)
        elif row.get("status") in {"registered","stale_unprobed"}:
            stale.append(row)
    preferred_live = live[0] if live else None
    if preferred_live:
        state="live_terminal_attached"
    elif any(row["persistent"] for row in candidates):
        state="persistent_terminal_callable_not_attached"
    elif candidates:
        state="ephemeral_terminal_callable"
    else:
        state="terminal_missing"
    return {
        "state": state,
        "live_handles": live,
        "stale_handles_requiring_probe": stale,
        "callable_candidates": candidates,
        "preferred_live_handle": deepcopy(preferred_live),
        "truth_boundary": "callable terminal capability is not a live terminal session; live requires a real observed handle",
    }
