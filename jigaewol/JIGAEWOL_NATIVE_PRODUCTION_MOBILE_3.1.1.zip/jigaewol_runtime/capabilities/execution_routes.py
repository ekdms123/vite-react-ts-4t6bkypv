from __future__ import annotations

from .search_intent import explicit_public_search_requested

"""Evidence-bound routing over the *currently callable* HOST capability surface.

This module does not install, connect or execute providers.  It compresses a
large callable tool surface into task-relevant route candidates while retaining
why each route was selected.  A route score is advisory; execution truth still
comes only from a real HOST tool result.
"""

from copy import deepcopy
import re

from .manifest import normalize_capabilities, capability_is_callable
from .ranker import rank_capabilities

_TOKEN = re.compile(r"[^\W_]+", re.UNICODE)


_TRAIT_ALIASES = {
    "web_read": "web_search",
    "search": "web_search",
    "internet_search": "web_search",
    "repo": "repository",
    "github": "repository",
    "code_repository": "repository",
    "shell": "terminal",
    "command_execution": "code_execution",
    "python_execution": "code_execution",
    "file_io": "filesystem",
    "vision": "image_analysis",
    "image_search": "image_retrieval",
    "browser_automation": "browser",
    "knowledge": "knowledge_base",
}

def _canonical_trait(value: str) -> str:
    raw=str(value or "").strip().casefold()
    return _TRAIT_ALIASES.get(raw, raw)

_ROLE_TRAITS = {
    "code_repository": {"repository"},
    "knowledge_base": {"knowledge_base"},
    "agent_delegate": {"agent_delegate"},
    "file_io": {"filesystem"},
    "browser": {"browser"},
    "search": {"web_search"},
    "academic_search": {"web_search"},
}

def _term_match(hay: str, term: str) -> bool:
    term = str(term).casefold().strip()
    if not term:
        return False
    if any(ord(ch) > 127 for ch in term):
        return term in hay
    return re.search(r"(?<![a-z0-9_])" + re.escape(term) + r"(?![a-z0-9_])", hay) is not None

# Trait evidence is conservative and transparent. A trait is inferred only from
# manifest role/tags/operation/description supplied by the current HOST.
_TRAIT_TERMS = {
    "repository": ("code_repository", "repository", "github", "repo", "pull request", "commit", "branch"),
    # Keep execution evidence narrow.  Generic words such as "compute" or
    # "execute" are too broad: Wolfram can compute and databases can execute
    # queries without being general code runners.
    "code_execution": ("code execution", "run code", "execute code", "terminal", "shell", "vm", "run commands", "node.js snippet", "python snippet"),
    "filesystem": ("filesystem", "file_io", "files", "local files", "edit files"),
    "terminal": ("terminal", "shell", "command", "processes", "run commands"),
    "network": ("network access", "http", "internet access", "remote network"),
    "web_search": ("web search", "research", "crawl", "retrieval"),
    "browser": ("browser", "navigate", "click", "forms", "page state", "tabs"),
    "authenticated_session": ("login", "logged-in", "authenticated", "cookies", "session"),
    "remote_computer": ("remote computer", "authorized computer", "real machine", "desktop commander", "remote desktop"),
    "interaction": ("click", "forms", "fill forms", "interact", "interaction", "type into", "browser automation"),
    "web_write": ("post to", "send message", "social post", "schedule posts", "publish posts", "create post", "comment", "reply", "submit form", "browser write"),
    "write": ("write", "create", "update", "edit", "publish", "post", "send", "commit"),
    "deploy": ("deploy", "hosting", "hosted app", "publish app", "website"),
    # Persistence should mean stateful execution storage, not merely that a
    # provider happens to call something a "project".
    "persistent_workspace": ("persistent workspace", "project vm", "hosted workspace", "workspace filesystem", "remote computer", "persistent execution state"),
    # External delegation is a privileged semantic claim.  Explicit role/tags
    # remain the primary evidence; these phrases are intentionally narrow.
    "agent_delegate": ("external agent delegate", "delegate complex multi-step", "autonomous external agent"),
    "knowledge_base": ("knowledge_base", "workspace knowledge", "documents", "notion", "drive", "coda"),
}


def _haystack(spec):
    values = [spec.get("id", ""), spec.get("role", ""), spec.get("operation", ""), spec.get("provider", ""),
              spec.get("plugin", ""), spec.get("description", "")]
    values += list(spec.get("tags", ()) or ())
    return " ".join(str(x) for x in values if x).casefold()


def capability_traits(spec) -> tuple[str, ...]:
    checked = normalize_capabilities([spec])[0]
    hay = _haystack(checked)
    traits = set(_ROLE_TRAITS.get(str(checked.get("role") or "").casefold(), set()))
    explicit = checked.get("traits", ()) or ()
    if isinstance(explicit, str):
        explicit = (explicit,)
    traits.update(_canonical_trait(x) for x in explicit if str(x).strip())
    for trait, terms in _TRAIT_TERMS.items():
        if trait == "agent_delegate" and "agent_delegate" not in traits:
            # Never upgrade prose that merely mentions agents into delegation
            # authority.  AgentPool applies the same truth boundary.
            continue
        if any(_term_match(hay, term) for term in terms):
            traits.add(trait)
    return tuple(sorted(traits))


_REQUEST_NEGATION_RE = re.compile(
    r"(?:하지\s*마|하지말|하지\s*말|말고|말아|않고|않아|금지|제외|빼고|"
    r"\bdo\s+not\b|\bdon['’]?t\b|\bnot\b|\bwithout\b)", re.IGNORECASE
)
_REQUEST_MENTION_SUFFIX_RE = re.compile(
    r"^(?:이라는|라는|이란|란|의(?:\s|$)|이라는\s*단어|라는\s*단어|"
    r"하라는\s*말|하라고(?:\s*한)?\s*말?|이라는\s*말|라는\s*말|"
    r"(?:으)?로\s*(?:분류|판단|인식)|경로|개념|의미|여부|문구|표현|코드|상태)"
)
_REQUEST_COMPLETED_SUFFIX_RE = re.compile(r"^(?:낸|놓은|둔|본|했던|한\s+것|해둔)")


def _mask_quoted_request_text(text: str) -> str:
    patterns = (r"```.*?```", r"`[^`]*`", r'"[^"\n]*"', r"“[^”\n]*”", r"‘[^’\n]*’", r"'[^'\n]*'")
    out = str(text)
    for pattern in patterns:
        out = re.sub(pattern, lambda m: " " * len(m.group(0)), out, flags=re.DOTALL)
    return out


def _requested_term(text: str, term: str) -> bool:
    """Return true only when a capability term is used as a live request.

    This intentionally mirrors the canonical intent polarity rules without importing
    the jigaewol_components layer. Negated, quoted, descriptive and completed-action mentions
    must not turn into actuator requirements merely because a noun appears.
    """
    lowered = _mask_quoted_request_text(str(text)).casefold()
    needle = str(term).casefold()
    start = 0
    while True:
        idx = lowered.find(needle, start)
        if idx < 0:
            return False
        end = idx + len(needle)
        after = lowered[end:min(len(lowered), end + 24)]
        window = lowered[max(0, idx - 12):min(len(lowered), end + 18)]
        if (
            not _REQUEST_NEGATION_RE.search(window)
            and not _REQUEST_MENTION_SUFFIX_RE.search(after)
            and not _REQUEST_COMPLETED_SUFFIX_RE.search(after)
        ):
            return True
        start = end


def infer_required_traits(need: str) -> tuple[str, ...]:
    """Infer live actuator constraints without converting mere mentions into work.

    The returned traits are routing constraints, never new goals.  Every lexical hit is
    polarity/scope checked so ``DO NOT X``, quoted X, ``X라는 단어`` and completed
    ``찾아낸``-style mentions do not silently become host actions.
    """
    text = str(need or "")
    groups = {
        "repository": ("github", "repo", "repository", "pull request", "commit", "깃허브", "레포"),
        "code_execution": ("run code", "execute code", "terminal", "shell", "vm", "실행", "코드 실행", "테스트"),
        "filesystem": ("filesystem", "local file", "folder", "파일", "폴더"),
        "browser": ("browser", "website", "web app", "브라우저", "홈페이지", "사이트"),
        "authenticated_session": ("login", "logged in", "account", "로그인", "계정", "추천 피드"),
        "remote_compute": ("remote execution", "remote exec", "원격 실행", "remote vm", "원격 vm"),
        "remote_computer": (
            "remote computer", "remote body", "computer state", "remote desktop",
            "원격 컴퓨터", "원격 pc", "원격 피씨", "원격 body", "원격 바디",
        ),
        "persistent_workspace": ("persistent workspace", "persistent state", "상태 유지", "세션 유지", "실행 상태 유지", "작업공간 유지"),
        "interaction": ("click", "fill form", "interact", "댓글", "dm", "디엠", "알티", "리트윗", "좋아요", "폼", "입력", "사이트에서 검색", "페이지에서 검색", "search from", "search on this site"),
        "web_write": ("post", "send message", "comment", "reply", "게시", "댓글", "전송", "디엠", "dm", "알티", "리트윗", "좋아요"),
        "write": ("write file", "edit file", "commit", "파일 수정", "코드 수정", "업로드"),
        "deploy": ("deploy", "publish website", "배포", "홈페이지 만들어"),
        "agent_delegate": ("subagent", "agent", "하위 에이전트", "에이전트"),
        "knowledge_base": ("notion", "drive", "docs", "노션", "드라이브", "지식창고"),
    }
    out = [trait for trait, terms in groups.items() if any(_requested_term(text, term) for term in terms)]

    # Image generation/editing is an actuator intent, not a noun mention.  A control
    # request such as "이미지 생성 도구를 ZIP이 관리하게 해" must therefore not
    # accidentally emit an image.  Require a visual object plus a direct create/edit
    # speech act.
    folded = _mask_quoted_request_text(text).casefold()
    visual_object = re.search(r"(?:이미지|그림|사진|일러스트|포스터|로고|다이어그램|image|picture|photo|illustration|poster|logo|diagram)", folded)
    image_generate = re.search(r"(?:그려\s*줘|그려줘|그려\s*주세요|만들어\s*줘|만들어줘|생성해\s*줘|생성해줘|렌더(?:링)?해\s*줘|렌더(?:링)?해줘|시각화해\s*줘|시각화해줘|(?:generate|create|draw|render|visualize)\b[^.?!\n]{0,40}(?:image|picture|illustration|poster|logo|diagram)|(?:image|picture|illustration|poster|logo|diagram)[^.?!\n]{0,40}\b(?:generate|create|draw|render|visualize))", folded, re.I)
    image_edit = re.search(r"(?:이\s*(?:사진|이미지|그림)|첨부(?:한)?\s*(?:사진|이미지|그림)|(?:this|attached)\s+(?:photo|image|picture))", folded, re.I) and re.search(r"(?:지워\s*줘|지워줘|제거해\s*줘|제거해줘|추가해\s*줘|추가해줘|바꿔\s*줘|바꿔줘|수정해\s*줘|수정해줘|편집해\s*줘|편집해줘|복원해\s*줘|복원해줘|업스케일|리터치|(?:edit|remove|add|replace|retouch|restore|upscale)\b)", folded, re.I)
    if visual_object and image_generate:
        out.append("image_generation")
    if image_edit:
        out.append("image_editing")

    if explicit_public_search_requested(text):
        out.append("web_search")
    return tuple(sorted(set(out)))


def rank_execution_routes(need: str, capabilities, *, required_traits=None, avoid_capability_ids=(), limit=None, include_reserve=False):
    specs = tuple(spec for spec in normalize_capabilities(capabilities or ()) if capability_is_callable(spec))
    required = set(required_traits if required_traits is not None else infer_required_traits(need))
    avoid = {str(x) for x in (avoid_capability_ids or ())}
    lexical = {spec["id"]: score for spec, score in rank_capabilities(str(need or ""), specs)}
    rows = []
    for index, spec in enumerate(specs):
        cid = str(spec["id"])
        traits = set(capability_traits(spec))
        matched = sorted(required & traits)
        missing = sorted(required - traits)
        # Missing traits are not a hard veto because the semantic planner may
        # intentionally compose multiple tools. They reduce single-route fit.
        score = float(lexical.get(cid, 0.0))
        score += len(matched) * 3.0
        score -= len(missing) * 0.6
        score -= float(spec.get("cost", 0.5)) * 0.05
        temporarily_deprioritized = cid in avoid
        if temporarily_deprioritized:
            score -= 1000.0
        matched_any = bool(matched)
        lexical_hit = cid in lexical and float(lexical.get(cid, 0.0)) > 0.0
        activation_state = (
            "temporarily_deprioritized" if temporarily_deprioritized else
            "primary" if (matched_any or lexical_hit or not required) else
            "exaptive_reserve"
        )
        # No callable route is deleted merely because current lexical/trait fit is zero.
        # Low-fit routes stay in a reserve so later evidence, exaptation, or a new
        # representation can reactivate them. Selection is scheduling, not ontology.
        rows.append({
            "capability_id": cid,
            "role": spec.get("role"),
            "provider": spec.get("provider"),
            "plugin": spec.get("plugin"),
            "operation": spec.get("operation"),
            "traits": sorted(traits),
            "matched_required_traits": matched,
            "missing_required_traits": missing,
            "score": score,
            "cost": spec.get("cost", 0.5),
            "permission": spec.get("permission", "none"),
            "route_state": "callable_manifest_candidate_not_execution_evidence",
            "activation_state": activation_state,
            "selection_is_scheduling_not_pruning": True,
            "manifest_index": index,
        })
    state_order = {"primary": 0, "exaptive_reserve": 1, "temporarily_deprioritized": 2}
    rows.sort(key=lambda row: (state_order.get(row["activation_state"], 9), -row["score"], row["cost"], row["manifest_index"], row["capability_id"]))
    # Compatibility: callers historically interpreted avoided routes as absent from
    # the *active* schedule. The full cognition packet explicitly opts into reserves,
    # so observed failures remain recoverable without being immediately retried.
    visible = rows if include_reserve else [row for row in rows if row["activation_state"] != "temporarily_deprioritized"]
    if limit is None:
        return tuple(deepcopy(visible))
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
        raise ValueError("execution route limit must be None or a positive integer")
    selected = visible[:limit]
    # Explicit limits are display/scheduling limits only. The caller can inspect
    # `activation_state` with an unlimited call to recover the full live reservoir.
    return tuple(deepcopy(selected))




def _incremental_cost_state(spec) -> str:
    """Classify *billing* evidence separately from latency/routing cost hints.

    ``spec['cost']`` is a generic routing/latency hint and must never be treated as
    proof that a provider is monetarily free. Only explicit host evidence can prove
    zero incremental cost.
    """
    if spec.get("zero_incremental_cost") is True:
        return "proven_free"
    if spec.get("zero_incremental_cost") is False or spec.get("paid") is True:
        return "paid_or_incremental_cost"
    billing = spec.get("billing")
    if isinstance(billing, dict):
        if billing.get("zero_incremental_cost") is True:
            return "proven_free"
        if billing.get("paid") is True:
            return "paid_or_incremental_cost"
        amount = billing.get("incremental_cost")
        if isinstance(amount, (int, float)) and not isinstance(amount, bool):
            return "proven_free" if float(amount) == 0.0 else "paid_or_incremental_cost"
        if str(amount or "").strip().casefold() in {"0", "0.0", "free", "included", "none"}:
            return "proven_free"
    return "unknown"

def compose_execution_routes(need: str, capabilities, *, required_traits=None, avoid_capability_ids=(), zero_cost_policy="cost_agnostic"):
    """Compose multiple callable components by trait coverage before convenience.

    Unlike single-route ranking, composition never discards a useful component merely
    because it cannot satisfy the whole task alone. Destination coverage is the
    primary objective; lexical fit and cost only break ties.
    """
    specs = tuple(spec for spec in normalize_capabilities(capabilities or ()) if capability_is_callable(spec))
    required = set(required_traits if required_traits is not None else infer_required_traits(need))
    avoid = {str(x) for x in (avoid_capability_ids or ())}
    if zero_cost_policy not in {"prefer_proven_free", "proven_free_only", "cost_agnostic"}:
        raise ValueError("unknown zero_cost_policy")
    if not required:
        return {
            "required_traits": [], "covered_traits": [], "missing_traits": [],
            "complete": True, "routes": [],
            "selection_policy": "destination_coverage_before_convenience",
            "route_state": "no_explicit_execution_traits_inferred",
        }

    lexical = {spec["id"]: score for spec, score in rank_capabilities(str(need or ""), specs)}
    pool=[]
    for index,spec in enumerate(specs):
        cid=str(spec["id"])
        if cid in avoid:
            continue
        traits=set(capability_traits(spec))
        gain=required & traits
        if not gain:
            continue
        cost_state = _incremental_cost_state(spec)
        pool.append({
            "capability_id":cid, "role":spec.get("role"), "provider":spec.get("provider"),
            "plugin":spec.get("plugin"), "operation":spec.get("operation"),
            "traits":sorted(traits), "score":float(lexical.get(cid,0.0)),
            "cost":float(spec.get("cost",.5)), "permission":spec.get("permission","none"),
            "incremental_cost_state": cost_state,
            "manifest_index":index,
            "route_state":"callable_manifest_candidate_not_execution_evidence",
        })
    deferred_cost_unknown = sorted(row["capability_id"] for row in pool if row["incremental_cost_state"] == "unknown")
    excluded_paid = sorted(row["capability_id"] for row in pool if row["incremental_cost_state"] == "paid_or_incremental_cost")
    if zero_cost_policy == "proven_free_only":
        pool = [row for row in pool if row["incremental_cost_state"] == "proven_free"]
    uncovered=set(required); selected=[]; unused=list(pool)
    while uncovered:
        candidates=[]
        for row in unused:
            gain=uncovered & set(row["traits"])
            if gain:
                cost_rank = {"proven_free": 2, "unknown": 1, "paid_or_incremental_cost": 0}[row["incremental_cost_state"]]
                if zero_cost_policy == "cost_agnostic":
                    cost_rank = 1
                candidates.append((len(gain), cost_rank, row["score"], -row["cost"], -row["manifest_index"], row, gain))
        if not candidates:
            break
        _,_,_,_,_,chosen,gain=max(candidates, key=lambda x:(x[0],x[1],x[2],x[3],x[4],str(x[5]["capability_id"])))
        selected.append({**deepcopy(chosen), "newly_covered_traits":sorted(gain)})
        uncovered -= set(gain)
        unused=[row for row in unused if row["capability_id"] != chosen["capability_id"]]
    covered=required-uncovered
    selected_ids = {row["capability_id"] for row in selected}
    reserve = [
        {**deepcopy(row), "activation_state": "exaptive_reserve", "selection_is_scheduling_not_pruning": True}
        for row in pool if row["capability_id"] not in selected_ids
    ]
    selection_policy = (
        "destination_coverage_then_semantic_fit_then_route_cost"
        if zero_cost_policy == "cost_agnostic"
        else "destination_coverage_then_proven_zero_incremental_cost_then_semantic_fit"
    )
    return {
        "required_traits":sorted(required), "covered_traits":sorted(covered),
        "missing_traits":sorted(uncovered), "complete":not uncovered, "routes":selected,
        "reserve_routes": reserve,
        "selection_policy":selection_policy,
        "selection_is_scheduling_not_pruning": True,
        "missing_traits_trigger_open_discovery": bool(uncovered),
        "zero_cost_policy": zero_cost_policy,
        "cost_unknown_routes": deferred_cost_unknown,
        "deferred_cost_unknown": deferred_cost_unknown if zero_cost_policy == "proven_free_only" else [],
        "excluded_paid_or_incremental_cost": excluded_paid if zero_cost_policy == "proven_free_only" else [],
        "route_state":"callable_manifest_composition_not_execution_evidence",
    }


_TRAIT_DISCOVERY_TERMS = {
    "remote_computer": "remote computer terminal filesystem authorized device",
    "web_write": "authenticated browser automation post comment message submit form",
    "interaction": "browser automation click fill forms login",
    "authenticated_session": "authenticated browser session login cookies",
    "agent_delegate": "external agent delegate subagent multi-step task",
    "repository": "GitHub repository code source control",
    "code_execution": "terminal shell code execution sandbox VM",
    "filesystem": "filesystem files folders local workspace",
    "knowledge_base": "persistent knowledge base documents workspace",
    "web_search": "web search crawl research retrieval",
    "deploy": "application deployment hosting publish",
}

def trait_discovery_query(traits) -> str:
    values=[]
    for trait in sorted({str(x) for x in (traits or ()) if str(x)}):
        values.append(_TRAIT_DISCOVERY_TERMS.get(trait, trait.replace("_", " ")))
    return " ; ".join(values)
