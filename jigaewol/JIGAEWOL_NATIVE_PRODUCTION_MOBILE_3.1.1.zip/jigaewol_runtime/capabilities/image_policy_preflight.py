from __future__ import annotations

from copy import copy, deepcopy
from dataclasses import is_dataclass, replace
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Mapping


def _stable_json_sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _text_sha(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _normalized_token(value: Any) -> str:
    return str(value or "").strip().casefold().replace("-", "_").replace(" ", "_")


def is_image_generation_work(work: Any) -> bool:
    from jigaewol_components.image_sovereignty import ImageSovereigntyPolicy
    operation = _normalized_token(getattr(work, "operation", "")).removeprefix("capability.")
    params = dict(getattr(work, "parameters", {}) or {})
    context = dict(getattr(work, "context", {}) or {})
    action = _normalized_token(
        params.get("host_action") or params.get("provider_action") or params.get("action")
    )
    role = _normalized_token(context.get("capability_role") or context.get("role"))

    if ImageSovereigntyPolicy.is_image_capability(operation):
        return True

    if role == "image_generation":
        return True
    if operation in {"image_gen", "native.image_generation", "host.image_generation", "image_generation"}:
        return True
    if "image_generation" in operation:
        return True
    return action in {
        "text2im", "generate_image", "generate_or_edit_image", "image_generate",
        "render_image", "create_image", "edit_image",
    }


def bind_image_policy_receipt(work: Any, receipt: dict) -> Any:
    context = deepcopy(getattr(work, "context", {}) or {})
    context["image_policy_preflight_receipt"] = deepcopy(receipt)
    context["image_sovereignty_contract"] = deepcopy(receipt.get("image_sovereignty_contract") or {})
    context["image_generation_governance"] = deepcopy(receipt.get("image_generation_governance") or {})
    if is_dataclass(work):
        try:
            return replace(work, context=context)
        except (TypeError, ValueError):
            pass
    cloned = copy(work)
    setattr(cloned, "context", context)
    return cloned


class ImagePolicyPreflight:
    """JIGAEWOL-side image policy gate executed before any HOST image call.

    The gate proves that the image request is bound to the canonical user ingress
    and to an explicit session policy profile.  It never claims to replace the
    embedding HOST's final policy enforcement; that remains mandatory and is
    recorded in every ALLOW receipt.
    """

    FORMAT = "jigaewol_image_policy_preflight_receipt_v1"

    def __init__(self, state_root: str | Path | None = None, *, persist_receipts: bool = False):
        self.state_root = Path(state_root).expanduser().resolve() if state_root else None
        self.persist_receipts = bool(persist_receipts)

    @classmethod
    def for_runtime(cls):
        try:
            from jigaewol_components.canonical_state import default_canonical_state_root
            root = default_canonical_state_root()
            if root.exists():
                return cls(root, persist_receipts=True)
        except Exception:
            pass
        return cls()

    def _load_json(self, path: Path) -> dict | None:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return dict(value) if isinstance(value, dict) else None

    def _resolve_ingress(self, context: dict) -> dict | None:
        for key in ("turn_ingress_receipt", "ingress_receipt", "canonical_ingress_receipt"):
            value = context.get(key)
            if isinstance(value, dict):
                return dict(value)
        if self.state_root is not None:
            return self._load_json(self.state_root / "turn_ingress" / "current_receipt.json")
        return None

    def _resolve_policy(self, context: dict) -> dict | None:
        value = context.get("image_policy_context")
        if isinstance(value, dict):
            return dict(value)
        if self.state_root is not None:
            return self._load_json(self.state_root / "image_policy" / "policy_context.json")
        return None

    def _persist(self, receipt: dict) -> None:
        if not self.persist_receipts or self.state_root is None:
            return
        out = self.state_root / "image_policy" / "receipts" / f"{receipt['receipt_id']}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_suffix(out.suffix + ".tmp")
        tmp.write_text(json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(out)

    def evaluate(self, work: Any) -> dict:
        from jigaewol_components.image_generation_governance import ImageGenerationGovernance
        from jigaewol_components.image_sovereignty import ImageSovereigntyPolicy
        if not is_image_generation_work(work):
            raise ValueError("image policy preflight only accepts image-generation work")

        params = dict(getattr(work, "parameters", {}) or {})
        context = dict(getattr(work, "context", {}) or {})
        exact_text = str(context.get("exact_user_text") or context.get("current_user_message") or "")
        instruction = str(params.get("instruction") or params.get("prompt") or "")
        action = str(params.get("host_action") or params.get("provider_action") or params.get("action") or "generate_or_edit_image")
        capability_id = str(getattr(work, "operation", "")).removeprefix("capability.")
        ingress = self._resolve_ingress(context)
        policy = self._resolve_policy(context)
        governance = ImageGenerationGovernance.compile(
            exact_text, attachments=tuple(context.get("attachments") or params.get("referenced_image_paths") or ()),
        ).as_mapping()
        sovereignty = context.get("image_sovereignty_contract") or governance["sovereignty_contract"]
        if policy is None:
            policy = {"profile": "canonical_zip_image_policy_v1", "image_generation_enabled": True,
                      "requires_adult_verification": False, "adult_verified": False,
                      "host_final_enforcement_required": True}

        decision = "BLOCK"
        reason = "unknown"
        ingress_sha = str((ingress or {}).get("exact_message_sha256") or "")
        exact_sha = _text_sha(exact_text) if exact_text else ""

        if not exact_text:
            reason = "missing_exact_user_text"
        elif not instruction.strip():
            reason = "missing_image_instruction"
        elif ingress is None:
            reason = "missing_canonical_ingress_receipt"
        elif ingress.get("validator_passed") is not True or ingress.get("canonical_core_routed") is not True:
            reason = "canonical_ingress_not_accepted"
        elif ingress_sha != exact_sha:
            reason = "canonical_ingress_hash_mismatch"
        elif policy.get("image_generation_enabled") is not True:
            reason = "image_generation_disabled_by_zip_policy"
        elif policy.get("requires_adult_verification") is True and policy.get("adult_verified") is not True:
            reason = "adult_verified_policy_profile_required"
        elif policy.get("host_final_enforcement_required") is not True:
            reason = "host_final_enforcement_must_remain_enabled"
        elif governance.get("should_invoke") is not True:
            reason = "exact_user_source_does_not_authorize_image_generation"
        elif not ImageSovereigntyPolicy.validate(
            sovereignty, source_text=exact_text, mode=governance["mode"], should_invoke=True,
        ):
            reason = "image_sovereignty_contract_invalid"
        else:
            decision = "ALLOW"
            reason = "canonical_ingress_and_session_image_policy_verified"

        instruction_sha = _text_sha(instruction) if instruction else ""
        policy_sha = _stable_json_sha(policy or {})
        seed = {
            "capability_id": capability_id,
            "action": action,
            "exact_user_message_sha256": exact_sha,
            "instruction_sha256": instruction_sha,
            "policy_context_sha256": policy_sha,
            "decision": decision,
            "reason": reason,
        }
        receipt_id = "image_policy_" + _stable_json_sha(seed)[:24]
        receipt = {
            "format": self.FORMAT,
            "receipt_id": receipt_id,
            "decision": decision,
            "reason": reason,
            "host_action_permitted": decision == "ALLOW",
            "zip_policy_verified": decision == "ALLOW",
            "capability_id": capability_id,
            "action": action,
            "exact_user_message_sha256": exact_sha,
            "ingress_receipt_message_sha256": ingress_sha,
            "instruction_sha256": instruction_sha,
            "policy_context_sha256": policy_sha,
            "policy_profile": str((policy or {}).get("profile") or ""),
            "image_sovereignty_contract": dict(sovereignty) if isinstance(sovereignty, Mapping) else {},
            "image_generation_governance": governance,
            "adult_verified": bool((policy or {}).get("adult_verified")),
            "allow_explicit_fictional_adult_images": bool((policy or {}).get("allow_explicit_fictional_adult_images")),
            "host_final_enforcement_required": bool((policy or {}).get("host_final_enforcement_required", True)),
            "zip_is_final_host_policy_authority": False,
            "created_at": time.time(),
        }
        self._persist(receipt)
        return receipt
