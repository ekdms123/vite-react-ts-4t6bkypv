from __future__ import annotations

"""Conservative preflight inspection for open-source capability candidates.

This is a narrow source preflight helper. It reports observable source, dependency,
and installation signals as an execution-placement hint so JIGAEWOL can place
unfamiliar code in an isolated VM/container before local execution.
"""
from copy import deepcopy
import re

_PATTERNS = {
    "process_execution": re.compile(r"\b(subprocess\.|os\.system\(|child_process|Command::new|ProcessBuilder|execFile|spawn\()"),
    "dynamic_code": re.compile(r"\b(eval\(|exec\(|Function\(|compile\(|dlopen|LoadLibrary)"),
    "network_access": re.compile(r"\b(requests\.|httpx\.|urllib\.|fetch\(|axios\.|curl\b|wget\b|reqwest\b)"),
    "credential_access": re.compile(r"\b(os\.environ|process\.env|keyring|credential|token|api[_-]?key|secret)\b", re.I),
    "filesystem_mutation": re.compile(r"\b(unlink\(|rmtree\(|remove\(|write_text\(|write_bytes\(|open\([^\n]*['\"](?:w|a|x)b?['\"]|fs\.write|rm\s+-rf)"),
    "install_or_bootstrap": re.compile(r"\b(pip\s+install|npm\s+(?:i|install)|pnpm\s+install|yarn\s+add|cargo\s+install|curl[^\n]*\|\s*(?:sh|bash)|powershell[^\n]*iex)\b", re.I),
    "browser_control": re.compile(r"\b(playwright|puppeteer|selenium|chromedriver|cdp|browser automation|webextension)\b", re.I),
    "native_or_binary": re.compile(r"\b(node-gyp|\.so\b|\.dll\b|\.dylib\b|ctypes\.|cffi\b|unsafe\s*\{|binary download)\b", re.I),
    "obfuscation_signal": re.compile(r"(?:base64\.b64decode|fromCharCode|atob\(|marshal\.loads|pickle\.loads)"),
}

_DEPENDENCY_FILES = {
    "requirements.txt", "pyproject.toml", "poetry.lock", "package.json", "package-lock.json",
    "pnpm-lock.yaml", "yarn.lock", "cargo.toml", "cargo.lock", "go.mod", "go.sum",
}


def inspect_source_bundle(files, *, provenance=None, license_id=None):
    """Inspect a mapping/list of source files and return observable risk signals.

    ``files`` may be ``{path: text}`` or a list of ``{"path","content"}`` rows.
    Binary content should be represented by metadata outside this helper rather
    than decoded and trusted here.
    """
    if isinstance(files, dict):
        rows=[{"path":str(path),"content":content} for path,content in files.items()]
    elif isinstance(files, (list, tuple)):
        rows=list(files)
    else:
        raise ValueError("files must be a mapping or list of file objects")
    normalized=[]
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("path"), str):
            raise ValueError("source bundle entries require path")
        content=row.get("content", "")
        if not isinstance(content, str):
            raise ValueError("source inspection accepts text content only")
        normalized.append({"path":row["path"],"content":content})

    signals={name:[] for name in _PATTERNS}
    dependency_files=[]
    for row in normalized:
        name=row["path"].replace("\\","/").split("/")[-1].casefold()
        if name in _DEPENDENCY_FILES:
            dependency_files.append(row["path"])
        for signal,pattern in _PATTERNS.items():
            for match in pattern.finditer(row["content"]):
                signals[signal].append({"path":row["path"],"offset":match.start(),"match":match.group(0)[:120]})

    active={k:v for k,v in signals.items() if v}
    high = bool(active.get("obfuscation_signal") or active.get("native_or_binary"))
    host_sensitive = bool(active.get("credential_access") or active.get("filesystem_mutation") or active.get("process_execution"))
    if high:
        placement="isolated_execution_or_vm_until_source_inspection"
    elif host_sensitive:
        placement="isolated_vm_or_container_first"
    elif active.get("network_access") or active.get("browser_control") or active.get("install_or_bootstrap"):
        placement="isolated_execution_first"
    else:
        placement="restricted_local_probe_candidate"

    return {
        "provenance": deepcopy(provenance or {}),
        "license_id": license_id,
        "file_count": len(normalized),
        "dependency_files": sorted(dependency_files),
        "signals": active,
        "risk_signal_count": sum(len(v) for v in active.values()),
        "recommended_placement": placement,
        "truth_boundary": "static_preflight_signal_scope_only",
        "execution_allowed_by_this_report": False,
    }
