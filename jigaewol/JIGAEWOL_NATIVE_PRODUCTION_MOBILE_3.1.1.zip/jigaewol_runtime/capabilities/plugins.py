"""Provider-neutral plugin/tool integration for the HOST ║ JIGAEWOL boundary.

This module deliberately does not call external APIs.  It lets a host expose
connected plugin actions as rich capability manifests, and routes selected
JIGAEWOL capability work to the observed callable that performs execution.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Callable, Any

from .manifest import CapabilityManifest, provider_arguments, validate_parameters


@dataclass(frozen=True)
class PluginInvocation:
    capability_id: str
    plugin: str | None
    operation: str | None
    arguments: dict
    work_id: str
    turn_id: str
    task_id: str
    context: dict


class HostPluginRouter:
    """Bind capability manifests to one real HOST plugin dispatcher.

    ``host_call`` receives a PluginInvocation and MUST return an actual tool
    result carrying an origin_ref (ToolInvocationResult, compatible dict, or
    tuple).  The router never synthesizes success or provider provenance.
    """
    def __init__(self, host_call: Callable[[PluginInvocation], Any]):
        self.host_call = host_call
        self._manifests: dict[str, CapabilityManifest] = {}

    def register(self, manifest: CapabilityManifest) -> CapabilityManifest:
        if manifest.capability_id in self._manifests:
            raise ValueError(f"capability already registered: {manifest.capability_id}")
        self._manifests[manifest.capability_id] = manifest
        return manifest

    def capabilities(self) -> tuple[dict, ...]:
        return tuple(m.to_spec() for m in self._manifests.values())

    def tool_handlers(self) -> dict[str, Callable]:
        return {capability_id: self._make_handler(manifest)
                for capability_id, manifest in self._manifests.items()}

    def _make_handler(self, manifest: CapabilityManifest):
        def handler(work):
            exact_parameters = deepcopy(getattr(work, "parameters", {}) or {})
            if not exact_parameters:
                fallback = getattr(work, "context", {}).get("parameters") if isinstance(getattr(work, "context", {}), dict) else None
                exact_parameters = deepcopy(fallback) if isinstance(fallback, dict) else {}
            spec = manifest.to_spec()
            provider_params = provider_arguments(spec, exact_parameters)
            validate_parameters(spec, provider_params)
            invocation = PluginInvocation(
                capability_id=manifest.capability_id,
                plugin=manifest.plugin,
                operation=manifest.operation,
                arguments=provider_params,
                work_id=str(work.work_id), turn_id=str(work.turn_id), task_id=str(work.task_id),
                context=deepcopy(getattr(work, "context", {}) or {}),
            )
            return self.host_call(invocation)
        return handler


def plugin_capability(capability_id: str, *, plugin: str, description: str,
                      role: str = "search", operation: str | None = None,
                      input_schema: dict | None = None, permission: str = "none",
                      cost: float = .5, modalities_in=(), modalities_out=(), tags=()):
    return CapabilityManifest(
        capability_id=capability_id, plugin=plugin, provider="chatgpt_plugin",
        operation=operation, role=role, description=description,
        input_schema=deepcopy(input_schema or {"type": "object"}),
        permission_class=permission, cost_latency_hint=cost,
        modalities_in=tuple(modalities_in), modalities_out=tuple(modalities_out), tags=tuple(tags),
    )


PLUGIN_PRESETS = {
    "firecrawl": ("Firecrawl", "search", "Live web search, extraction, crawling, developer/research indexes and page monitoring."),
    "wolfram": ("Wolfram", "compute", "Symbolic, numeric and curated computational knowledge for exact calculation and verification."),
    "elicit": ("Elicit", "academic_search", "Academic paper discovery, evidence extraction, reports and systematic reviews."),
    "parallel_search": ("Parallel Search", "search", "Web search and content extraction for broad, parallel evidence gathering."),
    "tavily": ("Tavily AI", "search", "Current web search, extraction, crawling, mapping and research."),
    "context7": ("Context7", "documentation", "Current software-library documentation and code examples."),
    "exa": ("Exa", "search", "Semantic web search and clean page retrieval."),
    "notion": ("Notion", "knowledge_base", "Search, read and update connected Notion workspace knowledge."),
    "coda": ("Coda", "knowledge_base", "Read and modify connected Coda documents, tables and rows."),
    "posthog": ("PostHog", "analytics", "Product analytics, experiments, feature flags, errors, sessions and LLM analytics."),
    "scite": ("Scite", "academic_search", "Scientific literature search with citation-context and citation-quality evidence."),
    "sider_scholar": ("Sider Scholar", "academic_search", "Scholar, PubMed, arXiv and open-access literature discovery and retrieval."),
    "consensus": ("Consensus", "academic_search", "Peer-reviewed research search and evidence lookup."),
    "scispace": ("SciSpace", "academic_search", "Large scholarly index for semantic paper discovery and structured comparison."),
    "github": ("GitHub", "code_repository", "Search and operate on connected repositories, files, issues, pull requests and commits."),
    "tinyfish": ("TinyFish", "search", "Live browser navigation and user-directed web interaction: navigate, click, fill forms, inspect dynamic page state and web apps."),
    "floot": ("Floot", "compute", "Remote project and VM execution fabric with network access, code execution, testing, app resources and hosting from chat."),
    "manus": ("Manus", "agent_delegate", "Delegate complex multi-step projects to an autonomous external agent and receive its finished work back in chat."),
    "acumen": ("Acumen by Talarion", "search", "Proactively surface recent context, omissions and developments an agent may not know to ask for before research."),
    "vidiq": ("vidIQ", "search", "YouTube channel analytics, video performance, keyword research and trending-topic discovery."),
    "plugin_management": ("Plugin Management", "capability_management", "Discover plugins and inspect installation, dependency, connection and permission state."),
    "google_drive": ("Google Drive", "knowledge_base", "Persistent connected file and document workspace: search, read, create, update, upload, organize and share Drive resources when the HOST exposes those actions."),
    "opera_browser": ("Opera Browser Connector", "browser", "Use the user's explicitly connected Opera browser state as a sensor: inspect open tabs, authenticated page content, screenshots, history and navigation exposed by the HOST."),
    "remote_desktop_commander": ("Remote Desktop Commander", "compute", "Authorized remote computer filesystem and terminal surface for inspecting files, running commands, managing processes and editing local workspaces when connected by the user."),
    "metricool": ("Metricool for Social Media", "analytics", "Connected social analytics, content planning and scheduling surface across supported social networks. It does not imply public-firehose search or account access beyond the connected Metricool scope."),
    "replit": ("Replit", "compute", "AI app-builder and hosted development surface for creating, updating, inspecting and publishing runnable applications."),
    "digitalocean": ("DigitalOcean", "infrastructure", "Cloud infrastructure control surface for droplets, images, keys, regions, sizing, snapshots and lifecycle operations."),
    "supabase": ("Supabase", "database", "Postgres, Auth, Storage, Edge Functions, branches, migrations, SQL execution and project diagnostics."),
    "vercel": ("Vercel", "deploy", "Web application and agent deployment surface with projects, deployments, build/runtime logs, domains and platform documentation."),
    "neon": ("Neon", "database", "Branchable Postgres, SQL execution, Auth, Data API, functions, storage, snapshots, logs and compute lifecycle."),
    "render": ("Render", "deploy", "Application hosting surface for services, deploys, logs, metrics, Postgres, key-value stores and cron jobs."),
    "gitbook": ("GitBook", "documentation", "Developer documentation workspace with sites, spaces, pages, change requests and API operations."),
    "lovable": ("Lovable", "compute", "Full-stack app-building agent with project code, diffs, files, database access, connectors, analytics and deployment."),
    "base44": ("Base44", "compute", "AI app-builder with sandbox command execution, file editing, data schemas, connectors and checkpoints."),
    "codex_security": ("Codex Security", "security", "Software security scanning, analysis and investigation workflows exposed by the host when connected."),
    "hugging_face": ("Hugging Face", "model_registry", "Model, dataset, Space and research inspection surface exposed by the host when connected."),
    "datadog": ("Datadog", "observability", "Logs, traces, metrics, dashboards, incidents, monitors and runtime observability exposed by the host when connected."),
}


def preset_plugin_capabilities(names=None) -> tuple[CapabilityManifest, ...]:
    # The default catalogue must not silently reintroduce a plugin the user
    # explicitly declined. An explicit name list can still be used after approval.
    selected = tuple(PLUGIN_PRESETS.keys() if names is None else names)
    if names is None:
        selected = tuple(name for name in selected if name != "hugging_face")
    out = []
    for key in selected:
        if key not in PLUGIN_PRESETS:
            raise KeyError(key)
        plugin, role, description = PLUGIN_PRESETS[key]
        out.append(plugin_capability(
            "plugin." + key, plugin=plugin, role=role, operation="auto",
            description=description,
            input_schema={"type": "object"},
            tags=("plugin", key),
        ))
    return tuple(out)


def image_generation_capability(capability_id="image_gen") -> CapabilityManifest:
    return CapabilityManifest(
        capability_id=capability_id, provider="host_native", operation="generate_or_edit_image",
        role="image_generation",
        description="Generate or edit an image using the HOST-native image generation surface. Use supplied media refs for edits.",
        permission_class="none", cost_latency_hint=.8,
        input_schema={
            "type": "object",
            "properties": {
                "instruction": {"type": "string"},
                "media_refs": {"type": "array"},
            },
            "required": ["instruction"],
        },
        modalities_in=("text", "image"), modalities_out=("image",), tags=("image", "generation", "editing"),
    )


def skill_capability(capability_id: str, *, skill: str, description: str, role: str = "methodology", operation: str = "apply"):
    """Describe a HOST-exposed skill without pretending it is installed/executable."""
    return CapabilityManifest(
        capability_id=capability_id, plugin=skill, provider="host_skill", operation=operation,
        role=role, description=description, input_schema={"type": "object"},
        permission_class="none", cost_latency_hint=.15, tags=("skill", skill.casefold()),
    )


def cognition_capability_stack() -> tuple[CapabilityManifest, ...]:
    """Manifests for the requested cognition stack; connection remains a HOST fact."""
    plugin_names = (
        "github", "scispace", "consensus", "sider_scholar", "scite", "posthog", "coda",
        "notion", "exa", "context7", "tavily", "parallel_search", "wolfram", "firecrawl",
    )
    return (
        *preset_plugin_capabilities(plugin_names),
        skill_capability(
            "skill.superpowers", skill="Superpowers", role="methodology", operation="workflow",
            description="Agentic engineering workflow for brainstorming, planning, TDD, debugging and verification.",
        ),
    )




def self_expanding_capability_templates() -> tuple[CapabilityManifest, ...]:
    """Discovery templates for capabilities found after the original cognition stack.

    Presence here is not a connection claim. The current HOST must still expose
    and bind a callable action before execution is possible.
    """
    return preset_plugin_capabilities((
        "tinyfish", "floot", "manus", "acumen", "vidiq", "plugin_management",
        "google_drive", "opera_browser", "remote_desktop_commander", "metricool",
        "replit", "digitalocean", "supabase", "vercel", "neon", "render",
        "gitbook", "lovable", "base44", "codex_security", "datadog",
    ))

def native_chat_capability_stack() -> tuple[CapabilityManifest, ...]:
    """HOST-native capability templates for the normal ChatGPT execution surface.

    These are discovery templates only. A capability becomes executable only when
    the current HOST exposes and binds the corresponding handler. Once bound, its
    observation returns through the same HostWork -> cognition.delta path as a
    plugin capability.
    """
    return (
        CapabilityManifest(
            capability_id="native.web_search", provider="host_native", operation="search",
            role="search", description="Current web search and retrieval exposed by the chat host.",
            input_schema={"type": "object"}, permission_class="none", cost_latency_hint=.45,
            modalities_in=("text",), modalities_out=("text",), tags=("native", "search"),
        ),
        CapabilityManifest(
            capability_id="native.python", provider="host_native", operation="compute",
            role="compute", description="Stateful Python computation exposed by the chat host.",
            input_schema={"type": "object"}, permission_class="none", cost_latency_hint=.35,
            modalities_in=("text", "file"), modalities_out=("text", "file"), tags=("native", "python", "compute"),
        ),
        CapabilityManifest(
            capability_id="native.files", provider="host_native", operation="file_io",
            role="file_io", description="Search, read, inspect and hand off files exposed by the current chat host.",
            input_schema={"type": "object"}, permission_class="read", cost_latency_hint=.2,
            modalities_in=("text", "file"), modalities_out=("text", "file"), tags=("native", "files", "io"),
        ),
        CapabilityManifest(
            capability_id="native.image_analysis", provider="host_native", operation="analyze_image",
            role="image_analysis", description="Analyze user-supplied images or rendered media using the host vision surface.",
            input_schema={"type": "object"}, permission_class="none", cost_latency_hint=.45,
            modalities_in=("text", "image"), modalities_out=("text",), tags=("native", "vision", "analysis"),
        ),
        image_generation_capability("native.image_generation"),
    )
