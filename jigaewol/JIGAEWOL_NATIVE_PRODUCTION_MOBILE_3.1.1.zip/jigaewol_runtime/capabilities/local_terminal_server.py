from __future__ import annotations

"""Owner-local persistent bash daemon used by LocalTerminalBridge.

The server is deliberately tiny: one bash process, one owner-only Unix socket,
one random bearer token stored mode 0600, and one durable workspace.  A daemon
restart recreates a shell in the workspace but never claims volatile shell
state survived.
"""

import argparse
import hmac
import json
import os
from pathlib import Path
import re
import shlex
import selectors
import signal
import socket
import subprocess
import sys
import threading
import time
import uuid


def _recv_line(conn: socket.socket, limit: int = 1_000_000) -> bytes:
    data = bytearray()
    while b"\n" not in data:
        chunk = conn.recv(65536)
        if not chunk:
            break
        data.extend(chunk)
        if len(data) > limit:
            raise ValueError("terminal bridge request too large")
    return bytes(data).split(b"\n", 1)[0]


class _PersistentBash:
    def __init__(self, workspace: Path):
        workspace.mkdir(parents=True, exist_ok=True)
        self.workspace = workspace.resolve()
        env = dict(os.environ)
        env["JIGAEWOL_WORKSPACE"] = str(self.workspace)
        self.base_env = dict(env)
        self.proc = subprocess.Popen(
            ["/bin/bash", "--noprofile", "--norc"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=0,
            start_new_session=True,
            cwd=str(workspace),
            env=env,
        )
        self.lock = threading.Lock()
        # Bytes already read past the previous command's marker, plus markers belonging
        # to commands that timed out. A timed-out command keeps running and still prints
        # its marker later, so that output has to be consumed before the next command's
        # reply can be read — otherwise it bleeds into the next caller's stdout.
        self.residual = bytearray()
        self.pending_markers: list[str] = []
        os.set_blocking(self.proc.stdout.fileno(), False)

    def _read_once(self, selector, deadline: float, on_timeout: str) -> None:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(on_timeout)
        if not selector.select(remaining):
            return
        chunk = os.read(self.proc.stdout.fileno(), 65536)
        if not chunk:
            raise RuntimeError("persistent bash stdout closed")
        self.residual.extend(chunk)

    def _drain_pending(self, selector, deadline: float) -> None:
        while self.pending_markers:
            token = ("\n" + self.pending_markers[0] + ":").encode()
            pos = self.residual.find(token)
            end = self.residual.find(b"\n", pos + 1) if pos >= 0 else -1
            if end >= 0:
                del self.residual[: end + 1]
                self.pending_markers.pop(0)
                continue
            self._read_once(selector, deadline, "terminal session is still draining a timed-out command")

    def execute(self, command: str, timeout: float) -> dict:
        if self.proc.poll() is not None:
            raise RuntimeError(f"persistent bash exited: {self.proc.returncode}")
        marker = "__JIGAEWOL_DONE_" + uuid.uuid4().hex + "__"
        payload = (
            command
            + "\n__jigaewol_ec=$?\nprintf \"\\n"
            + marker
            + ":%s\\n\" \"$__jigaewol_ec\"\n"
        ).encode()
        with self.lock, selectors.DefaultSelector() as selector:
            selector.register(self.proc.stdout, selectors.EVENT_READ)
            deadline = time.monotonic() + timeout
            self._drain_pending(selector, deadline)
            self.proc.stdin.write(payload)
            self.proc.stdin.flush()
            token = ("\n" + marker + ":").encode()
            while True:
                pos = self.residual.find(token)
                end = self.residual.find(b"\n", pos + 1) if pos >= 0 else -1
                if end >= 0:
                    marker_line = self.residual[pos + 1 : end].decode("utf-8", "replace")
                    status = int(marker_line.rsplit(":", 1)[1])
                    body = bytes(self.residual[:pos]).decode("utf-8", "replace")
                    del self.residual[: end + 1]
                    return {"stdout": body, "exit_code": status}
                try:
                    self._read_once(selector, deadline, "persistent terminal command timed out")
                except TimeoutError:
                    self.pending_markers.append(marker)
                    raise

    def snapshot(self, timeout: float = 3.0) -> dict:
        """Observe a bounded, non-secret shell recovery subset.

        Full shell/process state is intentionally not serialized. We retain only a cwd
        inside the durable workspace and a small allowlist of dynamic environment keys.
        """
        prefix = "__JIGAEWOL_SHELL_SNAPSHOT__"
        code = (
            "import json,os; print("
            + repr(prefix)
            + "+json.dumps({'cwd':os.getcwd(),'env':dict(os.environ)},ensure_ascii=False,sort_keys=True))"
        )
        command = shlex.quote(sys.executable) + " -c " + shlex.quote(code)
        result = self.execute(command, timeout)
        payload = None
        for line in reversed(str(result.get("stdout") or "").splitlines()):
            if line.startswith(prefix):
                payload = json.loads(line[len(prefix):])
                break
        if not isinstance(payload, dict):
            raise RuntimeError("shell snapshot marker missing")
        raw_cwd = Path(str(payload.get("cwd") or "")).resolve()
        try:
            rel = raw_cwd.relative_to(self.workspace).as_posix()
            cwd_within = True
        except ValueError:
            rel = ""
            cwd_within = False
        raw_env = dict(payload.get("env") or {})
        safe_names = {"PATH", "PYTHONPATH", "VIRTUAL_ENV", "NODE_ENV", "NVM_DIR", "CONDA_PREFIX", "CONDA_DEFAULT_ENV"}
        dynamic: dict[str, str] = {}
        excluded_sensitive: list[str] = []
        for key, value in raw_env.items():
            key = str(key); value = str(value)
            if self.base_env.get(key) == value or key in {"PWD", "OLDPWD", "SHLVL", "_", "JIGAEWOL_WORKSPACE"}:
                continue
            if re.search(r"(?:TOKEN|SECRET|PASS(?:WORD|WD)?|COOKIE|AUTH|CREDENTIAL|API[_-]?KEY|PRIVATE[_-]?KEY)", key, re.I):
                excluded_sensitive.append(key)
                continue
            allowed = key in safe_names or key.startswith("JIGAEWOL_PERSIST_")
            if allowed and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) and len(value) <= 4096:
                dynamic[key] = value
        return {
            "cwd_within_workspace": cwd_within,
            "cwd_relative": rel,
            "dynamic_env": dynamic,
            "excluded_sensitive_env_count": len(excluded_sensitive),
            "excluded_sensitive_env_names": sorted(excluded_sensitive),
            "shell_process_state_preserved": False,
            "background_jobs_preserved": False,
        }

    def close(self):
        if self.proc.poll() is None:
            try:
                self.proc.stdin.write(b"exit\n")
                self.proc.stdin.flush()
                self.proc.wait(timeout=2)
            except (BrokenPipeError, subprocess.TimeoutExpired, OSError):
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    self.proc.kill()


def serve(socket_path: Path, token_path: Path, meta_path: Path, workspace: Path):
    # chmod after create leaves a window where the umask decides who can read the bearer
    # token or connect to the socket. Narrow the umask first so they are never group- or
    # world-readable, even briefly.
    os.umask(0o077)
    workspace.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex + uuid.uuid4().hex
    token_path.write_text(token, encoding="utf-8")
    os.chmod(token_path, 0o600)
    if socket_path.exists():
        socket_path.unlink()
    shell = _PersistentBash(workspace)
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(str(socket_path))
    os.chmod(socket_path, 0o600)
    server.listen(8)
    meta = {
        "session_id": "local-" + uuid.uuid4().hex,
        "pid": os.getpid(),
        "bash_pid": shell.proc.pid,
        "socket": str(socket_path),
        "workspace": str(workspace.resolve()),
        "started_at": time.time(),
        "shell_state_scope": "process",
        "workspace_durability": "filesystem_until_deleted",
        "cwd_rehydrate_policy": "workspace_root",
        "dynamic_environment_rehydrate_policy": "not_preserved",
    }
    meta_path.write_text(json.dumps(meta, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    os.chmod(meta_path, 0o600)

    def _graceful_signal(signum, _frame):
        raise SystemExit(128 + int(signum))

    signal.signal(signal.SIGTERM, _graceful_signal)
    signal.signal(signal.SIGINT, _graceful_signal)
    try:
        while True:
            conn, _ = server.accept()
            with conn:
                try:
                    request = json.loads(_recv_line(conn).decode("utf-8"))
                    supplied = request.get("token")
                    if not isinstance(supplied, str) or not hmac.compare_digest(supplied, token):
                        raise PermissionError("invalid terminal bridge token")
                    operation = request.get("op")
                    if operation == "ping":
                        response = {"ok": True, "meta": meta, "bash_alive": shell.proc.poll() is None}
                    elif operation == "exec":
                        command = request.get("command")
                        if not isinstance(command, str) or not command:
                            raise ValueError("command is required")
                        response = {
                            "ok": True,
                            **shell.execute(command, float(request.get("timeout", 30))),
                            "meta": meta,
                        }
                    elif operation == "snapshot":
                        response = {"ok": True, "snapshot": shell.snapshot(float(request.get("timeout", 3))), "meta": meta}
                    elif operation == "close":
                        response = {"ok": True, "closing": True, "meta": meta}
                        conn.sendall((json.dumps(response) + "\n").encode())
                        break
                    else:
                        raise ValueError("unknown terminal bridge operation")
                except Exception as exc:
                    response = {"ok": False, "error_type": type(exc).__name__, "error": str(exc)}
                conn.sendall((json.dumps(response, ensure_ascii=False) + "\n").encode("utf-8"))
    finally:
        shell.close()
        server.close()
        try:
            socket_path.unlink()
        except FileNotFoundError:
            pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--socket", required=True)
    parser.add_argument("--token-file", required=True)
    parser.add_argument("--meta-file", required=True)
    parser.add_argument("--workspace", required=True)
    args = parser.parse_args()
    serve(Path(args.socket), Path(args.token_file), Path(args.meta_file), Path(args.workspace))


if __name__ == "__main__":
    main()
