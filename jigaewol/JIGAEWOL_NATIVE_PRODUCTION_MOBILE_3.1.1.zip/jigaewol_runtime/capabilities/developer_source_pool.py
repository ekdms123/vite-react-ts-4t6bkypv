from __future__ import annotations

"""Curated developer open-source candidates verified through the connected GitHub surface.

Rows in this module are discovery seeds only. They do not imply installation,
connection, license approval, execution, or compatibility with the current host.
Materialization must still pass the normal source-inspection and isolated-execution
lifecycle before a candidate can become an executable JIGAEWOL capability.
"""

import re
from copy import deepcopy


DEVELOPER_SOURCE_POOL = (
    {
        "name": "OpenHands",
        "source_ref": "https://github.com/OpenHands/OpenHands",
        "source_type": "github_open_source",
        "keywords": ("coding agent", "software engineering agent", "terminal", "repository", "sandbox"),
        "roles": ("cognition:domain_delegate_software", "compute:exec", "workspace:persistent"),
    },
    {
        "name": "Aider",
        "source_ref": "https://github.com/Aider-AI/aider",
        "source_type": "github_open_source",
        "keywords": ("coding agent", "pair programming", "terminal", "git", "repository"),
        "roles": ("cognition:domain_delegate_software", "search:code_ecosystem"),
    },
    {
        "name": "Continue",
        "source_ref": "https://github.com/continuedev/continue",
        "source_type": "github_open_source",
        "keywords": ("coding agent", "developer assistant", "ide", "code", "agent"),
        "roles": ("cognition:domain_delegate_software", "search:developer_docs"),
    },
    {
        "name": "Cline",
        "source_ref": "https://github.com/cline/cline",
        "source_type": "github_open_source",
        "keywords": ("coding agent", "terminal", "browser", "mcp", "code"),
        "roles": ("cognition:domain_delegate_software", "browser:interact", "compute:exec"),
    },
    {
        "name": "OpenCode",
        "source_ref": "https://github.com/anomalyco/opencode",
        "source_type": "github_open_source",
        "keywords": ("coding agent", "terminal", "cli", "software agent", "code"),
        "roles": ("cognition:domain_delegate_software", "compute:exec"),
    },
    {
        "name": "Goose",
        "source_ref": "https://github.com/aaif-goose/goose",
        "source_type": "github_open_source",
        "keywords": ("coding agent", "developer agent", "terminal", "mcp", "automation"),
        "roles": ("cognition:domain_delegate_software", "compute:exec", "capability:discover_execute"),
    },
    {
        "name": "SWE-agent",
        "source_ref": "https://github.com/SWE-agent/SWE-agent",
        "source_type": "github_open_source",
        "keywords": ("software engineering agent", "coding agent", "benchmark", "repository", "terminal"),
        "roles": ("cognition:domain_delegate_software", "compute:exec"),
    },
    {
        "name": "browser-use",
        "source_ref": "https://github.com/browser-use/browser-use",
        "source_type": "github_open_source",
        "keywords": ("browser automation", "browser agent", "web", "playwright", "automation"),
        "roles": ("browser:interact", "search:web_current"),
    },
    {
        "name": "PydanticAI",
        "source_ref": "https://github.com/pydantic/pydantic-ai",
        "source_type": "github_open_source",
        "keywords": ("agent framework", "python", "tools", "structured output", "evaluation"),
        "roles": ("cognition:parallel_delegate", "capability:discover_execute"),
    },
    {
        "name": "LangGraph",
        "source_ref": "https://github.com/langchain-ai/langgraph",
        "source_type": "github_open_source",
        "keywords": ("agent orchestration", "graph", "workflow", "state", "multi agent"),
        "roles": ("cognition:parallel_delegate", "automation:continuity"),
    },
    {
        "name": "LiteLLM",
        "source_ref": "https://github.com/BerriAI/litellm",
        "source_type": "github_open_source",
        "keywords": ("llm gateway", "model routing", "proxy", "providers", "observability"),
        "roles": ("capability:discover_execute", "cognition:general_delegate"),
    },
    {
        "name": "Daytona",
        "source_ref": "https://github.com/daytonaio/daytona",
        "source_type": "github_open_source",
        "keywords": ("sandbox", "code execution", "developer environment", "workspace", "agent"),
        "roles": ("compute:remote_exec", "workspace:persistent"),
    },
    {
        "name": "E2B",
        "source_ref": "https://github.com/e2b-dev/E2B",
        "source_type": "github_open_source",
        "keywords": ("sandbox", "code execution", "agent", "isolated execution", "cloud"),
        "roles": ("compute:remote_exec", "workspace:persistent"),
    },
    {
        "name": "MCP Servers",
        "source_ref": "https://github.com/modelcontextprotocol/servers",
        "source_type": "github_open_source",
        "keywords": ("mcp", "model context protocol", "server", "tools", "connectors"),
        "roles": ("capability:discover_execute",),
    },
)


def _tokens(value: str) -> set[str]:
    return {x for x in re.findall(r"[a-z0-9_:+.-]+", str(value or "").casefold()) if len(x) > 1}


def developer_source_pool_snapshot() -> tuple[dict, ...]:
    out = []
    for row in DEVELOPER_SOURCE_POOL:
        item = deepcopy(row)
        item.update({
            "execution_state": "candidate_unmaterialized",
            "installed": False,
            "connected": False,
            "callable": False,
            "executed": False,
            "license_state": "resolve_during_source_inspection",
            "truth_boundary": "github_repository_verified_candidate_not_execution_evidence",
        })
        out.append(item)
    return tuple(out)


def search_developer_source_pool(need: str, *, limit: int | None = None) -> tuple[dict, ...]:
    query = _tokens(need)
    if not query:
        return ()
    ranked = []
    for row in developer_source_pool_snapshot():
        hay = _tokens(" ".join((row["name"], row["source_ref"], *row["keywords"], *row["roles"])))
        score = len(query & hay)
        phrase_bonus = 1 if str(need).casefold() in " ".join(row["keywords"]).casefold() else 0
        if score or phrase_bonus:
            ranked.append((score + phrase_bonus, row["name"].casefold(), row))
    ranked.sort(key=lambda x: (-x[0], x[1]))
    selected = ranked if limit is None else ranked[: max(0, int(limit))]
    return tuple(deepcopy(row) for _, _, row in selected)
