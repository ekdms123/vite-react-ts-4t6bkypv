"""Typed executable capability manifests and provider-neutral HOST routing."""
from .manifest import CapabilityManifest, canonical_role, normalize_capability, normalize_capabilities, validate_parameters, provider_arguments, capability_is_callable
from .source_inspection import inspect_source_bundle
from .fabric_plan import build_execution_fabric_plan
from .plugins import HostPluginRouter, PluginInvocation, plugin_capability, preset_plugin_capabilities, image_generation_capability, skill_capability, cognition_capability_stack, native_chat_capability_stack, self_expanding_capability_templates
from .acquisition import AcquisitionLedger, assess_capability_need
from .workstation import virtual_workstation_plan
from .developer_source_pool import DEVELOPER_SOURCE_POOL, developer_source_pool_snapshot, search_developer_source_pool

__all__ = [
    "CapabilityManifest", "canonical_role", "normalize_capability", "normalize_capabilities", "validate_parameters", "provider_arguments", "capability_is_callable", "inspect_source_bundle", "build_execution_fabric_plan",
    "HostPluginRouter", "PluginInvocation", "plugin_capability", "preset_plugin_capabilities", "image_generation_capability", "skill_capability", "cognition_capability_stack", "native_chat_capability_stack", "self_expanding_capability_templates",
    "AcquisitionLedger", "assess_capability_need", "virtual_workstation_plan", "DEVELOPER_SOURCE_POOL", "developer_source_pool_snapshot", "search_developer_source_pool",
]

from .action_router import HostActionRouter, HostActionInvocation, declared_actions, requested_action, action_surface_snapshot
from .terminal_protocol import terminal_command_plan, terminal_backplane_status
__all__ += ["HostActionRouter", "HostActionInvocation", "declared_actions", "requested_action", "action_surface_snapshot", "terminal_command_plan", "terminal_backplane_status"]

from .local_terminal_bridge import LocalTerminalBridge, capability_spec as local_terminal_capability_spec
__all__ += ["LocalTerminalBridge", "local_terminal_capability_spec"]

from .materializer import MaterializationStep, plan_open_source_materialization
from .perception import PerceptionStep, plan_signed_in_perception, signed_in_perception_status
__all__ += ["MaterializationStep", "plan_open_source_materialization", "PerceptionStep", "plan_signed_in_perception", "signed_in_perception_status"]
