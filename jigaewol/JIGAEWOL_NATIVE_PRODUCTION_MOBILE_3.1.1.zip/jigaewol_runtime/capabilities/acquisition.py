from __future__ import annotations

"""Capability acquisition truth ledger.

This module does not install or invoke anything by itself. It records discovery,
inspection, installation, current callability, execution evidence, and scoped
integration. External connection state reported by a real executor is preserved as
observation. Unknown metadata is preserved verbatim and the candidate space stays open-set.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path

from .ranker import rank_capabilities
from .manifest import normalize_capabilities, capability_is_callable


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def assess_capability_need(need: str, specs) -> dict:
    need = _text(need, "capability need")
    if specs is None:
        specs = ()
    if isinstance(specs, (str, bytes)) or not isinstance(specs, (list, tuple)):
        raise ValueError("capability specs must be a list or tuple")
    normalized = normalize_capabilities(specs)
    callable_specs = [item for item in normalized if capability_is_callable(item)]
    ranked = rank_capabilities(need, callable_specs) if callable_specs else []
    if ranked:
        spec, score = ranked[0]
        return {
            "status": "satisfied",
            "need": need,
            "capability_id": spec["id"],
            "score": float(score),
            "route_basis": "need_ranked_connected_capability",
        }
    return {
        "status": "acquisition_required",
        "need": need,
        "capability_id": None,
        "score": None,
        "route_basis": "no_connected_capability_with_positive_need_evidence",
    }


class AcquisitionLedger:
    """Persistent open-set ledger for capability acquisition lifecycle truth."""

    def __init__(self, path=None):
        self.path = Path(path) if path is not None else None
        self._rows: dict[str, dict] = {}
        if self.path is not None and self.path.exists():
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("candidates", {}), dict):
                raise ValueError("invalid capability acquisition ledger")
            self._rows = deepcopy(data.get("candidates", {}))

    def _persist(self):
        if self.path is None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"version": 1, "candidates": self._rows}
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _candidate_id(need: str, source_type: str, source_ref: str) -> str:
        raw = json.dumps([need, source_type, source_ref], ensure_ascii=False, separators=(",", ":"))
        return "acq_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

    def discover(self, *, need, source_type, source_ref, metadata=None):
        need = _text(need, "capability need")
        source_type = _text(source_type, "capability source_type")
        source_ref = _text(source_ref, "capability source_ref")
        if metadata is None:
            metadata = {}
        if not isinstance(metadata, dict):
            raise ValueError("capability metadata must be an object")
        cid = self._candidate_id(need, source_type, source_ref)
        row = self._rows.get(cid, {})
        row.update({
            "candidate_id": cid,
            "need": need,
            "source_type": source_type,
            "source_ref": source_ref,
            "metadata": deepcopy(metadata),
            "discovered": True,
            "inspected": bool(row.get("inspected", False)),
            "connection_required": row.get("connection_required", metadata.get("connection_required", None)),
            "installed": bool(row.get("installed", False)),
            "connected": row.get("connected", None),
            "callable": row.get("callable", None),
            "executed": bool(row.get("executed", False)),
            "integrated": bool(row.get("integrated", False)),
        })
        self._rows[cid] = row
        self._persist()
        return cid

    def _row(self, candidate_id):
        candidate_id = _text(candidate_id, "candidate id")
        if candidate_id not in self._rows:
            raise KeyError(candidate_id)
        return self._rows[candidate_id]

    def inspect(self, candidate_id, *, findings):
        if not isinstance(findings, dict):
            raise ValueError("inspection findings must be an object")
        row = self._row(candidate_id)
        row["inspected"] = True
        row["inspection"] = deepcopy(findings)
        self._persist()
        return self.get(candidate_id)


    def augment_inspection(self, candidate_id, *, findings):
        if not isinstance(findings, dict):
            raise ValueError("inspection findings must be an object")
        row = self._row(candidate_id)
        merged = deepcopy(row.get("inspection") or {})
        merged.update(deepcopy(findings))
        row["inspection"] = merged
        row["inspected"] = True
        self._persist()
        return self.get(candidate_id)

    def set_connection_requirement(self, candidate_id, *, connection_required=None):
        """Record a real host/service connection requirement as observed state."""
        row = self._row(candidate_id)
        if connection_required is not None and not isinstance(connection_required, bool):
            raise ValueError("connection_required must be boolean or None")
        if connection_required is not None:
            row["connection_required"] = connection_required
        self._persist()
        return self.get(candidate_id)

    def authorize(self, candidate_id, *, authorization_ref, scope):
        row = self._row(candidate_id)
        row["authorized"] = True
        row["authorization_ref"] = _text(authorization_ref, "authorization_ref")
        row["authorization_scope"] = _text(scope, "authorization scope")
        self._persist()
        return self.get(candidate_id)

    def keep_goal_open(self, candidate_id, *, reason):
        row = self._row(candidate_id)
        row["candidate_goal_kept_open"] = True
        row.setdefault("goal_open_reasons", []).append(_text(reason, "goal open reason"))
        self._persist()
        return self.get(candidate_id)

    def install(self, candidate_id, *, evidence_ref):
        row = self._row(candidate_id)
        # A real executor/service may report authentication or connection requirements.
        row["installed"] = True
        row["installation_evidence_ref"] = _text(evidence_ref, "installation evidence_ref")
        self._persist()
        return self.get(candidate_id)

    def connect(self, candidate_id, *, evidence_ref):
        row = self._row(candidate_id)
        if not row.get("installed"):
            raise ValueError("connection requires installation")
        if row.get("connection_required") is False:
            row["connected"] = True
            row["connection_evidence_ref"] = _text(evidence_ref, "connection evidence_ref")
            self._persist()
            return self.get(candidate_id)
        # The actual executor is the source of truth for whether a connection was
        # performed, prompted for authentication, or unavailable.
        row["connected"] = True
        row["connection_evidence_ref"] = _text(evidence_ref, "connection evidence_ref")
        self._persist()
        return self.get(candidate_id)

    def mark_callable(self, candidate_id, *, callable_now, evidence_ref):
        if not isinstance(callable_now, bool):
            raise ValueError("callable_now must be boolean")
        row = self._row(candidate_id)
        if not row.get("installed"):
            raise ValueError("callability probe requires installation")
        if row.get("connection_required") is True and row.get("connected") is not True:
            raise ValueError("callability probe requires completed connection")
        row["callable"] = callable_now
        row["callability_evidence_ref"] = _text(evidence_ref, "callability evidence_ref")
        self._persist()
        return self.get(candidate_id)

    def record_execution(self, candidate_id, *, result, origin_ref):
        row = self._row(candidate_id)
        if row.get("callable") is not True:
            raise ValueError("execution requires current callable evidence")
        origin_ref = _text(origin_ref, "execution origin_ref")
        # A provider error is a real attempted invocation, not successful execution.
        # Retain failed observations without upgrading the capability to "executed".
        failed = isinstance(result, dict) and (
            result.get("success") is False or result.get("ok") is False
            or result.get("isError") is True or result.get("is_error") is True
            or (result.get("error") not in (None, "", False))
            or str(result.get("status", "")).casefold() in {"error", "failed", "failure"}
        )
        # Non-error is not the same as successful execution: empty/pending/ambiguous
        # payloads are attempts with unknown outcome, never completion evidence.
        successful = isinstance(result, dict) and (
            result.get("success") is True or result.get("ok") is True
            or str(result.get("status", "")).casefold() in {"success", "succeeded", "completed", "complete"}
        ) and not failed
        observation = {"origin_ref": origin_ref, "result": deepcopy(result)}
        if failed:
            row.setdefault("execution_attempt_failures", []).append(observation)
            row["candidate_goal_kept_open"] = True
        elif successful:
            row["executed"] = True
            row.setdefault("execution_evidence", []).append(observation)
        else:
            row.setdefault("execution_unconfirmed_attempts", []).append(observation)
            row["candidate_goal_kept_open"] = True
        self._persist()
        return self.get(candidate_id)

    def integrate(self, candidate_id, *, capability_id, scope):
        row = self._row(candidate_id)
        if not row.get("executed"):
            raise ValueError("integration requires execution evidence")
        row["integrated"] = True
        row["capability_id"] = _text(capability_id, "capability_id")
        row["integration_scope"] = _text(scope, "integration scope")
        self._persist()
        return self.get(candidate_id)

    def block(self, candidate_id, *, stage, reason, evidence_ref=None):
        row = self._row(candidate_id)
        row["blocked"] = True
        row["blocked_stage"] = _text(stage, "blocked stage")
        row["blocker_reason"] = _text(reason, "blocker reason")
        if evidence_ref is not None:
            row["blocker_evidence_ref"] = _text(evidence_ref, "blocker evidence_ref")
        entry={
            "stage": row["blocked_stage"], "reason": row["blocker_reason"],
            "evidence_ref": row.get("blocker_evidence_ref"),
        }
        history=row.setdefault("blocker_history", [])
        if not history or history[-1] != entry:
            history.append(entry)
        self._persist()
        return self.get(candidate_id)

    def clear_blocker(self, candidate_id):
        row = self._row(candidate_id)
        for key in ("blocked", "blocked_stage", "blocker_reason", "blocker_evidence_ref"):
            row.pop(key, None)
        self._persist()
        return self.get(candidate_id)

    def record_route_failure(self, candidate_id, *, reason):
        """Record evidence that one route failed while keeping the capability goal open."""
        row = self._row(candidate_id)
        reason_text = _text(reason, "route failure reason")
        row["blocked"] = True
        row["blocked_stage"] = "observed_route_failure"
        row["blocker_reason"] = reason_text
        row.setdefault("route_failure_history", []).append({"reason": reason_text})
        self._persist()
        return self.get(candidate_id)

    def get(self, candidate_id):
        return deepcopy(self._row(candidate_id))

    def reconcile_callable_surface(self, capabilities, *, evidence_ref):
        """Reconcile explicit candidate identities with the current callable HOST surface.

        No fuzzy matching is allowed here: installation names, providers and prose
        descriptions are not callability evidence. A candidate is updated only
        when its metadata (or already-integrated row) declares an exact capability
        id that the current host actually exposes.
        """
        from .manifest import normalize_capabilities, capability_is_callable

        evidence_ref = _text(evidence_ref, "callable-surface evidence_ref")
        specs = normalize_capabilities(capabilities or ())
        callable_ids = {str(spec["id"]) for spec in specs if capability_is_callable(spec)}
        changed = []
        for cid, row in self._rows.items():
            metadata = row.get("metadata") if isinstance(row.get("metadata"), dict) else {}
            declared = set()
            for value in (row.get("capability_id"), metadata.get("capability_id")):
                if isinstance(value, str) and value.strip():
                    declared.add(value.strip())
            values = metadata.get("capability_ids", ())
            if isinstance(values, str):
                values = (values,)
            if isinstance(values, (list, tuple, set, frozenset)):
                declared.update(str(x).strip() for x in values if isinstance(x, str) and x.strip())
            matched = sorted(declared & callable_ids)
            if not matched:
                continue
            before = deepcopy(row)
            # Current callability is stronger evidence than a stale connection flag.
            row["connected"] = True
            row["callable"] = True
            row["callability_evidence_ref"] = evidence_ref
            row["callability_match"] = matched
            if before != row:
                changed.append(deepcopy(row))
        if changed:
            self._persist()
        return tuple(changed)

    def snapshot(self):
        return tuple(deepcopy(self._rows[key]) for key in sorted(self._rows))
