"""Run the original ZIP kernel in an existing chat Python/terminal sandbox.

No server, new account, model API or paid provider is initialized. Native host
tools return their real results against the current pending invocation.
"""
from __future__ import annotations
import hashlib,json,os,sqlite3,stat,tempfile,zipfile
from pathlib import Path
from jigaewol_components.execution_cost_policy import assert_zero_spend,execution_policy
from jigaewol_components.state_transaction import state_transaction
from jigaewol_runtime.mobile_adapters import configured_adapters
from jigaewol_runtime.mobile_service import MobileRuntimeService
from jigaewol_components.free_route_broker import FreeRouteBroker

class InChatSandbox:
    def __init__(self,state_root,*,user_id='owner'):
        self.root=Path(state_root).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.root.chmod(0o700)
        os.environ['JIGAEWOL_RUNTIME_HOME']=str(self.root/'home')
        self.policy=execution_policy()
        self.runtime=MobileRuntimeService(self.root,user_id=user_id,adapters=configured_adapters(self.root))
        self.runtime.register_configured_adapters()
        self.free_routes=FreeRouteBroker(self.root/'personal_memory'/'free_routes')
        self.local_adapters=set(configured_adapters(self.root))
        self.routes_path=self.root/'free_host_routes.json'
        if not self.routes_path.exists():self._write_routes({})

    def _write_routes(self,rows):
        fd,name=tempfile.mkstemp(dir=self.root,prefix='.routes-')
        try:
            with os.fdopen(fd,'w') as stream:json.dump(rows,stream,ensure_ascii=False);stream.flush();os.fsync(stream.fileno())
            os.replace(name,self.routes_path)
        finally:Path(name).unlink(missing_ok=True)
    def _routes(self):return json.loads(self.routes_path.read_text())
    def _view(self,result):return {**result,'execution_surface':'in_chat_sandbox','execution_cost_policy':self.policy,'new_server_or_api_started':False}

    def register_host_tool(self,name,*,traits,billing_mode,proof_ref,quoted_usd=0):
        receipt=assert_zero_spend(provider=name,quoted_usd=quoted_usd,billing_mode=billing_mode,proof_ref=proof_ref)
        with state_transaction(self.root/'inchat.lock'):
            rows=self._routes();rows[str(name)]=receipt;self._write_routes(rows)
            self.runtime.register_capability(str(name),traits=tuple(traits),effect_class='read')
            for trait in traits:
                self.free_routes.register(route_id=str(name),capability=str(trait),pool='native_host:'+str(name),
                    billing_mode=billing_mode,proof_ref=proof_ref,quoted_usd=quoted_usd,connected=True,
                    observation_ref=proof_ref)
        return receipt

    def begin(self,**arguments):
        with state_transaction(self.root/'inchat.lock'):return self._view(self.runtime.begin(**arguments))
    def next(self,turn_id):return self._view(self.runtime.next(turn_id))
    def resume(self,turn_id):
        with state_transaction(self.root/'inchat.lock'):return self._view(self.runtime.resume(turn_id))
    def publish(self,turn_id):return self.runtime.publish(turn_id)
    def candidate(self,**arguments):
        with state_transaction(self.root/'inchat.lock'):
            if arguments.get('operation')=='run':
                from jigaewol_components.candidate_lab import CandidateLab
                row=self.runtime._turn(arguments['turn_id'])
                lab=CandidateLab(self.runtime._scope_root(row)/'candidate_lab')
                with lab.db() as db:
                    found=db.execute('SELECT body FROM candidates WHERE id=?',(arguments['arguments']['candidate_id'],)).fetchone()
                if not found:raise KeyError('unknown candidate')
                allowed=self.local_adapters|set(self._routes())
                if any(step['capability'] not in allowed for step in json.loads(found[0])['operator_program']):
                    raise PermissionError('candidate retained; bind an observed zero-spending route before execution')
            return self.runtime.candidate(**arguments)
    def policy_operation(self,**arguments):
        with state_transaction(self.root/'inchat.lock'):return self.runtime.policy(**arguments)
    def execute(self,*,turn_id,invocation_id,arguments):
        with state_transaction(self.root/'inchat.lock'):
            with self.runtime.db() as db:
                prior=db.execute('SELECT 1 FROM effects WHERE turn_id=? AND invocation=?',(turn_id,invocation_id)).fetchone()
            if prior:
                return self._view(self.runtime.execute_action(turn_id=turn_id,invocation_id=invocation_id,arguments=arguments))
            pending=self.runtime.next(turn_id)['request'];payload=pending.get('request_payload') or {}
            name=self.runtime._adapter_name(payload)
            if name not in self.runtime.adapters:raise ValueError('next step uses an actual registered native host tool')
            if name not in self.local_adapters and name not in self._routes():
                raise PermissionError('restored third-party adapter needs a current zero-spending route receipt')
            assert_zero_spend(provider=name,quoted_usd=0,billing_mode='local_included',proof_ref='existing_chat_sandbox')
            return self._view(self.runtime.execute_action(turn_id=turn_id,invocation_id=invocation_id,arguments=arguments))

    def route_select(self,**arguments):return self.free_routes.select(**arguments)
    def route_register(self,**arguments):return self.free_routes.register(**arguments)
    def route_observe_quota(self,**arguments):return self.free_routes.observe_quota(**arguments)

    def observe_host(self,*,turn_id,host_event_id,observed_result,tool_name=None):
        with state_transaction(self.root/'inchat.lock'):
            pending=self.runtime.next(turn_id)['request']
            if pending.get('kind')=='action':
                route=self._routes().get(str(tool_name))
                if not route:raise PermissionError('bind a verified zero-spending host route before calling it')
                assert_zero_spend(provider=tool_name,quoted_usd=route['additional_spend_usd'],billing_mode=route['billing_mode'],proof_ref=route['proof_ref'])
                if observed_result.get('executor_id')!=tool_name:raise ValueError('actual host executor must match its free route receipt')
            return self._view(self.runtime.observe(turn_id=turn_id,host_event_id=host_event_id,observed_result=observed_result))

    def checkpoint(self,destination):
        destination=Path(destination).resolve()
        if destination==self.root or self.root in destination.parents:raise ValueError('capsule must be outside runtime state')
        with state_transaction(self.root/'inchat.lock'),tempfile.TemporaryDirectory(prefix='jigaewol-checkpoint-') as tmp:
            temporary=Path(tmp);rows=[]
            for path in sorted(self.root.rglob('*')):
                if not path.is_file() or path.is_symlink():continue
                relative=path.relative_to(self.root)
                if any(x in {'browser','mcp_token','owner_token','private','cookies'} for x in relative.parts) or path.name.endswith(('-wal','-shm','.lock')):continue
                target=temporary/relative;target.parent.mkdir(parents=True,exist_ok=True)
                if path.suffix in {'.sqlite3','.db'}:
                    with sqlite3.connect(path) as src,sqlite3.connect(target) as dst:src.backup(dst)
                else:target.write_bytes(path.read_bytes())
                rows.append({'path':relative.as_posix(),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'size':target.stat().st_size})
            manifest={'schema':'jigaewol_inchat_state_v1','origin_root':str(self.root),'authority':['USER','JIGAEWOL','MODEL'],'additional_spend_usd':0,'members':rows}
            destination.parent.mkdir(parents=True,exist_ok=True)
            fd,name=tempfile.mkstemp(dir=destination.parent,prefix='.capsule-');os.close(fd)
            try:
                with zipfile.ZipFile(name,'w',compression=zipfile.ZIP_DEFLATED) as archive:
                    archive.writestr('STATE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False))
                    for row in rows:archive.write(temporary/row['path'],'state/'+row['path'])
                os.replace(name,destination)
            finally:Path(name).unlink(missing_ok=True)
        return {'artifact':str(destination),'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'files':len(rows),'additional_spend_usd':0,'known_external_credential_files_excluded':True,'journal_integrity_key_retained':True}

    @staticmethod
    def restore(capsule,state_root=None):
        with zipfile.ZipFile(capsule) as archive:
            infos=archive.infolist();names=[x.filename for x in infos]
            if len(names)!=len(set(names)) or len(names)>20000 or sum(x.file_size for x in infos)>128*1024*1024:raise ValueError('invalid capsule membership or size')
            manifest=json.loads(archive.read('STATE_MANIFEST.json'));rows=manifest['members']
            if manifest.get('schema')!='jigaewol_inchat_state_v1':raise ValueError('unsupported state capsule')
            # Keep authenticated journals and request hashes byte-identical. The
            # portable chat path is stable; never rewrite a signed request to move it.
            root=Path(state_root or manifest['origin_root']).resolve()
            if root.exists() and any(root.iterdir()):raise ValueError('restore into a fresh state directory')
            if set(names)!={'STATE_MANIFEST.json',*('state/'+x['path'] for x in rows)}:raise ValueError('unmanifested capsule entry')
            verified=[];seen=set()
            for row in rows:
                rel=str(row['path']);target=(root/rel).resolve()
                if rel in seen or root not in target.parents or '..' in Path(rel).parts or '\\' in rel or stat.S_ISLNK((archive.getinfo('state/'+rel).external_attr>>16)&0xffff):raise ValueError('unsafe state path')
                seen.add(rel);data=archive.read('state/'+rel)
                if len(data)!=row['size'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('state hash mismatch')
                verified.append((target,data))
            root.mkdir(parents=True,exist_ok=True);root.chmod(0o700)
            for target,data in verified:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);target.chmod(0o600)
            if str(root)!=manifest['origin_root']:
                (root/'RESTORED_PATH_BINDINGS.json').write_text(json.dumps({
                    'origin_root':manifest['origin_root'],'current_root':str(root),
                    'signed_request_bytes_preserved':True},ensure_ascii=False))
        return {'restored_files':len(verified),'state_root':str(root),'additional_spend_usd':0,
                'signed_request_bytes_preserved':True,'origin_root':manifest['origin_root']}
