from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib, json, math

@dataclass(frozen=True)
class BoundaryCase:
    features: dict[str, float | bool | str]
    action: str
    rationale: str = ""

@dataclass(frozen=True)
class DecisionBoundary:
    boundary_id: str
    discriminators: tuple[str, ...]
    cases: tuple[BoundaryCase, ...]
    default_action: str
    flip_conditions: tuple[dict, ...] = ()
    priority: int = 0

@dataclass(frozen=True)
class BoundaryDecision:
    action: str
    boundary_id: str
    confidence: float
    matched_case: int | None
    decisive_features: tuple[str, ...]


def _sim(a: dict, b: dict, keys: tuple[str, ...]) -> float:
    score = 0.0; total = 0.0
    for k in keys:
        if k not in a or k not in b:
            continue
        total += 1.0
        av, bv = a[k], b[k]
        if isinstance(av, bool) or isinstance(bv, bool):
            score += 1.0 if type(av) is bool and type(bv) is bool and av == bv else 0.0
        elif (isinstance(av, (int, float)) and not isinstance(av, bool) and
              isinstance(bv, (int, float)) and not isinstance(bv, bool)):
            af, bf = float(av), float(bv)
            score += math.exp(-abs(af - bf)) if math.isfinite(af) and math.isfinite(bf) else 0.0
        else:
            score += 1.0 if str(av).casefold() == str(bv).casefold() else 0.0
    return score / total if total else 0.0

class BoundaryStore:
    """Executable library of 'what would make the decision flip?' assets."""
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else None
        self.boundaries: dict[str, DecisionBoundary] = {}
        if self.path and self.path.exists(): self._load()

    def add(self, discriminators, cases, default_action, *, flip_conditions=(), priority=0, boundary_id=None):
        norm_cases = tuple(c if isinstance(c, BoundaryCase) else BoundaryCase(**c) for c in cases)
        if isinstance(priority, bool) or not isinstance(priority, int):
            raise ValueError("boundary priority must be an integer, not a boolean")
        raw = json.dumps({"d": list(discriminators), "c": [asdict(c) for c in norm_cases], "a": default_action},
                         sort_keys=True, allow_nan=False)
        bid = boundary_id or "boundary_" + hashlib.sha256(raw.encode()).hexdigest()[:16]
        obj = DecisionBoundary(bid, tuple(discriminators), norm_cases, str(default_action), tuple(flip_conditions), priority)
        self.boundaries[bid] = obj
        self._save(); return obj

    def decide(self, features: dict) -> BoundaryDecision:
        best = None
        for boundary in self.boundaries.values():
            for i, case in enumerate(boundary.cases):
                sim = _sim(features, case.features, boundary.discriminators)
                candidate = (sim, boundary.priority, boundary, i, case)
                if best is None or candidate[:2] > best[:2]: best = candidate
        if best is None:
            raise LookupError("no decision boundaries installed")
        sim, _, boundary, idx, case = best
        action = case.action if sim >= .5 else boundary.default_action
        decisive = tuple(k for k in boundary.discriminators if k in features and k in case.features)
        return BoundaryDecision(action, boundary.boundary_id, sim, idx if sim >= .5 else None, decisive)

    def _save(self):
        if not self.path: return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        rows=[]
        for b in self.boundaries.values():
            rows.append({**asdict(b),"cases":[asdict(c) for c in b.cases]})
        self.path.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf-8")

    def _load(self):
        for row in json.loads(self.path.read_text(encoding="utf-8")):
            row["cases"] = tuple(BoundaryCase(**x) for x in row.get("cases",()))
            row["discriminators"] = tuple(row.get("discriminators",()))
            row["flip_conditions"] = tuple(row.get("flip_conditions",()))
            obj=DecisionBoundary(**row); self.boundaries[obj.boundary_id]=obj
