from __future__ import annotations
from dataclasses import dataclass, asdict
import operator

@dataclass(frozen=True)
class Condition:
    feature: str
    op: str
    value: object = True

@dataclass(frozen=True)
class Rule:
    when: tuple[Condition, ...]
    action: str
    priority: int = 0
    unless: tuple[Condition, ...] = ()

_OPS={
    'eq':operator.eq,'ne':operator.ne,'lt':operator.lt,'le':operator.le,
    'gt':operator.gt,'ge':operator.ge,'in':lambda a,b:a in b,
    'not_in':lambda a,b:a not in b,
}

def _condition(x):
    if isinstance(x,Condition): return x
    if isinstance(x,dict) and {'feature','op'} <= set(x): return Condition(str(x['feature']),str(x['op']),x.get('value',True))
    raise ValueError('condition must be Condition or {feature,op,value}')

class DecisionRuleKernel:
    """Executable rule layer for externalized judgment boundaries.

    Rules are inspectable data; the model may propose them, but the runtime
    executes equality/threshold/membership conditions deterministically.
    """
    def __init__(self, rules=()): self.rules=[]; self.install(rules)
    def add(self, when, action, *, priority=0, unless=()):
        # Backward-compatible exact-match dictionary syntax.
        if isinstance(when,dict): wh=tuple(Condition(str(k),'eq',v) for k,v in sorted(when.items()))
        else: wh=tuple(_condition(x) for x in when)
        if isinstance(unless,dict): un=tuple(Condition(str(k),'eq',v) for k,v in sorted(unless.items()))
        else: un=tuple(_condition(x) for x in unless)
        if isinstance(priority,bool) or not isinstance(priority,int): raise ValueError('rule priority must be an integer')
        r=Rule(wh,str(action),priority,un); self.rules.append(r); return r
    @staticmethod
    def _match_one(facts,c):
        actual=facts.get(c.feature)
        if c.op=='truthy': return bool(actual)
        if c.op=='falsy': return not bool(actual)
        fn=_OPS.get(c.op)
        if fn is None: raise ValueError(f'unsupported rule op: {c.op}')
        try:return bool(fn(actual,c.value))
        except (TypeError,ValueError):return False
    @classmethod
    def _match(cls,facts,conditions): return all(cls._match_one(facts,c) for c in conditions)
    def decide(self, facts, *, default='open'):
        eligible=[]
        for idx,r in enumerate(self.rules):
            if self._match(facts,r.when) and not (r.unless and self._match(facts,r.unless)):
                eligible.append((r.priority,len(r.when),-idx,r))
        if not eligible:return {'action':default,'rule':None,'facts':dict(facts)}
        r=max(eligible)[-1]; return {'action':r.action,'rule':r,'facts':dict(facts)}
    def export(self): return [asdict(r) for r in self.rules]
    def install(self,rows):
        for row in rows or ():
            if isinstance(row,Rule): self.rules.append(row); continue
            d=dict(row); d['when']=tuple(_condition(x) for x in d.get('when',())); d['unless']=tuple(_condition(x) for x in d.get('unless',()))
            if isinstance(d.get('priority',0),bool) or not isinstance(d.get('priority',0),int): raise ValueError('rule priority must be an integer')
            self.rules.append(Rule(**d))
        return self
