from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib,json

_NX_SENTINEL = object()
_nx = _NX_SENTINEL

def _networkx():
    """Load networkx only if graph hashing is actually exercised.

    Canonical turn ingress constructs causal-memory objects on every turn but
    usually does not hash a causal graph. Eager networkx import added material
    cold-start latency to unrelated chat turns.
    """
    global _nx
    if _nx is _NX_SENTINEL:
        try:
            import networkx as loaded
        except ImportError:  # portable fallback
            loaded = None
        _nx = loaded
    return _nx

@dataclass(frozen=True)
class CausalMechanism:
    mechanism_id: str
    bottleneck: str
    nodes: tuple[tuple[str,str], ...]  # (id, role)
    edges: tuple[tuple[str,str,str], ...]  # (src,dst,relation)
    operation: str
    preconditions: tuple[str,...]=()
    failure_modes: tuple[str,...]=()
    payload: dict | None=None


def _fallback_hash(nodes,edges,iterations=3):
    labels={n:r for n,r in nodes}
    outgoing={n:[] for n,_ in nodes}; incoming={n:[] for n,_ in nodes}
    for a,b,r in edges:
        outgoing.setdefault(a,[]).append((r,b)); incoming.setdefault(b,[]).append((r,a))
    for _ in range(iterations):
        nxt={}
        for n in labels:
            parts=[labels[n]]
            parts += sorted("o:"+r+":"+labels.get(b,"") for r,b in outgoing.get(n,()))
            parts += sorted("i:"+r+":"+labels.get(a,"") for r,a in incoming.get(n,()))
            nxt[n]=hashlib.blake2b("|".join(parts).encode(),digest_size=16).hexdigest()
        labels=nxt
    return hashlib.blake2b("|".join(sorted(labels.values())).encode(),digest_size=16).hexdigest()


def graph_hash(mechanism: CausalMechanism) -> str:
    nx = _networkx()
    if nx is not None:
        g=nx.DiGraph()
        for n,r in mechanism.nodes: g.add_node(n, role=r)
        for a,b,r in mechanism.edges: g.add_edge(a,b, relation=r)
        return nx.weisfeiler_lehman_graph_hash(g,node_attr="role",edge_attr="relation",iterations=3)
    return _fallback_hash(mechanism.nodes,mechanism.edges)


def _edge_features(m): return {f"{dict(m.nodes).get(a,'?')}::{r}::{dict(m.nodes).get(b,'?')}" for a,b,r in m.edges}
def _jaccard(a,b): return len(a&b)/len(a|b) if a|b else 1.0

class CausalMemory:
    """Cross-domain memory keyed by causal role topology, not vocabulary overlap."""
    def __init__(self,path: str|Path|None=None):
        self.path=Path(path) if path else None; self.items={}
        if self.path and self.path.exists(): self._load()
    def add(self,m:CausalMechanism): self.items[m.mechanism_id]=m; self._save(); return m
    def retrieve(self,query:CausalMechanism,k=None):
        if k is not None and (type(k) is not int or k < 1):
            raise ValueError("causal recall k must be a positive integer or None")
        qh=graph_hash(query); qf=_edge_features(query)
        ranked=[]
        for m in self.items.values():
            h=graph_hash(m); structural=1.0 if h==qh else _jaccard(qf,_edge_features(m))
            bottleneck=1.0 if m.bottleneck.casefold()==query.bottleneck.casefold() else 0.0
            pre=_jaccard(set(m.preconditions),set(query.preconditions))
            score=.65*structural+.25*bottleneck+.10*pre
            ranked.append((score,m))
        ordered = sorted(ranked,key=lambda x:x[0],reverse=True)
        return ordered if k is None else ordered[:k]
    def _save(self):
        if not self.path:return
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.path.write_text(json.dumps([asdict(x) for x in self.items.values()],ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    def _load(self):
        for x in json.loads(self.path.read_text(encoding="utf-8")):
            for key in ("nodes","edges","preconditions","failure_modes"):
                x[key]=tuple(tuple(y) if isinstance(y,list) else y for y in x.get(key,())) if key in {"nodes","edges"} else tuple(x.get(key,()))
            m=CausalMechanism(**x); self.items[m.mechanism_id]=m
