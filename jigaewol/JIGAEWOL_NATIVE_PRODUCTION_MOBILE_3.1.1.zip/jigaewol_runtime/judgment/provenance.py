from __future__ import annotations
from pathlib import Path
import hashlib,platform,sys

DEFAULT_EXCLUDE_DIRS={'.git','.pytest_cache','__pycache__','build','dist','.venv','venv'}

def tree_manifest(root,include_suffixes=(".py",".json",".txt",".md",".toml"),exclude_dirs=DEFAULT_EXCLUDE_DIRS):
    root=Path(root); rows=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.suffix not in include_suffixes: continue
        rel_parts=p.relative_to(root).parts
        if any(part in exclude_dirs or part.endswith('.egg-info') for part in rel_parts): continue
        rel=p.relative_to(root).as_posix(); data=p.read_bytes()
        rows.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'size':len(data)})
    return rows

def merkleish_root(rows):
    h=hashlib.sha256()
    for row in sorted(rows,key=lambda x:x['path']):
        h.update(row['path'].encode()); h.update(b'\0'); h.update(row['sha256'].encode()); h.update(b'\n')
    return h.hexdigest()

def runtime_fingerprint(package_root,kernel_sha256=None):
    rows=tree_manifest(package_root)
    return {'engine_tree_sha256':merkleish_root(rows),'file_count':len(rows),'kernel_sha256':kernel_sha256,'python':sys.version.split()[0],'platform':platform.platform()}
