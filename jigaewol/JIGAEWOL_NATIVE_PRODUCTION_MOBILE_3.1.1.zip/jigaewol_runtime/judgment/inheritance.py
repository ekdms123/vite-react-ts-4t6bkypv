from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import hashlib,json

@dataclass(frozen=True)
class JudgmentPack:
    pack_id:str
    version:int
    boundaries:tuple[dict,...]
    lenses:tuple[dict,...]
    residuals:tuple[dict,...]
    causal_mechanisms:tuple[dict,...]
    decision_programs:tuple[dict,...]
    validation_receipts:tuple[dict,...]
    parent_pack_ids:tuple[str,...]=()


def build_pack(*,boundaries=(),lenses=(),residuals=(),causal_mechanisms=(),decision_programs=(),validation_receipts=(),parent_pack_ids=()):
    body={"version":2,"boundaries":list(boundaries),"lenses":list(lenses),"residuals":list(residuals),"causal_mechanisms":list(causal_mechanisms),"decision_programs":list(decision_programs),"validation_receipts":list(validation_receipts),"parent_pack_ids":list(parent_pack_ids)}
    raw=json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False)
    return JudgmentPack("jpack_"+hashlib.sha256(raw.encode()).hexdigest()[:20],2,tuple(body["boundaries"]),tuple(body["lenses"]),tuple(body["residuals"]),tuple(body["causal_mechanisms"]),tuple(body["decision_programs"]),tuple(body["validation_receipts"]),tuple(body["parent_pack_ids"]))

def save_pack(pack:JudgmentPack,path):
    Path(path).write_text(json.dumps(asdict(pack),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def load_pack(path):
    d=json.loads(Path(path).read_text(encoding='utf-8'))
    # v1 compatibility: decision_programs did not exist.
    d.setdefault('decision_programs',())
    d.setdefault('version',1)
    for k in ("boundaries","lenses","residuals","causal_mechanisms","decision_programs","validation_receipts","parent_pack_ids"):
        d[k]=tuple(d.get(k,()))
    if d['version']==1:
        d['version']=2
        body={k:d[k] for k in ("boundaries","lenses","residuals","causal_mechanisms","decision_programs","validation_receipts","parent_pack_ids")}
        body['version']=2
        d['pack_id']='jpack_'+hashlib.sha256(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()[:20]
    return JudgmentPack(**d)
