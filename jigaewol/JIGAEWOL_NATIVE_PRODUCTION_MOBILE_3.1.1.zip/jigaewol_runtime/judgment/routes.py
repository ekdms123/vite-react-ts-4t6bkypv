from __future__ import annotations
from dataclasses import dataclass
import ast, operator

_ALLOWED_BIN={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv}
_ALLOWED_CMP={ast.Eq:operator.eq,ast.NotEq:operator.ne,ast.Lt:operator.lt,ast.LtE:operator.le,ast.Gt:operator.gt,ast.GtE:operator.ge,ast.In:lambda a,b:a in b,ast.NotIn:lambda a,b:a not in b}

class PredicateError(ValueError): pass

@dataclass(frozen=True)
class ExecutablePredicate:
    expression: str
    def evaluate(self, observation: dict) -> bool:
        tree=ast.parse(self.expression,mode='eval')
        def ev(n):
            if isinstance(n,ast.Expression): return ev(n.body)
            if isinstance(n,ast.Constant): return n.value
            if isinstance(n,ast.Name): return observation.get(n.id)
            if isinstance(n,ast.Subscript): return ev(n.value)[ev(n.slice)]
            if isinstance(n,ast.List): return [ev(x) for x in n.elts]
            if isinstance(n,ast.Tuple): return tuple(ev(x) for x in n.elts)
            if isinstance(n,ast.BoolOp):
                vals=[bool(ev(x)) for x in n.values]
                return all(vals) if isinstance(n.op,ast.And) else any(vals)
            if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.Not): return not bool(ev(n.operand))
            if isinstance(n,ast.BinOp) and type(n.op) in _ALLOWED_BIN: return _ALLOWED_BIN[type(n.op)](ev(n.left),ev(n.right))
            if isinstance(n,ast.Compare):
                left=ev(n.left)
                for op,rightn in zip(n.ops,n.comparators):
                    right=ev(rightn); fn=_ALLOWED_CMP.get(type(op))
                    if fn is None or not fn(left,right): return False
                    left=right
                return True
            raise PredicateError(f"unsupported predicate node: {type(n).__name__}")
        return bool(ev(tree))

@dataclass(frozen=True)
class Route:
    route_id: str
    execute: object
    falsifier: ExecutablePredicate | None = None
    abandon: ExecutablePredicate | None = None
    alternates: tuple[str,...] = ()

@dataclass(frozen=True)
class RouteResult:
    route_id: str
    status: str
    observation: dict
    attempts: tuple[str,...]
    failure: str | None = None

class RouteExecutor:
    """Small durable-style route switcher: failure is data, not conversation death."""
    def __init__(self): self.routes={}
    def add(self, route: Route): self.routes[route.route_id]=route; return route
    def run(self, route_id: str, context: dict | None=None, *, max_hops=None) -> RouteResult:
        if max_hops is not None and (type(max_hops) is not int or max_hops < 1):
            raise ValueError("max_hops must be a positive integer when explicitly supplied")
        context=dict(context or {}); queue=[route_id]; seen=[]; last_failure=None
        while queue and (max_hops is None or len(seen)<max_hops):
            rid=queue.pop(0)
            if rid in seen: continue
            seen.append(rid); route=self.routes[rid]
            try:
                out=route.execute(context)
                obs=out if isinstance(out,dict) else {"output":out}
                if route.falsifier and route.falsifier.evaluate(obs):
                    last_failure="falsifier_true"; queue.extend(route.alternates); continue
                if route.abandon and route.abandon.evaluate(obs):
                    last_failure="abandon_true"; queue.extend(route.alternates); continue
                return RouteResult(rid,"success",obs,tuple(seen),None)
            except Exception as exc:
                last_failure=f"{type(exc).__name__}: {exc}"; queue.extend(route.alternates)
        return RouteResult(seen[-1] if seen else route_id,"failed",{},tuple(seen),last_failure or "no_route")
