from __future__ import annotations
from dataclasses import dataclass
import re

@dataclass(frozen=True)
class TurnEvent:
    kind: str
    confidence: float
    evidence: tuple[str, ...] = ()

_CONTINUE = {"이어서", "계속", "계속해", "계속해줘", "진행", "진행해", "continue", "go on", "keep going"}
_CANCEL = {"취소", "그만", "중단", "멈춰", "cancel", "stop"}
_FEEDBACK = ("좋아", "별로", "잘했", "틀렸", "피드백", "good", "bad", "wrong")
_FEEDBACK_CONTEXT = ("답변", "결과", "방금", "이전", "그거", "이거", "response", "answer", "result")
_CORRECTION = ("아니", "말고", "정정", "바꿔", "수정", "이전", "instead", "change", "correction")


_PERSISTENCE_CONTINUATION = re.compile(
    r"(?:"
    r"쭉\s*(?:좀\s*)?(?:밀|가|진행|해)"
    r"|끝까지\s*(?:좀\s*)?(?:밀|가|진행|해)"
    r"|멈추지\s*(?:마|말고|마라|말아)"
    r"|(?:왜\s*)?(?:자꾸|계속)[^\n]{0,32}멈추"
    r"|keep\s+(?:pushing|going)"
    r"|do\s+not\s+stop|don't\s+stop"
    r"|why\s+do\s+you\s+keep\s+stopping"
    r")",
    re.IGNORECASE,
)


def _clean(text: str) -> str:
    return " ".join(str(text).casefold().strip().split()).rstrip(".!?~…")


def classify_turn_event(text: str, *, has_open_task: bool = False) -> TurnEvent:
    t = _clean(text)
    if not t:
        return TurnEvent("EMPTY", 1.0, ())
    if t in _CANCEL:
        return TurnEvent("CANCEL", .99, (t,))
    if t in _CONTINUE:
        return TurnEvent("CONTINUE", .99, (t,))
    if has_open_task and _PERSISTENCE_CONTINUATION.search(t):
        return TurnEvent("CONTINUE", .97, ("persistence_continuation",))
    if has_open_task:
        # Control commands often arrive with a short correction/confirmation payload
        # (e.g. "이어서~ 그런데 이것도 같이 고치는 거 맞지?"). Treat a
        # leading continuation phrase as runtime-control intent instead of inventing
        # a new task merely because the message is longer than a few characters.
        lead = t[:32]
        if any(x in lead for x in _CONTINUE) or re.match(r"^(?:멈췄?우?면\s*)?(?:이어서|계속|진행)", t):
            return TurnEvent("CONTINUE", .96, tuple(x for x in _CONTINUE if x in lead) or (lead,))
    if has_open_task and any(x in t for x in _CORRECTION):
        return TurnEvent("CORRECTION", .85, tuple(x for x in _CORRECTION if x in t))
    if has_open_task:
        hits = tuple(x for x in _FEEDBACK if x in t)
        leading_feedback = any(
            t == x or t.startswith(x + " ") or t.startswith(x + ",") or t.startswith(x + ".")
            or x in {"잘했", "틀렸"} and t.startswith(x)
            for x in hits
        )
        contextual_feedback = bool(hits) and any(x in t for x in _FEEDBACK_CONTEXT)
        if leading_feedback or contextual_feedback:
            return TurnEvent("FEEDBACK", .72, hits)
    return TurnEvent("NEW_GOAL", .75 if has_open_task else .95, ())


def term_present(text: str, term: str) -> bool:
    """Conservative lexical detector with local Korean/English negation handling.

    It is intentionally not a semantic parser. Its job is to avoid the v8 bug
    where an explicitly negated keyword still flips a positive feature bit.
    """
    s = str(text).casefold()
    term = str(term).casefold()
    for m in re.finditer(re.escape(term), s):
        lo = max(0, m.start() - 18)
        hi = min(len(s), m.end() + 14)
        window = s[lo:hi]
        if re.search(r"(?:하지\s*마|말고|아니|금지|no\s+|not\s+|without\s+)[^\n]{0,10}" + re.escape(term), window):
            continue
        if re.search(re.escape(term) + r"[^\n]{0,8}(?:하지\s*마|말고|아니|금지|하지\s*않)", window):
            continue
        return True
    return False
