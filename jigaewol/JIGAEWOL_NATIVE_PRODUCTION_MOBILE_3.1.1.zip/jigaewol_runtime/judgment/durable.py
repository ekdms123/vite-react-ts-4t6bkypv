from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json,sqlite3,time,uuid

@dataclass(frozen=True)
class RunEvent:
    seq:int; run_id:str; task_id:str; kind:str; payload:dict

class DurableRunStore:
    """Authoritative event log for resumable cognition runs.

    Inspired by durable-execution/event-sourcing systems, but intentionally small
    enough to remain portable inside the ZIP runtime.
    """
    def __init__(self,path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.path) as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS run_events(
              seq INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL, task_id TEXT NOT NULL,
              kind TEXT NOT NULL, payload_json TEXT NOT NULL, created_at REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS run_events_run_idx ON run_events(run_id,seq);
            CREATE TABLE IF NOT EXISTS task_heads(
              task_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, status TEXT NOT NULL, updated_at REAL NOT NULL);
            ''')
    def start(self,task_id):
        run_id='run_'+uuid.uuid4().hex[:16]; self.append(run_id,task_id,'RUN_STARTED',{})
        return run_id
    def append(self,run_id,task_id,kind,payload):
        with sqlite3.connect(self.path) as c:
            cur=c.execute('INSERT INTO run_events(run_id,task_id,kind,payload_json,created_at) VALUES(?,?,?,?,?)',(run_id,task_id,kind,json.dumps(payload,ensure_ascii=False,sort_keys=True,allow_nan=False),time.time()))
            status={'RUN_FINISHED':'finished','RUN_CANCELLED':'cancelled','RUN_FAILED':'failed'}.get(kind,'active')
            c.execute('INSERT INTO task_heads(task_id,run_id,status,updated_at) VALUES(?,?,?,?) ON CONFLICT(task_id) DO UPDATE SET run_id=excluded.run_id,status=excluded.status,updated_at=excluded.updated_at',(task_id,run_id,status,time.time()))
            return int(cur.lastrowid)
    def replay(self,run_id):
        with sqlite3.connect(self.path) as c:
            rows=c.execute('SELECT seq,run_id,task_id,kind,payload_json FROM run_events WHERE run_id=? ORDER BY seq',(run_id,)).fetchall()
        return [RunEvent(r[0],r[1],r[2],r[3],json.loads(r[4])) for r in rows]
    def head(self,task_id):
        with sqlite3.connect(self.path) as c:
            row=c.execute('SELECT run_id,status FROM task_heads WHERE task_id=?',(task_id,)).fetchone()
        return {'run_id':row[0],'status':row[1]} if row else None
    def interrupted(self,task_id):
        h=self.head(task_id); return bool(h and h['status']=='active')
