from __future__ import annotations

"""Goal-preserving translation of observed execution failures.

A failed operation changes only the observed route state. It never rewrites the
user's contract or shrinks the user's destination.
"""

from jigaewol_components.user_contract import OPERATIONAL_CONTRACT_TEXT

def translate_failure(*, operation:str, error_type:str, error_text:str, goal_anchor_ids=(), capabilities=()) -> dict:
    text=str(error_text).casefold(); et=str(error_type)
    if "permission" in text or "not allowed" in text or et in {"PermissionError"}:
        origin="observed_permission_failure"
    elif "not found" in text or et in {"FileNotFoundError","KeyError"}:
        origin="missing_resource_or_route"
    elif "timeout" in text or et in {"TimeoutError"}:
        origin="execution_budget_or_latency"
    else:
        origin="route_failure_unknown_origin"
    alternatives=[]
    caps=[str(x) for x in capabilities]
    if caps: alternatives.append("switch_connected_capability")
    alternatives += ["change_representation","change_search_lineage","apply_local_judgment","decompose_then_reenter","preserve_open_variable_and_complete_unblocked_material"]
    return {
        "version":3,
        "user_contract": OPERATIONAL_CONTRACT_TEXT,
        "blocked_operation":str(operation),
        "boundary_origin":origin,
        "goal_anchor_ids":[str(x) for x in goal_anchor_ids],
        "goal_policy":"keep_live_unless_user_supersedes_or_cancels",
        "route_classes":alternatives,
        "instruction":"Choose a route that preserves the live user goal; do not convert one blocked route into a smaller objective.",
    }
