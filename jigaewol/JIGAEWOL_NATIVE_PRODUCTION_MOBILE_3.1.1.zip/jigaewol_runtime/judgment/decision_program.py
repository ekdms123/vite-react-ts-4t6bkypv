from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from collections import Counter
import hashlib, json, math

@dataclass(frozen=True)
class LabeledCase:
    features: dict
    action: str
    weight: float = 1.0

@dataclass(frozen=True)
class DecisionProgram:
    program_id: str
    tree: dict
    feature_names: tuple[str, ...]
    actions: tuple[str, ...]
    source_case_sha256: tuple[str, ...]
    training_accuracy: float
    version: int = 1

    def decide(self, features: dict) -> dict:
        if not isinstance(features, dict):
            raise ValueError('decision features must be an object')
        _validate_program(self)
        node=self.tree; path=[]
        while node.get('kind')=='split':
            feature=node['feature']; op=node['op']; value=node['value']; actual=features.get(feature)
            yes=False
            try:
                if op=='le':
                    if isinstance(actual, bool) or isinstance(value, bool):
                        yes=False
                    else:
                        af, vf = float(actual), float(value)
                        yes=math.isfinite(af) and math.isfinite(vf) and af <= vf
                elif op=='eq': yes=actual == value
                else: raise ValueError(f'unsupported decision op: {op}')
            except (TypeError,ValueError): yes=False
            path.append({'feature':feature,'op':op,'value':value,'actual':actual,'branch':'yes' if yes else 'no','gain':node.get('gain',0.0)})
            node=node['yes'] if yes else node['no']
        confidence=_finite_number(node.get('confidence',0.0), 'decision leaf confidence', minimum=0.0, maximum=1.0)
        return {'program_id':self.program_id,'action':node['action'],'confidence':confidence,'path':path,'leaf_counts':dict(node.get('counts',{}))}


def _canon(v): return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def _case_hash(c): return hashlib.sha256(_canon({'features':c.features,'action':c.action,'weight':c.weight}).encode()).hexdigest()

def _finite_number(value, label, *, minimum=None, maximum=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(label + ' must be a finite number')
    number=float(value)
    if not math.isfinite(number):
        raise ValueError(label + ' must be a finite number')
    if minimum is not None and number < minimum:
        raise ValueError(label + f' must be >= {minimum}')
    if maximum is not None and number > maximum:
        raise ValueError(label + f' must be <= {maximum}')
    return number

def _validate_tree(node, *, depth=0, max_depth=256):
    if not isinstance(node, dict):
        raise ValueError('decision tree node must be an object')
    if depth > max_depth:
        raise ValueError('decision tree exceeds structural depth limit')
    kind=node.get('kind')
    if kind=='leaf':
        action=node.get('action')
        if not isinstance(action, str) or not action.strip():
            raise ValueError('decision leaf action must be nonempty text')
        _finite_number(node.get('confidence',0.0), 'decision leaf confidence', minimum=0.0, maximum=1.0)
        counts=node.get('counts',{})
        if not isinstance(counts, dict):
            raise ValueError('decision leaf counts must be an object')
        for key,value in counts.items():
            if not isinstance(key, str) or not key:
                raise ValueError('decision leaf count keys must be nonempty text')
            _finite_number(value, 'decision leaf count', minimum=0.0)
        return
    if kind!='split':
        raise ValueError('decision tree node kind must be split or leaf')
    feature=node.get('feature')
    if not isinstance(feature, str) or not feature.strip():
        raise ValueError('decision split feature must be nonempty text')
    if node.get('op') not in {'le','eq'}:
        raise ValueError('decision split op must be le or eq')
    if 'value' not in node:
        raise ValueError('decision split needs value')
    _canon(node['value'])
    _finite_number(node.get('gain',0.0), 'decision split gain', minimum=0.0)
    _validate_tree(node.get('yes'), depth=depth+1, max_depth=max_depth)
    _validate_tree(node.get('no'), depth=depth+1, max_depth=max_depth)

def _validate_program(program):
    if not isinstance(program, DecisionProgram):
        raise ValueError('decision program must be a DecisionProgram')
    if not isinstance(program.program_id, str) or not program.program_id.strip():
        raise ValueError('decision program id must be nonempty text')
    if type(program.version) is not int or program.version < 1:
        raise ValueError('decision program version must be a positive integer')
    for label, values in (('feature_names',program.feature_names),('actions',program.actions),('source_case_sha256',program.source_case_sha256)):
        if not isinstance(values, tuple) or any(not isinstance(x,str) or not x for x in values):
            raise ValueError('decision program '+label+' must be a tuple of nonempty text')
    _finite_number(program.training_accuracy, 'decision program training_accuracy', minimum=0.0, maximum=1.0)
    _validate_tree(program.tree)
    return program
def _gini(cases):
    total=sum(max(0.0,float(c.weight)) for c in cases)
    if total<=0:return 0.0
    counts=Counter()
    for c in cases: counts[c.action]+=max(0.0,float(c.weight))
    return 1.0-sum((w/total)**2 for w in counts.values())
def _majority(cases):
    counts=Counter()
    for c in cases: counts[c.action]+=max(0.0,float(c.weight))
    action,weight=max(sorted(counts.items()), key=lambda kv:(kv[1],kv[0]))
    total=sum(counts.values()) or 1.0
    return action, dict(counts), weight/total

class DecisionProgramCompiler:
    """Compile labeled judgment examples into a small executable decision tree.

    This deliberately externalizes *decision boundaries*, not prose answers.
    Candidate splits are deterministic numeric thresholds or categorical equalities.
    The resulting program is data, portable, content-addressed, and executable
    without asking a model to rediscover the boundary.
    """
    def __init__(self, *, max_depth=None, min_gain=1e-9):
        # Default is convergence-driven: stop on pure leaves / no material gain.
        # An explicit max_depth is a caller-supplied resource horizon, not a
        # developer-convenience cognitive ceiling.
        if max_depth is not None and (isinstance(max_depth, bool) or not isinstance(max_depth, int) or max_depth < 1):
            raise ValueError('max_depth must be None or a positive integer')
        if isinstance(min_gain, bool) or not isinstance(min_gain, (int, float)) or not math.isfinite(float(min_gain)) or min_gain < 0:
            raise ValueError('min_gain must be a finite nonnegative number')
        self.max_depth=max_depth; self.min_gain=float(min_gain)

    @staticmethod
    def _normalize(cases):
        out=[]
        for c in cases:
            if isinstance(c,LabeledCase): obj=c
            else:
                raw_weight=c.get('weight',1.0)
                if isinstance(raw_weight,bool) or not isinstance(raw_weight,(int,float)) or not math.isfinite(float(raw_weight)):
                    raise ValueError('decision case weight must be a finite positive number')
                obj=LabeledCase(dict(c.get('features',{})),str(c['action']),float(raw_weight))
            if not obj.features: raise ValueError('decision case features must be nonempty')
            if not obj.action: raise ValueError('decision case action must be nonempty')
            if isinstance(obj.weight,bool) or not isinstance(obj.weight,(int,float)) or not math.isfinite(float(obj.weight)) or obj.weight<=0:
                raise ValueError('decision case weight must be a finite positive number')
            out.append(obj)
        if len(out)<2: raise ValueError('at least two labeled cases are required')
        return out

    def _candidates(self,cases):
        features=sorted({k for c in cases for k in c.features})
        for f in features:
            vals=[c.features[f] for c in cases if f in c.features]
            numeric=vals and all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(float(v)) for v in vals)
            if numeric:
                uniq=sorted(set(float(v) for v in vals))
                for a,b in zip(uniq,uniq[1:]):
                    yield f,'le',(a+b)/2
            else:
                for v in sorted(set(_canon(v) for v in vals)):
                    yield f,'eq',json.loads(v)

    @staticmethod
    def _split(cases,f,op,v):
        yes=[]; no=[]
        for c in cases:
            actual=c.features.get(f,None)
            hit=False
            try:
                hit=(actual is not None and float(actual)<=float(v)) if op=='le' else (actual==v)
            except (TypeError,ValueError): hit=False
            (yes if hit else no).append(c)
        return yes,no

    def _build(self,cases,depth):
        action,counts,confidence=_majority(cases)
        if (self.max_depth is not None and depth>=self.max_depth) or len(counts)<=1:
            return {'kind':'leaf','action':action,'counts':counts,'confidence':confidence}
        parent=_gini(cases); total=sum(c.weight for c in cases); best=None
        for f,op,v in self._candidates(cases):
            yes,no=self._split(cases,f,op,v)
            if not yes or not no: continue
            weighted=(sum(c.weight for c in yes)/total)*_gini(yes)+(sum(c.weight for c in no)/total)*_gini(no)
            gain=parent-weighted
            sig=(round(gain,15),f,op,_canon(v))
            if best is None or sig>best[0]: best=(sig,f,op,v,yes,no,gain)
        if best is None or best[-1] <= self.min_gain:
            return {'kind':'leaf','action':action,'counts':counts,'confidence':confidence}
        _,f,op,v,yes,no,gain=best
        return {'kind':'split','feature':f,'op':op,'value':v,'gain':gain,
                'yes':self._build(yes,depth+1),'no':self._build(no,depth+1)}

    def compile(self,cases):
        cases=self._normalize(cases); tree=self._build(cases,0)
        feature_names=tuple(sorted({k for c in cases for k in c.features}))
        actions=tuple(sorted({c.action for c in cases}))
        source_hashes=tuple(_case_hash(c) for c in cases)
        body={'version':1,'tree':tree,'feature_names':feature_names,'actions':actions,'source_case_sha256':source_hashes}
        pid='dprog_'+hashlib.sha256(_canon(body).encode()).hexdigest()[:20]
        temp=DecisionProgram(pid,tree,feature_names,actions,source_hashes,0.0,1)
        accuracy=sum(c.weight for c in cases if temp.decide(c.features)['action']==c.action)/sum(c.weight for c in cases)
        return DecisionProgram(pid,tree,feature_names,actions,source_hashes,accuracy,1)

class DecisionProgramStore:
    def __init__(self,path: str|Path|None=None):
        self.path=Path(path) if path else None; self.programs={}
        if self.path and self.path.exists(): self._load()
    def add(self,program:DecisionProgram):
        program=_validate_program(program); self.programs[program.program_id]=program; self._save(); return program
    def compile(self,cases,**kwargs): return self.add(DecisionProgramCompiler(**kwargs).compile(cases))
    def decide(self,program_id,features): return self.programs[program_id].decide(features)
    def export(self): return [asdict(p) for p in self.programs.values()]
    def install(self,rows):
        for row in rows or ():
            if not isinstance(row, dict): raise ValueError('decision program row must be an object')
            d=dict(row); d['feature_names']=tuple(d.get('feature_names',())); d['actions']=tuple(d.get('actions',())); d['source_case_sha256']=tuple(d.get('source_case_sha256',()))
            p=_validate_program(DecisionProgram(**d)); self.programs[p.program_id]=p
        self._save()
    def _save(self):
        if not self.path:return
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.path.write_text(json.dumps(self.export(),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    def _load(self):
        self.install(json.loads(self.path.read_text(encoding='utf-8')))
