from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib,json
from .causal_memory import CausalMechanism

@dataclass(frozen=True)
class NodeRule:
    collection: str
    id_field: str
    role: str

@dataclass(frozen=True)
class EdgeRule:
    collection: str
    src_field: str
    dst_field: str
    relation: str

@dataclass(frozen=True)
class LensSpec:
    lens_id: str
    node_rules: tuple[NodeRule,...]
    edge_rules: tuple[EdgeRule,...]
    bottleneck_field: str | None = None
    operation: str = "inspect_causal_state"


def _text(value,label):
    if not isinstance(value,str) or not value.strip():
        raise ValueError(label+' must be nonempty text')
    return value.strip()

def _validate_lens(lens):
    if not isinstance(lens,LensSpec): raise ValueError('lens must be a LensSpec')
    _text(lens.lens_id,'lens id'); _text(lens.operation,'lens operation')
    if lens.bottleneck_field is not None: _text(lens.bottleneck_field,'lens bottleneck_field')
    for rule in lens.node_rules:
        if not isinstance(rule,NodeRule): raise ValueError('node rule must be a NodeRule')
        _text(rule.collection,'node rule collection'); _text(rule.id_field,'node rule id_field'); _text(rule.role,'node rule role')
    for rule in lens.edge_rules:
        if not isinstance(rule,EdgeRule): raise ValueError('edge rule must be an EdgeRule')
        _text(rule.collection,'edge rule collection'); _text(rule.src_field,'edge rule src_field'); _text(rule.dst_field,'edge rule dst_field'); _text(rule.relation,'edge rule relation')
    return lens

def _row_id(value,label):
    if isinstance(value,bool) or not isinstance(value,(str,int,float)):
        raise ValueError(label+' must be text or a number')
    if isinstance(value,float) and (value != value or value in (float('inf'),float('-inf'))):
        raise ValueError(label+' must be finite')
    text=str(value).strip()
    if not text: raise ValueError(label+' must be nonempty')
    return text

class RepresentationTransducer:
    """Declarative raw-object -> causal-representation compiler.

    A lens is data, not a prompt. Different domains can compile into the same
    causal role graph, after which CausalMemory can reuse mechanisms across them.
    """
    def __init__(self,path=None):
        from pathlib import Path
        self.path=Path(path) if path else None; self.lenses={}
        if self.path and self.path.exists(): self.install(json.loads(self.path.read_text(encoding="utf-8")))
    def add(self,lens:LensSpec):
        lens=_validate_lens(lens); self.lenses[lens.lens_id]=lens; self._save(); return lens
    def compile(self,lens_id:str,source:dict)->CausalMechanism:
        if not isinstance(source,dict): raise ValueError('lens source must be an object')
        lens=_validate_lens(self.lenses[lens_id]); nodes=[]; edges=[]
        for rule in lens.node_rules:
            rows=source.get(rule.collection,[]) or []
            if not isinstance(rows,list): raise ValueError('lens collection '+rule.collection+' must be a list of objects')
            for row in rows:
                if not isinstance(row,dict) or rule.id_field not in row: raise ValueError('lens node row is missing '+rule.id_field)
                nodes.append((_row_id(row[rule.id_field],'lens node id'),rule.role))
        for rule in lens.edge_rules:
            rows=source.get(rule.collection,[]) or []
            if not isinstance(rows,list): raise ValueError('lens collection '+rule.collection+' must be a list of objects')
            for row in rows:
                if not isinstance(row,dict) or rule.src_field not in row or rule.dst_field not in row: raise ValueError('lens edge row is missing an endpoint field')
                edges.append((_row_id(row[rule.src_field],'lens edge source'),_row_id(row[rule.dst_field],'lens edge destination'),rule.relation))
        # Deduplicate without changing deterministic order.
        nodes=tuple(dict.fromkeys(nodes)); edges=tuple(dict.fromkeys(edges))
        bottleneck=str(source.get(lens.bottleneck_field,"unknown")) if lens.bottleneck_field else "unknown"
        raw=json.dumps({"lens":lens_id,"nodes":nodes,"edges":edges},sort_keys=True,allow_nan=False)
        mid="lensgraph_"+hashlib.sha256(raw.encode()).hexdigest()[:16]
        return CausalMechanism(mid,bottleneck,nodes,edges,lens.operation,payload={"lens_id":lens_id})

    def install(self, rows):
        if rows is None: rows=()
        if not isinstance(rows,(list,tuple)): raise ValueError('lens rows must be a list or tuple')
        for row in rows:
            if not isinstance(row,dict): raise ValueError('lens row must be an object')
            d=dict(row)
            d["node_rules"]=tuple(NodeRule(**x) if isinstance(x,dict) else x for x in d.get("node_rules",()))
            d["edge_rules"]=tuple(EdgeRule(**x) if isinstance(x,dict) else x for x in d.get("edge_rules",()))
            lens=_validate_lens(LensSpec(**d)); self.lenses[lens.lens_id]=lens
        self._save(); return tuple(self.lenses.values())
    def _save(self):
        if not self.path:return
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.path.write_text(json.dumps(self.export(),ensure_ascii=False,indent=2,allow_nan=False),encoding="utf-8")
    def export(self):
        out=[]
        for lens in self.lenses.values():
            out.append({"lens_id":lens.lens_id,"node_rules":[asdict(x) for x in lens.node_rules],"edge_rules":[asdict(x) for x in lens.edge_rules],"bottleneck_field":lens.bottleneck_field,"operation":lens.operation})
        return out
