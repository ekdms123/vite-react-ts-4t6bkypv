"""JIGAEWOL externalized judgment layer."""
from .boundary import DecisionBoundary, BoundaryCase, BoundaryStore, BoundaryDecision
from .causal_memory import CausalMemory, CausalMechanism
from .residual import ResidualCompiler, ResidualCapsule, ResidualStore
from .routes import ExecutablePredicate, Route, RouteExecutor, RouteResult
from .turn_events import TurnEvent, classify_turn_event
from .lenses import RepresentationTransducer, LensSpec, NodeRule, EdgeRule
from .inheritance import JudgmentPack, build_pack, save_pack, load_pack
from .goal_lifecycle import GoalLifecycleStore, GoalRecord
from .rule_kernel import DecisionRuleKernel, Rule, Condition
from .decision_program import DecisionProgram, DecisionProgramCompiler, DecisionProgramStore, LabeledCase

__all__ = [
    "DecisionBoundary", "BoundaryCase", "BoundaryStore", "BoundaryDecision",
    "CausalMemory", "CausalMechanism", "ResidualCompiler", "ResidualCapsule", "ResidualStore",
    "ExecutablePredicate", "Route", "RouteExecutor", "RouteResult",
    "TurnEvent", "classify_turn_event",
    "RepresentationTransducer", "LensSpec", "NodeRule", "EdgeRule",
    "JudgmentPack", "build_pack", "save_pack", "load_pack",
    "GoalLifecycleStore", "GoalRecord", "DecisionRuleKernel", "Rule", "Condition",
    "DecisionProgram", "DecisionProgramCompiler", "DecisionProgramStore", "LabeledCase",
]

from .boundary_router import translate_failure
