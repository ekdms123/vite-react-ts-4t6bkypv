from __future__ import annotations
from dataclasses import dataclass, asdict, fields
from pathlib import Path
import hashlib, json, time

from jigaewol_components.source_authority import explicit_cancel_current_task, explicit_replacement_requested

@dataclass(frozen=True)
class GoalRecord:
    goal_id: str
    meaning: str
    source_turn_id: str
    task_id: str = ''
    quote: str = ''
    status: str = 'active'
    supersedes: tuple[str,...] = ()
    created_at: float = 0.0

class GoalLifecycleStore:
    """Session-scoped lifecycle for source-addressed goals.

    The newest explicit correction can supersede older task-local anchors. This
    store is now bound to turn intake rather than existing as a side API only.
    """
    VALID={'active','superseded','withdrawn','resolved'}
    def __init__(self,path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.records={}; self._load()
    def add(self, meaning, source_turn_id, *, task_id='', quote='', supersedes=()):
        meaning=str(meaning).strip(); source_turn_id=str(source_turn_id); task_id=str(task_id or '')
        quote=str(quote or '')
        if not meaning: raise ValueError('goal meaning must be nonempty')
        # Idempotence for replay/restoration: the same source goal should not
        # duplicate merely because intake was retried.
        for rec in self.records.values():
            if rec.meaning==meaning and rec.source_turn_id==source_turn_id and rec.task_id==task_id and rec.status=='active':
                return rec
        raw=f'{source_turn_id}\x1f{task_id}\x1f{meaning}\x1f{quote}'
        gid='goal_'+hashlib.sha256(raw.encode()).hexdigest()[:16]
        # ``supersedes`` is lineage metadata only. Destructive status changes are
        # performed by sync_turn after exact-user-source authorization; add() itself
        # never gains deletion authority from a caller-supplied id list.
        rec=GoalRecord(gid,meaning,source_turn_id,task_id,quote,'active',tuple(supersedes),time.time())
        self.records[gid]=rec; self._save(); return rec
    def set_status(self,goal_id,status,*,exact_user_text=''):
        if status not in self.VALID: raise ValueError('invalid goal status')
        if goal_id not in self.records: raise KeyError(goal_id)
        if status in {'superseded','withdrawn'} and not (
            explicit_replacement_requested(exact_user_text) or explicit_cancel_current_task(exact_user_text)
        ):
            raise PermissionError('destructive goal status requires explicit exact-user-source authority')
        self._replace(goal_id,status=status); self._save(); return self.records[goal_id]
    def active(self, task_id=None):
        rows=tuple(x for x in self.records.values() if x.status=='active')
        if task_id is None: return rows
        tid=str(task_id or '')
        return tuple(x for x in rows if x.task_id==tid)
    def sync_turn(self, *, task_id, source_turn_id, requirements, event_kind='NEW_GOAL', bare_continuation=False, supersede_map=None, exact_user_text=''):
        """Apply explicit goal lifecycle semantics for one accepted intake."""
        task_id=str(task_id or ''); source_turn_id=str(source_turn_id)
        current=list(self.active(task_id))
        if str(event_kind)=='CANCEL':
            if not explicit_cancel_current_task(exact_user_text):
                # Derived classifiers cannot acquire destructive authority. If source
                # text is not itself an explicit cancel command, preserve live goals.
                event_kind='NEW_GOAL'
            else:
                for rec in current: self._replace(rec.goal_id,status='withdrawn')
                self._save(); return self.active(task_id)
        if bare_continuation:
            return self.active(task_id)
        rows=[]
        for req in requirements or ():
            if not isinstance(req,dict): continue
            meaning=str(req.get('meaning','')).strip()
            if not meaning: continue
            rows.append((meaning,str(req.get('quote',req.get('quote_preview','')) or '')))
        if str(event_kind)=='CORRECTION' and rows:
            # Destructive supersession is source-authorized, never model-authorized.
            # A semantic payload may propose supersedes_goal_ids, but without exact
            # user replacement language those ids are ignored and old goals survive.
            source_allows_replacement = explicit_replacement_requested(exact_user_text)
            # Corrections are selective by default. Older JIGAEWOL revisions
            # superseded *every* live goal on any correction turn, which could
            # silently delete unrelated user requirements. Semantic intake may
            # now bind each corrected requirement to exact goal ids. "*" is
            # accepted only when the correction explicitly replaces the whole
            # prior goal set. Without such a binding we preserve old goals and
            # add the correction, preferring temporary tension over goal loss.
            smap=(supersede_map if isinstance(supersede_map,dict) else {}) if source_allows_replacement else {}
            all_ids={x.goal_id for x in current}
            for meaning,quote in rows:
                raw=smap.get(meaning,())
                targets=set()
                for gid in raw if isinstance(raw,(list,tuple,set)) else ():
                    gid=str(gid)
                    if gid=='*': targets.update(all_ids)
                    elif gid in all_ids: targets.add(gid)
                for gid in targets:
                    if self.records[gid].status=='active': self._replace(gid,status='superseded')
                self.add(meaning,source_turn_id,task_id=task_id,quote=quote,supersedes=tuple(sorted(targets)))
            self._save(); return self.active(task_id)
        existing={x.meaning.casefold().strip() for x in self.active(task_id)}
        for meaning,quote in rows:
            if meaning.casefold().strip() not in existing:
                self.add(meaning,source_turn_id,task_id=task_id,quote=quote)
                existing.add(meaning.casefold().strip())
        self._save(); return self.active(task_id)
    def as_requirements(self, task_id):
        return [
            {'meaning':r.meaning,'quote':r.quote,'turn_id':r.source_turn_id,'status':r.status,
             'goal_id':r.goal_id,'supersedes':list(r.supersedes)}
            for r in self.active(task_id)
        ]
    def _replace(self,gid,**kw):
        d=asdict(self.records[gid]); d.update(kw); d['supersedes']=tuple(d.get('supersedes',()))
        self.records[gid]=GoalRecord(**d)
    def _save(self):
        self.path.write_text(json.dumps([asdict(x) for x in self.records.values()],ensure_ascii=False,indent=2),encoding='utf-8')
    def _load(self):
        if not self.path.exists(): return
        allowed={f.name for f in fields(GoalRecord)}
        for d in json.loads(self.path.read_text(encoding='utf-8')):
            d={k:v for k,v in d.items() if k in allowed}
            d.setdefault('task_id',''); d.setdefault('quote',''); d.setdefault('status','active'); d.setdefault('created_at',0.0)
            d['supersedes']=tuple(d.get('supersedes',())); r=GoalRecord(**d); self.records[r.goal_id]=r
