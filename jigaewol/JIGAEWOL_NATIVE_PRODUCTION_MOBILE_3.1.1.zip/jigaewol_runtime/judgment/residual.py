from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib,json

@dataclass(frozen=True)
class ResidualCapsule:
    capsule_id: str
    kind: str
    trigger_features: tuple[str,...]
    correction: dict
    executable: bool
    validation_cases: tuple[dict,...]
    source_trace_ids: tuple[str,...]=()

class ResidualCompiler:
    """Compile the delta between a weak decision and a corrected decision.

    The model does not need to relearn the whole answer. We preserve the decisive
    repeatable difference: missing fact, representation lens, operation, or control route.
    """
    KINDS={"knowledge_gap","representation_error","operation_missing","control_failure"}
    def classify(self,baseline:dict,corrected:dict)->str:
        if baseline.get("missing_information") and corrected.get("new_information"): return "knowledge_gap"
        if baseline.get("representation") != corrected.get("representation"): return "representation_error"
        if baseline.get("operation") != corrected.get("operation"): return "operation_missing"
        return "control_failure"
    def compile(self,baseline:dict,corrected:dict,*,validation_cases=(),source_trace_ids=()):
        kind=self.classify(baseline,corrected)
        diff={k:corrected.get(k) for k in corrected if baseline.get(k)!=corrected.get(k)}
        trigger=tuple(sorted(k for k in baseline if k in corrected and baseline.get(k)==corrected.get(k)))
        raw=json.dumps({"kind":kind,"trigger":trigger,"diff":diff},sort_keys=True,allow_nan=False)
        cid="residual_"+hashlib.sha256(raw.encode()).hexdigest()[:18]
        executable = kind in {"operation_missing","control_failure"} and isinstance(diff.get("operation") or diff.get("route"), (str,dict))
        return ResidualCapsule(cid,kind,trigger,diff,executable,tuple(validation_cases),tuple(source_trace_ids))
    @staticmethod
    def apply(capsule:ResidualCapsule,state:dict)->dict:
        out=dict(state); out.update(capsule.correction); return out


class ResidualStore:
    """Persistent residual capsules: the decisive correction survives the model turn."""
    def __init__(self,path=None):
        from pathlib import Path
        self.path=Path(path) if path else None; self.items={}
        if self.path and self.path.exists(): self._load()
    def add(self,capsule:ResidualCapsule): self.items[capsule.capsule_id]=capsule; self._save(); return capsule
    def export(self): return [asdict(x) for x in self.items.values()]
    def install(self,rows):
        for d in rows or ():
            d=dict(d); d['trigger_features']=tuple(d.get('trigger_features',())); d['validation_cases']=tuple(d.get('validation_cases',())); d['source_trace_ids']=tuple(d.get('source_trace_ids',()))
            c=ResidualCapsule(**d); self.items[c.capsule_id]=c
        self._save()
    def _save(self):
        if not self.path:return
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.path.write_text(json.dumps(self.export(),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    def _load(self): self.install(json.loads(self.path.read_text(encoding='utf-8')))
