"""Single-owner OAuth with PKCE, durable grants and revocable token rotation."""
from __future__ import annotations
import hashlib
import hmac
import html
import json
import secrets
import sqlite3
import time
import base64
from urllib.parse import urlencode, urlsplit

def sha(value): return hashlib.sha256(str(value).encode()).hexdigest()

class OwnerOAuth:
    def __init__(self, path, *, issuer, owner_secret, redirect_hosts=('chatgpt.com','chat.openai.com','localhost','127.0.0.1')):
        self.path = str(path)
        self.issuer = str(issuer).rstrip('/')
        self.owner_secret = owner_secret
        self.redirect_hosts = frozenset(redirect_hosts)
        with self.db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS clients(id TEXT PRIMARY KEY, body TEXT);
            CREATE TABLE IF NOT EXISTS attempts(id TEXT PRIMARY KEY, body TEXT, expires REAL);
            CREATE TABLE IF NOT EXISTS codes(hash TEXT PRIMARY KEY, body TEXT, expires REAL);
            CREATE TABLE IF NOT EXISTS tokens(hash TEXT PRIMARY KEY, client TEXT, kind TEXT, expires REAL);
            ''')

    def db(self):
        db = sqlite3.connect(self.path,timeout=30); db.execute('PRAGMA journal_mode=WAL'); return db

    def metadata(self):
        return {'issuer':self.issuer,'authorization_endpoint':self.issuer+'/authorize',
                'token_endpoint':self.issuer+'/token','registration_endpoint':self.issuer+'/register',
                'revocation_endpoint':self.issuer+'/revoke','response_types_supported':['code'],
                'grant_types_supported':['authorization_code','refresh_token'],
                'token_endpoint_auth_methods_supported':['none'],'code_challenge_methods_supported':['S256'],
                'scopes_supported':['jigaewol']}

    def register(self, value):
        redirects = value.get('redirect_uris')
        if not isinstance(redirects,list) or not redirects or len(redirects)>10: raise ValueError('redirect_uris required')
        for uri in redirects:
            parsed = urlsplit(uri)
            if parsed.hostname not in self.redirect_hosts or parsed.fragment or parsed.username:
                raise ValueError('redirect host not registered for this owner service')
            if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in {'localhost','127.0.0.1'}):
                raise ValueError('redirect requires HTTPS')
        if value.get('token_endpoint_auth_method','none') != 'none': raise ValueError('use public PKCE client')
        cid = secrets.token_urlsafe(24)
        result = {'client_id':cid,'redirect_uris':redirects,'token_endpoint_auth_method':'none','grant_types':['authorization_code','refresh_token'],'response_types':['code']}
        with self.db() as db: db.execute('INSERT INTO clients VALUES (?,?)',(cid,json.dumps(result)))
        return result

    def _validate_authorize(self, value):
        with self.db() as db: row = db.execute('SELECT body FROM clients WHERE id=?',(value.get('client_id'),)).fetchone()
        if not row or value.get('redirect_uri') not in json.loads(row[0])['redirect_uris']: raise ValueError('invalid client redirect')
        challenge = value.get('code_challenge','')
        if value.get('response_type')!='code' or value.get('code_challenge_method')!='S256' or len(challenge)!=43:
            raise ValueError('authorization_code requires S256 PKCE')
        if value.get('resource',self.issuer+'/mcp') != self.issuer+'/mcp': raise ValueError('invalid resource')
        if value.get('scope','jigaewol') not in {'','jigaewol'}: raise ValueError('invalid scope')
        return dict(value)

    def authorize_page(self, value):
        value = self._validate_authorize(value)
        attempt = secrets.token_urlsafe(32)
        with self.db() as db:
            db.execute('DELETE FROM attempts WHERE expires<?',(time.time(),))
            db.execute('INSERT INTO attempts VALUES (?,?,?)',(sha(attempt),json.dumps(value),time.time()+600))
        return ('<!doctype html><html lang="ko"><meta name="viewport" content="width=device-width,initial-scale=1">'
                '<title>JIGAEWOL 연결</title><main><h1>개인 JIGAEWOL 연결</h1><p>ChatGPT가 사용자의 ZIP 작업·파일·재개 상태에 접근하도록 연결합니다.</p>'
                '<form method="post" action="/authorize"><input type="hidden" name="attempt" value="'+html.escape(attempt)+'">'
                '<label>소유자 연결 키 <input name="owner_secret" type="password" required autocomplete="current-password"></label>'
                '<button>연결 승인</button></form></main></html>')

    def authorize(self, value):
        if not hmac.compare_digest(str(value.get('owner_secret','')),self.owner_secret): raise PermissionError('owner authentication failed')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT body,expires FROM attempts WHERE id=?',(sha(value.get('attempt','')),)).fetchone()
            if not row or row[1]<time.time(): raise ValueError('authorization attempt expired')
            db.execute('DELETE FROM attempts WHERE id=?',(sha(value['attempt']),))
            auth = json.loads(row[0]); code = secrets.token_urlsafe(32)
            db.execute('INSERT INTO codes VALUES (?,?,?)',(sha(code),json.dumps(auth),time.time()+120))
        return auth['redirect_uri']+('&' if '?' in auth['redirect_uri'] else '?')+urlencode({'code':code,'state':auth.get('state','')})

    def _issue(self, db, client):
        access, refresh = secrets.token_urlsafe(48), secrets.token_urlsafe(48)
        db.execute('INSERT INTO tokens VALUES (?,?,?,?)',(sha(access),client,'access',time.time()+3600))
        db.execute('INSERT INTO tokens VALUES (?,?,?,?)',(sha(refresh),client,'refresh',time.time()+30*86400))
        return {'access_token':access,'token_type':'Bearer','expires_in':3600,'refresh_token':refresh,'scope':'jigaewol'}

    def token(self, value):
        client = value.get('client_id','')
        if value.get('resource',self.issuer+'/mcp') != self.issuer+'/mcp': raise ValueError('invalid resource')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            if value.get('grant_type')=='authorization_code':
                row = db.execute('SELECT body,expires FROM codes WHERE hash=?',(sha(value.get('code','')),)).fetchone()
                if not row or row[1]<time.time(): raise ValueError('invalid_grant')
                auth = json.loads(row[0]); verifier = value.get('code_verifier','')
                if not 43<=len(verifier)<=128: raise ValueError('invalid_grant')
                challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
                if auth['client_id']!=client or auth['redirect_uri']!=value.get('redirect_uri') or not hmac.compare_digest(challenge,auth['code_challenge']):
                    raise ValueError('invalid_grant')
                db.execute('DELETE FROM codes WHERE hash=?',(sha(value['code']),))
            elif value.get('grant_type')=='refresh_token':
                row = db.execute('SELECT client,kind,expires FROM tokens WHERE hash=?',(sha(value.get('refresh_token','')),)).fetchone()
                if not row or row[0]!=client or row[1]!='refresh' or row[2]<time.time(): raise ValueError('invalid_grant')
                db.execute('DELETE FROM tokens WHERE hash=?',(sha(value['refresh_token']),))
            else: raise ValueError('unsupported_grant_type')
            return self._issue(db,client)

    def valid(self, token):
        with self.db() as db: row = db.execute('SELECT kind,expires FROM tokens WHERE hash=?',(sha(token),)).fetchone()
        return bool(row and row[0]=='access' and row[1]>time.time())

    def revoke(self, value):
        with self.db() as db:
            row = db.execute('SELECT client FROM tokens WHERE hash=?',(sha(value.get('token','')),)).fetchone()
            if row and row[0]==value.get('client_id'):
                db.execute('DELETE FROM tokens WHERE client=?',(row[0],))
        return {}
