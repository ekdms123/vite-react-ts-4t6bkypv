from dataclasses import dataclass


@dataclass(frozen=True)
class BudgetPolicy:
    depth_class: str
    max_nodes: int
    max_recompiles: int
    target_context_chars: int
    expected_gain_floor: float
