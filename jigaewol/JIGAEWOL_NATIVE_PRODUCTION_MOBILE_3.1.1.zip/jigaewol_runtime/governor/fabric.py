from __future__ import annotations

"""Small adaptive execution accounting.

This module tracks pressure; it never treats a stage budget as a semantic
ceiling.  JIGAEWOL expands work only when an observation can still change a
reachable decision or material result.
"""

from copy import deepcopy

_STAGES = ("intake", "semantic_epoch", "observation", "delta", "materialization")


def _positive_int(value, label):
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(label + " must be a positive integer")
    return value


def _nonnegative_int(value, label):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(label + " must be a nonnegative integer")
    return value


def _stage_for(operation: str) -> str:
    op = str(operation or "")
    if op == "intents.extract":
        return "intake"
    if op == "cognition.delta":
        return "delta"
    if op.startswith("capability.") or (op.startswith("integration.")) or op.startswith("methods.") or op.startswith("research."):
        return "observation"
    if op in {"chat.respond", "material.realize", "creative.realize", "code.realize", "deliver", "closure.check"}:
        return "materialization"
    return "semantic_epoch"


def build_execution_fabric(*, task_id: str, max_nodes: int, depth_class: str, profile: str,
                           inference_portfolio=None, needs_research: bool = False) -> dict:
    total = max(4, _positive_int(max_nodes, "max_nodes"))
    if not isinstance(needs_research, bool):
        raise ValueError("needs_research must be boolean")
    return {
        "version": 2,
        "active": True,
        "task_id": str(task_id),
        "depth_class": str(depth_class),
        "profile": str(profile),
        "resource_window": total,
        "used": {k: 0 for k in _STAGES},
        "pressure_events": [],
        "policy": "adaptive_window_no_semantic_ceiling",
        "needs_research": needs_research,
    }


def charge_execution_fabric(plan: dict | None, operation: str) -> dict:
    if not isinstance(plan, dict) or not plan.get("active"):
        return deepcopy(plan) if isinstance(plan, dict) else {}
    out = deepcopy(plan)
    stage = _stage_for(operation)
    used = out.setdefault("used", {})
    if not isinstance(used, dict):
        raise ValueError("execution fabric used counters must be an object")
    for key, value in used.items():
        _nonnegative_int(value, "execution fabric counter " + str(key))
    used[stage] = _nonnegative_int(used.get(stage, 0), "execution fabric counter " + stage) + 1
    total_used = sum(used.values())
    window = _positive_int(out.get("resource_window", 4), "execution fabric resource_window")
    if total_used > window:
        out.setdefault("pressure_events", []).append({
            "operation": str(operation),
            "stage": stage,
            "total_used": total_used,
            "resource_window": window,
            "effect": "pressure_exposed_not_goal_closed",
        })
    return out


def reprice_verification_fabric(plan: dict | None, verification_targets, *, convergence_witness=None) -> dict:
    """Compatibility shim for old callers; records evidence pressure only."""
    out = deepcopy(plan) if isinstance(plan, dict) else {}
    if out.get("active"):
        targets = [x for x in (verification_targets or []) if isinstance(x, dict)]
        out.setdefault("pressure_events", []).append({
            "stage": "observation",
            "verification_target_count": len(targets),
            "convergence_witness": str(convergence_witness or ""),
            "effect": "no_budget_repricing",
        })
    return out
