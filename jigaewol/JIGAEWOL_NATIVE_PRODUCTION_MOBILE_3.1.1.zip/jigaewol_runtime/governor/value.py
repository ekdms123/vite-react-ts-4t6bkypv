from .budget import BudgetPolicy
from math import isfinite


def _finite(value, default=0.0):
    if isinstance(value, bool):
        return float(default)
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return number if isfinite(number) else float(default)


def budget_for_signals(signals, *, profile="apex") -> BudgetPolicy:
    """Allocate headroom from task evidence, never from a magic profile name.

    ``profile`` remains accepted as descriptive workflow metadata for backward
    compatibility. Resource ceilings are intentionally profile-neutral: a caller
    cannot obtain more cognition merely by knowing a privileged string.
    """
    if not isinstance(profile, str) or not profile.strip():
        raise ValueError("profile must be nonempty text")

    score = signals.leverage_score()
    intensity = max(1, int(round(_finite(getattr(signals, "requested_intensity", 1), 1.0))))
    exploration = max(0.0, _finite(getattr(signals, "exploration_leverage", 0.0)))
    fidelity = max(0.0, _finite(getattr(signals, "intent_fidelity", 0.0)))
    novelty = max(0.0, _finite(getattr(signals, "creative_leverage", 0.0)))

    # Unified adaptive policy: preserve the former highest non-keyed headroom so
    # removing profile privilege cannot silently downgrade demanding tasks.
    if score < .55 and intensity <= 1 and exploration < .35 and novelty < .35:
        return BudgetPolicy("tiny", 10, 1, 3200, 0.045)
    if score < 1.8 and intensity <= 2 and exploration < .75:
        return BudgetPolicy("focused", 24, 2, 9000, 0.06)
    if score < 4.4 and intensity <= 4 and max(exploration, fidelity, novelty) < 1.15:
        return BudgetPolicy("deep", 52, 6, 26000, 0.045)
    return BudgetPolicy("frontier", 112, 14, 56000, 0.02)
