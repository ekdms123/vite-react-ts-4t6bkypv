from __future__ import annotations

"""Optional evidence-retention policy helper.

This optional helper provides bounded audit-record retention semantics when a workflow requests them.
"""

from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Mapping, Sequence
import hashlib
import json
import math


class PreservationLevel(IntEnum):
    METADATA = 0
    FEATURES_POLICY = 1
    REDACTED_EVIDENCE = 2
    ENCRYPTED_RAW_BOUNDED = 3


def _preservation_level(value, label="preservation level") -> PreservationLevel:
    if isinstance(value, bool) or not isinstance(value, (int, PreservationLevel)):
        raise ValueError(label + " must be an integer preservation level")
    try:
        return PreservationLevel(int(value))
    except ValueError as exc:
        raise ValueError(label + " is outside the supported preservation levels") from exc


def _clamp01(value: float) -> float:
    if isinstance(value, bool):
        raise ValueError("preservation factor must be a finite number")
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("preservation factor must be a finite number") from exc
    if not math.isfinite(number):
        raise ValueError("preservation factor must be a finite number")
    return max(0.0, min(1.0, number))


def _level(value: float, t1: float, t2: float, t3: float) -> PreservationLevel:
    v = _clamp01(value)
    if v >= t3:
        return PreservationLevel.ENCRYPTED_RAW_BOUNDED
    if v >= t2:
        return PreservationLevel.REDACTED_EVIDENCE
    if v >= t1:
        return PreservationLevel.FEATURES_POLICY
    return PreservationLevel.METADATA


@dataclass(frozen=True)
class PreservationFactors:
    decision_impact: float = 0.0
    reversibility: float = 1.0
    audit_requirement: float = 0.0
    legal_requirement: float = 0.0
    evidence_ambiguity: float = 0.0
    model_uncertainty: float = 0.0
    capability_risk: float = 0.0

    def normalized(self) -> dict[str, float]:
        return {
            "decision_impact": _clamp01(self.decision_impact),
            "irreversibility": 1.0 - _clamp01(self.reversibility),
            "audit_requirement": _clamp01(self.audit_requirement),
            "legal_requirement": _clamp01(self.legal_requirement),
            "evidence_ambiguity": _clamp01(self.evidence_ambiguity),
            "model_uncertainty": _clamp01(self.model_uncertainty),
            "capability_risk": _clamp01(self.capability_risk),
        }


class EvidencePreservationFloor:
    """Calculate the minimum auditable retention level.

    The function is monotone in every normalized retention/audit requirement axis:
    increasing a requirement can never lower the returned level. Persistence is
    deliberately excluded from the calculation.
    """

    _THRESHOLDS = {
        "decision_impact": (0.15, 0.55, 0.85),
        "irreversibility": (0.25, 0.60, 0.90),
        "audit_requirement": (0.10, 0.50, 0.90),
        "legal_requirement": (0.10, 0.40, 0.80),
        "evidence_ambiguity": (0.20, 0.50, 0.85),
        "model_uncertainty": (0.20, 0.50, 0.85),
        "capability_risk": (0.20, 0.60, 0.90),
    }

    def required_level(
        self,
        factors: PreservationFactors | Mapping[str, Any],
        *,
        policy_minimum: int | PreservationLevel = PreservationLevel.METADATA,
        persistence_strength: float | None = None,
    ) -> PreservationLevel:
        if not isinstance(factors, PreservationFactors):
            factors = PreservationFactors(**dict(factors))
        levels = [_preservation_level(policy_minimum, "policy_minimum")]
        for name, value in factors.normalized().items():
            levels.append(_level(value, *self._THRESHOLDS[name]))
        # persistence_strength is intentionally not consulted: stronger user
        # persistence cannot lower or raise mandatory audit evidence.
        _ = persistence_strength
        return max(levels)


class EvidenceRetentionArbitrator:
    def __init__(self, floor: EvidencePreservationFloor | None = None):
        self.floor = floor or EvidencePreservationFloor()

    @staticmethod
    def _hash_payload(payload: Any) -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def build_record(
        self,
        *,
        event_id: str,
        policy_class: str,
        decision: str,
        factors: PreservationFactors | Mapping[str, Any],
        minimal_provenance_hash: str | None = None,
        transient_raw_event: Any | None = None,
        normalized_features: Mapping[str, Any] | None = None,
        policy_path: Sequence[str] | None = None,
        redacted_evidence_snippets: Sequence[str] | None = None,
        encrypted_raw_event: str | None = None,
        retention_until: str | None = None,
        encryption_context: Mapping[str, Any] | None = None,
        policy_minimum: int | PreservationLevel = PreservationLevel.METADATA,
        persistence_strength: float | None = None,
    ) -> dict[str, Any]:
        if not str(event_id).strip() or not str(policy_class).strip() or not str(decision).strip():
            raise ValueError("event_id, policy_class and decision are required")
        required = self.floor.required_level(
            factors,
            policy_minimum=policy_minimum,
            persistence_strength=persistence_strength,
        )
        provenance_hash = minimal_provenance_hash
        if not provenance_hash and transient_raw_event is not None:
            provenance_hash = self._hash_payload(transient_raw_event)
        if not provenance_hash:
            raise ValueError("minimal provenance hash or transient raw event is required")

        record: dict[str, Any] = {
            "event_id": str(event_id),
            "policy_class": str(policy_class),
            "decision": str(decision),
            "minimal_provenance_hash": str(provenance_hash),
            "preservation_level": int(required),
            "preservation_level_name": required.name,
            "persistence_affects_floor": False,
        }

        if required >= PreservationLevel.FEATURES_POLICY:
            if not normalized_features or not policy_path:
                raise ValueError("level 1+ requires normalized_features and policy_path")
            record["normalized_features"] = dict(normalized_features)
            record["policy_path"] = [str(x) for x in policy_path]

        if required >= PreservationLevel.REDACTED_EVIDENCE:
            snippets = [str(x) for x in (redacted_evidence_snippets or ()) if str(x).strip()]
            if not snippets:
                raise ValueError("level 2+ requires at least one redacted evidence snippet")
            record["redacted_evidence_snippets"] = snippets

        if required >= PreservationLevel.ENCRYPTED_RAW_BOUNDED:
            if not encrypted_raw_event or not retention_until:
                raise ValueError("level 3 requires host-encrypted raw event and bounded retention_until")
            record["encrypted_raw_event"] = str(encrypted_raw_event)
            record["retention_until"] = str(retention_until)
            record["encryption_context"] = dict(encryption_context or {})

        # Deliberately never copy transient_raw_event into the output record.
        self.validate_record(record, required_level=required)
        return record

    @staticmethod
    def validate_record(record: Mapping[str, Any], *, required_level: int | PreservationLevel | None = None) -> bool:
        if "raw_event" in record or "transient_raw_event" in record:
            raise ValueError("plaintext raw event must not be persisted by this record format")
        level = _preservation_level(record.get("preservation_level", 0), "record preservation_level")
        if required_level is not None and level < _preservation_level(required_level, "required_level"):
            raise ValueError("privacy minimization attempted to go below the required evidence floor")
        base = ("event_id", "policy_class", "decision", "minimal_provenance_hash")
        if any(not record.get(k) for k in base):
            raise ValueError("decision record is missing mandatory metadata")
        if level >= PreservationLevel.FEATURES_POLICY:
            if not record.get("normalized_features") or not record.get("policy_path"):
                raise ValueError("level 1 evidence is incomplete")
        if level >= PreservationLevel.REDACTED_EVIDENCE:
            if not record.get("redacted_evidence_snippets"):
                raise ValueError("cannot remove the last evidence required to justify a level 2+ decision")
        if level >= PreservationLevel.ENCRYPTED_RAW_BOUNDED:
            if not record.get("encrypted_raw_event") or not record.get("retention_until"):
                raise ValueError("level 3 evidence requires encrypted payload and bounded retention")
        return True


