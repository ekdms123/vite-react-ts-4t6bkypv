from dataclasses import dataclass, replace
from math import isfinite


def _finite_nonnegative(value, default=0.0) -> float:
    if isinstance(value, bool):
        return float(default)
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    if not isfinite(number):
        return float(default)
    return max(0.0, number)


def _bounded_display(value) -> float:
    """Project an unbounded nonnegative magnitude into [0, 1) without mutating it."""
    raw = _finite_nonnegative(value)
    return raw / (raw + 1.0)


def _projection_state(raw_value, display_value) -> str:
    """Describe projection loss instead of pretending the bounded view is the source value."""
    raw = _finite_nonnegative(raw_value)
    display = _finite_nonnegative(display_value)
    if display >= 0.99:
        return "saturated"
    if raw > 1.0:
        return "compressed"
    return "within_scale"


@dataclass(frozen=True)
class CompileSignals:
    intent_count: int = 1
    ambiguity: float | None = None
    ambiguity_basis: str = "pending_semantic_intake:no_presemantic_meaning_claim"
    factual_stakes: float = 0.0
    creative_leverage: float = 0.0
    # Verification is independent of creativity. A user may request extreme
    # divergence without asking for a post-generation audit loop.
    verification_leverage: float = 0.0
    verification_requested: bool = False
    artifact_surface: float = 0.0
    contradiction_count: int = 0

    # ``requested_intensity`` remains as the compatibility/resource-facing field.
    # It is no longer a 1..5 semantic bucket.  ``raw_intensity`` is the exact
    # accepted semantic magnitude; display/projection fields are derived views.
    requested_intensity: float = 1.0
    raw_intensity: float = 1.0
    display_intensity: float = 0.5
    projection_state: str = "within_scale"

    domain: str = "general"
    needs_research: bool = False
    structural_pressure: float = 0.0
    exploration_leverage: float = 0.0
    intent_fidelity: float = 0.0

    @classmethod
    def simple_chat(cls) -> "CompileSignals":
        raw = 1.0
        display = _bounded_display(raw)
        return cls(
            intent_count=1,
            requested_intensity=raw,
            raw_intensity=raw,
            display_intensity=display,
            projection_state=_projection_state(raw, display),
        )

    def ambiguity_exploration_opportunity(self) -> float:
        """Project unresolved ambiguity into exploration value without rewriting it.

        ``ambiguity is None`` is an epistemic state: ambiguity has not yet been
        established, not evidence that ambiguity is zero.  Resource allocation
        may still care about that unresolved state when the live task already
        carries evidence that clarification/exploration can matter.  Keep the raw
        cognition untouched and derive the resource projection separately.
        """
        if self.ambiguity is not None:
            return 0.0
        return max(
            _finite_nonnegative(self.exploration_leverage),
            _finite_nonnegative(self.structural_pressure),
            _finite_nonnegative(self.factual_stakes),
            _finite_nonnegative(self.creative_leverage),
            _finite_nonnegative(self.artifact_surface),
            _finite_nonnegative(self.intent_fidelity),
        )

    def leverage_score(self) -> float:
        # Public callers can construct CompileSignals directly. Malformed or
        # non-finite telemetry must never buy frontier resources accidentally.
        intent_count = _finite_nonnegative(self.intent_count, 1.0)
        if self.ambiguity is None:
            # Do not collapse epistemic unknown into numeric zero.  Unknown is
            # preserved on the signal and contributes only through a separate
            # exploration-opportunity projection grounded in other live task
            # leverage.
            ambiguity_contribution = self.ambiguity_exploration_opportunity()
        else:
            ambiguity_contribution = _finite_nonnegative(self.ambiguity)
        stakes = _finite_nonnegative(self.factual_stakes)
        creative = _finite_nonnegative(self.creative_leverage)
        verification = _finite_nonnegative(self.verification_leverage)
        artifact = _finite_nonnegative(self.artifact_surface)
        contradictions = _finite_nonnegative(self.contradiction_count)
        intensity = _finite_nonnegative(self.raw_intensity, self.requested_intensity)
        structural = _finite_nonnegative(self.structural_pressure)
        exploration = _finite_nonnegative(self.exploration_leverage)
        fidelity = _finite_nonnegative(self.intent_fidelity)
        return (
            min(intent_count / 8, 1.5)
            + ambiguity_contribution
            + stakes
            + creative * 1.4
            + min(verification * 0.7, 1.0)
            + artifact
            + min(contradictions * 0.25, 1.0)
            + min(max(intensity - 1, 0) * 0.28, 1.1)
            + min(structural, 2.4)
            + min(exploration * 1.35, 2.0)
            + min(fidelity * 0.75, 1.2)
        )


def _semantic_number(task_model: dict, name: str, current, *, low=0.0, high=None):
    """Return an accepted semantic magnitude without silently amputating it.

    The source semantic value is open-ended by default.  A caller may request an
    explicit upper projection boundary with ``high=...`` for a derived view, but
    semantic intake itself does not impose a hidden 1.5 ceiling.
    """
    if name not in task_model:
        return current, False
    value = task_model.get(name)
    if isinstance(value, bool):
        return current, False
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return current, False
    if not isfinite(number):
        return current, False
    number = max(low, number)
    if high is not None:
        number = min(float(high), number)
    return number, True


def apply_task_model(signals: CompileSignals, task_model: dict | None) -> CompileSignals:
    """Fuse semantic intake into compile signals without a lexical domain prison.

    Raw semantic magnitudes remain raw cognition. Bounded values are projections,
    never replacements for the source magnitude. Malformed optional fields are
    ignored rather than silently becoming evidence.
    """
    if not isinstance(task_model, dict):
        return signals

    def number(name, current):
        return _semantic_number(task_model, name, current)[0]

    raw_domains = task_model.get("domains", ())
    if isinstance(raw_domains, str):
        raw_domains = (raw_domains,)
    elif not isinstance(raw_domains, (list, tuple, set)):
        raw_domains = ()
    domains = [x.strip() for x in raw_domains if isinstance(x, str) and x.strip()]

    raw_primary = task_model.get("primary_domain")
    semantic_primary = raw_primary.strip() if isinstance(raw_primary, str) and raw_primary.strip() else (domains[0] if domains else "")
    # Semantic intake may add a domain hypothesis, but it cannot replace a
    # source-grounded domain with its own classifier label.
    source_domain = str(signals.domain or "").strip()
    primary = source_domain if source_domain and source_domain not in {"general", "unknown", "ambiguous"} else (semantic_primary or source_domain)

    research_value = number("research_value", signals.factual_stakes)
    exploration = max(
        signals.exploration_leverage,
        number("exploration_leverage", signals.exploration_leverage),
        number("breadth_target", 0.0),
        number("divergence_target", 0.0),
    )
    fidelity = max(signals.intent_fidelity, number("intent_fidelity", signals.intent_fidelity))

    intensity_value = task_model.get(
        "reasoning_intensity",
        task_model.get("requested_intensity", None),
    )
    intensity_supplied = "reasoning_intensity" in task_model or "requested_intensity" in task_model
    if intensity_supplied:
        try:
            if isinstance(intensity_value, bool):
                raise ValueError("boolean intensity is not numeric evidence")
            semantic_raw_intensity = float(intensity_value)
            if not isfinite(semantic_raw_intensity):
                raise ValueError("non-finite intensity")
            semantic_raw_intensity = max(0.0, semantic_raw_intensity)
            display_intensity = _bounded_display(semantic_raw_intensity)
            projection_state = _projection_state(semantic_raw_intensity, display_intensity)
        except (TypeError, ValueError, OverflowError):
            semantic_raw_intensity = signals.raw_intensity
            display_intensity = signals.display_intensity
            projection_state = signals.projection_state
            intensity_supplied = False
    else:
        semantic_raw_intensity = signals.raw_intensity
        display_intensity = signals.display_intensity
        projection_state = signals.projection_state

    semantic_ambiguity, ambiguity_supplied = _semantic_number(
        task_model, "ambiguity", signals.ambiguity
    )
    if signals.ambiguity is None:
        merged_ambiguity = semantic_ambiguity
    elif semantic_ambiguity is None:
        merged_ambiguity = signals.ambiguity
    else:
        merged_ambiguity = max(signals.ambiguity, semantic_ambiguity)
    requested_research = task_model.get("needs_research")
    needs_research = bool(
        signals.needs_research
        or research_value >= .45
        or requested_research is True
    )
    verification_value = number("verification_leverage", signals.verification_leverage)
    requested_verification = task_model.get("verification_requested")
    verification_requested = bool(signals.verification_requested or requested_verification is True)

    return replace(
        signals,
        ambiguity=merged_ambiguity,
        ambiguity_basis=("source_plus_semantic_task_model" if ambiguity_supplied else signals.ambiguity_basis),
        factual_stakes=max(signals.factual_stakes, research_value),
        creative_leverage=max(
            signals.creative_leverage,
            number("creative_leverage", signals.creative_leverage),
            number("novelty_target", 0.0),
        ),
        verification_leverage=max(signals.verification_leverage, verification_value),
        verification_requested=verification_requested,
        artifact_surface=max(signals.artifact_surface, number("artifact_leverage", signals.artifact_surface)),
        structural_pressure=max(signals.structural_pressure, number("structural_pressure", signals.structural_pressure)),
        exploration_leverage=exploration,
        intent_fidelity=fidelity,
        requested_intensity=max(signals.requested_intensity, semantic_raw_intensity),
        raw_intensity=max(signals.raw_intensity, semantic_raw_intensity) if intensity_supplied else signals.raw_intensity,
        display_intensity=max(signals.display_intensity, display_intensity) if intensity_supplied else signals.display_intensity,
        projection_state=(
            _projection_state(max(signals.raw_intensity, semantic_raw_intensity), max(signals.display_intensity, display_intensity))
            if intensity_supplied else signals.projection_state
        ),
        domain=primary,
        needs_research=needs_research,
    )
