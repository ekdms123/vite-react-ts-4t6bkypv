from dataclasses import replace
from .program_ir import ProgramIR
from jigaewol_runtime.kernel.ids import new_id


def validate_graph(program):
    ids = [n.node_id for n in program.nodes]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate program node")
    parents = {i: set() for i in ids}
    for left, right in program.edges:
        if left not in parents or right not in parents:
            raise ValueError("program edge references a missing node")
        parents[right].add(left)
    done = set()
    while len(done) < len(ids):
        ready = {i for i in ids if i not in done and parents[i] <= done}
        if not ready:
            raise ValueError("program rewrite would create a cycle")
        done.update(ready)
    return program


def recompile(program: ProgramIR, event, state) -> ProgramIR:
    invalid = getattr(event, "invalidates_world", None)
    if not invalid:
        return program
    active = tuple(w for w in getattr(state, "active_world_ids", ()) if w != invalid)
    nodes = []
    for node in program.nodes:
        if node.status == "done":
            nodes.append(node)
            continue
        refs = tuple(w for w in node.world_refs if w != invalid)
        if invalid in node.world_refs and not refs:
            refs = active
        nodes.append(replace(node, world_refs=refs))
    return replace(program, program_id=new_id("program"), nodes=tuple(nodes),
                   world_refs=tuple(w for w in program.world_refs if w != invalid))




def _validate_intent_conservation(selected_nodes, replacement_nodes):
    """A program rewrite may change routes, never silently drop live intent refs."""
    required={ref for node in selected_nodes for ref in getattr(node,'intent_refs',())}
    preserved={ref for node in replacement_nodes for ref in getattr(node,'intent_refs',())}
    missing=sorted(required-preserved)
    if missing:
        raise ValueError("program rewrite would erase live user intent refs: "+",".join(missing))

def rewrite_subgraph(program, replace_ids, with_nodes, protected_completed_effect_refs=()):
    """Replace pending nodes while keeping unrelated edges and completed work."""
    selected = {n.node_id for n in program.nodes if n.node_id in replace_ids or n.operation in replace_ids}
    if not selected or not with_nodes:
        raise ValueError("rewrite requires existing pending nodes and replacement work")
    if any(n.status == "done" for n in program.nodes if n.node_id in selected):
        raise ValueError("completed operations remain immutable")
    insert_at = min(i for i, n in enumerate(program.nodes) if n.node_id in selected)
    incoming = {a for a, b in program.edges if b in selected and a not in selected}
    outgoing = {b for a, b in program.edges if a in selected and b not in selected}
    edges = [(a, b) for a, b in program.edges if a not in selected and b not in selected]
    replacement = tuple(with_nodes)
    _validate_intent_conservation(
        tuple(n for n in program.nodes if n.node_id in selected), replacement
    )
    edges += [(a, replacement[0].node_id) for a in sorted(incoming)]
    edges += [(a.node_id, b.node_id) for a, b in zip(replacement, replacement[1:])]
    edges += [(replacement[-1].node_id, b) for b in sorted(outgoing)]
    kept = [n for n in program.nodes if n.node_id not in selected]
    before = sum(n.node_id not in selected for n in program.nodes[:insert_at])
    nodes = tuple(kept[:before]) + replacement + tuple(kept[before:])
    if len(nodes) > program.budget_policy.max_nodes:
        raise ValueError("program node budget would be exceeded")
    metadata = dict(program.metadata)
    metadata.update(protected_effect_refs=tuple(protected_completed_effect_refs), self_rewrite=True)
    return validate_graph(replace(program, program_id=new_id("program"), nodes=nodes,
                         edges=tuple(dict.fromkeys(edges)), metadata=tuple(metadata.items())))


def rewrite_subgraph_parallel_phase(program, replace_ids, prefix_nodes, parallel_nodes, join_node, suffix_nodes, protected_completed_effect_refs=()):
    """Replace pending work with a prefix -> parallel fanout -> join -> suffix DAG.

    This is the execution-level counterpart to route competition.
    The fanout nodes are causally independent siblings; a host may execute them
    concurrently.  The join cannot run until every sibling has an observed
    result.  Completed nodes outside the replaced subgraph remain immutable.
    """
    selected = {n.node_id for n in program.nodes if n.node_id in replace_ids or n.operation in replace_ids}
    if not selected:
        raise ValueError("parallel rewrite requires existing pending nodes")
    if any(n.status == "done" for n in program.nodes if n.node_id in selected):
        raise ValueError("completed operations remain immutable")
    prefix=tuple(prefix_nodes or ())
    parallel=tuple(parallel_nodes or ())
    suffix=tuple(suffix_nodes or ())
    if not parallel or join_node is None:
        return rewrite_subgraph(program, replace_ids, prefix + parallel + ((join_node,) if join_node is not None else ()) + suffix, protected_completed_effect_refs)
    insert_at=min(i for i,n in enumerate(program.nodes) if n.node_id in selected)
    incoming={a for a,b in program.edges if b in selected and a not in selected}
    outgoing={b for a,b in program.edges if a in selected and b not in selected}
    edges=[(a,b) for a,b in program.edges if a not in selected and b not in selected]
    entry_ids=[]
    if prefix:
        entry_ids=[prefix[0].node_id]
        edges += [(a,b.node_id) for a,b in zip(prefix,prefix[1:])]
        fan_parent=prefix[-1].node_id
        edges += [(fan_parent,n.node_id) for n in parallel]
    else:
        entry_ids=[n.node_id for n in parallel]
    for parent in sorted(incoming):
        edges += [(parent,e) for e in entry_ids]
    edges += [(n.node_id,join_node.node_id) for n in parallel]
    if suffix:
        edges.append((join_node.node_id,suffix[0].node_id))
        edges += [(a.node_id,b.node_id) for a,b in zip(suffix,suffix[1:])]
        exit_id=suffix[-1].node_id
    else:
        exit_id=join_node.node_id
    edges += [(exit_id,b) for b in sorted(outgoing)]
    replacement=prefix+parallel+(join_node,)+suffix
    _validate_intent_conservation(
        tuple(n for n in program.nodes if n.node_id in selected), replacement
    )
    kept=[n for n in program.nodes if n.node_id not in selected]
    before=sum(n.node_id not in selected for n in program.nodes[:insert_at])
    nodes=tuple(kept[:before])+replacement+tuple(kept[before:])
    if len(nodes)>program.budget_policy.max_nodes:
        raise ValueError("program node budget would be exceeded")
    metadata=dict(program.metadata)
    metadata.update(protected_effect_refs=tuple(protected_completed_effect_refs), self_rewrite=True, parallel_phase=True)
    return validate_graph(replace(program, program_id=new_id("program"), nodes=nodes, edges=tuple(dict.fromkeys(edges)), metadata=tuple(metadata.items())))
