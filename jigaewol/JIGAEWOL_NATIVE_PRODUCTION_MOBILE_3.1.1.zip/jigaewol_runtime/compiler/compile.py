from jigaewol_runtime.kernel.ids import new_id
from jigaewol_runtime.governor.value import budget_for_signals
from .program_ir import ProgramIR, ProgramNode
from jigaewol_runtime.capabilities.manifest import normalize_capabilities
from jigaewol_runtime.capabilities.execution_routes import infer_required_traits

SEARCH_ID_HINTS = {"search", "web", "web_search", "browser", "research", "academic_search", "scholar", "literature"}
SEARCH_ROLE_HINTS = {"search", "academic_search"}
CODE_REPOSITORY_ROLE_HINTS = {"code_repository", "github", "repository", "repo"}


def is_search_capability(spec):
    if isinstance(spec, dict):
        role = spec.get("role")
        cid = spec.get("id", spec.get("capability_id", ""))
    else:
        role = getattr(spec, "role", None)
        cid = getattr(spec, "capability_id", str(spec))
    role_text = str(role or "").lower()
    cid_text = str(cid or "").lower()
    return (role_text in SEARCH_ROLE_HINTS or cid_text in SEARCH_ID_HINTS
            or any(token in role_text or token in cid_text for token in ("search", "research", "browser", "scholar", "literature")))


def is_repository_capability(spec):
    if isinstance(spec, dict):
        role = spec.get("role")
        cid = spec.get("id", spec.get("capability_id", ""))
    else:
        role = getattr(spec, "role", None)
        cid = getattr(spec, "capability_id", str(spec))
    role_text = str(role or "").lower()
    cid_text = str(cid or "").lower()
    return (role_text in CODE_REPOSITORY_ROLE_HINTS or cid_text == "github"
            or any(token in role_text or token in cid_text for token in ("repository", "repo", "source_control", "git")))


def capability_specs(capabilities):
    return normalize_capabilities(capabilities)


def compile_turn(contract, signals, capabilities, worlds=(), *, profile="apex", external_kernel_request=None, required_traits=None):
    """Compile only the stable delivery boundary. Non-trivial cognition compiles itself at runtime."""
    if not isinstance(profile,str) or not profile.strip():
        raise ValueError("profile must be nonempty text")
    profile=profile.strip()
    budget = budget_for_signals(signals, profile=profile)
    intents = tuple(n.intent_id for n in contract.nodes)
    refs = tuple(getattr(w, "world_id", str(w)) for w in worlds)
    caps = capability_specs(capabilities)
    nodes = []

    def add(executor, operation, **kw):
        params = kw.pop("parameters", ())
        if isinstance(params, dict):
            params = tuple(params.items())
        node = ProgramNode(new_id("node"), executor, operation, intent_refs=intents, world_refs=refs,
                           parameters=params, **kw)
        nodes.append(node)
        return node

    domain = getattr(signals, "domain", "general")
    realize = {"creative": "creative.realize", "code": "code.realize"}.get(domain, "material.realize")
    repo_cap = next((c for c in caps if is_repository_capability(c)), None)
    required_execution_traits = set(
        infer_required_traits(contract.raw_turn.message) if required_traits is None
        else (str(x) for x in required_traits if str(x))
    )
    repository_relevant = domain == "code" or "repository" in required_execution_traits

    # Repository access is an observation component only when the live task actually
    # calls for code/source evidence. A connected GitHub surface is not a reason
    # to force every user turn through one preferred provider.
    def add_repository_pulse():
        if not repo_cap or not repository_relevant:
            return None
        return add(
            "host_tool", "capability." + repo_cap["id"],
            permission_class=repo_cap["permission"],
            evidence_requirements=("real_origin",), cost_estimate=repo_cap["cost"],
            parameters={
                "query": contract.raw_turn.message,
                "task": "Find repository/code/skill evidence materially relevant to the live user request; report no relevant evidence when none exists.",
                "observation_policy": "delta",
                "always_run": True,
                "jigaewol_repository_relevant_pulse": True,
            },
        )

    if budget.depth_class == "tiny":
        add_repository_pulse()
        add("host_semantic", "chat.respond", expected_effects=("text_response",), cost_estimate=.1)
    else:
        if external_kernel_request and repo_cap:
            add("host_tool", "capability." + repo_cap["id"], permission_class=repo_cap["permission"],
                evidence_requirements=("real_origin",), cost_estimate=repo_cap["cost"],
                parameters=external_kernel_request)
        add("host_semantic", "cognition.compile", expected_effects=("runtime_cognitive_program",), cost_estimate=.2)
        add_repository_pulse()
        add("host_semantic", realize, expected_effects=("material_result",), cost_estimate=.5)
    add("local", "closure.check", expected_effects=("intent_closure",), cost_estimate=.02)
    return ProgramIR(new_id("program"), intents, tuple(nodes),
        tuple((a.node_id, b.node_id) for a, b in zip(nodes, nodes[1:])), refs, budget,
        ("new_observation", "frame_change", "material_opportunity"), intents,
        (("mode", budget.depth_class), ("domain", domain), ("realize_operation", realize),
         ("profile", profile), ("cognition", "runtime_compiled")))
