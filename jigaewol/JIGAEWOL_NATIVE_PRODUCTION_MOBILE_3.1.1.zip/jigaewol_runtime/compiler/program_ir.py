from __future__ import annotations
from dataclasses import dataclass, replace


@dataclass(frozen=True)
class ProgramNode:
    node_id: str
    executor: str
    operation: str
    inputs: tuple[str, ...] = ()
    outputs: tuple[str, ...] = ()
    intent_refs: tuple[str, ...] = ()
    world_refs: tuple[str, ...] = ()
    expected_effects: tuple[str, ...] = ()
    evidence_requirements: tuple[str, ...] = ()
    permission_class: str = "none"
    cost_estimate: float = 0.0
    status: str = "pending"
    parameters: tuple[tuple[str, object], ...] = ()
    operator_ids: tuple[str, ...] = ()
    language_refs: tuple[str, ...] = ()
    trigger_refs: tuple[str, ...] = ()
    action_species_ids: tuple[str, ...] = ()
    visibility_scope: str | None = None

    def with_status(self, status: str) -> "ProgramNode":
        return replace(self, status=status)


@dataclass(frozen=True)
class ProgramIR:
    program_id: str
    objective_refs: tuple[str, ...]
    nodes: tuple[ProgramNode, ...]
    edges: tuple[tuple[str, str], ...]
    world_refs: tuple[str, ...]
    budget_policy: object
    recompile_triggers: tuple[str, ...]
    closure_requirements: tuple[str, ...]
    metadata: tuple[tuple[str, object], ...] = ()

    def node(self, node_id: str) -> ProgramNode:
        for node in self.nodes:
            if node.node_id == node_id or node.operation == node_id:
                return node
        raise KeyError(node_id)

    def node_ids(self) -> tuple[str, ...]:
        return tuple(n.node_id for n in self.nodes)
