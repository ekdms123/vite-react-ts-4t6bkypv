"""JIGAEWOL runtime public package with lazy capability loading."""
from importlib import import_module

from jigaewol_core.constants import VERSION as __version__

_EXPORTS = {
    "JigaewolRuntime": ("bridge.core", "JigaewolRuntime"), "JigaewolView": ("bridge.core", "JigaewolView"),
    "HostPump": ("bridge.pump", "HostPump"), "PumpReceipt": ("bridge.pump", "PumpReceipt"),
    "JigaewolHostRunner": ("bridge.pump", "JigaewolHostRunner"),
    "GeneralChatDriver": ("bridge.chat_driver", "GeneralChatDriver"),
    "PerTurnGate": ("bridge.turn_gate", "PerTurnGate"), "TurnTicket": ("bridge.turn_gate", "TurnTicket"),
    "capability_fingerprint": ("bridge.turn_gate", "capability_fingerprint"),
    "SemanticRequest": ("bridge.semantic_request", "SemanticRequest"), "build_semantic_request": ("bridge.semantic_request", "build_semantic_request"),
    "CapabilityManifest": ("capabilities", "CapabilityManifest"), "HostPluginRouter": ("capabilities", "HostPluginRouter"),
    "plugin_capability": ("capabilities", "plugin_capability"), "preset_plugin_capabilities": ("capabilities", "preset_plugin_capabilities"),
    "image_generation_capability": ("capabilities", "image_generation_capability"), "skill_capability": ("capabilities", "skill_capability"),
    "cognition_capability_stack": ("capabilities", "cognition_capability_stack"), "native_chat_capability_stack": ("capabilities", "native_chat_capability_stack"),
    "developer_source_pool_snapshot": ("capabilities", "developer_source_pool_snapshot"), "search_developer_source_pool": ("capabilities", "search_developer_source_pool"),
    "EvidenceEvent": ("cognition.evidence_records", "EvidenceEvent"), "EvidenceClaim": ("cognition.evidence_records", "EvidenceClaim"),
    "EvidenceAttribution": ("cognition.evidence_records", "EvidenceAttribution"), "EvidenceBundle": ("cognition.evidence_records", "EvidenceBundle"),
    "EntailmentLink": ("cognition.evidence_records", "EntailmentLink"),
    "PreservationLevel": ("governor.evidence_retention", "PreservationLevel"), "PreservationFactors": ("governor.evidence_retention", "PreservationFactors"),
    "EvidencePreservationFloor": ("governor.evidence_retention", "EvidencePreservationFloor"),
    "EvidenceRetentionArbitrator": ("governor.evidence_retention", "EvidenceRetentionArbitrator"),
    "OperatingFoundation": ("foundation.runtime", "OperatingFoundation"), "Namespace": ("foundation.namespace", "Namespace"),
    "MemoryFabric": ("foundation.memory", "MemoryFabric"), "ComponentRegistry": ("foundation.components", "ComponentRegistry"),
    "SelfMaintenanceLedger": ("foundation.self_maintenance", "SelfMaintenanceLedger"),
    "SelfMaintenanceWorkspace": ("foundation.self_maintenance", "SelfMaintenanceWorkspace"),
    "SelfMaintenanceController": ("foundation.self_maintenance", "SelfMaintenanceController"),
}

__all__ = list(_EXPORTS)


def __getattr__(name: str):
    spec = _EXPORTS.get(name)
    if spec is None:
        raise AttributeError(name)
    module_name, symbol = spec
    value = getattr(import_module(f"{__name__}.{module_name}"), symbol)
    globals()[name] = value
    return value
