"""Standard-library Streamable HTTP MCP transport for mobile ChatGPT."""
from __future__ import annotations
from jigaewol_core.constants import VERSION
import argparse
import hmac
import json
import os
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from .mobile_service import MobileRuntimeService

def _schema(fields, required=()):
    return {'type':'object','properties':fields,'required':list(required),'additionalProperties':False}

STRING = {'type':'string'}
TOOLS = [
    ('jigaewol_policy','Propose operator policies, evaluate actual independently executed candidate programs, promote paired observations and consume the active policy in the next cognition request.',_schema({'turn_id':STRING,'operation':{'type':'string','enum':['propose','evaluate','promote','rollback','active']},'arguments':{'type':'object'}},('turn_id','operation','arguments'))),
    ('jigaewol_requirement','Read every original requirement and keep unfinished obligations. Account using a stored current-turn observation or an exact published response span.',_schema({'turn_id':STRING,'operation':{'type':'string','enum':['status','account']},'arguments':{'type':'object'}},('turn_id',))),
    ('jigaewol_capability','Discover classified personal-toolkit candidates, fetch pinned source into quarantine, inspect files, record the actual user approval, probe task effects and bind a reusable adapter.',_schema({'turn_id':STRING,'operation':{'type':'string','enum':['discover','inspect','fetch','get','authorize','materialize','probe','bind']},'arguments':{'type':'object'}},('turn_id','operation','arguments'))),
    ('jigaewol_action_execute','Execute the ZIP pending action once in its task workspace. Copy invocation_id from the pending request; arguments supply only executable details.',_schema({'turn_id':STRING,'invocation_id':STRING,'arguments':{'type':'object'}},('turn_id','invocation_id','arguments'))),
    ('jigaewol_candidate','Propose, execute, run independent workers, synthesize or remember candidate programs under the unchanged user goal.',_schema({'turn_id':STRING,'operation':{'type':'string','enum':['propose','run','run_batch','synthesize','remember']},'arguments':{'type':'object'}},('turn_id','operation','arguments'))),
    ('jigaewol_turn_begin','Pass the exact current user message to the ZIP before generation or work. Preserve USER > JIGAEWOL > MODEL.',
     _schema({'exact_message':STRING,'host_event_id':STRING,'project_id':STRING,'session_id':STRING,'attachments':{'type':'array','items':{'type':'object'}}},('exact_message','host_event_id'))),
    ('jigaewol_turn_next','Get the next ZIP-owned cognition/action request and events after the cursor.',
     _schema({'turn_id':STRING,'event_cursor':{'type':'integer','minimum':0}},('turn_id',))),
    ('jigaewol_turn_observe','Return the actually observed result of the exact pending invocation. Then execute the next request.',
     _schema({'turn_id':STRING,'host_event_id':STRING,'observed_result':{'type':'object'}},('turn_id','host_event_id','observed_result'))),
    ('jigaewol_turn_resume','Resume durable work in this chat; restores unfinished work and event cursor.',
     _schema({'turn_id':STRING,'event_cursor':{'type':'integer','minimum':0}},('turn_id',))),
    ('jigaewol_turn_publish','Retrieve the response released by the original canonical finalizer.',_schema({'turn_id':STRING},('turn_id',))),
    ('jigaewol_request_read','Read the lossless pending request or a subtree using JSON Pointer, e.g. /evidence/host_observations.',_schema({'turn_id':STRING,'json_pointer':STRING},('turn_id',))),
]

def model_view(result):
    """Return the complete request; size is not permission to erase source clauses."""
    return dict(result)

class RuntimeMCPServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, service, token, allowed_origins=(), public_url=''):
        self.service = service
        self.token = token
        self.allowed_origins = set(allowed_origins)
        self.public_url = str(public_url).rstrip('/')
        self.oauth = None
        if self.public_url:
            from .mobile_oauth import OwnerOAuth
            self.oauth = OwnerOAuth(service.root/'oauth.sqlite3',issuer=self.public_url,owner_secret=token)
        super().__init__(address, RuntimeMCPHandler)

class RuntimeMCPHandler(BaseHTTPRequestHandler):
    server_version = 'JIGAEWOL/2.9.0'
    def log_message(self, *_):
        pass

    def _send(self, status, body=None, *, mime='application/json',headers=None):
        data = (str(body).encode() if mime!='application/json' else json.dumps(body,ensure_ascii=False,default=str).encode()) if body is not None else b''
        self.send_response(status)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        if mime=='text/html':
            self.send_header('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'")
        for key,value in (headers or {}).items(): self.send_header(key,value)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/health':
            self._send(200,{'status':'running','transport':'streamable-http','authority':['USER','JIGAEWOL','MODEL']})
        elif self.server.oauth and path in {'/.well-known/oauth-authorization-server','/.well-known/openid-configuration'}:
            self._send(200,self.server.oauth.metadata())
        elif self.server.oauth and path in {'/.well-known/oauth-protected-resource','/.well-known/oauth-protected-resource/mcp'}:
            self._send(200,{'resource':self.server.public_url+'/mcp','authorization_servers':[self.server.public_url],'scopes_supported':['jigaewol']})
        elif self.server.oauth and path == '/authorize':
            try:
                params = {key:value[-1] for key,value in parse_qs(urlsplit(self.path).query).items()}
                self._send(200,self.server.oauth.authorize_page(params),mime='text/html')
            except (ValueError,KeyError) as exc: self._send(400,{'error':str(exc)})
        else:
            self._send(405,{'error':'Use POST /mcp; this server uses JSON responses and cursor polling.'})

    def do_POST(self):
        if self.server.oauth and self.path in {'/register','/authorize','/token','/revoke'}:
            try:
                length = int(self.headers.get('Content-Length','0'))
                if not 0<length<=32768: return self._send(413)
                body = self.rfile.read(length)
                params = json.loads(body) if 'application/json' in self.headers.get('Content-Type','') else {key:value[-1] for key,value in parse_qs(body.decode()).items()}
                if self.path == '/authorize':
                    return self._send(303,headers={'Location':self.server.oauth.authorize(params)})
                method = {'/register':self.server.oauth.register,'/token':self.server.oauth.token,'/revoke':self.server.oauth.revoke}[self.path]
                return self._send(201 if self.path=='/register' else 200,method(params))
            except PermissionError as exc: return self._send(403,{'error':str(exc)})
            except Exception as exc: return self._send(400,{'error':str(exc)})
        if self.path != '/mcp':
            return self._send(404)
        auth = self.headers.get('Authorization','')
        authenticated = hmac.compare_digest(auth,'Bearer '+self.server.token) or (auth.startswith('Bearer ') and self.server.oauth and self.server.oauth.valid(auth[7:]))
        if not authenticated:
            headers = {'WWW-Authenticate':'Bearer resource_metadata="'+self.server.public_url+'/.well-known/oauth-protected-resource"'} if self.server.oauth else {'WWW-Authenticate':'Bearer'}
            return self._send(401,{'error':'authentication_required'},headers=headers)
        origin = self.headers.get('Origin')
        if origin and origin not in self.server.allowed_origins:
            return self._send(403,{'error':'origin_not_registered'})
        try:
            length = int(self.headers.get('Content-Length','0'))
            if not 0 < length <= 16*1024*1024:
                return self._send(413)
            request = json.loads(self.rfile.read(length))
            method = request.get('method')
            params = request.get('params') or {}
            if 'id' not in request:
                return self._send(202)
            if method == 'initialize':
                requested = params.get('protocolVersion')
                result = {'protocolVersion':requested if requested in {'2025-03-26','2025-06-18','2025-11-25'} else '2025-03-26','capabilities':{'tools':{},'resources':{}},
                          'serverInfo':{'name':'JIGAEWOL','version':VERSION},
                          'instructions':Path(__file__).with_name('mobile_instructions.txt').read_text()}
            elif method == 'ping':
                result = {}
            elif method == 'tools/list':
                result = {'tools':[{'name':n,'description':d,'inputSchema':s,'annotations':{'readOnlyHint':n in {'jigaewol_turn_next','jigaewol_request_read','jigaewol_turn_publish'},'openWorldHint':True},
                    '_meta':{'ui':{'resourceUri':'ui://jigaewol/cockpit','visibility':['model','app']},'openai/outputTemplate':'ui://jigaewol/cockpit'}} for n,d,s in TOOLS]}
            elif method == 'tools/call':
                name = params['name']
                arguments = params.get('arguments') or {}
                service = self.server.service
                methods = {'jigaewol_turn_begin':service.begin,'jigaewol_turn_next':service.next,
                           'jigaewol_action_execute':service.execute_action,'jigaewol_candidate':service.candidate,
                           'jigaewol_capability':service.capability,
                           'jigaewol_requirement':service.requirement,
                           'jigaewol_policy':service.policy,
                           'jigaewol_turn_observe':service.observe,'jigaewol_turn_resume':service.resume,
                           'jigaewol_turn_publish':service.publish,'jigaewol_request_read':service.next}
                if name not in methods:
                    raise ValueError('unknown tool')
                pointer = arguments.pop('json_pointer','') if name == 'jigaewol_request_read' else ''
                output = methods[name](**arguments)
                if pointer:
                    node = output['request'].get('request_payload',{})
                    if not pointer.startswith('/'):
                        raise ValueError('JSON Pointer must start with /')
                    for part in pointer[1:].split('/'):
                        key = part.replace('~1','/').replace('~0','~')
                        node = node[int(key)] if isinstance(node,list) else node[key]
                    output = {'turn_id':arguments['turn_id'],'json_pointer':pointer,'value':node,'lossless':True}
                if name != 'jigaewol_request_read':
                    output = model_view(output)
                result = {'content':[{'type':'text','text':json.dumps(output,ensure_ascii=False,default=str)}],
                          'structuredContent':output, 'isError':False,'_meta':{'ui/resourceUri':'ui://jigaewol/cockpit'}}
            elif method == 'resources/list':
                result = {'resources':[{'uri':'ui://jigaewol/cockpit','name':'JIGAEWOL task','mimeType':'text/html;profile=mcp-app'}]}
            elif method == 'resources/templates/list':
                result = {'resourceTemplates':[{'uriTemplate':'jigaewol://turn/{turn_id}/request','name':'lossless ZIP request','mimeType':'application/json'}]}
            elif method == 'resources/read':
                uri = params['uri']
                if uri == 'ui://jigaewol/cockpit':
                    result = {'contents':[{'uri':uri,'mimeType':'text/html;profile=mcp-app',
                        'text':Path(__file__).with_name('mobile_cockpit.html').read_text(),
                        '_meta':{'ui':{'csp':{'connectDomains':[],'resourceDomains':[]}},'openai/widgetCSP':{'connect_domains':[],'resource_domains':[]}}}]}
                    self._send(200,{'jsonrpc':'2.0','id':request['id'],'result':result}); return
                prefix = 'jigaewol://turn/'
                if not uri.startswith(prefix) or not uri.endswith('/request'):
                    raise ValueError('unknown resource')
                turn_id = uri[len(prefix):-len('/request')]
                result = {'contents':[{'uri':uri,'mimeType':'application/json','text':json.dumps(self.server.service.next(turn_id)['request'],ensure_ascii=False,default=str)}]}
            else:
                self._send(200,{'jsonrpc':'2.0','id':request['id'],'error':{'code':-32601,'message':'Method not found'}})
                return
            self._send(200,{'jsonrpc':'2.0','id':request['id'],'result':result})
        except Exception as exc:
            if isinstance(locals().get('request'),dict) and request.get('method') == 'tools/call':
                self._send(200,{'jsonrpc':'2.0','id':request.get('id'),'result':{'content':[{'type':'text','text':str(exc)}],'isError':True}})
            else:
                self._send(400,{'jsonrpc':'2.0','id':locals().get('request',{}).get('id'),'error':{'code':-32602,'message':str(exc)}})

def owner_token(token_path):
    token_path=Path(token_path)
    if not token_path.exists():
        value=os.environ.get('JIGAEWOL_OWNER_SECRET') or secrets.token_urlsafe(48)
        if len(value)<32:raise ValueError('owner connection secret requires at least 32 characters')
        token_path.parent.mkdir(parents=True,exist_ok=True)
        fd=os.open(token_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as stream:stream.write(value)
    token_path.chmod(0o600)
    value=token_path.read_text().strip()
    if len(value)<32:raise ValueError('persisted owner connection secret is invalid')
    return value

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--state',required=True)
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=8787)
    parser.add_argument('--user',default='owner')
    parser.add_argument('--token-file',required=True)
    parser.add_argument('--allow-origin',action='append',default=[])
    parser.add_argument('--worker',action='store_true')
    parser.add_argument('--public-url',default=os.environ.get('JIGAEWOL_PUBLIC_URL',''))
    args = parser.parse_args()
    token_path = Path(args.token_file)
    token=owner_token(token_path)
    from .mobile_adapters import configured_adapters
    service = MobileRuntimeService(args.state,user_id=args.user,adapters=configured_adapters(args.state))
    service.register_configured_adapters()
    if args.worker:
        def worker():
            service.recover_jobs()
            while True:
                service.recover_jobs()
                if not service.work_once():
                    threading.Event().wait(0.5)
        threading.Thread(target=worker,daemon=True).start()
    server = RuntimeMCPServer((args.host,args.port),service,token,args.allow_origin,args.public_url)
    server.serve_forever()

if __name__ == '__main__':
    main()
