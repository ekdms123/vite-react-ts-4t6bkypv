from __future__ import annotations

"""Compact public execution graph for JIGAEWOL.

The graph exposes scheduled work, observations, semantic epoch boundaries,
integrations, persistence, and failures. It exports observable execution/provenance causes, routes, tools, receipts and failures.
"""


def public_trace_graph(runtime) -> dict:
    nodes: list[dict] = []
    edges: list[dict] = []
    seen: set[str] = set()

    def add(nid: str, kind: str, label: str, state: str | None = None, meta: dict | None = None):
        if nid in seen:
            return nid
        seen.add(nid)
        row = {"id": nid, "kind": kind, "label": label, "state": state}
        if meta:
            row["meta"] = meta
        nodes.append(row)
        return nid

    def edge(left: str, right: str, relation: str):
        if left in seen and right in seen:
            edges.append({"from": left, "to": right, "relation": relation})

    goal_ids = (runtime.extensions.get("goal_gravity") or {}).get("anchor_ids", []) or []
    for gid in goal_ids:
        add("goal:" + str(gid), "goal", str(gid), "live")

    add("turn:" + runtime.raw.turn_id, "turn", runtime.raw.turn_id, "active")
    for gid in goal_ids:
        edge("turn:" + runtime.raw.turn_id, "goal:" + str(gid), "preserves")

    for node in runtime.program.nodes:
        nid = "op:" + node.node_id
        add(nid, "operation", node.operation, node.status, {"executor": node.executor})
    for left, right in runtime.program.edges:
        edge("op:" + left, "op:" + right, "depends_on")

    epoch_ids: list[str] = []
    for idx, row in enumerate(runtime.extensions.get("semantic_epochs", []) or []):
        if not isinstance(row, dict):
            continue
        ref = str(row.get("result_ref") or row.get("work_id") or idx)
        eid = "epoch:" + ref
        epoch_ids.append(eid)
        add(eid, "semantic_epoch", str(row.get("kind") or "semantic"), "completed", {
            "material_delta": row.get("material_delta"),
            "source_refs": row.get("source_refs", []),
        })
        if idx == 0:
            edge("turn:" + runtime.raw.turn_id, eid, "starts")
        elif idx > 0:
            edge(epoch_ids[idx - 1], eid, "updates")

    observation_ids: dict[str, str] = {}
    for idx, row in enumerate(runtime.extensions.get("tool_submissions", []) or []):
        if not isinstance(row, dict):
            continue
        source_ref = str(row.get("source_ref") or row.get("work_id") or idx)
        oid = "obs:" + source_ref
        observation_ids[source_ref] = oid
        add(oid, "observation", str(row.get("operation") or row.get("origin_ref") or "tool result"), "observed", {
            "source_ref": row.get("source_ref"),
            "origin_ref": row.get("origin_ref"),
            "result_sha256": row.get("result_sha256"),
        })

    for idx, row in enumerate(runtime.extensions.get("semantic_epochs", []) or []):
        if not isinstance(row, dict):
            continue
        ref = str(row.get("result_ref") or row.get("work_id") or idx)
        eid = "epoch:" + ref
        for source_ref in row.get("source_refs", []) or []:
            if str(source_ref) in observation_ids:
                edge(observation_ids[str(source_ref)], eid, "causes_delta")

    for idx, row in enumerate(runtime.extensions.get("integration_execution_history", []) or []):
        if not isinstance(row, dict):
            continue
        gid = str(row.get("integration_id") or idx)
        rid = "integration:" + gid + ":" + str(idx)
        add(rid, "integration_execution", gid, str(row.get("status") or "observed"), {
            "execution_scope": row.get("execution_scope"),
            "source_ref": row.get("source_ref"),
            "result_sha256": row.get("result_sha256"),
        })
        source_ref = str(row.get("source_ref") or "")
        if source_ref in observation_ids:
            edge(observation_ids[source_ref], rid, "verifies")

    for idx, row in enumerate(runtime.extensions.get("failures", []) or []):
        if not isinstance(row, dict):
            continue
        fid = "failure:" + str(row.get("work_id") or idx)
        add(fid, "failure", str(row.get("failure_type") or row.get("reason") or "failure"), "observed")

    evidence_graph = runtime.extensions.get("evidence_graph") or {}
    graph_nodes = evidence_graph.get("nodes", {}) if isinstance(evidence_graph, dict) else {}
    for node_id, row in graph_nodes.items():
        if not isinstance(row, dict):
            continue
        gid = "decision:" + str(node_id)
        add(gid, "decision_" + str(row.get("kind") or "node"), str(node_id), str(row.get("state") or "open"), {
            "support_strength": row.get("support_strength", 0.0),
            "contradiction_strength": row.get("contradiction_strength", 0.0),
            "component_id": (evidence_graph.get("component_of") or {}).get(node_id),
            "source_grounded": row.get("source_grounded", False) is True,
        })
    for row in evidence_graph.get("edges", []) if isinstance(evidence_graph, dict) else []:
        if not isinstance(row, dict):
            continue
        edge("decision:" + str(row.get("from")), "decision:" + str(row.get("to")), str(row.get("relation") or "depends_on"))

    profile_id = runtime.extensions.get("profile_id")
    if profile_id:
        pid = "profile:" + str(profile_id)
        add(pid, "persistent_mechanism", str(profile_id), str(runtime.extensions.get("adaptation_profile_status", "candidate")))
        if epoch_ids:
            edge(epoch_ids[-1], pid, "persists_execution_pattern")

    unique: list[dict] = []
    keys: set[tuple[str, str, str]] = set()
    for row in edges:
        key = (row["from"], row["to"], row["relation"])
        if key not in keys:
            keys.add(key)
            unique.append(row)

    return {
        "version": 4,
        "turn_id": runtime.raw.turn_id,
        "task_id": runtime.raw.task_id,
        "nodes": nodes,
        "edges": unique,
        "scope": "observable_execution_and_provenance",
    }
