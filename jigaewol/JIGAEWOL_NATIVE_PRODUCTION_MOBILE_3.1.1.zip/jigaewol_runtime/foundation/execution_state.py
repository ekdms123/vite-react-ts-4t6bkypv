from __future__ import annotations

"""Durable handles for execution state that lives outside the chat process.

A stored handle is a locator, not proof that a process/session is still alive. On
reload, previously live handles are marked stale until a real provider probe
confirms them again.
"""
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path


def _now(): return datetime.now(timezone.utc).isoformat()

class ExecutionStateLedger:
    def __init__(self, path, *, host_session_id=None):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.host_session_id = str(host_session_id) if host_session_id is not None else None
        if self.path.exists():
            data=json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data,dict) or not isinstance(data.get("handles",{}),dict):
                raise ValueError("invalid execution state ledger")
            self._data=data
            prior_session=self._data.get("host_session_id")
            # Legacy/no-session callers retain the conservative restart rule.
            # OperatingFoundation supplies its stable chat session id so a new
            # Python process on the *same chat* does not manufacture a session
            # change on every turn. A real chat/session change invalidates live
            # claims until a provider probe occurs.
            session_changed = (
                self.host_session_id is None or prior_session is None
                or prior_session != self.host_session_id
            )
            changed=False
            if session_changed:
                for row in self._data["handles"].values():
                    if row.get("status") in {"observed_alive","registered"}:
                        row["status"]="stale_unprobed"
                        changed=True
            if self.host_session_id is not None and prior_session != self.host_session_id:
                self._data["host_session_id"]=self.host_session_id
                changed=True
            if changed: self._persist()
        else:
            self._data={"version":2,"handles":{},"host_session_id":self.host_session_id}
            self._persist()

    def _persist(self):
        tmp=self.path.with_suffix(self.path.suffix+".tmp")
        tmp.write_text(json.dumps(self._data,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
        tmp.replace(self.path)

    def register(self, *, kind, provider, handle_id, origin_ref, metadata=None):
        for name,value in (("kind",kind),("provider",provider),("handle_id",handle_id),("origin_ref",origin_ref)):
            if not isinstance(value,str) or not value.strip(): raise ValueError(name+" must be nonempty text")
        key=f"{provider.strip()}::{kind.strip()}::{handle_id.strip()}"
        row={
            "key":key,"kind":kind.strip(),"provider":provider.strip(),"handle_id":handle_id.strip(),
            "origin_ref":origin_ref.strip(),"metadata":deepcopy(metadata or {}),
            "status":"registered","registered_at":_now(),"last_probe_at":None,
        }
        self._data["handles"][key]=row; self._persist(); return deepcopy(row)


    def observe(self, *, kind, provider, handle_id, origin_ref, metadata=None, alive=True):
        """Register a handle from a real host observation and immediately bind liveness.

        This method is for the same turn that actually created/queried the
        external resource.  Reloaded/imported handles must still re-probe.
        """
        if type(alive) is not bool:
            raise ValueError("alive must be boolean")
        row = self.register(
            kind=kind, provider=provider, handle_id=handle_id,
            origin_ref=origin_ref, metadata=metadata or {},
        )
        return self.probe(row["key"], alive=alive, origin_ref=origin_ref)

    def probe_descriptor(self, descriptor):
        """Apply a normalized execution-probe descriptor."""
        if not isinstance(descriptor, dict):
            raise ValueError("execution probe descriptor must be an object")
        key = descriptor.get("key")
        if not key:
            for name in ("provider", "kind", "handle_id"):
                if not isinstance(descriptor.get(name), str) or not descriptor[name].strip():
                    raise ValueError("execution probe descriptor requires key or provider/kind/handle_id")
            key = f"{descriptor['provider'].strip()}::{descriptor['kind'].strip()}::{descriptor['handle_id'].strip()}"
        return self.probe(key, alive=descriptor.get("alive"), origin_ref=descriptor.get("origin_ref"))

    def probe(self, key, *, alive, origin_ref):
        if not isinstance(alive,bool): raise ValueError("alive must be boolean")
        if key not in self._data["handles"]: raise KeyError(key)
        if not isinstance(origin_ref,str) or not origin_ref.strip(): raise ValueError("origin_ref must be nonempty text")
        row=self._data["handles"][key]
        row["status"]="observed_alive" if alive else "observed_unavailable"
        row["last_probe_at"]=_now(); row["last_probe_origin_ref"]=origin_ref.strip()
        self._persist(); return deepcopy(row)

    def invalidate(self,key,*,reason):
        if key not in self._data["handles"]: raise KeyError(key)
        row=self._data["handles"][key]; row["status"]="invalidated"; row["invalidated_reason"]=str(reason); row["invalidated_at"]=_now()
        self._persist(); return deepcopy(row)

    def snapshot(self):
        return tuple(deepcopy(self._data["handles"][k]) for k in sorted(self._data["handles"]))

    def usable(self):
        return tuple(row for row in self.snapshot() if row.get("status")=="observed_alive")

    def reprobe_plan(self):
        """Return locators that need a real provider probe before reuse.

        The plan is intentionally provider-neutral.  HOST decides which concrete
        tool action can prove that a VM, browser session, remote computer or
        delegated job still exists.
        """
        rows=[]
        for row in self.snapshot():
            if row.get("status") not in {"stale_unprobed", "registered"}:
                continue
            rows.append({
                "key": row["key"],
                "kind": row["kind"],
                "provider": row["provider"],
                "handle_id": row["handle_id"],
                "metadata": deepcopy(row.get("metadata") or {}),
                "required_observation": "real_provider_probe_before_reuse",
            })
        return tuple(rows)

    def import_handles(self, handles, *, source_ref):
        """Recover external execution locators without recovering liveness.

        Project memory may remember that a browser/VM/remote computer handle
        existed.  A new chat process cannot know whether that external state is
        still alive, so every imported handle is deliberately marked
        ``stale_unprobed`` until HOST performs a real provider probe.
        """
        if isinstance(handles, dict):
            handles=[handles]
        if isinstance(handles, (str, bytes)) or not isinstance(handles, (list, tuple)):
            raise ValueError("execution handles snapshot must be a list of objects")
        if not isinstance(source_ref, str) or not source_ref.strip():
            raise ValueError("source_ref must be nonempty text")
        imported=[]
        for incoming in handles:
            if not isinstance(incoming, dict):
                raise ValueError("execution handles snapshot entries must be objects")
            for name in ("kind", "provider", "handle_id"):
                if not isinstance(incoming.get(name), str) or not incoming[name].strip():
                    raise ValueError("imported execution handle requires "+name)
            key=f"{incoming['provider'].strip()}::{incoming['kind'].strip()}::{incoming['handle_id'].strip()}"
            metadata=deepcopy(incoming.get("metadata") or {})
            metadata["imported_from"] = source_ref.strip()
            metadata["imported_previous_status"] = incoming.get("status")
            row={
                "key":key,
                "kind":incoming["kind"].strip(),
                "provider":incoming["provider"].strip(),
                "handle_id":incoming["handle_id"].strip(),
                "origin_ref":"external_import:"+source_ref.strip(),
                "metadata":metadata,
                "status":"stale_unprobed",
                "registered_at":incoming.get("registered_at") or _now(),
                "last_probe_at":None,
                "imported_at":_now(),
            }
            self._data["handles"][key]=row
            imported.append(deepcopy(row))
        self._persist()
        return tuple(imported)
