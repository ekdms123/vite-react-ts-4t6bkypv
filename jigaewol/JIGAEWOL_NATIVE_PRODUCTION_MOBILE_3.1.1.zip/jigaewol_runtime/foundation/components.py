from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess
import sys

from jigaewol_runtime.capabilities.ranker import rank_capabilities

_FORBIDDEN_NAMES = {"open", "eval", "exec", "compile", "__import__", "input", "breakpoint"}
_FORBIDDEN_NODES = (ast.Import, ast.ImportFrom, ast.With, ast.AsyncWith, ast.Lambda, ast.Global, ast.Nonlocal)


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _validate_pure_component_python(source: str):
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, _FORBIDDEN_NODES):
            raise ValueError(f"pure component forbids {type(node).__name__}")
        if isinstance(node, ast.Name) and node.id in _FORBIDDEN_NAMES:
            raise ValueError(f"pure component forbids name {node.id}")
        if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            raise ValueError("pure component forbids dunder attribute access")
    defs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run"]
    if len(defs) != 1:
        raise ValueError("pure Python component must define exactly one run(payload) function")
    if len(defs[0].args.args) != 1:
        raise ValueError("run must accept exactly one positional payload")


class ComponentRegistry:
    """Content-addressed executable knowledge with execution evidence."""

    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.registry_path = self.root / "registry.json"
        if not self.registry_path.exists():
            self.registry_path.write_text(json.dumps({"version": 2, "components": {}}, indent=2) + "\n", encoding="utf-8")

    def _load(self):
        data = json.loads(self.registry_path.read_text(encoding="utf-8"))
        return data

    def _save(self, data):
        tmp = self.registry_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.registry_path)

    def register_pure_python(self, *, component_id, source, provenance, dependencies=(), permissions=(), license="internal-generated", trust_scope="pure_function"):
        if not isinstance(component_id, str) or not component_id.strip():
            raise ValueError("component_id must be nonempty text")
        if not isinstance(source, str) or not source.strip():
            raise ValueError("component source must be nonempty text")
        if trust_scope != "pure_function":
            raise ValueError("this executor only promotes pure_function components")
        _validate_pure_component_python(source)
        digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
        versioned_id = f"{component_id}@{digest[:12]}"
        component_dir = self.root / digest
        component_dir.mkdir(parents=True, exist_ok=True)
        source_path = component_dir / "component.py"
        if source_path.exists() and source_path.read_text(encoding="utf-8") != source:
            raise RuntimeError("content-addressed component collision")
        source_path.write_text(source, encoding="utf-8")
        manifest = {
            "component_id": component_id, "versioned_id": versioned_id, "sha256": digest,
            "entrypoint": "run", "kind": "python_component", "provenance": provenance,
            "dependencies": list(dependencies), "permissions": list(permissions), "license": license,
            "trust_scope": trust_scope, "execution_evidence": [], "integrated": False,
            "task_description": "", "retrieval_terms": [], "created_at": datetime.now(timezone.utc).isoformat(),
        }
        data = self._load()
        prior = data["components"].get(versioned_id)
        if prior and prior["sha256"] != digest:
            raise RuntimeError("component version collision")
        if prior:
            return prior
        data["components"][versioned_id] = manifest
        self._save(data)
        return manifest

    def execute(self, versioned_id: str, payload, *, timeout=5.0):
        data = self._load()
        if versioned_id not in data["components"]:
            raise KeyError(versioned_id)
        manifest = data["components"][versioned_id]
        path = self.root / manifest["sha256"] / "component.py"
        wrapper = r'''
import importlib.util, json, sys
path=sys.argv[1]
spec=importlib.util.spec_from_file_location("jigaewol_component", path)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
payload=json.loads(sys.stdin.read())
out=mod.run(payload)
sys.stdout.write(json.dumps(out, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False))
'''
        encoded = _json(payload)
        proc = subprocess.run(
            [sys.executable, "-I", "-c", wrapper, str(path)], input=encoded,
            text=True, capture_output=True, timeout=timeout,
        )
        evidence = {
            "executed_at": datetime.now(timezone.utc).isoformat(),
            "input_sha256": hashlib.sha256(encoded.encode("utf-8")).hexdigest(),
            "exit_code": proc.returncode,
            "stderr": proc.stderr,
        }
        if proc.returncode != 0:
            manifest["execution_evidence"].append(evidence)
            self._save(data)
            raise RuntimeError("component execution failed: " + proc.stderr.strip())
        result = json.loads(proc.stdout)
        evidence["output_sha256"] = hashlib.sha256(proc.stdout.encode("utf-8")).hexdigest()
        manifest["execution_evidence"].append(evidence)
        manifest["executed"] = True
        self._save(data)
        return result, evidence

    def export_bundle(self, versioned_id: str):
        data = self._load()
        manifest = data["components"].get(versioned_id)
        if manifest is None:
            raise KeyError(versioned_id)
        source_path = self.root / manifest["sha256"] / "component.py"
        source = source_path.read_text(encoding="utf-8")
        actual = hashlib.sha256(source.encode("utf-8")).hexdigest()
        if actual != manifest["sha256"]:
            raise RuntimeError("component source no longer matches registry sha256")
        return {"manifest": manifest, "source": source}

    def export_integrated_bundles(self):
        data = self._load()
        return tuple(self.export_bundle(vid) for vid, row in sorted(data["components"].items()) if row.get("integrated") is True)

    def import_bundle(self, bundle):
        if not isinstance(bundle, dict) or not isinstance(bundle.get("manifest"), dict) or not isinstance(bundle.get("source"), str):
            raise ValueError("component bundle must contain manifest and source")
        manifest = dict(bundle["manifest"])
        source = bundle["source"]
        if manifest.get("kind") == "python_subagent":
            manifest["kind"] = "python_component"
        expected = str(manifest.get("sha256", ""))
        actual = hashlib.sha256(source.encode("utf-8")).hexdigest()
        if actual != expected:
            raise ValueError("component bundle source sha256 mismatch")
        if manifest.get("kind") != "python_component" or manifest.get("trust_scope") != "pure_function":
            raise ValueError("unsupported imported component trust scope")
        _validate_pure_component_python(source)
        versioned_id = manifest.get("versioned_id")
        if not isinstance(versioned_id, str) or not versioned_id.endswith("@" + expected[:12]):
            raise ValueError("component bundle versioned_id does not bind source hash")
        component_dir = self.root / expected
        component_dir.mkdir(parents=True, exist_ok=True)
        source_path = component_dir / "component.py"
        if source_path.exists() and source_path.read_text(encoding="utf-8") != source:
            raise RuntimeError("content-addressed component collision")
        source_path.write_text(source, encoding="utf-8")
        data = self._load()
        existing = data["components"].get(versioned_id)
        if existing is not None and existing.get("sha256") != expected:
            raise RuntimeError("component registry collision")
        # External execution evidence is provenance, not a local execution claim.
        imported = dict(manifest)
        imported["imported_execution_evidence"] = list(imported.pop("execution_evidence", []))
        imported["execution_evidence"] = []
        imported["executed"] = False
        imported["imported_from_external_memory"] = True
        data["components"][versioned_id] = imported
        self._save(data)
        return dict(imported)

    def integrate(self, versioned_id: str, *, scope: str, basis: str):
        data = self._load()
        manifest = data["components"].get(versioned_id)
        if manifest is None:
            raise KeyError(versioned_id)
        if not manifest.get("execution_evidence") or not any(e.get("exit_code") == 0 for e in manifest["execution_evidence"]):
            raise ValueError("component integration requires successful execution evidence")
        manifest["integrated"] = True
        manifest["integration_scope"] = scope
        manifest["integration_basis"] = basis
        self._save(data)
        return dict(manifest)

    def get(self, versioned_id):
        return self._load()["components"].get(versioned_id)

    def snapshot(self):
        return self._load()

    def learn_from_success(self, *, component_id, source, task_description, probe_payload, provenance,
                           expected_output=None, dependencies=(), permissions=(), license="internal-generated"):
        if not isinstance(task_description, str) or not task_description.strip():
            raise ValueError("task_description must be nonempty text")
        manifest = self.register_pure_python(
            component_id=component_id, source=source, provenance=provenance, dependencies=dependencies,
            permissions=permissions, license=license, trust_scope="pure_function",
        )
        data = self._load(); row = data["components"][manifest["versioned_id"]]
        row["task_description"] = task_description.strip()
        row["retrieval_terms"] = sorted(set(task_description.casefold().replace("/", " ").replace("-", " ").split()))
        self._save(data)
        result, evidence = self.execute(manifest["versioned_id"], probe_payload)
        if expected_output is not None and result != expected_output:
            data = self._load(); row = data["components"][manifest["versioned_id"]]
            row["candidate_rejected"] = True
            row["rejection_reason"] = "probe output did not match expected_output"
            self._save(data)
            raise ValueError("component probe output did not match expected_output")
        return self.get(manifest["versioned_id"])

    def _rankable_specs(self, *, include_unintegrated=True):
        data = self._load(); specs=[]
        for vid,row in sorted(data["components"].items()):
            if row.get("candidate_rejected"):
                continue
            if not row.get("execution_evidence"):
                continue
            if not include_unintegrated and row.get("integrated") is not True:
                continue
            description = " ".join(x for x in [row.get("task_description", ""), " ".join(row.get("retrieval_terms") or ())] if x)
            specs.append({
                "id": vid, "role": "reusable_executable_component", "description": description or row.get("component_id", vid),
                "provider": "jigaewol.component_registry", "tags": list(row.get("retrieval_terms") or ()),
            })
        return specs

    def recommend(self, task_description: str, *, include_unintegrated=True):
        specs = self._rankable_specs(include_unintegrated=include_unintegrated)
        ranked = rank_capabilities(task_description, specs) if specs else []
        if not ranked:
            return None
        spec, score = ranked[0]
        return {"versioned_id": spec["id"], "score": float(score), "manifest": self.get(spec["id"])}

    def reuse_for_task(self, task_description: str, payload, *, timeout=5.0):
        match = self.recommend(task_description, include_unintegrated=True)
        if match is None:
            return None
        result, evidence = self.execute(match["versioned_id"], payload, timeout=timeout)
        manifest = self.get(match["versioned_id"])
        successes = sum(1 for e in manifest.get("execution_evidence", ()) if e.get("exit_code") == 0)
        if manifest.get("integrated") is not True and successes >= 2:
            manifest = self.integrate(
                match["versioned_id"], scope="retrieved_similar_task",
                basis="candidate generated from prior successful task and succeeded on a second retrieved similar task",
            )
        return {"versioned_id": match["versioned_id"], "score": match["score"], "result": result, "evidence": evidence, "manifest": manifest}

    def capability_specs(self):
        return tuple(self._rankable_specs(include_unintegrated=False))

