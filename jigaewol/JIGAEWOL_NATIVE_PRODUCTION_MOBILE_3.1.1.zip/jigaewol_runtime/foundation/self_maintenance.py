from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json


class SelfMaintenanceLedger:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(json.dumps({"version": 1, "candidates": []}, indent=2) + "\n", encoding="utf-8")

    def record(self, *, parent_version, candidate_version, modification_trigger, changed_files,
               previous_structure_insufficient, actual_execution_evidence, preserved_capabilities,
               newly_gained_capabilities, known_regressions_or_unknowns, rollback_target, disposition="candidate"):
        if disposition not in {"candidate", "promoted", "retained_for_revision"}:
            raise ValueError("invalid maintenance disposition")
        row = {
            "parent_version": parent_version,
            "candidate_version": candidate_version,
            "modification_trigger": modification_trigger,
            "changed_subsystem_files": list(changed_files),
            "why_previous_structure_was_insufficient": previous_structure_insufficient,
            "actual_execution_evidence": actual_execution_evidence,
            "preserved_capabilities": list(preserved_capabilities),
            "newly_gained_capability": list(newly_gained_capabilities),
            "known_regressions_or_unknowns": list(known_regressions_or_unknowns),
            "rollback_target": rollback_target,
            "disposition": disposition,
            "recorded_at": datetime.now(timezone.utc).isoformat(),
        }
        data = json.loads(self.path.read_text(encoding="utf-8"))
        data["candidates"].append(row)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)
        return row


class SelfMaintenanceWorkspace:
    """Isolated mechanical workspace for self-source maintenance.

    It copies the active tree into a candidate directory, applies exact-text edits,
    and records argv-based probes. Promotion is a separate evidence-backed operation.
    """

    def __init__(self, parent_root, candidate_root):
        from pathlib import Path
        self.parent_root = Path(parent_root).resolve()
        self.candidate_root = Path(candidate_root).resolve()
        if self.parent_root == self.candidate_root:
            raise ValueError("candidate_root must differ from parent_root")
        try:
            self.candidate_root.relative_to(self.parent_root)
        except ValueError:
            pass
        else:
            raise ValueError("candidate_root must not be nested inside parent_root")
        self.events_path = self.candidate_root / ".jigaewol_self_maintenance.json"

    @classmethod
    def create(cls, parent_root, candidate_root):
        import shutil
        from pathlib import Path
        parent = Path(parent_root).resolve(); candidate = Path(candidate_root).resolve()
        if not parent.is_dir():
            raise ValueError("parent_root must be an existing directory")
        if candidate.exists():
            raise FileExistsError("candidate_root already exists; refusing to overwrite")
        obj = cls(parent, candidate)
        shutil.copytree(parent, candidate, ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','.git','.jigaewol_state'))
        obj._append({"kind":"candidate_created","parent_root":str(parent),"candidate_root":str(candidate)})
        return obj

    def _inside_candidate(self, relative_path):
        from pathlib import Path
        rel = Path(relative_path)
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError("relative_path must stay inside candidate")
        path = (self.candidate_root / rel).resolve()
        path.relative_to(self.candidate_root)
        return path

    def _append(self, row):
        from datetime import datetime, timezone
        import json
        data={"version":1,"events":[]}
        if self.events_path.exists():
            data=json.loads(self.events_path.read_text(encoding='utf-8'))
        row=dict(row); row["recorded_at"]=datetime.now(timezone.utc).isoformat()
        data.setdefault("events",[]).append(row)
        self.events_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding='utf-8')
        return row

    def replace_text(self, relative_path, *, old, new, trigger):
        import hashlib
        if not isinstance(old,str) or not old:
            raise ValueError("old must be nonempty exact text")
        if not isinstance(new,str):
            raise ValueError("new must be text")
        path=self._inside_candidate(relative_path)
        before=path.read_text(encoding='utf-8')
        if before.count(old) != 1:
            raise ValueError("old text must match exactly once in candidate file")
        before_sha=hashlib.sha256(before.encode()).hexdigest()
        after=before.replace(old,new,1)
        path.write_text(after,encoding='utf-8')
        after_sha=hashlib.sha256(after.encode()).hexdigest()
        return self._append({
            "kind":"candidate_patch","file":str(relative_path),"trigger":str(trigger),
            "before_sha256":before_sha,"after_sha256":after_sha,
        })

    def run_probe(self, argv, *, timeout=60.0):
        import subprocess
        if not isinstance(argv,(list,tuple)) or not argv or any(not isinstance(x,str) or not x for x in argv):
            raise ValueError("argv must be a nonempty string sequence")
        proc=subprocess.run(list(argv),cwd=self.candidate_root,text=True,capture_output=True,timeout=timeout)
        row=self._append({
            "kind":"candidate_probe","argv":list(argv),"exit_code":proc.returncode,
            "stdout":proc.stdout,"stderr":proc.stderr,
        })
        return row

    @staticmethod
    def _checkpoint_members(root):
        """Return deterministic source members for a recoverable dev checkpoint.

        Checkpoints intentionally exclude transient execution state and caches.
        They preserve source, tests, release metadata and maintenance evidence so
        an interrupted chat/runtime can reconstruct the candidate without
        pretending the old Python process is still alive.
        """
        root = Path(root).resolve()
        excluded_parts = {"__pycache__", ".pytest_cache", ".git", ".jigaewol_state"}
        rows = []
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            if any(part in excluded_parts for part in rel.parts):
                continue
            data = path.read_bytes()
            rows.append({
                "path": rel.as_posix(),
                "size": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            })
        return rows

    def checkpoint_archive(self, destination, *, label="development-checkpoint"):
        """Create a verified recoverable ZIP without modifying the parent tree.

        The archive carries a content manifest inside the ZIP and a sidecar
        manifest next to it.  This is a durability mechanism, not a promotion:
        creating a checkpoint does not make the candidate canonical or trusted.
        """
        import zipfile

        destination = Path(destination).resolve()
        if destination.suffix.lower() != ".zip":
            raise ValueError("checkpoint destination must be a .zip path")
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            raise FileExistsError("checkpoint archive already exists; refusing to overwrite")
        for root in (self.parent_root, self.candidate_root):
            try:
                destination.relative_to(root)
            except ValueError:
                pass
            else:
                raise ValueError("checkpoint archive must live outside parent and candidate trees")

        members = self._checkpoint_members(self.candidate_root)
        manifest = {
            "format": "JIGAEWOL_SELF_MAINTENANCE_CHECKPOINT_V1",
            "label": str(label),
            "parent_root": str(self.parent_root),
            "candidate_root_at_capture": str(self.candidate_root),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "member_count": len(members),
            "members": members,
        }
        manifest_bytes = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
        manifest_name = "JIGAEWOL_CHECKPOINT_MANIFEST.json"
        with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for row in members:
                zf.write(self.candidate_root / row["path"], row["path"])
            zf.writestr(manifest_name, manifest_bytes)

        archive_sha = hashlib.sha256(destination.read_bytes()).hexdigest()
        sidecar = destination.with_suffix(destination.suffix + ".manifest.json")
        sidecar_payload = {
            "archive": str(destination),
            "archive_sha256": archive_sha,
            "embedded_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
            **manifest,
        }
        sidecar.write_text(json.dumps(sidecar_payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        self._append({
            "kind": "candidate_checkpoint",
            "label": str(label),
            "archive": str(destination),
            "archive_sha256": archive_sha,
            "member_count": len(members),
            "truth_state": "checkpoint_only_not_promoted",
        })
        return sidecar_payload

    @classmethod
    def restore_checkpoint(cls, archive_path, destination):
        """Verify and restore a development checkpoint into a new directory."""
        import zipfile

        archive_path = Path(archive_path).resolve()
        destination = Path(destination).resolve()
        if destination.exists():
            raise FileExistsError("checkpoint restore destination already exists")
        if not archive_path.is_file():
            raise FileNotFoundError(str(archive_path))
        with zipfile.ZipFile(archive_path, "r") as zf:
            try:
                raw = zf.read("JIGAEWOL_CHECKPOINT_MANIFEST.json")
            except KeyError as exc:
                raise ValueError("checkpoint has no embedded manifest") from exc
            manifest = json.loads(raw.decode("utf-8"))
            if manifest.get("format") != "JIGAEWOL_SELF_MAINTENANCE_CHECKPOINT_V1":
                raise ValueError("unsupported checkpoint format")
            expected = {row["path"]: row for row in manifest.get("members", [])}
            if len(expected) != int(manifest.get("member_count", -1)):
                raise ValueError("checkpoint manifest member count mismatch")
            names = set(zf.namelist()) - {"JIGAEWOL_CHECKPOINT_MANIFEST.json"}
            if names != set(expected):
                raise ValueError("checkpoint archive/member manifest mismatch")
            for name, row in expected.items():
                data = zf.read(name)
                if len(data) != int(row["size"]) or hashlib.sha256(data).hexdigest() != row["sha256"]:
                    raise ValueError("checkpoint member hash mismatch: " + name)
            destination.mkdir(parents=True)
            for name in sorted(names):
                target = (destination / name).resolve()
                target.relative_to(destination)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(zf.read(name))
        return {
            "restored_root": str(destination),
            "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
            "member_count": len(expected),
            "truth_state": "verified_checkpoint_restore_not_promotion",
        }

    def reject(self, *, reason):
        return self._append({"kind":"candidate_rejected","reason":str(reason),"rollback_target":str(self.parent_root)})


class SelfMaintenanceController:
    """Detect -> candidate -> observed capability delta -> versioned release.

    The active tree remains available as a rollback point. Successful probes establish
    that the candidate actually runs. Capability gains and regressions remain visible,
    and explicit user-directed replacement can choose a new structure across tradeoffs.
    """

    def __init__(self, *, stable_root, releases_root, ledger: SelfMaintenanceLedger, parent_version: str):
        from pathlib import Path
        self.stable_root = Path(stable_root).resolve()
        self.releases_root = Path(releases_root).resolve()
        self.releases_root.mkdir(parents=True, exist_ok=True)
        self.ledger = ledger
        self.parent_version = str(parent_version)

    @staticmethod
    def detect(signals: dict):
        if not isinstance(signals, dict):
            raise ValueError("signals must be an object")
        reasons=[]
        if int(signals.get("repeated_error_count", 0) or 0) >= 2:
            reasons.append("repeated_error")
        if signals.get("audit_failure"):
            reasons.append("audit_failure")
        if signals.get("capability_bottleneck"):
            reasons.append("capability_bottleneck")
        if signals.get("stale_subsystem"):
            reasons.append("stale_subsystem")
        return {"self_maintenance_required": bool(reasons), "reasons": tuple(reasons)}

    @staticmethod
    def _events(workspace: SelfMaintenanceWorkspace):
        import json
        if not workspace.events_path.exists():
            return []
        return json.loads(workspace.events_path.read_text(encoding="utf-8")).get("events", [])

    def promote(self, workspace: SelfMaintenanceWorkspace, *, candidate_version: str,
                capability_delta_report: dict, new_capabilities=(), known_unknowns=(),
                user_directed_replacement: bool = False, objective_gain_report: dict | None = None):
        import shutil, json
        if workspace.parent_root != self.stable_root:
            raise ValueError("workspace parent must match the active stable root")
        if not isinstance(capability_delta_report, dict):
            raise ValueError("capability_delta_report must be an object")
        missing = list(capability_delta_report.get("missing_capabilities") or ())
        preserved = list(capability_delta_report.get("preserved_capabilities") or ())
        objective_gain_report = dict(objective_gain_report or {})
        material_gain = bool(objective_gain_report.get("material_gain"))
        events=self._events(workspace)
        probes=[e for e in events if e.get("kind")=="candidate_probe"]
        if not probes or any(int(e.get("exit_code", 1)) != 0 for e in probes):
            raise ValueError("promotion needs successful candidate execution probes")
        patches=[e.get("file") for e in events if e.get("kind")=="candidate_patch" and e.get("file")]
        regressions=[*known_unknowns, *[f"missing:{x}" for x in missing]]
        if missing and not (user_directed_replacement or material_gain):
            record=self.ledger.record(
                parent_version=self.parent_version, candidate_version=candidate_version,
                modification_trigger="candidate_has_visible_capability_tradeoffs", changed_files=patches,
                previous_structure_insufficient="candidate remains available for objective-directed revision",
                actual_execution_evidence=probes, preserved_capabilities=preserved,
                newly_gained_capabilities=list(new_capabilities),
                known_regressions_or_unknowns=regressions,
                rollback_target=str(self.stable_root), disposition="retained_for_revision",
            )
            return {
                "promoted_root": None, "record": record,
                "next_action": "revise_candidate_or_supply_objective_gain_evidence",
            }
        target=(self.releases_root / str(candidate_version)).resolve()
        if target.exists():
            raise FileExistsError("promoted release target already exists")
        shutil.copytree(workspace.candidate_root, target, ignore=shutil.ignore_patterns('.jigaewol_self_maintenance.json','__pycache__','.pytest_cache','.git'))
        record=self.ledger.record(
            parent_version=self.parent_version, candidate_version=str(candidate_version),
            modification_trigger=("user_directed_structure_replacement" if user_directed_replacement else "objective_gain_backed_structure_replacement"),
            changed_files=patches,
            previous_structure_insufficient="candidate addresses the recorded maintenance objective",
            actual_execution_evidence=probes, preserved_capabilities=preserved,
            newly_gained_capabilities=list(new_capabilities),
            known_regressions_or_unknowns=regressions,
            rollback_target=str(self.stable_root), disposition="promoted",
        )
        record["objective_gain_report"] = objective_gain_report
        record["user_directed_replacement"] = bool(user_directed_replacement)
        (target/"SELF_MAINTENANCE_PROMOTION.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        return {"promoted_root":str(target),"record":record}
