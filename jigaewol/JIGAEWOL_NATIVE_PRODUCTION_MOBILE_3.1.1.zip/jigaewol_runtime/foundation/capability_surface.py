from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import json

from jigaewol_runtime.bridge.turn_gate import capability_fingerprint
from jigaewol_runtime.capabilities.manifest import normalize_capabilities


class CapabilitySurfaceLedger:
    """Durable evidence of current-host callable surface changes.

    It never infers callability from installation.  The caller must pass only the
    capabilities the current host has actually exposed as callable.
    """

    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(json.dumps({"version": 1, "current": None, "history": []}, indent=2) + "\n", encoding="utf-8")

    def observe(self, capabilities, *, rebound: bool, receipt_id: str):
        normalized = sorted(normalize_capabilities(capabilities or ()), key=lambda x: x["id"])
        fp = capability_fingerprint(normalized)
        data = json.loads(self.path.read_text(encoding="utf-8"))
        prior = data.get("current") or {"fingerprint": None, "capability_ids": []}
        before = set(prior.get("capability_ids") or ())
        after = {x["id"] for x in normalized}
        changed = prior.get("fingerprint") != fp
        event = {
            "observed_at": datetime.now(timezone.utc).isoformat(),
            "receipt_id": receipt_id,
            "fingerprint": fp,
            "changed": changed,
            "rebound": bool(rebound),
            "added": sorted(after - before),
            "removed": sorted(before - after),
            "capability_ids": sorted(after),
            "truth": "callable_current_host_surface_only",
        }
        if changed:
            data.setdefault("history", []).append(event)
        data["current"] = event
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)
        return event

    def snapshot(self):
        return json.loads(self.path.read_text(encoding="utf-8"))
