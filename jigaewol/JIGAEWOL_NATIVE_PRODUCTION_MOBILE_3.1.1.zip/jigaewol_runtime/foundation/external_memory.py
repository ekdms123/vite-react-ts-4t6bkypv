from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re

from .namespace import Namespace


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass(frozen=True)
class ExternalMemoryAction:
    action_id: str
    provider: str
    operation: str
    payload: dict
    reason: str


class ExternalMemoryConflict(RuntimeError):
    def __init__(self, message, *, head_revision_ids=()):
        super().__init__(message)
        self.head_revision_ids = tuple(head_revision_ids)


class ExternalActionQueue:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(json.dumps({"version": 1, "actions": {}}, indent=2) + "\n", encoding="utf-8")

    def _load(self):
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("actions"), dict):
            raise ValueError("invalid external action queue")
        return data

    def _save(self, data):
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    def enqueue(self, provider, operation, payload, reason):
        raw = _json([provider, operation, payload, reason])
        action_id = "ext_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]
        data = self._load()
        row = data["actions"].get(action_id)
        if row is None:
            row = {
                "action_id": action_id, "provider": provider, "operation": operation,
                "payload": payload, "reason": reason, "status": "pending",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            data["actions"][action_id] = row
            self._save(data)
        return ExternalMemoryAction(action_id, provider, operation, payload, reason)

    def acknowledge(self, action_id, *, result, status="executed"):
        data = self._load()
        if action_id not in data["actions"]:
            raise KeyError(action_id)
        if status not in {"executed", "failed", "unavailable"}:
            raise ValueError("invalid external action status")
        row = data["actions"][action_id]
        row["status"] = status
        row["result"] = result
        row["updated_at"] = datetime.now(timezone.utc).isoformat()
        self._save(data)
        return dict(row)

    def pending(self):
        data = self._load()
        return tuple(dict(row) for row in data["actions"].values() if row.get("status") == "pending")


class NotionMemoryCodec:
    FORMAT = "JIGAEWOL_MEMORY_V1"

    @classmethod
    def revision_id(cls, snapshot: dict, *, scope: str, stream_key: str, parent_revision_id: str | None = None):
        raw = _json({
            "format": cls.FORMAT,
            "scope": scope,
            "stream_key": stream_key,
            "parent_revision_id": parent_revision_id,
            "snapshot": snapshot,
        })
        return "rev_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]

    @classmethod
    def encode(cls, snapshot: dict, *, release_version: str, continuation: dict | None = None,
               scope: str = "project", stream_key: str | None = None,
               parent_revision_id: str | None = None):
        if stream_key is None:
            stream_key = (snapshot.get("namespace") or {}).get("stable_key")
        if not isinstance(stream_key, str) or not stream_key:
            raise ValueError("external memory stream_key is required")
        revision_id = cls.revision_id(
            snapshot, scope=scope, stream_key=stream_key, parent_revision_id=parent_revision_id,
        )
        lineage = {
            "scope": scope,
            "stream_key": stream_key,
            "revision_id": revision_id,
            "parent_revision_id": parent_revision_id,
        }
        envelope = {
            "format": cls.FORMAT,
            "release_version": release_version,
            "written_at": datetime.now(timezone.utc).isoformat(),
            "snapshot": snapshot,
            "continuation": continuation or {},
            "lineage": lineage,
        }
        payload = json.dumps(envelope, ensure_ascii=False, sort_keys=True, indent=2)
        active = snapshot.get("active") or []
        return (
            f"<callout icon=\"🧠\" color=\"blue_bg\">\n"
            f"\tMachine-recoverable JIGAEWOL {scope} memory. Stream key: `{stream_key}`; revision: `{revision_id}`\n"
            f"</callout>\n"
            f"## Current state\n"
            f"- Active durable memories: {len(active)}\n"
            f"- Release: {release_version}\n"
            f"- External scope: {scope}\n"
            f"## Machine snapshot\n"
            f"```json\n{payload}\n```"
        )

    @classmethod
    def decode(cls, text: str):
        if not isinstance(text, str):
            raise TypeError("Notion content must be text")
        for match in re.finditer(r"```json\s*(\{.*?\})\s*```", text, flags=re.S):
            try:
                data = json.loads(match.group(1))
            except json.JSONDecodeError:
                continue
            if data.get("format") == cls.FORMAT and isinstance(data.get("snapshot"), dict):
                # 10.2.0 snapshots had no lineage. Preserve recovery compatibility.
                if "lineage" not in data:
                    ns = data["snapshot"].get("namespace") or {}
                    stream_key = ns.get("stable_key")
                    if stream_key:
                        data["lineage"] = {
                            "scope": "project", "stream_key": stream_key,
                            "revision_id": cls.revision_id(data["snapshot"], scope="project", stream_key=stream_key),
                            "parent_revision_id": None,
                            "legacy_10_2_0": True,
                        }
                return data
        raise ValueError("JIGAEWOL_MEMORY_V1 snapshot not found")


class NotionScopedMemory:
    """Host-neutral immutable-checkpoint protocol for one memory stream.

    Writes are create-only. Concurrent chats can therefore create sibling
    revisions without overwriting each other. Recovery verifies the lineage and
    rejects divergent heads instead of silently choosing last-writer-wins.
    """

    def __init__(self, namespace: Namespace, queue: ExternalActionQueue, *, scope: str,
                 stream_key: str, parent_page_id=None):
        self.namespace = namespace
        self.queue = queue
        self.scope = scope
        self.stream_key = stream_key
        self.parent_page_id = parent_page_id

    @property
    def title_prefix(self):
        label = {
            "project": self.namespace.project_id,
            "user": self.namespace.user_id,
            "global_reusable": self.namespace.user_id,
        }.get(self.scope, self.scope)
        return f"JIGAEWOL {self.scope.replace('_', ' ').title()} Checkpoint — {label}"

    def bootstrap_search(self, *, operation="search"):
        suffix = self.stream_key[-8:]
        query = f"{self.title_prefix} {suffix}"
        return self.queue.enqueue(
            "notion", operation, {
                "query": query,
                "scope": self.scope,
                "expected_stream_key": self.stream_key,
                "verification": "fetch_candidates_decode_JIGAEWOL_MEMORY_V1_and_match_lineage.stream_key_exactly",
            },
            f"locate_{self.scope}_memory_checkpoints_for_verified_bootstrap",
        )

    def checkpoint_action(self, content: str, *, revision_id: str, parent_revision_id: str | None):
        payload = {
            "title": f"{self.title_prefix} — {revision_id[-8:]}",
            "content": content,
            "scope": self.scope,
            "stream_key": self.stream_key,
            "revision_id": revision_id,
            "parent_revision_id": parent_revision_id,
            "write_semantics": "immutable_create_only_checkpoint",
        }
        if self.parent_page_id:
            payload["parent_page_id"] = self.parent_page_id
        return self.queue.enqueue(
            "notion", "create_page", payload,
            f"persist_{self.scope}_memory_without_overwrite",
        )


class NotionProjectMemory(NotionScopedMemory):
    """Backward-compatible project protocol with immutable 10.2.1 checkpoints."""

    def __init__(self, namespace: Namespace, queue: ExternalActionQueue, *, parent_page_id=None):
        super().__init__(namespace, queue, scope="project", stream_key=namespace.stable_key,
                         parent_page_id=parent_page_id)

    @property
    def title(self):
        # Legacy title retained for callers/docs; new writes use title_prefix+revision.
        return f"JIGAEWOL Project Memory — {self.namespace.project_id} — {self.namespace.stable_key[-8:]}"

    def create_action(self, content: str):
        env = NotionMemoryCodec.decode(content)
        lin = env["lineage"]
        return self.checkpoint_action(content, revision_id=lin["revision_id"], parent_revision_id=lin.get("parent_revision_id"))

    def update_action(self, page_id: str, content: str):
        # 10.2.1 intentionally does not replace page_id. Keep API compatibility
        # while converting the operation into an immutable checkpoint creation.
        env = NotionMemoryCodec.decode(content)
        lin = env["lineage"]
        return self.checkpoint_action(content, revision_id=lin["revision_id"], parent_revision_id=lin.get("parent_revision_id"))
