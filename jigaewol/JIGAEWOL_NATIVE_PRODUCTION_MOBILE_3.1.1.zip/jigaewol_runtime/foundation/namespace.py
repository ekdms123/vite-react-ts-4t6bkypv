from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import re


def _text(value: str, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be nonempty text")
    return value.strip()


def _component(value: str, prefix: str) -> str:
    value = _text(value, prefix)
    slug = re.sub(r"[^a-zA-Z0-9._-]+", "-", value).strip("-._").lower()[:40] or prefix
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]
    return f"{prefix}-{slug}-{digest}"


@dataclass(frozen=True)
class Namespace:
    user_id: str
    project_id: str
    session_id: str

    def __post_init__(self):
        _text(self.user_id, "user_id")
        _text(self.project_id, "project_id")
        _text(self.session_id, "session_id")

    @property
    def stable_key(self) -> str:
        raw = json.dumps([self.user_id, self.project_id], ensure_ascii=False, separators=(",", ":"))
        return "jigaewol-project-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]

    @property
    def user_stable_key(self) -> str:
        raw = json.dumps([self.user_id], ensure_ascii=False, separators=(",", ":"))
        return "jigaewol-user-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]

    @property
    def global_stable_key(self) -> str:
        # global_reusable is global across this operator's projects, not across accounts.
        raw = json.dumps(["global_reusable", self.user_id], ensure_ascii=False, separators=(",", ":"))
        return "jigaewol-global-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]

    def stream_key(self, scope: str) -> str:
        if scope in {"project", "executable"}:
            return self.stable_key
        if scope == "user":
            return self.user_stable_key
        if scope == "global_reusable":
            return self.global_stable_key
        raise ValueError("scope has no external durable stream")


class NamespaceLayout:
    """Physical isolation boundary for user/project/session state.

    Raw identifiers never become path components.  The hash suffix prevents two
    visually similar slugs from aliasing each other while preserving a readable
    directory name.
    """

    def __init__(self, root, namespace: Namespace):
        self.root = Path(root)
        self.namespace = namespace
        self.user_dir = self.root / "users" / _component(namespace.user_id, "user")
        self.project_dir = self.user_dir / "projects" / _component(namespace.project_id, "project")
        self.session_dir = self.project_dir / "sessions" / _component(namespace.session_id, "session")
        self.runtime_dir = self.session_dir / "runtime"
        self.user_memory_dir = self.user_dir / "memory"
        self.project_memory_dir = self.project_dir / "memory"
        self.session_memory_dir = self.session_dir / "memory"
        self.components_dir = self.user_dir / "components"
        self.release_dir = self.root / "releases"

    def ensure(self):
        for path in (
            self.user_dir, self.project_dir, self.session_dir, self.runtime_dir,
            self.user_memory_dir, self.project_memory_dir, self.session_memory_dir,
            self.components_dir, self.release_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)
        manifest = self.project_dir / "namespace.json"
        payload = {
            "user_id": self.namespace.user_id,
            "project_id": self.namespace.project_id,
            "stable_key": self.namespace.stable_key,
        }
        if manifest.exists():
            current = json.loads(manifest.read_text(encoding="utf-8"))
            if current != payload:
                raise RuntimeError("namespace path collision or corrupted namespace manifest")
        else:
            manifest.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        session_manifest = self.session_dir / "namespace.json"
        sp = {**payload, "session_id": self.namespace.session_id}
        if session_manifest.exists():
            current = json.loads(session_manifest.read_text(encoding="utf-8"))
            if current != sp:
                raise RuntimeError("session path collision or corrupted namespace manifest")
        else:
            session_manifest.write_text(json.dumps(sp, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return self
