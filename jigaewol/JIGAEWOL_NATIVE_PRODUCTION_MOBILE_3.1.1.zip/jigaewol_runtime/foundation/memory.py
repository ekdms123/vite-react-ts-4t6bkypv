from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from contextlib import closing
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import sqlite3

from .namespace import NamespaceLayout

SCOPES = {"session", "project", "user", "global_reusable", "executable"}
DURABLE_EVENT_KINDS = {
    "decision", "project_state", "user_preference", "blocker", "capability_transition",
    "component_promotion", "self_maintenance", "open_question", "world_state",
}
TRANSIENT_EVENT_KINDS = {"transient", "chitchat", "tool_observation", "scratch"}


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _now():
    return datetime.now(timezone.utc).isoformat()


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be nonempty text")
    return value.strip()


@dataclass(frozen=True)
class MemoryRecord:
    memory_id: str
    scope: str
    key: str
    value: object
    status: str
    version: int
    supersedes: str | None
    provenance: dict
    created_at: str
    updated_at: str


class _MemoryDB:
    def __init__(self, path: Path, expected_scope: str):
        self.path = path
        self.expected_scope = expected_scope
        path.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(path)) as conn, conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""CREATE TABLE IF NOT EXISTS memories(
                memory_id TEXT PRIMARY KEY,
                scope TEXT NOT NULL,
                key TEXT NOT NULL,
                value_json TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('active','superseded')),
                version INTEGER NOT NULL,
                supersedes TEXT,
                provenance_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS memories_active_key_idx ON memories(key,status,version)")

    @staticmethod
    def _decode(row):
        if row is None:
            return None
        return MemoryRecord(
            memory_id=row[0], scope=row[1], key=row[2], value=json.loads(row[3]), status=row[4],
            version=int(row[5]), supersedes=row[6], provenance=json.loads(row[7]),
            created_at=row[8], updated_at=row[9],
        )

    def active(self, key: str):
        with closing(sqlite3.connect(self.path)) as conn:
            row = conn.execute(
                "SELECT memory_id,scope,key,value_json,status,version,supersedes,provenance_json,created_at,updated_at "
                "FROM memories WHERE key=? AND status='active' ORDER BY version DESC LIMIT 1", (key,)
            ).fetchone()
        return self._decode(row)

    def write(self, scope: str, key: str, value, provenance: dict, *, supersede=True):
        if scope != self.expected_scope:
            raise ValueError(f"scope {scope!r} cannot be written to {self.expected_scope!r} store")
        key = _text(key, "memory key")
        if not isinstance(provenance, dict):
            raise ValueError("provenance must be an object")
        encoded = _json(value)
        now = _now()
        with closing(sqlite3.connect(self.path)) as conn, conn:
            row = conn.execute(
                "SELECT memory_id,value_json,version FROM memories WHERE key=? AND status='active' "
                "ORDER BY version DESC LIMIT 1", (key,)
            ).fetchone()
            if row and row[1] == encoded:
                return self._decode(conn.execute(
                    "SELECT memory_id,scope,key,value_json,status,version,supersedes,provenance_json,created_at,updated_at "
                    "FROM memories WHERE memory_id=?", (row[0],)
                ).fetchone()), False
            prior_id = row[0] if row else None
            version = int(row[2]) + 1 if row else 1
            if row and not supersede:
                raise ValueError("active memory already exists; explicit supersession is required")
            raw_id = _json([scope, key, version, encoded, now])
            memory_id = "mem_" + hashlib.sha256(raw_id.encode("utf-8")).hexdigest()[:20]
            if row:
                conn.execute("UPDATE memories SET status='superseded',updated_at=? WHERE memory_id=?", (now, prior_id))
            conn.execute(
                "INSERT INTO memories(memory_id,scope,key,value_json,status,version,supersedes,provenance_json,created_at,updated_at) "
                "VALUES(?,?,?,?, 'active',?,?,?,?,?)",
                (memory_id, scope, key, encoded, version, prior_id, _json(provenance), now, now),
            )
            created = conn.execute(
                "SELECT memory_id,scope,key,value_json,status,version,supersedes,provenance_json,created_at,updated_at "
                "FROM memories WHERE memory_id=?", (memory_id,)
            ).fetchone()
        return self._decode(created), True

    def list(self, *, include_superseded=False):
        where = "" if include_superseded else " WHERE status='active'"
        with closing(sqlite3.connect(self.path)) as conn:
            rows = conn.execute(
                "SELECT memory_id,scope,key,value_json,status,version,supersedes,provenance_json,created_at,updated_at "
                f"FROM memories{where} ORDER BY key,version"
            ).fetchall()
        return tuple(self._decode(row) for row in rows)


class MemoryWritePolicy:
    """Semantic/event policy: durability is about state change, not turn length."""

    def decide(self, event: dict) -> dict:
        if not isinstance(event, dict):
            raise ValueError("memory event must be an object")
        kind = _text(event.get("kind"), "memory event kind")
        if kind in TRANSIENT_EVENT_KINDS:
            return {"write": False, "reason": "transient_event", "scope": None}
        if event.get("durable") is False:
            return {"write": False, "reason": "explicitly_nondurable", "scope": None}
        if kind not in DURABLE_EVENT_KINDS and event.get("durable") is not True:
            return {"write": False, "reason": "no_durable_state_transition", "scope": None}
        scope = event.get("scope")
        if scope is None:
            if kind == "user_preference": scope = "user"
            elif kind == "component_promotion": scope = "executable"
            elif kind == "world_state" and event.get("reusable_across_projects"): scope = "global_reusable"
            else: scope = "project"
        if scope not in SCOPES:
            raise ValueError("invalid memory scope")
        if scope == "session" and kind != "session_note" and event.get("durable") is not True:
            return {"write": False, "reason": "session_scope_not_durable", "scope": None}
        return {"write": True, "reason": "durable_state_transition", "scope": scope}


class MemoryFabric:
    """Composable memory plane with physically separated project/session stores."""

    def __init__(self, layout: NamespaceLayout):
        self.layout = layout.ensure()
        self.policy = MemoryWritePolicy()
        self._db = {
            "session": _MemoryDB(layout.session_memory_dir / "memory.sqlite3", "session"),
            "project": _MemoryDB(layout.project_memory_dir / "memory.sqlite3", "project"),
            "user": _MemoryDB(layout.user_memory_dir / "user.sqlite3", "user"),
            "global_reusable": _MemoryDB(layout.user_memory_dir / "global_reusable.sqlite3", "global_reusable"),
            "executable": _MemoryDB(layout.user_memory_dir / "executable.sqlite3", "executable"),
        }

    def write(self, *, scope, key, value, provenance, supersede=True):
        if scope not in SCOPES:
            raise ValueError("invalid memory scope")
        return self._db[scope].write(scope, key, value, provenance, supersede=supersede)

    def checkpoint(self, event: dict, *, provenance: dict):
        decision = self.policy.decide(event)
        if not decision["write"]:
            return {**decision, "changed": False, "record": None}
        key = _text(event.get("key"), "memory event key")
        value = deepcopy(event.get("value"))
        record, changed = self.write(
            scope=decision["scope"], key=key, value=value,
            provenance={**deepcopy(provenance), "event_kind": event["kind"]}, supersede=True,
        )
        return {**decision, "changed": changed, "record": asdict(record)}

    def active_records(self):
        # Precedence is session > project > user > global. Executable knowledge is
        # intentionally separate from semantic memory and never shadows it by key.
        merged = {}
        for scope in ("global_reusable", "user", "project", "session"):
            for record in self._db[scope].list():
                merged[record.key] = record
        return tuple(merged[k] for k in sorted(merged))

    def executable_records(self):
        return self._db["executable"].list()

    def scope_records(self, scope, *, include_superseded=False):
        if scope not in SCOPES:
            raise ValueError("invalid memory scope")
        return self._db[scope].list(include_superseded=include_superseded)

    def scope_snapshot(self, scope: str):
        if scope not in {"project", "user", "global_reusable"}:
            raise ValueError("scope has no external snapshot")
        ns = {
            "user_id": self.layout.namespace.user_id,
            "project_id": self.layout.namespace.project_id,
            "session_id": self.layout.namespace.session_id,
            "stable_key": self.layout.namespace.stable_key,
            "stream_key": self.layout.namespace.stream_key(scope),
            "external_scope": scope,
        }
        out = {"namespace": ns, "active": [asdict(x) for x in self.scope_records(scope)]}
        if scope == "project":
            out["executable"] = [asdict(x) for x in self.executable_records()]
        return out

    def project_snapshot(self):
        """External project-memory view without user/global/session contamination."""
        return self.scope_snapshot("project")

    def snapshot(self):
        return {
            "namespace": {
                "user_id": self.layout.namespace.user_id,
                "project_id": self.layout.namespace.project_id,
                "session_id": self.layout.namespace.session_id,
                "stable_key": self.layout.namespace.stable_key,
            },
            "active": [asdict(x) for x in self.active_records()],
            "executable": [asdict(x) for x in self.executable_records()],
        }

    def import_external_snapshot(self, snapshot: dict, *, source_ref: str, scope: str, expected_stream_key: str):
        if scope not in {"project", "user", "global_reusable"}:
            raise ValueError("invalid external memory scope")
        if not isinstance(snapshot, dict):
            raise ValueError("memory snapshot must be an object")
        ns = snapshot.get("namespace") or {}
        actual_stream = ns.get("stream_key")
        if actual_stream is None and scope == "project":
            actual_stream = ns.get("stable_key")  # 10.2.0 compatibility
        if actual_stream != expected_stream_key:
            raise ValueError("external memory belongs to a different memory stream")
        allowed = {scope}
        if scope == "project":
            allowed.add("executable")
        imported = []
        rows = list(snapshot.get("active") or ())
        if scope == "project":
            rows += list(snapshot.get("executable") or ())
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError("snapshot rows must be objects")
            row_scope = row.get("scope")
            if row_scope not in allowed:
                continue
            record, changed = self.write(
                scope=row_scope, key=row["key"], value=row.get("value"),
                provenance={"kind": "external_recovery", "source_ref": source_ref, "source_memory_id": row.get("memory_id")},
                supersede=True,
            )
            if changed:
                imported.append(record.memory_id)
        return tuple(imported)

    def import_snapshot(self, snapshot: dict, *, source_ref: str, allowed_scopes=None):
        if not isinstance(snapshot, dict):
            raise ValueError("memory snapshot must be an object")
        ns = snapshot.get("namespace") or {}
        if ns.get("stable_key") != self.layout.namespace.stable_key:
            raise ValueError("external memory belongs to a different project namespace")
        allowed = set(SCOPES if allowed_scopes is None else allowed_scopes)
        if not allowed <= SCOPES:
            raise ValueError("invalid allowed memory scopes")
        imported = []
        for row in list(snapshot.get("active") or ()) + list(snapshot.get("executable") or ()):
            if not isinstance(row, dict):
                raise ValueError("snapshot rows must be objects")
            scope = row.get("scope")
            if scope not in allowed:
                continue
            record, changed = self.write(
                scope=scope, key=row["key"], value=row.get("value"),
                provenance={"kind": "external_recovery", "source_ref": source_ref, "source_memory_id": row.get("memory_id")},
                supersede=True,
            )
            if changed:
                imported.append(record.memory_id)
        return tuple(imported)
