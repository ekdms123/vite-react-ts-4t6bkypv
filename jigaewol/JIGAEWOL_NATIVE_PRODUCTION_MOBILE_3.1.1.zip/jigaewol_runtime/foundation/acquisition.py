from __future__ import annotations

from dataclasses import asdict
import json

from jigaewol_runtime.capabilities.acquisition import AcquisitionLedger
from jigaewol_runtime.capabilities.developer_source_pool import search_developer_source_pool
from .external_memory import ExternalActionQueue


class CapabilityAcquisitionCoordinator:
    """Open-set host-neutral acquisition planner + lifecycle controller.

    The coordinator never fabricates host actions. It determines the next truth
    transition, asks a supplied executor to perform that transition, then records
    only the evidence returned by the executor. Internal approval labels never
    become a veto; concrete executor requirements are observed at execution time.
    """

    def __init__(self, ledger: AcquisitionLedger, queue: ExternalActionQueue):
        self.ledger = ledger
        self.queue = queue

    @staticmethod
    def acquisition_preferences():
        return {
            "user_directive_is_destination_authority": True,
            "default_cost_policy": "cost_agnostic",
            "cost_constraints_apply_only_when_user_or_executor_requires_them": True,
            "route_preferences_preserve_user_goal": True,
            "goal_survives_route_unavailability": True,
        }

    @staticmethod
    def integrity_review_requirements():
        return (
            "provenance", "dependencies", "execution_surface",
            "incremental_cost_or_quota", "requires_external_api_key",
            "observed_callable_state", "observed_execution_result",
        )


    def plan_discovery(self, need: str, *, include_academic=False):
        if not isinstance(need, str) or not need.strip():
            raise ValueError("capability need must be nonempty text")
        need = need.strip()
        seed_candidates = list(search_developer_source_pool(need, limit=None))
        sensors = [
            ("current_host", "enumerate_callable_capabilities", {"need": need, "inspection_requirements": self.integrity_review_requirements(), "preferences": self.acquisition_preferences()}),
            ("plugin_management", "search_plugins", {"query": need, "inspection_requirements": self.integrity_review_requirements(), "preferences": self.acquisition_preferences()}),
            ("skills", "search_or_list", {"query": need, "inspection_requirements": self.integrity_review_requirements(), "preferences": self.acquisition_preferences()}),
            ("github", "search_repositories_and_code", {"query": need, "seed_candidates": seed_candidates, "inspection_requirements": self.integrity_review_requirements(), "preferences": self.acquisition_preferences()}),
            ("web", "developer_search", {"query": need, "inspection_requirements": self.integrity_review_requirements(), "preferences": self.acquisition_preferences()}),
        ]
        if include_academic:
            sensors.append(("academic", "search", {"query": need}))
        return tuple(asdict(self.queue.enqueue(provider, operation, payload, "capability_need_open_set_discovery"))
                     for provider, operation, payload in sensors)

    def discover_candidate(self, *, need, source_type, source_ref, metadata=None):
        return self.ledger.discover(need=need, source_type=source_type, source_ref=source_ref, metadata=metadata or {})

    def next_stage(self, candidate_id: str):
        row = self.ledger.get(candidate_id)
        if not row.get("inspected"):
            return {"stage": "inspect", "candidate_id": candidate_id, "candidate": row}
        if not row.get("installed"):
            return {"stage": "install", "candidate_id": candidate_id, "candidate": row}
        if row.get("connected") is not True:
            return {"stage": "connect", "candidate_id": candidate_id, "candidate": row}
        if row.get("callable") is not True:
            return {"stage": "probe_callable", "candidate_id": candidate_id, "candidate": row}
        if not row.get("executed"):
            return {"stage": "execute_probe", "candidate_id": candidate_id, "candidate": row}
        if not row.get("integrated"):
            return {"stage": "integrate", "candidate_id": candidate_id, "candidate": row}
        return {"stage": "complete", "candidate_id": candidate_id, "candidate": row}

    def _apply(self, candidate_id: str, action: dict, outcome: dict, *, capability_id: str, scope: str):
        if not isinstance(outcome, dict) or outcome.get("ok") is not True:
            reason = outcome.get("reason", "host stage failed") if isinstance(outcome, dict) else "invalid host result"
            # A failed or caution-labelled route is evidence about that route, not
            # authority to erase the user's capability goal or the candidate.
            self.ledger.block(
                candidate_id, stage=action.get("stage", "unknown"), reason=str(reason),
                evidence_ref=outcome.get("evidence_ref") if isinstance(outcome, dict) else None,
            )
            return self.ledger.get(candidate_id)
        stage = action["stage"]
        self.ledger.clear_blocker(candidate_id)
        if stage == "inspect":
            findings = outcome.get("findings") or {}
            row = self.ledger.inspect(candidate_id, findings=findings)
            self.ledger.set_connection_requirement(
                candidate_id,
                connection_required=findings.get("connection_required", row.get("connection_required")),
            )
        elif stage == "install":
            self.ledger.install(candidate_id, evidence_ref=outcome["evidence_ref"])
        elif stage == "connect":
            self.ledger.connect(candidate_id, evidence_ref=outcome["evidence_ref"])
        elif stage == "probe_callable":
            self.ledger.mark_callable(candidate_id, callable_now=bool(outcome.get("callable")), evidence_ref=outcome["evidence_ref"])
        elif stage == "execute_probe":
            self.ledger.record_execution(candidate_id, result=outcome.get("result"), origin_ref=outcome["origin_ref"])
        elif stage == "integrate":
            self.ledger.integrate(candidate_id, capability_id=capability_id, scope=scope)
        return self.ledger.get(candidate_id)

    def drive(self, candidate_id: str, host_executor, *, capability_id: str, scope: str, max_steps=None):
        """Drive one candidate while there is observable lifecycle progress.

        ``host_executor(action)`` is the only place installation, connection, or
        execution happens.  There is intentionally no arbitrary default step
        ceiling: the lifecycle is finite when the HOST keeps advancing it.  A
        caller may still supply an explicit horizon as a resource boundary.

        If the same non-terminal stage + candidate state repeats, the coordinator
        returns a *resumable* row annotated with ``_drive_status`` instead of
        rejecting the candidate or pretending the underlying capability goal
        failed.  The caller can resume after credentials, connectivity, quota, or
        another host condition changes.
        """
        if not callable(host_executor):
            raise TypeError("host_executor must be callable")
        if max_steps is not None:
            if isinstance(max_steps, bool) or not isinstance(max_steps, int):
                raise ValueError("max_steps must be an integer or None, not boolean")
            if max_steps < 1:
                raise ValueError("max_steps must be at least 1")

        seen_states = set()
        steps = 0
        while True:
            action = self.next_stage(candidate_id)
            stage = action["stage"]
            if stage == "complete":
                return self.ledger.get(candidate_id)

            state_key = json.dumps(
                {"stage": stage, "candidate": action.get("candidate", {})},
                ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str,
            )
            if state_key in seen_states:
                row = self.ledger.get(candidate_id)
                row["_drive_status"] = "blocked_no_progress"
                row["_blocked_stage"] = stage
                row["_resume_hint"] = "resume_after_host_condition_or_route_changes"
                return row
            seen_states.add(state_key)

            if max_steps is not None and steps >= max_steps:
                row = self.ledger.get(candidate_id)
                row["_drive_status"] = "paused_explicit_step_horizon"
                row["_blocked_stage"] = stage
                row["_resume_hint"] = "resume_with_more_steps_or_after_route_change"
                return row

            if stage == "integrate":
                self._apply(candidate_id, action, {"ok": True}, capability_id=capability_id, scope=scope)
                steps += 1
                continue
            outcome = host_executor(action)
            row = self._apply(candidate_id, action, outcome, capability_id=capability_id, scope=scope)
            steps += 1
            if isinstance(row, dict) and row.get("blocked") :
                row["_drive_status"] = "blocked_host_condition"
                row["_blocked_stage"] = action["stage"]
                row["_resume_hint"] = "resume_after_host_condition_or_route_changes"
                return row


    def materialization_plan(self, candidate_id: str, capabilities, *, execution_handles=()):
        """Compile the next candidate into concrete current-HOST actions when possible."""
        from jigaewol_runtime.capabilities.materializer import plan_open_source_materialization
        return plan_open_source_materialization(self.ledger.get(candidate_id), capabilities, execution_handles=execution_handles)

    def queue_next_stage(self, candidate_id: str):
        """Queue the next host stage for chats where no direct executor is supplied."""
        action = self.next_stage(candidate_id)
        if action["stage"] in {"complete", "integrate"}:
            return action
        return asdict(self.queue.enqueue(
            "capability_acquisition", action["stage"],
            {"candidate_id": candidate_id, "candidate": action.get("candidate")},
            "advance_capability_acquisition_lifecycle",
        ))

    def snapshot(self):
        return self.ledger.snapshot()
