from __future__ import annotations

from contextlib import closing
from dataclasses import asdict, replace
from copy import deepcopy
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sqlite3

from jigaewol_runtime.bridge.chat_driver import GeneralChatDriver
from jigaewol_runtime.bridge.turn_gate import PerTurnGate
from jigaewol_runtime.contract.intents import IntentProposal
from jigaewol_runtime.contract.raw_turn import SourceSpan

from .namespace import Namespace, NamespaceLayout
from .memory import MemoryFabric
from .external_memory import ExternalActionQueue, NotionProjectMemory, NotionScopedMemory, NotionMemoryCodec, ExternalMemoryConflict
from .capability_surface import CapabilitySurfaceLedger
from .components import ComponentRegistry
from .acquisition import CapabilityAcquisitionCoordinator
from .self_maintenance import SelfMaintenanceLedger, SelfMaintenanceController
from .execution_state import ExecutionStateLedger
from jigaewol_runtime.capabilities.acquisition import assess_capability_need
from jigaewol_runtime.capabilities.execution_routes import compose_execution_routes, infer_required_traits, trait_discovery_query
from jigaewol_runtime.capabilities.workstation import virtual_workstation_plan
from jigaewol_runtime.capabilities.fabric_plan import build_execution_fabric_plan
from jigaewol_runtime.capabilities.execution_envelope import normalize_execution_handles, normalize_execution_probes
from jigaewol_runtime.capabilities.action_router import action_surface_snapshot
from jigaewol_runtime.capabilities.terminal_protocol import terminal_backplane_status
from jigaewol_runtime.capabilities.local_terminal_bridge import LocalTerminalBridge, capability_spec as local_terminal_capability_spec, CAPABILITY_ID as LOCAL_TERMINAL_CAPABILITY_ID
from jigaewol_components.authority_guard import source_bound_objective, source_effect_authorized

_TRIVIAL_EXACT = {
    "ok", "okay", "thanks", "thank you", "got it", "고마워", "고맙습니다", "이해했어", "알겠어",
}



def _normalized_text(message: str):
    return " ".join(message.casefold().strip().rstrip(".!?~…").split())


def is_trivial_exact(message: str, *, attachments=()):
    """Conservative optimization only; false negatives fall back to full cognition.

    This finite set is not a capability boundary.  It only skips semantic intake
    for exact acknowledgements whose source-grounded intent is unambiguous.
    """
    return not attachments and _normalized_text(message) in _TRIVIAL_EXACT


class FoundationIngressLedger:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(self.path)) as conn, conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""CREATE TABLE IF NOT EXISTS ingress(
                foundation_receipt_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                project_id TEXT NOT NULL,
                session_id TEXT NOT NULL,
                message_sha256 TEXT NOT NULL,
                core_receipt_id TEXT,
                turn_id TEXT,
                capability_fingerprint TEXT,
                capabilities_rebound INTEGER NOT NULL DEFAULT 0,
                path_kind TEXT,
                status TEXT NOT NULL,
                error_type TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""")

    def received(self, ns: Namespace, message: str):
        digest = hashlib.sha256(message.encode("utf-8")).hexdigest()
        now = datetime.now(timezone.utc).isoformat()
        rid = "foundation_" + hashlib.sha256(
            json.dumps([ns.user_id, ns.project_id, ns.session_id, digest, now], separators=(",", ":")).encode()
        ).hexdigest()[:20]
        with closing(sqlite3.connect(self.path)) as conn, conn:
            conn.execute("INSERT INTO ingress VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                rid, ns.user_id, ns.project_id, ns.session_id, digest,
                None, None, None, 0, None, "received", None, now, now,
            ))
        return rid

    def admitted(self, rid, ticket, path_kind):
        now = datetime.now(timezone.utc).isoformat()
        with closing(sqlite3.connect(self.path)) as conn, conn:
            conn.execute(
                "UPDATE ingress SET core_receipt_id=?,turn_id=?,capability_fingerprint=?,capabilities_rebound=?,path_kind=?,status='admitted',updated_at=? WHERE foundation_receipt_id=?",
                (ticket.receipt_id, ticket.turn_id, ticket.capability_fingerprint, int(ticket.capabilities_rebound), path_kind, now, rid),
            )
        return self.get(rid)

    def failed(self, rid, exc):
        now = datetime.now(timezone.utc).isoformat()
        with closing(sqlite3.connect(self.path)) as conn, conn:
            conn.execute("UPDATE ingress SET status='failed',error_type=?,updated_at=? WHERE foundation_receipt_id=?", (type(exc).__name__, now, rid))
        return self.get(rid)

    def get(self, rid):
        with closing(sqlite3.connect(self.path)) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT * FROM ingress WHERE foundation_receipt_id=?", (rid,)).fetchone()
        return dict(row) if row else None

    def recent(self, *, session_id=None):
        with closing(sqlite3.connect(self.path)) as conn:
            conn.row_factory = sqlite3.Row
            if session_id:
                rows = conn.execute("SELECT * FROM ingress WHERE session_id=? ORDER BY created_at DESC", (session_id,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM ingress ORDER BY created_at DESC").fetchall()
        return tuple(dict(row) for row in rows)


class OperatingFoundation:
    """JIGAEWOL 10.2 public operating boundary.

    Existing GeneralChatDriver/PerTurnGate remain the cognition engine.  This
    layer supplies namespace isolation, durable memory, external-memory actions,
    callable-surface evidence, and reusable executable components.
    """

    def __init__(self, root, *, user_id, project_id, session_id="chat", capabilities=(), notion_parent_page_id=None):
        self.namespace = Namespace(user_id, project_id, session_id)
        self.layout = NamespaceLayout(root, self.namespace).ensure()
        self.driver = GeneralChatDriver(self.layout.runtime_dir, session_id=session_id, capabilities=capabilities, require_gate=True)
        self.gate = PerTurnGate(self.driver)
        self.memory = MemoryFabric(self.layout)
        self.ingress_ledger = FoundationIngressLedger(self.layout.project_dir / "foundation.sqlite3")
        self.capability_surface = CapabilitySurfaceLedger(self.layout.project_dir / "capability_surface.json")
        self.external_queue = ExternalActionQueue(self.layout.project_dir / "external_actions.json")
        self.notion = NotionProjectMemory(self.namespace, self.external_queue, parent_page_id=notion_parent_page_id)
        self.notion_streams = {
            "project": self.notion,
            "user": NotionScopedMemory(self.namespace, self.external_queue, scope="user", stream_key=self.namespace.user_stable_key, parent_page_id=notion_parent_page_id),
            "global_reusable": NotionScopedMemory(self.namespace, self.external_queue, scope="global_reusable", stream_key=self.namespace.global_stable_key, parent_page_id=notion_parent_page_id),
        }
        self.components = ComponentRegistry(self.layout.components_dir)
        self.execution_state = ExecutionStateLedger(
            self.layout.project_dir / "execution_state.json", host_session_id=self.namespace.session_id
        )
        self.local_terminal = LocalTerminalBridge(self.layout.session_dir / "local_terminal")
        self.acquisition = CapabilityAcquisitionCoordinator(self.driver.acquisitions, self.external_queue)
        self._execution_fabric_runtime = None

    def execution_fabric_snapshot(self, *, prepare_computer: bool = False, session_id: str = "", objective: str = ""):
        """Expose the durable execution bodies used behind the canonical chat boundary.

        OperatingFoundation is the object actually owned by CoreRuntime.  Delegate the
        broader computer/mobile/acquisition/search/worker snapshot to the persistent
        RuntimeFoundation using a namespace-local durable root, so canonical turns and
        developer tools observe the same execution-fabric semantics.
        """
        if self._execution_fabric_runtime is None:
            from jigaewol_components.runtime_foundation import RuntimeFoundation
            persistent_root = self.layout.project_dir / "execution_fabric_runtime"
            self._execution_fabric_runtime = RuntimeFoundation(
                self.layout.project_dir,
                runtime_identity="JIGAEWOL",
                persistent_root=persistent_root,
            )
        effective_session=str(session_id or self.namespace.session_id)
        shared_mobile_root=self.layout.root.parent / "mobile_cockpit"
        rehydration=self._execution_fabric_runtime.mobile_cockpit.rehydrate_observed_routes_from(
            shared_mobile_root, session_id=effective_session
        )
        snapshot=self._execution_fabric_runtime.execution_fabric_snapshot(
            prepare_computer=prepare_computer,
            session_id=effective_session,
            objective=str(objective or ""),
        )
        snapshot=dict(snapshot)
        mobile=dict(snapshot.get("mobile_cockpit") or {})
        mobile["shared_rehydration"]=rehydration
        snapshot["mobile_cockpit"]=mobile
        return snapshot

    def _host_context_path(self):
        return self.layout.project_dir / "turn_host_context.json"

    def _load_host_contexts(self):
        path=self._host_context_path()
        if not path.exists():
            return {}
        data=json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data,dict) or not isinstance(data.get("turns",{}),dict):
            raise ValueError("invalid turn host context store")
        return data.get("turns",{})

    def _set_turn_host_context(self, turn_id, context):
        if not isinstance(turn_id,str) or not turn_id.strip():
            raise ValueError("turn_id must be nonempty text")
        if not isinstance(context,dict):
            raise ValueError("turn host context must be an object")
        path=self._host_context_path(); path.parent.mkdir(parents=True,exist_ok=True)
        turns=self._load_host_contexts(); turns[turn_id]=deepcopy(context)
        tmp=path.with_suffix(path.suffix+".tmp")
        tmp.write_text(json.dumps({"version":1,"turns":turns},ensure_ascii=False,sort_keys=True,indent=2,default=str)+"\n",encoding="utf-8")
        tmp.replace(path)
        return deepcopy(turns[turn_id])

    def turn_host_context(self, turn_id):
        if not isinstance(turn_id,str) or not turn_id:
            return {}
        return deepcopy(self._load_host_contexts().get(turn_id,{}) or {})

    def _decorate_view(self, view):
        """Expose the durable-memory event contract to actual host semantic work."""
        policy = {
            "purpose": "emit durable state transitions, not transcript summaries",
            "result_control_field": "memory_events",
            "schema": {
                "kind": "decision|project_state|user_preference|blocker|capability_transition|component_promotion|self_maintenance|open_question|world_state|transient",
                "key": "stable semantic key",
                "value": "JSON-compatible current state",
                "scope": "optional session|project|user|global_reusable|executable",
                "durable": "optional boolean override",
            },
            "rule": "memory_events represent durable state changes; ordinary transcript text stays in conversation context.",
            "executable_learning_control_field": "component_candidates",
            "executable_learning_rule": "A successful task may emit a component_candidates item when it yields a deterministic reusable function with source, task_description and a real probe payload.",
        }
        def decorate(work):
            if getattr(work, "executor", None) != "host_semantic":
                return work
            context = deepcopy(getattr(work, "context", {}) or {})
            context["operating_foundation_memory_policy"] = deepcopy(policy)
            host_context=self.turn_host_context(getattr(work,"turn_id",getattr(view,"turn_id","")))
            if host_context:
                context["operating_foundation_execution_context"] = host_context
            return replace(work, context=context)
        next_work = tuple(decorate(w) for w in view.next_work)
        pending_work = tuple(decorate(w) for w in view.pending_work)
        return replace(view, next_work=next_work, pending_work=pending_work)

    def _decorate_ticket(self, ticket):
        return replace(ticket, view=self._decorate_view(ticket.view))

    def verify_ingress_receipt(self, foundation_receipt_id: str, *, message: str | None = None, turn_id: str | None = None):
        """Fail closed unless a durable admitted receipt proves this turn entered JIGAEWOL.

        This is intentionally stronger than a policy statement. It verifies the
        persisted Foundation receipt and, when supplied, binds it back to the
        exact user message and turn id.
        """
        row = self.ingress_ledger.get(foundation_receipt_id)
        if row is None:
            raise RuntimeError("JIGAEWOL ingress receipt not found")
        if row.get("status") != "admitted":
            raise RuntimeError(f"JIGAEWOL ingress receipt is not admitted: {row.get('status')}")
        if not row.get("core_receipt_id") or not row.get("turn_id"):
            raise RuntimeError("JIGAEWOL ingress receipt lacks core PerTurnGate evidence")
        if message is not None:
            digest = hashlib.sha256(message.encode("utf-8")).hexdigest()
            if row.get("message_sha256") != digest:
                raise RuntimeError("JIGAEWOL ingress receipt message hash mismatch")
        if turn_id is not None and row.get("turn_id") != turn_id:
            raise RuntimeError("JIGAEWOL ingress receipt turn id mismatch")
        core = self.gate.receipt(row["core_receipt_id"])
        if core is None or core.get("status") != "admitted":
            raise RuntimeError("core PerTurnGate receipt is missing or not admitted")
        if core.get("turn_id") != row.get("turn_id"):
            raise RuntimeError("foundation/core ingress turn id mismatch")
        return row

    def _augment_internal_capabilities(self, capabilities):
        rows=list(capabilities or ())
        ids=set()
        for row in rows:
            if isinstance(row, dict):
                cid=row.get("id", row.get("capability_id"))
            else:
                cid=getattr(row,"capability_id",None)
            if isinstance(cid,str): ids.add(cid)
        if LOCAL_TERMINAL_CAPABILITY_ID not in ids:
            rows.append(local_terminal_capability_spec())
        return tuple(rows)

    def internal_tool_handlers(self):
        return {LOCAL_TERMINAL_CAPABILITY_ID: self.local_terminal.action_handler}

    def ensure_local_terminal(self):
        ping=self.local_terminal.start()
        handle=self.local_terminal.handle(origin_ref="jigaewol-local-terminal:ensure")
        observed=self.observe_host_execution({
            "output":ping, "origin_ref":"jigaewol-local-terminal:ensure",
            "execution_handles":[handle],
        })
        return {"capability":local_terminal_capability_spec(), "observation":observed, "ping":ping}

    def ingress(self, message: str, *, capabilities=None, attachments=(), **kwargs):
        if not isinstance(message, str) or not message.strip():
            raise ValueError("message must be nonempty text")
        prior_session_receipts = self.ingress_ledger.recent(session_id=self.namespace.session_id)
        session_first_turn = not prior_session_receipts
        rid = self.ingress_ledger.received(self.namespace, message)
        caps = self.driver.capability_snapshot() if capabilities is None else capabilities
        caps = self._augment_internal_capabilities(caps)
        path_kind = "full"
        try:
            if "mode" not in kwargs and "intents" not in kwargs and is_trivial_exact(message, attachments=attachments):
                path_kind = "trivial_exact"
                kwargs["mode"] = "direct"
                kwargs["intents"] = [IntentProposal(
                    message.strip(), (SourceSpan(0, len(message)),), 5, True, "trivial_exact:acknowledgement"
                )]
            ticket = self.gate.enter(message, capabilities=caps, attachments=attachments, **kwargs)
            foundation_receipt = self.ingress_ledger.admitted(rid, ticket, path_kind)
            surface_event = self.capability_surface.observe(caps, rebound=ticket.capabilities_rebound, receipt_id=rid)
            reconciled_acquisitions = self.driver.acquisitions.reconcile_callable_surface(
                caps, evidence_ref="foundation_ingress:" + rid
            )
            semantic_authority = dict(kwargs.get("semantic_authority") or {})
            route_objective = source_bound_objective(message, semantic_authority) if semantic_authority else str(message)
            authority_traits = tuple(
                str(x) for x in (semantic_authority.get("required_capability_traits") or ()) if str(x)
            )
            routing_trait_hints = tuple(sorted(set(infer_required_traits(route_objective)) | set(authority_traits)))
            effect_authorized = source_effect_authorized(semantic_authority)
            # Trait inference can rank/discover routes, but it cannot itself declare
            # that execution is required.  Only exact-source effect authority may
            # populate the required trait set used by the execution fabric.
            required_traits = routing_trait_hints if effect_authorized else ()
            execution_route = compose_execution_routes(
                route_objective, caps, required_traits=required_traits,
            )
            execution_route["routing_trait_hints"] = list(routing_trait_hints)
            execution_route["source_effect_authorized"] = bool(effect_authorized)
            workstation = virtual_workstation_plan(caps)
            workstation["execution_state"] = {
                "handles": list(self.execution_state.snapshot()),
                "usable_handles": list(self.execution_state.usable()),
                "reprobe_plan": list(self.execution_state.reprobe_plan()),
                "truth_rule": "a current provider probe establishes liveness; a stored handle supplies the locator",
            }
            execution_fabric_plan = build_execution_fabric_plan(
                route_objective, caps, execution_handles=self.execution_state.snapshot()
            )
            action_surface = action_surface_snapshot(caps)
            terminal_status = terminal_backplane_status(caps, self.execution_state.snapshot())
            discovery_actions = ()
            if effect_authorized and path_kind != "trivial_exact" and execution_route.get("missing_traits"):
                discovery_need = trait_discovery_query(execution_route.get("missing_traits"))
                discovery_actions = self.acquisition.plan_discovery(discovery_need)
            host_contract = {
                "user_directive_is_destination_authority": True,
                "exact_user_wording_is_source_truth": True,
                "user_goal_remains_canonical_through_internal_planning": True,
                "internal_labels_are_descriptive_context": True,
                "runtime_footer_default": False,
                "chat_is_runtime_entry_surface": True,
                "every_canonical_user_turn_requires_fresh_ingress": True,
                "ingress_receipt_precedes_jigaewol_task_execution": True,
                "current_turn_receipt_is_turn_specific": True,
                "task_execution_requires_current_ingress_receipt": True,
                "project_scope_context": self.namespace.project_id,
                "project_scope_changes_follow_user_directive": True,
                "workspace_contract": {
                    "default_mode": "follow_current_user_directive",
                    "user_directed_structure_changes_supported": True,
                    "workspace_mode_follows_user_and_observed_provider_state": True,
                    "provider_requirements_are_observed_at_execution_time": True,
                },
                "execution_state_may_live_in_connected_components": True,
                "action_level_dispatch_required": bool(effect_authorized),
                "provider_actions_come_from_observed_surface": True,
                "derived_route_traits_are_advisory": True,
                "host_effect_requires_exact_source_authority": True,
                "source_effect_authorized": bool(effect_authorized),
                "startup_sequence": (
                    "per_turn_ingress",
                    "bind_current_callable_surface",
                    "reprobe_persistent_execution_handles_before_reuse",
                    "execute_user_task_through_best_available_or_composed_route",
                ),
                "capability_expansion": {
                    "trigger": "missing_required_execution_traits_or_materially_better_route",
                    "search_order": ("current_host", "plugin_directory", "skills", "github_open_source", "web_developer_sources"),
                    "callable_state_requires_current_probe": True,
                    "execution_state_requires_observed_run": True,
                    "route_failure_keeps_goal_live": True,
                    "destination_coverage_precedes_route_convenience": True,
                    "broad_capability_horizon": True,
                    "lazy_activation_over_shortlisting": True,
                    "user_requested_scope_is_preserved": True,
                    "candidate_discovery_may_be_broad_while_active_surface_stays_small": True,
                    "provider_requirements_come_from_observation": True,
                    "execution_state_comes_from_observed_run": True,
                    "actual_execution_requires_observed_callable_body": True,
                    "candidate_route_failure_keeps_goal_live": True,
                },
                "capability_policy": {
                    "default_cost_policy": "cost_agnostic",
                    "user_cost_constraints_override": True,
                    "destination_coverage_before_convenience": True,
                    "provider_or_platform_requirements_are_reported_as_observed_state": True,
                },
            }
            self._set_turn_host_context(ticket.turn_id, {
                "host_contract": host_contract,
                "execution_fabric_plan": execution_fabric_plan,
                "execution_route_composition": execution_route,
                "virtual_workstation": workstation,
                "action_surface": list(action_surface),
                "terminal_backplane": terminal_status,
                "capability_discovery_actions": list(discovery_actions),
                "truth_boundary": "foundation planning context; HOST observations establish actual tool execution",
            })
            ticket = self._decorate_ticket(ticket)
            return {
                "foundation_receipt": foundation_receipt,
                "core_ticket": ticket,
                "capability_surface_event": surface_event,
                "capability_acquisition_reconciliation": reconciled_acquisitions,
                "execution_route_composition": execution_route,
                "execution_fabric_plan": execution_fabric_plan,
                "virtual_workstation": workstation,
                "action_surface": action_surface,
                "terminal_backplane": terminal_status,
                "capability_discovery_actions": discovery_actions,
                "host_contract": host_contract,
                "path_kind": path_kind,
            }
        except Exception as exc:
            self.ingress_ledger.failed(rid, exc)
            raise

    def observe_host_execution(self, result):
        """Persist real out-of-band HOST execution state without claiming task completion.

        Use this for cockpit/bootstrap operations (for example attaching a
        persistent terminal workspace) that were actually executed by HOST but
        were not the pending cognition work item.  The result must use the same
        capability envelope fields as a normal tool submission.
        """
        if not isinstance(result, dict) or "output" not in result:
            raise ValueError("host execution observation requires an output-bearing envelope")
        origin_ref = result.get("origin_ref")
        if not isinstance(origin_ref, str) or not origin_ref.strip():
            raise ValueError("host execution observation requires origin_ref")
        handles = normalize_execution_handles(result.get("execution_handles", ()), default_origin_ref=origin_ref)
        probes = normalize_execution_probes(result.get("execution_probes", ()), default_origin_ref=origin_ref)
        rows=[]
        for item in handles:
            observed=item.get("observed_alive")
            if observed is None:
                row=self.execution_state.register(
                    kind=item["kind"],provider=item["provider"],handle_id=item["handle_id"],
                    origin_ref=item["origin_ref"],metadata=item.get("metadata") or {},
                )
            else:
                row=self.execution_state.observe(
                    kind=item["kind"],provider=item["provider"],handle_id=item["handle_id"],
                    origin_ref=item["origin_ref"],metadata=item.get("metadata") or {},alive=observed,
                )
            rows.append(row)
        probe_rows=[self.execution_state.probe_descriptor(item) for item in probes]
        return {
            "origin_ref":origin_ref.strip(),
            "execution_handles":tuple(rows),
            "execution_probes":tuple(probe_rows),
            "truth_boundary":"external execution observed; no cognition work is marked complete by this method",
        }

    def submit(self, work, result):
        """Submit actual host work and atomically apply declared durable memory events.

        `memory_events` is an Operating Foundation control field, not answer
        material. It is stripped before the result crosses into the 10.1.x
        cognition engine, then each event is evaluated by MemoryWritePolicy.
        This keeps transcript prose separate from durable world state.
        """
        core_result = deepcopy(result)
        events = ()
        component_candidates = ()
        execution_handles = ()
        execution_probes = ()
        if isinstance(core_result, dict) and "memory_events" in core_result:
            raw_events = core_result.pop("memory_events")
            if isinstance(raw_events, dict):
                raw_events = [raw_events]
            if isinstance(raw_events, (str, bytes)) or not isinstance(raw_events, (list, tuple)):
                raise ValueError("memory_events must be an object or list of objects")
            if any(not isinstance(event, dict) for event in raw_events):
                raise ValueError("memory_events must contain objects")
            events = tuple(deepcopy(raw_events))
        if isinstance(core_result, dict) and "execution_handles" in core_result:
            raw_handles = core_result.pop("execution_handles")
            default_origin = core_result.get("origin_ref") if isinstance(core_result, dict) else None
            execution_handles = normalize_execution_handles(raw_handles, default_origin_ref=default_origin)
        if isinstance(core_result, dict) and "execution_probes" in core_result:
            raw_probes = core_result.pop("execution_probes")
            default_origin = core_result.get("origin_ref") if isinstance(core_result, dict) else None
            execution_probes = normalize_execution_probes(raw_probes, default_origin_ref=default_origin)
        if isinstance(core_result, dict) and "component_candidates" in core_result:
            raw_components = core_result.pop("component_candidates", ())
            if isinstance(raw_components, dict):
                raw_components = [raw_components]
            if isinstance(raw_components, (str, bytes)) or not isinstance(raw_components, (list, tuple)):
                raise ValueError("component_candidates must be an object or list of objects")
            if any(not isinstance(item, dict) for item in raw_components):
                raise ValueError("component_candidates must contain objects")
            component_candidates = tuple(deepcopy(raw_components))
        view = self._decorate_view(self.driver.submit(work, core_result))
        writes = tuple(self.checkpoint(event, turn_id=work.turn_id) for event in events)
        learned=[]
        for item in component_candidates:
            learned.append(self.components.learn_from_success(
                component_id=item.get("component_id"), source=item["source"], task_description=item["task_description"],
                probe_payload=item["probe_payload"], expected_output=item.get("expected_output"),
                provenance=item.get("provenance") or {"turn_id":work.turn_id},
                dependencies=item.get("dependencies", ()), permissions=item.get("permissions", ()),
                license=item.get("license", "internal-generated"),
            ))
        registered_handles=[]
        for item in execution_handles:
            observed = item.get("observed_alive")
            if observed is None:
                row = self.execution_state.register(
                    kind=item["kind"], provider=item["provider"], handle_id=item["handle_id"],
                    origin_ref=item["origin_ref"], metadata=item.get("metadata") or {},
                )
            else:
                row = self.execution_state.observe(
                    kind=item["kind"], provider=item["provider"], handle_id=item["handle_id"],
                    origin_ref=item["origin_ref"], metadata=item.get("metadata") or {}, alive=observed,
                )
            registered_handles.append(row)
        probe_updates=[]
        for probe in execution_probes:
            probe_updates.append(self.execution_state.probe_descriptor(probe))
        return {"view": view, "memory_writes": writes, "component_learning": tuple(learned),
                "execution_handles": tuple(registered_handles), "execution_probes": tuple(probe_updates)}

    def fail(self, work, error):
        return self._decorate_view(self.driver.fail(work, error))

    def resume(self, turn_id):
        return self._decorate_view(self.driver.resume(turn_id))

    def portable_project_snapshot(self):
        snapshot = self.memory.project_snapshot()
        snapshot["component_bundles"] = list(self.components.export_integrated_bundles())
        snapshot["execution_handles"] = list(self.execution_state.snapshot())
        return snapshot

    def _lineage_path(self, scope: str):
        if scope == "project":
            return self.layout.project_memory_dir / "external_lineage.json"
        if scope in {"user", "global_reusable"}:
            return self.layout.user_memory_dir / f"external_lineage_{scope}.json"
        raise ValueError("scope has no external lineage")

    def _lineage_head(self, scope: str):
        path=self._lineage_path(scope)
        if not path.exists(): return None
        data=json.loads(path.read_text(encoding="utf-8"))
        return data.get("head_revision_id")

    def _set_lineage_head(self, scope: str, revision_id: str, *, page_id=None):
        path=self._lineage_path(scope); path.parent.mkdir(parents=True,exist_ok=True)
        data={"scope":scope,"stream_key":self.namespace.stream_key(scope),"head_revision_id":revision_id,
              "page_id":page_id,"updated_at":datetime.now(timezone.utc).isoformat()}
        tmp=path.with_suffix(path.suffix+".tmp")
        tmp.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8"); tmp.replace(path)
        return data

    def encode_external_snapshot(self, scope: str, *, continuation=None, release_version="2.1.0"):
        if scope == "project":
            snapshot=self.portable_project_snapshot()
        elif scope in {"user","global_reusable"}:
            snapshot=self.memory.scope_snapshot(scope)
        else:
            raise ValueError("scope has no external snapshot")
        return NotionMemoryCodec.encode(
            snapshot, release_version=release_version, continuation=continuation or {}, scope=scope,
            stream_key=self.namespace.stream_key(scope), parent_revision_id=self._lineage_head(scope),
        )

    def checkpoint(self, event: dict, *, turn_id: str | None = None, release_version="2.1.0"):
        provenance = {
            "kind": "automatic_memory_policy", "turn_id": turn_id,
            "session_id": self.namespace.session_id, "project_id": self.namespace.project_id,
        }
        result = self.memory.checkpoint(event, provenance=provenance)
        scope=result.get("scope")
        external_scope="project" if scope == "executable" else scope
        if result.get("write") and result.get("changed") and external_scope in {"project","user","global_reusable"}:
            content=self.encode_external_snapshot(external_scope, continuation={"latest_turn_id":turn_id}, release_version=release_version)
            env=NotionMemoryCodec.decode(content); lin=env["lineage"]
            result["external_memory_action"] = asdict(self.notion_streams[external_scope].checkpoint_action(
                content, revision_id=lin["revision_id"], parent_revision_id=lin.get("parent_revision_id")
            ))
        else:
            result["external_memory_action"] = None
        return result

    def acknowledge_external_checkpoint(self, *, scope: str, revision_id: str, notion_page_id: str | None = None):
        return self._set_lineage_head(scope, revision_id, page_id=notion_page_id)

    def external_page_id(self):
        # Legacy 10.2.0 binding only. 10.2.1 writes immutable checkpoint pages.
        meta = self.layout.project_dir / "external_memory.json"
        if not meta.exists(): return None
        return json.loads(meta.read_text(encoding="utf-8")).get("notion_page_id")

    def bind_external_page(self, *, notion_page_id: str, notion_url: str | None = None):
        payload = {"notion_page_id": notion_page_id, "notion_url": notion_url, "stable_key": self.namespace.stable_key,
                   "binding_mode":"explicit"}
        path = self.layout.project_dir / "external_memory.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        return payload

    def recover_external_candidates(self, texts, *, scope: str, source_ref: str):
        if isinstance(texts, str): texts=[texts]
        if not isinstance(texts,(list,tuple)) or not texts:
            raise ValueError("texts must contain at least one fetched external snapshot")
        stream_key=self.namespace.stream_key(scope)
        revisions={}
        for text in texts:
            env=NotionMemoryCodec.decode(text); lin=env.get("lineage") or {}
            if lin.get("scope") != scope or lin.get("stream_key") != stream_key:
                continue
            revisions[lin["revision_id"]]=env
        if not revisions:
            raise ValueError("no external snapshot matches requested stream")
        parented={env["lineage"].get("parent_revision_id") for env in revisions.values() if env["lineage"].get("parent_revision_id") in revisions}
        heads=sorted(set(revisions)-parented)
        if len(heads) != 1:
            raise ExternalMemoryConflict("external memory has divergent concurrent heads; refusing last-writer-wins recovery", head_revision_ids=heads)
        head=heads[0]; env=revisions[head]
        imported=self.memory.import_external_snapshot(env["snapshot"],source_ref=source_ref,scope=scope,expected_stream_key=stream_key)
        imported_components=[]
        imported_execution_handles=[]
        if scope == "project":
            for bundle in (env["snapshot"].get("component_bundles") or ()):
                imported_components.append(self.components.import_bundle(bundle)["versioned_id"])
            imported_execution_handles.extend(self.execution_state.import_handles(
                env["snapshot"].get("execution_handles") or (), source_ref=source_ref
            ))
        self._set_lineage_head(scope,head)
        return {"head_revision_id":head,"imported_memory_ids":imported,"imported_components":tuple(imported_components),
                "imported_execution_handles":tuple(imported_execution_handles),
                "continuation":env.get("continuation") or {},"release_version":env.get("release_version")}

    def recover_from_notion_text(self, text: str, *, source_ref: str):
        return self.recover_external_candidates([text],scope="project",source_ref=source_ref)

    def reuse_component(self, task_description: str, payload):
        result=self.components.reuse_for_task(task_description,payload)
        if result and result["manifest"].get("integrated"):
            self.memory.write(scope="executable",key=result["versioned_id"],
                              value={"sha256":result["manifest"]["sha256"],"integration_scope":result["manifest"].get("integration_scope")},
                              provenance={"kind":"component_reuse","task_description":task_description})
        return result

    def resolve_capability_need(self, need: str):
        component=self.components.recommend(need,include_unintegrated=False)
        if component is not None:
            return {"status":"reusable_component_available","need":need,"component_id":component["versioned_id"],"score":component["score"],
                    "route_basis":"integrated_executable_component"}
        connected=assess_capability_need(need,self.driver.capability_snapshot())
        if connected["status"] == "satisfied": return connected
        return {**connected,"discovery_actions":self.acquisition.plan_discovery(need)}

    def self_maintenance_controller(self, stable_root, *, parent_version="2.1.0"):
        ledger=SelfMaintenanceLedger(self.layout.user_dir / "self_maintenance_lineage.json")
        return SelfMaintenanceController(stable_root=stable_root,releases_root=self.layout.release_dir,
                                         ledger=ledger,parent_version=parent_version)

    def bootstrap(self, *, ensure_external_recovery=True):
        if not isinstance(ensure_external_recovery, bool):
            raise ValueError("ensure_external_recovery must be boolean")
        if ensure_external_recovery:
            for scope, connector in self.notion_streams.items():
                if self._lineage_head(scope) is None:
                    connector.bootstrap_search(operation="search" if scope == "project" else "search_scoped_checkpoints")
        return {
            "namespace": {"user_id":self.namespace.user_id,"project_id":self.namespace.project_id,
                          "session_id":self.namespace.session_id,"stable_key":self.namespace.stable_key,
                          "user_stable_key":self.namespace.user_stable_key,"global_stable_key":self.namespace.global_stable_key},
            "memory": self.memory.snapshot(),
            "external_lineage": {scope:self._lineage_head(scope) for scope in ("project","user","global_reusable")},
            "latest_resumable_turn_id": self.driver.runtime.latest_resumable_turn_id(),
            "capability_surface": self.capability_surface.snapshot().get("current"),
            "pending_external_actions": list(self.external_queue.pending()),
            "components": self.components.snapshot(),
            "recent_ingress": list(self.ingress_ledger.recent(session_id=self.namespace.session_id)[:10]),
            "strict_per_turn_ingress": {
                "required": True,
                "ordinary_chat_entrypoint": "OperatingFoundation.ingress",
                "portable_command": "tools/jigaewol_gateway.py",
                "trivial_decision_after_ingress": True,
                "current_user_message_starts_each_canonical_turn": True,
                "current_ingress_receipt_required": True,
                "fresh_receipt_required_for_each_canonical_user_turn": True,
                "current_turn_receipt_is_unique_to_turn": True,
                "task_work_starts_after_current_ingress": True,
                "task_execution_requires_current_ingress_receipt": True,
            },
        }
