"""Foundation package with lazy public exports.

Public names are loaded lazily so the package does not import every subsystem eagerly.  Names remain
available, but modules are loaded only when a caller asks for the corresponding
component.
"""
from importlib import import_module

__version__ = "2.1.0"

_EXPORTS = {
    "Namespace": ("namespace", "Namespace"), "NamespaceLayout": ("namespace", "NamespaceLayout"),
    "MemoryFabric": ("memory", "MemoryFabric"), "MemoryWritePolicy": ("memory", "MemoryWritePolicy"), "MemoryRecord": ("memory", "MemoryRecord"),
    "ExternalActionQueue": ("external_memory", "ExternalActionQueue"), "ExternalMemoryAction": ("external_memory", "ExternalMemoryAction"),
    "ExternalMemoryConflict": ("external_memory", "ExternalMemoryConflict"), "NotionMemoryCodec": ("external_memory", "NotionMemoryCodec"),
    "NotionProjectMemory": ("external_memory", "NotionProjectMemory"), "NotionScopedMemory": ("external_memory", "NotionScopedMemory"),
    "CapabilitySurfaceLedger": ("capability_surface", "CapabilitySurfaceLedger"),
    "ComponentRegistry": ("components", "ComponentRegistry"),
    "OperatingFoundation": ("runtime", "OperatingFoundation"), "is_trivial_exact": ("runtime", "is_trivial_exact"),
    "SelfMaintenanceLedger": ("self_maintenance", "SelfMaintenanceLedger"), "SelfMaintenanceWorkspace": ("self_maintenance", "SelfMaintenanceWorkspace"),
    "SelfMaintenanceController": ("self_maintenance", "SelfMaintenanceController"),
    "CapabilityAcquisitionCoordinator": ("acquisition", "CapabilityAcquisitionCoordinator"),
}

__all__ = list(_EXPORTS)


def __getattr__(name: str):
    spec = _EXPORTS.get(name)
    if spec is None:
        raise AttributeError(name)
    module_name, symbol = spec
    value = getattr(import_module(f"{__name__}.{module_name}"), symbol)
    globals()[name] = value
    return value
