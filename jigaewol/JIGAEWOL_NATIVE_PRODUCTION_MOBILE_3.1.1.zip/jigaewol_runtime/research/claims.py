from dataclasses import dataclass


@dataclass(frozen=True)
class Claim:
    text: str
    confidence: float | None = None
    evidence_refs: tuple[str, ...] = ()
    contradiction_refs: tuple[str, ...] = ()
