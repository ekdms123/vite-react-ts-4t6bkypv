from dataclasses import dataclass, replace
import math
import re


@dataclass(frozen=True)
class ResearchFrontier:
    claim_nodes: tuple[str, ...] = ()
    uncertainty_nodes: tuple[str, ...] = ()
    contradiction_nodes: tuple[str, ...] = ()
    pending_questions: tuple[str, ...] = ()
    source_classes_seen: tuple[str, ...] = ()
    language_regions_seen: tuple[str, ...] = ()
    expected_information_gain: float | None = None
    salient_terms: tuple[str, ...] = ()
    asked_queries: tuple[str, ...] = ()
    pending_discoveries: tuple[str, ...] = ()
    discovery_refs: tuple[str, ...] = ()


def apply_evidence(frontier, claims):
    if not isinstance(frontier, ResearchFrontier):
        raise ValueError("frontier must be a ResearchFrontier")
    claims = tuple(claims)
    if any(not hasattr(c, "text") or not isinstance(c.text, str) or not c.text.strip() for c in claims):
        raise ValueError("research claims must contain nonempty text")
    for c in claims:
        if c.confidence is not None:
            if isinstance(c.confidence, bool) or not isinstance(c.confidence, (int, float)) or not math.isfinite(float(c.confidence)) or not 0 <= float(c.confidence) <= 1:
                raise ValueError("research claim confidence must be finite between 0 and 1 or unknown")
        for field in (c.evidence_refs, c.contradiction_refs):
            if not isinstance(field, tuple) or any(not isinstance(ref, str) or not ref.strip() for ref in field):
                raise ValueError("research claim refs must be tuples of nonempty text ids")
    texts = tuple(c.text.strip() for c in claims)
    seen = {t.casefold().strip() for t in frontier.claim_nodes}
    discoveries = tuple(c.text.strip() for c in claims if c.evidence_refs and c.text.casefold().strip() not in seen)
    refs = tuple(ref for c in claims if c.text.strip() in discoveries for ref in c.evidence_refs)
    terms = list(frontier.salient_terms)
    for text in discoveries:
        terms.extend(t for t in re.findall(r"\w+", text.casefold()) if len(t) >= 3)
    contradictions = tuple(ref for c in claims for ref in c.contradiction_refs)
    return replace(frontier,
        claim_nodes=tuple(dict.fromkeys(frontier.claim_nodes + texts)),
        contradiction_nodes=tuple(dict.fromkeys(frontier.contradiction_nodes + contradictions)),
        salient_terms=tuple(dict.fromkeys(terms)),
        pending_discoveries=tuple(dict.fromkeys(frontier.pending_discoveries + discoveries)),
        discovery_refs=tuple(dict.fromkeys(frontier.discovery_refs + refs)))

