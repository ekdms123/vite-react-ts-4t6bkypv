from __future__ import annotations

"""Research-branch routing over capabilities the HOST actually exposed.

Selection policy lives in ``capabilities.routing`` so ordinary capability
selection and research routing cannot drift into two incompatible ontologies.
This adapter adds branch metadata and deterministic provider rotation.
"""

from copy import deepcopy

from jigaewol_runtime.capabilities.routing import select_branch_capability
from jigaewol_runtime.capabilities.manifest import canonical_role


def route_search_branches(branches, capability_specs):
    """Bind each research branch to one connected observation capability.

    Exact requested capability wins. Otherwise branch role/source culture/
    mechanism is used to infer the observation surface, and equivalent
    providers are rotated across sibling branches. An unavailable preferred
    provider only redirects that branch; it never closes the research goal.
    """
    specs = [deepcopy(x) for x in (capability_specs or ())
             if isinstance(x, dict) and str(x.get("id", x.get("capability_id", ""))).strip()]
    if not specs:
        raise ValueError("research routing requires at least one connected capability")

    routed = []
    for offset, raw in enumerate(branches or ()):
        branch = deepcopy(raw)
        chosen, basis = select_branch_capability(branch, specs, offset=offset)
        cid = str(chosen.get("id", chosen.get("capability_id", ""))).strip()
        branch["capability_id"] = cid
        branch["capability_role"] = canonical_role(cid, chosen.get("role")) or ""
        branch["route_basis"] = basis
        branch["provider"] = str(chosen.get("provider", "") or "")
        branch["plugin"] = str(chosen.get("plugin", "") or "")
        routed.append(branch)
    return routed
