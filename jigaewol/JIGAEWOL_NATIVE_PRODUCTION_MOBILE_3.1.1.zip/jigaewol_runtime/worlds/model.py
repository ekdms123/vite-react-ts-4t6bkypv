from dataclasses import dataclass, field


@dataclass(frozen=True)
class WorldModel:
    world_id: str
    problem_unit: str
    causal_model: str
    actors_resources_information_time: dict[str, object]
    assumptions: tuple[str, ...]
    predicted_observations: tuple[str, ...]
    discriminating_questions: tuple[str, ...]
    mechanism_family: str
    expected_material_effects: tuple[str, ...]
    evidence_for: tuple[str, ...]
    evidence_against: tuple[str, ...]
    status: str
    representation: dict[str, object] = field(default_factory=dict)
