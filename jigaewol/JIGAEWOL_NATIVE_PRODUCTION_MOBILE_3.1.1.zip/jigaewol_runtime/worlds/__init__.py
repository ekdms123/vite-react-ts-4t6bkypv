"""Competing causal/problem worlds."""
