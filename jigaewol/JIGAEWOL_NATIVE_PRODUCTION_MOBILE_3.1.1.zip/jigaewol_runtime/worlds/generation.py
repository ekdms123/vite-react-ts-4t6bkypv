from __future__ import annotations

"""Executable problem-representation generation.

This module is deliberately more than a proposal container.  It can transform a
structured problem frame without asking the host model to invent the alternate
frames first.  Host semantics are still used later to *realize* each generated
frame, but the divergence topology, counterfactual interventions, cross-domain
role transfer, novelty pressure and branch isolation are runtime mechanisms.

The built-in operators are seeds rather than an ontology ceiling.  Additional
``FrameRevisionSpec`` and ``MechanismPattern`` values can be supplied at runtime
and are executed by the same validators.
"""

from copy import deepcopy
from dataclasses import asdict, dataclass, field, replace
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json

import os

from jigaewol_runtime.kernel.ids import new_id
from .model import WorldModel


@dataclass(frozen=True)
class WorldProposal:
    problem_unit: str = ""
    causal_model: str = ""
    mechanism_family: str = ""
    assumptions: tuple[str, ...] = ()
    predicted_observations: tuple[str, ...] = ()
    discriminating_questions: tuple[str, ...] = ()
    expected_material_effects: tuple[str, ...] = ()
    representation: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class ProblemFrame:
    objective: str
    problem_unit: str
    boundary: str = "current task boundary"
    assumptions: tuple[str, ...] = ()
    constraints: tuple[str, ...] = ()
    actors: tuple[str, ...] = ()
    resources: tuple[str, ...] = ()
    information: tuple[str, ...] = ()
    time_horizon: str = "current decision horizon"
    causal_links: tuple[tuple[str, str, str], ...] = ()
    facets: dict[str, object] = field(default_factory=dict)

    @classmethod
    def from_value(cls, value, *, objective: str = "") -> "ProblemFrame":
        if isinstance(value, cls):
            return value
        data = dict(value or {}) if isinstance(value, dict) else {}
        obj = str(data.get("objective") or objective or data.get("goal") or "").strip()
        unit = str(data.get("problem_unit") or data.get("problem") or data.get("working_decision") or obj or "current problem").strip()
        boundary = str(data.get("boundary") or data.get("system_boundary") or "current task boundary").strip()

        def texts(name):
            raw = data.get(name, ())
            if isinstance(raw, str):
                raw = (raw,)
            if not isinstance(raw, (list, tuple, set)):
                return ()
            return tuple(str(x).strip() for x in raw if isinstance(x, (str, int, float)) and str(x).strip())

        raw_links = data.get("causal_links", data.get("causal_edges", ())) or ()
        links = []
        if isinstance(raw_links, (list, tuple)):
            for row in raw_links:
                if isinstance(row, dict):
                    src, rel, dst = row.get("source"), row.get("relation"), row.get("target")
                elif isinstance(row, (list, tuple)) and len(row) == 3:
                    src, rel, dst = row
                else:
                    continue
                triple = tuple(str(x).strip() for x in (src, rel, dst))
                if all(triple):
                    links.append(triple)
        known = {
            "objective", "goal", "problem_unit", "problem", "working_decision", "boundary", "system_boundary",
            "assumptions", "constraints", "actors", "resources", "information", "time_horizon", "causal_links", "causal_edges", "facets",
        }
        facets = deepcopy(data.get("facets", {})) if isinstance(data.get("facets"), dict) else {}
        facets.update({k: deepcopy(v) for k, v in data.items() if k not in known})
        return cls(
            objective=obj,
            problem_unit=unit,
            boundary=boundary,
            assumptions=texts("assumptions"),
            constraints=texts("constraints"),
            actors=texts("actors"),
            resources=texts("resources"),
            information=texts("information"),
            time_horizon=str(data.get("time_horizon") or "current decision horizon").strip(),
            causal_links=tuple(links),
            facets=facets,
        )


@dataclass(frozen=True)
class FrameRevisionSpec:
    operator_id: str
    family: str
    transformation_claim: str
    operations: tuple[dict[str, object], ...]


@dataclass(frozen=True)
class MechanismPattern:
    pattern_id: str
    source_domain: str
    mechanism: str
    roles: tuple[str, ...]
    relations: tuple[tuple[str, str, str], ...] = ()
    target_hints: dict[str, tuple[str, ...]] = field(default_factory=dict)
    break_conditions: tuple[str, ...] = ()


@dataclass(frozen=True)
class _GeneratedFrame:
    frame: ProblemFrame
    operator_chain: tuple[str, ...]
    claims: tuple[str, ...]
    questions: tuple[str, ...] = ()
    counterfactuals: tuple[str, ...] = ()
    mechanism_family: str = "representation_revision"
    source_pattern: str = ""
    mechanism_transfer: dict[str, object] = field(default_factory=dict)


def _validate_proposal(p: WorldProposal) -> None:
    if not isinstance(p, WorldProposal):
        raise ValueError("world proposals must be WorldProposal values")
    for label in ("problem_unit", "causal_model", "mechanism_family"):
        if not isinstance(getattr(p, label), str):
            raise ValueError(label + " must be text")
    for label in ("assumptions", "predicted_observations", "discriminating_questions", "expected_material_effects"):
        value = getattr(p, label)
        if not isinstance(value, (list, tuple)) or any(not isinstance(item, str) for item in value):
            raise ValueError(label + " must be a list of text values")
    if not isinstance(p.representation, dict):
        raise ValueError("world representation must be an object")


def _signature(p: WorldProposal) -> str:
    _validate_proposal(p)
    if p.representation:
        return json.dumps(p.representation, ensure_ascii=False, sort_keys=True, allow_nan=False, separators=(",", ":"))
    return json.dumps({
        "problem_unit": p.problem_unit,
        "causal_model": p.causal_model,
        "mechanism_family": p.mechanism_family,
        "assumptions": list(p.assumptions),
        "predicted_observations": list(p.predicted_observations),
        "discriminating_questions": list(p.discriminating_questions),
        "expected_material_effects": list(p.expected_material_effects),
    }, ensure_ascii=False, sort_keys=True, allow_nan=False, separators=(",", ":"))


def admit_worlds(proposals, contract=None) -> tuple[WorldModel, ...]:
    seen: set[str] = set()
    worlds = []
    for p in proposals:
        key = _signature(p)
        if key in seen:
            continue
        seen.add(key)
        worlds.append(WorldModel(
            world_id=new_id("world"), problem_unit=p.problem_unit, causal_model=p.causal_model,
            actors_resources_information_time={}, assumptions=tuple(p.assumptions),
            predicted_observations=tuple(p.predicted_observations),
            discriminating_questions=tuple(p.discriminating_questions), mechanism_family=p.mechanism_family,
            expected_material_effects=tuple(p.expected_material_effects), evidence_for=(), evidence_against=(),
            status="active", representation=deepcopy(p.representation),
        ))
    return tuple(worlds)


def _require_text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def revision_spec_from_value(value) -> FrameRevisionSpec:
    if isinstance(value, FrameRevisionSpec):
        return _validate_revision(value)
    if not isinstance(value, dict):
        raise ValueError("revision spec must be an object")
    operations = value.get("operations", ())
    if isinstance(operations, list):
        operations = tuple(deepcopy(operations))
    return _validate_revision(FrameRevisionSpec(
        operator_id=str(value.get("operator_id", "")),
        family=str(value.get("family", "custom")),
        transformation_claim=str(value.get("transformation_claim", "")),
        operations=operations if isinstance(operations, tuple) else (),
    ))


def mechanism_pattern_from_value(value) -> MechanismPattern:
    if isinstance(value, MechanismPattern):
        return value
    if not isinstance(value, dict):
        raise ValueError("mechanism pattern must be an object")
    roles = value.get("roles", ())
    relations = value.get("relations", ())
    hints = value.get("target_hints", {})
    if isinstance(roles, list):
        roles = tuple(str(x) for x in roles)
    if not isinstance(roles, tuple) or any(not isinstance(x, str) or not x.strip() for x in roles):
        raise ValueError("mechanism pattern roles must be nonempty text")
    clean_relations = []
    if isinstance(relations, (list, tuple)):
        for row in relations:
            if not isinstance(row, (list, tuple)) or len(row) != 3:
                raise ValueError("mechanism pattern relations must be triples")
            clean_relations.append(tuple(str(x).strip() for x in row))
    if not isinstance(hints, dict):
        raise ValueError("mechanism pattern target_hints must be an object")
    clean_hints = {}
    for role, fields in hints.items():
        if isinstance(fields, str):
            fields = (fields,)
        if not isinstance(fields, (list, tuple)):
            raise ValueError("target hint values must be text lists")
        clean_hints[str(role)] = tuple(str(x).strip() for x in fields if str(x).strip())
    breaks = value.get("break_conditions", ())
    if isinstance(breaks, str):
        breaks = (breaks,)
    if not isinstance(breaks, (list, tuple)):
        raise ValueError("break_conditions must be a text list")
    return MechanismPattern(
        pattern_id=_require_text(value.get("pattern_id"), "pattern_id"),
        source_domain=_require_text(value.get("source_domain"), "source_domain"),
        mechanism=_require_text(value.get("mechanism"), "mechanism"),
        roles=roles,
        relations=tuple(clean_relations),
        target_hints=clean_hints,
        break_conditions=tuple(str(x).strip() for x in breaks if str(x).strip()),
    )


def _validate_revision(spec: FrameRevisionSpec) -> FrameRevisionSpec:
    if not isinstance(spec, FrameRevisionSpec):
        raise ValueError("revision spec must be FrameRevisionSpec")
    _require_text(spec.operator_id, "operator_id")
    _require_text(spec.family, "family")
    _require_text(spec.transformation_claim, "transformation_claim")
    if not isinstance(spec.operations, tuple) or not spec.operations:
        raise ValueError("revision operations must be a nonempty tuple")
    allowed = {
        "set_focus", "set_problem_unit", "set_boundary", "set_time_horizon", "inject_question",
        "negate_assumption", "remove_constraint", "reverse_causal_links", "add_counterfactual",
    }
    for row in spec.operations:
        if not isinstance(row, dict) or row.get("op") not in allowed:
            raise ValueError("unsupported frame revision operation")
    return spec


def apply_revision_spec(frame: ProblemFrame, spec: FrameRevisionSpec) -> _GeneratedFrame:
    spec = _validate_revision(spec)
    current = ProblemFrame.from_value(frame)
    questions = []
    counterfactuals = []
    facets = deepcopy(current.facets)
    for row in spec.operations:
        op = row["op"]
        if op == "set_focus":
            facets["focus"] = _require_text(row.get("value"), "focus value")
            current = replace(current, facets=deepcopy(facets))
        elif op == "set_problem_unit":
            current = replace(current, problem_unit=_require_text(row.get("value"), "problem unit"))
        elif op == "set_boundary":
            current = replace(current, boundary=_require_text(row.get("value"), "boundary"))
        elif op == "set_time_horizon":
            current = replace(current, time_horizon=_require_text(row.get("value"), "time horizon"))
        elif op == "inject_question":
            questions.append(_require_text(row.get("value"), "question"))
        elif op == "add_counterfactual":
            counterfactuals.append(_require_text(row.get("value"), "counterfactual"))
        elif op == "negate_assumption":
            index = row.get("index")
            if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < len(current.assumptions):
                raise ValueError("negate_assumption index must address an assumption")
            assumptions = list(current.assumptions)
            original = assumptions[index]
            assumptions[index] = f"NOT({original})"
            counterfactuals.append(assumptions[index])
            current = replace(current, assumptions=tuple(assumptions))
        elif op == "remove_constraint":
            index = row.get("index")
            if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < len(current.constraints):
                raise ValueError("remove_constraint index must address a constraint")
            constraints = list(current.constraints)
            removed = constraints.pop(index)
            counterfactuals.append(f"constraint removed: {removed}")
            current = replace(current, constraints=tuple(constraints))
        elif op == "reverse_causal_links":
            current = replace(current, causal_links=tuple((dst, f"reverse_of:{rel}", src) for src, rel, dst in current.causal_links))
    return _GeneratedFrame(
        frame=current,
        operator_chain=(spec.operator_id,),
        claims=(spec.transformation_claim,),
        questions=tuple(questions),
        counterfactuals=tuple(counterfactuals),
    )


def _base_focus(frame: ProblemFrame):
    value = frame.facets.get("focus", "object") if isinstance(frame.facets, dict) else "object"
    return str(value or "object")


def _builtin_revisions(frame: ProblemFrame) -> list[_GeneratedFrame]:
    out = []

    def changed(operator_id, claim, **kwargs):
        current = kwargs.pop("frame", frame)
        facets = deepcopy(current.facets)
        if "focus" in kwargs:
            facets["focus"] = kwargs.pop("focus")
            current = replace(current, facets=facets)
        out.append(_GeneratedFrame(
            frame=current,
            operator_chain=(operator_id,),
            claims=(claim,),
            questions=tuple(kwargs.pop("questions", ())),
            counterfactuals=tuple(kwargs.pop("counterfactuals", ())),
            mechanism_family=str(kwargs.pop("mechanism_family", "representation_revision")),
        ))

    changed(
        "focus.relation",
        "move the unit of analysis from the isolated object to interactions across its boundary",
        frame=replace(frame, problem_unit=f"relationships and interfaces around {frame.problem_unit}"),
        focus="relations",
        questions=("Which behavior disappears if the interfaces are removed while the components remain?",),
    )
    changed(
        "focus.process",
        "replace the thing-like representation with the process that repeatedly produces the observed state",
        frame=replace(frame, problem_unit=f"process that produces {frame.problem_unit}"),
        focus="process",
        questions=("What state transition repeatedly recreates the problem even after local fixes?",),
    )
    changed(
        "boundary.expand",
        "move the system boundary one causal layer outward to include the environment that shapes the local behavior",
        frame=replace(frame, boundary=f"one causal layer outside ({frame.boundary})"),
        questions=("Which external feedback loop makes the local optimum misleading?",),
    )
    changed(
        "boundary.contract",
        "contract the system boundary to the smallest controllable interface and ask what remains sufficient",
        frame=replace(frame, boundary=f"minimal controllable interface inside ({frame.boundary})"),
        questions=("What is the smallest intervention surface that can still change the outcome?",),
    )
    if frame.causal_links:
        reversed_frame = replace(frame, causal_links=tuple((dst, f"reverse_of:{rel}", src) for src, rel, dst in frame.causal_links))
        changed(
            "causal.reverse",
            "reverse the stated causal arrows as a diagnostic counterfactual and search for observations that distinguish direction",
            frame=reversed_frame,
            counterfactuals=("causal directions reversed",),
            questions=("What observation would be expected under the reversed causal direction but not the original?",),
        )
    else:
        changed(
            "causal.reverse",
            "treat the observed outcome as a possible cause of the supposed driver instead of only its effect",
            counterfactuals=("cause/effect direction may be reversed",),
            questions=("If the supposed effect were upstream, what would change first?",),
        )
    for index, assumption in enumerate(frame.assumptions):
        assumptions = list(frame.assumptions)
        assumptions[index] = f"NOT({assumption})"
        changed(
            "assumption.negate",
            f"negate one accepted assumption and propagate the counterfactual instead of optimizing inside it: {assumption}",
            frame=replace(frame, assumptions=tuple(assumptions)),
            counterfactuals=(f"NOT({assumption})",),
            questions=(f"What becomes possible or impossible if '{assumption}' is false?",),
        )
    for index, constraint in enumerate(frame.constraints):
        constraints = list(frame.constraints)
        constraints.pop(index)
        changed(
            "constraint.remove",
            f"temporarily remove a declared constraint to separate intrinsic difficulty from self-imposed search topology: {constraint}",
            frame=replace(frame, constraints=tuple(constraints)),
            counterfactuals=(f"constraint removed: {constraint}",),
            questions=(f"If '{constraint}' vanished, which mechanism would become available and can any part of it survive when the constraint returns?",),
        )
    changed(
        "timescale.long",
        "move from immediate-turn optimization to the repeated multi-session dynamics that accumulate or erase capability",
        frame=replace(frame, time_horizon=f"long-horizon repeated dynamics beyond {frame.time_horizon}"),
        questions=("Which choice looks worse locally but compounds into a better system over repeated use?",),
    )
    changed(
        "timescale.short",
        "collapse the horizon to the first irreversible transition and identify the earliest leverage point",
        frame=replace(frame, time_horizon=f"earliest irreversible transition within {frame.time_horizon}"),
        questions=("What is the first state transition after which later repair becomes expensive?",),
    )
    changed(
        "objective.failure_inversion",
        "preserve the real goal while modeling the anti-goal as a generator of failure mechanisms",
        counterfactuals=(f"diagnostic anti-goal: systematically prevent '{frame.objective}'",),
        questions=("If we were trying to guarantee failure, what mechanism would we install first, and where is its inverse usable?",),
        mechanism_family="adversarial_goal_diagnostic",
    )
    return out


def _changed_frame_fields(base: ProblemFrame, other: ProblemFrame) -> dict[str, object]:
    fields = ("problem_unit", "boundary", "assumptions", "constraints", "actors", "resources", "information", "time_horizon", "causal_links", "facets")
    return {name: deepcopy(getattr(other, name)) for name in fields if getattr(other, name) != getattr(base, name)}


def _compose_revisions(base: ProblemFrame, rows: list[_GeneratedFrame], *, depth: int, max_attempts: int) -> list[_GeneratedFrame]:
    if isinstance(depth, bool) or not isinstance(depth, int) or depth < 1:
        raise ValueError("composition_depth must be a positive integer")
    if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts < 1:
        raise ValueError("max_generation_attempts must be a positive integer")
    if depth <= 1:
        return []
    out = []
    attempts = 0
    upper = min(depth, len(rows))
    for size in range(2, upper + 1):
        for group in combinations(rows, size):
            if attempts >= max_attempts:
                return out
            attempts += 1
            changes = {}
            conflict = False
            for row in group:
                for name, value in _changed_frame_fields(base, row.frame).items():
                    if name in changes and changes[name] != value:
                        conflict = True
                        break
                    changes[name] = value
                if conflict:
                    break
            if conflict or not changes:
                continue
            frame = replace(base, **changes)
            chain = tuple(op for row in group for op in row.operator_chain)
            claims = tuple(dict.fromkeys(claim for row in group for claim in row.claims))
            questions = tuple(dict.fromkeys(q for row in group for q in row.questions))
            counterfactuals = tuple(dict.fromkeys(q for row in group for q in row.counterfactuals))
            out.append(_GeneratedFrame(
                frame=frame,
                operator_chain=chain,
                claims=claims,
                questions=questions,
                counterfactuals=counterfactuals,
                mechanism_family="composed_representation_revision",
            ))
    return out


def default_mechanism_patterns() -> tuple[MechanismPattern, ...]:
    """Small seed library; callers may add arbitrary observed mechanism patterns."""
    return (
        MechanismPattern(
            "version-control.branch-merge", "version control",
            "branch independently, preserve a shared base, diff outcomes, merge compatible changes and surface conflicts",
            ("branch", "shared_base", "conflict", "merge_rule"),
            (("branch", "diverges_from", "shared_base"), ("conflict", "blocks", "merge_rule")),
            {
                "branch": ("actors", "problem_unit"), "shared_base": ("objective", "boundary"),
                "conflict": ("constraints", "assumptions"), "merge_rule": ("information", "objective"),
            },
        ),
        MechanismPattern(
            "evolution.variation-selection-retention", "evolutionary search",
            "generate variation before selection, expose variants to different pressures, retain useful heritable structure",
            ("variation", "selection_pressure", "retention", "population"),
            (("variation", "feeds", "population"), ("selection_pressure", "filters", "population"), ("retention", "preserves", "population")),
            {
                "variation": ("assumptions", "actors"), "selection_pressure": ("constraints", "objective"),
                "retention": ("information", "resources"), "population": ("problem_unit", "actors"),
            },
        ),
        MechanismPattern(
            "control.feedback-error-correction", "control systems",
            "sense state, compare against a reference, expose error, apply correction, observe the new state",
            ("sensor", "reference", "error", "actuator"),
            (("sensor", "estimates", "error"), ("reference", "defines", "error"), ("error", "drives", "actuator")),
            {
                "sensor": ("information", "actors"), "reference": ("objective",),
                "error": ("constraints", "assumptions"), "actuator": ("resources", "actors"),
            },
        ),
        MechanismPattern(
            "anomaly.detect-amplify-memory", "adaptive anomaly-detection systems",
            "detect anomalous patterns, amplify a targeted response, retain memory of successful recognition without treating every signal as global truth",
            ("detector", "signal", "response", "memory"),
            (("detector", "recognizes", "signal"), ("signal", "activates", "response"), ("response", "updates", "memory")),
            {
                "detector": ("information", "actors"), "signal": ("assumptions", "constraints"),
                "response": ("resources", "actors"), "memory": ("information", "resources"),
            },
        ),
    )


def _target_pool(frame: ProblemFrame) -> dict[str, tuple[str, ...]]:
    return {
        "objective": (frame.objective,) if frame.objective else (),
        "problem_unit": (frame.problem_unit,) if frame.problem_unit else (),
        "boundary": (frame.boundary,) if frame.boundary else (),
        "assumptions": frame.assumptions,
        "constraints": frame.constraints,
        "actors": frame.actors,
        "resources": frame.resources,
        "information": frame.information,
        "time_horizon": (frame.time_horizon,) if frame.time_horizon else (),
    }


def transfer_mechanism(frame: ProblemFrame, pattern: MechanismPattern) -> _GeneratedFrame:
    if not isinstance(pattern, MechanismPattern):
        raise ValueError("mechanism source must be MechanismPattern")
    for label in (pattern.pattern_id, pattern.source_domain, pattern.mechanism):
        _require_text(label, "mechanism pattern text")
    if not pattern.roles:
        raise ValueError("mechanism pattern needs roles")
    pool = _target_pool(frame)
    mapping = {}
    used = set()
    fallbacks = ["problem_unit", "actors", "resources", "information", "constraints", "assumptions", "objective", "boundary", "time_horizon"]
    for role in pattern.roles:
        hints = tuple(pattern.target_hints.get(role, ())) + tuple(x for x in fallbacks if x not in pattern.target_hints.get(role, ()))
        choice = None
        for field_name in hints:
            values = pool.get(field_name, ())
            for value in values:
                token = (field_name, value)
                if token not in used:
                    choice = {"field": field_name, "value": value}
                    used.add(token)
                    break
            if choice:
                break
        mapping[role] = choice or {"field": "problem_unit", "value": frame.problem_unit}
    transfer = {
        "pattern_id": pattern.pattern_id,
        "source_domain": pattern.source_domain,
        "mechanism": pattern.mechanism,
        "role_mapping": mapping,
        "relations": [list(x) for x in pattern.relations],
        "break_conditions": list(pattern.break_conditions),
    }
    questions = tuple(
        f"Does target role '{role}' really behave like source role '{role}' mapped to '{mapping[role]['value']}', or does the analogy break?"
        for role in pattern.roles
    )
    return _GeneratedFrame(
        frame=frame,
        operator_chain=("transfer:" + pattern.pattern_id,),
        claims=(f"transfer the causal mechanism from {pattern.source_domain} instead of copying its surface vocabulary",),
        questions=questions,
        mechanism_family="cross_domain_transfer",
        source_pattern=pattern.pattern_id,
        mechanism_transfer=transfer,
    )


def _causal_model(frame: ProblemFrame, claims: tuple[str, ...], transfer: dict[str, object]) -> str:
    links = "; ".join(f"{a} --{r}--> {b}" for a, r, b in frame.causal_links)
    basis = " | ".join(claims)
    if transfer:
        return f"{basis}; transferred mechanism: {transfer.get('mechanism')}; target links: {links or 'to be discriminated by branch execution'}"
    return f"{basis}; causal graph: {links or 'direction intentionally left open for discrimination'}"


def _representation(candidate: _GeneratedFrame) -> dict[str, object]:
    frame = candidate.frame
    focus = _base_focus(frame)
    return {
        "goal_anchor": frame.objective,
        "problem_unit": frame.problem_unit,
        "boundary": frame.boundary,
        "focus": focus,
        "assumptions": list(frame.assumptions),
        "constraints": list(frame.constraints),
        "actors": list(frame.actors),
        "resources": list(frame.resources),
        "information": list(frame.information),
        "time_horizon": frame.time_horizon,
        "causal_links": [list(x) for x in frame.causal_links],
        "counterfactuals": list(candidate.counterfactuals),
        "mechanism_transfer": deepcopy(candidate.mechanism_transfer),
        "generation": {
            "engine": "JIGAEWOL_COGNITION_GENERATION_V1",
            "operator_chain": list(candidate.operator_chain),
            "transformation_claims": list(candidate.claims),
            "source_pattern": candidate.source_pattern,
            "host_generated_world": False,
        },
        "facets": deepcopy(frame.facets),
    }


def _proposal(candidate: _GeneratedFrame) -> WorldProposal:
    frame = candidate.frame
    predicted = []
    if candidate.counterfactuals:
        predicted.append("the branch should produce materially different actions if its counterfactual changes the mechanism")
    if candidate.source_pattern:
        predicted.append("the transferred mechanism should preserve causal roles while surface terminology changes")
    predicted.append("a useful branch changes mechanism, evidence demand, action, or artifact structure rather than wording alone")
    effects = (
        "produce an independently realizable mechanism path",
        "expose a discriminator that can retain or reject this representation after evidence",
    )
    return WorldProposal(
        problem_unit=frame.problem_unit,
        causal_model=_causal_model(frame, candidate.claims, candidate.mechanism_transfer),
        mechanism_family=candidate.mechanism_family,
        assumptions=frame.assumptions,
        predicted_observations=tuple(predicted),
        discriminating_questions=tuple(candidate.questions),
        expected_material_effects=effects,
        representation=_representation(candidate),
    )


def _words(value) -> set[str]:
    if isinstance(value, (list, tuple, set)):
        value = " ".join(str(x) for x in value)
    return {x for x in str(value or "").casefold().replace("_", " ").replace("-", " ").split() if x}


def _set_distance(left, right) -> float:
    a, b = set(left), set(right)
    if not a and not b:
        return 0.0
    return 1.0 - len(a & b) / max(1, len(a | b))


def descriptor_distance(left: dict, right: dict) -> float:
    """Structural novelty distance; no model self-rating is used."""
    categorical = ["focus", "boundary", "mechanism_family", "source_pattern"]
    parts = [0.0 if str(left.get(k, "")) == str(right.get(k, "")) else 1.0 for k in categorical]
    parts.append(_set_distance(_words(left.get("operator_chain", ())), _words(right.get("operator_chain", ()))))
    parts.append(_set_distance(_words(left.get("counterfactuals", ())), _words(right.get("counterfactuals", ()))))
    return sum(parts) / len(parts)


class NoveltyArchive:
    def __init__(self, path=None):
        self.path = Path(path) if path else None
        self.entries: list[dict[str, object]] = []
        if self.path and self.path.exists():
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                self.entries = [x for x in data if isinstance(x, dict) and isinstance(x.get("descriptor"), dict)]

    def score(self, descriptor: dict[str, object], *, extra_descriptors=()) -> float:
        pool = [x["descriptor"] for x in self.entries] + [x for x in extra_descriptors if isinstance(x, dict)]
        if not pool:
            return 1.0
        return min(descriptor_distance(descriptor, other) for other in pool)

    def admit(self, descriptor: dict[str, object], *, source_id: str) -> dict[str, object]:
        row = {"source_id": _require_text(source_id, "novelty source_id"), "descriptor": deepcopy(descriptor)}
        if not any(x.get("source_id") == row["source_id"] and x.get("descriptor") == row["descriptor"] for x in self.entries):
            self.entries.append(row)
            self._save()
        return row

    def _save(self):
        if not self.path:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        raw = json.dumps(self.entries, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(raw, encoding="utf-8")
        os.replace(tmp, self.path)


def _descriptor(proposal: WorldProposal) -> dict[str, object]:
    rep = proposal.representation
    gen = rep.get("generation", {}) if isinstance(rep.get("generation"), dict) else {}
    return {
        "focus": str(rep.get("focus", "")),
        "boundary": str(rep.get("boundary", "")),
        "operator_chain": list(gen.get("operator_chain", ())),
        "mechanism_family": proposal.mechanism_family,
        "counterfactuals": list(rep.get("counterfactuals", ())),
        "source_pattern": str(gen.get("source_pattern", "")),
    }


def _greedy_novelty_select(proposals: list[WorldProposal], archive: NoveltyArchive, budget: int) -> list[WorldProposal]:
    if isinstance(budget, bool) or not isinstance(budget, int) or budget < 1:
        raise ValueError("branch_budget must be a positive integer execution budget")
    remaining = list(proposals)
    selected = []
    selected_descriptors = []
    family_seen = set()
    while remaining and len(selected) < budget:
        def rank(p):
            d = _descriptor(p)
            novelty = archive.score(d, extra_descriptors=selected_descriptors)
            gen = p.representation.get("generation", {})
            family = tuple(gen.get("operator_chain", ()))[:1] or (p.mechanism_family,)
            coverage = 1 if family not in family_seen else 0
            transfer = 1 if gen.get("source_pattern") else 0
            return coverage, novelty, transfer, -len(selected)
        chosen = max(remaining, key=rank)
        remaining.remove(chosen)
        selected.append(chosen)
        d = _descriptor(chosen)
        selected_descriptors.append(d)
        gen = chosen.representation.get("generation", {})
        family_seen.add(tuple(gen.get("operator_chain", ()))[:1] or (chosen.mechanism_family,))
    return selected


def generate_worlds(seed, *, revision_specs=(), source_mechanisms=(), archive=None, branch_budget=8, composition_depth=2, max_generation_attempts=2048) -> dict[str, object]:
    """Generate structurally revised problem worlds before host semantic realization.

    ``composition_depth`` controls executable transformation composition and is an
    explicit search budget, not a semantic ceiling. ``max_generation_attempts``
    is the resource boundary for combinatorial revision search.
    """
    frame = ProblemFrame.from_value(seed)
    archive = archive if isinstance(archive, NoveltyArchive) else NoveltyArchive(archive)
    revision_rows = _builtin_revisions(frame)
    for spec in revision_specs or ():
        revision_rows.append(apply_revision_spec(frame, spec))
    generated = list(revision_rows)
    generated.extend(_compose_revisions(
        frame, revision_rows, depth=composition_depth, max_attempts=max_generation_attempts
    ))
    sources = tuple(source_mechanisms or ())
    if not sources:
        sources = default_mechanism_patterns()
    for pattern in sources:
        generated.append(transfer_mechanism(frame, pattern))

    proposals = [_proposal(row) for row in generated]
    dedup = {}
    for p in proposals:
        dedup.setdefault(_signature(p), p)
    proposals = list(dedup.values())
    selected = _greedy_novelty_select(proposals, archive, int(branch_budget))
    worlds = admit_worlds(selected)
    novelty_rows = []
    for world in worlds:
        proposal_like = WorldProposal(
            problem_unit=world.problem_unit, causal_model=world.causal_model, mechanism_family=world.mechanism_family,
            assumptions=world.assumptions, predicted_observations=world.predicted_observations,
            discriminating_questions=world.discriminating_questions, expected_material_effects=world.expected_material_effects,
            representation=world.representation,
        )
        desc = _descriptor(proposal_like)
        score = archive.score(desc)
        archive.admit(desc, source_id=world.world_id)
        novelty_rows.append({"world_id": world.world_id, "novelty_before_selection": score, "descriptor": desc})
    return {
        "engine": "JIGAEWOL_COGNITION_GENERATION_V1",
        "seed_frame": asdict(frame),
        "worlds": worlds,
        "novelty": novelty_rows,
        "candidate_count": len(proposals),
        "selected_count": len(worlds),
        "selection_basis": "greedy structural novelty with operator-family coverage; host self-ratings are not used",
        "composition_depth": composition_depth,
        "max_generation_attempts": max_generation_attempts,
    }



def branch_packet(world: WorldModel) -> dict[str, object]:
    if not isinstance(world, WorldModel):
        raise ValueError("branch packet needs WorldModel")
    raw = json.dumps(world.representation, ensure_ascii=False, sort_keys=True, allow_nan=False, separators=(",", ":"))
    token = "branchiso_" + sha256((world.world_id + raw).encode("utf-8")).hexdigest()[:20]
    return {
        "branch_id": world.world_id,
        "isolation_token": token,
        "goal_anchor": world.representation.get("goal_anchor", ""),
        "problem_unit": world.problem_unit,
        "causal_model": world.causal_model,
        "mechanism_family": world.mechanism_family,
        "assumptions": list(world.assumptions),
        "discriminating_questions": list(world.discriminating_questions),
        "expected_material_effects": list(world.expected_material_effects),
        "representation": deepcopy(world.representation),
        "isolation_contract": "realize only this generated representation plus the original goal; sibling branch outputs are intentionally withheld",
    }


def recombine_branch_results(rows) -> dict[str, object]:
    clean = []
    for raw in rows or ():
        if not isinstance(raw, dict):
            continue
        branch_id = str(raw.get("branch_id", "")).strip()
        mechanism = str(raw.get("mechanism", "")).strip()
        if not branch_id or not mechanism:
            continue
        clean.append({
            "branch_id": branch_id,
            "mechanism": mechanism,
            "actions": [str(x) for x in raw.get("actions", ()) if str(x).strip()],
            "assumptions": [str(x) for x in raw.get("assumptions", ()) if str(x).strip()],
            "falsifier": str(raw.get("falsifier", "")).strip(),
            "expected_effect": str(raw.get("expected_effect", "")).strip(),
        })
    mechanisms = list(dict.fromkeys(x["mechanism"] for x in clean))
    action_union = list(dict.fromkeys(a for x in clean for a in x["actions"]))
    shared_actions = []
    if clean:
        shared = set(clean[0]["actions"])
        for row in clean[1:]:
            shared &= set(row["actions"])
        shared_actions = sorted(shared)
    tensions = []
    for left, right in combinations(clean, 2):
        if left["mechanism"] != right["mechanism"] or set(left["assumptions"]) != set(right["assumptions"]):
            tensions.append({
                "left": left["branch_id"], "right": right["branch_id"],
                "question": f"Can '{left['mechanism']}' and '{right['mechanism']}' coexist without one erasing the other's causal advantage?",
            })
    return {
        "parents": [x["branch_id"] for x in clean],
        "mechanisms": mechanisms,
        "action_union": action_union,
        "shared_actions": shared_actions,
        "tensions": tensions,
        "recombination_rule": "preserve unique mechanisms and explicit tensions; do not average branches into generic wording",
    }
