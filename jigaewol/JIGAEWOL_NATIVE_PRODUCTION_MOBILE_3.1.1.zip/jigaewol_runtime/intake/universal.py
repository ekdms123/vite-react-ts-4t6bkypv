from __future__ import annotations

from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import mimetypes
import plistlib

from .zip_project import index_zip

MAX_CONTEXT_CHARS = None
MAX_FILE_TEXT_CHARS = None


class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        text = " ".join(data.split())
        if text:
            self.parts.append(text)

    def text(self) -> str:
        return "\n".join(self.parts)


@dataclass(frozen=True)
class AttachmentIntake:
    inventory: tuple[str, ...]
    context_slices: tuple[str, ...]
    provenance: tuple[str, ...]
    media: tuple[dict, ...] = ()


def _clip(text: str, limit: int | None = MAX_FILE_TEXT_CHARS) -> str:
    if not isinstance(text, str):
        raise ValueError("intake text must be a string")
    if limit is None:
        return text
    if isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0:
        raise ValueError("intake clip limit must be a positive integer or None")
    if len(text) <= limit:
        return text
    marker = "\n…[explicit-resource-slice]…\n"
    if limit <= len(marker) + 2:
        head = (limit + 1) // 2
        tail = limit - head
        return text[:head] + (text[-tail:] if tail else "")
    room = limit - len(marker)
    head = (room + 1) // 2
    tail = room - head
    return text[:head] + marker + (text[-tail:] if tail else "")


def _html_text(raw: str) -> str:
    parser = _TextExtractor()
    parser.feed(raw)
    return parser.text()


def _webarchive(path: Path) -> AttachmentIntake:
    payload = plistlib.loads(path.read_bytes())
    main = payload.get("WebMainResource", {})
    data = main.get("WebResourceData", b"")
    if isinstance(data, str):
        data = data.encode("utf-8")
    encoding = main.get("WebResourceTextEncodingName") or "utf-8"
    try:
        raw = bytes(data).decode(str(encoding), errors="replace")
    except LookupError:
        raw = bytes(data).decode("utf-8", errors="replace")
    mime = str(main.get("WebResourceMIMEType") or "")
    text = _html_text(raw) if "html" in mime.lower() or "<html" in raw.lower() else raw
    url = str(main.get("WebResourceURL") or "")
    context = _clip(text)
    return AttachmentIntake(
        inventory=(path.name,),
        context_slices=(f"webarchive:{path.name}:url={url}:mime={mime}\n{context}",),
        provenance=(f"file:{path}",),
    )


def _zip(path: Path) -> AttachmentIntake:
    bundle = index_zip(path)
    inventory = tuple(item.path for item in bundle.inventory)
    slices: list[str] = []
    for name, code in sorted(bundle.code_map.files.items()):
        slices.append(
            f"zip-code:{name}:imports={','.join(code.imports)};symbols={','.join(code.symbols)};parse_error={code.parse_error or ''}"
        )
    for name in inventory:
        ref = bundle.content_refs[name]
        if ref.text is None:
            continue
        slices.append(f"zip-text:{name}:sha256={ref.sha256}\n{ref.text}")
    return AttachmentIntake(inventory, tuple(slices), tuple(bundle.provenance))


def _plain(path: Path) -> AttachmentIntake:
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    mime, _ = mimetypes.guess_type(path.name)
    mime = mime or "application/octet-stream"
    media = ()
    if mime.startswith("image/"):
        media = ({
            "kind": "image", "name": path.name, "mime": mime,
            "size": len(data), "sha256": digest,
            # This is an external reference. Semantic/provider adapters decide
            # how to bind it to their native multimodal input surface.
            "host_ref": f"file:{path}",
        },)
    text: str | None = None
    if not media:
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            pass
    if text is not None:
        return AttachmentIntake(
            (path.name,),
            (f"file-text:{path.name}:mime={mime}:sha256={digest}\n{_clip(text)}",),
            (f"file:{path}",),
        )
    return AttachmentIntake(
        (path.name,),
        (f"file-binary:{path.name}:mime={mime}:size={len(data)}:sha256={digest}",),
        (f"file:{path}",),
        media,
    )


def intake_attachments(attachments) -> AttachmentIntake:
    if attachments is None:
        attachments = ()
    if isinstance(attachments, (str, bytes)) or not isinstance(attachments, (list, tuple)):
        raise ValueError("attachments must be a list or tuple of paths/references")
    inventory: list[str] = []
    slices: list[str] = []
    provenance: list[str] = []
    media: list[dict] = []
    for attachment in attachments:
        path = Path(attachment)
        if not path.exists():
            inventory.append(str(attachment))
            slices.append(f"attachment-ref:{attachment}")
            continue
        if path.suffix.lower() == ".zip":
            item = _zip(path)
        elif path.suffix.lower() == ".webarchive":
            item = _webarchive(path)
        else:
            item = _plain(path)
        inventory.extend(item.inventory)
        provenance.extend(item.provenance)
        media.extend(item.media)
        slices.extend(item.context_slices)
    unique_media = []
    seen_media = set()
    for item in media:
        key = (item.get("host_ref"), item.get("sha256"))
        if key in seen_media:
            continue
        seen_media.add(key)
        unique_media.append(item)
    return AttachmentIntake(tuple(dict.fromkeys(inventory)), tuple(slices), tuple(dict.fromkeys(provenance)), tuple(unique_media))
