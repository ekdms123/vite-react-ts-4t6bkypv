"""First-class attachment and project intake."""
