from __future__ import annotations
from dataclasses import dataclass
import hashlib


@dataclass(frozen=True)
class InventoryItem:
    path: str
    size: int
    kind: str


@dataclass(frozen=True)
class ContentRef:
    path: str
    sha256: str
    size: int
    text: str | None = None


def hash_bytes(path: str, data: bytes, text: str | None = None) -> ContentRef:
    return ContentRef(path, hashlib.sha256(data).hexdigest(), len(data), text)
