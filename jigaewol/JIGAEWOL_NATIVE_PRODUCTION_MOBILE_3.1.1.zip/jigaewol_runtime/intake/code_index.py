from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import ast


@dataclass(frozen=True)
class CodeFile:
    path: str
    imports: tuple[str, ...]
    symbols: tuple[str, ...]
    parse_error: str | None = None


@dataclass(frozen=True)
class CodeMap:
    files: dict[str, CodeFile]


def _index_source(path: str, source: str) -> CodeFile:
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        return CodeFile(path, (), (), f"{exc.msg}:{exc.lineno}")
    imports: list[str] = []
    symbols: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module or "")
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            symbols.append(node.name)
    return CodeFile(path, tuple(dict.fromkeys(imports)), tuple(dict.fromkeys(symbols)))


def index_python_tree(root) -> CodeMap:
    root = Path(root)
    files: dict[str, CodeFile] = {}
    for path in sorted(root.rglob("*.py")):
        rel = path.relative_to(root).as_posix()
        try:
            source = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            files[rel] = CodeFile(rel, (), (), "decode_error")
            continue
        files[rel] = _index_source(rel, source)
    return CodeMap(files)
