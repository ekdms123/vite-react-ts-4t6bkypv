from __future__ import annotations
from dataclasses import dataclass
from pathlib import PurePosixPath, Path
import zipfile

from .files import InventoryItem, ContentRef, hash_bytes
from .code_index import CodeMap, CodeFile, _index_source

MAX_MEMBER_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024


@dataclass(frozen=True)
class ZipIntakeBundle:
    inventory: tuple[InventoryItem, ...]
    content_refs: dict[str, ContentRef]
    code_map: CodeMap
    unreadable_items: tuple[str, ...]
    provenance: tuple[str, ...]


def _safe_member(name: str) -> str:
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts:
        raise ValueError(f"zip member path escapes the extraction root: {name}")
    return p.as_posix()


def index_zip(path) -> ZipIntakeBundle:
    archive_path = Path(path)
    inventory: list[InventoryItem] = []
    content_refs: dict[str, ContentRef] = {}
    unreadable: list[str] = []
    code_files: dict[str, CodeFile] = {}
    total = 0
    seen_members: set[str] = set()
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = _safe_member(info.filename)
            if name in seen_members:
                raise ValueError(f"duplicate normalized zip member: {name}")
            seen_members.add(name)
            if info.file_size > MAX_MEMBER_BYTES:
                unreadable.append(f"{name}:oversize")
                continue
            total += info.file_size
            if total > MAX_TOTAL_BYTES:
                raise ValueError("zip exceeds total intake budget")
            data = archive.read(info)
            text = None
            kind = "binary"
            try:
                text = data.decode("utf-8")
                kind = "text"
            except UnicodeDecodeError:
                unreadable.append(f"{name}:binary")
            inventory.append(InventoryItem(name, len(data), kind))
            content_refs[name] = hash_bytes(name, data, text)
            if name.endswith(".py") and text is not None:
                code_files[name] = _index_source(name, text)
    return ZipIntakeBundle(tuple(inventory), content_refs, CodeMap(code_files), tuple(unreadable), (f"file:{archive_path}",))
