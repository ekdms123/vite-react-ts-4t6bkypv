from __future__ import annotations

from dataclasses import dataclass
from collections import OrderedDict

from jigaewol_runtime.kernel.ids import new_id
from .raw_turn import RawTurn, SourceSpan


@dataclass(frozen=True)
class IntentProposal:
    meaning: str
    source_spans: tuple[SourceSpan, ...]
    strength: int
    required: bool
    duplicate_key: str | None = None

    def __post_init__(self):
        if not isinstance(self.meaning, str) or not self.meaning.strip():
            raise ValueError("intent meaning must be nonempty text")
        if not isinstance(self.source_spans, tuple) or any(not isinstance(span, SourceSpan) for span in self.source_spans):
            raise ValueError("intent source_spans must be a tuple of SourceSpan values")
        if type(self.strength) is not int or self.strength < 0:
            raise ValueError("intent strength must be a nonnegative integer")
        if type(self.required) is not bool:
            raise ValueError("intent required must be boolean")
        if self.duplicate_key is not None and not isinstance(self.duplicate_key, str):
            raise ValueError("intent duplicate_key must be text or None")


@dataclass(frozen=True)
class IntentNode:
    intent_id: str
    meaning: str
    source_spans: tuple[SourceSpan, ...]
    strength: int
    required: bool
    canonical_key: str


@dataclass(frozen=True)
class IntentLattice:
    raw_turn: RawTurn
    nodes: tuple[IntentNode, ...]

    def required_ids(self) -> tuple[str, ...]:
        return tuple(n.intent_id for n in self.nodes if n.required)


def build_intent_lattice(raw_turn: RawTurn, proposals) -> IntentLattice:
    if not isinstance(raw_turn, RawTurn):
        raise ValueError("intent lattice needs a RawTurn")
    if isinstance(proposals, (str, bytes)):
        raise ValueError("intent proposals must be IntentProposal values")
    grouped: OrderedDict[str, list[IntentProposal]] = OrderedDict()
    for proposal in proposals:
        if not isinstance(proposal, IntentProposal):
            raise ValueError("intent proposals must be IntentProposal values")
        for span in proposal.source_spans:
            span.text(raw_turn.message)
        key = proposal.duplicate_key or f"meaning:{proposal.meaning.strip()}"
        grouped.setdefault(key, []).append(proposal)

    nodes: list[IntentNode] = []
    for key, items in grouped.items():
        spans: list[SourceSpan] = []
        for item in items:
            for span in item.source_spans:
                if span not in spans:
                    spans.append(span)
        nodes.append(
            IntentNode(
                intent_id=new_id("intent"),
                meaning=items[0].meaning,
                source_spans=tuple(spans),
                strength=max(i.strength for i in items),
                required=any(i.required for i in items),
                canonical_key=key,
            )
        )
    return IntentLattice(raw_turn=raw_turn, nodes=tuple(nodes))


def single_intent_contract(message: str) -> IntentLattice:
    raw = RawTurn.create(new_id("turn"), message)
    span = SourceSpan(0, len(message))
    return build_intent_lattice(raw, (IntentProposal(message, (span,), 1, True),))
