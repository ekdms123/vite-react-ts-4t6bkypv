from __future__ import annotations

from dataclasses import dataclass
import hashlib


@dataclass(frozen=True, order=True)
class SourceSpan:
    start: int
    end: int

    def __post_init__(self):
        if type(self.start) is not int or type(self.end) is not int or self.start < 0 or self.end < self.start:
            raise ValueError("source span bounds must be nonnegative ordered integers")

    def text(self, message: str) -> str:
        if not isinstance(message, str):
            raise ValueError("source span text requires a string message")
        if self.start < 0 or self.end < self.start or self.end > len(message):
            raise ValueError(f"invalid source span {self.start}:{self.end} for message length {len(message)}")
        return message[self.start:self.end]


@dataclass(frozen=True)
class RawTurn:
    turn_id: str
    message: str
    attachment_refs: tuple[str, ...] = ()
    capability_snapshot_ref: str | None = None
    task_id: str | None = None
    source_hash: str = ""

    def __post_init__(self):
        if not isinstance(self.turn_id, str) or not self.turn_id.strip():
            raise ValueError("turn_id must be nonempty text")
        if not isinstance(self.message, str):
            raise ValueError("message must be text")
        if not isinstance(self.attachment_refs, tuple) or any(
                not isinstance(ref, str) or not ref.strip() for ref in self.attachment_refs):
            raise ValueError("attachment_refs must be a tuple of nonempty text ids")
        if self.capability_snapshot_ref is not None and not isinstance(self.capability_snapshot_ref, str):
            raise ValueError("capability_snapshot_ref must be text or None")
        if self.task_id is not None and not isinstance(self.task_id, str):
            raise ValueError("task_id must be text or None")
        if not isinstance(self.source_hash, str):
            raise ValueError("source_hash must be text")

    @classmethod
    def create(
        cls,
        turn_id: str,
        message: str,
        attachment_refs=(),
        capability_snapshot_ref: str | None = None,
        task_id: str | None = None,
    ) -> "RawTurn":
        if not isinstance(turn_id, str) or not turn_id.strip():
            raise ValueError("turn_id must be nonempty text")
        if not isinstance(message, str):
            raise ValueError("message must be text")
        if isinstance(attachment_refs, str) or not isinstance(attachment_refs, (list, tuple)) or any(
                not isinstance(ref, str) or not ref.strip() for ref in attachment_refs):
            raise ValueError("attachment_refs must be a list of nonempty text ids")
        if capability_snapshot_ref is not None and not isinstance(capability_snapshot_ref, str):
            raise ValueError("capability_snapshot_ref must be text or None")
        if task_id is not None and not isinstance(task_id, str):
            raise ValueError("task_id must be text or None")
        return cls(
            turn_id=turn_id.strip(),
            message=message,
            attachment_refs=tuple(ref.strip() for ref in attachment_refs),
            capability_snapshot_ref=capability_snapshot_ref,
            task_id=task_id,
            source_hash=hashlib.sha256(message.encode("utf-8")).hexdigest(),
        )
