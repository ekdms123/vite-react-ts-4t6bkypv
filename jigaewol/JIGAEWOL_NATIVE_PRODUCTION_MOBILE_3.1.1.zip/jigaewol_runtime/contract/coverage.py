from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class IntentClosure:
    intent_id: str
    status: str
    effect_refs: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()


def compute_closure(intent_lattice, ledger):
    result = {}
    for node in intent_lattice.nodes:
        entries = ledger.entries_for_intent(node.intent_id) if hasattr(ledger, "entries_for_intent") else ()
        effects = tuple(e.entry_id for e in entries if e.kind == "effect" and e.verification_status in {"supported", "verified", "observed"})
        evidence = tuple(e.entry_id for e in entries if e.kind in {"claim", "evidence"} and e.verification_status in {"supported", "verified", "observed"})
        status = "resolved" if effects or (not node.required and evidence) else "unresolved"
        result[node.intent_id] = IntentClosure(node.intent_id, status, effects, evidence)
    return result
