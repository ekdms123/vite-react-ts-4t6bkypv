from __future__ import annotations

"""Source-grounded destination contract.

This object is deliberately separate from working interpretation and execution
state. Tool failures and budget events may alter routes; they do not get write
authority over the user's destination.
"""

from copy import deepcopy
import hashlib
import math
import re


_MAX_AMBITION = 5
_STRONG_MARKERS = (
    "업계가 놀랄", "도약적", "비범", "극한", "난제", "완전히 새", "완전히 다른",
    "미친", "괴물", "breakthrough", "step-change", "radical", "exceptional",
    "frontier", "state of the art", "world-class", "non-obvious", "unconventional",
)
_MEDIUM_MARKERS = ("깊게", "창의적", "새로운", "novel", "creative", "deep", "ambitious")


def _sha(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _semantic_intensity(task_model) -> int | None:
    if not isinstance(task_model, dict):
        return None
    values = []
    for key in ("reasoning_intensity", "requested_intensity"):
        value = task_model.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        number = float(value)
        if math.isfinite(number):
            values.append(int(round(number)))
    for key in ("novelty_target", "exploration_leverage", "breadth_target", "divergence_target", "intent_fidelity"):
        value = task_model.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        number = float(value)
        if math.isfinite(number):
            values.append(5 if number >= 1.0 else 4 if number >= .75 else 2)
    return max(values) if values else None


def _marker_present(message: str, marker: str) -> bool:
    """Use lexical markers only when their local source context is not negated."""
    folded = message.casefold()
    needle = marker.casefold()
    for match in re.finditer(re.escape(needle), folded):
        before = folded[max(0, match.start() - 18):match.start()]
        after = folded[match.end():min(len(folded), match.end() + 18)]
        if re.search(r"(?:하지\s*마|말고|아니|금지|no\s+|not\s+|without\s+)[^\n]{0,10}$", before):
            continue
        if re.match(r"[^\n]{0,10}(?:하지\s*마|말고|아니|금지|하지\s*않|아님|제외)", after):
            continue
        return True
    return False


def _source_intensity(message: str) -> tuple[int | None, list[str]]:
    """Return only explicit, non-negated lexical evidence; absence is not low ambition evidence."""
    strong = [m for m in _STRONG_MARKERS if _marker_present(message, m)]
    if strong:
        return _MAX_AMBITION, strong
    medium = [m for m in _MEDIUM_MARKERS if _marker_present(message, m)]
    return (3, medium) if medium else (None, [])


def _prior_floor(prior) -> int | None:
    if not isinstance(prior, dict) or "ambition_floor" not in prior:
        return None
    value = prior.get("ambition_floor")
    if type(value) is not int or not 1 <= value <= _MAX_AMBITION:
        return None
    return value


def compile_goal_contract(message, requirements=(), task_model=None, *, source_hash=None, prior=None):
    if not isinstance(message, str) or not message.strip():
        raise ValueError("goal contract needs the actual user message")
    raw = message
    source_floor, markers = _source_intensity(raw)
    semantic_floor = _semantic_intensity(task_model)
    prior_floor = _prior_floor(prior)
    grounded = [value for value in (source_floor, semantic_floor, prior_floor) if value is not None]
    floor = min(_MAX_AMBITION, max([1, *grounded]))
    ambition_basis = []
    if source_floor is not None:
        ambition_basis.append("explicit_source_markers")
    if semantic_floor is not None:
        ambition_basis.append("semantic_task_model")
    if prior_floor is not None:
        ambition_basis.append("live_task_prior_contract")
    # The floor is a one-way guard inside a live task. Lowering it requires the
    # caller to compile a source-grounded correction into a fresh task contract.

    reqs = []
    for row in requirements or ():
        if not isinstance(row, dict):
            continue
        meaning = row.get("meaning", "")
        quote = row.get("quote", "")
        if not isinstance(meaning, str) or not isinstance(quote, str):
            continue
        meaning, quote = meaning.strip(), quote.strip()
        if meaning or quote:
            turn_id = row.get("turn_id")
            if turn_id is not None and not isinstance(turn_id, str):
                turn_id = None
            reqs.append({"meaning": meaning, "quote": quote, "turn_id": turn_id})

    history = []
    if isinstance(prior, dict):
        prior_history = prior.get("source_history", [])
        if isinstance(prior_history, list):
            history.extend(deepcopy(row) for row in prior_history if isinstance(row, dict))
        prior_req = prior.get("source_request", "")
        prior_sha = prior.get("source_request_sha256", "")
        if isinstance(prior_req, str):
            prior_req = prior_req.strip()
        else:
            prior_req = ""
        if not isinstance(prior_sha, str) or len(prior_sha) != 64 or any(c not in "0123456789abcdef" for c in prior_sha.casefold()):
            prior_sha = ""
        if prior_req and prior_req != raw:
            entry = {"source_request": prior_req, "source_request_sha256": prior_sha.casefold() or _sha(prior_req)}
            if not history or history[-1] != entry:
                history.append(entry)

    actual_sha = _sha(raw)
    if source_hash is not None:
        if not isinstance(source_hash, str) or source_hash.casefold() != actual_sha:
            raise ValueError("goal contract source_hash must match the actual user message")

    # A number in the request ("1000을 목표로") is a direction, never a step budget.
    # Recording it explicitly — with the flag that says it is not a budget — is what
    # keeps a downstream scheduler from reading "1000" as work to ration.
    # (merged from the GPT lineage)
    from jigaewol_components.user_directive_authority import compile_user_directive
    directive_authority = compile_user_directive(raw, reqs)
    numeric = list(directive_authority.numeric_aspirations)
    return {
        "version": 2,
        "source_request": raw,
        "source_request_sha256": actual_sha,
        "source_history": history,
        "active_requirements": reqs,
        "user_directive_authority": directive_authority.as_mapping(),
        "numeric_aspirations": numeric,
        "aspiration_magnitude_max": max((x["value"] for x in numeric), default=None),
        "numeric_aspiration_is_execution_budget": False,
        "semantic_ceiling": None,
        "silent_downgrade_allowed": False,
        "verification_failure_can_rewrite_destination": False,
        "classifier_output_can_rewrite_destination": False,
        "memory_ranking_can_delete_possibility": False,
        "ambition_floor": floor,
        "ambition_markers": markers,
        "ambition_basis": ambition_basis or ["pending_semantic_intake"],
        "ambition_evidence_pending": not bool(ambition_basis),
        "working_interpretation_is_mutable": True,
        "execution_state_is_mutable": True,
        "user_destination_locked": True,
        "downgrade_authority": "user_or_source_grounded_correction_only",
        "route_failure_can_rewrite_destination": False,
        "budget_exhaustion_can_rewrite_destination": False,
        "negative_evidence_default_scope": "route_or_condition_local",
        "truth_states": ["executed", "observed", "inferred", "proposed", "open"],
        "quality_policy": {
            "novelty_request_increases_generation_search_not_self_praise": True,
            "activity_volume_is_not_quality": True,
            "verification_scales_with_consequence": True,
        },
    }
