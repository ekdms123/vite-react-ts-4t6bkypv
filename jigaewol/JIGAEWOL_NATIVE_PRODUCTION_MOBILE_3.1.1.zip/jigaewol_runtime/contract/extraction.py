"""Literal request accounting; semantic extraction is an explicit host operation."""
import hashlib
import re
from .intents import IntentProposal
from .raw_turn import SourceSpan


def locate_quote(text, quote, occurrence=None):
    if not isinstance(quote, str) or not quote:
        raise ValueError("provide a nonempty exact quote")
    positions = []
    start = 0
    while True:
        at = text.find(quote, start)
        if at < 0:
            break
        positions.append(at)
        start = at + 1
    if not positions:
        raise ValueError("quote does not occur in the recorded text")
    if occurrence is None:
        if len(positions) != 1:
            raise ValueError("repeated quote: supply a longer quote or zero-based occurrence")
        occurrence = 0
    if isinstance(occurrence, bool) or not isinstance(occurrence, int) or not 0 <= occurrence < len(positions):
        raise ValueError("quote occurrence is out of range")
    return SourceSpan(positions[occurrence], positions[occurrence] + len(quote))


def source_role_hints(message):
    """Return conservative structural hints for quoted/pasted source material.

    The host semantic extractor remains responsible for meaning. These spans only
    protect high-confidence source material from the raw-segment fail-safe. An
    explicit semantic requirement may still cite text inside a protected span,
    so user-adopted quoted rules remain actionable.
    """
    if not isinstance(message, str):
        raise ValueError("source role hints require a string message")
    hints = []

    def add(start, end, reason, confidence="high"):
        start, end = int(start), int(end)
        if start < 0 or end <= start or end > len(message):
            return
        span = message[start:end]
        row = {
            "role": "context_candidate",
            "reason": reason,
            "confidence": confidence,
            "start": start,
            "end": end,
            "source_sha256": hashlib.sha256(span.encode("utf-8")).hexdigest(),
            "preview": " ".join(span.split())[:180],
        }
        if not any(x["start"] == start and x["end"] == end and x["reason"] == reason for x in hints):
            hints.append(row)

    # A bare Markdown '>' is formatting, not evidence that the user has stopped
    # speaking in their own voice. Do not silently demote blockquotes. Quoted
    # material becomes context only through an explicit reporting/paste transition
    # or host-semantic context annotation below.

    # A leading blockquote can be source context when the *live tail itself*
    # explicitly refers to it as an answer/quote/source. The punctuation alone
    # never supplies this meaning.
    lines = message.splitlines(keepends=True)
    cursor = 0
    quote_start = quote_end = None
    for line in lines:
        stripped = line.lstrip(" \t")
        if stripped.startswith(">"):
            if quote_start is None:
                quote_start = cursor
            quote_end = cursor + len(line)
        elif quote_start is not None:
            break
        cursor += len(line)
    if quote_start is not None and quote_end is not None and quote_end < len(message):
        tail = message[quote_end:].casefold()
        context_cues = ("이 답변", "저 답변", "위 답변", "예전 답변", "인용된", "이 인용", "quoted answer", "prior answer", "above answer", "this answer")
        if any(cue in tail for cue in context_cues):
            add(quote_start, quote_end, "explicitly_referenced_leading_quote")

    # Long pasted prior material followed by a reporting switch back into the
    # live user voice. The marker must be linguistically strong: a bare '>' is
    # never enough. This covers common Korean and English handoff patterns.
    transition = re.compile(
        r">\s*(?:라는데|라고\s*(?:하는데|했는데|하던데|요구해서|말해서|질문해서|보냈는데|썼는데)|이\s*답변(?:은|이)?|"
        r"this\s+(?:answer|reply)\s+says|it\s+says|according\s+to\s+this)\b",
        re.IGNORECASE,
    )
    matches = list(transition.finditer(message))
    if matches:
        marker = matches[-1]
        prefix = message[:marker.start()]
        tail = message[marker.end():]
        if len(prefix.strip()) >= 240 and len(tail.strip()) >= 4:
            add(0, marker.start(), "reported_or_pasted_prefix_before_live_tail")
            # The reporting marker belongs to the live tail even if it begins
            # with markdown quote syntax.
            hints[:] = [
                x for x in hints
                if not (x.get("reason") == "markdown_blockquote" and x["start"] <= marker.start() < x["end"])
            ]

    hints.sort(key=lambda x: (x["start"], x["end"], x["reason"]))
    return hints


def request_segments(message):
    # Protect fenced/inline code and URLs before considering sentence boundaries.
    protected = [(m.start(), m.end()) for m in re.finditer(
        r"```[\s\S]*?(?:```|$)|~~~[\s\S]*?(?:~~~|$)|`[^`\n]+`|https?://\S+", message)]
    cuts = [0]
    for match in re.finditer(r"\n+|[.!?](?=\s|$)|[。！？]", message):
        if not any(a <= match.start() < b for a, b in protected):
            cuts.append(match.end())
    cuts.append(len(message))
    segments = []
    for a, b in zip(cuts, cuts[1:]):
        while a < b and message[a].isspace():
            a += 1
        while b > a and message[b - 1].isspace():
            b -= 1
        if a < b:
            segments.append({"segment": len(segments) + 1, "text": message[a:b], "start": a, "end": b})
    return segments


def provisional_request_segments(message):
    """Preserve every exact source segment in provisional goal accounting.

    Source-role hints remain available separately. Provisional accounting does
    not grant tool permission and therefore needs no inferred scope subtraction.
    """
    return request_segments(message)


def ensure_accounted(message, spans):
    covered = bytearray(len(message))
    for span in spans:
        span.text(message)
        covered[span.start:span.end] = b"\x01" * (span.end - span.start)
    missing = [i for i, c in enumerate(message) if (c.isalnum() or c == '_') and not covered[i]]
    if missing:
        at = missing[0]
        raise ValueError("unaccounted request text: " + message[max(0, at - 15):at + 65])


def extract_requirements(message, payload):
    """Extract source-grounded requirements without making one output ontology a gate.

    Explicit semantic requirements are used when they are valid. Any request
    segment not covered by a valid explicit requirement/context entry remains a
    first-class raw objective segment instead of causing the intake result to be
    rejected.
    """
    payload = payload if isinstance(payload, dict) else {}
    items = payload.get("requirements", [])
    if not isinstance(items, list):
        items = []
    contexts = payload.get("context", [])
    if not isinstance(contexts, list):
        contexts = []

    segments = request_segments(message)
    proposals = []
    # Account exact source requirements; role annotations stay alongside them.
    # Context annotations and structural guesses remain additive metadata. They
    # never discharge an exact source requirement on the user's behalf.
    accounted = []
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        meaning = item.get("meaning")
        quote = item.get("quote")
        if not isinstance(meaning, str) or not meaning.strip() or not isinstance(quote, str) or not quote:
            continue
        try:
            span = locate_quote(message, quote, item.get("occurrence"))
        except ValueError:
            continue
        overlaps = [seg for seg in segments if span.start < seg["end"] and span.end > seg["start"]]
        if len(overlaps) > 1:
            continue
        proposals.append(IntentProposal(meaning.strip(), (span,), 5, True, "requirement:" + str(i)))
        accounted.append(span)

    # A partial semantic extraction never demotes otherwise-unaccounted blockquotes.
    # Formatting is not evidence of source/context status; explicit context annotations are.

    for item in contexts:
        if not isinstance(item, dict):
            continue
        reason = item.get("reason")
        if not isinstance(reason, str) or not reason.strip():
            continue
        quote = item.get("quote")
        if not isinstance(quote, str) or not quote:
            continue
        try:
            locate_quote(message, quote, item.get("occurrence"))
        except ValueError:
            continue

    def segment_accounted(seg):
        for pos in range(seg["start"], seg["end"]):
            ch = message[pos]
            if not (ch.isalnum() or ch == "_"):
                continue
            if not any(span.start <= pos < span.end for span in accounted):
                return False
        return True

    # The raw request itself remains authoritative source material. Semantic
    # extraction enriches it; it never gets veto power over whether the turn has
    # a live objective.
    for seg in segments:
        if segment_accounted(seg):
            continue
        span = SourceSpan(seg["start"], seg["end"])
        proposals.append(IntentProposal(seg["text"], (span,), 5, True, "raw-segment:" + str(seg["segment"])))
        accounted.append(span)

    if not proposals and message:
        proposals.append(IntentProposal(message, (SourceSpan(0, len(message)),), 5, True, "raw-request"))
    return tuple(proposals)
