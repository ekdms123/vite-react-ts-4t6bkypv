"""Raw user contract and additive intent lattice."""
