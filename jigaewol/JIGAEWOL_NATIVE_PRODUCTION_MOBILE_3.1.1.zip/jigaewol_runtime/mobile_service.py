"""Durable mobile transport over the original USER -> ZIP -> MODEL kernel.

No model state or client-supplied completion flag owns the destination. Each ingress
uses the existing exact-message gateway and causal coordinator. Host models and
tools return observations for the currently pending invocation only.
"""
from __future__ import annotations
import hashlib
import json
import sqlite3
import time
import uuid
from dataclasses import asdict
from pathlib import Path

from jigaewol_components.state_transaction import state_transaction
from jigaewol_components.snapshot_store import save_snapshot, load_snapshot
from jigaewol_core.canonical_entrypoint import admit_exact_user_message
from jigaewol_core.causal_loop import CausalLoopCoordinator
from jigaewol_core.causal_journal import LoopHandle
from jigaewol_core.cognition_port import ReceiptCognitionPort
from jigaewol_core.action_port import ReceiptActionPort, ActionReceiptLedger
from model_host.host_generator import HostGenerationLedger
from jigaewol_core.runtime import CoreRuntime

def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str).encode()).hexdigest()

class MobileRuntimeService:
    def __init__(self, root, *, user_id='owner', adapters=None):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.user_id = str(user_id)
        self.adapters = dict(adapters or {})
        self.db_path = self.root/'mobile.sqlite3'
        with self.db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS turns(id TEXT PRIMARY KEY, scope TEXT, event TEXT, message_sha TEXT, body TEXT, UNIQUE(scope,event));
            CREATE TABLE IF NOT EXISTS events(cursor INTEGER PRIMARY KEY AUTOINCREMENT, turn_id TEXT, kind TEXT, body TEXT);
            CREATE TABLE IF NOT EXISTS observations(turn_id TEXT, event TEXT, sha TEXT, body TEXT, PRIMARY KEY(turn_id,event));
            CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, turn_id TEXT, invocation TEXT, body TEXT, state TEXT, lease REAL, owner TEXT, UNIQUE(turn_id,invocation));
            CREATE TABLE IF NOT EXISTS capabilities(name TEXT PRIMARY KEY, body TEXT);
            CREATE TABLE IF NOT EXISTS effects(turn_id TEXT, invocation TEXT, arguments_sha TEXT, body TEXT, PRIMARY KEY(turn_id,invocation));
            ''')
        self._restore_workbench_adapters()
        adopted=Path(__file__).resolve().parents[1]/'blueprints'/'USER_IMPLEMENTATION_REQUEST.txt'
        if adopted.exists():self._requirements('personal').admit(adopted.read_text())
    def _requirements(self,project_id):
        from jigaewol_components.requirement_ledger import RequirementLedger
        return RequirementLedger(self.root/'personal_memory'/'requirements'/RequirementLedger.project_key(self.user_id,project_id))

    def _restore_workbench_adapters(self):
        from jigaewol_components.capability_workbench import CapabilityWorkbench
        with self.db() as db:rows=db.execute('SELECT name,body FROM capabilities').fetchall()
        for name,body in rows:
            binding=json.loads(body).get('workbench_binding')
            if binding:
                workbench=CapabilityWorkbench(self.root/'personal_memory'/'capability_workbench')
                self.adapters[name]=workbench.make_adapter(binding['candidate_id'],argv=binding['argv'])

    def db(self):
        connection = sqlite3.connect(self.db_path, timeout=30)
        connection.execute('PRAGMA journal_mode=WAL')
        connection.execute('PRAGMA busy_timeout=30000')
        return connection

    def register_configured_adapters(self):
        traits = {"process.run":("code_execution","terminal","filesystem"),
                  "file.read":("filesystem",),"file.write":("filesystem",),
                  "artifact.revise":("filesystem","code_modification"),
                  "search:public_sources":("web_search",),
                  "browser:observe":("browser",),"browser:signed_in_observe":("browser","authenticated_browser"),
                  "search:web_current":("web_search",)}
        for name in self.adapters:
            if name != "cognition":
                self.register_capability(name,traits=traits.get(name,()),effect_class="read" if name.startswith("search:") or name == "file.read" else "write")

    def _turn(self, turn_id):
        with self.db() as db:
            row = db.execute('SELECT body FROM turns WHERE id=?', (turn_id,)).fetchone()
        if not row:
            raise KeyError('unknown turn')
        result=json.loads(row[0])
        # Transport locations are local addresses, not signed user instructions.
        # Reconstruct them from the restored turn identity rather than an old host.
        if result.get('pending_path'):
            result['pending_path']=str(self.root/'transport'/(result['turn_id']+'.json'))
        return result

    def _scope_root(self, row):
        return self.root/'scopes'/row['scope']

    def _event(self, db, turn_id, kind, body):
        db.execute('INSERT INTO events(turn_id,kind,body) VALUES (?,?,?)', (turn_id, kind, json.dumps(body, ensure_ascii=False, default=str)))

    def _save(self, row, *, event):
        with self.db() as db:
            db.execute('UPDATE turns SET body=? WHERE id=?', (json.dumps(row, ensure_ascii=False, default=str), row['turn_id']))
            self._event(db, row['turn_id'], event, {'state': row['state'], 'release_turn_id': row.get('release_turn_id','')})

    def register_capability(self, name, *, traits=(), adapter=None, schema=None, credential_scopes=(), effect_class='read'):
        if adapter:
            self.adapters[str(name)] = adapter
        row = dict(name=str(name), traits=list(traits), input_schema=schema or {'type':'object'},
                   credential_scopes=list(credential_scopes), effect_class=effect_class,
                   execution_state='callable_registered' if str(name) in self.adapters else 'host_dispatch')
        with self.db() as db:
            db.execute('INSERT OR REPLACE INTO capabilities VALUES (?,?)', (str(name), json.dumps(row)))
        return row

    def capabilities(self):
        with self.db() as db:
            rows = [json.loads(x[0]) for x in db.execute('SELECT body FROM capabilities ORDER BY name')]
        return tuple({'executor_id': row['name'], 'capability_id':row['name'], 'name':row['name'], 'traits':row['traits'],
                      'callable':True, 'available':True, 'source':'observed_adapter_registry'} for row in rows)

    def _adapter_name(self,payload):
        operation=str(payload.get('operation') or '')
        executor=str(payload.get('executor') or '')
        aliases={'compute:exec':'process.run','state:write_artifact':'file.write','browser:interact':'browser:observe'}
        if operation in aliases and executor in {'host','process.run','file.read','file.write'}:
            return aliases[operation]
        return executor if executor in self.adapters else aliases.get(operation,operation)

    def execute_action(self, *, turn_id, invocation_id, arguments):
        """Bind one observed effect; retries use the persisted result, never replay it."""
        row = self._turn(turn_id)
        with state_transaction(self.root/'locks'/row['scope']):
            return self._execute_action(turn_id=turn_id,invocation_id=invocation_id,arguments=arguments)

    def _execute_action(self, *, turn_id, invocation_id, arguments):
        row = self._turn(turn_id)
        protected = {'objective','prompt','requirement_ids','requirement_message_sha256','image_generation_governance',
                     'render_action_id','render_observation','selected_route','open_execution_obligation_ids',
                     'open_execution_frontier_ids','semantic_scope_root','origin_goal_sha256','query_program','source_family'}
        if protected.intersection(arguments):
            raise ValueError('execution arguments cannot replace ZIP-owned goal or requirement fields')
        argument_sha = digest(arguments)
        with self.db() as db:
            saved = db.execute('SELECT arguments_sha,body FROM effects WHERE turn_id=? AND invocation=?',(turn_id,invocation_id)).fetchone()
        if saved:
            if saved[0] != argument_sha:
                raise ValueError('effect invocation reused with different arguments')
            effect = json.loads(saved[1])
            if effect['state'] == 'observed':
                return self.observe(turn_id=turn_id,host_event_id='backend:'+invocation_id,observed_result=effect['observation'])
            return {'state':'reconciliation_required','turn_id':turn_id,'invocation_id':invocation_id,
                    'original_goal_preserved':True,'reason':'effect started but its result was not durably observed'}
        pending = load_snapshot(row['pending_path'])
        if pending.get('kind') != 'action' or pending.get('invocation_id') != invocation_id:
            raise ValueError('ZIP has no pending action to execute')
        payload = dict(pending['request_payload'])
        operation = payload.get('operation')
        adapter_name = self._adapter_name(payload)
        if adapter_name not in self.adapters:
            return {'state':'host_dispatch_required','request':pending,'adapter_need':operation,'original_goal_preserved':True}
        work = dict(payload.get('payload') or {})
        params = {**dict(work.get('parameters') or {}), **dict(arguments)}
        work['parameters'] = params
        payload['payload'] = work
        with self.db() as db:
            db.execute('INSERT INTO effects VALUES (?,?,?,?)',(turn_id,invocation_id,argument_sha,json.dumps({'state':'started','adapter':adapter_name,'started_at':time.time()})))
        try:
            result = self.adapters[adapter_name](payload,self._scope_root(row)/'workspace')
        except Exception as exc:
            result = {'success':False,'error_type':type(exc).__name__,'error':str(exc),'effect_state':'reconcile_if_partial'}
        observation = {k:pending[k] for k in ('kind','invocation_id','request_sha256')}
        observation.update(result=result,success=result.get('success') if isinstance(result,dict) else None,
                           executor_id=adapter_name,host_call_observed=True,origin_ref='backend:'+pending['invocation_id'])
        with self.db() as db:
            db.execute('UPDATE effects SET body=? WHERE turn_id=? AND invocation=?',(json.dumps({'state':'observed','observation':observation},ensure_ascii=False,default=str),turn_id,invocation_id))
        return self.observe(turn_id=turn_id,host_event_id='backend:'+pending['invocation_id'],observed_result=observation)

    def candidate(self, *, turn_id, operation, arguments):
        from jigaewol_components.candidate_lab import CandidateLab
        row = self._turn(turn_id)
        lab = CandidateLab(self._scope_root(row)/'candidate_lab',adapters=self.adapters,experience_root=self.root/'personal_memory'/'experiences')
        args = dict(arguments)
        if operation == 'propose':
            args['goal_ref'] = row['message_sha']
            for step in args.get('operator_program',[]):
                if step.get('capability')=='cognition:worker':
                    step['arguments']['objective']=row['exact_message']
                    step['arguments']['representation']=args.get('representation','')
                    step['arguments']['assumptions']=args.get('assumptions',[])
            return lab.propose(**args)
        if operation == 'synthesize':
            return lab.synthesize(row['message_sha'])
        if operation == 'remember':
            lab.require_goal(args['candidate_id'],row['message_sha'])
            return lab.remember(**args) or {'state':'experience_saved'}
        if operation == 'run':
            candidate_id = args['candidate_id']
            lab.require_goal(candidate_id,row['message_sha'])
            # Task-effect scoring follows actual adapter return values. Quality and
            # preference remain independent subsequent observers, not fabricated 9s.
            return lab.run(candidate_id,observer='backend_adapter_results',score_result=lambda results:{
                'execution_effect':float(bool(results) and all(isinstance(x['result'],dict) and x['result'].get('success') is True for x in results))})
        if operation == 'run_batch':
            candidate_ids = args['candidate_ids']
            for cid in candidate_ids: lab.require_goal(cid,row['message_sha'])
            return lab.run_batch(candidate_ids,max_workers=args.get('max_workers',4),observer='independent_backend_workers')
        raise ValueError('unknown candidate operation')

    def capability(self, *, turn_id, operation, arguments):
        from jigaewol_components.capability_workbench import CapabilityWorkbench
        workbench=CapabilityWorkbench(self.root/'personal_memory'/'capability_workbench')
        row=self._turn(turn_id);args=dict(arguments)
        if operation=='discover':return workbench.discover(**args)
        if operation in {'inspect','fetch'}:
            args['need_ref']=row['message_sha']
            if operation=='inspect':
                source=Path(args['source']).resolve()
                if not source.is_relative_to(self._scope_root(row)/'workspace'):
                    raise ValueError('local inspection source must be in this task workspace')
            return getattr(workbench,operation)(**args)
        if operation=='authorize':
            import re
            source=row['exact_message']
            denied=bool(re.search(r'(?:승인|설치|연결|실행).{0,8}(?:하지\s*마|하지\s*말|금지|안\s*해|안\s*돼)|do not.{0,15}(?:install|connect|approve)',source,re.I))
            if denied or not re.search(r'승인|설치해|설치하|연결해|연결하|실행해|approve|install|connect',source,re.I):
                raise ValueError('package connection needs the user approval message in this chat')
            # The server supplies the stored user message, never a model-authored grant.
            return workbench.authorize(args['candidate_id'],exact_user_directive=row['exact_message'],
                reviewed_execution=bool(re.search(r'내가.{0,10}(작성|검토)|reviewed by me|my own code',row['exact_message'],re.I)))
        if operation in {'get','materialize','probe'}:return getattr(workbench,operation)(**args)
        if operation=='bind':
            traits=args.pop('traits',('code_execution',))
            adapter,metadata=workbench.bind(**args)
            self.register_capability(args['capability_name'],adapter=adapter,traits=traits,effect_class='write')
            with self.db() as db:
                capability=json.loads(db.execute('SELECT body FROM capabilities WHERE name=?',(args['capability_name'],)).fetchone()[0])
                capability['workbench_binding']=args
                db.execute('UPDATE capabilities SET body=? WHERE name=?',(json.dumps(capability),args['capability_name']))
            return metadata
        raise ValueError('unknown capability operation')

    def policy(self, *, turn_id, operation, arguments):
        from jigaewol_components.mutable_policy_evolution import MutablePolicyEvolution
        from jigaewol_components.candidate_lab import CandidateLab
        row=self._turn(turn_id);args=dict(arguments)
        evo=MutablePolicyEvolution(self.root/'personal_memory'/'policy_evolution'/'candidates')
        if operation=='propose':
            args.setdefault('provenance',{})['exact_goal_sha256']=row['message_sha']
            return asdict(evo.propose(**args))
        if operation=='evaluate':
            program_id=args['program_candidate_id'];policy_id=args['candidate_id']
            lab=CandidateLab(self._scope_root(row)/'candidate_lab')
            lab.require_goal(program_id,row['message_sha'])
            program=next((p for p in lab.candidates(row['message_sha']) if p['candidate_id']==program_id),None)
            if not program or policy_id not in program['ancestry']:
                raise ValueError('policy evaluation needs a genuinely executed program carrying this policy revision')
            for ref in program['evidence_refs']:lab.evidence.resolve(ref)
            ref=evo.observations.record(case_id=row['message_sha'],subject_ref=policy_id,scores=program['scores'],
                artifacts=program['artifact_refs'],observer='executed_candidate_program:'+program_id)
            return asdict(evo.evaluate(candidate_id=policy_id,case_id=row['message_sha'],scores=program['scores'],evidence_refs=[ref]))
        if operation=='promote':return asdict(evo.promote(**args))
        if operation=='rollback':return evo.rollback(**args)
        if operation=='active':return evo.active_revision(args['family']) or {}
        raise ValueError('unknown policy operation')

    def begin(self, *, exact_message, host_event_id, project_id='personal', session_id='mobile', attachments=()):
        if not exact_message or not host_event_id:
            raise ValueError('exact_message and unique host_event_id are required')
        scope = digest([self.user_id, str(project_id), str(session_id)])
        message_sha = hashlib.sha256(str(exact_message).encode()).hexdigest()
        self._requirements(str(project_id)).admit(str(exact_message))
        turn_id = 'mobile_'+uuid.uuid4().hex
        row = dict(turn_id=turn_id, scope=scope, user_id=self.user_id, project_id=str(project_id),
                   session_id=str(session_id), exact_message=str(exact_message), message_sha=message_sha,
                   host_event_id=str(host_event_id), attachments=list(attachments), state='ingress_pending', created_at=time.time())
        with state_transaction(self.root/'locks'/scope):
            with self.db() as db:
                existing = db.execute('SELECT body,message_sha FROM turns WHERE scope=? AND event=?', (scope,str(host_event_id))).fetchone()
                if existing:
                    if existing[1] != message_sha:
                        raise ValueError('host event reused with a different exact message')
                    row = json.loads(existing[0])
                else:
                    db.execute('INSERT INTO turns VALUES (?,?,?,?,?)', (turn_id,scope,str(host_event_id),message_sha,json.dumps(row,ensure_ascii=False)))
                    self._event(db, turn_id, 'ingress_recorded', {'message_sha':message_sha})
            if row['state'] == 'ingress_pending':
                state_root = self._scope_root(row)
                admission = admit_exact_user_message(state_root=state_root, raw_message_bytes=row['exact_message'].encode(),
                    user_id=self.user_id, project_id=row['project_id'], session_id=row['session_id'], origin_ref='mobile:'+row['host_event_id'])
                row['gateway_envelope'] = admission['gateway_envelope']
                row['state'] = 'admitted'
                self._save(row, event='gateway_admitted')
            if row['state'] == 'admitted':
                self._drive(row)
        return self.next(row['turn_id'])

    def _drive(self, row, observed=None, *, recovery=False):
        state_root = self._scope_root(row)
        runtime = CoreRuntime(state_root, user_id=self.user_id, project_id=row['project_id'], session_id=row['session_id'],
            capabilities=self.capabilities(), host_attachments=row.get("attachments",()), policy_root=self.root/"personal_memory", require_gateway_turn=True, gateway_envelope=row['gateway_envelope'])
        coordinator = CausalLoopCoordinator(state_root/'causal_loop')
        ports = dict(runtime=runtime, cognition_port=ReceiptCognitionPort(HostGenerationLedger(state_root/'host_generation')),
                     action_port=ReceiptActionPort(ActionReceiptLedger(state_root/'causal_action_receipts')),
                     message=row['exact_message'], capabilities=self.capabilities(), raw_message_bytes=row['exact_message'].encode())
        if recovery:
            outcome = coordinator._drive(handle=LoopHandle(**row['loop_handle']), **ports)
        elif observed is None:
            outcome = coordinator.run_until_blocked(**ports)
        else:
            outcome = coordinator.resume(handle=LoopHandle(**row['loop_handle']), observed_result=observed, **ports)
        row['state'] = outcome.status
        row['loop_handle'] = asdict(outcome.handle)
        row['release_turn_id'] = outcome.handle.turn_id
        row['causal_head_sha256'] = outcome.state.causal_head_sha256
        row['pending_path'] = str(self.root/'transport'/(row['turn_id']+'.json'))
        save_snapshot(row['pending_path'], dict(outcome.pending or {}))
        if outcome.released:
            row['delivered_body'] = str(outcome.released.body)
        row['runtime_digest'] = runtime.active_artifact_integrity.get('content_set_sha256','')
        self._save(row, event='kernel_transition')
        self._enqueue(row)

    def next(self, turn_id, event_cursor=0):
        row = self._turn(turn_id)
        pending = load_snapshot(row['pending_path']) if row.get('pending_path') else {}
        with self.db() as db:
            events = [{'cursor':x[0], 'kind':x[1], **json.loads(x[2])} for x in db.execute('SELECT cursor,kind,body FROM events WHERE turn_id=? AND cursor>? ORDER BY cursor', (turn_id,int(event_cursor)))]
        production=None
        if row['state']=='INCOMPLETE':
            from jigaewol_components.turn_production import TurnProduction
            production=TurnProduction(self._scope_root(row)/'turn_production',adapters=self.adapters).begin(
                row['exact_message'],row.get('release_turn_id') or row['turn_id'])
        return dict(turn_id=turn_id, state=row['state'], authority=['USER','JIGAEWOL','MODEL'],
                    active_runtime_digest=row.get('runtime_digest',''), message_sha256=row['message_sha'],
                    request=pending, events=events, next_cursor=events[-1]['cursor'] if events else int(event_cursor),
                    deliverable=row.get('delivered_body'), attachments=row['attachments'],
                    production_request=production,task_continuation_required=row['state']=='INCOMPLETE')

    def requirement(self, *, turn_id, operation='status', arguments=None):
        row=self._turn(turn_id);args=dict(arguments or {})
        ledger=self._requirements(row['project_id'])
        if operation=='status':return ledger.status(row['message_sha'])
        if operation!='account':raise ValueError('unknown requirement operation')
        observation_id=args.pop('observation_event_id','')
        if args.get('state')=='effect_observed':
            with self.db() as db:saved=db.execute('SELECT body FROM observations WHERE turn_id=? AND event=?',(turn_id,observation_id)).fetchone()
            if not saved or not json.loads(saved[0]).get('applied'):raise ValueError('requirement needs an applied current-turn observation')
            args['observed_effect']=json.loads(saved[0])['result']
        if args.get('state')=='response_addressed':args['response_text']=row.get('delivered_body','')
        if args.get('state')=='superseded_by_user':raise ValueError('supersession uses a new exact user message, not a model account')
        args.pop('response_text',None) if args.get('state')!='response_addressed' else None
        return ledger.account(row['message_sha'],**args)

    def observe(self, *, turn_id, host_event_id, observed_result):
        row = self._turn(turn_id)
        value = dict(observed_result)
        if value.get('kind') == 'action':
            from jigaewol_core.execution_truth import classify_execution_result
            actual_success = classify_execution_result(value.get('result')).successful
            if value.get('success') is True and actual_success is False:
                raise ValueError('success label contradicts observed action failure')
            if 'success' not in value:
                value['success'] = actual_success
        event = str(host_event_id)
        if not event:
            raise ValueError('observation host_event_id required')
        with state_transaction(self.root/'locks'/row['scope']):
            row = self._turn(turn_id)
            existing = None
            with self.db() as db:
                existing = db.execute('SELECT sha,body FROM observations WHERE turn_id=? AND event=?', (turn_id,event)).fetchone()
                if existing:
                    if existing[0] != digest(value):
                        raise ValueError('observation event reused with different result')
                    # Receipt already persisted; never dispatch the external effect twice.
                    row = self._turn(turn_id)
                    if json.loads(existing[1]).get('applied'):
                        return self.next(turn_id)
            if existing and self._observation_in_journal(row,value):
                self.resume(turn_id)
                with self.db() as db:
                    db.execute('UPDATE observations SET body=? WHERE turn_id=? AND event=?',(json.dumps({'result':value,'applied':True},ensure_ascii=False,default=str),turn_id,event))
                    db.execute("UPDATE jobs SET state='done',lease=0 WHERE turn_id=? AND invocation=?",(turn_id,value['invocation_id']))
                return self.next(turn_id)
            row = self._turn(turn_id)
            pending = load_snapshot(row['pending_path'])
            for field in ('kind','invocation_id','request_sha256'):
                if value.get(field) != pending.get(field):
                    raise ValueError('observation does not match pending '+field)
            if not existing:
                with self.db() as db:
                    db.execute('INSERT INTO observations VALUES (?,?,?,?)', (turn_id,event,digest(value),json.dumps({'result':value,'applied':False},ensure_ascii=False,default=str)))
            self._drive(row, value)
            with self.db() as db:
                db.execute('UPDATE observations SET body=? WHERE turn_id=? AND event=?', (json.dumps({'result':value,'applied':True},ensure_ascii=False,default=str),turn_id,event))
                db.execute("UPDATE jobs SET state='done', lease=0 WHERE turn_id=? AND invocation=?", (turn_id,value['invocation_id']))
        return self.next(turn_id)

    def _observation_in_journal(self, row, value):
        if not row.get('loop_handle'): return False
        coordinator = CausalLoopCoordinator(self._scope_root(row)/'causal_loop')
        head = coordinator.journal.current(LoopHandle(**row['loop_handle']))
        path = coordinator.journal._turn_path(head.turn_id)
        for line in path.read_text().splitlines():
            transition = json.loads(line).get('transition') or {}
            receipt = transition.get('cognition_receipt') or transition.get('action_receipt') or {}
            if receipt.get('invocation_id') == value.get('invocation_id') and receipt.get('request_sha256') == value.get('request_sha256'):
                return True
        return False

    def resume(self, turn_id, event_cursor=0):
        row = self._turn(turn_id)
        # Restores the durable cursor and requeues an unfinished provider-independent
        # invocation. A lost process is never interpreted as completed work.
        with state_transaction(self.root/'locks'/row['scope']):
            coordinator = CausalLoopCoordinator(self._scope_root(row)/'causal_loop')
            if not row.get('loop_handle'):
                from jigaewol_components.snapshot_store import load_snapshot
                for path in (self._scope_root(row)/'core_turns').glob('*.json'):
                    snapshot = load_snapshot(path)
                    if snapshot.get('gateway_turn_id') == row.get('gateway_envelope',{}).get('gateway_turn_id'):
                        row['loop_handle'] = asdict(coordinator.journal.issue_handle(snapshot['release_turn_id']))
                        break
            if row.get('loop_handle'):
                head = coordinator.journal.current(LoopHandle(**row['loop_handle']))
                if head.state.get('terminal'):
                    sha = str(head.state.get('candidate_sha256') or '')
                    blob = self._scope_root(row)/'response_sink'/'cas'/'sha256'/sha[:2]/sha
                    body = blob.read_text()
                    if hashlib.sha256(body.encode()).hexdigest() != sha:
                        raise ValueError('published response changed during recovery')
                    row['state'] = 'COMPLETED' if head.state.get('terminal_semantics') == 'SOLVED' else 'INCOMPLETE'
                    row['delivered_body'] = body
                    row['causal_head_sha256'] = head.causal_head_sha256
                    self._save(row,event='published_response_restored')
                elif head.causal_head_sha256 != row.get('causal_head_sha256'):
                    self._drive(row,recovery=True)
            self._enqueue(row)
        return self.next(turn_id, event_cursor)

    def publish(self, turn_id):
        row = self._turn(turn_id)
        if row['state'] not in {'COMPLETED','INCOMPLETE'} or not row.get('delivered_body'):
            raise ValueError('canonical publication is still pending')
        return {'turn_id':turn_id,'body':row['delivered_body'],'sha256':hashlib.sha256(row['delivered_body'].encode()).hexdigest(),
                'state':row['state'],'goal_completed':row['state']=='COMPLETED',
                'continuation_required':row['state']=='INCOMPLETE'}

    def _enqueue(self, row):
        if not row.get('pending_path'):
            return
        pending = load_snapshot(row['pending_path'])
        if not pending.get('invocation_id'):
            return
        payload = pending.get('request_payload') or {}
        executor = str(payload.get('executor') or '')
        adapter = 'cognition' if pending.get('kind') == 'cognition' else self._adapter_name(payload)
        if adapter not in self.adapters:
            return
        from .mobile_adapters import parameters
        args = parameters(payload)
        if adapter == 'process.run' and not args.get('argv'): return
        if adapter == 'file.write' and not any(k in args for k in ('content','body')): return
        if adapter.startswith('browser:') and not (args.get('steps') or args.get('url')):return
        job_id = digest([row['turn_id'],pending['invocation_id']])
        with self.db() as db:
            db.execute('INSERT OR IGNORE INTO jobs VALUES (?,?,?,?,?,?,?)', (job_id,row['turn_id'],pending['invocation_id'],json.dumps({'adapter':adapter}), 'pending',0,''))

    def work_once(self, *, owner=None, lease_seconds=300):
        owner = owner or uuid.uuid4().hex
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            job = db.execute("SELECT id,turn_id,invocation,body FROM jobs WHERE state='pending' ORDER BY rowid LIMIT 1").fetchone()
            if not job:
                return False
            db.execute("UPDATE jobs SET state='running',owner=?,lease=? WHERE id=?", (owner,time.time()+lease_seconds,job[0]))
        row = self._turn(job[1])
        pending = load_snapshot(row['pending_path'])
        adapter = self.adapters[json.loads(job[3])['adapter']]
        if pending.get('invocation_id') != job[2]:
            with self.db() as db: db.execute("UPDATE jobs SET state='obsolete',lease=0 WHERE id=?",(job[0],))
            return True
        import threading
        stop = threading.Event()
        def heartbeat():
            while not stop.wait(max(0.05,lease_seconds/3)):
                with self.db() as db:
                    db.execute("UPDATE jobs SET lease=? WHERE id=? AND owner=? AND state='running'",(time.time()+lease_seconds,job[0],owner))
        thread = threading.Thread(target=heartbeat,daemon=True);thread.start()
        try:
            if pending['kind'] == 'action':
                self.execute_action(turn_id=job[1],invocation_id=pending['invocation_id'],arguments={})
                return True
            result = adapter(pending['request_payload'], self._scope_root(row)/'workspace')
            observation = {key:pending[key] for key in ('kind','invocation_id','request_sha256')}
            observation['origin_ref'] = 'mobile-worker:'+job[0]
            if pending['kind'] == 'cognition':
                observation['body'] = str(result)
            else:
                observation.update(result=result, success=result.get('success') if isinstance(result,dict) else None,
                                   host_call_observed=True, executor_id=json.loads(job[3])['adapter'])
            self.observe(turn_id=job[1], host_event_id='job:'+job[0], observed_result=observation)
        except Exception as exc:
            capability_name = json.loads(job[3])['adapter']
            with self.db() as db:
                detail = json.loads(job[3]);detail['failures'] = int(detail.get('failures',0))+1
                detail['next_attempt_at'] = time.time()+min(60,2**min(detail['failures'],6))
                capability = db.execute('SELECT body FROM capabilities WHERE name=?',(capability_name,)).fetchone()
                effect = json.loads(capability[0]).get('effect_class') if capability else None
                state = 'retry_pending' if capability_name=='cognition' or effect=='read' else 'reconciliation_required'
                db.execute('UPDATE jobs SET state=?,lease=0,body=? WHERE id=?',(state,json.dumps(detail),job[0]))
                self._event(db,job[1],'worker_route_failed',{'error_type':type(exc).__name__,'error':str(exc),'job_id':job[0]})
        finally:
            stop.set();thread.join(timeout=1)
        return True

    def recover_jobs(self):
        # External effects with an expired lease require reconciliation, not blind
        # automatic replay. Pure cognition/read work can safely be requeued.
        with self.db() as db:
            for job_id, body in db.execute("SELECT id,body FROM jobs WHERE state='retry_pending'").fetchall():
                if json.loads(body).get('next_attempt_at',0)<=time.time():
                    db.execute("UPDATE jobs SET state='pending' WHERE id=?",(job_id,))
            jobs = list(db.execute("SELECT id,body FROM jobs WHERE state='running' AND lease<?", (time.time(),)))
            for job_id, body in jobs:
                adapter = json.loads(body)['adapter']
                capability = db.execute('SELECT body FROM capabilities WHERE name=?',(adapter,)).fetchone()
                effect = json.loads(capability[0]).get('effect_class') if capability else None
                state = 'pending' if adapter == 'cognition' or effect == 'read' else 'reconciliation_required'
                db.execute('UPDATE jobs SET state=?,lease=0 WHERE id=?',(state,job_id))
        return len(jobs)
