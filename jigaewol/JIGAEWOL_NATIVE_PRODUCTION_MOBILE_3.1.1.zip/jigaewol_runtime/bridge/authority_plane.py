"""User > Jigaewol > model authority plane with orthogonal truth state."""
from __future__ import annotations
from copy import deepcopy

from jigaewol_core.authority_kernel import authority_kernel_snapshot

PLANE_ID = "jigaewol-user-authority-v4"
RELATION = "user_directive_runtime_delegation_model_material"

AUTHORITY_PLANE = {
    "plane_id": PLANE_ID,
    "relation": RELATION,
    "hierarchy": ["USER", "JIGAEWOL", "MODEL"],
    "user": {
        "role": "directive_owner",
        "owns": [
            "objective", "requirements", "constraints", "style", "priority", "stop_or_change",
            "representation", "route", "search", "tool_composition", "scheduling", "state", "repair",
        ],
        "explicit_means_override_derived_means": True,
        "requirement_lifecycle": "live_until_delivered_or_user_changes_it",
    },
    "jigaewol": {
        "role": "delegated_execution_and_cognition_instrument",
        "owns": [],
        "derives_or_operates": ["representation", "route", "search", "tool_composition", "scheduling", "state", "repair"],
        "delegation_is_revocable_by_current_user_directive": True,
        "route_posture": "expand_or_replace",
        "architecture_posture": "replaceable",
    },
    "model": {
        "role": "replaceable_cognitive_material",
        "outputs": ["hypotheses", "candidate_plans", "candidate_language", "reframes"],
    },
    "truth": {
        "role": "orthogonal_observation_ledger",
        "owns": ["observed_fact", "execution_truth"],
        "facts": "evidence_labeled",
        "execution": "receipt_labeled",
    },
    "kernel": authority_kernel_snapshot(),
}


def authority_plane_snapshot() -> dict:
    return deepcopy(AUTHORITY_PLANE)


def compact_authority_plane_snapshot() -> dict:
    return deepcopy(AUTHORITY_PLANE)


def authority_owner(domain: str) -> str:
    """Return directive authority, not the component currently performing the work.

    Jigaewol may derive or execute means under delegation, but performing/deriving a
    method never turns the runtime into the owner of that method. Observation-bound
    truth remains orthogonal and is represented by the truth ledger rather than by
    this directive-authority helper.
    """
    key = str(domain or "").strip()
    if key in set(AUTHORITY_PLANE["truth"].get("owns", ())):
        return "OBSERVATION"
    return "USER"


def is_peer_plane(value) -> bool:
    return isinstance(value, dict) and value.get("relation") == RELATION
