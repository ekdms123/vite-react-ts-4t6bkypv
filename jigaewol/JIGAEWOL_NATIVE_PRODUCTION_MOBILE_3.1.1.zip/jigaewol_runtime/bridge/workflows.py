"""Live hypothesis, research, selection, creation and reconstruction handlers."""
import json
import math
from copy import deepcopy
from dataclasses import asdict, replace

from jigaewol_runtime.worlds.generation import (
    WorldProposal, ProblemFrame, admit_worlds, generate_worlds, branch_packet,
    revision_spec_from_value, mechanism_pattern_from_value,
)
from jigaewol_runtime.compiler.compile import is_search_capability
from jigaewol_runtime.cognition import compiled_kernel_packet, validate_cognitive_program
from jigaewol_runtime.cognition.epoch import delta_instruction
from jigaewol_runtime.cognition.impact import consume_pending_observations
from jigaewol_runtime.cognition.evidence_graph import build_evidence_graph, apply_evidence_graph_delta, graph_summary
from jigaewol_runtime.cognition.structures import evaluate_trigger_condition, merge_generative_world, validate_step_references
from jigaewol_runtime.operators.spec import OperatorSpec
from jigaewol_runtime.operators.registry import OperatorRegistry
from jigaewol_runtime.operators.generated import validate_generated_operator, apply_generated_operator
from jigaewol_runtime.research.claims import Claim
from jigaewol_runtime.research.frontier import ResearchFrontier, apply_evidence
from jigaewol_runtime.research.routing import route_search_branches
from jigaewol_runtime.bridge.route_resilience import route_signature
from jigaewol_runtime.realization.creative import creative_state_from, apply_creative_choice
from jigaewol_runtime.realization.editing import apply_text_edits
from jigaewol_runtime.feedback.workflow import FeedbackWorkflow
from jigaewol_runtime.bridge.exploration import ExplorationMixin, hinge_in
from jigaewol_runtime.exploration.transfers import compile_transfer_plans
from jigaewol_runtime.realization.creative_compiler import compile_creative_program as compile_creative_contract
from jigaewol_runtime.adaptation.search_strategy import normalize_search_plan, mark_interpreted

MATERIAL = {"chat.respond", "material.realize", "creative.realize", "code.realize", "deliver"}
SEMANTIC = MATERIAL | {"quality.inspect", "cognition.compile", "cognition.delta", "worlds.generate", "worlds.realize", "research.plan", "research.interpret", "trajectories.propose", "trajectories.rewrite", "runtime.reconstruct", "capability.acquire", "feedback.design", "feedback.review", "methods.interpret", "integration.install"}


def _bool_field(payload, key, default=False):
    if key not in payload:
        return bool(default)
    value = payload[key]
    if not isinstance(value, bool):
        raise ValueError(key + " must be boolean")
    return value


def _object_sequence(payload, key, *, default=()):
    value = payload.get(key, default)
    if value is None:
        return ()
    if not isinstance(value, (list, tuple)):
        raise ValueError(key + " must be a list of objects")
    if any(not isinstance(item, dict) for item in value):
        raise ValueError(key + " entries must be objects")
    return value


def _finite_signal(value, default=0.0):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return float(default)
    number = float(value)
    return number if math.isfinite(number) else float(default)


def _text_field(payload, key, default=""):
    if key not in payload:
        return default
    value = payload[key]
    if not isinstance(value, str):
        raise ValueError(key + " must be text")
    return value


def _text_sequence_field(payload, key):
    value = payload.get(key, ())
    if value is None:
        return ()
    if not isinstance(value, (list, tuple)) or any(not isinstance(item, str) for item in value):
        raise ValueError(key + " must be a list of text values")
    return tuple(value)


class WorkflowMixin(ExplorationMixin, FeedbackWorkflow):
    def _register_operators(self, runtime, payload):
        specs = dict(runtime.extensions.get("operators", {}))
        registry = OperatorRegistry()
        for value in specs.values():
            registry.register(OperatorSpec(**{**value, "applicability": tuple(value.get("applicability", ())), "steps": tuple(value.get("steps", ())) }))
        for data in _object_sequence(payload, "operators"):
            raw_cost = data.get("cost_hint", .1)
            if isinstance(raw_cost, bool):
                raise ValueError("operator cost_hint must be a finite nonnegative number")
            try:
                cost_hint = float(raw_cost)
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError("operator cost_hint must be a finite nonnegative number") from exc
            spec = OperatorSpec(
                str(data["operator_id"]), str(data.get("input_schema", "proposed_structure")),
                str(data.get("output_schema", "proposed_structure")), tuple(data.get("applicability", ())),
                str(data["transformation_claim"]), str(data.get("verifier", "literal_structure_change")),
                cost_hint, "host_proposed", tuple(data.get("steps", ())))
            validate_generated_operator(spec)
            if spec.operator_id in specs:
                if json.dumps(specs[spec.operator_id], sort_keys=True) != json.dumps(asdict(spec), sort_keys=True):
                    raise ValueError("use a new operator id for a changed recipe")
            else:
                registry.register(spec)
            specs[spec.operator_id] = asdict(spec)
        runtime.extensions["operators"] = specs

    def _world_result(self, runtime, node, payload):
        """Accept task-native world representations without a fixed world ontology."""
        rows = payload.get("worlds") if isinstance(payload, dict) else None
        if rows is None and isinstance(payload, dict):
            rows = payload.get("representations")
        if rows is None:
            rows = [deepcopy(payload)] if isinstance(payload, dict) and payload else []
        if not isinstance(rows, list):
            rows = [rows]

        proposals = []
        for raw in rows:
            item = deepcopy(raw) if isinstance(raw, dict) else {"representation": deepcopy(raw)}
            if "problem_unit" in item:
                problem_unit = _text_field(item, "problem_unit")
            elif "problem" in item:
                problem_unit = _text_field(item, "problem")
            else:
                problem_unit = _text_field(item, "idea") if "idea" in item else ""
            causal_model = _text_field(item, "causal_model") if "causal_model" in item else (_text_field(item, "causal") if "causal" in item else "")
            mechanism_family = _text_field(item, "mechanism_family") if "mechanism_family" in item else (_text_field(item, "mechanism") if "mechanism" in item else "")
            proposals.append(WorldProposal(
                problem_unit=problem_unit,
                causal_model=causal_model,
                mechanism_family=mechanism_family,
                assumptions=_text_sequence_field(item, "assumptions"),
                predicted_observations=_text_sequence_field(item, "predicted_observations"),
                discriminating_questions=_text_sequence_field(item, "discriminating_questions"),
                expected_material_effects=_text_sequence_field(item, "expected_material_effects"),
                representation=item,
            ))

        if proposals:
            runtime.worlds = admit_worlds(proposals, runtime.lattice)
            refs = tuple(w.world_id for w in runtime.worlds)
            runtime.program = replace(runtime.program, world_refs=refs, nodes=tuple(
                replace(n, world_refs=refs) if n.status != "done" and n.node_id != node.node_id else n for n in runtime.program.nodes))
        else:
            refs = tuple(w.world_id for w in runtime.worlds)

        self._register_operators(runtime, payload)
        self._compile_exploration(runtime, payload)
        return runtime.ledger.add_observation({
            "worlds": [asdict(w) for w in runtime.worlds],
            "accepted_representation": deepcopy(payload),
            "representation_policy": "task_native_open_set",
        }, world_refs=refs)

    def _world_branch_result(self, runtime, node, payload):
        """Bind one isolated generated representation to its semantic realization."""
        if not isinstance(payload, dict):
            raise ValueError("worlds.realize result must be an object")
        params = dict(node.parameters)
        packet = params.get("cognition_generation_branch")
        if not isinstance(packet, dict):
            raise ValueError("worlds.realize requires a generated branch packet")
        branch_id = str(packet.get("branch_id", "")).strip()
        if not branch_id:
            raise ValueError("generated branch packet is missing branch_id")
        mechanism = str(payload.get("mechanism", "")).strip()
        if not mechanism:
            raise ValueError("worlds.realize must return a concrete mechanism")
        def texts(name):
            raw = payload.get(name, ()) or ()
            if isinstance(raw, str):
                raw = (raw,)
            if not isinstance(raw, (list, tuple)):
                raise ValueError(name + " must be text or a list of text")
            return [str(x).strip() for x in raw if str(x).strip()]
        row = {
            "branch_id": branch_id,
            "isolation_token": str(packet.get("isolation_token", "")),
            "mechanism": mechanism,
            "actions": texts("actions"),
            "assumptions": texts("assumptions"),
            "falsifier": str(payload.get("falsifier", "")).strip(),
            "expected_effect": str(payload.get("expected_effect", "")).strip(),
            "representation": deepcopy(packet.get("representation", {})),
            "semantic_payload": deepcopy(payload),
        }
        group = str(params.get("_jigaewol_parallel_group", "world_generation"))
        runtime.extensions.setdefault("world_branch_results", {}).setdefault(group, {})[branch_id] = deepcopy(row)
        return runtime.ledger.add_observation({"cognition_generation_branch_result": row}, world_refs=(branch_id,))

    def _split_parallel_batch(self, runtime, nodes):
        """Return prefix, first safe parallel batch, and suffix.

        Parallelism is an execution optimization, not a reasoning requirement.
        Only nodes carrying the exact same runtime batch marker are fanned out.
        """
        first = None
        group = None
        for i, n in enumerate(nodes):
            params = dict(n.parameters)
            g = str(params.get("_jigaewol_parallel_group", "")).strip()
            if g and params.get("_jigaewol_parallel_safe") is True:
                first, group = i, g
                break
        if first is None:
            return tuple(nodes), (), (), None
        batch = []
        j = first
        while j < len(nodes):
            params = dict(nodes[j].parameters)
            if str(params.get("_jigaewol_parallel_group", "")).strip() != group or params.get("_jigaewol_parallel_safe") is not True:
                break
            batch.append(nodes[j]); j += 1
        if len(batch) < 2:
            return tuple(nodes), (), (), None
        return tuple(nodes[:first]), tuple(batch), tuple(nodes[j:]), group

    def _install_epoch_nodes(self, runtime, node, built, *, required=True):
        remaining = [n for n in runtime.program.nodes if n.status == "pending" and n.node_id != node.node_id]
        target = next((n for n in remaining if n.operation in MATERIAL), None)
        closure = next((n for n in remaining if n.operation == "closure.check"), None)
        if not built:
            return
        suffix = list(built)
        if target is not None:
            suffix.append(target)
        if closure is not None:
            suffix.append(closure)
        if not suffix:
            return
        prefix, parallel, tail, group = self._split_parallel_batch(runtime, suffix)
        ids = tuple(n.node_id for n in remaining)
        if parallel:
            join = self._node(runtime, "host_semantic", "cognition.delta", intents=runtime.program.objective_refs,
                parameters={
                    "instruction": delta_instruction(),
                    "observation_group": group,
                    "batch_operations": [n.operation for n in parallel],
                    "_jigaewol_batch_join": True,
                })
            self._replace_pending_parallel(runtime, ids, prefix, parallel, join, tail,
                                           count_rewrite=True, required=required)
        else:
            self._replace_pending(runtime, ids, suffix, count_rewrite=True, required=required)

    def _cognition_result(self, runtime, node, payload):
        """Compile one adaptive semantic epoch.

        Frames and routes are runtime-owned working state. The host may create,
        revise, merge or discard them without a predeclared route count or gain
        threshold deciding whether the exploration is allowed to exist.
        """
        meta = dict(runtime.program.metadata)
        kernel_packet = compiled_kernel_packet(
            runtime.extensions.get("external_kernel"),
            domain=str(meta.get("domain", "general")),
            depth_class=str(meta.get("mode", "standard")),
        )
        payload = validate_cognitive_program(payload, kernel_packet)

        # Generative-world state used to be read by visibility and artifact
        # trigger paths without ever being written. Reconnect that dormant
        # contract as an optional, validated, open-set state update.
        generative_world = merge_generative_world(
            runtime.extensions.get("generative_world"), payload.get("generative_world")
        )
        reference_view = {**generative_world, "steps": payload.get("steps", [])}
        validate_step_references(reference_view)
        if payload.get("generative_world") is not None or runtime.extensions.get("generative_world") is not None:
            runtime.extensions["generative_world"] = generative_world

        # Cross-domain transfer is executable structure, not a note. Compile any
        # supplied transfer plans into validated operators and integrate them into the
        # live operator registry for subsequent trajectory/material work.
        if payload.get("transfer_plans") is not None:
            compiled_transfers = compile_transfer_plans(payload.get("transfer_plans"))
            operator_store = dict(runtime.extensions.get("operators", {}))
            stored_transfers = []
            for row in compiled_transfers:
                stored = deepcopy(row)
                spec = row.get("operator")
                if spec is not None:
                    validate_generated_operator(spec)
                    encoded = asdict(spec)
                    existing = operator_store.get(spec.operator_id)
                    if existing is not None and json.dumps(existing, sort_keys=True, allow_nan=False) != json.dumps(encoded, sort_keys=True, allow_nan=False):
                        raise ValueError("transfer operator id already exists with different structure")
                    operator_store[spec.operator_id] = encoded
                    stored["operator"] = encoded
                stored_transfers.append(stored)
            runtime.extensions["operators"] = operator_store
            runtime.extensions["transfer_plans"] = stored_transfers

        creative_contract = None
        has_creative_state = payload.get("creative_state") is not None
        if payload.get("creative_program") is not None:
            creative_contract = compile_creative_contract(payload.get("creative_program"))
            runtime.extensions["creative_contract"] = deepcopy(creative_contract)
            runtime.extensions["creative_state"] = deepcopy(creative_contract.get("state_after", {}))
        elif has_creative_state:
            runtime.extensions["creative_state"] = asdict(creative_state_from(payload.get("creative_state")))

        if creative_contract is not None or has_creative_state:
            # Creative realization is selected by actual semantic output, never
            # by a magic mode string. Retarget only the generic material path so
            # a task-specific executor such as code.realize is not overwritten.
            def bind_creative(n):
                if n.status != "pending" or n.operation not in {"material.realize", "creative.realize"}:
                    return n
                params = dict(n.parameters)
                if creative_contract is not None:
                    params["creative_contract"] = deepcopy(creative_contract)
                return replace(n, operation="creative.realize", parameters=tuple(params.items()))

            runtime.program = replace(runtime.program, nodes=tuple(bind_creative(n) for n in runtime.program.nodes))
            meta = dict(runtime.program.metadata)
            if meta.get("realize_operation") == "material.realize":
                meta["realize_operation"] = "creative.realize"
                runtime.program = replace(runtime.program, metadata=tuple(meta.items()))
        frame = deepcopy(payload.get("frame", {}))
        gravity = runtime.extensions.get("goal_gravity", {}) or {}
        frame["runtime_goal_anchor_ids"] = list(gravity.get("anchor_ids", []))
        frame["goal_gravity_signature"] = gravity.get("signature")
        evidence_graph = build_evidence_graph(
            goal_nodes=gravity.get("anchors", []) or [],
            route_candidates=payload.get("route_candidates", []),
            decision_graph=payload.get("decision_graph"),
        )
        decision_state = {
            "frame": frame,
            "route_candidates": deepcopy(payload.get("route_candidates", [])),
            "open_variables": deepcopy(payload.get("open_variables", [])),
            "stop_condition": str(payload.get("stop_condition", "")),
            "route_pressure": deepcopy(payload.get("route_pressure", {})),
            "evidence_graph_summary": graph_summary(evidence_graph),
        }
        runtime.extensions["decision_state"] = decision_state
        runtime.extensions["cognition_frame"] = deepcopy(frame)
        runtime.extensions["route_candidates"] = deepcopy(decision_state["route_candidates"])
        runtime.extensions["open_variables"] = deepcopy(decision_state["open_variables"])
        runtime.extensions["stop_condition"] = decision_state["stop_condition"]
        runtime.extensions["evidence_graph"] = deepcopy(evidence_graph)
        runtime.extensions.setdefault("semantic_epochs", []).append({
            "kind": "compile",
            "frame": deepcopy(frame),
            "route_ids": [r.get("id") for r in decision_state["route_candidates"]],
            "open_variables": deepcopy(decision_state["open_variables"]),
            "stop_condition": decision_state["stop_condition"],
            "kernel_source_sha256": kernel_packet.get("source_sha256"),
            "evidence_graph_summary": graph_summary(evidence_graph),
        })
        observation_ref = runtime.ledger.add_observation({"semantic_epoch": decision_state}, world_refs=node.world_refs)

        # Cognition generation is a runtime transformation step, not a request for
        # the host model to invent N viewpoints.  When semantic intake carries
        # any positive divergence/creative/structural pressure, mutate the current
        # problem representation first, then realize the selected frames in
        # isolated sibling contexts.  The finite branch count is an execution
        # budget derived from live node headroom, not a conceptual ontology cap.
        generated_branch_nodes = []
        compile_signals = runtime.extensions.get("compile_signals", {}) or {}
        # Creative artifact pressure alone does not mean "fork the cognition".
        # Generation activates on semantic divergence/exploration pressure, or
        # when the compile epoch supplies executable generation extensions. This
        # preserves ordinary creative/material flows while making explicit
        # representation-level exploration operational rather than stylistic.
        generation_pressure = _finite_signal(compile_signals.get("exploration_leverage", 0.0))
        generation_revisions = payload.get("generation_revisions", ()) or ()
        mechanism_sources = payload.get("mechanism_sources", ()) or ()
        generation_extensions = bool(generation_revisions or mechanism_sources)
        if generation_pressure > 0.0 or generation_extensions:
            explicit_budget = payload.get("generation_branch_budget")
            if explicit_budget is not None:
                if isinstance(explicit_budget, bool) or not isinstance(explicit_budget, int) or explicit_budget < 1:
                    raise ValueError("generation_branch_budget must be a positive integer")
                branch_budget = explicit_budget
            else:
                live_headroom = max(3, int(runtime.program.budget_policy.max_nodes) // 3)
                requested = max(3, int(math.ceil(2.0 + generation_pressure * 2.0)))
                semantic_authority = runtime.extensions.get("semantic_authority", {}) or {}
                open_horizon = bool(
                    semantic_authority.get("frontier_exploration_required")
                    or semantic_authority.get("representation_search_required")
                    or semantic_authority.get("possibility_space_open")
                )
                # For an open horizon, the small signal-derived request is not allowed to
                # become the active cognition ceiling. Use all current node headroom now;
                # reservoir/continuation machinery can schedule more after this window.
                branch_budget = live_headroom if open_horizon else min(live_headroom, requested)
            objective = runtime.raw.message
            requirements = runtime.extensions.get("task_requirements", []) or []
            if requirements:
                meanings = [str(x.get("meaning", "")).strip() for x in requirements if isinstance(x, dict) and str(x.get("meaning", "")).strip()]
                if meanings:
                    objective = " | ".join(meanings)
            seed = ProblemFrame.from_value(frame, objective=objective)
            raw_revisions = generation_revisions
            if not isinstance(raw_revisions, (list, tuple)):
                raise ValueError("generation_revisions must be a list")
            revision_specs = tuple(revision_spec_from_value(x) for x in raw_revisions)
            raw_sources = mechanism_sources
            if not isinstance(raw_sources, (list, tuple)):
                raise ValueError("mechanism_sources must be a list")
            source_patterns = tuple(mechanism_pattern_from_value(x) for x in raw_sources)
            generated = generate_worlds(
                seed, revision_specs=revision_specs, source_mechanisms=source_patterns,
                archive=self.novelty_archive, branch_budget=branch_budget,
            )
            runtime.worlds = tuple(generated["worlds"])
            refs = tuple(w.world_id for w in runtime.worlds)
            runtime.program = replace(runtime.program, world_refs=refs, nodes=tuple(
                replace(n, world_refs=refs) if n.status != "done" and n.node_id != node.node_id else n
                for n in runtime.program.nodes
            ))
            group = "world_generation_" + str(len(runtime.extensions.get("semantic_epochs", [])))
            runtime.extensions["cognition_generation"] = {
                "engine": generated["engine"],
                "seed_frame": deepcopy(generated["seed_frame"]),
                "candidate_count": generated["candidate_count"],
                "selected_count": generated["selected_count"],
                "selection_basis": generated["selection_basis"],
                "novelty": deepcopy(generated["novelty"]),
                "parallel_group": group,
                "branch_budget": branch_budget,
                "branch_budget_semantics": "initial_scheduling_window_not_semantic_ceiling",
                "semantic_horizon_open": bool(
                    (runtime.extensions.get("semantic_authority", {}) or {}).get("possibility_space_open")
                    or (runtime.extensions.get("semantic_authority", {}) or {}).get("frontier_exploration_required")
                    or (runtime.extensions.get("semantic_authority", {}) or {}).get("representation_search_required")
                ),
                "pressure": generation_pressure,
            }
            for world in runtime.worlds:
                params = {
                    "cognition_generation_branch": branch_packet(world),
                    "_jigaewol_parallel_safe": True,
                    "_jigaewol_parallel_group": group,
                    "_jigaewol_delta_join_planned": True,
                }
                generated_branch_nodes.append(self._node(
                    runtime, "host_semantic", "worlds.realize",
                    intents=runtime.program.objective_refs, parameters=params, cost=.12,
                ))

        built = list(generated_branch_nodes)
        gain_estimates = []
        for step in payload.get("steps", []):
            # A model-proposed expected_gain is descriptive telemetry, not veto
            # authority over whether an otherwise valid executable step exists.
            eg = step.get("expected_gain")
            if isinstance(eg, dict):
                gain_estimates.append({
                    "operation": step.get("operation"),
                    "expected_gain": deepcopy(eg),
                    "role": "advisory_not_gate",
                })
            built.append(self._step_node(runtime, step, runtime.program.objective_refs))
        if gain_estimates:
            runtime.extensions.setdefault("gain_estimate_history", []).append({"steps": gain_estimates})

        # A declared research need must cross an actual observation boundary if
        # a search capability exists.  We add at most one planning hop when the
        # epoch supplied no executable search itself.
        compile_signals = runtime.extensions.get("compile_signals", {}) or {}
        search_specs = [c for c in runtime.extensions.get("capability_specs", []) if is_search_capability(c)]
        search_ids = {str(c["id"]) for c in search_specs}
        search_planned = any(n.operation.startswith("capability.") and n.operation.removeprefix("capability.") in search_ids for n in built)
        search_seen = any(str(x.get("operation", "")).removeprefix("capability.") in search_ids
                          for x in runtime.extensions.get("tool_submissions", []) if isinstance(x, dict))
        if compile_signals.get("needs_research") is True and search_specs and not search_planned and not search_seen:
            built.insert(0, self._node(runtime, "host_semantic", "research.plan", intents=runtime.program.objective_refs,
                parameters={"instruction": "Design a sufficient observation-parented search lattice that preserves materially different decision-relevant branches until evidence makes them unnecessary."}))

        self._install_epoch_nodes(runtime, node, built, required=True)
        return observation_ref

    def _cognition_delta_result(self, runtime, node, payload):
        """Integrate a semantic delta while leaving working representations free to reform."""
        if not isinstance(payload, dict):
            raise ValueError("cognition.delta result must be an object")
        delta = payload.get("decision_delta", {})
        if not isinstance(delta, dict):
            raise ValueError("cognition.delta decision_delta must be an object")
        steps = payload.get("new_steps", []) or []
        if not isinstance(steps, list):
            raise ValueError("cognition.delta new_steps must be a list")
        params = dict(node.parameters)
        explicit_refs = {str(x) for x in params.get("observation_refs", []) if str(x)}
        group = params.get("observation_group") if params.get("_jigaewol_batch_join") is True else None
        pending = consume_pending_observations(
            runtime.extensions, group=group, source_refs=explicit_refs if group is None else None
        )
        expected_refs = {str(x.get("source_ref")) for x in pending if x.get("source_ref")}
        observed_refs = expected_refs | explicit_refs

        declared_frame_refs = {str(x) for x in payload.get("frame_change_source_refs", []) if str(x)}
        if declared_frame_refs and not declared_frame_refs <= observed_refs:
            raise ValueError("declared frame-change observation refs must name actually observed refs")
        new_frame = payload.get("new_frame")
        frame_changed = _bool_field(payload, "frame_changed", False) or isinstance(new_frame, dict)
        if frame_changed and not isinstance(new_frame, dict):
            raise ValueError("a declared frame change needs a new_frame object")
        if isinstance(new_frame, dict):
            runtime.extensions["cognition_frame"] = deepcopy(new_frame)
            runtime.extensions.setdefault("decision_state", {})["frame"] = deepcopy(new_frame)

        graph_delta = payload.get("evidence_graph_delta")
        graph_receipt = None
        if graph_delta is not None:
            current_graph = runtime.extensions.get("evidence_graph")
            if not isinstance(current_graph, dict):
                gravity = runtime.extensions.get("goal_gravity", {}) or {}
                current_graph = build_evidence_graph(
                    goal_nodes=gravity.get("anchors", []) or [],
                    route_candidates=runtime.extensions.get("route_candidates", []) or [],
                    decision_graph=None,
                )
            updated_graph, graph_receipt = apply_evidence_graph_delta(
                current_graph, graph_delta, observed_refs=observed_refs
            )
            runtime.extensions["evidence_graph"] = deepcopy(updated_graph)
            runtime.extensions.setdefault("decision_state", {})["evidence_graph_summary"] = graph_summary(updated_graph)
            runtime.extensions.setdefault("decision_state", {})["evidence_graph_receipt"] = deepcopy(graph_receipt)

        runtime.extensions.setdefault("decision_state", {}).update({
            "last_delta": deepcopy(delta),
            "material_delta": deepcopy(payload.get("material_delta")),
            "requires_more_evidence": _bool_field(payload, "requires_more_evidence", False),
            "stop_condition": str(payload.get("stop_condition", runtime.extensions.get("stop_condition", ""))),
        })
        runtime.extensions.setdefault("semantic_epochs", []).append({
            "kind": "delta", "observation_refs": sorted(observed_refs),
            "decision_delta": deepcopy(delta), "frame_changed": frame_changed,
            "frame_change_source_refs": sorted(declared_frame_refs),
            "material_delta": deepcopy(payload.get("material_delta")),
            "evidence_graph_receipt": deepcopy(graph_receipt),
        })
        result_ref = runtime.ledger.add_observation({
            "decision_delta": deepcopy(delta), "observation_refs": sorted(observed_refs),
            "material_delta": deepcopy(payload.get("material_delta")), "frame_changed": frame_changed,
            "frame_change_source_refs": sorted(declared_frame_refs),
            "evidence_graph_receipt": deepcopy(graph_receipt),
        }, world_refs=node.world_refs)
        built = [self._step_node(runtime, step, runtime.program.objective_refs) for step in steps]
        if built:
            self._install_epoch_nodes(runtime, node, built, required=True)
        return result_ref

    def _frontier(self, runtime):
        data = runtime.extensions.get("frontier", {})
        if data is None:
            data = {}
        if not isinstance(data, dict):
            raise ValueError("research frontier state must be an object")
        fields = {name: data.get(name, field.default) for name, field in ResearchFrontier.__dataclass_fields__.items()}
        for name, value in tuple(fields.items()):
            if name == "expected_information_gain":
                if value is None:
                    fields[name] = None
                    continue
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                    raise ValueError("research frontier expected_information_gain must be finite numeric or unknown")
                fields[name] = float(value)
                continue
            if not isinstance(value, (list, tuple)) or any(not isinstance(item, str) or not item.strip() for item in value):
                raise ValueError("research frontier " + name + " must be a list of nonempty text values")
            fields[name] = tuple(item.strip() for item in value)
        return ResearchFrontier(**fields)

    def _research_result(self, runtime, node, payload):
        frontier = self._frontier(runtime)
        if node.operation == "research.plan":
            # Search breadth is bounded by the actual execution resource window,
            # not by an arbitrary semantic branch ceiling. Distinctness remains a
            # runtime choice rather than a prerequisite for admitting the plan.
            limit = max(1, int(runtime.program.budget_policy.max_nodes))
            supplied = payload.get("branches") if isinstance(payload, dict) else None
            if supplied is None and isinstance(payload, dict):
                supplied = payload.get("queries")
            branch_count = len(supplied) if isinstance(supplied, list) else 0
            if branch_count > limit:
                # The compiler's initial node window is headroom, not a semantic
                # ceiling. Admit a host-proposed open-set research epoch and let
                # actual host/tool resources decide how far it can execute.
                self._extend_soft_budget(
                    runtime,
                    min_nodes=max(branch_count + len(runtime.program.nodes) + 4, branch_count),
                    reason="research_branch_extension",
                )
                limit = max(branch_count, int(runtime.program.budget_policy.max_nodes))
            compile_signals = runtime.extensions.get("compile_signals", {}) or {}
            diversity_pressure = max(
                _finite_signal(compile_signals.get("exploration_leverage", 0.0)),
                _finite_signal(compile_signals.get("creative_leverage", 0.0)),
            )
            strategy, branches = normalize_search_plan(
                payload, runtime.extensions.get("search_strategy"), max_branches=limit,
                required_diversity=bool(diversity_pressure >= .6 and len(payload.get("branches", []) or []) > 1))
            routed = route_search_branches(branches, runtime.extensions.get("capability_specs", []))
            for branch in routed:
                if branch.get("id") in strategy.get("nodes", {}):
                    strategy["nodes"][branch["id"]].update({
                        key: deepcopy(branch.get(key)) for key in
                        ("capability_id", "capability_role", "route_basis", "provider", "plugin")
                    })
            branches = routed
            runtime.extensions["search_strategy"] = strategy
            queries = [b["query"] for b in branches]
            runtime.extensions["queries"] = queries
            runtime.extensions["search_branch_ids"] = [b["id"] for b in branches]
            runtime.extensions["frontier"] = asdict(replace(
                frontier, asked_queries=frontier.asked_queries + tuple(queries),
                pending_discoveries=(), discovery_refs=()))
            if not runtime.extensions.get("capability_specs"):
                raise ValueError("research plan requires a connected observation capability")
            # Independent first-epoch branches can execute concurrently, then one
            # cognition.delta sees the full observation batch.  Descendant
            # branches normally arrive in later deltas and keep their causal refs.
            group = "search_epoch_" + str(strategy.get("epoch", 0))
            built=[]
            for branch in branches:
                params={
                    "queries":[branch["query"]],
                    "search_branch_ids":[branch["id"]],
                    "search_strategy_epoch":strategy.get("epoch"),
                    "observation_policy":"delta",
                    "mechanism":branch.get("mechanism"),
                    "discriminator":branch.get("discriminator"),
                    "hypothesis":branch.get("hypothesis"),
                    "decision_effect":branch.get("decision_effect"),
                    "source_culture":branch.get("source_culture"),
                    "language":branch.get("language"),
                    "representation_shift":branch.get("representation_shift"),
                    "research_route_basis":branch.get("route_basis"),
                }
                # Only siblings with no parent dependency are safe to fan out.
                if not branch.get("parent_ids"):
                    params.update(_jigaewol_parallel_safe=True,_jigaewol_parallel_group=group,_jigaewol_delta_join_planned=True)
                built.append(self._cap_node(runtime, str(branch["capability_id"]), params, runtime.program.objective_refs))
            self._install_epoch_nodes(runtime, node, built, required=True)
            return runtime.ledger.add_observation({"search_plan": branches, "queries": queries}, world_refs=node.world_refs)

        # Legacy explicit research.interpret remains supported for hosts that want
        # claim extraction.  The preferred ordinary path is cognition.delta.
        claims=[]
        for item in _object_sequence(payload, "claims"):
            refs=[]
            spans = item.get("evidence_spans", ())
            if not isinstance(spans, (list, tuple)) or any(not isinstance(span, dict) for span in spans):
                raise ValueError("claim evidence_spans must be a list of objects")
            for span in spans:
                if "quote" in span:
                    refs.append(runtime.ledger.add_quote(span["source_ref"], span["quote"], span.get("occurrence")))
                else:
                    refs.append(runtime.ledger.add_evidence(span["source_ref"], span["start"], span["end"]))
            raw_text = item.get("text")
            if not isinstance(raw_text, str) or not raw_text.strip():
                raise ValueError("claim text is required")
            text = raw_text.strip()
            runtime.ledger.add_claim(text, refs, node.intent_refs)
            raw_confidence = item.get("confidence")
            if raw_confidence is None:
                confidence = None
            else:
                if isinstance(raw_confidence, bool):
                    raise ValueError("claim confidence must be a finite number between 0 and 1 or unknown")
                try:
                    confidence = float(raw_confidence)
                except (TypeError, ValueError, OverflowError) as exc:
                    raise ValueError("claim confidence must be a finite number between 0 and 1 or unknown") from exc
                if not math.isfinite(confidence) or confidence < 0 or confidence > 1:
                    raise ValueError("claim confidence must be a finite number between 0 and 1 or unknown")
            contradiction_refs = item.get("contradiction_refs", ())
            if not isinstance(contradiction_refs, (list, tuple)) or any(not isinstance(ref, str) or not ref.strip() for ref in contradiction_refs):
                raise ValueError("claim contradiction_refs must be a list of nonempty text ids")
            claims.append(Claim(text, confidence, tuple(refs), tuple(ref.strip() for ref in contradiction_refs)))
        frontier=apply_evidence(frontier,claims)
        questions=payload.get("questions",()) or ()
        if not isinstance(questions, (list, tuple)) or any(not isinstance(q,str) or not q.strip() for q in questions):
            raise ValueError("follow-up questions must be a list of nonempty text")
        questions = tuple(q.strip() for q in questions)
        runtime.extensions["frontier"]=asdict(replace(frontier,pending_questions=tuple(dict.fromkeys(frontier.pending_questions+tuple(questions)))))
        observation=runtime.ledger.add_observation(payload,world_refs=node.world_refs)
        runtime.extensions.setdefault("research_refs",[]).append(observation)
        branch_ids=payload.get("branch_ids",[]) or []
        if not isinstance(branch_ids, (list, tuple)) or any(not isinstance(branch_id, str) or not branch_id.strip() for branch_id in branch_ids):
            raise ValueError("branch_ids must be a list of nonempty text ids")
        branch_ids = [branch_id.strip() for branch_id in branch_ids]
        if branch_ids:
            runtime.extensions["search_strategy"]=mark_interpreted(runtime.extensions.get("search_strategy"),branch_ids)
        runtime.extensions["research_delta"]={
            "decision_delta":deepcopy(payload.get("decision_delta",{})),
            "questions":list(questions),"source_ref":observation}
        return observation

    def _trajectory_result(self, runtime, node, payload):
        self._register_operators(runtime, payload)
        candidates = []
        seen = set()
        for item in _object_sequence(payload, "candidates"):
            candidate = deepcopy(item)
            raw_id = candidate.get("id")
            if not isinstance(raw_id, str) or not raw_id.strip():
                raise ValueError("each candidate needs a distinct id and actual material sample")
            cid = raw_id.strip()
            if cid in seen or not isinstance(candidate.get("sample"), str) or not candidate["sample"].strip():
                raise ValueError("each candidate needs a distinct id and actual material sample")
            mechanism = candidate.get("mechanism")
            if not isinstance(mechanism, str) or not mechanism.strip():
                raise ValueError("provide a mechanism and actual material")
            candidate["id"] = cid
            candidate["mechanism"] = mechanism.strip()
            seen.add(cid)
            raw_refs = candidate.get("intent_refs", ())
            if not isinstance(raw_refs, (list, tuple)) or any(not isinstance(ref, str) or not ref.strip() for ref in raw_refs):
                raise ValueError("candidate intent_refs must be a list of nonempty text ids")
            refs = tuple(ref.strip() for ref in raw_refs)
            if not set(refs) <= set(node.intent_refs):
                raise ValueError("candidate references an unknown requirement")
            # Old self-assessments may be retained as commentary, never as selection measurements.
            candidate.pop("vector", None)
            self._bind_exploration_candidate(runtime, candidate)
            structure = candidate.get("structure", {})
            applied = []
            for oid in candidate.get("operator_ids", ()):
                data = runtime.extensions.get("operators", {}).get(oid)
                if not data:
                    raise ValueError("operator must be registered before use")
                result = apply_generated_operator(OperatorSpec(**data), structure)
                structure = result["structure"]
                applied.append(result)
            if applied:
                candidate["structure"] = structure
                candidate["operator_results"] = applied
            if "explore_variant_id" in candidate:
                self._check_exploration_guards(runtime, structure)
            candidates.append(candidate)
        if not candidates:
            raise ValueError("provide actual candidate samples")
        self._check_exploration_candidates(runtime, candidates)
        runtime.extensions["candidates"] = candidates
        choice = payload.get("candidate_choice")
        if choice is not None and choice not in seen:
            raise ValueError("candidate_choice must identify a current candidate")
        if choice is not None and not str(payload.get("choice_reason", "")).strip():
            raise ValueError("candidate_choice needs a reason comparing the actual materials")
        runtime.extensions["candidate_choice"] = choice
        runtime.extensions["candidate_choice_reason"] = payload.get("choice_reason", "")
        changed = [c for c in candidates if any(r["changed"] for r in c.get("operator_results", []))]
        if changed:
            runtime.extensions["candidate_choice"] = None
            runtime.extensions["candidate_choice_reason"] = ""
            target = next((n for n in runtime.program.nodes if n.status == "pending" and n.node_id != node.node_id), None)
            if target is None:
                raise ValueError("changed candidate structures require a remaining materialization step")
            # Selection and measurement wait for new actual samples. Keeping a
            # different structure beside the old prose is not a realized change.
            runtime.extensions["candidates_to_rewrite"] = [deepcopy(c) for c in changed]
            rewrite = self._node(runtime, "host_semantic", "trajectories.rewrite",
                                 parameters={"candidates_to_rewrite": deepcopy(changed)})
            self._replace_pending(runtime, (target.node_id,), [rewrite, target], count_rewrite=False, required=True)
        return runtime.ledger.add_observation({"candidates": candidates, "assessment_basis": "candidate_proposal_only"}, world_refs=node.world_refs)

    def _trajectory_rewrite_result(self, runtime, node, payload):
        pending = {c["id"]: c for c in runtime.extensions.get("candidates_to_rewrite", [])}
        updates = _object_sequence(payload, "candidates", default=[])
        if len(updates) != len(pending) or {c.get("id") for c in updates} != set(pending):
            raise ValueError("rewrite each changed candidate exactly once")
        updated = {}
        for item in updates:
            old = pending[item["id"]]
            sample = item.get("sample")
            if not isinstance(sample, str) or not sample.strip() or sample == old["sample"]:
                raise ValueError("changed structure needs a new actual sample before selection")
            reason = item.get("rewrite_reason")
            if not isinstance(reason, str) or not reason.strip():
                raise ValueError("state which material change realizes the transformed structure")
            updated[item["id"]] = {**deepcopy(old), "sample": sample,
                "rewrite_reason": reason, "pre_transform_sample": old["sample"],
                "realization_basis": "host_rewritten_material_after_executed_data_edits"}
            if "explore_variant_id" in old or "method_job_id" in old:
                updated[item["id"]]["hinge"] = hinge_in(item.get("hinge", old.get("hinge")), sample)
        runtime.extensions["candidates"] = [updated.get(c["id"], c) for c in runtime.extensions["candidates"]]
        self._check_exploration_candidates(runtime, runtime.extensions["candidates"])
        choice = payload.get("candidate_choice")
        if choice is not None:
            if choice not in {c["id"] for c in runtime.extensions["candidates"]}:
                raise ValueError("candidate_choice must identify a current candidate")
            if not str(payload.get("choice_reason", "")).strip():
                raise ValueError("compare the rewritten material before choosing")
            runtime.extensions["candidate_choice"] = choice
            runtime.extensions["candidate_choice_reason"] = payload["choice_reason"]
        runtime.extensions.pop("candidates_to_rewrite", None)
        return runtime.ledger.add_observation({"rewritten_candidates": list(updated.values()),
            "basis": "changed_text_not_semantic_certification"}, world_refs=node.world_refs)

    def _select_trajectory(self, runtime, node):
        if runtime.extensions.get("candidates_to_rewrite"):
            raise ValueError("realize changed structures as new samples before selection")
        candidates = runtime.extensions.get("candidates", [])
        required = tuple(i.intent_id for i in runtime.lattice.nodes if i.required and i.intent_id in node.intent_refs)
        decision = self._feedback_choose(runtime, required)
        if decision["candidate_id"] is None:
            runtime.extensions["selected"] = None
            return runtime.ledger.add_observation({"selection": None, "feedback_decision": decision})
        selected = next(c for c in candidates if c["id"] == decision["candidate_id"])
        runtime.extensions["selected"] = selected
        if selected.get("creative_state"):
            runtime.extensions["creative_state"] = asdict(creative_state_from(selected["creative_state"]))
        if selected.get("actions"):
            target = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation in MATERIAL), None)
            if target:
                tools = [self._action_node(runtime, a) for a in selected["actions"]]
                self._replace_pending(runtime, (target.node_id,), tools + [target], count_rewrite=False, required=True)
        return runtime.ledger.add_observation({"selected": selected, "basis": decision["basis"], "feedback_decision": decision}, world_refs=node.world_refs)

    def _accept_open_semantic_shape(self, runtime, node, payload):
        """Preserve a non-material semantic result without swallowing validator errors.

        This path is explicit: it is used only when a material/delivery work item
        returns a non-empty payload with no material fields at all. Malformed
        payloads for known semantic operations still raise normally.
        """
        ref = runtime.ledger.add_observation({
            "semantic_result": deepcopy(payload),
            "source_operation": node.operation,
            "state": "accepted_unprojected_cognition",
        }, world_refs=node.world_refs)
        runtime.extensions.setdefault("semantic_projection_events", []).append({
            "operation": node.operation,
            "result_ref": ref,
            "state": "accepted_unprojected_cognition",
        })
        remaining = [
            n for n in runtime.program.nodes
            if n.status == "pending" and n.node_id != node.node_id
        ]
        if remaining:
            reframe = self._node(
                runtime, "host_semantic", "cognition.compile",
                intents=runtime.program.objective_refs,
                parameters={
                    "accepted_semantic_result_ref": ref,
                    "source_operation": node.operation,
                    "instruction": (
                        "Integrate this accepted semantic result as first-class cognition. "
                        "Form the next executable work state without treating a material-output schema as a permission gate."
                    ),
                },
            )
            self._replace_pending(
                runtime, tuple(n.node_id for n in remaining), [reframe, *remaining],
                count_rewrite=True, required=False,
            )
        return ref

    def _material_result(self, runtime, node, payload):
        material_fields = {"answer", "output", "actions", "edits"}
        if payload and not any(key in payload for key in material_fields):
            return self._accept_open_semantic_shape(runtime, node, payload)
        if payload.get("actions"):
            draft = payload.get("answer", payload.get("output"))
            if draft is not None:
                runtime.extensions["draft"] = draft
            target = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "closure.check"), None)
            if not target:
                raise ValueError("tool requests need a remaining delivery boundary")
            steps = [self._action_node(runtime, a) for a in payload["actions"]]
            steps += [self._node(runtime, "host_semantic", node.operation, intents=node.intent_refs), target]
            self._replace_pending(runtime, (target.node_id,), steps, count_rewrite=False, required=True)
            return runtime.ledger.add_observation({"pending_actions": payload["actions"], "draft": draft})
        if "edits" in payload:
            if "answer" in payload or "output" in payload:
                raise ValueError("provide literal edits or a complete answer")
            answer = apply_text_edits(runtime.answer, payload["edits"])
        else:
            answer = payload.get("answer", payload.get("output"))
        if answer is None or not str(answer).strip():
            raise ValueError("deliver a substantive answer or material result")

        # Material is bound to recorded tool/source refs through normal
        # intent effects.  No special self-attested synthesis witness is needed.
        self._carry_explored_material(runtime, payload, answer)
        previous = runtime.extensions.get("answer_ref")
        previous_content = runtime.ledger.get(previous).content if previous else None
        answer_ref = runtime.ledger.add_material(answer)
        runtime.answer = answer
        runtime.extensions["answer_ref"] = answer_ref
        runtime.extensions["draft_refs"] = runtime.extensions.get("draft_refs", []) + [answer_ref]
        unresolved = list(payload.get("unresolved", ()))
        known = set(node.intent_refs)
        if any(ref not in known for ref in unresolved):
            raise ValueError("unresolved must contain intent ids; describe details in the answer")
        runtime.extensions["unresolved"] = unresolved
        if str(payload.get("opportunity", "")).strip():
            runtime.extensions["opportunity"] = str(payload["opportunity"])
        else:
            runtime.extensions.pop("opportunity", None)
        # A replacement answer supersedes prior coverage of the same delivered requirements.
        for ref, entry in tuple(runtime.ledger._entries.items()):
            if entry.kind == "effect" and set(entry.intent_refs) & set(node.intent_refs):
                runtime.ledger._entries[ref] = replace(entry, verification_status="superseded")
        explicit = payload.get("intent_effects")
        if explicit is not None and not isinstance(explicit, dict):
            raise ValueError("intent_effects must be a requirement-to-material object")
        open_intents = [ref for ref in node.intent_refs if ref not in unresolved]
        # Personal chat should not fail a good single-requirement answer over bookkeeping syntax.
        # Linkage is not truth certification; a single delivered requirement can safely map to the delivered text.
        if explicit is None and len(open_intents) == 1:
            explicit = {open_intents[0]: {"quote": str(answer), "content": str(answer)}}
        effects = []
        for intent_ref, spec in (explicit or {}).items():
            if intent_ref not in known or not isinstance(spec, dict):
                raise ValueError("effect must map to an intended requirement")
            if intent_ref in unresolved:
                continue
            refs = []
            quote = spec.get("quote")
            if quote is not None:
                if not isinstance(quote, str) or not quote or quote not in str(answer):
                    raise ValueError("effect quote must occur in delivered answer")
                refs.append(runtime.ledger.add_quote(answer_ref, quote, spec.get("occurrence")))
            if spec.get("whole_answer"):
                raise ValueError("whole_answer cannot replace an explicit requirement-to-material quote")
            for ref in spec.get("exact_refs", ()):
                if not runtime.ledger.material_reference(ref):
                    raise ValueError("effect needs a recorded material reference")
                refs.append(ref)
            effect_content = str(spec.get("content") or quote or "delivered requirement material")
            effects.append(runtime.ledger.add_effect(effect_content, (intent_ref,), refs, node.world_refs))
        if node.operation == "creative.realize" or payload.get("creative_state") or payload.get("creative_updates"):
            state = creative_state_from(runtime.extensions.get("creative_state", {}))
            before = asdict(state)
            for update in _object_sequence(payload, "creative_updates"):
                state = apply_creative_choice(state, update["choice"], answer_ref, update.get("changes", {}))
            if payload.get("creative_state"):
                supplied = creative_state_from(payload["creative_state"])
                state = replace(supplied, resulting_text_refs=state.resulting_text_refs + (answer_ref,))
            runtime.extensions["creative_state"] = asdict(state)
            runtime.ledger.add_observation({"creative_before": before, "creative_after": asdict(state),
                "output_ref": answer_ref, "content_changed": previous_content != answer, "basis": "state_update_and_delivered_text"})
        self._feedback_delivery(runtime, payload)
        self._next_exploration(runtime, node, payload, answer)

        # JIGAEWOL 10: material changes may call the runtime back. Only explicit
        # trigger_events emitted for currently registered artifact_triggers count.
        triggers = {str(t.get("id")): t for t in runtime.extensions.get("generative_world", {}).get("artifact_triggers", []) if isinstance(t, dict) and str(t.get("id", "")).strip()}
        events = _object_sequence(payload, "trigger_events", default=[])
        spawned = []
        for event in events:
            tid = str(event.get("trigger_id", "")).strip()
            spec = triggers.get(tid)
            if spec is None:
                raise ValueError("material result referenced an unknown artifact trigger")
            if not evaluate_trigger_condition(spec, payload):
                raise ValueError("artifact trigger event condition is false for the actual material result")
            spawned.append({
                "trigger_id": tid,
                "origin_answer_ref": answer_ref,
                "spawn": str(spec.get("spawn")),
                "event": deepcopy(event),
                "condition": deepcopy(spec.get("condition")),
                "condition_verification": "runtime_evaluated_true",
                "status": "scheduled_in_turn",
            })
        if spawned:
            runtime.extensions.setdefault("artifact_trigger_events", []).extend(deepcopy(spawned))
            closure = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "closure.check"), None)
            if closure is not None:
                followups = []
                for item in spawned:
                    followups.append(self._node(
                        runtime, "host_semantic", "cognition.compile", intents=runtime.program.objective_refs,
                        parameters={"artifact_trigger": deepcopy(item)},
                        trigger_refs=(item["trigger_id"],),
                        language_refs=tuple(x.get("id") for x in runtime.extensions.get("generative_world", {}).get("world_language", {}).get("units", []) if isinstance(x, dict) and x.get("id")),
                    ))
                self._replace_pending(runtime, (closure.node_id,), followups + [closure], count_rewrite=True, required=True)
        self._schedule_quality_inspection(runtime, node, answer_ref)
        return effects[-1] if effects else runtime.ledger.add_observation({"answer_ref": answer_ref, "unresolved": list(node.intent_refs), "spawned_triggers": spawned})

    def _quality_pressure(self, runtime):
        signals = runtime.extensions.get("compile_signals", {}) or {}
        requested = signals.get("verification_requested") is True
        # Post-generation semantic auditing is opt-in at the task level. A model's
        # internal verification_leverage estimate may allocate cognition, but it
        # cannot silently create another audit pass the user did not request.
        # Deterministic checks, execution truth, provenance, and release integrity
        # remain separate runtime invariants and are not disabled here.
        mode = str(runtime.extensions.get("mode", "auto"))
        return mode != "direct" and requested

    def _schedule_quality_inspection(self, runtime, node, answer_ref):
        if not self._quality_pressure(runtime):
            return
        if runtime.extensions.get("quality_audited_answer_ref") == answer_ref:
            return
        if any(n.status == "pending" and n.operation == "quality.inspect" for n in runtime.program.nodes):
            return
        closure = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "closure.check"), None)
        if closure is None:
            return
        inspect = self._node(runtime, "host_semantic", "quality.inspect", intents=node.intent_refs, parameters={
            "answer_ref": answer_ref,
            "instruction": (
                "Inspect the actual material against the live goal. Measure goal coverage, evidence binding, "
                "mechanism effect, novelty, structural difference from generic/default answers, and concrete genericity risks. "
                "Do not reward unusual wording by itself."
            ),
        })
        self._replace_pending(runtime, (closure.node_id,), [inspect, closure], count_rewrite=False, required=True)

    def _quality_result(self, runtime, node, payload):
        if not isinstance(payload, dict):
            raise ValueError("quality.inspect result must be an object")
        verdict = str(payload.get("verdict", "accept")).strip().casefold()
        if verdict not in {"accept", "revise"}:
            raise ValueError("quality verdict must be accept or revise")
        metrics = {}
        for key in ("goal_coverage", "evidence_binding", "mechanism_effect", "novelty"):
            if key not in payload or payload.get(key) is None:
                raise ValueError("missing quality metric: " + key)
            raw_value = payload[key]
            if isinstance(raw_value, bool):
                raise ValueError(key + " must be a finite number between 0 and 1")
            try:
                value = float(raw_value)
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError(key + " must be a finite number between 0 and 1") from exc
            if not math.isfinite(value) or value < 0 or value > 1:
                raise ValueError(key + " must be a finite number between 0 and 1")
            metrics[key] = value
        structural = payload.get("structural_difference", []) or []
        risks = payload.get("genericity_risks", []) or []
        if not isinstance(structural, list) or not isinstance(risks, list):
            raise ValueError("quality structural_difference and genericity_risks must be lists")
        assessment = {
            "verdict": verdict, **metrics,
            "structural_difference": [str(x) for x in structural],
            "genericity_risks": [str(x) for x in risks],
            "answer_ref": runtime.extensions.get("answer_ref"),
            "basis": "post_material_semantic_inspection",
        }
        runtime.extensions["quality_assessment"] = assessment
        runtime.extensions["quality_audited_answer_ref"] = runtime.extensions.get("answer_ref")
        if verdict == "revise":
            closure = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "closure.check"), None)
            if closure is not None:
                realize_op = dict(runtime.program.metadata).get("realize_operation", "material.realize")
                revise = self._node(runtime, "host_semantic", realize_op, intents=runtime.program.objective_refs, parameters={
                    "quality_revision": deepcopy(assessment),
                    "instruction": "Revise the actual material to address the measured genericity/goal-fit weaknesses; preserve already-satisfied requirements.",
                })
                self._replace_pending(runtime, (closure.node_id,), [revise, closure], count_rewrite=True, required=True)
        return runtime.ledger.add_observation({"quality_assessment": deepcopy(assessment)}, world_refs=node.world_refs)

    def _reconstruction_result(self, runtime, node, payload):
        self._register_operators(runtime, payload)
        steps = payload.get("steps")
        if steps:
            remaining = [n for n in runtime.program.nodes if n.status == "pending" and n.node_id != node.node_id]
            built = []
            failed = set(runtime.extensions.get("failed_route_signatures", ()) or ())
            retry_basis = str(payload.get("retry_basis", "") or "").strip()
            for step in steps:
                op = str(step.get("operation", "")) if isinstance(step, dict) else ""
                params = step.get("parameters", {}) if isinstance(step, dict) else {}
                signature = route_signature(op, params)
                if signature in failed and not retry_basis:
                    raise ValueError(
                        "runtime.reconstruct repeated an identical failed route without a changed-condition retry_basis"
                    )
                built.append(self._step_node(runtime, step, runtime.program.objective_refs))
            if not any(n.operation in MATERIAL for n in built):
                op = dict(runtime.program.metadata).get("realize_operation", "material.realize")
                built.append(self._node(runtime, "host_semantic", op, intents=runtime.program.objective_refs))
            built.append(self._node(runtime, "local", "closure.check"))
            self._replace_pending(runtime, tuple(n.node_id for n in remaining), built, count_rewrite=False, required=True)
        return runtime.ledger.add_observation(payload, world_refs=node.world_refs)
