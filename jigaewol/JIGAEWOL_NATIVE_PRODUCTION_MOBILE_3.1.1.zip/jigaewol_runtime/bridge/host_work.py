from dataclasses import dataclass, field


@dataclass(frozen=True)
class HostWork:
    work_id: str
    turn_id: str
    task_id: str
    executor: str
    operation: str
    intent_refs: tuple[str, ...]
    world_refs: tuple[str, ...]
    input_refs: tuple[str, ...]
    context_slices: tuple[str, ...]
    expected_output_schema: str
    expected_effects: tuple[str, ...]
    evidence_requirements: tuple[str, ...]
    permission_class: str
    cost_hint: float
    operator_ids: tuple[str, ...] = ()
    language_refs: tuple[str, ...] = ()
    trigger_refs: tuple[str, ...] = ()
    visibility_scope: str | None = None
    # Stable across persistence/resume. HOST tools should use this to reconcile
    # a side effect that may have succeeded before JIGAEWOL received submit().
    idempotency_key: str | None = None
    resume_policy: str = "safe_replay"
    # Exact executable arguments live outside the compactable semantic context.
    # HOST tool adapters must use this field when invoking real providers.
    parameters: dict = field(default_factory=dict)
    context: dict = field(default_factory=dict)
