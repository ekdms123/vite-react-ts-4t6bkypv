from __future__ import annotations

"""Auditable per-user-turn ingress for ordinary chat hosts.

The gate coordinates ingress, current callable capability binding, and
restart recovery. It intentionally does not execute HOST semantic/tool work.
"""

from dataclasses import dataclass
import hashlib

from jigaewol_runtime.bridge.chat_driver import GeneralChatDriver
from jigaewol_runtime.bridge.core import JigaewolView
from jigaewol_runtime.capabilities.manifest import normalize_capabilities
from jigaewol_runtime.kernel.ids import strict_json


def capability_fingerprint(capabilities) -> str:
    """Return a deterministic SHA-256 over normalized callable capabilities."""
    normalized = normalize_capabilities(capabilities)
    ordered = sorted(normalized, key=lambda cap: cap["id"])
    return hashlib.sha256(strict_json(ordered).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class TurnTicket:
    receipt_id: str
    session_id: str
    turn_id: str
    message_sha256: str
    view: JigaewolView
    recovered_turn_ids: tuple[str, ...]
    capability_fingerprint: str
    capabilities_rebound: bool


class PerTurnGate:
    """Supported ordinary-chat entrypoint above ``GeneralChatDriver``."""

    def __init__(self, driver: GeneralChatDriver, *, ledger=None):
        if not isinstance(driver, GeneralChatDriver):
            raise TypeError("driver must be a GeneralChatDriver")
        self.driver = driver
        self.ledger = ledger or driver.runtime.store
        self.session_id = driver.runtime.session_id
        self._capability_fingerprint = capability_fingerprint(driver.capability_snapshot())

    def _bind_if_changed(self, capabilities):
        if capabilities is None:
            return self._capability_fingerprint, False
        fingerprint = capability_fingerprint(capabilities)
        if fingerprint == self._capability_fingerprint:
            return fingerprint, False
        self.driver.bind_capabilities(capabilities)
        self._capability_fingerprint = fingerprint
        return fingerprint, True

    def enter(self, message: str, *, capabilities=None, attachments=None, **begin_kwargs) -> TurnTicket:
        if not isinstance(message, str):
            raise TypeError("message must be text")
        message_sha256 = hashlib.sha256(message.encode("utf-8")).hexdigest()
        received = self.ledger.record_ingress_received(
            session_id=self.session_id,
            message_sha256=message_sha256,
        )
        receipt_id = received["receipt_id"]
        fingerprint = None
        rebound = False
        recovered_turn_ids: tuple[str, ...] = ()
        target_turn_established = False
        try:
            fingerprint, rebound = self._bind_if_changed(capabilities)
            if self.driver.runtime.latest_resumable_turn_id() is not None:
                recovered = self.driver.resume_pending()
                if recovered is not None:
                    recovered_turn_ids = (recovered.turn_id,)

            kwargs = dict(begin_kwargs)
            if attachments is not None:
                kwargs["attachments"] = attachments
            view = self.driver._begin_from_gate(message, **kwargs)
            target_turn_established = True
            self.ledger.record_ingress_admitted(
                receipt_id,
                turn_id=view.turn_id,
                capability_fingerprint=fingerprint,
                capabilities_rebound=rebound,
                recovered_turn_ids=recovered_turn_ids,
            )
            return TurnTicket(
                receipt_id=receipt_id,
                session_id=self.session_id,
                turn_id=view.turn_id,
                message_sha256=message_sha256,
                view=view,
                recovered_turn_ids=recovered_turn_ids,
                capability_fingerprint=fingerprint,
                capabilities_rebound=rebound,
            )
        except Exception as exc:
            current = self.ledger.get_ingress_receipt(receipt_id)
            if not target_turn_established and current is not None and current["status"] == "received":
                self.ledger.record_ingress_failed(
                    receipt_id,
                    exc,
                    capability_fingerprint=fingerprint,
                    capabilities_rebound=rebound,
                    recovered_turn_ids=recovered_turn_ids,
                )
            raise

    def receipt(self, receipt_id: str):
        return self.ledger.get_ingress_receipt(receipt_id)

    def recent_receipts(self, *, limit=None):
        return self.ledger.list_ingress_receipts(self.session_id, limit=limit)
