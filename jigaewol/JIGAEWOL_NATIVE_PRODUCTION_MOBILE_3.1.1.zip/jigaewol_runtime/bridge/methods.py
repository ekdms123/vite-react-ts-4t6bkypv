"""Host-authored computations become real tool work and observed next choices."""
from copy import deepcopy
import hashlib
import json
import math

from jigaewol_runtime.methods import prepare_job, run_job


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def read_path(value, path):
    if not isinstance(path, list) or any(type(k) not in (str, int) for k in path):
        raise ValueError("observation path must be a JSON path")
    try:
        for key in path:
            if isinstance(value, dict) and type(key) is str:
                value = value[key]
            elif isinstance(value, list) and type(key) is int and 0 <= key < len(value):
                value = value[key]
            else:
                raise KeyError(key)
    except (KeyError, IndexError, TypeError) as exc:
        raise ValueError("observation path is absent from the actual result") from exc
    return value


def observation_of(value, spec):
    if not isinstance(spec, dict) or set(spec) != {"path", "equals"}:
        raise ValueError("observation needs path and equals")
    actual = read_path(value, spec["path"])
    if canonical(actual) != canonical(spec["equals"]):
        raise ValueError("observation does not match the recorded actual result")
    return deepcopy(actual)


class MethodsMixin:
    def activate(self, *, deep=False):
        """Verify the durable runtime state quickly; optionally probe the worker.

        Ordinary ChatGPT turns should not pay a cold-subprocess tax merely to
        prove that state can be opened.  ``deep=True`` preserves the previous
        end-to-end Python worker probe for explicit diagnostics/self-checks.
        """
        with self.store._connect() as conn:
            health_row = conn.execute("SELECT 1").fetchone()
            if health_row is None or health_row[0] != 1:
                raise RuntimeError("runtime state store health check failed")
        effective = self.external_kernel.effective() if hasattr(self, "external_kernel") else {}
        identity = effective.get("manifest", {}).get("identity", {}) if isinstance(effective, dict) else {}
        phrase = identity.get("activation_phrase") if isinstance(identity, dict) else None
        if not isinstance(phrase, str) or not phrase.strip():
            phrase = "JIGAEWOL READY."
        component_status = self.external_component_status() if hasattr(self, "external_component_status") else []

        if not deep:
            fingerprint = hashlib.sha256(canonical({
                "session_id": getattr(self, "session_id", ""),
                "kernel": effective.get("manifest", {}).get("manifest_sha256") if isinstance(effective, dict) else None,
                "components": [(x.get("id"), bool(x.get("installed"))) for x in component_status if isinstance(x, dict)],
            }).encode()).hexdigest()[:16]
            return {
                "status": "connected", "phrase": phrase, "verification_mode": "fast",
                "scope": "actual_state_store_effective_kernel_and_pinned_components",
                "activation_id": "activation_fast_" + fingerprint,
                "external_components": component_status,
            }

        probe = {"id": "activation", "purpose": "Check the actual computation connection",
            "representation": "JSON round trip", "entrypoint": "solve",
            "applicability": "Explicit deep activation only", "source": "def solve(data):\n    return data\n"}
        job = prepare_job(probe, {"connected": True})
        report = run_job(job)
        cold_start_retry = False
        if report.get("status") != "ok" or report.get("output") != {"connected": True}:
            raise ValueError("computation initialization failed: " + str(report.get("error", report)))
        return {
            "status": "connected", "phrase": phrase, "verification_mode": "deep",
            "scope": "actual_python_worker_state_store_effective_kernel_and_pinned_components",
            "job_id": report["job_id"], "cold_start_retry": cold_start_retry,
            "external_components": component_status,
        }


    def self_check(self):
        """Run small deterministic runtime probes, not semantic self-praise."""
        import tempfile
        from jigaewol_runtime.cognition.external import bundled_manifest, validate_manifest
        from jigaewol_runtime.adaptation.goal_gravity import build_goal_gravity
        from jigaewol_runtime.adaptation.search_strategy import empty_search_strategy, normalize_search_plan, bind_search_observation
        from jigaewol_runtime.adaptation.integrations import IntegrationStore
        from jigaewol_runtime.adaptation.access import AccessGateStore, marker_matches
        from jigaewol_runtime.governor.value import budget_for_signals
        from jigaewol_runtime.compiler.signals import CompileSignals
        from jigaewol_runtime.kernel.store import StateStore
        from jigaewol_runtime.kernel.errors import JigaewolError
        from jigaewol_runtime.bridge.context_packet import enforce_context_budget, size

        checks=[]
        manifest=bundled_manifest(); validate_manifest(manifest)
        checks.append({"id":"manifest","status":"ok","kernel_id":manifest.get("kernel_id")})
        components=self.external_component_status() if hasattr(self,"external_component_status") else []
        if len(components)!=len(manifest.get("external_components",[])) or any(not x.get("installed") for x in components):
            raise ValueError("packaged component bootstrap failed")
        checks.append({"id":"executable_components","status":"ok","count":len(components)})

        req=[{"meaning":"preserve live objective","quote":"do it","turn_id":"t0"}]
        g1=build_goal_gravity(req,(),"t1"); g2=build_goal_gravity(req,(),"t1")
        if g1["signature"]!=g2["signature"]: raise ValueError("goal addressing failed")
        checks.append({"id":"goal_addressing","status":"ok"})

        strategy,_=normalize_search_plan({"branches":[{
            "id":"seed","query":"state recovery latency checkpoint architecture",
            "mechanism":"arbitrary task-native mechanism family",
            "discriminator":"whether checkpointing changes restart cost","parent_ids":[]
        }]},empty_search_strategy())
        strategy=bind_search_observation(strategy,["seed"],source_ref="source:x",origin_ref="tool:x",result_sha256="a"*64)
        child={"query":"resume token invalidation after checkpoint",
               "mechanism":"another completely open label","discriminator":"whether invalidation dominates restart cost",
               "parent_ids":["seed"],"parent_observation_sha256":["a"*64]}
        normalize_search_plan({"branches":[child]},strategy)
        checks.append({"id":"open_search_lineage","status":"ok"})

        packet={"request":"x"*50000,
                "sections":{"new_observations":[{"ref":"E1","id":"entry:x","content":"y"*50000}],
                            "observation_refs":["entry:x"]},
                "references":{"E1":"entry:x"},"omitted":[]}
        compact=enforce_context_budget(packet,2500)
        if size(compact)>2500 or "entry:x" not in compact.get("sections",{}).get("observation_refs",[]):
            raise ValueError("context hard cap or causal address preservation failed")
        checks.append({"id":"context_cap","status":"ok","chars":size(compact)})

        with tempfile.TemporaryDirectory() as td:
            store=StateStore(td); store.open_turn("s","t","probe","task")
            r1=store.save_runtime("t",{"extensions":{}},expected_revision=None)
            try: store.save_runtime("t",{"extensions":{}},expected_revision=None)
            except JigaewolError: pass
            else: raise ValueError("state create-only CAS failed")
            store.save_runtime("t",{"extensions":{}},expected_revision=r1)

            integrations=IntegrationStore(td+"/integrations")
            upstream="def solve(data):\n    return {'value': data['value'] * 2}\n"
            remote={"id":"remote_probe","version":"1","kind":"python_method","purpose":"execution probe",
                    "applicability":["*"],"effect_contract":{"produces":["computed value"]},
                    "origin":{"kind":"github","ref":"owner/repo:path","source_sha256":hashlib.sha256(upstream.encode()).hexdigest()},
                    "instruction":"execute pinned method",
                    "method":{"id":"probe","purpose":"double","representation":"number","entrypoint":"solve",
                              "applicability":"self-check","source":upstream}}
            installed=integrations.install(remote,observed_source=upstream)
            job=prepare_job(installed["method"],{"value":4}); report=run_job(job)
            if report.get("status")!="ok" or report.get("output")!={"value":8}:
                raise ValueError("content-pinned executable integration failed")
            checks.append({"id":"content_pinned_execution","status":"ok"})

            gate=AccessGateStore(td+"/access"); secret="selfcheck-key"; gate.configure(secret)
            if not gate.verify(secret) or gate.verify("wrong") or secret in gate.path.read_text():
                raise ValueError("keyed access storage failed")
            if not marker_matches("JIGAEWOL::PRIORITY") or marker_matches("JIGAEWOL::PRIORITY OFF"):
                raise ValueError("access marker failed")
            checks.append({"id":"keyed_access","status":"ok"})

        low=budget_for_signals(CompileSignals.simple_chat(),profile="custom_profile")
        low_apex=budget_for_signals(CompileSignals.simple_chat(),profile="apex")
        if low != low_apex: raise ValueError("profile names must not buy resource headroom")
        high=budget_for_signals(CompileSignals(intent_count=8,creative_leverage=.8,artifact_surface=1,requested_intensity=5,needs_research=True),profile="custom_profile")
        if high.max_nodes<=low.max_nodes: raise ValueError("adaptive resource scaling failed")
        checks.append({"id":"adaptive_resources","status":"ok","profile_neutral":True,"low":low.depth_class,"high":high.depth_class})

        digest=hashlib.sha256(canonical(checks).encode()).hexdigest()
        return {"status":"ok","kernel_id":manifest.get("kernel_id"),"kernel_sha256":manifest.get("manifest_sha256"),
                "checks":checks,"checks_sha256":digest,
                "scope":"deterministic runtime guarantees only; not a claim of semantic intelligence"}

    def method_library(self):
        """Current session's retained method metadata; never executes a method."""
        return self.store.method_library(self.session_id)

    def method_by_hash(self, method_hash):
        return self.store.method_by_hash(self.session_id, method_hash)

    def _queue_method(self, runtime, target, request, parent_job=None):
        if not isinstance(request, dict) or set(request) - {
                "method", "method_hash", "input", "input_from", "question", "prediction", "capability_id"}:
            raise ValueError("method_request fields: method or method_hash, input or input_from, question, prediction?, capability_id?")
        if bool("method" in request) == bool("method_hash" in request):
            raise ValueError("supply one method definition or one retained method_hash")
        if not isinstance(request.get("question"), str) or not request["question"].strip():
            raise ValueError("state the question this computation can change")
        if bool("input" in request) == bool("input_from" in request):
            raise ValueError("supply actual JSON input or input_from")
        if "method_hash" in request:
            record = self.method_by_hash(request["method_hash"])
            if record is None:
                raise ValueError("unknown retained method_hash in this session")
            method = record["method"]
        else:
            method = request["method"]
        data = request.get("input")
        if "input_from" in request:
            previous = request["input_from"]
            if not isinstance(previous, dict) or set(previous) != {"job_id", "path"}:
                raise ValueError("input_from needs job_id and path")
            run = runtime.extensions.get("method_runs", {}).get(previous["job_id"])
            if not run or run.get("result", {}).get("status") != "ok":
                raise ValueError("input_from needs a completed successful current-turn computation")
            data = deepcopy(read_path(run["result"]["output"], previous["path"]))
        job = prepare_job(method, data)
        if parent_job and job["job_id"] == parent_job:
            raise ValueError("revise the method or its input before another computation")
        if job["job_id"] in runtime.extensions.get("method_runs", {}):
            raise ValueError("this exact computation is already recorded; reuse its result or revise its input/method")
        prediction = request.get("prediction")
        if prediction is not None:
            if not isinstance(prediction, dict) or set(prediction) != {"path", "equals"}:
                raise ValueError("prediction needs path and equals against the future result")
            # Syntax only: no result exists yet.
            if not isinstance(prediction["path"], list) or any(type(k) not in (str, int) for k in prediction["path"]):
                raise ValueError("prediction path must be a JSON path")
            canonical(prediction["equals"])
        caps = runtime.extensions["capability_specs"]
        chosen = request.get("capability_id")
        cap = next((c for c in caps if (c["id"] == chosen if chosen else c.get("role") == "compute")), None)
        if cap is None:
            raise ValueError("connect an actual native Python capability with role=compute")
        tool = self._cap_node(runtime, cap["id"], {"method_job": job})
        interpret = self._node(runtime, "host_semantic", "methods.interpret",
            parameters={"job_id": job["job_id"], "resume_node_id": target.node_id})
        self._replace_pending(runtime, (target.node_id,), [tool, interpret, target], count_rewrite=False, required=True)
        runtime.extensions.setdefault("method_runs", {})[job["job_id"]] = {
            "job": job, "question": request["question"], "prediction": deepcopy(prediction),
            "parent_job": parent_job, "input_from": deepcopy(request.get("input_from")),
            "resume_operation": target.operation}
        return runtime.ledger.add_observation({"method_job": job["job_id"], "question": request["question"],
            "representation": method["representation"], "status": "queued_for_actual_host_tool"})

    def _method_tool_result(self, runtime, node, payload, source_ref):
        job = dict(node.parameters).get("method_job")
        if not job:
            return
        result = payload.get("output")
        if not isinstance(result, dict):
            raise ValueError("submit the actual run_job result object")
        for key in ("job_id", "method_hash", "input_hash"):
            if result.get(key) != job[key]:
                raise ValueError("computation result does not match the pending job/input/method")
        status = result.get("status")
        if status not in {"ok", "error", "timeout"}:
            raise ValueError("computation result status must be ok, error or timeout")
        elapsed = result.get("elapsed_seconds")
        if type(elapsed) not in (int, float) or not math.isfinite(elapsed) or elapsed < 0:
            raise ValueError("computation result needs actual nonnegative elapsed_seconds")
        if status == "ok":
            if "output" not in result or hashlib.sha256(canonical(result["output"]).encode("utf-8")).hexdigest() != result.get("output_hash"):
                raise ValueError("actual computation output hash does not match")
        elif not isinstance(result.get("error"), str) or not result["error"].strip():
            raise ValueError("failed computation needs its actual error")
        run = runtime.extensions["method_runs"][job["job_id"]]
        run.update(result=deepcopy(result), source_ref=source_ref, origin_ref=payload["origin_ref"])
        if run["prediction"] is not None:
            try:
                actual = read_path(result, run["prediction"]["path"])
                run["prediction_result"] = {"observed": actual,
                    "matched": canonical(actual) == canonical(run["prediction"]["equals"])}
            except ValueError:
                run["prediction_result"] = {"matched": False, "reason": "predicted_path_absent"}
        runtime.extensions["latest_method_result"] = deepcopy(run)

    def _interpret_method(self, runtime, node, payload):
        jid = dict(node.parameters)["job_id"]
        run = runtime.extensions["method_runs"][jid]
        if "result" not in run:
            raise ValueError("interpretation requires an actual submitted computation result")
        observed = observation_of(run["result"], payload.get("observation"))
        consequence = payload.get("consequence")
        if not isinstance(consequence, str) or not consequence.strip():
            raise ValueError("state how this observation changes the next action or representation")
        action = payload.get("next")
        if action not in {"use", "revise", "discard"}:
            raise ValueError("next must be use, revise or discard")
        if action == "use" and run["result"]["status"] != "ok":
            raise ValueError("failed computations cannot be used as a successful method")
        if action == "revise":
            target = runtime.program.node(dict(node.parameters)["resume_node_id"])
            self._queue_method(runtime, target, payload.get("revision"), parent_job=jid)
        elif "revision" in payload:
            raise ValueError("revision belongs to next=revise")
        retain = payload.get("retain")
        if retain is not None:
            if action != "use" or not isinstance(retain, str) or not retain.strip():
                raise ValueError("retain needs the observed applicability condition of a used method")
            method = run["job"]["method"]
            runtime.extensions.setdefault("retained_methods", {})[run["job"]["method_hash"]] = {
                "method": deepcopy(method), "method_hash": run["job"]["method_hash"],
                "turn_id": runtime.raw.turn_id, "job_id": jid, "source_ref": run["source_ref"],
                "reuse_condition": retain, "basis": "host_selected_after_actual_computation"}
        run["interpretation"] = {"observation": deepcopy(payload["observation"]), "consequence": consequence, "next": action}
        runtime.extensions["latest_method_result"] = deepcopy(run)
        return runtime.ledger.add_observation({"method_job": jid, "observed": observed,
            "consequence": consequence, "next": action, "basis": "host_interpretation_of_actual_output"})
