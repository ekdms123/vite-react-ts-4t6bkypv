from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field, asdict, replace
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json

from jigaewol_runtime.kernel.ids import new_id
from jigaewol_runtime.kernel.store import StateStore
from jigaewol_runtime.scopes.task import TaskScope
from jigaewol_runtime.contract.raw_turn import RawTurn, SourceSpan
from jigaewol_runtime.contract.intents import IntentProposal, build_intent_lattice
from jigaewol_runtime.contract.coverage import compute_closure
from jigaewol_runtime.contract.goal_contract import compile_goal_contract
from jigaewol_runtime.compiler.signals import CompileSignals, apply_task_model
from jigaewol_runtime.compiler.compile import compile_turn, capability_specs, is_search_capability
from jigaewol_runtime.capabilities.manifest import validate_parameters, provider_arguments
from jigaewol_runtime.capabilities.plugins import cognition_capability_stack, native_chat_capability_stack, self_expanding_capability_templates
from jigaewol_runtime.compiler.program_ir import ProgramNode
from jigaewol_runtime.compiler.recompile import rewrite_subgraph, rewrite_subgraph_parallel_phase
from jigaewol_runtime.scheduler.graph import Scheduler
from jigaewol_runtime.scheduler.dispatch import to_host_work
from jigaewol_runtime.blackboard.ledger import Ledger
from jigaewol_runtime.intake.universal import intake_attachments
from jigaewol_runtime.bridge.runtime_state import encode_runtime, decode_runtime
from jigaewol_runtime.scopes.repertoire import RepertoireStore
from jigaewol_runtime.bridge.host_contract import build_runtime_schema_registry, validate_semantic_transport
from jigaewol_runtime.bridge.guidance import GUIDANCE
from jigaewol_runtime.bridge.workflows import WorkflowMixin, MATERIAL, SEMANTIC
from jigaewol_runtime.operators.spec import OperatorSpec
from jigaewol_runtime.operators.generated import apply_generated_operator
from jigaewol_runtime.contract.extraction import extract_requirements, ensure_accounted, request_segments, provisional_request_segments
from jigaewol_runtime.bridge.context_packet import make_packet, normalize_result, TASK_CONTEXT_RULE, apply_visibility_partition
from jigaewol_runtime.bridge.authority_plane import authority_plane_snapshot
from jigaewol_runtime.bridge.route_resilience import route_signature, failed_route_record
from jigaewol_runtime.bridge.goal_route_state import GoalRouteStateStore
from jigaewol_runtime.bridge.methods import MethodsMixin
from jigaewol_runtime.cognition import ExternalKernelStore, compiled_kernel_packet, bundled_manifest
from jigaewol_runtime.cognition.components import (
    bootstrap_packaged_components, remote_fetch_plan, verify_remote_component, extract_fetched_text,
)
from jigaewol_runtime.cognition.load import structural_pressure
from jigaewol_runtime.learning import trajectory_credit, CreditStore
from jigaewol_runtime.governor import build_execution_fabric, charge_execution_fabric
from jigaewol_runtime.interpretability import public_trace_graph
from jigaewol_runtime.cognition.structures import partition_for
from jigaewol_runtime.cognition.impact import observation_policy, add_pending_observation
from jigaewol_runtime.cognition.epoch import delta_instruction
from jigaewol_runtime.adaptation import (
    build_goal_gravity, AdaptationArchive, IntegrationStore,
    bind_search_observation, empty_search_strategy,
)
from jigaewol_runtime.adaptation.source_perspectives import suggest_source_perspectives
from jigaewol_runtime.adaptation.runtime import AdaptationMixin
from jigaewol_runtime.judgment.turn_events import classify_turn_event
from jigaewol_runtime.judgment import (
    BoundaryStore, ResidualCompiler, ResidualStore, CausalMemory, CausalMechanism,
    RepresentationTransducer, DecisionProgramStore, build_pack, load_pack,
)
from jigaewol_runtime.judgment.boundary_router import translate_failure
from jigaewol_runtime.judgment.durable import DurableRunStore
from jigaewol_runtime.judgment.goal_lifecycle import GoalLifecycleStore
from jigaewol_runtime.judgment.provenance import runtime_fingerprint
from jigaewol_runtime.worlds.generation import NoveltyArchive, recombine_branch_results
from jigaewol_components.directive_invariant import recompute_from_raw, verify_atom_conservation, verify_destination
from jigaewol_components.source_authority import explicit_replacement_requested, explicit_new_task_requested
from jigaewol_components.authority_guard import source_continuation_requested, source_continuation_evidence, source_effect_authorized
from jigaewol_components.mutable_policy_evolution import MutablePolicyEvolution


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass(frozen=True)
class JigaewolView:
    turn_id: str
    task_id: str
    program_id: str
    phase: str
    next_work: tuple[object, ...]
    answer: object | None = None
    unresolved_intents: tuple[str, ...] = ()
    ledger_refs: tuple[str, ...] = ()
    attachment_inventory: tuple[str, ...] = ()
    attachment_context: tuple[str, ...] = ()
    pending_work: tuple[object, ...] = ()
    worlds: tuple[object, ...] = ()
    recompile_count: int = 0
    capabilities: tuple[str, ...] = ()
    repertoire_context: tuple[str, ...] = ()
    learned: bool = False
    notices: tuple[str, ...] = ()
    selected_trajectory: object | None = None

    def to_dict(self):
        return asdict(self)


@dataclass
class _Runtime:
    raw: RawTurn
    lattice: object
    program: object
    ledger: Ledger
    work_to_node: dict[str, str]
    answer: object | None = None
    attachment_inventory: tuple[str, ...] = ()
    attachment_context: tuple[str, ...] = ()
    pending_work: tuple[object, ...] = ()
    worlds: tuple[object, ...] = ()
    recompile_count: int = 0
    capabilities: tuple[str, ...] = ()
    repertoire_context: tuple[str, ...] = ()
    learned: bool = False
    extensions: dict = field(default_factory=dict)


def _segment_intents(message):
    # Provisional segments are replaced by the explicit extraction operation.
    return tuple(IntentProposal(s["text"], (SourceSpan(s["start"], s["end"]),), 5, True,
                                "segment:" + str(s["segment"])) for s in provisional_request_segments(message))


def _merge_task_requirements(*histories):
    merged, seen = [], set()
    for history in histories:
        for entry in history:
            key = (entry["meaning"], entry["quote"])
            if key not in seen:
                merged.append({k: entry[k] for k in ("meaning", "quote", "turn_id")})
                seen.add(key)
    return merged


def _current_task_requirements(lattice, raw):
    return _merge_task_requirements([
        {"meaning": node.meaning, "quote": span.text(raw.message), "turn_id": raw.turn_id}
        for node in lattice.nodes if node.required for span in node.source_spans])


def _bare_continuation(message):
    text = " ".join(str(message).casefold().strip().split()).rstrip(".!?~…")
    return text in {"이어서", "계속", "계속해", "계속해줘", "계속 진행", "continue", "go on", "keep going"}


def _previous_task_requirements(previous):
    if not previous:
        return []
    history = previous.get("extensions", {}).get("task_requirements")
    if history is not None:
        return _merge_task_requirements(history)
    # Legacy runtimes retain spans against their own original request.
    raw = previous["raw"]
    return _merge_task_requirements([
        {"meaning": node["meaning"], "quote": SourceSpan(**span).text(raw["message"]),
         "turn_id": raw["turn_id"]}
        for node in previous.get("lattice", {}).get("nodes", []) if node.get("required")
        for span in node.get("source_spans", [])])


def _signals(message, intent_count, attachments, capabilities, continuation=False):
    """Bootstrap only directly observable transport/structure signals.

    Semantic importance, ambiguity, research need and creative leverage belong to
    semantic intake. Surface length and a lexical turn label do not get to decide
    them before the runtime has interpreted the live task.
    """
    pressure = structural_pressure(message, intent_count=intent_count,
                                   attachment_count=len(attachments or ()),
                                   capability_count=len(capabilities or ()))
    return CompileSignals(intent_count=intent_count, ambiguity=None,
        ambiguity_basis="pending_semantic_intake:no_presemantic_meaning_claim",
        factual_stakes=0.0, creative_leverage=0.0,
        artifact_surface=1.0 if attachments else 0.0, requested_intensity=1,
        domain="general", needs_research=False, structural_pressure=pressure.structural_pressure)


def _task_signal_gravity(history):
    """Expose the latest semantic signal snapshot without turning history into a veto/floor.

    Older task interpretations remain inspectable in history, but their maxima do
    not silently become permanent properties of the live task.
    """
    rows = []
    for runtime in history or ():
        ext = runtime.get("extensions", {}) if isinstance(runtime, dict) else {}
        data = ext.get("compile_signals", {}) if isinstance(ext, dict) else {}
        if isinstance(data, dict) and data:
            rows.append(data)
    return deepcopy(rows[-1]) if rows else {}


def _continuation_signals(signals, previous, task_requirements=()):
    """Carry objective surface area, not inherited semantic conclusions.

    Continuation keeps the live destination attached. Ambiguity, stakes, research
    need, creativity and representation pressure are re-formed by current semantic
    intake instead of being forced upward by historical maxima.
    """
    if not previous:
        return signals
    active_count = max(signals.intent_count, len(tuple(task_requirements or ())))
    return replace(signals, intent_count=active_count)


def _route_capability_id(operation: str) -> str:
    operation = str(operation or "").strip()
    if operation.startswith("capability."):
        return operation.removeprefix("capability.")
    return "operation::" + operation


def _failed_routes_for_inheritance(previous: dict | None) -> list[dict]:
    if not isinstance(previous, dict):
        return []
    previous_turn_id = str((previous.get("raw") or {}).get("turn_id") or "")
    rows = []
    for raw in (previous.get("extensions") or {}).get("failed_routes", []) or []:
        if not isinstance(raw, dict):
            continue
        if raw.get("routing_context_source") == "durable_goal_route_state":
            continue
        observed_turn_id = str(raw.get("observed_turn_id") or "")
        if observed_turn_id and previous_turn_id and observed_turn_id != previous_turn_id:
            continue
        rows.append(deepcopy(raw))
    return rows


def _merge_failed_route_context(inherited_rows, durable_states, previous_turn_id: str) -> list[dict]:
    merged: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for raw in inherited_rows or ():
        if not isinstance(raw, dict):
            continue
        row = deepcopy(raw)
        row.setdefault("observed_turn_id", str(previous_turn_id or ""))
        row.setdefault("routing_context_source", "previous_turn")
        key = (str(row.get("signature") or ""), str(row.get("operation") or ""))
        if key in seen:
            continue
        seen.add(key); merged.append(row)
    for state in durable_states or ():
        capability_id = str(state.capability_id)
        operation = (capability_id.removeprefix("operation::") if capability_id.startswith("operation::")
                     else "capability." + capability_id)
        row = {
            "signature": state.route_signature,
            "operation": operation,
            "failure_ref": state.last_failure_receipt,
            "failure_count": state.failure_count,
            "cooldown": state.cooldown,
            "scope": "goal_route_state",
            "destination_effect": "none",
            "routing_context_source": "durable_goal_route_state",
        }
        key = (str(row["signature"]), str(row["operation"]))
        if key in seen:
            continue
        seen.add(key); merged.append(row)
    return merged


class JigaewolRuntime(AdaptationMixin, MethodsMixin, WorkflowMixin):
    def __init__(self, state_dir, session_id="chat"):
        self.store = StateStore(state_dir)
        self.session_id = session_id
        state_path = Path(state_dir)
        self.repertoire = RepertoireStore(state_path.parent / (state_path.name + "_repertoire") / session_id)
        self.external_kernel = ExternalKernelStore(state_path, auto_configure=False)
        self.adaptation = AdaptationArchive(self.store, self.session_id)
        self.integrations = IntegrationStore(self.store, self.session_id)
        # Default components are executable semantic extensions, not documentary links.
        # Exact packaged bytes are checked against the same SHA pins used by
        # GitHub before they enter the extension registry.
        self.external_component_bootstrap = bootstrap_packaged_components(self.integrations, bundled_manifest())
        # persistent judgment plane: persistent executable boundaries, causal
        # mechanisms, residual compilers, and authoritative run events.
        judgment_root = state_path / "judgment" / session_id
        self.novelty_archive = NoveltyArchive(judgment_root / "world_novelty.json")
        self.boundaries = BoundaryStore(judgment_root / "boundaries.json")
        # Restored after the lineage merge. The keyed *access gate* stayed removed —
        # a permission key over the user's own runtime is precisely the kind of gate
        # this merge is stripping out. The evidence-retention arbitrator is not a
        # gate: it decides what evidence is kept, and it stays lazy so importing the
        # runtime never pays for it.
        self._evidence_retention = None
        self.causal_memory = CausalMemory(judgment_root / "causal_memory.json")
        self.residual_compiler = ResidualCompiler()
        self.residuals = ResidualStore(judgment_root / "residuals.json")
        self.decision_programs = DecisionProgramStore(judgment_root / "decision_programs.json")
        self.representation_transducer = RepresentationTransducer(judgment_root / "lenses.json")
        self.durable_runs = DurableRunStore(judgment_root / "runs.sqlite3")
        self.goal_lifecycle = GoalLifecycleStore(judgment_root / "goals.json")
        self.goal_route_states = GoalRouteStateStore(judgment_root / "goal_routes.sqlite3")
        self.route_policy_evolution = MutablePolicyEvolution(judgment_root / "route_policy_evolution")
        self.credit_store = CreditStore(judgment_root / "credit")
        self.schemas = build_runtime_schema_registry()
        self._runtimes = {}


    @property
    def evidence_retention(self):
        if self._evidence_retention is None:
            from jigaewol_runtime.governor.evidence_retention import EvidenceRetentionArbitrator
            self._evidence_retention = EvidenceRetentionArbitrator()
        return self._evidence_retention


    def install_decision_boundary(self, discriminators, cases, default_action, **kwargs):
        return self.boundaries.add(discriminators, cases, default_action, **kwargs)

    def decide_boundary(self, features):
        return self.boundaries.decide(features)

    def compile_residual(self, baseline, corrected, **kwargs):
        return self.residuals.add(self.residual_compiler.compile(baseline, corrected, **kwargs))

    def compile_decision_program(self, cases, **kwargs):
        return self.decision_programs.compile(cases, **kwargs)

    def decide_program(self, program_id, features):
        return self.decision_programs.decide(program_id, features)

    def remember_causal_mechanism(self, mechanism):
        if not isinstance(mechanism, CausalMechanism):
            mechanism = CausalMechanism(**{**mechanism,
                "nodes": tuple(tuple(x) for x in mechanism.get("nodes", ())),
                "edges": tuple(tuple(x) for x in mechanism.get("edges", ())),
                "preconditions": tuple(mechanism.get("preconditions", ())),
                "failure_modes": tuple(mechanism.get("failure_modes", ()))})
        return self.causal_memory.add(mechanism)

    def recall_causal_mechanisms(self, query, limit=None):
        if not isinstance(query, CausalMechanism):
            query = CausalMechanism(**{**query,
                "nodes": tuple(tuple(x) for x in query.get("nodes", ())),
                "edges": tuple(tuple(x) for x in query.get("edges", ())),
                "preconditions": tuple(query.get("preconditions", ())),
                "failure_modes": tuple(query.get("failure_modes", ()))})
        return self.causal_memory.retrieve(query, k=limit)

    def judgment_pack(self, validation_receipts=(), parent_pack_ids=()):
        from dataclasses import asdict as _asdict
        boundaries=[_asdict(x) for x in self.boundaries.boundaries.values()]
        causal=[_asdict(x) for x in self.causal_memory.items.values()]
        lenses=self.representation_transducer.export()
        residuals=self.residuals.export()
        decision_programs=self.decision_programs.export()
        return build_pack(boundaries=boundaries, lenses=lenses, residuals=residuals, causal_mechanisms=causal,
                          decision_programs=decision_programs, validation_receipts=validation_receipts, parent_pack_ids=parent_pack_ids)

    def install_judgment_pack(self, pack):
        """Install a content-addressed judgment inheritance pack into this session.

        Pack validation receipts remain attached provenance; installation never
        upgrades their truth state.
        """
        from jigaewol_runtime.judgment.inheritance import load_pack, JudgmentPack
        from jigaewol_runtime.judgment.boundary import BoundaryCase
        if not isinstance(pack, JudgmentPack):
            pack = load_pack(pack) if isinstance(pack, (str, Path)) else JudgmentPack(**pack)
        for b in pack.boundaries:
            cases=[BoundaryCase(**c) if not isinstance(c, BoundaryCase) else c for c in b.get("cases",())]
            self.boundaries.add(b.get("discriminators",()), cases, b.get("default_action","open"),
                flip_conditions=b.get("flip_conditions",()), priority=b.get("priority",0), boundary_id=b.get("boundary_id"))
        self.representation_transducer.install(pack.lenses)
        self.residuals.install(pack.residuals)
        self.decision_programs.install(pack.decision_programs)
        for m in pack.causal_mechanisms:
            self.remember_causal_mechanism(m)
        return {"pack_id":pack.pack_id,"boundaries":len(pack.boundaries),"lenses":len(pack.lenses),
                "residuals":len(pack.residuals),"decision_programs":len(pack.decision_programs),
                "causal_mechanisms":len(pack.causal_mechanisms),"validation_receipts":len(pack.validation_receipts)}

    def execute_route(self, turn_id, route_executor, route_id, context=None):
        """Execute a declared route graph and bind recovery as runtime evidence."""
        result = route_executor.run(route_id, context or {})
        runtime = self._runtimes.get(turn_id)
        if runtime is not None:
            record={"requested_route_id":route_id,"selected_route_id":result.route_id,"status":result.status,
                    "attempts":list(result.attempts),"failure":result.failure}
            runtime.extensions.setdefault("route_recoveries", []).append(record)
            try:
                self._persist(runtime)
            except Exception as exc:
                runtime.extensions.setdefault("nonblocking_notices", []).append({
                    "kind": "route_recovery_persist_failed",
                    "error_type": type(exc).__name__,
                    "message": str(exc)[:300],
                })
        return result

    def engine_fingerprint(self):
        package_root = Path(__file__).resolve().parents[1]
        effective = self.external_kernel.effective() or {}
        manifest = effective.get("manifest", {}) if isinstance(effective, dict) else {}
        return runtime_fingerprint(package_root, manifest.get("manifest_sha256"))

    def configure_external_kernel(self, repository_full_name, path=None, ref=None, expected_sha256=None, enabled=True, allow_schema_downgrade=False):
        """Configure a GitHub-hosted cognitive manifest for this local state directory."""
        from jigaewol_runtime.cognition.external import DEFAULT_PATH
        return self.external_kernel.configure(
            repository_full_name, path or DEFAULT_PATH, ref, expected_sha256, enabled,
            allow_schema_downgrade=allow_schema_downgrade,
        )

    def external_kernel_status(self):
        return self.external_kernel.status()

    def external_component_status(self):
        """Report content-pinned components currently installed in this session."""
        catalog={x.get("id"):x for x in self.integrations.catalog(limit=None) if isinstance(x,dict)}
        manifest=((self.external_kernel.effective() or {}).get("manifest") or bundled_manifest())
        rows=[]
        for plan in remote_fetch_plan(manifest):
            integration=catalog.get(plan["id"])
            rows.append({
                "id":plan["id"],
                "expected_sha256":plan["expected_sha256"],
                "installed":bool(integration),
                "integration_manifest_sha256":integration.get("manifest_sha256") if integration else None,
                "remote_ref":(integration.get("origin",{}) or {}).get("ref") if integration else None,
            })
        return rows

    def external_component_fetch_plan(self, component_ids=()):
        """Return exact GitHub fetch work for refreshing pinned components."""
        manifest=((self.external_kernel.effective() or {}).get("manifest") or bundled_manifest())
        return remote_fetch_plan(manifest, only_ids=component_ids)

    def ingest_external_component(self, component_id, fetched_output):
        """Verify real fetched bytes and idempotently install the registered component extension."""
        manifest=((self.external_kernel.effective() or {}).get("manifest") or bundled_manifest())
        text=extract_fetched_text(fetched_output)
        descriptor,integration=verify_remote_component(manifest, str(component_id), text)
        checked=self.integrations.install(integration, observed_source=text)
        return {
            "id":checked["id"],
            "source_sha256":descriptor["sha256"],
            "manifest_sha256":checked["manifest_sha256"],
            "status":"remote_bytes_verified_and_installed",
            "remote_ref":checked["origin"]["ref"],
        }

    def begin(self, message, attachments=(), capabilities=(), task_id=None, *, new_task=False, mode="auto", intents=None, continuation=None, generator_id=None, profile="apex", capability_acquisitions=(), semantic_authority=None):
        if not isinstance(new_task, bool):
            raise ValueError("new_task must be boolean")
        if continuation is not None and not isinstance(continuation, bool):
            raise ValueError("continuation must be boolean or None")
        """Open one user turn atomically.

        Validation and compilation are staged before the durable turn row is
        created. If initial advancement fails, the new row/runtime are removed
        so a failed begin cannot invalidate receipts for the preceding turn.
        """
        if not isinstance(message, str) or not message.strip():
            raise ValueError("provide the actual current user message")
        if not isinstance(mode,str) or not mode.strip():
            raise ValueError("mode must be nonempty text")
        if not isinstance(profile,str) or not profile.strip():
            raise ValueError("profile must be nonempty text")
        mode=mode.strip(); profile=profile.strip()
        semantic_authority = dict(semantic_authority or {})
        semantic_trait_hints = tuple(
            str(x) for x in semantic_authority.get("required_capability_traits", ()) if str(x)
        ) if semantic_authority else ()
        semantic_required_traits = semantic_trait_hints if source_effect_authorized(semantic_authority) else ()

        tid = new_id("turn")
        active = self.store.latest_task_for_session(self.session_id)
        source_requests_new_task = explicit_new_task_requested(message)
        rejected_scope_hints: list[str] = []
        if active and new_task and not source_requests_new_task:
            # ``new_task`` is a host/runtime routing hint, not user authority.  A
            # caller may not detach unfinished obligations unless the exact source
            # message itself requests a separate task.
            rejected_scope_hints.append("caller_new_task_without_exact_user_source")
            new_task = False
        if active and continuation is False and not source_requests_new_task:
            rejected_scope_hints.append("caller_continuation_false_without_exact_user_source")
            continuation = None
        if source_requests_new_task:
            new_task = True
            continuation = False
        task = TaskScope.resolve(active, task_id, new_task)
        raw = RawTurn.create(tid, message, tuple(str(a) for a in attachments), None, task)
        verify_destination(
            raw_user_text=message,
            original_user_directive_sha256=raw.source_hash,
        )
        planning_snapshot = recompute_from_raw(message)
        verify_atom_conservation(
            raw_user_text=message,
            active_atom_ids=planning_snapshot.original_active_atom_ids,
        )
        proposals = tuple(intents) if intents is not None else _segment_intents(message)
        if not proposals:
            raise ValueError("at least one source-grounded intent is required")
        lattice = build_intent_lattice(raw, proposals)
        if intents is not None:
            ensure_accounted(message, [s for p in proposals for s in p.source_spans])
        intake = intake_attachments(attachments)

        previous = None if new_task else self.store.latest_runtime_for_task(task, self.session_id, tid)
        task_history = [] if new_task else self.store.runtime_history_for_task(task, self.session_id, tid)
        task_gravity = _task_signal_gravity(task_history)
        turn_event = classify_turn_event(message, has_open_task=bool(previous))
        # Prior work is durable context, not current authority.  It becomes active
        # only when the exact current source contains an explicit continuation/anaphora
        # reference.  Host/model routing hints cannot manufacture continuity.
        continuation_evidence = source_continuation_evidence(message)
        follows = bool(previous) and bool(continuation_evidence)
        if previous and continuation is True and not follows:
            rejected_scope_hints.append("caller_continuation_true_without_exact_user_source")
        signals = _signals(message, len(lattice.nodes), attachments, capabilities, follows)
        if mode == "direct":
            signals = CompileSignals.simple_chat()
        external_request = self.external_kernel.fetch_parameters()
        program = compile_turn(lattice, signals, capabilities, profile=profile, external_kernel_request=external_request, required_traits=semantic_required_traits)
        recalled = self.repertoire.recall(message)
        context = tuple({"strategy": p["strategy"], "basis": "user_feedback"} for p in recalled)
        inherited = None
        if previous:
            inherited = {"turn_id": previous["raw"]["turn_id"], "request": previous["raw"]["message"],
                         "answer": previous.get("answer"), "unresolved": previous.get("extensions", {}).get("unresolved", []),
                         "phase": previous.get("extensions", {}).get("phase", "unknown"),
                         "signals": {**task_gravity, **{k: v for k, v in previous.get("extensions", {}).get("compile_signals", {}).items()
                                                   if k not in task_gravity}},
                         "feedback_preferences": previous.get("extensions", {}).get("feedback_plane", {}).get("preferences", []),
                         "feedback_decision": previous.get("extensions", {}).get("feedback_decision"),
                         "delivery_feedback": previous.get("extensions", {}).get("delivery_feedback"),
                         "cognitive_frame": previous.get("extensions", {}).get("cognitive_frame"),
                         "generative_world": previous.get("extensions", {}).get("generative_world"),
                         "decision_state": previous.get("extensions", {}).get("decision_state"),
                         "goal_contract": previous.get("extensions", {}).get("goal_contract"),
                         "failed_routes": _failed_routes_for_inheritance(previous)}
        continuation_determined = bool(follows)
        previous_requirements = _previous_task_requirements(previous) if follows else []
        current_task_requirements = (_current_task_requirements(lattice, raw)
            if intents is not None and not (follows and _bare_continuation(message)) else [])
        task_requirements = _merge_task_requirements(
            previous_requirements if follows else [],
            current_task_requirements)
        # Bind the goal lifecycle to the actual turn path whenever intake is
        # already source-grounded (explicit intents). Semantic intake will run
        # the same sync after extraction on ordinary chat turns.
        if intents is not None:
            self.goal_lifecycle.sync_turn(
                task_id=task, source_turn_id=tid, requirements=current_task_requirements,
                event_kind=turn_event.kind, bare_continuation=bool(follows and _bare_continuation(message)),
                exact_user_text=message)
            lifecycle_requirements = self.goal_lifecycle.as_requirements(task)
            # The lifecycle is authoritative once synchronized. Do not merge
            # superseded historical requirements back in through the raw
            # continuation cache; only retain source-grounded requirements
            # from this turn alongside still-active lifecycle goals.
            task_requirements = _merge_task_requirements(lifecycle_requirements, current_task_requirements)
        gravity_intents = () if (turn_event.kind in {"CANCEL"} or (follows and _bare_continuation(message))) else lattice.nodes
        goal_gravity = build_goal_gravity(task_requirements, gravity_intents, tid)
        directive_authority = {"active": True, "mode": "user_directive", "silent_goal_shrink_allowed": False}
        if isinstance(capability_acquisitions, (str, bytes)) or not isinstance(capability_acquisitions, (list, tuple)):
            raise ValueError("capability_acquisitions must be a list or tuple")
        if any(not isinstance(row, dict) for row in capability_acquisitions):
            raise ValueError("capability_acquisitions entries must be objects")
        capability_acquisition_snapshot = deepcopy(list(capability_acquisitions))
        source_perspective_hints = suggest_source_perspectives(
            message,
            novelty_pressure=max(
                float(getattr(signals, "exploration_leverage", 0.0) or 0.0),
                float(getattr(signals, "creative_leverage", 0.0) or 0.0),
            ),
        )
        adaptation_query = message + " " + " ".join(str(x.get("meaning", "")) for x in task_requirements)
        budget_nodes=max(1,int(program.budget_policy.max_nodes))
        adaptation_seed = self.adaptation.recall(adaptation_query, limit=None)
        integration_catalog = self.integrations.catalog(limit=None)
        if follows and inherited and mode != "direct":
            signals = _continuation_signals(signals, inherited, previous_requirements)
            program = compile_turn(lattice, signals, capabilities, profile=profile, external_kernel_request=external_request, required_traits=semantic_required_traits)
        component_credit = self.credit_store.snapshot(limit=None)
        initial_task_model = {}
        prior_goal_contract = (previous.get("extensions", {}).get("goal_contract") if previous and follows else None)
        goal_contract = compile_goal_contract(
            message, task_requirements, initial_task_model, source_hash=raw.source_hash, prior=prior_goal_contract
        )
        if intents is None:
            intake_node = ProgramNode(new_id("node"), "host_semantic", "intents.extract",
                intent_refs=program.objective_refs, expected_effects=("accounted_requirements",), cost_estimate=.1)
            program = replace(program, nodes=(intake_node,), edges=())
        active_goal_route_states = self.goal_route_states.active_for_task(task) if follows else ()
        inherited_failed_routes = list((inherited or {}).get("failed_routes", [])) if follows else []
        routing_failed_routes = _merge_failed_route_context(
            inherited_failed_routes, active_goal_route_states,
            str((inherited or {}).get("turn_id") or ""),
        )
        runtime = _Runtime(raw, lattice, program, Ledger(), {}, attachment_inventory=intake.inventory,
            attachment_context=intake.context_slices, capabilities=tuple(c["id"] for c in capability_specs(capabilities)),
            repertoire_context=context, extensions={"capability_specs": capability_specs(capabilities),
                "cognition_stack_catalog": [{**m.to_spec(), "connection_state": "host_must_expose"} for m in cognition_capability_stack()],
                "self_expanding_capability_catalog": [{**m.to_spec(), "connection_state": "host_must_expose"} for m in self_expanding_capability_templates()],
                "native_capability_catalog": [{**m.to_spec(), "connection_state": "host_must_expose"} for m in native_chat_capability_stack()],
                "previous_turn": inherited if follows and continuation_determined else None,
                "_previous_turn_candidate": inherited if continuation is None else None,
                "failed_routes": routing_failed_routes,
                "failed_route_signatures": sorted({str(x.get("signature")) for x in routing_failed_routes if x.get("signature")}),
                "goal_route_states": [asdict(x) for x in active_goal_route_states],
                "_previous_task_requirements": previous_requirements,
                "task_requirements": task_requirements, "continuation_determined": continuation_determined,
                "notices": [], "receipts": {}, "tool_submissions": [], "unresolved": [], "mode": mode,
                "profile": profile, "generator_id": generator_id,
                "semantic_authority": deepcopy(semantic_authority),
                "execution_policy": {
                    "profile_resource_neutral": True,
                    "adaptive_depth": True,
                    "github_every_turn_when_connected": False,
                    "repository_observation_when_relevant": True,
                    "open_set_tool_selection": True,
                    "post_observation_reassessment": True,
                    "truth_states": ["executed", "observed", "inferred", "proposed", "open"],
                    "route_failure_is_local": True,
                },
                "turn_event": {"kind": turn_event.kind, "confidence": turn_event.confidence, "evidence": list(turn_event.evidence)},
                "method_library": self.method_library(),
                "judgment_plane": {
                    "lenses": self.representation_transducer.export(),
                    "residuals": self.residuals.export(),
                    "decision_programs": self.decision_programs.export(),
                    "causal_mechanisms": [asdict(x) for x in self.causal_memory.items.values()],
                },
                "external_kernel": self.external_kernel.effective(),
                "external_kernel_config": self.external_kernel.config(),
                "cognitive_repertoire": {item["id"]: item for item in self.store.cognitive_operator_library(self.session_id)},
                "continuation": follows, "continuation_override": continuation,
                "compile_signals": asdict(signals), "task_signal_gravity": task_gravity,
                "goal_gravity": goal_gravity,
                "goal_contract": goal_contract,
                "component_credit": component_credit, "task_model": initial_task_model,
                "execution_fabric": build_execution_fabric(task_id=task, max_nodes=program.budget_policy.max_nodes,
                    depth_class=program.budget_policy.depth_class, profile=profile,
                    needs_research=bool(signals.needs_research)),
                "goal_lifecycle": [asdict(x) for x in self.goal_lifecycle.active(task)],
                "attachment_media": [deepcopy(x) for x in intake.media],
                "user_directive_authority": directive_authority,
                "adaptation_seed": adaptation_seed,
                "search_strategy": empty_search_strategy(),
                "source_perspective_hints": [deepcopy(x) for x in source_perspective_hints],
                "capability_acquisitions": capability_acquisition_snapshot,
                "integration_catalog": integration_catalog,
                "integration_runs": {}, "integration_ids_used": [],
                "intake_confirmed": intents is not None,
                "task_id_explicit": task_id is not None,
                "new_task_explicit": bool(new_task),
                "source_authorized_new_task": bool(source_requests_new_task),
                "rejected_scope_hints": tuple(rejected_scope_hints)})
        self.store.open_turn(self.session_id, tid, message, task_id=task)
        try:
            self.durable_runs.append(tid, task, "TURN_OPENED", {"event": turn_event.kind, "message_sha256": raw.source_hash})
        except Exception as exc:
            runtime.extensions["notices"].append("durable run journal unavailable: " + str(exc))
        self._runtimes[tid] = runtime
        try:
            view = self._advance(tid)
            if follows and active_goal_route_states:
                self.goal_route_states.decrement_cooldowns(task)
            return view
        except Exception:
            self._runtimes.pop(tid, None)
            self.store.discard_turn(tid, self.session_id)
            raise

    def _record_route_outcome(self, runtime, *, operation, parameters, outcome, evidence_ref):
        operation = str(operation or "").strip()
        if not operation.startswith("capability."):
            return None
        outcome = str(outcome or "").strip().casefold()
        if outcome not in {"success", "failure"}:
            raise ValueError("route outcome must be success or failure")
        task_id = str(runtime.raw.task_id or "")
        capability_id = _route_capability_id(operation)
        signature = route_signature(operation, parameters)
        if outcome == "failure":
            state = self.goal_route_states.record_failure(
                task_id=task_id, capability_id=capability_id, route_signature=signature,
                failure_receipt=str(evidence_ref),
            )
        else:
            state = self.goal_route_states.record_success(
                task_id=task_id, capability_id=capability_id, route_signature=signature,
            )
        vector = self.route_policy_evolution.record_outcome_vector(
            family="execution_route_outcomes",
            subject_ref=f"{task_id}:{capability_id}:{signature}",
            case_id=task_id,
            scores={
                "success": 1.0 if outcome == "success" else 0.0,
                "stability": 1.0 / (1.0 + float(state.failure_count)),
                "cooldown_clear": 1.0 if state.cooldown == 0 else 0.0,
                "evidence_quality": 1.0,
            },
            evidence_refs=(str(evidence_ref),),
            metadata={
                "operation": str(operation),
                "capability_id": capability_id,
                "route_signature": signature,
                "outcome": outcome,
                "failure_count": state.failure_count,
                "cooldown": state.cooldown,
            },
        )
        runtime.extensions.setdefault("route_outcome_vectors", []).append(asdict(vector))
        runtime.extensions["goal_route_states"] = [asdict(x) for x in self.goal_route_states.active_for_task(task_id)]
        return {"goal_route_state": state, "evaluation_vector": vector}

    def _persist(self, runtime):
        revision = self.store.save_runtime(
            runtime.raw.turn_id,
            encode_runtime(runtime),
            expected_revision=getattr(runtime, "_store_revision", None),
        )
        runtime._store_revision = revision

    def _restore(self, turn_id):
        if not self.store.turn_in_session(turn_id, self.session_id):
            raise KeyError(turn_id)
        payload, revision = self.store.load_runtime_record(turn_id)
        if payload is None:
            raise KeyError(turn_id)
        runtime = decode_runtime(payload, _Runtime)
        runtime._store_revision = revision
        self._runtimes[turn_id] = runtime
        return runtime

    def resume(self, turn_id):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        if runtime.extensions.get("phase") in {"finished", "partial"}:
            return self._view(runtime, runtime.extensions["phase"])
        if runtime.pending_work:
            return self._view(runtime, "work", runtime.pending_work)
        return self._advance(turn_id)

    def latest_resumable_turn_id(self):
        return self.store.latest_resumable_turn_for_session(self.session_id)

    def _reroute_unavailable_pending_after_rebind(self, runtime):
        """Reroute pending tool work whose capability vanished from the current HOST.

        A changed HOST surface is not an execution failure: no provider result was
        observed.  For mutating work, however, a crash may have happened after a
        side effect but before submit(), so that uncertainty remains explicit and
        reconstruction is instructed to reconcile before any replay.
        """
        available = set(runtime.capabilities)
        stale = []
        for work in tuple(runtime.pending_work):
            if work.executor != "host_tool" or not work.operation.startswith("capability."):
                continue
            capability_id = work.operation.removeprefix("capability.")
            if capability_id in available:
                continue
            node_id = runtime.work_to_node.get(work.work_id)
            if node_id is None:
                continue
            node = runtime.program.node(node_id)
            effect_status = (
                "unknown_if_prior_host_execution_occurred"
                if work.resume_policy == "reconcile_before_replay"
                else "not_observed_in_jigaewol"
            )
            event = {
                "work_id": work.work_id,
                "operation": work.operation,
                "capability_id": capability_id,
                "basis": "current_host_surface_no_longer_exposes_pending_capability",
                "prior_resume_policy": work.resume_policy,
                "idempotency_key": work.idempotency_key,
                "effect_status": effect_status,
                "route_scope": "local",
            }
            observation_ref = runtime.ledger.add_observation({"host_surface_change": deepcopy(event)})
            event["observation_ref"] = observation_ref
            runtime.extensions.setdefault("capability_rebind_unavailable", []).append(deepcopy(event))
            repair = self._node(runtime, "host_semantic", "runtime.reconstruct", intents=node.intent_refs, parameters={
                "instruction": (
                    "The previously pending HOST capability is not exposed in the current runtime. Preserve the live goal and "
                    "choose an executable alternate route from the current capability surface. This is a host-surface change, "
                    "not proof that the prior tool execution failed. If effect_status is unknown_if_prior_host_execution_occurred, "
                    "first seek reconciliation/verification and never blindly replay a potentially mutating effect."
                ),
                "unavailable_operation": work.operation,
                "unavailable_capability_id": capability_id,
                "host_surface_observation_ref": observation_ref,
                "prior_resume_policy": work.resume_policy,
                "idempotency_key": work.idempotency_key,
                "effect_status": effect_status,
            })
            self._replace_pending(runtime, (node.node_id,), [repair], count_rewrite=True, required=True)
            runtime.work_to_node.pop(work.work_id, None)
            runtime.pending_work = tuple(w for w in runtime.pending_work if w.work_id != work.work_id)
            stale.append(event)
        return tuple(stale)

    def rebind_capabilities(self, turn_id, capabilities):
        """Replace stale HOST exposure claims on a persisted nonterminal turn."""
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        if runtime.extensions.get("phase") in {"finished", "partial"}:
            return self._view(runtime, runtime.extensions["phase"])
        specs = capability_specs(capabilities)
        runtime.capabilities = tuple(c["id"] for c in specs)
        runtime.extensions["capability_specs"] = specs
        runtime.extensions.setdefault("capability_rebindings", []).append({
            "capability_ids": list(runtime.capabilities),
            "basis": "current_host_exposure_snapshot",
        })
        self._reroute_unavailable_pending_after_rebind(runtime)
        self._persist(runtime)
        return self._view(runtime, "work" if runtime.pending_work else runtime.extensions.get("phase", "work"), runtime.pending_work)

    def resume_latest(self):
        turn_id = self.latest_resumable_turn_id()
        return None if turn_id is None else self.resume(turn_id)

    def read_context(self, turn_id, section):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        if section == "attachments":
            return {"paths": list(runtime.raw.attachment_refs), "inventory": list(runtime.attachment_inventory),
                    "previews": list(runtime.attachment_context)}
        if section == "worlds":
            return [asdict(w) for w in runtime.worlds]
        if section == "ledger":
            return [asdict(e) for e in runtime.ledger._entries.values()]
        if section == "current_answer":
            return deepcopy(runtime.answer)
        if section == "confirmed_methods":
            return list(runtime.repertoire_context)
        if section == "continuation_candidate":
            return deepcopy(runtime.extensions.get("previous_turn") or runtime.extensions.get("_previous_turn_candidate"))
        return deepcopy(runtime.extensions.get(section))

    def explain_turn(self, turn_id):
        """Return an inspectable public causal graph of observable execution/provenance decisions."""
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        return public_trace_graph(runtime)

    def extend_budget(self, turn_id, *, additional_nodes=8, additional_recompiles=1):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        if (isinstance(additional_nodes, bool) or not isinstance(additional_nodes, int) or additional_nodes < 0 or
                isinstance(additional_recompiles, bool) or not isinstance(additional_recompiles, int) or additional_recompiles < 0):
            raise ValueError("budget increments must be nonnegative integers, not booleans")
        budget = runtime.program.budget_policy
        runtime.program = replace(runtime.program, budget_policy=replace(budget,
            max_nodes=budget.max_nodes + additional_nodes, max_recompiles=budget.max_recompiles + additional_recompiles))
        self._persist(runtime)
        return self.resume(turn_id)

    def ledger_entries(self, turn_id):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        return tuple(runtime.ledger._entries.values())

    def execution_trace(self, turn_id):
        """Return the single public execution graph for this turn.

        Older generations maintained a second hand-built trace schema here,
        which drifted from interpretability.trace_graph. JIGAEWOL keeps one source
        of truth to avoid contradictory status surfaces.
        """
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        graph = public_trace_graph(runtime)
        graph["rail"] = (
            "tool_backed_execution_observed" if runtime.extensions.get("tool_submissions") else
            "tool_capable_no_tool_result_yet" if runtime.extensions.get("capability_specs") else
            "portable_semantic"
        )
        graph["recompile_count"] = runtime.recompile_count
        graph["notices"] = list(runtime.extensions.get("notices", []))
        return graph

    def read_result(self, turn_id, ref):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        if runtime.pending_work:
            ref = runtime.pending_work[0].context.get("references", {}).get(ref, ref)
        return asdict(runtime.ledger.get(ref))

    def submit_current(self, turn_id, result):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        if len(runtime.pending_work) != 1:
            raise ValueError("submit_current requires exactly one pending work item")
        return self.submit(turn_id, runtime.pending_work[0].work_id, result)

    def submit_work(self, work, result):
        """Bind a response to the returned work object, without copying identifiers."""
        return self.submit(work.turn_id, work.work_id, result)

    def submit_batch(self, turn_id, submissions):
        """Submit prepared semantic results in order; tool work is a boundary.

        Earlier valid submissions remain committed if a later item fails. Read
        each operation's context before preparing its result. This helper never
        performs tools or accepts a tool receipt on a caller's behalf.
        """
        items = list(submissions)
        if any(not isinstance(item, (list, tuple)) or len(item) != 2 or
               not isinstance(item[0], str) for item in items):
            raise ValueError("batch items must be (expected_operation, result) pairs")
        view = self.resume(turn_id)
        for operation, result in items:
            if view.phase != "work" or len(view.next_work) != 1:
                raise ValueError("batch has no pending work for " + operation)
            work = view.next_work[0]
            if work.operation != operation:
                raise ValueError("batch expected " + operation + "; current work is " + work.operation)
            if work.executor != "host_semantic":
                raise ValueError("batch stops before tool work; perform the actual tool and use submit_work")
            view = self.submit_work(work, result)
        return view

    def delivery_receipt(self, turn_id, answer):
        """Bind exact text to a finished local turn, without attesting its truth."""
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        stored = self.store.persisted_turn_by_id(turn_id, self.session_id) if hasattr(self.store, "persisted_turn_by_id") else None
        request_hash = hashlib.sha256(runtime.raw.message.encode("utf-8")).hexdigest()
        if stored is not None and (stored[1] != runtime.raw.message or stored[2] != request_hash):
            raise ValueError("stored original request does not match the runtime")
        if not isinstance(answer, str) or not isinstance(runtime.answer, str) or answer != runtime.answer:
            raise ValueError("receipt answer must exactly equal the final delivered text")
        if runtime.extensions.get("phase") != "finished" or runtime.pending_work:
            raise ValueError("delivery receipt requires a finished turn with no pending work")
        closure = compute_closure(runtime.lattice, runtime.ledger)
        if (not runtime.extensions.get("intake_confirmed") or runtime.extensions.get("unresolved") or
                any(item.status != "resolved" for item in closure.values()) or self._feedback_closure(runtime)):
            raise ValueError("delivery receipt requires closed requirement links and declared hard probes")
        if not any(n.operation == "closure.check" and n.status == "done" for n in runtime.program.nodes):
            raise ValueError("delivery receipt requires a completed closure.check operation")
        answer_ref = runtime.extensions.get("answer_ref")
        if (not answer_ref or runtime.ledger.get(answer_ref).kind != "material" or
                runtime.ledger.get(answer_ref).content != answer):
            raise ValueError("delivery receipt requires the current answer's recorded material")
        def quotes_current_answer(ref):
            entry = runtime.ledger.get(ref)
            if entry.kind != "evidence" or entry.subject_ref != answer_ref:
                return False
            return any(isinstance(span, (tuple, list)) and len(span) == 3 and
                span[0] == answer_ref and isinstance(span[1], int) and not isinstance(span[1], bool) and
                isinstance(span[2], int) and not isinstance(span[2], bool) and
                0 <= span[1] < span[2] <= len(answer) and answer[span[1]:span[2]] == entry.content
                for span in entry.exact_spans_or_diffs)
        for item in closure.values():
            current = any(quotes_current_answer(ref)
                for effect_ref in item.effect_refs
                for ref in runtime.ledger.get(effect_ref).exact_spans_or_diffs)
            if not current:
                raise ValueError("delivery receipt requires each requirement to quote the current answer")
        return {
            "turn_id": turn_id, "closure": "finished", "request_sha256": request_hash,
            "answer_sha256": hashlib.sha256(answer.encode("utf-8")).hexdigest(),
            "requirements_linked": len(closure),
            "host_results_submitted": len(runtime.extensions.get("receipts", {})),
            "tool_results_submitted": len(runtime.extensions.get("tool_submissions", [])),
            "scope": "local_runtime_request_answer_binding_and_requirement_linkage",
            "coverage_scope": "literal_links_to_current_answer_not_semantic_satisfaction",
            "tool_scope": "host_submitted_results_not_independent_execution_attestation",
        }

    def read_work_result(self, work, ref):
        references = work.context.get("references", {})
        resolved = references.get(ref, ref)
        if getattr(work, "visibility_scope", None) is not None:
            allowed = set(references.values())
            if resolved not in allowed:
                raise PermissionError("scoped work cannot retrieve a result outside its filtered references")
        runtime = self._runtimes.get(work.turn_id) or self._restore(work.turn_id)
        return asdict(runtime.ledger.get(resolved))

    def _accept_intake(self, runtime, payload):
        proposals = extract_requirements(runtime.raw.message, payload)
        runtime.lattice = build_intent_lattice(runtime.raw, proposals)
        semantic_follows = payload.get("continuation", runtime.extensions.get("continuation", False))
        previous = runtime.extensions.get("previous_turn") or runtime.extensions.get("_previous_turn_candidate")
        source_evidence = source_continuation_evidence(runtime.raw.message)
        source_follows = bool(previous) and bool(source_evidence)
        # Semantic intake may describe continuity, but it has no authority to activate
        # or detach prior work.  Activation is exact-source bound.
        follows = bool(source_follows and not runtime.extensions.get("new_task_explicit"))
        if previous and bool(semantic_follows) and not follows:
            runtime.extensions["rejected_semantic_task_attach"] = {
                "reason": "semantic_intake_cannot_activate_prior_work_without_exact_user_source",
                "semantic_continuation": True,
                "source_continuation_evidence": list(source_evidence),
                "previous_turn_id": previous.get("turn_id"),
            }
        if previous and not bool(semantic_follows) and follows:
            runtime.extensions["rejected_semantic_task_detach"] = {
                "reason": "exact_user_source_continuation_outranks_semantic_detach",
                "semantic_continuation": False,
                "source_continuation_evidence": list(source_evidence),
                "previous_turn_id": previous.get("turn_id"),
            }
        current_task_requirements = ([] if follows and _bare_continuation(runtime.raw.message)
            else _current_task_requirements(runtime.lattice, runtime.raw))
        task_requirements = _merge_task_requirements(
            runtime.extensions.get("_previous_task_requirements", []) if follows else [],
            current_task_requirements)
        event_kind = str((runtime.extensions.get("turn_event") or {}).get("kind", "NEW_GOAL"))
        supersede_map = {}
        proposed_supersede_map = {}
        active_ids = {x.goal_id for x in self.goal_lifecycle.active(runtime.raw.task_id or "")}
        for item in payload.get("requirements", []) if isinstance(payload, dict) else ():
            if not isinstance(item, dict):
                continue
            meaning = str(item.get("meaning", "")).strip()
            raw_ids = item.get("supersedes_goal_ids", [])
            if meaning and isinstance(raw_ids, list):
                ids = [str(x) for x in raw_ids if str(x) == "*" or str(x) in active_ids]
                if ids:
                    proposed_supersede_map[meaning] = ids
        # A semantic model can suggest which goals a correction targets, but it
        # cannot grant itself authority to delete/replace them. Destructive
        # supersession activates only when the exact user source says so.
        if explicit_replacement_requested(runtime.raw.message):
            supersede_map = proposed_supersede_map
        elif proposed_supersede_map:
            runtime.extensions["rejected_semantic_supersession"] = {
                "reason": "exact_user_source_did_not_authorize_replacement",
                "proposed": deepcopy(proposed_supersede_map),
            }
        lifecycle_event_kind = "CORRECTION" if supersede_map else event_kind
        self.goal_lifecycle.sync_turn(
            task_id=runtime.raw.task_id or "", source_turn_id=runtime.raw.turn_id,
            requirements=current_task_requirements, event_kind=lifecycle_event_kind,
            bare_continuation=bool(follows and _bare_continuation(runtime.raw.message)),
            supersede_map=supersede_map, exact_user_text=runtime.raw.message)
        lifecycle_requirements = self.goal_lifecycle.as_requirements(runtime.raw.task_id or "")
        # Lifecycle is authoritative for supersede/withdraw semantics. Never
        # reintroduce superseded historical requirements from the provisional
        # continuation merge; only retain source-grounded requirements from
        # this turn alongside active lifecycle goals.
        task_requirements = _merge_task_requirements(lifecycle_requirements, current_task_requirements)
        signals = _signals(runtime.raw.message, len(runtime.lattice.nodes), runtime.raw.attachment_refs,
                           runtime.capabilities, bool(follows and previous))
        mode = runtime.extensions.get("mode", "auto")
        if mode == "direct":
            signals = CompileSignals.simple_chat()
        if follows and previous and mode != "direct":
            gravity = runtime.extensions.get("task_signal_gravity", {})
            inherited_previous = deepcopy(previous)
            inherited_previous["signals"] = {**gravity, **{k: v for k, v in previous.get("signals", {}).items() if k not in gravity}}
            signals = _continuation_signals(signals, inherited_previous, task_requirements)
        else:
            signals = replace(signals, intent_count=len(runtime.lattice.nodes))
        task_model = deepcopy(payload.get("task_model", {})) if isinstance(payload, dict) else {}
        # An explicit direct turn is a hard latency preference. Semantic intake
        # may describe the task, but it must not silently re-escalate the turn.
        if mode != "direct":
            signals = apply_task_model(signals, task_model)
        specs = tuple(SimpleNamespace(capability_id=c["id"], permission_class=c["permission"], role=c.get("role"),
                      cost_latency_hint=c["cost"], feedback_kind=c.get("feedback_kind", "tool_observation"),
                      evaluator_id=c.get("evaluator_id")) for c in runtime.extensions["capability_specs"])
        runtime.program = compile_turn(
            runtime.lattice, signals, specs, profile=runtime.extensions.get("profile", "apex"),
            external_kernel_request=self.external_kernel.fetch_parameters(),
            required_traits=(
                tuple(str(x) for x in (runtime.extensions.get("semantic_authority") or {}).get("required_capability_traits", ()) if str(x))
                if source_effect_authorized(runtime.extensions.get("semantic_authority") or {})
                else ()
            ),
        )
        component_credit = self.credit_store.snapshot(limit=None)
        budget_nodes=max(1,int(runtime.program.budget_policy.max_nodes))
        adaptation_seed = self.adaptation.recall(
            runtime.raw.message + " " + " ".join(str(x.get("meaning", "")) for x in task_requirements), limit=None)
        gravity_intents = () if (event_kind == "CANCEL" or (follows and _bare_continuation(runtime.raw.message))) else runtime.lattice.nodes
        refreshed_goal = build_goal_gravity(task_requirements, gravity_intents, runtime.raw.turn_id)
        prior_contract = (previous.get("goal_contract") if follows and isinstance(previous, dict) else None)
        refreshed_contract = compile_goal_contract(
            runtime.raw.message, task_requirements, task_model, source_hash=runtime.raw.source_hash, prior=prior_contract
        )
        runtime.extensions.update(intake_confirmed=True, compile_signals=asdict(signals), continuation=follows,
            continuation_determined=True, task_requirements=task_requirements,
            routing_trait_hints=list((runtime.extensions.get("semantic_authority") or {}).get("required_capability_traits", ()) or ()),
            source_effect_authorized=source_effect_authorized(runtime.extensions.get("semantic_authority") or {}),
            goal_gravity=refreshed_goal, goal_contract=refreshed_contract, task_model=task_model, component_credit=component_credit,
            execution_fabric=build_execution_fabric(task_id=runtime.raw.task_id or "", max_nodes=runtime.program.budget_policy.max_nodes,
                depth_class=runtime.program.budget_policy.depth_class, profile=runtime.extensions.get("profile", "apex"),
                needs_research=bool(signals.needs_research)),
            goal_lifecycle=[asdict(x) for x in self.goal_lifecycle.active(runtime.raw.task_id or "")],
            adaptation_seed=adaptation_seed, integration_catalog=self.integrations.catalog(limit=None),
            previous_turn=previous if follows else None)
        runtime.extensions.pop("_previous_turn_candidate", None)
        runtime.extensions.pop("_previous_task_requirements", None)
        from jigaewol_runtime.contract.extraction import source_role_hints
        runtime.ledger.add_observation({
            "requirements": deepcopy(payload.get("requirements", [])),
            "context": deepcopy(payload.get("context", [])),
            "structural_context_hints": deepcopy(source_role_hints(runtime.raw.message)),
            "intake_policy": "semantic_enrichment_over_raw_source_with_conservative_context_hints",
        })

    def _record_attempt(self, runtime):
        if runtime.extensions.get("trajectory_ref") or runtime.program.budget_policy.depth_class == "tiny":
            return
        strategy = {"operations": [n.operation for n in runtime.program.nodes],
                    "mechanisms": [w.mechanism_family for w in runtime.worlds if w.status == "active"],
                    "selected": runtime.extensions.get("selected", {}).get("mechanism") if runtime.extensions.get("selected") else None}
        runtime.extensions["trajectory_credit"] = trajectory_credit(runtime)
        self.credit_store.update(runtime.extensions["trajectory_credit"], helpful=None)
        strategy["semantic_epochs"] = [{"kind": x.get("kind"), "frame_changed": x.get("frame_changed", False)}
                                      for x in runtime.extensions.get("semantic_epochs", []) if isinstance(x, dict)]
        runtime.extensions["trajectory_ref"] = self.repertoire.record_outcome(runtime.raw.message, strategy)
        self._record_adaptation_profile(runtime)

    def feedback(self, turn_id, *, helpful, feedback_turn_id, user_quote):
        if not isinstance(helpful, bool):
            raise ValueError("helpful must be boolean")
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        feedback_runtime = self._runtimes.get(feedback_turn_id) or self._restore(feedback_turn_id)
        if not isinstance(user_quote, str) or not user_quote or user_quote not in feedback_runtime.raw.message:
            raise ValueError("feedback must quote the user's actual feedback turn")
        ref = runtime.extensions.get("trajectory_ref")
        if not ref:
            raise ValueError("this turn has no completed trajectory to assess")
        result = self.repertoire.feedback(ref, helpful, user_quote, feedback_turn_id)
        profile_id = runtime.extensions.get("profile_id")
        if profile_id:
            result["adaptation_feedback"] = self.adaptation.feedback(profile_id, helpful)
        if runtime.extensions.get("trajectory_credit"):
            result["component_credit"] = self.credit_store.update(runtime.extensions["trajectory_credit"], helpful=helpful)
        runtime.learned = bool(helpful)
        self._persist(runtime)
        return result

    def _node(self, runtime, executor, operation, *, intents=None, parameters=None, permission="none", cost=.1, operator_ids=(), language_refs=(), trigger_refs=(), action_species_ids=(), visibility_scope=None):
        return ProgramNode(new_id("node"), executor, operation,
            intent_refs=tuple(intents) if intents is not None else runtime.program.objective_refs,
            world_refs=tuple(w.world_id for w in runtime.worlds if w.status == "active"),
            parameters=tuple((parameters or {}).items()), permission_class=permission, cost_estimate=cost,
            operator_ids=tuple(operator_ids or ()), language_refs=tuple(language_refs or ()),
            trigger_refs=tuple(trigger_refs or ()), action_species_ids=tuple(action_species_ids or ()), visibility_scope=visibility_scope)

    def _cap_node(self, runtime, cap, parameters=None, intents=None, operator_ids=(), language_refs=(), trigger_refs=(), action_species_ids=(), visibility_scope=None):
        specs = runtime.extensions.get("capability_specs", [])
        spec = next((c for c in specs if c["id"] == cap), None)
        if spec is None:
            raise ValueError("requested capability is not connected: " + str(cap))
        parameters = dict(parameters or {})
        internal_boundary = any(parameters.get(k) for k in ("method_job", "integration_job", "feedback_job", "jigaewol_external_kernel"))
        if "observation_policy" not in parameters and not internal_boundary:
            parameters["observation_policy"] = "delta"
        validate_parameters(spec, provider_arguments(spec, parameters))
        return self._node(runtime, "host_tool", "capability." + cap, parameters=parameters,
                          intents=intents, permission=spec["permission"], cost=spec["cost"], operator_ids=operator_ids,
                          language_refs=language_refs, trigger_refs=trigger_refs, action_species_ids=action_species_ids, visibility_scope=visibility_scope)

    def _action_node(self, runtime, action):
        cap = action.get("capability_id", action.get("operation", ""))
        cap = str(cap).removeprefix("capability.")
        parameters = action.get("parameters", action.get("args", {}))
        if not isinstance(parameters, dict):
            raise ValueError("action parameters must be an object")
        return self._cap_node(runtime, cap, parameters)

    def _step_node(self, runtime, step, intents):
        op = str(step.get("operation", ""))
        params = dict(step.get("parameters", {}))
        operator_ids = tuple(step.get("operator_ids", ()) or ())
        language_refs = tuple(step.get("language_refs", ()) or ())
        trigger_refs = tuple(step.get("trigger_refs", ()) or ())
        action_species_ids = tuple(step.get("action_species_ids", ()) or ())
        visibility_scope = step.get("visibility_scope")
        integration_node = self._integration_step_node(runtime, step, intents) if op.startswith("integration.") else None
        if integration_node is not None:
            return integration_node
        if op.startswith("capability."):
            return self._cap_node(runtime, op.removeprefix("capability."), params, intents, operator_ids=operator_ids, language_refs=language_refs, trigger_refs=trigger_refs, action_species_ids=action_species_ids, visibility_scope=visibility_scope)
        if op in SEMANTIC or op.startswith("semantic."):
            if op.startswith("semantic.") and not str(params.get("instruction", "")).strip():
                raise ValueError("custom semantic steps need an instruction")
            return self._node(runtime, "host_semantic", op, intents=intents, parameters=params, operator_ids=operator_ids, language_refs=language_refs, trigger_refs=trigger_refs, action_species_ids=action_species_ids, visibility_scope=visibility_scope)
        if op in {"trajectories.select", "operator.apply", "feedback.run",
                  "judgment.transduce", "judgment.decide", "judgment.residual.apply", "judgment.recall"}:
            return self._node(runtime, "local", op, intents=intents, parameters=params, operator_ids=operator_ids, language_refs=language_refs, trigger_refs=trigger_refs, action_species_ids=action_species_ids, visibility_scope=visibility_scope)
        raise ValueError("unknown execution operation: " + op)

    def _closure_has_marginal_work(self, runtime, unresolved):
        """Continue only while the live semantic decision surface is changing.

        This is a convergence witness, not a fixed iteration limit. Raw goals and
        cognition remain intact; the witness only prevents repeatedly compiling
        the same unresolved/opportunity state without new evidence or decisions.
        """
        search = runtime.extensions.get("search_strategy", {}) or {}
        search_nodes = search.get("nodes", {}) if isinstance(search, dict) else {}
        search_state = []
        if isinstance(search_nodes, dict):
            for key, row in sorted(search_nodes.items()):
                if isinstance(row, dict):
                    search_state.append((
                        str(key), str(row.get("status", "")),
                        str(row.get("result_sha256", "")), str(row.get("source_ref", "")),
                    ))
        tool_state = [
            (str(x.get("operation", "")), str(x.get("result_sha256", "")), str(x.get("source_ref", "")))
            for x in runtime.extensions.get("tool_submissions", ()) if isinstance(x, dict)
        ]
        semantic = {
            "unresolved": sorted(str(x) for x in (unresolved or ())),
            "opportunity": str(runtime.extensions.get("opportunity", "") or ""),
            "decision_state": deepcopy(runtime.extensions.get("decision_state", {})),
            "route_candidates": deepcopy(runtime.extensions.get("route_candidates", [])),
            "search_state": search_state,
            "tool_state": tool_state,
            "quality_assessment": deepcopy(runtime.extensions.get("quality_assessment")),
        }
        signature = hashlib.sha256(_json(semantic).encode("utf-8")).hexdigest()
        previous = runtime.extensions.get("_last_closure_rewrite_signature")
        if previous == signature:
            runtime.extensions["convergence_witness"] = {
                "signature": signature,
                "basis": "unchanged_semantic_decision_surface",
                "fixed_iteration_cap_used": False,
            }
            return False
        runtime.extensions["_last_closure_rewrite_signature"] = signature
        runtime.extensions.pop("convergence_witness", None)
        return True

    def _extend_soft_budget(self, runtime, *, min_recompiles=None, min_nodes=None, reason="live_semantic_work"):
        """Grow compiler headroom without treating an initial heuristic window as a goal ceiling."""
        budget = runtime.program.budget_policy
        target_recompiles = budget.max_recompiles
        target_nodes = budget.max_nodes
        if min_recompiles is not None:
            target_recompiles = max(target_recompiles, int(min_recompiles))
        if min_nodes is not None:
            target_nodes = max(target_nodes, int(min_nodes))
        if target_recompiles == budget.max_recompiles and target_nodes == budget.max_nodes:
            return False
        runtime.program = replace(runtime.program, budget_policy=replace(
            budget, max_recompiles=target_recompiles, max_nodes=target_nodes))
        runtime.extensions.setdefault("soft_budget_extensions", []).append({
            "reason": str(reason),
            "max_recompiles": target_recompiles,
            "max_nodes": target_nodes,
            "basis": "initial_headroom_extended_for_live_goal_not_capability_privilege",
        })
        return True

    def _can_rewrite(self, runtime):
        if runtime.recompile_count >= runtime.program.budget_policy.max_recompiles:
            self._extend_soft_budget(
                runtime, min_recompiles=runtime.recompile_count + 1, reason="rewrite_opportunity")
        return True

    def _replace_pending(self, runtime, ids, nodes, count_rewrite=True, required=False):
        if count_rewrite:
            self._can_rewrite(runtime)
        selected = {n.node_id for n in runtime.program.nodes if n.node_id in ids or n.operation in ids}
        needed = len(runtime.program.nodes) - len(selected) + len(nodes)
        if needed > runtime.program.budget_policy.max_nodes:
            self._extend_soft_budget(runtime, min_nodes=needed + 4, reason="program_rewrite")
        protected = tuple(e.entry_id for e in runtime.ledger._entries.values() if e.kind == "effect" and e.verification_status == "observed")
        runtime.program = rewrite_subgraph(runtime.program, ids, tuple(nodes), protected)
        if count_rewrite:
            runtime.recompile_count += 1
        return True

    def _replace_pending_parallel(self, runtime, ids, prefix_nodes, parallel_nodes, join_node, suffix_nodes, count_rewrite=True, required=False):
        """Install a real fan-out/join phase; compiler windows are soft headroom only."""
        if count_rewrite:
            self._can_rewrite(runtime)
        selected={n.node_id for n in runtime.program.nodes if n.node_id in ids or n.operation in ids}
        needed=len(runtime.program.nodes)-len(selected)+len(prefix_nodes)+len(parallel_nodes)+1+len(suffix_nodes)
        if needed>runtime.program.budget_policy.max_nodes:
            self._extend_soft_budget(runtime, min_nodes=needed+4, reason="parallel_program_rewrite")
        protected=tuple(e.entry_id for e in runtime.ledger._entries.values() if e.kind=="effect" and e.verification_status=="observed")
        runtime.program=rewrite_subgraph_parallel_phase(runtime.program,ids,tuple(prefix_nodes),tuple(parallel_nodes),join_node,tuple(suffix_nodes),protected)
        if count_rewrite: runtime.recompile_count+=1
        runtime.extensions.setdefault("parallel_phase_history",[]).append({"fanout":[n.node_id for n in parallel_nodes],"join":join_node.node_id})
        return True

    def _view(self, runtime, phase, work=(), unresolved=None):
        runtime.extensions["phase"] = phase
        if unresolved is not None:
            runtime.extensions["unresolved"] = list(unresolved)
        return JigaewolView(runtime.raw.turn_id, runtime.raw.task_id or "", runtime.program.program_id, phase,
            tuple(work), runtime.answer, tuple(runtime.extensions.get("unresolved", ())),
            tuple(runtime.ledger._entries), runtime.attachment_inventory, runtime.attachment_context,
            runtime.pending_work, runtime.worlds, runtime.recompile_count, runtime.capabilities,
            runtime.repertoire_context, runtime.learned, tuple(runtime.extensions.get("notices", ())), runtime.extensions.get("selected"))

    def _finish_view(self, runtime, phase, work=(), unresolved=None):
        view = self._view(runtime, phase, work, unresolved)
        if phase in {"finished", "partial"} and not runtime.extensions.get("durable_terminal_recorded"):
            kind = "RUN_FINISHED" if phase == "finished" else "RUN_FAILED"
            try:
                self.durable_runs.append(runtime.raw.turn_id, runtime.raw.task_id or "", kind, {"phase": phase, "unresolved": list(view.unresolved_intents)})
                runtime.extensions["durable_terminal_recorded"] = True
            except Exception as exc:
                runtime.extensions.setdefault("notices", []).append("durable terminal journal unavailable: " + str(exc))
        self._persist(runtime)
        return view

    def _context(self, runtime, node):
        if node.operation == "feedback.review":
            feedback = self._plane(runtime).public_packet()
            if len(_json(feedback)) > runtime.program.budget_policy.target_context_chars:
                matrix = feedback["matrix"]
                feedback = {"decision": feedback["decision"], "matrix": {
                    "probes": [{k: p[k] for k in ("id", "question", "hard")} for p in matrix["probes"]],
                    "rows": [{"blind": row["blind"], "cells": {pid: {k: c.get(k) for k in
                        ("state", "passed", "value", "usable", "probe_health")} for pid, c in row["cells"].items()}}
                        for row in matrix["rows"]]},
                    "candidates": [{"blind": c["blind"], "material_hash": c["material_hash"]} for c in feedback["candidates"]],
                    "context_transformations": [{"section": "feedback", "representation": "compact_first_class"}],
                    "omitted": ["material", "probes", "full_matrix"]}
            return {"version": 2, "authority": authority_plane_snapshot(), "request": runtime.raw.message, "instruction": GUIDANCE["feedback.review"],
                    "task_requirements": deepcopy(runtime.extensions.get("task_requirements", [])),
                    "task_context_rule": TASK_CONTEXT_RULE,
                    "feedback": feedback,
                    "requirements": [{"id": n.intent_id, "meaning": n.meaning} for n in runtime.lattice.nodes],
                    "references": {}}
        if dict(node.parameters).get("method_job") or dict(node.parameters).get("integration_job"):
            return {"version": 2, "authority": authority_plane_snapshot(), "instruction": GUIDANCE["methods.execute"],
                    "task_requirements": deepcopy(runtime.extensions.get("task_requirements", [])),
                    "task_context_rule": TASK_CONTEXT_RULE,
                    "goal_gravity": deepcopy(runtime.extensions.get("goal_gravity", {})),
                    "parameters": dict(node.parameters), "references": {},
                    "request_constraints": runtime.raw.message}
        if dict(node.parameters).get("feedback_job"):
            return {"version": 2, "authority": authority_plane_snapshot(), "instruction": GUIDANCE["feedback.tool"],
                    "task_requirements": deepcopy(runtime.extensions.get("task_requirements", [])),
                    "task_context_rule": TASK_CONTEXT_RULE,
                    "parameters": dict(node.parameters), "references": {},
                    "request_constraints": runtime.raw.message}
        if node.operation == "worlds.realize":
            params = dict(node.parameters)
            branch = deepcopy(params.get("cognition_generation_branch", {}))
            return {
                "version": 3,
                "authority": authority_plane_snapshot(),
                "request": runtime.raw.message,
                "instruction": GUIDANCE["worlds.realize"],
                "task_requirements": deepcopy(runtime.extensions.get("task_requirements", [])),
                "task_context_rule": TASK_CONTEXT_RULE,
                "goal_gravity": deepcopy(runtime.extensions.get("goal_gravity", {})),
                "cognition_generation_branch": branch,
                "references": {},
                "isolation": {
                    "sibling_outputs_visible": False,
                    "reason": "divergent branch realization must not converge by copying sibling semantic outputs",
                },
            }
        packet = make_packet(runtime, node, GUIDANCE.get(node.operation,
            "Execute parameters.instruction and return the actual result."))
        params = dict(node.parameters)
        batch_ops = params.get("batch_operations", []) if isinstance(params, dict) else []
        if node.operation == "cognition.delta" and isinstance(batch_ops, list) and batch_ops and set(batch_ops) == {"worlds.realize"}:
            group = str(params.get("observation_group", ""))
            by_group = runtime.extensions.get("world_branch_results", {}).get(group, {})
            rows = [deepcopy(by_group[k]) for k in sorted(by_group)] if isinstance(by_group, dict) else []
            packet.setdefault("sections", {})["cognition_generation_recombination"] = {
                "branch_results": rows,
                "candidate_synthesis": recombine_branch_results(rows),
                "instruction": "Synthesize without averaging away branch-specific mechanisms or unresolved tensions.",
            }
        meta = dict(runtime.program.metadata)
        kernel_packet = compiled_kernel_packet(
            runtime.extensions.get("external_kernel"),
            domain=str(meta.get("domain", "general")),
            depth_class=str(meta.get("mode", "standard")),
        )
        if node.operation == "cognition.compile":
            packet.setdefault("sections", {})["kernel_policy"] = kernel_packet
        if getattr(node, "operator_ids", ()):
            active = {str(x.get("id")): x for x in (kernel_packet or {}).get("active_operators", [])
                      if isinstance(x, dict) and x.get("id")}
            contracts = []
            for oid in node.operator_ids:
                if oid not in active:
                    continue
                contract = deepcopy(active[oid])
                contract["contract_sha256"] = hashlib.sha256(_json(active[oid]).encode("utf-8")).hexdigest()
                contracts.append(contract)
            packet["operator_contracts"] = contracts
            packet["operator_binding_scope"] = "operator contract injected into actual work context; semantic compliance is not runtime-attested"
        scope = getattr(node, "visibility_scope", None)
        if scope is not None:
            partition = partition_for(runtime.extensions.get("generative_world", {}), scope)
            packet = apply_visibility_partition(packet, partition)
        return packet

    def _advance(self, turn_id):
        runtime = self._runtimes[turn_id]
        if runtime.pending_work:
            return self._finish_view(runtime, "work", runtime.pending_work)
        while True:
            ready = Scheduler.ready(runtime.program, runtime.ledger)
            local = [n for n in ready if n.executor == "local"]
            if local:
                for node in local:
                    if node.operation == "closure.check":
                        closure = compute_closure(runtime.lattice, runtime.ledger)
                        unresolved = {i for i, c in closure.items() if c.status != "resolved"}
                        unresolved.update(runtime.extensions.get("unresolved", ()))
                        unresolved.update(self._feedback_closure(runtime))
                        if not runtime.extensions.get("intake_confirmed", False):
                            unresolved.update(runtime.program.objective_refs)
                        opportunity = runtime.extensions.get("opportunity")
                        if (unresolved or opportunity) and self._can_rewrite(runtime) and self._closure_has_marginal_work(runtime, unresolved):
                            refs = tuple(unresolved) or runtime.program.objective_refs
                            op = dict(runtime.program.metadata).get("realize_operation", "material.realize")
                            steps = [self._node(runtime, "host_semantic", "cognition.compile", intents=refs),
                                     self._node(runtime, "host_semantic", op, intents=runtime.program.objective_refs),
                                     self._node(runtime, "local", "closure.check")]
                            if self._replace_pending(runtime, (node.node_id,), steps):
                                continue
                        runtime.program = Scheduler.apply_result(runtime.program, node.node_id, "closure:recorded")
                        runtime.pending_work = ()
                        if runtime.answer is None:
                            unresolved.update(runtime.program.objective_refs)
                        if not unresolved:
                            self._record_attempt(runtime)
                        return self._finish_view(runtime, "partial" if unresolved else "finished", unresolved=tuple(unresolved))
                    if node.operation == "trajectories.select":
                        result = self._select_trajectory(runtime, node)
                    elif node.operation == "feedback.run":
                        result = self._feedback_run(runtime, node)
                    elif node.operation == "operator.apply":
                        params = dict(node.parameters)
                        spec = OperatorSpec(**runtime.extensions["operators"][params["operator_id"]])
                        executed = apply_generated_operator(spec, params["structure"])
                        runtime.extensions["last_operator_result"] = deepcopy(executed)
                        result = runtime.ledger.add_observation(executed)
                    elif node.operation == "judgment.transduce":
                        params=dict(node.parameters); lens_id=str(params.get("lens_id", "")); source=params.get("source")
                        if not lens_id or not isinstance(source,dict): raise ValueError("judgment.transduce needs lens_id and source object")
                        mech=self.representation_transducer.compile(lens_id, source)
                        result=runtime.ledger.add_observation({"judgment_transduction":asdict(mech)})
                    elif node.operation == "judgment.decide":
                        params=dict(node.parameters); pid=str(params.get("program_id", "")); features=params.get("features")
                        if not pid or not isinstance(features,dict): raise ValueError("judgment.decide needs program_id and features object")
                        decision=self.decision_programs.decide(pid,features)
                        result=runtime.ledger.add_observation({"judgment_decision":decision})
                    elif node.operation == "judgment.residual.apply":
                        params=dict(node.parameters); cid=str(params.get("capsule_id", "")); state=params.get("state")
                        if cid not in self.residuals.items or not isinstance(state,dict): raise ValueError("judgment.residual.apply needs known capsule_id and state object")
                        applied=self.residual_compiler.apply(self.residuals.items[cid],state)
                        result=runtime.ledger.add_observation({"residual_applied":cid,"state":applied})
                    elif node.operation == "judgment.recall":
                        params=dict(node.parameters); q=params.get("query")
                        if not isinstance(q,dict): raise ValueError("judgment.recall needs causal query object")
                        limit=params.get("limit", 5)
                        if type(limit) is not int or limit < 1:
                            raise ValueError("judgment.recall limit must be a positive integer")
                        rows=self.recall_causal_mechanisms(q,limit=limit)
                        result=runtime.ledger.add_observation({"causal_recall":[{"score":score,"mechanism":asdict(mech)} for score,mech in rows]})
                    else:
                        raise ValueError("local operation has no executable handler: " + node.operation)
                    runtime.program = Scheduler.apply_result(runtime.program, node.node_id, result)
                continue
            host = [n for n in ready if n.executor != "local"]
            if host:
                first=host[0]
                params=dict(first.parameters)
                group=str(params.get("_jigaewol_parallel_group","")).strip() if params.get("_jigaewol_parallel_safe") is True else ""
                selected=[first]
                if group:
                    selected=[n for n in host if dict(n.parameters).get("_jigaewol_parallel_safe") is True and str(dict(n.parameters).get("_jigaewol_parallel_group",""))==group]
                works=[]
                for node in selected:
                    work=to_host_work(node,turn_id,runtime.raw.task_id or "")
                    context=self._context(runtime,node)
                    if getattr(node,"visibility_scope",None) is not None:
                        allowed=set(context.get("references",{}).values())
                        input_refs=tuple(ref for ref in runtime.ledger._entries if ref in allowed)
                    else:
                        input_refs=tuple(runtime.ledger._entries)
                    work=replace(work,context=context,context_slices=(),input_refs=input_refs)
                    runtime.work_to_node[work.work_id]=node.node_id
                    works.append(work)
                runtime.pending_work=tuple(works)
                if len(works)>1:
                    runtime.extensions.setdefault("parallel_batches",[]).append({"group":group,"work_ids":[w.work_id for w in works],"operations":[w.operation for w in works]})
                return self._finish_view(runtime,"work",runtime.pending_work)
            unresolved = tuple(i for i, c in compute_closure(runtime.lattice, runtime.ledger).items() if c.status != "resolved")
            if not unresolved and runtime.answer is not None:
                self._record_attempt(runtime)
                return self._finish_view(runtime, "finished", unresolved=())
            runtime.extensions["notices"].append("no executable next step; deliver partial result or supply a revised task")
            return self._finish_view(runtime, "partial", unresolved=unresolved or runtime.program.objective_refs)

    def fail_work(self, turn_id, work_id, error):
        """Convert a host/tool execution failure into repair work without a user nudge.

        The failed operation is not forged into a success receipt. Instead its
        exact failure becomes an observed control event and the pending node is
        replaced by runtime.reconstruct, which must choose an alternate executable
        route or explicitly preserve an unresolved variable.
        """
        runtime=self._runtimes.get(turn_id) or self._restore(turn_id)
        if work_id not in runtime.work_to_node: raise KeyError(work_id)
        node=runtime.program.node(runtime.work_to_node[work_id])
        failure={
            "work_id":work_id,"operation":node.operation,"executor":node.executor,
            "error_type":type(error).__name__,"error":str(error),
        }
        failed_route = failed_route_record(
            node.operation, dict(node.parameters), error_type=failure["error_type"],
            error=failure["error"], work_id=work_id,
        )
        failure["route_signature"] = failed_route["signature"]
        failure_ref=runtime.ledger.add_observation({"execution_failure":failure})
        boundary_translation=translate_failure(
            operation=node.operation,error_type=failure["error_type"],error_text=failure["error"],
            goal_anchor_ids=(runtime.extensions.get("goal_gravity") or {}).get("anchor_ids",[]),
            capabilities=runtime.capabilities)
        runtime.extensions.setdefault("boundary_translations",[]).append(deepcopy(boundary_translation))
        runtime.extensions.setdefault("execution_failures",[]).append({**failure,"failure_ref":failure_ref})
        runtime.extensions.setdefault("failed_routes",[]).append({
            **failed_route, "failure_ref": failure_ref, "observed_turn_id": runtime.raw.turn_id,
            "routing_context_source": "current_turn_failure",
        })
        try:
            self._record_route_outcome(
                runtime, operation=node.operation, parameters=dict(node.parameters),
                outcome="failure", evidence_ref=failure_ref,
            )
        except Exception as route_state_exc:
            runtime.extensions.setdefault("nonblocking_notices", []).append({
                "kind": "route_failure_state_recording_failed",
                "error_type": type(route_state_exc).__name__,
                "message": str(route_state_exc)[:300],
            })
        runtime.extensions["failed_route_signatures"] = sorted({
            str(x.get("signature")) for x in runtime.extensions.get("failed_routes", [])
            if isinstance(x, dict) and x.get("signature")
        })
        runtime.extensions["latest_execution_failure"]={**failure,"failure_ref":failure_ref}
        runtime.work_to_node.pop(work_id,None); runtime.pending_work=()
        repair=self._node(runtime,"host_semantic","runtime.reconstruct",intents=node.intent_refs,parameters={
            "instruction":(
                "The previous executable route failed. Preserve the live goal and build an orthogonal route now. "
                "Prefer another connected capability, representation, search lineage, local judgment operation, or semantic route. "
                "Do not ask the user to repeat the task merely because this route failed."
            ),
            "failed_operation":node.operation,"failure_ref":failure_ref,
            "failed_route_signature": failed_route["signature"],
            "failed_route_signatures": list(runtime.extensions.get("failed_route_signatures", [])),
            "boundary_translation":boundary_translation,
        })
        # A reconstruct that fails the same way the last reconstruct failed has
        # produced no new information, and spawning another one is not persistence —
        # it is a spin. `_can_rewrite` deliberately has no ceiling ("a budget is not a
        # goal ceiling"), so the bound has to come from *route novelty*: the repair
        # loop continues only while each attempt is materially different.
        #
        # Keeping the goal alive means leaving it resumable and unresolved, which is
        # what the partial-result path already does. It does not mean looping until a
        # host resource ceiling kills the turn and loses the goal entirely.
        repeated_repair_failure = (
            node.operation == "runtime.reconstruct"
            and sum(
                1 for x in runtime.extensions.get("failed_routes", [])
                if isinstance(x, dict) and str(x.get("operation")) == "runtime.reconstruct"
                and str(x.get("error_type")) == failure["error_type"]
            ) > 1
        )
        if repeated_repair_failure:
            runtime.extensions.setdefault("notices", []).append(
                "route reconstruction failed identically twice; the goal stays open and resumable "
                "rather than spinning on the same failed route"
            )
            runtime.extensions["repair_loop_halted"] = {
                "failed_route_signature": failed_route["signature"],
                "basis": "identical_repair_failure_produces_no_new_route_information",
                "goal_remains_resumable": True,
                "goal_closed_by_this": False,
            }
            try:
                self.durable_runs.append(turn_id, runtime.raw.task_id or "", "WORK_FAILED", failure)
            except Exception as exc:
                runtime.extensions.setdefault("notices", []).append(
                    "durable failure journal unavailable: " + str(exc)
                )
            self._persist(runtime)
            return self._finish_view(
                runtime, "partial",
                unresolved=tuple(node.intent_refs) or runtime.program.objective_refs,
            )
        self._replace_pending(runtime,(node.node_id,),[repair],count_rewrite=True,required=True)
        try:
            self.durable_runs.append(turn_id,runtime.raw.task_id or "","WORK_FAILED",failure)
        except Exception as exc:
            runtime.extensions.setdefault("notices", []).append(
                "durable failure journal unavailable: " + str(exc)
            )
        self._persist(runtime)
        return self._advance(turn_id)

    def _apply_semantic_result(self, runtime, node, payload):
        """Project accepted cognition into operation-specific runtime state.

        This adapter is downstream of semantic acceptance. Failure to project a
        novel cognitive shape does not turn the cognition itself into a failed
        HOST work result; the raw semantic state remains first-class and can be
        re-integrated by a later cognition epoch.
        """
        if node.operation == "methods.interpret":
            return self._interpret_method(runtime, node, payload)
        if node.operation == "feedback.design":
            return self._feedback_design(runtime, node, payload)
        if node.operation == "feedback.review":
            return self._feedback_review(runtime, node, payload)
        if node.operation == "integration.install":
            return self._integration_install_result(runtime, node, payload)
        if node.operation == "quality.inspect":
            return self._quality_result(runtime, node, payload)
        if node.operation == "cognition.compile":
            return self._cognition_result(runtime, node, payload)
        if node.operation == "cognition.delta":
            return self._cognition_delta_result(runtime, node, payload)
        if node.operation == "worlds.generate":
            return self._world_result(runtime, node, payload)
        if node.operation == "worlds.realize":
            return self._world_branch_result(runtime, node, payload)
        if node.operation in {"research.plan", "research.interpret"}:
            return self._research_result(runtime, node, payload)
        if node.operation == "trajectories.propose":
            return self._trajectory_result(runtime, node, payload)
        if node.operation == "trajectories.rewrite":
            return self._trajectory_rewrite_result(runtime, node, payload)
        if node.operation == "runtime.reconstruct":
            return self._reconstruction_result(runtime, node, payload)
        if node.operation in MATERIAL:
            return self._material_result(runtime, node, payload)
        return runtime.ledger.add_observation(payload, world_refs=node.world_refs)

    def submit(self, turn_id, work_id, result):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        digest = hashlib.sha256(_json(result).encode()).hexdigest()
        receipt = runtime.extensions.get("receipts", {}).get(work_id)
        if receipt:
            if receipt != digest:
                raise ValueError("stored work result differs; submit a new work item")
            return self.resume(turn_id)
        if work_id not in runtime.work_to_node:
            raise KeyError(work_id)
        original = deepcopy(runtime)
        try:
            node = runtime.program.node(runtime.work_to_node[work_id])
            work = next(w for w in runtime.pending_work if w.work_id == work_id)
            runtime.extensions["execution_fabric"] = charge_execution_fabric(runtime.extensions.get("execution_fabric"), node.operation)
            raw_payload = result if isinstance(result, dict) else {"answer": result}
            payload = normalize_result(raw_payload, work.context.get("references", {}))
            if "method_request" in payload:
                if node.executor != "host_semantic" or node.operation in {"intents.extract", "methods.interpret"} or set(payload) != {"method_request"}:
                    raise ValueError("submit method_request alone from an ordinary semantic work item after intake")
                self._queue_method(runtime, node, payload["method_request"])
                runtime.work_to_node.pop(work_id)
                runtime.pending_work = tuple(w for w in runtime.pending_work if w.work_id != work_id)
                runtime.extensions.setdefault("receipts", {})[work_id] = digest
                return self._advance(turn_id)
            if node.executor == "host_tool":
                self.schemas.validate(work.expected_output_schema, payload)
            else:
                validate_semantic_transport(payload)
            if node.operation == "intents.extract":
                self._accept_intake(runtime, payload)
                runtime.work_to_node.pop(work_id)
                runtime.pending_work = tuple(w for w in runtime.pending_work if w.work_id != work_id)
                runtime.extensions.setdefault("receipts", {})[work_id] = digest
                return self._advance(turn_id)
            if node.executor == "host_tool":
                origin = payload.get("origin_ref")
                if not origin:
                    raise ValueError("tool result requires the actual host tool origin")
                output = payload.get("output")
                urls = payload.get("source_urls", [])
                if not isinstance(urls, (list, tuple)) or any(not isinstance(url, str) or not url.startswith(("https://", "http://")) for url in urls):
                    raise ValueError("source_urls must list actual source URLs returned by the tool")
                result_ref = runtime.ledger.add_source(output, (str(origin), *urls))
                if dict(node.parameters).get("jigaewol_external_kernel"):
                    try:
                        runtime.extensions["external_kernel"] = self.external_kernel.ingest(output)
                        runtime.extensions["external_kernel_origin_ref"] = str(origin)
                        runtime.extensions.pop("external_kernel_error", None)
                    except Exception as exc:
                        runtime.extensions["external_kernel"] = self.external_kernel.effective()
                        runtime.extensions["external_kernel_error"] = str(exc)
                        runtime.extensions["notices"].append("GitHub kernel refresh failed; bundled/cached kernel remains active: " + str(exc))
                self._method_tool_result(runtime, node, payload, result_ref)
                self._feedback_tool_result(runtime, node, payload, result_ref)
                self._integration_tool_result(runtime, node, payload, result_ref, digest)
                branch_ids = dict(node.parameters).get("search_branch_ids", [])
                if node.operation.startswith("capability.") and branch_ids:
                    # A research branch may intentionally use documentation, a
                    # repository, a connected knowledge base or another real
                    # observation capability. Bind the returned observation to
                    # its lineage regardless of the provider's coarse role.
                    runtime.extensions["search_strategy"] = bind_search_observation(
                        runtime.extensions.get("search_strategy"), branch_ids, source_ref=result_ref,
                        origin_ref=str(origin), result_sha256=digest)
                runtime.extensions.setdefault("tool_submissions", []).append({
                    "work_id": work_id, "operation": node.operation,
                    "result_sha256": digest, "source_ref": result_ref, "origin_ref": str(origin)})
                external = tuple(str(r) for r in payload.get("effect_refs", ()) if str(r))
                if external:
                    artifact = runtime.ledger.add_material(output, (str(origin),), external)
                    runtime.extensions["artifact_refs"] = runtime.extensions.get("artifact_refs", []) + [artifact]
                    # Artifact existence is available as material; goal satisfaction is decided at delivery.
            else:
                # Known semantic operations own explicit, open-set validators.
                # Malformed payloads and programming errors must fail the work
                # instead of being relabeled as "novel cognition". Unknown
                # semantic operations are already preserved by
                # _apply_semantic_result's generic observation path.
                result_ref = self._apply_semantic_result(runtime, node, payload)
                runtime.extensions.setdefault("semantic_acceptance_receipts", []).append({
                    "work_id": work_id,
                    "operation": node.operation,
                    "result_sha256": digest,
                    "result_ref": result_ref,
                    "state": "accepted_into_jigaewol_cognition",
                })
            if node.executor != "host_tool" and dict(node.parameters).get("integration_id"):
                self._integration_semantic_result(runtime, node, payload, result_ref, digest)
            try:
                self._record_route_outcome(
                    runtime, operation=node.operation, parameters=dict(node.parameters),
                    outcome="success", evidence_ref=result_ref,
                )
            except Exception as route_state_exc:
                runtime.extensions.setdefault("nonblocking_notices", []).append({
                    "kind": "route_success_state_recording_failed",
                    "error_type": type(route_state_exc).__name__,
                    "message": str(route_state_exc)[:300],
                })
            runtime.program = Scheduler.apply_result(runtime.program, node.node_id, result_ref)
            if node.executor == "host_tool":
                params = dict(node.parameters)
                spec_id = node.operation.removeprefix("capability.") if node.operation.startswith("capability.") else ""
                specs = runtime.extensions.get("capability_specs", [])
                spec = next((x for x in specs if str(x.get("id")) == spec_id), {})
                role = str(spec.get("role", ""))
                search_ids = {str(c["id"]) for c in specs if is_search_capability(c)}
                policy = observation_policy(
                    params,
                    is_search=spec_id in search_ids,
                    is_repository=(role in {"repository", "code_repository"} or "github" in spec_id.casefold() or "repo" in spec_id.casefold()),
                )
                if policy != "none":
                    add_pending_observation(
                        runtime.extensions, source_ref=result_ref, result_sha256=digest,
                        operation=node.operation, policy=policy, group=params.get("_jigaewol_parallel_group"))
                # Batched siblings already have one DAG join. Sequential evidence
                # receives one smallest-delta epoch before the next consequential
                # action; it never restarts cognition.compile automatically.
                if policy != "none" and params.get("_jigaewol_delta_join_planned") is not True:
                    pending = [n for n in runtime.program.nodes if n.status == "pending"]
                    next_node = next((n for n in pending if n.operation != "closure.check"), None)
                    if next_node is not None and next_node.operation != "cognition.delta":
                        delta = self._node(runtime, "host_semantic", "cognition.delta", intents=next_node.intent_refs, parameters={
                            "instruction": delta_instruction(),
                            "observation_refs": [result_ref],
                            "observation_group": "sequential",
                        })
                        self._replace_pending(runtime, (next_node.node_id,), [delta, next_node],
                                              count_rewrite=True, required=True)
            if getattr(work, "operator_ids", ()):
                contracts = work.context.get("operator_contracts", [])
                runtime.extensions.setdefault("operator_binding_receipts", []).append({
                    "work_id": work_id,
                    "operator_ids": list(work.operator_ids),
                    "contract_sha256": [c.get("contract_sha256") for c in contracts if isinstance(c, dict)],
                    "result_sha256": digest,
                    "verification": "contract_was_in_actual_work_context_and_result_was_bound_to_that_work",
                    "semantic_compliance": "not_runtime_attested",
                })
            runtime.work_to_node.pop(work_id)
            runtime.pending_work = tuple(w for w in runtime.pending_work if w.work_id != work_id)
            runtime.extensions.setdefault("receipts", {})[work_id] = digest
            return self._advance(turn_id)
        except Exception as exc:
            self._runtimes[turn_id] = original
            try:
                self.durable_runs.append(turn_id, original.raw.task_id or "", "WORK_FAILED", {"work_id": work_id, "error": f"{type(exc).__name__}: {exc}"})
            except Exception as journal_exc:
                original.extensions.setdefault("notices", []).append(
                    "durable failure journal unavailable: " + str(journal_exc)
                )
            raise
