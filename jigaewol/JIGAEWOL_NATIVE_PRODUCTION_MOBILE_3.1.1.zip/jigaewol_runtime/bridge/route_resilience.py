from __future__ import annotations

"""Route-local failure accounting for execution reconstruction.

A failed execution path is evidence about that exact route, not authority to
shrink the user's destination.  Signatures are deliberately mechanical: they
help the runtime detect accidental replay of an identical failed route while
still allowing a retry when the host supplies a concrete changed-condition
basis.
"""

from copy import deepcopy
import hashlib
import json

_VOLATILE_KEYS = {
    "instruction", "failure_ref", "boundary_translation", "observation_policy",
    "search_cycle_epoch", "search_branch_ids", "research_route_basis",
}


def _stable(value):
    if isinstance(value, dict):
        return {
            str(k): _stable(v)
            for k, v in sorted(value.items(), key=lambda item: str(item[0]))
            if str(k) not in _VOLATILE_KEYS and not str(k).startswith("_jigaewol_")
        }
    if isinstance(value, (list, tuple)):
        return [_stable(v) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)


def route_signature(operation: str, parameters=None) -> str:
    op = str(operation or "").strip()
    payload = {"operation": op, "parameters": _stable(dict(parameters or {}))}
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return "route_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def failed_route_record(operation: str, parameters, *, error_type: str, error: str, work_id: str) -> dict:
    return {
        "signature": route_signature(operation, parameters),
        "operation": str(operation),
        "parameters": deepcopy(_stable(dict(parameters or {}))),
        "error_type": str(error_type),
        "error": str(error),
        "work_id": str(work_id),
        "scope": "route_local",
        "destination_effect": "none",
    }
