from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import re

from jigaewol_components.user_contract import OPERATIONAL_CONTRACT_TEXT
from jigaewol_runtime.adaptation.integrations import validate_integration_manifest
from jigaewol_runtime.bridge.authority_plane import authority_plane_snapshot
from jigaewol_runtime.capabilities.execution_envelope import normalize_execution_handles, normalize_execution_probes
from jigaewol_runtime.kernel.schemas import SchemaRegistry

POSITIVE_INVARIANTS = (
    "Authority order is USER > JIGAEWOL > MODEL.",
    "The exact live user directive owns the destination, explicit means, and every live requirement through delivery.",
    "Jigaewol derives, composes and replaces representations, routes, tools, bodies and runtime structures only as revocable delegated means in service of that directive.",
    "The model contributes replaceable hypotheses, plans, reframes and language rather than destination authority.",
    "Current capability catalogs are starting material for discovery, composition, acquisition and construction.",
    "Observed, executed, successful, inferred, proposed and open states remain distinct in the truth ledger.",
    "Verification records truth state and improvement signals while user work continues through the strongest available route.",
    "Recurring failure raises architecture replacement pressure and feeds the next executable state.",
)


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + " must be nonempty text")
    return value.strip()


def validate_semantic_transport(value):
    """Validate transport shape without rewriting the user contract or cognition content."""
    if not isinstance(value, dict):
        raise ValueError("semantic result transport must be an object")
    return value


def _host_result(value):
    return validate_semantic_transport(value)


def _capability(value):
    if not isinstance(value, dict):
        raise ValueError("invalid capability manifest payload")
    _text(value.get("capability_id"), "capability_id")
    operations = value.get("operations")
    if not isinstance(operations, list) or not operations or any(not isinstance(x, str) or not x.strip() for x in operations):
        raise ValueError("capability operations must be a nonempty text list")
    return value


def _worlds_result(value):
    value = validate_semantic_transport(value)
    for key in ("worlds", "representations"):
        rows = value.get(key)
        if rows is not None and not isinstance(rows, list):
            raise ValueError(key + " must be a list when supplied")
    return value


def _validate_step_list(steps, label="steps"):
    if not isinstance(steps, list):
        raise ValueError(label + " must be a list")
    for step in steps:
        if not isinstance(step, dict):
            raise ValueError(label + " entries must be objects")
        _text(step.get("operation"), label + " operation")
        if "parameters" in step and not isinstance(step["parameters"], dict):
            raise ValueError(label + " parameters must be objects")
        if "parallel_group" in step and not isinstance(step["parallel_group"], str):
            raise ValueError("parallel_group must be text")
    return steps


def _cognition_compile(value):
    if not isinstance(value, dict):
        raise ValueError("cognition.compile result must be an object")
    if "frame" in value and value.get("frame") is not None and not isinstance(value.get("frame"), dict):
        raise ValueError("cognition frame must be an object when supplied")
    _validate_step_list(value.get("steps", []), "cognition steps")
    routes = value.get("route_candidates", [])
    if routes is not None and not isinstance(routes, list):
        raise ValueError("route_candidates must be a list")
    if "stop_condition" in value and value.get("stop_condition") is not None and not isinstance(value.get("stop_condition"), str):
        raise ValueError("cognition stop_condition must be text when supplied")
    return value


def _cognition_delta(value):
    if not isinstance(value, dict):
        raise ValueError("cognition.delta result must be an object")
    if not isinstance(value.get("decision_delta", {}), dict):
        raise ValueError("cognition.delta decision_delta must be an object")
    _validate_step_list(value.get("new_steps", []), "delta new_steps")
    if "requires_more_evidence" in value and type(value["requires_more_evidence"]) is not bool:
        raise ValueError("requires_more_evidence must be boolean")
    if "frame_changed" in value and type(value["frame_changed"]) is not bool:
        raise ValueError("frame_changed must be boolean")
    if "new_frame" in value and value.get("new_frame") is not None and not isinstance(value.get("new_frame"), dict):
        raise ValueError("new_frame must be an object when supplied")
    cause = value.get("frame_change_source_refs", [])
    if cause is not None and (not isinstance(cause, list) or any(not isinstance(x, str) or not x.strip() for x in cause)):
        raise ValueError("frame_change_source_refs must be a list of nonempty refs")
    if "stop_condition" in value and value.get("stop_condition") is not None and not isinstance(value.get("stop_condition"), str):
        raise ValueError("delta stop_condition must be text when supplied")
    return value


def _research_plan(value):
    value = validate_semantic_transport(value)
    if "branches" in value and value.get("branches") is not None and not isinstance(value.get("branches"), list):
        raise ValueError("research branches must be a list when supplied")
    if "queries" in value and value.get("queries") is not None and not isinstance(value.get("queries"), list):
        raise ValueError("research queries must be a list when supplied")
    return value


def _research_interpret(value):
    return validate_semantic_transport(value)


def _integration_install(value):
    if not isinstance(value, dict):
        raise ValueError("integration.install requires an object")
    _text(value.get("source_ref"), "integration.install source_ref")
    validate_integration_manifest(value.get("manifest"))
    return value


def _material_result(value):
    return validate_semantic_transport(value)


def _capability_result(value):
    if not isinstance(value, dict) or "output" not in value:
        raise ValueError("capability.result requires output and origin_ref")
    origin_ref = _text(value.get("origin_ref"), "capability.result origin_ref")
    urls = value.get("source_urls", [])
    if urls is not None and (not isinstance(urls, list) or any(not isinstance(x, str) for x in urls)):
        raise ValueError("source_urls must be a list")
    handles = normalize_execution_handles(value.get("execution_handles", ()), default_origin_ref=origin_ref)
    probes = normalize_execution_probes(value.get("execution_probes", ()), default_origin_ref=origin_ref)
    value = dict(value)
    value["execution_handles"] = [dict(x) for x in handles]
    value["execution_probes"] = [dict(x) for x in probes]
    return value


def _trajectories_result(value):
    value = validate_semantic_transport(value)
    if "candidates" in value and value.get("candidates") is not None and not isinstance(value.get("candidates"), list):
        raise ValueError("candidates must be a list when supplied")
    return value


def _intents_result(value):
    value = validate_semantic_transport(value)
    requirements = value.get("requirements", [])
    if requirements is not None and not isinstance(requirements, list):
        raise ValueError("requirements must be a list when supplied")
    if "continuation" in value and type(value["continuation"]) is not bool:
        raise ValueError("continuation must be boolean")
    tm = value.get("task_model")
    if tm is not None and not isinstance(tm, dict):
        raise ValueError("task_model must be an object")
    for item in requirements or []:
        if not isinstance(item, dict):
            raise ValueError("intent requirements must be objects")
        ids = item.get("supersedes_goal_ids", [])
        if not isinstance(ids, list) or any(not isinstance(x, str) or not x.strip() for x in ids):
            raise ValueError("supersedes_goal_ids must be a list")
    return value


def _feedback_design(value):
    return validate_semantic_transport(value)


def _feedback_review(value):
    return validate_semantic_transport(value)


def _methods_interpret(value):
    return validate_semantic_transport(value)


def build_runtime_schema_registry() -> SchemaRegistry:
    registry = SchemaRegistry()
    registry.register("methods.interpret", _methods_interpret)
    registry.register("feedback.design", _feedback_design)
    registry.register("feedback.review", _feedback_review)
    registry.register("intents.result", _intents_result)
    registry.register("host.result", _host_result)
    registry.register("freeform", _host_result)
    registry.register("worlds.result", _worlds_result)
    registry.register("trajectories.result", _trajectories_result)
    registry.register("cognition.compile", _cognition_compile)
    registry.register("cognition.delta", _cognition_delta)
    registry.register("research.plan", _research_plan)
    registry.register("research.interpret", _research_interpret)
    registry.register("integration.install", _integration_install)
    registry.register("material.result", _material_result)
    registry.register("capability.result", _capability_result)
    registry.register("capability.manifest", _capability)
    return registry


def render_host_constitution(registry: SchemaRegistry | None = None) -> str:
    registry = registry or build_runtime_schema_registry()
    # Keep host-facing control text compact: canonical source authority and truth
    # labeling are invariants; duplicated architecture prose is not.
    lines = [
        "# Jigaewol Runtime Contract",
        OPERATIONAL_CONTRACT_TEXT,
        POSITIVE_INVARIANTS[0],
        "Downstream modules consume canonical directives without reinterpreting their authority.",
        "Execution/tool claims are labeled from observed results.",
        "Schemas: " + ", ".join(registry.names()),
    ]
    return "\n".join(lines) + "\n"


@dataclass(frozen=True)
class DocumentedExample:
    schema_name: str
    payload: object


def load_examples(path) -> tuple[DocumentedExample, ...]:
    text = Path(path).read_text(encoding="utf-8")
    pattern = re.compile(r"<!--\s*example:([\w.\-]+)\s*-->\s*```json\s*(.*?)\s*```", re.S)
    return tuple(DocumentedExample(schema, json.loads(payload)) for schema, payload in pattern.findall(text))
