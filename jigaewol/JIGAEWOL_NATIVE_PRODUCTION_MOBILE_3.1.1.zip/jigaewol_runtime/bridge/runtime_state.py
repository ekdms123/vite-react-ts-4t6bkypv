from __future__ import annotations

from dataclasses import asdict

from jigaewol_runtime.blackboard.ledger import Ledger, LedgerEntry
from jigaewol_runtime.bridge.host_work import HostWork
from jigaewol_runtime.compiler.program_ir import ProgramIR, ProgramNode
from jigaewol_runtime.contract.intents import IntentLattice, IntentNode
from jigaewol_runtime.contract.raw_turn import RawTurn, SourceSpan
from jigaewol_runtime.governor.budget import BudgetPolicy
from jigaewol_runtime.worlds.model import WorldModel


def _strict_bool(value, label):
    if not isinstance(value, bool):
        raise ValueError(label + " must be boolean")
    return value


def _object(value, label):
    if not isinstance(value, dict):
        raise ValueError(label + " must be an object")
    return value


def _sequence(value, label):
    if not isinstance(value, (list, tuple)):
        raise ValueError(label + " must be a list")
    return value


def _text_sequence(value, label):
    rows = _sequence(value, label)
    if any(not isinstance(item, str) for item in rows):
        raise ValueError(label + " must contain text values")
    return tuple(rows)


def _object_sequence(value, label):
    rows = _sequence(value, label)
    if any(not isinstance(item, dict) for item in rows):
        raise ValueError(label + " must contain objects")
    return rows


def _pairs(value, label, *, text_values=False):
    rows = _sequence(value, label)
    out = []
    for item in rows:
        if not isinstance(item, (list, tuple)) or len(item) != 2 or not isinstance(item[0], str):
            raise ValueError(label + " must contain [text, value] pairs")
        if text_values and not isinstance(item[1], str):
            raise ValueError(label + " values must be text")
        out.append((item[0], item[1]))
    return tuple(out)


def encode_runtime(runtime) -> dict:
    return {
        "raw": asdict(runtime.raw),
        "lattice": {
            "nodes": [asdict(n) for n in runtime.lattice.nodes],
        },
        "program": {
            "program_id": runtime.program.program_id,
            "objective_refs": list(runtime.program.objective_refs),
            "nodes": [asdict(n) for n in runtime.program.nodes],
            "edges": [list(e) for e in runtime.program.edges],
            "world_refs": list(runtime.program.world_refs),
            "budget_policy": asdict(runtime.program.budget_policy),
            "recompile_triggers": list(runtime.program.recompile_triggers),
            "closure_requirements": list(runtime.program.closure_requirements),
            "metadata": [list(x) for x in runtime.program.metadata],
        },
        "ledger": [asdict(e) for e in runtime.ledger._entries.values()],
        "work_to_node": dict(runtime.work_to_node),
        "pending_work": [asdict(w) for w in getattr(runtime, "pending_work", ())],
        "answer": runtime.answer,
        "attachment_inventory": list(runtime.attachment_inventory),
        "attachment_context": list(getattr(runtime, "attachment_context", ())),
        "worlds": [asdict(w) for w in getattr(runtime, "worlds", ())],
        "recompile_count": getattr(runtime, "recompile_count", 0),
        "capabilities": list(getattr(runtime, "capabilities", ())),
        "repertoire_context": list(getattr(runtime, "repertoire_context", ())),
        "learned": _strict_bool(getattr(runtime, "learned", False), "runtime learned"),
        "extensions": dict(getattr(runtime, "extensions", {})),
    }


def decode_runtime(payload: dict, runtime_cls):
    payload = _object(payload, "runtime state")
    recompile_count = payload.get("recompile_count", 0)
    if isinstance(recompile_count, bool) or not isinstance(recompile_count, int) or recompile_count < 0:
        raise ValueError("runtime recompile_count must be a nonnegative integer")

    raw_data = _object(payload.get("raw"), "runtime raw turn")
    raw = RawTurn(
        turn_id=raw_data["turn_id"],
        message=raw_data["message"],
        attachment_refs=_text_sequence(raw_data.get("attachment_refs", ()), "runtime attachment_refs"),
        capability_snapshot_ref=raw_data.get("capability_snapshot_ref"),
        task_id=raw_data.get("task_id"),
        source_hash=raw_data.get("source_hash", ""),
    )

    lattice_data = _object(payload.get("lattice"), "runtime lattice")
    nodes = []
    for item in _object_sequence(lattice_data.get("nodes", ()), "runtime lattice nodes"):
        spans = tuple(SourceSpan(**span) for span in _object_sequence(item.get("source_spans", ()), "intent source_spans"))
        nodes.append(IntentNode(
            intent_id=item["intent_id"], meaning=item["meaning"], source_spans=spans,
            strength=item["strength"], required=item["required"], canonical_key=item["canonical_key"],
        ))
    lattice = IntentLattice(raw_turn=raw, nodes=tuple(nodes))

    p = _object(payload.get("program"), "runtime program")
    budget = _object(p.get("budget_policy"), "runtime budget_policy")
    program = ProgramIR(
        program_id=p["program_id"],
        objective_refs=_text_sequence(p.get("objective_refs", ()), "program objective_refs"),
        nodes=tuple(ProgramNode(**{**n,
            "inputs": _text_sequence(n.get("inputs", ()), "program node inputs"),
            "outputs": _text_sequence(n.get("outputs", ()), "program node outputs"),
            "intent_refs": _text_sequence(n.get("intent_refs", ()), "program node intent_refs"),
            "world_refs": _text_sequence(n.get("world_refs", ()), "program node world_refs"),
            "expected_effects": _text_sequence(n.get("expected_effects", ()), "program node expected_effects"),
            "evidence_requirements": _text_sequence(n.get("evidence_requirements", ()), "program node evidence_requirements"),
            "parameters": _pairs(n.get("parameters", ()), "program node parameters"),
            "operator_ids": _text_sequence(n.get("operator_ids", ()), "program node operator_ids"),
            "language_refs": _text_sequence(n.get("language_refs", ()), "program node language_refs"),
            "trigger_refs": _text_sequence(n.get("trigger_refs", ()), "program node trigger_refs"),
            "action_species_ids": _text_sequence(n.get("action_species_ids", ()), "program node action_species_ids"),
            "visibility_scope": n.get("visibility_scope"),
        }) for n in _object_sequence(p.get("nodes", ()), "program nodes")),
        edges=_pairs(p.get("edges", ()), "program edges", text_values=True),
        world_refs=_text_sequence(p.get("world_refs", ()), "program world_refs"),
        budget_policy=BudgetPolicy(**budget),
        recompile_triggers=_text_sequence(p.get("recompile_triggers", ()), "program recompile_triggers"),
        closure_requirements=_text_sequence(p.get("closure_requirements", ()), "program closure_requirements"),
        metadata=_pairs(p.get("metadata", ()), "program metadata"),
    )

    ledger = Ledger()
    for item in _object_sequence(payload.get("ledger", ()), "runtime ledger"):
        entry = LedgerEntry(
            entry_id=item["entry_id"], kind=item["kind"], subject_ref=item.get("subject_ref"),
            content=item.get("content"), evidence_refs=_text_sequence(item.get("evidence_refs", ()), "ledger evidence_refs"),
            exact_spans_or_diffs=tuple(_sequence(item.get("exact_spans_or_diffs", ()), "ledger exact_spans_or_diffs")),
            tool_origin_refs=_text_sequence(item.get("tool_origin_refs", ()), "ledger tool_origin_refs"),
            world_refs=_text_sequence(item.get("world_refs", ()), "ledger world_refs"),
            intent_refs=_text_sequence(item.get("intent_refs", ()), "ledger intent_refs"),
            verification_status=item.get("verification_status", "unverified"),
        )
        ledger.append(entry)

    worlds = []
    for w in _object_sequence(payload.get("worlds", ()), "runtime worlds"):
        worlds.append(WorldModel(**{**w,
            "assumptions": _text_sequence(w.get("assumptions", ()), "world assumptions"),
            "predicted_observations": _text_sequence(w.get("predicted_observations", ()), "world predicted_observations"),
            "discriminating_questions": _text_sequence(w.get("discriminating_questions", ()), "world discriminating_questions"),
            "expected_material_effects": _text_sequence(w.get("expected_material_effects", ()), "world expected_material_effects"),
            "evidence_for": _text_sequence(w.get("evidence_for", ()), "world evidence_for"),
            "evidence_against": _text_sequence(w.get("evidence_against", ()), "world evidence_against"),
        }))

    runtime = runtime_cls(
        raw=raw, lattice=lattice, program=program, ledger=ledger,
        work_to_node=dict(_object(payload.get("work_to_node", {}), "runtime work_to_node")),
        answer=payload.get("answer"),
        attachment_inventory=tuple(_sequence(payload.get("attachment_inventory", ()), "runtime attachment_inventory")),
        attachment_context=tuple(_sequence(payload.get("attachment_context", ()), "runtime attachment_context")),
        worlds=tuple(worlds),
        recompile_count=recompile_count,
        capabilities=tuple(_sequence(payload.get("capabilities", ()), "runtime capabilities")),
        repertoire_context=tuple(_sequence(payload.get("repertoire_context", ()), "runtime repertoire_context")),
        learned=_strict_bool(payload.get("learned", False), "runtime learned"),
        extensions=dict(_object(payload.get("extensions", {}), "runtime extensions")),
    )

    pending = []
    for w in _object_sequence(payload.get("pending_work", ()), "runtime pending_work"):
        pending.append(HostWork(**{**w,
            "intent_refs": _text_sequence(w.get("intent_refs", ()), "pending work intent_refs"),
            "world_refs": _text_sequence(w.get("world_refs", ()), "pending work world_refs"),
            "input_refs": _text_sequence(w.get("input_refs", ()), "pending work input_refs"),
            "context_slices": _text_sequence(w.get("context_slices", ()), "pending work context_slices"),
            "expected_effects": _text_sequence(w.get("expected_effects", ()), "pending work expected_effects"),
            "evidence_requirements": _text_sequence(w.get("evidence_requirements", ()), "pending work evidence_requirements"),
            "operator_ids": _text_sequence(w.get("operator_ids", ()), "pending work operator_ids"),
            "language_refs": _text_sequence(w.get("language_refs", ()), "pending work language_refs"),
            "trigger_refs": _text_sequence(w.get("trigger_refs", ()), "pending work trigger_refs"),
            "visibility_scope": w.get("visibility_scope"),
            "idempotency_key": w.get("idempotency_key") or w.get("work_id"),
            "resume_policy": w.get(
                "resume_policy",
                "reconcile_before_replay"
                if w.get("executor") == "host_tool" and str(w.get("permission_class", "none")) not in {"none", "read"}
                else "safe_replay",
            ),
        }))
    runtime.pending_work = tuple(pending)
    return runtime
