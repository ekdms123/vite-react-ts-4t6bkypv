from __future__ import annotations

"""Durable route-local failure memory scoped to a live user goal.

A route failure is evidence about one task/capability/route signature.  It is
never authority to shrink the user's goal.  Cooldown is a scheduling hint that
expires across continuation turns; failure evidence remains durable after the
cooldown reaches zero.
"""

from dataclasses import dataclass
from pathlib import Path
import sqlite3
import time


@dataclass(frozen=True)
class GoalRouteState:
    task_id: str
    capability_id: str
    route_signature: str
    failure_count: int
    last_failure_receipt: str
    cooldown: int
    updated_at: float


class GoalRouteStateStore:
    """SQLite-backed route memory keyed by task + capability + route signature."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _connect(self):
        conn = sqlite3.connect(self.path)
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS goal_route_state (
                    task_id TEXT NOT NULL,
                    capability_id TEXT NOT NULL,
                    route_signature TEXT NOT NULL,
                    failure_count INTEGER NOT NULL DEFAULT 0,
                    last_failure_receipt TEXT NOT NULL DEFAULT '',
                    cooldown INTEGER NOT NULL DEFAULT 0,
                    updated_at REAL NOT NULL,
                    PRIMARY KEY(task_id, capability_id, route_signature)
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS goal_route_state_task_idx "
                "ON goal_route_state(task_id, cooldown DESC, updated_at DESC)"
            )

    @staticmethod
    def _required(value: str, label: str) -> str:
        value = str(value or "").strip()
        if not value:
            raise ValueError(f"{label} must be nonempty text")
        return value

    @staticmethod
    def _decode(row) -> GoalRouteState | None:
        if row is None:
            return None
        return GoalRouteState(
            task_id=str(row[0]),
            capability_id=str(row[1]),
            route_signature=str(row[2]),
            failure_count=int(row[3]),
            last_failure_receipt=str(row[4]),
            cooldown=int(row[5]),
            updated_at=float(row[6]),
        )

    def get(self, task_id: str, capability_id: str, route_signature: str) -> GoalRouteState | None:
        task_id = self._required(task_id, "task_id")
        capability_id = self._required(capability_id, "capability_id")
        route_signature = self._required(route_signature, "route_signature")
        with self._connect() as conn:
            row = conn.execute(
                "SELECT task_id,capability_id,route_signature,failure_count,last_failure_receipt,cooldown,updated_at "
                "FROM goal_route_state WHERE task_id=? AND capability_id=? AND route_signature=?",
                (task_id, capability_id, route_signature),
            ).fetchone()
        return self._decode(row)

    def record_failure(
        self,
        *,
        task_id: str,
        capability_id: str,
        route_signature: str,
        failure_receipt: str,
        max_cooldown: int = 8,
    ) -> GoalRouteState:
        task_id = self._required(task_id, "task_id")
        capability_id = self._required(capability_id, "capability_id")
        route_signature = self._required(route_signature, "route_signature")
        failure_receipt = self._required(failure_receipt, "failure_receipt")
        if isinstance(max_cooldown, bool) or not isinstance(max_cooldown, int) or max_cooldown < 1:
            raise ValueError("max_cooldown must be a positive integer")
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO goal_route_state(
                    task_id,capability_id,route_signature,failure_count,last_failure_receipt,cooldown,updated_at
                ) VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(task_id,capability_id,route_signature) DO UPDATE SET
                    failure_count=goal_route_state.failure_count+1,
                    last_failure_receipt=excluded.last_failure_receipt,
                    cooldown=MIN(?, goal_route_state.failure_count+1),
                    updated_at=excluded.updated_at
                """,
                (task_id, capability_id, route_signature, 1, failure_receipt, 1, now, max_cooldown),
            )
            row = conn.execute(
                "SELECT task_id,capability_id,route_signature,failure_count,last_failure_receipt,cooldown,updated_at "
                "FROM goal_route_state WHERE task_id=? AND capability_id=? AND route_signature=?",
                (task_id, capability_id, route_signature),
            ).fetchone()
        state = self._decode(row)
        assert state is not None
        return state

    def record_success(self, *, task_id: str, capability_id: str, route_signature: str) -> GoalRouteState:
        task_id = self._required(task_id, "task_id")
        capability_id = self._required(capability_id, "capability_id")
        route_signature = self._required(route_signature, "route_signature")
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO goal_route_state(
                    task_id,capability_id,route_signature,failure_count,last_failure_receipt,cooldown,updated_at
                ) VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(task_id,capability_id,route_signature) DO UPDATE SET
                    cooldown=0,
                    updated_at=excluded.updated_at
                """,
                (task_id, capability_id, route_signature, 0, "", 0, now),
            )
            row = conn.execute(
                "SELECT task_id,capability_id,route_signature,failure_count,last_failure_receipt,cooldown,updated_at "
                "FROM goal_route_state WHERE task_id=? AND capability_id=? AND route_signature=?",
                (task_id, capability_id, route_signature),
            ).fetchone()
        state = self._decode(row)
        assert state is not None
        return state

    def for_task(self, task_id: str) -> tuple[GoalRouteState, ...]:
        task_id = self._required(task_id, "task_id")
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT task_id,capability_id,route_signature,failure_count,last_failure_receipt,cooldown,updated_at "
                "FROM goal_route_state WHERE task_id=? "
                "ORDER BY cooldown DESC, updated_at DESC, capability_id, route_signature",
                (task_id,),
            ).fetchall()
        return tuple(self._decode(row) for row in rows if row is not None)

    def active_for_task(self, task_id: str) -> tuple[GoalRouteState, ...]:
        return tuple(state for state in self.for_task(task_id) if state.cooldown > 0)

    def decrement_cooldowns(self, task_id: str) -> None:
        task_id = self._required(task_id, "task_id")
        with self._connect() as conn:
            conn.execute(
                "UPDATE goal_route_state SET cooldown=CASE WHEN cooldown>0 THEN cooldown-1 ELSE 0 END "
                "WHERE task_id=? AND cooldown>0",
                (task_id,),
            )
