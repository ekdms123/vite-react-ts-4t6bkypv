"""Work-scoped context formation.

A packet is the active work authority for its execution horizon. User objectives
are carried as destinations while frames, routes, representations and
interpretations remain runtime-owned working state. Context pressure produces
first-class compact/distilled representations rather than retrieval receipts.
Source digests carry lineage metadata while the packet remains centered on the live user destination.
"""
from copy import deepcopy
from jigaewol_runtime.capabilities.execution_routes import rank_execution_routes, infer_required_traits, compose_execution_routes
from jigaewol_runtime.capabilities.workstation import virtual_workstation_plan
from jigaewol_runtime.capabilities.agent_pool import agent_pool_plan
import hashlib
import json

from jigaewol_runtime.bridge.authority_plane import authority_plane_snapshot, compact_authority_plane_snapshot
from jigaewol_runtime.cognition.evidence_graph import graph_summary
from jigaewol_components.user_contract import OPERATIONAL_CONTRACT_TEXT

MODEL_EXPANSION_RULE = "The explicit user directive owns the destination; internal heuristics organize and expand the means used to reach it."

TASK_CONTEXT_RULE = (
    "Carry every active user objective forward as the destination. "
    "Frames, routes, representations, interpretations and world models are revisable working state. "
    "Resource windows, classifiers and verifier output annotate and schedule work while the full destination remains live. "
    "Use exact result refs when observations change decisions and preserve unresolved possibilities as open work."
)

PRESERVATION_RULE = (
    "User objectives persist as destinations. Working representations may change freely when that helps the objective. "
    "Observed execution state remains separate from speculative or planned state."
)

COMPACT_TASK_CONTEXT_RULE = (
    "User directive is canonical; working cognition is revisable; execution truth is recorded separately."
)


def size(value):
    return len(json.dumps(value, ensure_ascii=False, allow_nan=False))


def _positive_int(value, label):
    if type(value) is not int or value < 1:
        raise ValueError(label + " must be a positive integer")
    return value


def _stable_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _sha256_text(value):
    return hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()


def _sha256_value(value):
    return _sha256_text(_stable_json(value))


def _clean_text(value):
    return " ".join(str(value or "").split())


def _distill_text(value, limit):
    """Create a bounded, first-class extractive representation.

    This helper does not pretend to infer new semantics. It normalizes noise and,
    when space is tight, preserves both the opening and closing semantic edges of
    the supplied text. Higher-level distillation comes from preferring existing
    semantic fields (objective meanings, decision state, observation identity)
    over raw transport detail.
    """
    text = _clean_text(value)
    if limit is None or len(text) <= limit:
        return text
    limit = max(8, _positive_int(limit, "distillation limit"))
    if limit <= 12:
        return text[:limit]
    marker = " … "
    room = limit - len(marker)
    head = max(1, (room * 2) // 3)
    tail = max(1, room - head)
    return text[:head].rstrip() + marker + text[-tail:].lstrip()


def _semantic_text(item, *keys):
    for key in keys:
        if isinstance(item, dict) and item.get(key) not in (None, ""):
            return str(item.get(key))
    return ""


def _compact_goal_gravity(goal_gravity, *, meaning_limit=None):
    """Form a compact goal model whose distilled meanings remain first-class.

    Compaction may change representation, but it does not demote a usable meaning
    into a receipt. Existing legacy preview fields are accepted and assimilated
    as distilled working meaning so repeated compaction remains usable in-place.
    """
    gravity = deepcopy(goal_gravity or {})
    anchors = []
    for item in gravity.get("anchors", []) or []:
        if not isinstance(item, dict):
            continue
        row = {k: deepcopy(item.get(k)) for k in (
            "id", "source_turn_id", "intent_id", "quote_sha256", "source",
            "priority", "status", "supersedes",
        ) if item.get(k) is not None}

        meaning = _semantic_text(item, "meaning", "distilled_meaning", "compact_meaning", "meaning_preview")
        if meaning:
            source_sha = (
                item.get("meaning_source_sha256")
                or item.get("meaning_sha256")
                or _sha256_text(meaning)
            )
            if meaning_limit is None or len(_clean_text(meaning)) <= meaning_limit:
                # Preserve the strongest representation name already present.
                if item.get("meaning") is not None:
                    row["meaning"] = _clean_text(meaning)
                    row["semantic_state"] = item.get("semantic_state") or "prime"
                else:
                    row["distilled_meaning"] = _clean_text(meaning)
                    row["semantic_state"] = "distilled"
                    row["meaning_source_sha256"] = source_sha
            else:
                row["distilled_meaning"] = _distill_text(meaning, meaning_limit)
                row["semantic_state"] = "distilled"
                row["meaning_source_sha256"] = source_sha
        elif item.get("meaning_source_sha256") or item.get("meaning_sha256"):
            row["meaning_source_sha256"] = item.get("meaning_source_sha256") or item.get("meaning_sha256")
            row["semantic_state"] = item.get("semantic_state") or "lineage_only"

        anchors.append(row)

    out = {
        "version": gravity.get("version", 1),
        "anchors": anchors,
        "anchor_ids": [str(x) for x in gravity.get("anchor_ids", []) or []],
        "signature": gravity.get("signature"),
        "rule": gravity.get("rule"),
        "priority_policy": gravity.get("priority_policy"),
        "semantic_state": gravity.get("semantic_state") or ("distilled" if meaning_limit is not None else "prime"),
    }
    for key in ("anchor_ids_sha256", "anchor_ids_count", "anchor_ids_complete"):
        if gravity.get(key) is not None:
            out[key] = deepcopy(gravity.get(key))
    return {k: v for k, v in out.items() if v not in (None, [], "")}


def _objective_invariants(raw, goal_gravity):
    gravity = goal_gravity or {}
    anchors = [x for x in gravity.get("anchors", []) or [] if isinstance(x, dict)]
    ids = [str(x) for x in gravity.get("anchor_ids", []) or []]
    return {
        "version": 2,
        "source_request_sha256": _sha256_text(raw),
        "goal_signature": gravity.get("signature"),
        "goal_anchor_ids": ids,
        "goal_anchor_ids_count": len(ids),
        "goal_anchor_ids_complete": True,
        "active_goal_count": len(anchors),
        "preservation_rule": PRESERVATION_RULE,
        "model_expansion_rule": MODEL_EXPANSION_RULE,
    }


def compact_task_requirements(requirements, quote_limit=None):
    out, transformed = [], False
    for item in requirements or ():
        if not isinstance(item, dict):
            continue
        row = {"turn_id": item.get("turn_id")} if item.get("turn_id") is not None else {}
        meaning = _semantic_text(item, "meaning", "distilled_meaning", "meaning_preview")
        if meaning:
            row["meaning"] = _clean_text(meaning) if item.get("meaning") is not None else _distill_text(meaning, None)
        quote = _semantic_text(item, "quote", "compact_quote", "quote_preview")
        if quote_limit is None or len(_clean_text(quote)) <= quote_limit:
            if quote:
                row["quote"] = _clean_text(quote)
        elif quote:
            row["compact_quote"] = _distill_text(quote, quote_limit)
            row["quote_source_sha256"] = item.get("quote_source_sha256") or item.get("quote_sha256") or _sha256_text(quote)
            row["semantic_state"] = "distilled"
            transformed = True
        out.append(row)
    return out, transformed



def make_packet(runtime, node, instruction=None, *, budget_chars=None):
    """Build the active work-authority packet for the current transition."""
    refs, reverse = {}, {}
    def alias(ref, prefix):
        if ref not in reverse:
            key = prefix + str(1 + sum(k.startswith(prefix) for k in refs))
            refs[key] = ref
            reverse[ref] = key
        return reverse[ref]

    raw = str(runtime.raw.message)
    requirements, transformed = compact_task_requirements(runtime.extensions.get("task_requirements", []))
    intents = []
    wanted = set(getattr(node, "intent_refs", ()) or ())
    lattice_nodes = getattr(getattr(runtime, "lattice", None), "nodes", getattr(runtime, "intents", []))
    for item in lattice_nodes:
        if getattr(item, "intent_id", None) in wanted:
            intents.append({
                "ref": alias(item.intent_id, "R"),
                "id": item.intent_id,
                "meaning": str(item.meaning),
                "quotes": [span.text(raw) for span in item.source_spans],
            })

    entry_index = []
    ledger_entries = list(runtime.ledger._entries.values())
    for entry in ledger_entries:
        entry_index.append({
            "ref": alias(entry.entry_id, "E"),
            "id": entry.entry_id,
            "kind": entry.kind,
            "status": entry.verification_status,
            "intent_refs": list(entry.intent_refs),
        })

    params = dict(getattr(node, "parameters", {}) or {})
    ext = runtime.extensions
    goal_gravity = deepcopy(ext.get("goal_gravity", {}))
    semantic_authority = dict(ext.get("semantic_authority") or {})
    proof_carrying_improvement = dict(semantic_authority.get("proof_carrying_improvement") or {})
    packet = {
        "version": 3,
        "authority": authority_plane_snapshot(),
        "context_stage": "PRIME",
        "instruction": instruction or str(getattr(node, "operation", "host work")),
        "request": raw,
        "request_sha256": _sha256_text(raw),
        "task_requirements": requirements,
        "task_context_rule": TASK_CONTEXT_RULE,
        "objective_invariants": _objective_invariants(raw, goal_gravity),
        "proof_carrying_improvement": deepcopy(proof_carrying_improvement) if proof_carrying_improvement.get("active") else {},
        "intents": intents,
        "parameters": params,
        "capabilities": deepcopy(runtime.extensions.get("capability_specs", [])),
        "attachments": {
            "inventory": list(getattr(runtime, "attachment_inventory", ()) or ()),
            "previews": list(getattr(runtime, "attachment_context", ()) or ()),
            "media": deepcopy(runtime.extensions.get("attachment_media", [])),
        },
        "references": refs,
        "entry_index": entry_index,
        "sections": {
            "goal_gravity": _compact_goal_gravity(goal_gravity),
            "goal_contract": {k: deepcopy(v) for k, v in (ext.get("goal_contract", {}) or {}).items() if k != "source_request"},
        },
        "context_transformations": [],
    }
    if not packet.get("proof_carrying_improvement"):
        packet.pop("proof_carrying_improvement", None)

    if transformed:
        packet["context_transformations"].append({
            "section": "task_requirements.quotes",
            "representation": "distilled",
            "reason": "source_was_already_compact",
        })

    op = node.operation
    if ext.get("previous_turn") and op in {"cognition.compile", "material.realize", "creative.realize", "code.realize"}:
        prev = ext["previous_turn"]
        packet["sections"]["previous_turn"] = {
            k: deepcopy(prev.get(k))
            for k in ("turn_id", "phase", "unresolved", "feedback_decision")
            if prev.get(k) is not None
        }

    if op == "intents.extract":
        from jigaewol_runtime.contract.extraction import request_segments, source_role_hints
        packet["request_segments"] = request_segments(raw)
        packet["source_role_hints"] = source_role_hints(raw)
        candidate = ext.get("previous_turn") or ext.get("_previous_turn_candidate")
        if candidate:
            packet["continuation_candidate"] = {
                "turn_id": candidate.get("turn_id"),
                "phase": candidate.get("phase"),
                "unresolved": candidate.get("unresolved", []),
                "request_compact": _distill_text(candidate.get("request", ""), 360),
            }

    if op == "runtime.reconstruct":
        packet["sections"]["execution_failures"] = deepcopy(ext.get("execution_failures", []))
        packet["sections"]["failed_routes"] = deepcopy(ext.get("failed_routes", []))
        packet["sections"]["current_capability_ids"] = [str(x.get("id")) for x in ext.get("capability_specs", []) if isinstance(x, dict) and x.get("id")]

    if op == "cognition.compile":
        semantic_required_traits = tuple(
            str(x) for x in semantic_authority.get("required_capability_traits", ()) if str(x)
        ) if semantic_authority else infer_required_traits(raw)
        failed_capability_ids = []
        for row in ext.get("failed_routes", []) or []:
            if not isinstance(row, dict):
                continue
            operation = str(row.get("operation", ""))
            if operation.startswith("capability."):
                failed_capability_ids.append(operation.removeprefix("capability."))
        _all_routes = list(rank_execution_routes(
            raw, ext.get("capability_specs", []),
            required_traits=semantic_required_traits,
            avoid_capability_ids=failed_capability_ids,
            limit=None,
            include_reserve=True,
        ))
        packet["sections"]["execution_route_candidates"] = [
            row for row in _all_routes if row.get("activation_state") == "primary"
        ]
        packet["sections"]["execution_route_reservoir"] = [
            {
                "capability_id": row.get("capability_id"),
                "traits": row.get("traits", []),
                "activation_state": row.get("activation_state"),
                "score": row.get("score"),
            }
            for row in _all_routes if row.get("activation_state") != "primary"
        ]
        packet["sections"]["execution_route_selection_semantics"] = "scheduling_not_pruning"
        packet["sections"]["execution_route_composition"] = compose_execution_routes(
            raw, ext.get("capability_specs", []),
            required_traits=semantic_required_traits,
            avoid_capability_ids=failed_capability_ids,
        )
        packet["sections"]["virtual_workstation"] = virtual_workstation_plan(ext.get("capability_specs", []))
        packet["sections"]["external_agent_pool"] = agent_pool_plan(raw, ext.get("capability_specs", []))
        packet["sections"]["compile_signals"] = deepcopy(ext.get("compile_signals", {}))
        packet["sections"]["task_model"] = deepcopy(ext.get("task_model", {}))
        packet["sections"]["decision_state"] = deepcopy(ext.get("decision_state"))
        packet["sections"]["evidence_graph"] = graph_summary(ext.get("evidence_graph", {}))
        packet["sections"]["judgment_plane"] = deepcopy(ext.get("judgment_plane", {}))
        packet["sections"]["integration_catalog"] = deepcopy(ext.get("integration_catalog", []))
        packet["sections"]["cognition_stack_catalog"] = deepcopy(ext.get("cognition_stack_catalog", []))
        packet["sections"]["self_expanding_capability_catalog"] = deepcopy(ext.get("self_expanding_capability_catalog", []))
        packet["sections"]["capability_acquisitions"] = deepcopy(ext.get("capability_acquisitions", []))
        packet["sections"]["source_culture_hints"] = deepcopy(ext.get("source_culture_hints", []))
    elif op == "cognition.delta":
        observation_refs = {str(x) for x in params.get("observation_refs", []) if str(x)}
        group = str(params.get("observation_group", ""))
        for row in ext.get("pending_observation_deltas", []) or []:
            if not group or not row.get("group") or str(row.get("group")) == group:
                observation_refs.add(str(row.get("source_ref")))
        observations = []
        for entry in ledger_entries:
            if entry.entry_id in observation_refs:
                observations.append({
                    "ref": alias(entry.entry_id, "E"),
                    "id": entry.entry_id,
                    "kind": entry.kind,
                    "status": entry.verification_status,
                    "content": deepcopy(entry.content),
                    "origin_refs": list(entry.tool_origin_refs),
                })
        packet["sections"].update({
            "decision_state": deepcopy(ext.get("decision_state", {})),
            "evidence_graph": graph_summary(ext.get("evidence_graph", {})),
            "new_observations": observations,
            "observation_refs": sorted(observation_refs),
        })
        packet["entry_index"] = [x for x in packet["entry_index"] if x["id"] in observation_refs]
    else:
        for key in ("decision_state", "selected", "research_delta", "creative_state", "current_answer"):
            value = ext.get(key) if key != "current_answer" else runtime.answer
            if value is not None:
                packet["sections"][key] = deepcopy(value)
        if op == "creative.realize" and ext.get("creative_state") is not None:
            from jigaewol_runtime.realization.creative import compile_creative_program
            packet["sections"]["creative_program"] = compile_creative_program(ext.get("creative_state"))

    if params.get("method_job") or params.get("integration_job"):
        packet["sections"] = {
            "job": deepcopy(params),
            "goal_gravity": _compact_goal_gravity(goal_gravity),
        }

    raw_target = runtime.program.budget_policy.target_context_chars if budget_chars is None else budget_chars
    target = max(1200, _positive_int(raw_target, "context budget"))
    # Budget metadata is present before enforcement so the cap applies to the
    # delivered object rather than to an object that later grows.
    packet["budget"] = {"target_chars": target, "actual_chars": 0, "hard_cap_met": False}
    for _ in range(4):
        packet = enforce_context_budget(packet, target)
        actual = size(packet)
        packet["budget"] = {"target_chars": target, "actual_chars": actual, "hard_cap_met": actual <= target}
        if size(packet) <= target:
            break
    actual = size(packet)
    packet["budget"] = {"target_chars": target, "actual_chars": actual, "hard_cap_met": actual <= target}
    return packet


def _used_reference_aliases(value, valid_aliases):
    """Return aliases used in explicit reference-bearing schema positions."""
    valid_aliases = set(valid_aliases or ())
    used = set()
    reference_values = set(globals().get("REFERENCE_VALUES", ())) | {"ref"}
    reference_lists = set(globals().get("REFERENCE_LISTS", ()))
    opaque = {"answer", "output", "creative_state", "changes", "revision", "structure", "design_space"}

    def mark(item):
        if isinstance(item, str) and item in valid_aliases:
            used.add(item)

    def visit(item):
        if isinstance(item, (list, tuple)):
            for child in item:
                visit(child)
            return
        if not isinstance(item, dict):
            return
        for key, child in item.items():
            if key == "references":
                continue
            if key == "intent_effects" and isinstance(child, dict):
                for alias, effect in child.items():
                    mark(alias)
                    visit(effect)
                continue
            if key in reference_values:
                mark(child)
                continue
            if key in reference_lists and isinstance(child, (list, tuple)):
                for ref in child:
                    mark(ref)
                continue
            if key in opaque:
                continue
            visit(child)

    visit(value)
    return used


def _note_transformation(out, section, representation, reason="context_budget", source=None):
    rows = out.setdefault("context_transformations", [])
    item = {"section": section, "representation": representation, "reason": reason}
    if source is not None:
        item["source_sha256"] = _sha256_value(source)
    if item not in rows:
        rows.append(item)




def _compact_intent_rows(rows, *, meaning_limit, quote_limit):
    compact = []
    for item in rows or []:
        if not isinstance(item, dict):
            continue
        row = {k: deepcopy(item.get(k)) for k in ("ref", "id") if item.get(k) is not None}
        meaning = _semantic_text(item, "meaning", "distilled_meaning", "meaning_preview")
        if meaning:
            if len(_clean_text(meaning)) <= meaning_limit and item.get("meaning") is not None:
                row["meaning"] = _clean_text(meaning)
            else:
                row["distilled_meaning"] = _distill_text(meaning, meaning_limit)
                row["meaning_source_sha256"] = (
                    item.get("meaning_source_sha256") or item.get("meaning_sha256") or _sha256_text(meaning)
                )
                row["semantic_state"] = "distilled"

        quotes = item.get("quotes")
        if not isinstance(quotes, list):
            quotes = item.get("compact_quotes") or item.get("quote_previews") or []
        quotes = [str(x) for x in quotes or []]
        if quotes:
            compact_quotes = [_distill_text(q, quote_limit) for q in quotes]
            if all(len(_clean_text(q)) <= quote_limit for q in quotes) and item.get("quotes") is not None:
                row["quotes"] = [_clean_text(q) for q in quotes]
            else:
                row["compact_quotes"] = compact_quotes
                row["quotes_source_sha256"] = item.get("quotes_source_sha256") or item.get("quotes_sha256") or [_sha256_text(q) for q in quotes]
                row["semantic_state"] = "distilled"
        compact.append(row)
    return compact


def _compact_capabilities(rows, *, identities_only=False):
    out = []
    for item in rows or []:
        if not isinstance(item, dict):
            out.append(item)
            continue
        keys = ("id", "role") if identities_only else (
            "id", "role", "permission", "cost", "feedback_kind", "evaluator_id",
            "description", "provider", "plugin", "operation", "input_schema",
            "output_schema", "modalities_in", "modalities_out", "tags"
        )
        out.append({k: deepcopy(item.get(k)) for k in keys if item.get(k) is not None})
    return out


def _distill_structured(value, limit):
    """Keep structured state usable while reducing transport surface."""
    if value is None or isinstance(value, (bool, int, float)):
        return deepcopy(value)
    if isinstance(value, str):
        return _distill_text(value, limit)
    if isinstance(value, dict):
        # Reuse an existing first-class distillation instead of wrapping a
        # distillation inside another digest/receipt-shaped object.
        if value.get("distilled_state") is not None:
            return _distill_structured(value.get("distilled_state"), limit)
        if value.get("distilled") is not None and isinstance(value.get("distilled"), str):
            return _distill_text(value.get("distilled"), limit)
    rendered = _stable_json(value)
    if len(rendered) <= limit:
        return deepcopy(value)
    return {
        "distilled": _distill_text(rendered, limit),
        "source_sha256": _sha256_text(rendered),
        "semantic_state": "distilled",
    }


def _distill_observations(rows, per_item_limit):
    out = []
    for item in rows or []:
        if not isinstance(item, dict):
            continue
        row = {k: deepcopy(item.get(k)) for k in ("ref", "id", "kind", "status", "origin_refs") if item.get(k) is not None}
        content = item.get("content")
        if content is None:
            content = item.get("distilled_content", item.get("content_preview"))
        if content is not None:
            rendered = _stable_json(content) if not isinstance(content, str) else _clean_text(content)
            if len(rendered) <= per_item_limit and item.get("content") is not None:
                row["content"] = deepcopy(content)
            else:
                row["distilled_content"] = _distill_text(rendered, per_item_limit)
                row["content_source_sha256"] = item.get("content_source_sha256") or item.get("content_sha256") or _sha256_text(rendered)
                row["semantic_state"] = "distilled"
        out.append(row)
    return out




def _source_authority_floor(packet):
    """Return the non-negotiable source-authority projection of a context packet.

    Context budgets may compress optional cognition, observations and route metadata,
    but they may never rewrite, truncate, reorder or drop the exact user request or
    active task requirements.  When those fields alone exceed the nominal budget we
    deliberately overrun the budget and record that fact instead of silently changing
    the destination seen by the executor/model.
    """
    request = str(packet.get("request") or "")
    requirements = deepcopy(packet.get("task_requirements") or [])
    invariants = deepcopy(packet.get("objective_invariants") or {})
    return {
        "request": request,
        "request_sha256": packet.get("request_sha256") or _sha256_text(request),
        "task_requirements": requirements,
        "objective_invariants": invariants,
    }


def _restore_source_authority(packet, floor):
    """Reapply immutable source authority after any representation transformation."""
    out = deepcopy(packet)
    out["request"] = str(floor.get("request") or "")
    out["request_sha256"] = str(floor.get("request_sha256") or _sha256_text(out["request"]))
    out["task_requirements"] = deepcopy(floor.get("task_requirements") or [])
    if floor.get("objective_invariants"):
        out["objective_invariants"] = deepcopy(floor["objective_invariants"])
    out.setdefault("source_authority", {})
    out["source_authority"].update({
        "request_exact_preserved": True,
        "task_requirements_exact_preserved": True,
        "context_budget_may_not_rewrite_destination": True,
        "request_sha256": out["request_sha256"],
        "task_requirement_count": len(out["task_requirements"]),
    })
    return out


def _axiomatic_context(out, target):
    """Re-form an over-budget packet while preserving exact source authority.

    Only runtime-owned/derived context is distilled.  The exact current request and
    every active task requirement remain byte-for-text identical to the PRIME packet.
    """
    floor = _source_authority_floor(out)
    sec = out.get("sections", {}) if isinstance(out.get("sections"), dict) else {}
    gravity = _compact_goal_gravity(sec.get("goal_gravity", {}), meaning_limit=max(56, target // 14))
    observations = _distill_observations(sec.get("new_observations", []), max(64, target // 12))
    obs_refs = [str(x) for x in sec.get("observation_refs", []) or []]

    context = {
        "objectives": gravity.get("anchors", []),
        # Requirements are intentionally not duplicated here.  Their exact, complete
        # representation is the top-level source-authority field restored below.
        "intents": _compact_intent_rows(out.get("intents", []), meaning_limit=max(56, target // 14), quote_limit=max(40, target // 20)),
        "decision": _distill_structured(sec.get("decision_state"), max(80, target // 10)) if sec.get("decision_state") is not None else None,
    }
    context = {k: v for k, v in context.items() if v not in (None, [], {}, "")}

    packet = {
        "version": out.get("version", 3),
        "authority": deepcopy(out.get("authority") or authority_plane_snapshot()),
        "context_stage": "AXIOMATIC",
        "instruction": _distill_text(out.get("instruction", ""), max(72, target // 12)),
        "request": floor["request"],
        "request_sha256": floor["request_sha256"],
        "task_requirements": deepcopy(floor["task_requirements"]),
        "task_context_rule": COMPACT_TASK_CONTEXT_RULE,
        "objective_invariants": deepcopy(floor["objective_invariants"]),
        "proof_carrying_improvement": deepcopy(out.get("proof_carrying_improvement", {})),
        "distilled_context": context,
        "attachments": {
            "inventory": list((out.get("attachments") or {}).get("inventory", [])),
            "media": deepcopy((out.get("attachments") or {}).get("media", [])),
        } if isinstance(out.get("attachments"), dict) else {},
        "references": deepcopy(out.get("references", {})),
        "sections": ({
            "observation_refs": obs_refs,
            "new_observations": observations,
        } if obs_refs or observations else {}),
        "context_transformations": [{
            "section": "packet",
            "representation": "axiomatic",
            "reason": "context_budget_non_authority_only",
            "source_sha256": _sha256_value(out),
        }],
    }
    if out.get("parameters"):
        packet["parameters"] = _distill_structured(out.get("parameters"), max(72, target // 12))
    if out.get("budget"):
        packet["budget"] = deepcopy(out.get("budget"))
    return _restore_source_authority(packet, floor)


def _trim_list_tail_for_budget(rows, excess_chars, *, min_keep=0):
    """Remove a tail in one O(n) pass for non-authority derived context only."""
    if not isinstance(rows, list) or len(rows) <= min_keep or excess_chars <= 0:
        return 0
    removed_estimate = 0
    cut = len(rows)
    floor = max(0, int(min_keep))
    while cut > floor and removed_estimate < excess_chars:
        cut -= 1
        try:
            removed_estimate += len(json.dumps(rows[cut], ensure_ascii=False, allow_nan=False)) + 1
        except Exception:
            removed_estimate += len(repr(rows[cut])) + 1
    if cut < len(rows):
        del rows[cut:]
    return removed_estimate


def _shrink_axiomatic(packet, target):
    """Reduce derived context while treating source authority as an immutable floor."""
    floor = _source_authority_floor(packet)
    out = _restore_source_authority(packet, floor)

    if isinstance(out.get("references"), dict):
        refs = out["references"]
        used = _used_reference_aliases(out, set(refs))
        out["references"] = {k: v for k, v in refs.items() if k in used}

    dc = out.get("distilled_context", {}) if isinstance(out.get("distilled_context"), dict) else {}
    current_size = size(out)
    if current_size > target:
        # These are derived views, not the canonical user requirements.
        for key in ("intents", "objectives"):
            if current_size <= target:
                break
            rows = dc.get(key)
            if not isinstance(rows, list) or not rows:
                continue
            _trim_list_tail_for_budget(rows, current_size - target, min_keep=0)
            if not rows:
                dc.pop(key, None)
            current_size = size(out)

    if current_size > target:
        sec = out.get("sections", {}) if isinstance(out.get("sections"), dict) else {}
        observations = sec.get("new_observations")
        if isinstance(observations, list) and observations:
            _trim_list_tail_for_budget(observations, current_size - target, min_keep=1)
            current_size = size(out)
            if observations and current_size > target:
                sec["new_observations"] = _distill_observations(observations, max(40, target // 20))
                current_size = size(out)

    if size(out) > target and dc.get("decision") is not None:
        dc["decision"] = _distill_structured(dc["decision"], max(48, target // 18))
    if size(out) > target:
        out["authority"] = compact_authority_plane_snapshot()
    if size(out) > target:
        out["instruction"] = _distill_text(out.get("instruction", ""), max(40, target // 20))
        out["task_context_rule"] = OPERATIONAL_CONTRACT_TEXT
    if size(out) > target:
        out.pop("parameters", None)
        out.pop("references", None)
    if size(out) > target:
        out.pop("context_transformations", None)
        if isinstance(out.get("distilled_context"), dict):
            for key in list(out["distilled_context"]):
                if out["distilled_context"].get(key) in (None, [], {}, ""):
                    out["distilled_context"].pop(key, None)
        if isinstance(out.get("sections"), dict) and not out["sections"]:
            out.pop("sections", None)
    if size(out) > target:
        out["instruction"] = _distill_text(out.get("instruction", ""), max(24, target // 28))
        out["task_context_rule"] = "User source is the immutable destination; derived cognition may only change means."

    out = _restore_source_authority(out, floor)
    actual = size(out)
    if actual > target:
        out.setdefault("source_authority", {})["budget_overrun_due_to_authority_floor"] = True
        out["source_authority"]["authority_floor_chars"] = size({
            "request": floor["request"],
            "request_sha256": floor["request_sha256"],
            "task_requirements": floor["task_requirements"],
            "objective_invariants": floor["objective_invariants"],
        })
        out["source_authority"]["nominal_context_target_chars"] = int(target)
    return out


def enforce_context_budget(packet, target):
    """Fit only runtime-owned context; never fit by changing the user's destination.

    The old implementation could truncate the request and drop requirement rows in the
    name of a hard context cap.  That gave an internal resource heuristic de-facto
    authority over the user.  The new rule is monotonic: budget pressure can delete or
    distill derived context, but the exact request and all active requirements survive.
    """
    target = max(1200, _positive_int(target, "context budget target"))
    floor = _source_authority_floor(packet)
    out = _restore_source_authority(deepcopy(packet), floor)
    out.setdefault("authority", authority_plane_snapshot())
    out.setdefault("context_stage", "PRIME")
    out.setdefault("context_transformations", [])

    if "references" in out:
        refs = out.get("references", {}) if isinstance(out.get("references"), dict) else {}
        used = _used_reference_aliases(out, set(refs))
        out["references"] = {k: v for k, v in refs.items() if k in used} if used else {}

    if size(out) <= target:
        return out

    out["context_stage"] = "SYNTHESIZED"
    # Never rewrite request/task_requirements here. Only derived cognition is compacted.
    out["instruction"] = _distill_text(out.get("instruction", ""), min(700, max(140, target // 4)))
    out["intents"] = _compact_intent_rows(
        out.get("intents", []), meaning_limit=max(72, target // 9), quote_limit=max(48, target // 14),
    )

    sections = out.get("sections")
    if isinstance(sections, dict):
        if sections.get("goal_gravity"):
            sections["goal_gravity"] = _compact_goal_gravity(sections["goal_gravity"], meaning_limit=max(72, target // 10))
        if isinstance(sections.get("new_observations"), list):
            sections["new_observations"] = _distill_observations(sections["new_observations"], max(72, target // 10))
        if sections.get("decision_state") is not None:
            sections["decision_state"] = {
                "distilled_state": _distill_structured(sections.get("decision_state"), max(96, target // 8)),
                "semantic_state": "distilled",
            }
        for key in list(sections):
            if key in {"goal_gravity", "new_observations", "observation_refs", "decision_state"}:
                continue
            if size(out) <= target:
                break
            sections[key] = {
                "distilled_state": _distill_structured(sections.get(key), max(72, target // 12)),
                "semantic_state": "distilled",
            }
            _note_transformation(out, f"sections.{key}", "distilled", source=packet.get("sections", {}).get(key))

    if size(out) > target and out.get("entry_index"):
        original_index = deepcopy(out["entry_index"])
        out["entry_index"] = [
            {k: deepcopy(row.get(k)) for k in ("ref", "id", "kind", "status") if row.get(k) is not None}
            for row in original_index if isinstance(row, dict)
        ]
        _note_transformation(out, "entry_index", "distilled", source=original_index)
    if size(out) > target and isinstance(out.get("capabilities"), list):
        out["capabilities"] = _compact_capabilities(out["capabilities"], identities_only=True)
        _note_transformation(out, "capabilities", "distilled", source=packet.get("capabilities"))
    if size(out) > target and isinstance(out.get("parameters"), dict) and out["parameters"]:
        original_parameters = deepcopy(out["parameters"])
        out["parameters"] = {
            "distilled_parameters": _distill_structured(original_parameters, max(96, target // 8)),
            "semantic_state": "distilled",
            "source_sha256": _sha256_value(original_parameters),
        }
        _note_transformation(out, "parameters", "distilled", source=original_parameters)
    if "references" in out:
        refs = out.get("references", {}) if isinstance(out.get("references"), dict) else {}
        used = _used_reference_aliases(out, set(refs))
        out["references"] = {k: v for k, v in refs.items() if k in used}

    out = _restore_source_authority(out, floor)
    if size(out) <= target:
        return out

    axiomatic = _shrink_axiomatic(_axiomatic_context(out, target), target)
    axiomatic = _restore_source_authority(axiomatic, floor)
    if size(axiomatic) > target:
        axiomatic.setdefault("source_authority", {})["budget_overrun_due_to_authority_floor"] = True
        axiomatic["source_authority"]["nominal_context_target_chars"] = int(target)
    return axiomatic


REFERENCE_LISTS = {
    "intent_refs", "required_intents", "world_refs", "input_refs", "evidence_refs",
    "exact_refs", "unresolved", "contradiction_refs", "observation_refs",
    "frame_change_source_refs", "parent_ids", "parent_observation_sha256",
}
REFERENCE_VALUES = {"source_ref", "invalidates_world", "subject_ref", "origin_ref"}

def normalize_result(value, references):
    # Only explicit schema reference fields are mapped. User text and literal
    # quotes remain untouched. Alias collisions are rejected instead of silently
    # overwriting one intent effect with another.
    def ref(value):
        return references.get(value, value) if isinstance(value, str) else value

    def visit(value):
        if isinstance(value, list):
            return [visit(v) for v in value]
        if not isinstance(value, dict):
            return value
        out = {}
        for key, item in value.items():
            if key == "intent_effects" and isinstance(item, dict):
                effects = {}
                sources = {}
                for alias, effect in item.items():
                    resolved = ref(alias)
                    if resolved in effects and alias != sources[resolved]:
                        raise ValueError(
                            f"multiple intent_effect aliases resolve to the same reference: {sources[resolved]!r}, {alias!r} -> {resolved!r}"
                        )
                    effects[resolved] = visit(effect)
                    sources[resolved] = alias
                out[key] = effects
            elif key in REFERENCE_LISTS and isinstance(item, (list, tuple)):
                out[key] = [ref(v) for v in item]
            elif key in REFERENCE_VALUES:
                out[key] = ref(item)
            elif key in {"parameters", "structure", "design_space", "method_request", "revision", "observation", "creative_state", "changes", "answer", "output"}:
                out[key] = deepcopy(item)
            else:
                out[key] = visit(item)
        return out
    return visit(deepcopy(value))

def _path_parts(selector):
    return [part for part in str(selector).split(".") if part]

def _path_exists(value, parts):
    current = value
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, list) and str(part).isdigit():
            index = int(part)
            if index < 0 or index >= len(current):
                return False
            current = current[index]
        else:
            return False
    return True

def _path_get(value, parts):
    current = value
    for part in parts:
        if isinstance(current, dict):
            current = current[part]
        elif isinstance(current, list) and str(part).isdigit():
            current = current[int(part)]
        else:
            raise KeyError(".".join(parts))
    return deepcopy(current)

def _path_set(target, parts, value):
    if not parts:
        return
    current = target
    for i, part in enumerate(parts):
        last = i == len(parts) - 1
        next_is_index = (not last) and str(parts[i + 1]).isdigit()

        if isinstance(current, dict):
            if last:
                current[part] = deepcopy(value)
                return
            expected = list if next_is_index else dict
            child = current.get(part)
            if not isinstance(child, expected):
                child = [] if next_is_index else {}
                current[part] = child
            current = child
            continue

        if isinstance(current, list) and str(part).isdigit():
            index = int(part)
            while len(current) <= index:
                current.append(None)
            if last:
                current[index] = deepcopy(value)
                return
            expected = list if next_is_index else dict
            child = current[index]
            if not isinstance(child, expected):
                child = [] if next_is_index else {}
                current[index] = child
            current = child
            continue

        raise ValueError(f"cannot materialize visibility path component {part!r}")

def _path_delete(value, parts):
    if not parts:
        return
    current = value
    for part in parts[:-1]:
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, list) and str(part).isdigit():
            index = int(part)
            if index < 0 or index >= len(current):
                return
            current = current[index]
        else:
            return
    final = parts[-1]
    if isinstance(current, dict):
        current.pop(final, None)
    elif isinstance(current, list) and str(final).isdigit():
        index = int(final)
        if 0 <= index < len(current):
            current.pop(index)

def _redact_literals(value, literals):
    """Redact literal data values without mutating protocol/schema keys."""
    if isinstance(value, str):
        out = value
        for literal in literals:
            if literal:
                out = out.replace(str(literal), "[REDACTED]")
        return out
    if isinstance(value, list):
        return [_redact_literals(v, literals) for v in value]
    if isinstance(value, tuple):
        return tuple(_redact_literals(v, literals) for v in value)
    if isinstance(value, dict):
        return {k: _redact_literals(v, literals) for k, v in value.items()}
    return value

def apply_visibility_partition(packet, partition):
    """Restrict one work item's optional payload while preserving its authority envelope.

    ``visible``/``hidden`` are structural dot paths; literal redaction is handled
    only by ``redact_literals``. An explicitly empty visible list means no
    optional payload, not full visibility. Authority and objective relation remain
    part of the scoped work item.
    """
    if partition is None:
        return packet
    if not isinstance(partition, dict):
        raise ValueError("visibility partition must be an object")

    scope_id = partition.get("id")
    if "visible" in partition:
        visible = list(partition.get("visible") or [])
    else:
        visible = ["*"]
    hidden = list(partition.get("hidden", []) or [])
    redact_literals = list(partition.get("redact_literals", []) or [])

    original = deepcopy(packet)
    broad = any(v in {"*", "..."} for v in visible)
    if broad:
        filtered = deepcopy(original)
    else:
        mandatory = (
            "version", "profile", "authority", "instruction", "parameters", "references", "budget",
            "request_sha256", "task_context_rule", "objective_invariants",
        )
        filtered = {k: deepcopy(original[k]) for k in mandatory if k in original}
        for selector in visible:
            parts = _path_parts(selector)
            if parts and _path_exists(original, parts):
                _path_set(filtered, parts, _path_get(original, parts))

        # Goal semantics stay visible by default because they express the live
        # destination, but a scope can explicitly blind the whole goal field.
        # Hiding a nested goal field does not accidentally remove the whole goal.
        goal_path = ["sections", "goal_gravity"]
        hide_whole_goal = any(str(selector) in {"sections", "sections.goal_gravity"} for selector in hidden)
        if not hide_whole_goal and _path_exists(original, goal_path):
            _path_set(filtered, goal_path, _path_get(original, goal_path))

    unmatched_hidden = []
    for selector in hidden:
        parts = _path_parts(selector)
        if parts and _path_exists(filtered, parts):
            _path_delete(filtered, parts)
        elif parts and _path_exists(original, parts):
            # Already excluded by the allowlist.
            pass
        else:
            unmatched_hidden.append(str(selector))

    # The peer-authority envelope is reinserted before literal redaction so
    # the declaration always survives scoping, and secrets cannot be resurrected
    # after redaction.
    for key in ("authority", "request_sha256", "task_context_rule", "objective_invariants"):
        if key in original:
            filtered[key] = deepcopy(original[key])

    filtered = _redact_literals(filtered, redact_literals)

    if isinstance(filtered.get("references"), dict):
        refmap = filtered["references"]
        probe = deepcopy(filtered)
        probe.pop("references", None)
        used = _used_reference_aliases(probe, set(refmap))
        filtered["references"] = {alias: ref for alias, ref in refmap.items() if alias in used}

    before_hash = hashlib.sha256(
        _stable_json(original).encode("utf-8")
    ).hexdigest()
    delivered_payload_hash = hashlib.sha256(
        _stable_json(filtered).encode("utf-8")
    ).hexdigest()

    def selector_digest(values):
        return hashlib.sha256(
            json.dumps(list(values), ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()

    filtered["visibility_enforcement"] = {
        "scope_id_sha256": hashlib.sha256(str(scope_id).encode("utf-8")).hexdigest(),
        "mode": "runtime_context_filter",
        "visible_selector_count": len(visible),
        "hidden_selector_count": len(hidden),
        "visible_selectors_sha256": selector_digest(visible),
        "hidden_selectors_sha256": selector_digest(hidden),
        "literal_redactions": len(redact_literals),
        "unmatched_hidden_selector_count": len(unmatched_hidden),
        "unmatched_hidden_selectors_sha256": selector_digest(unmatched_hidden),
        "source_context_sha256": before_hash,
        "delivered_payload_sha256": delivered_payload_hash,
        "objective_contract_preserved": bool(filtered.get("objective_invariants")),
        "goal_semantics_visible": bool(
            isinstance(filtered.get("sections"), dict) and filtered["sections"].get("goal_gravity")
        ),
    }
    return filtered

