"""Assembled semantic invocation request.

The exact user contract travels with cognition context and observed execution
state. Adapters may translate the request without inventing a higher authority
ordering inside Jigaewol.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass

from jigaewol_runtime.bridge.authority_plane import authority_plane_snapshot, is_peer_plane
from jigaewol_runtime.bridge.host_contract import render_host_constitution


@dataclass(frozen=True)
class SemanticRequest:
    work_id: str
    turn_id: str
    task_id: str
    operation: str
    intent_refs: tuple[str, ...]
    world_refs: tuple[str, ...]
    input_refs: tuple[str, ...]
    expected_output_schema: str
    expected_effects: tuple[str, ...]
    evidence_requirements: tuple[str, ...]
    permission_class: str
    cost_hint: float
    operator_ids: tuple[str, ...]
    language_refs: tuple[str, ...]
    trigger_refs: tuple[str, ...]
    visibility_scope: str | None
    attachment_refs: tuple[str, ...]
    media: tuple[dict, ...]
    context: dict
    authority_plane: dict
    host_contract: str
    transport_contract: dict
    prompt_layers: tuple[dict, ...]

    def to_dict(self) -> dict:
        return asdict(self)


def build_semantic_request(work) -> SemanticRequest:
    """Assemble the complete semantic request before an adapter/model sees it."""
    context = deepcopy(getattr(work, "context", {}) or {})
    plane = deepcopy(context.get("authority"))
    if not is_peer_plane(plane):
        plane = authority_plane_snapshot()
        context["authority"] = deepcopy(plane)

    contract = render_host_constitution()
    exact_user_text = str(context.get("exact_user_text") or context.get("current_user_message") or "")
    transport = {
        "relation": "exact_user_source_with_observed_execution_state",
        "user_contract": exact_user_text,
        "user_contract_source": "exact_current_user_text" if exact_user_text else "absent_not_invented",
        "invented_generic_user_contract_forbidden": True,
        "semantic_result_acceptance": "first_class_cognition_before_execution_projection",
        "execution_projection": "record only actually observed executable availability",
    }
    layers_list = []
    if exact_user_text:
        layers_list.append({"kind": "exact_user_source", "content": exact_user_text})
    layers_list.extend((
        {"kind": "host_constitution", "content": contract},
        {"kind": "authority_plane", "content": deepcopy(plane)},
        {"kind": "cognition_context", "content": deepcopy(context)},
    ))
    layers = tuple(layers_list)
    attachments = context.get("attachments") if isinstance(context.get("attachments"), dict) else {}
    media = tuple(deepcopy(x) for x in attachments.get("media", []) if isinstance(x, dict))
    attachment_refs = tuple(
        str(x.get("host_ref")) for x in media if isinstance(x.get("host_ref"), str) and x.get("host_ref")
    )

    return SemanticRequest(
        work_id=str(work.work_id),
        turn_id=str(work.turn_id),
        task_id=str(work.task_id),
        operation=str(work.operation),
        intent_refs=tuple(work.intent_refs),
        world_refs=tuple(work.world_refs),
        input_refs=tuple(work.input_refs),
        expected_output_schema=str(work.expected_output_schema),
        expected_effects=tuple(work.expected_effects),
        evidence_requirements=tuple(work.evidence_requirements),
        permission_class=str(work.permission_class),
        cost_hint=float(work.cost_hint),
        operator_ids=tuple(getattr(work, "operator_ids", ()) or ()),
        language_refs=tuple(getattr(work, "language_refs", ()) or ()),
        trigger_refs=tuple(getattr(work, "trigger_refs", ()) or ()),
        visibility_scope=getattr(work, "visibility_scope", None),
        attachment_refs=attachment_refs,
        media=media,
        context=context,
        authority_plane=deepcopy(plane),
        host_contract=contract,
        transport_contract=transport,
        prompt_layers=layers,
    )
