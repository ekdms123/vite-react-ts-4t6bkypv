"""Connect executed structure searches, actual samples and successive reframing."""
from copy import deepcopy
import json

from jigaewol_runtime.exploration.space import compile_space


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)


def at(structure, path):
    if type(path) is not list or not path:
        raise ValueError("exploration path must be a nonempty JSON path list")
    for key in path:
        if type(structure) is dict and type(key) is str and key in structure:
            structure = structure[key]
        elif type(structure) is list and type(key) is int and 0 <= key < len(structure):
            structure = structure[key]
        else:
            raise KeyError(key)
    return structure


def hinge_in(hinge, sample):
    required = {"quote", "effect"}
    if not isinstance(hinge, dict) or not required <= set(hinge):
        raise ValueError("explored material needs hinge fields quote,effect")
    if any(not isinstance(hinge[k], str) or not hinge[k].strip() for k in required):
        raise ValueError("hinge needs an exact sample quote and its concrete effect")
    if hinge["quote"] not in sample:
        raise ValueError("hinge quote must occur in the current sample")
    return deepcopy(hinge)


class ExplorationMixin:
    def _compile_exploration(self, runtime, payload):
        supplied = payload.get("design_space")
        previous = runtime.extensions.get("exploration")
        if supplied is None:
            basis = payload.get("method_basis")
            if basis is not None:
                run = runtime.extensions.get("method_runs", {}).get(basis)
                if not run or run.get("result", {}).get("status") != "ok" or run.get("interpretation", {}).get("next") != "use":
                    raise ValueError("method_basis needs an actual successful interpreted computation")
                if previous:
                    raise ValueError("existing exploration keeps protected structures; rebase its design_space using the new method findings")
                runtime.extensions["method_basis"] = basis
                return
            if previous:
                raise ValueError("continuing an existing exploration needs a task-specific design_space")
            return
        if not isinstance(supplied, dict):
            raise ValueError("design_space must be an object")
        spec = deepcopy(supplied)
        base_from = spec.pop("base_from", None)
        if base_from is not None:
            if not previous or "base" in spec:
                raise ValueError("base_from needs a previous exploration and replaces base")
            sources = [previous["baseline"], *previous["variants"]]
            source = next((v for v in sources if v["id"] == base_from), None)
            if source is None:
                raise ValueError("base_from must name a current executed variant")
            spec["base"] = deepcopy(source["structure"])
        guards = deepcopy(runtime.extensions.get("exploration_guards", []))
        # Earlier fixed values survive later rounds, even if the host omits them.
        paths = spec.setdefault("protected_paths", [])
        if not isinstance(paths, list):
            raise ValueError("protected_paths must be a list")
        for guard in guards:
            if guard["path"] not in paths:
                paths.append(deepcopy(guard["path"]))
            try:
                value = at(spec["base"], guard["path"])
            except (KeyError, IndexError, TypeError) as exc:
                raise ValueError("retain protected values when changing the representation") from exc
            if canonical(value) != canonical(guard["value"]):
                raise ValueError("later exploration cannot replace a protected value")
        compiled = compile_space(spec)
        if not compiled["variants"]:
            raise ValueError("design_space produced no changed structure; revise the moves")
        for path in paths:
            if not any(g["path"] == path for g in guards):
                guards.append({"path": deepcopy(path), "value": deepcopy(at(spec["base"], path))})
        compiled["round"] = (previous["round"] + 1) if previous else 1
        compiled["base_from"] = base_from
        compiled["protected_paths"] = deepcopy(paths)
        compiled["learning"] = deepcopy(runtime.extensions.get("exploration_learning"))
        runtime.extensions["exploration_guards"] = guards
        runtime.extensions["exploration"] = compiled
        runtime.extensions.setdefault("exploration_history", []).append({
            "round": compiled["round"], "base_from": base_from,
            "base_hash": compiled["baseline"]["structure_hash"],
            "variant_hashes": [v["structure_hash"] for v in compiled["variants"]],
            "learning": deepcopy(compiled["learning"])})
        runtime.ledger.add_observation({"exploration": compiled,
            "basis": "executed_structure_combinations_not_quality_measurement"})
        # Selection is rebuilt from the newly explored material.
        for key in ("selected", "candidates", "candidate_choice", "candidates_to_rewrite", "carry_forward"):
            runtime.extensions.pop(key, None)

    def _bind_exploration_candidate(self, runtime, candidate):
        space = runtime.extensions.get("exploration")
        if not space:
            if "explore_variant_id" in candidate:
                raise ValueError("explore_variant_id needs an executed design space")
            basis = runtime.extensions.get("method_basis")
            if basis:
                if candidate.get("method_job_id") != basis:
                    raise ValueError("candidate must reference the used actual method_basis job")
                candidate["hinge"] = hinge_in(candidate.get("hinge"), candidate["sample"])
            return
        variants = [space["baseline"], *space["variants"]]
        variant = next((v for v in variants if v["id"] == candidate.get("explore_variant_id")), None)
        if variant is None:
            raise ValueError("candidate must reference a current executed explore_variant_id")
        if "structure" in candidate and canonical(candidate["structure"]) != canonical(variant["structure"]):
            raise ValueError("candidate structure differs from its executed variant")
        candidate["structure"] = deepcopy(variant["structure"])
        candidate["exploration_round"] = space["round"]
        candidate["hinge"] = hinge_in(candidate.get("hinge"), candidate["sample"])

    def _check_exploration_guards(self, runtime, structure):
        for guard in runtime.extensions.get("exploration_guards", []):
            try:
                same = canonical(at(structure, guard["path"])) == canonical(guard["value"])
            except (KeyError, IndexError, TypeError):
                same = False
            if not same:
                raise ValueError("candidate edits changed a protected exploration value")

    def _check_exploration_candidates(self, runtime, candidates):
        if not runtime.extensions.get("exploration"):
            return
        ids = [c["explore_variant_id"] for c in candidates]
        if len(ids) != len(set(ids)) or "baseline" not in ids or len(ids) < 2:
            raise ValueError("realize the strong baseline and at least one distinct executed variant")
        if len({c["sample"].strip() for c in candidates}) != len(candidates):
            raise ValueError("different explored structures need different actual samples")

    def _carry_explored_material(self, runtime, payload, answer):
        selected = runtime.extensions.get("selected") or {}
        if "explore_variant_id" not in selected and "method_job_id" not in selected:
            return
        carry = payload.get("carry_forward")
        required = {"source_quote", "delivery_quote", "effect"}
        if not isinstance(carry, dict) or not required <= set(carry):
            raise ValueError("selected exploration needs carry_forward fields source_quote,delivery_quote,effect")
        if any(not isinstance(carry[k], str) or not carry[k].strip() for k in required):
            raise ValueError("carry_forward needs literal material and a concrete effect")
        if carry["source_quote"] != selected["hinge"]["quote"]:
            raise ValueError("carry_forward must refer to the selected sample's hinge")
        if carry["delivery_quote"] not in str(answer):
            raise ValueError("carry_forward delivery quote must occur in the final material")
        runtime.extensions["carry_forward"] = {**deepcopy(carry),
            "round": selected.get("exploration_round"), "variant_id": selected.get("explore_variant_id"),
            "method_job_id": selected.get("method_job_id"),
            "basis": "literal_material_lineage_not_semantic_certification"}

    def _next_exploration(self, runtime, node, payload, answer):
        learning = payload.get("next_exploration")
        if learning is None:
            return
        required = {"observation_quote", "next_question", "expected_difference"}
        if not isinstance(learning, dict) or not required <= set(learning):
            raise ValueError("next_exploration needs observation_quote,next_question,expected_difference")
        if any(not isinstance(learning[k], str) or not learning[k].strip() for k in required):
            raise ValueError("state the observed material and the new question it opens")
        if learning["observation_quote"] not in str(answer):
            raise ValueError("new exploration must start from a quote in the current actual material")
        target = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "closure.check"), None)
        if target is None:
            raise ValueError("new exploration needs a remaining delivery boundary")
        runtime.extensions["exploration_learning"] = deepcopy(learning)
        steps = [self._node(runtime, "host_semantic", "cognition.compile", intents=runtime.program.objective_refs),
                 self._node(runtime, "host_semantic", node.operation, intents=runtime.program.objective_refs),
                 target]
        self._replace_pending(runtime, (target.node_id,), steps, count_rewrite=False, required=True)
