from __future__ import annotations

"""Deferred bridge: JIGAEWOL emits work and the current host executes it."""

from jigaewol_runtime.bridge.core import JigaewolRuntime, JigaewolView
from pathlib import Path

from jigaewol_runtime.capabilities.manifest import normalize_capabilities
from jigaewol_runtime.capabilities.acquisition import AcquisitionLedger, assess_capability_need


class GeneralChatDriver:
    def __init__(self, state_dir, *, session_id="chat", runtime=None, capabilities=None, require_gate=False):
        self.runtime = runtime or JigaewolRuntime(state_dir, session_id=session_id)
        self.acquisitions = AcquisitionLedger(Path(state_dir) / "capability_acquisitions.json")
        self._bound_capabilities = ()
        self._require_gate = bool(require_gate)
        self._capabilities_explicitly_bound = capabilities is not None
        if capabilities is not None:
            self.bind_capabilities(capabilities)

    def bind_capabilities(self, capabilities):
        """Bind the HOST capabilities verified as callable in the current chat runtime.

        This binding is intentionally in-memory: a restarted host session must
        re-assert its current exposures instead of inheriting stale connection
        claims from persisted JIGAEWOL cognition.
        """
        self._bound_capabilities = tuple(normalize_capabilities(capabilities))
        self._capabilities_explicitly_bound = True
        return self.capability_snapshot()

    def capability_snapshot(self):
        return tuple(dict(cap) for cap in self._bound_capabilities)

    def assess_capability_need(self, need):
        """Report whether the current verified HOST surface satisfies a free-text need."""
        return assess_capability_need(need, self.capability_snapshot())

    def acquisition_snapshot(self):
        return self.acquisitions.snapshot()

    def activate(self, *, deep=False):
        result = dict(self.runtime.activate(deep=deep))
        result["host_capabilities_bound"] = tuple(cap["id"] for cap in self._bound_capabilities)
        result["host_capability_connection_scope"] = (
            "explicit_current_host_binding" if self._capabilities_explicitly_bound else "not_bound_in_this_host_runtime"
        )
        return result

    def _begin_core(self, message, **kwargs) -> JigaewolView:
        if "capabilities" not in kwargs:
            kwargs["capabilities"] = list(self.capability_snapshot())
        if "capability_acquisitions" not in kwargs:
            kwargs["capability_acquisitions"] = list(self.acquisition_snapshot())
        return self.runtime.begin(message, **kwargs)

    def begin(self, message, **kwargs) -> JigaewolView:
        if self._require_gate:
            raise RuntimeError(
                "direct GeneralChatDriver.begin() is disabled for this OperatingFoundation; "
                "EVERY USER MESSAGE must enter through PerTurnGate/OperatingFoundation.ingress()"
            )
        return self._begin_core(message, **kwargs)

    def _begin_from_gate(self, message, **kwargs) -> JigaewolView:
        """Internal gate-only ingress path.

        OperatingFoundation creates its driver with ``require_gate=True`` so
        ordinary-chat code cannot accidentally skip durable ingress evidence.
        """
        return self._begin_core(message, **kwargs)

    @staticmethod
    def next_work(view: JigaewolView):
        return tuple(view.next_work)

    @staticmethod
    def compact_status(view: JigaewolView) -> dict:
        """Return orchestration status without serializing the full context packet."""
        return {
            "turn_id": view.turn_id,
            "phase": view.phase,
            "pending_count": len(view.next_work),
            "pending": tuple(
                {
                    "work_id": work.work_id,
                    "executor": work.executor,
                    "operation": work.operation,
                }
                for work in view.next_work
            ),
            "capabilities": tuple(view.capabilities),
        }

    def advance_to_boundary(self, view: JigaewolView) -> JigaewolView:
        """Resume local execution until real HOST work or closure is reached.

        A work-phase view with no pending work is not a delivery boundary.  It is
        resumed immediately; returning the same empty work state is treated as a
        no-progress invariant failure rather than silently yielding to the user.
        """
        current = view
        while current.phase == "work" and not current.next_work:
            before = (current.phase, current.turn_id)
            resumed = self.resume(current.turn_id)
            if resumed.phase == "work" and not resumed.next_work and (resumed.phase, resumed.turn_id) == before:
                raise RuntimeError(
                    "JIGAEWOL made no progress while resuming an empty work state; "
                    "keep the turn resumable and report the actual failure"
                )
            current = resumed
        return current

    def submit(self, work, result) -> JigaewolView:
        return self.runtime.submit_work(work, result)

    def fail(self, work, error) -> JigaewolView:
        return self.runtime.fail_work(work.turn_id, work.work_id, error)

    def resume(self, turn_id) -> JigaewolView:
        return self.runtime.resume(turn_id)

    def resume_pending(self):
        """Resume the newest nonterminal turn, rebinding to current HOST exposures when known."""
        turn_id = self.runtime.latest_resumable_turn_id()
        if turn_id is None:
            return None
        if self._capabilities_explicitly_bound:
            self.runtime.rebind_capabilities(turn_id, self.capability_snapshot())
        return self.runtime.resume(turn_id)

    resume_latest = resume_pending

    def read_context(self, turn_id, section):
        return self.runtime.read_context(turn_id, section)

    def arm_access(self, secret):
        return self.runtime.arm_access(secret)

    def disarm_access(self):
        return self.runtime.disarm_access()

    def disable_access(self):
        return self.runtime.disable_access()

    def access_status(self):
        return self.runtime.access_status()
