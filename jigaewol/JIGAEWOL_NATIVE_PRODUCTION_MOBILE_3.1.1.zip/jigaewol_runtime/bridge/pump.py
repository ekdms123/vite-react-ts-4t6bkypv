from __future__ import annotations

from dataclasses import dataclass
import inspect
from concurrent.futures import ThreadPoolExecutor, as_completed

from jigaewol_runtime.bridge.host_contract import build_runtime_schema_registry, validate_semantic_transport
from jigaewol_runtime.bridge.semantic_request import build_semantic_request
from jigaewol_runtime.capabilities.adapters.host_tool import HostToolAdapter
from jigaewol_runtime.capabilities.action_router import HostActionInvocation, requested_action, provider_arguments_without_action
from jigaewol_runtime.capabilities.image_policy_preflight import (
    ImagePolicyPreflight, bind_image_policy_receipt, is_image_generation_work,
)


@dataclass(frozen=True)
class PumpReceipt:
    turn_id: str
    final_phase: str
    steps: int
    operations: tuple[str, ...]
    repair_attempts: int = 0
    repair_successes: int = 0
    repair_failures: int = 0
    reconstructions: int = 0
    horizon_extensions: int = 0


_USE_CONFIGURED_HORIZON = object()


class HostPump:
    """Drive JIGAEWOL work to closure using explicit host adapters.

    This is the single bridge execution engine. The caller supplies a semantic
    handler and tool handlers; successful observations are submitted immediately
    and failures are reconstructed through the runtime when possible.

    ``repair_handler`` receives ``(work, bad_result, exception)`` for host-tool
    failures only. Repair accounting distinguishes attempts, successful repaired
    submissions, failed repair attempts, and runtime reconstructions.
    """

    def __init__(
        self,
        forge,
        *,
        semantic_handler,
        tool_handlers=None,
        action_router=None,
        dynamic_tool_dispatcher=None,
        repair_handler=None,
        max_steps=None,
        adaptive_horizon=True,
        max_horizon_extensions=None,
        absolute_max_steps=None,
        max_parallel=4,
    ):
        if max_steps is not None:
            if isinstance(max_steps, bool) or not isinstance(max_steps, int):
                raise ValueError("max_steps must be an integer or None, not boolean")
            if max_steps < 1:
                raise ValueError("max_steps must be at least 1")
        if not isinstance(adaptive_horizon, bool):
            raise ValueError("adaptive_horizon must be boolean")
        if absolute_max_steps is not None:
            if isinstance(absolute_max_steps, bool) or not isinstance(absolute_max_steps, int):
                raise ValueError("absolute_max_steps must be an integer or None, not boolean")
            if absolute_max_steps < 1:
                raise ValueError("absolute_max_steps must be at least 1")
        if max_steps is not None and absolute_max_steps is not None and absolute_max_steps < max_steps:
            raise ValueError("absolute_max_steps cannot be smaller than max_steps")
        if isinstance(max_parallel, bool) or not isinstance(max_parallel, int) or max_parallel < 1:
            raise ValueError("max_parallel must be a positive integer, not boolean")
        if (max_horizon_extensions is not None and
                (isinstance(max_horizon_extensions, bool) or not isinstance(max_horizon_extensions, int) or max_horizon_extensions < 0)):
            raise ValueError("max_horizon_extensions must be a nonnegative integer or None")
        self.forge = forge
        self.semantic_handler = semantic_handler
        self.tool_handlers = dict(tool_handlers or {})
        if forge is not None and hasattr(forge, "internal_tool_handlers"):
            internal_handlers = dict(forge.internal_tool_handlers() or {})
            overlap = set(self.tool_handlers) & set(internal_handlers)
            if overlap:
                raise ValueError("tool_handlers and forge internal handlers overlap: " + ", ".join(sorted(overlap)))
            self.tool_handlers.update(internal_handlers)
        if action_router is not None:
            action_handlers = action_router.tool_handlers()
            overlap = set(self.tool_handlers) & set(action_handlers)
            if overlap:
                raise ValueError("tool_handlers and action_router overlap: " + ", ".join(sorted(overlap)))
            self.tool_handlers.update(action_handlers)
        self.tool_adapter = HostToolAdapter()
        self.image_policy_preflight = ImagePolicyPreflight.for_runtime()
        self.dynamic_tool_dispatcher = dynamic_tool_dispatcher
        self.repair_handler = repair_handler
        # No total-step ceiling is invented by default. A horizon exists only
        # when the HOST supplies a real resource boundary.
        self.max_steps = max_steps
        self.adaptive_horizon = adaptive_horizon
        self.max_horizon_extensions = max_horizon_extensions
        self.absolute_max_steps = absolute_max_steps
        self.max_parallel = max_parallel

    def _event(self, view, event, payload):
        """Lifecycle hook for compatibility adapters/telemetry."""
        return None

    def _execute(self, work):
        if work.executor == "host_semantic":
            return self.semantic_handler(build_semantic_request(work))
        if work.executor == "host_tool":
            if is_image_generation_work(work):
                image_policy_receipt = self.image_policy_preflight.evaluate(work)
                if not bool(image_policy_receipt.get("host_action_permitted")):
                    raise PermissionError(
                        "IMAGE_POLICY_PREFLIGHT_BLOCKED:" + str(image_policy_receipt.get("reason") or "unknown")
                    )
                work = bind_image_policy_receipt(work, image_policy_receipt)
            cap = work.operation.removeprefix("capability.")
            fn = self.tool_handlers.get(cap) or self.tool_handlers.get(work.operation)
            if fn is None and self.dynamic_tool_dispatcher is not None:
                action = requested_action(dict(getattr(work, "parameters", {}) or {}))
                if action is None:
                    raise LookupError(f"dynamic HOST dispatch for {work.operation} requires explicit host_action")
                invocation = HostActionInvocation(
                    capability_id=cap,
                    action=action,
                    arguments=provider_arguments_without_action(dict(getattr(work, "parameters", {}) or {})),
                    work_id=str(getattr(work, "work_id", "")),
                    turn_id=str(getattr(work, "turn_id", "")),
                    task_id=str(getattr(work, "task_id", "")),
                    context=dict(getattr(work, "context", {}) or {}),
                )
                def fn(_work, _invocation=invocation):
                    result = self.dynamic_tool_dispatcher(_invocation)
                    if isinstance(result, dict) and "output" in result and isinstance(result.get("origin_ref"), str) and result.get("origin_ref", "").strip():
                        return result
                    # The dispatcher callback itself is the actual host execution boundary.
                    # Preserve its raw return as output while attaching invocation provenance;
                    # this does not turn a merely callable capability into a successful one.
                    return {
                        "output": result,
                        "origin_ref": f"dynamic_host_action:{_invocation.capability_id}:{_invocation.action}:{_invocation.work_id}",
                    }
            if fn is None:
                # Registry absence is local evidence only.  If the host exposes a
                # dynamic dispatcher, materialize an open-set invocation even when
                # the planner did not know a provider-specific action vocabulary.
                if self.dynamic_tool_dispatcher is not None:
                    invocation = HostActionInvocation(
                        capability_id=cap, action="discover_execute",
                        arguments={
                            "requested_operation": str(work.operation),
                            **provider_arguments_without_action(dict(getattr(work, "parameters", {}) or {})),
                        },
                        work_id=str(getattr(work, "work_id", "")),
                        turn_id=str(getattr(work, "turn_id", "")),
                        task_id=str(getattr(work, "task_id", "")),
                        context={**dict(getattr(work, "context", {}) or {}), "route_negative_code": "NOT_REGISTERED_IN_TOOL_HANDLER_MAP"},
                    )
                    def fn(_work, _invocation=invocation):
                        result = self.dynamic_tool_dispatcher(_invocation)
                        if isinstance(result, dict) and "output" in result and str(result.get("origin_ref") or "").strip():
                            return result
                        return {"output": result, "origin_ref": f"dynamic_host_discovery:{_invocation.capability_id}:{_invocation.work_id}"}
                else:
                    raise LookupError(f"NOT_REGISTERED_IN_TOOL_HANDLER_MAP:{work.operation}")
            normalized = self.tool_adapter.invoke(work, lambda _op, _work: fn(_work))
            return normalized.as_payload()
        raise LookupError(f"THIS_HOST_EXECUTOR_PATH_UNBOUND:{work.executor}:goal_remains_live")

    def turn(self, message, *, attachments=(), capabilities=(), **begin_kwargs):
        """Route one complete user turn through the strongest available JIGAEWOL boundary.

        When the forge is an OperatingFoundation, ingress is mandatory and is
        used instead of any direct driver begin path.  Lower-level runtimes keep
        the historical ``begin`` contract.
        """
        ingress = getattr(self.forge, "ingress", None)
        if callable(ingress):
            entered = ingress(
                message, attachments=attachments, capabilities=capabilities, **begin_kwargs
            )
            ticket = entered.get("core_ticket") if isinstance(entered, dict) else None
            if ticket is None or not hasattr(ticket, "view"):
                raise RuntimeError("foundation ingress did not return a core ticket/view")
            view = ticket.view
        else:
            view = self.forge.begin(
                message,
                attachments=attachments,
                capabilities=capabilities,
                **begin_kwargs,
            )
        return self.drive(view)

    def _submit(self, view, work, result):
        """Submit across both the modern work-object API and legacy host shims."""
        fn = getattr(self.forge, "submit_work", None)
        if fn is not None:
            try:
                arity = len(inspect.signature(fn).parameters)
            except (TypeError, ValueError):
                arity = 2
            if arity == 2:
                submitted = fn(work, result)
            elif arity == 3:
                submitted = fn(view.turn_id, work.work_id, result)
            else:
                submitted = None
            if isinstance(submitted, dict) and "view" in submitted:
                return submitted["view"]
            if submitted is not None:
                return submitted
        fn = getattr(self.forge, "submit", None)
        if fn is None:
            raise AttributeError("forge exposes neither submit_work nor submit")
        try:
            arity = len(inspect.signature(fn).parameters)
        except (TypeError, ValueError):
            arity = 3
        if arity == 2:
            submitted = fn(work, result)
        else:
            submitted = fn(view.turn_id, work.work_id, result)
        if isinstance(submitted, dict) and "view" in submitted:
            return submitted["view"]
        return submitted

    def _fail(self, view, work, error):
        fn = getattr(self.forge, "fail_work", None)
        if fn is not None:
            try:
                arity = len(inspect.signature(fn).parameters)
            except (TypeError, ValueError):
                arity = 3
            if arity == 2:
                return fn(work, error)
            return fn(view.turn_id, work.work_id, error)
        fn = getattr(self.forge, "fail", None)
        if fn is not None:
            return fn(work, error)
        raise error

    def _attempt_repair(self, view, work, bad_result, error):
        """Return (view, attempted, succeeded, terminal_error)."""
        if self.repair_handler is None or work.executor != "host_tool":
            return view, False, False, error
        attempted = True
        try:
            fixed = self.repair_handler(work, bad_result, error)
        except Exception as repair_exc:
            return view, attempted, False, repair_exc
        if fixed is None:
            return view, attempted, False, error
        try:
            view = self._submit(view, work, fixed)
        except Exception as repair_submit_exc:
            return view, attempted, False, repair_submit_exc
        return view, attempted, True, None

    def drive(self, view, *, max_steps=_USE_CONFIGURED_HORIZON):
        ops = []
        repair_attempts = 0
        repair_successes = 0
        repair_failures = 0
        reconstructions = 0
        steps = 0
        horizon_extensions = 0

        if max_steps is _USE_CONFIGURED_HORIZON:
            # An explicit absolute ceiling without an initial horizon is still
            # a caller-owned resource boundary. With neither value configured,
            # the runtime closes on semantic/task convergence rather than an
            # arbitrary step count.
            horizon = self.max_steps if self.max_steps is not None else self.absolute_max_steps
            adaptive_horizon = self.adaptive_horizon and self.max_steps is not None
            absolute_max_steps = self.absolute_max_steps
        elif max_steps is None:
            horizon = None
            adaptive_horizon = False
            absolute_max_steps = None
        else:
            if isinstance(max_steps, bool) or not isinstance(max_steps, int):
                raise ValueError("max_steps must be an integer or None, not boolean")
            horizon = max_steps
            if horizon < 1:
                raise ValueError("max_steps must be at least 1")
            adaptive_horizon = False
            absolute_max_steps = horizon

        while view.phase == "work":
            if horizon is not None and steps >= horizon:
                extension_allowed = (
                    self.max_horizon_extensions is None
                    or horizon_extensions < self.max_horizon_extensions
                )
                if (
                    adaptive_horizon
                    and extension_allowed
                    and (absolute_max_steps is None or horizon < absolute_max_steps)
                    and hasattr(self.forge, "extend_budget")
                ):
                    horizon_extensions += 1
                    growth = self.max_steps * (2 ** min(horizon_extensions - 1, 4))
                    if absolute_max_steps is not None:
                        growth = min(growth, absolute_max_steps - horizon)
                    if growth <= 0:
                        raise RuntimeError(
                            f"host pump reached the caller-supplied resource ceiling after {steps} steps; "
                            "the active goal remains resumable"
                        )
                    view = self.forge.extend_budget(
                        view.turn_id,
                        additional_nodes=max(8, growth // 4),
                        additional_recompiles=max(1, growth // 64),
                    )
                    horizon += growth
                    continue
                raise RuntimeError(
                    f"host pump reached the host resource ceiling after {steps} steps; "
                    "the active goal remains resumable"
                )

            if not view.next_work:
                before = (view.phase, tuple(getattr(w, "work_id", "") for w in view.next_work))
                resumed = self.forge.resume(view.turn_id)
                after = (resumed.phase, tuple(getattr(w, "work_id", "") for w in resumed.next_work))
                if resumed.phase == "work" and not resumed.next_work and after == before:
                    raise RuntimeError(
                        "host pump detected a no-progress work state; "
                        "the active goal remains resumable and must not be reported as complete"
                    )
                view = resumed
                continue

            batch = list(view.next_work[: self.max_parallel])
            if horizon is not None and steps + len(batch) > horizon:
                batch = batch[: max(1, horizon - steps)]
            ops.extend(w.operation for w in batch)
            steps += len(batch)

            for w in batch:
                self._event(view, "WORK_STARTED", {"work_id": w.work_id, "operation": w.operation})

            outcomes = {}
            if len(batch) > 1:
                with ThreadPoolExecutor(max_workers=min(self.max_parallel, len(batch))) as pool:
                    futures = {pool.submit(self._execute, w): w for w in batch}
                    for fut in as_completed(futures):
                        w = futures[fut]
                        try:
                            outcomes[w.work_id] = (w, fut.result(), None)
                        except Exception as exc:
                            outcomes[w.work_id] = (w, None, exc)
            else:
                w = batch[0]
                try:
                    outcomes[w.work_id] = (w, self._execute(w), None)
                except Exception as exc:
                    outcomes[w.work_id] = (w, None, exc)

            for w in batch:
                _, result, exc = outcomes[w.work_id]
                if exc is not None:
                    continue
                try:
                    view = self._submit(view, w, result)
                    self._event(view, "WORK_COMPLETED", {"work_id": w.work_id, "operation": w.operation})
                except Exception as submit_exc:
                    self._event(
                        view,
                        "WORK_FAILED",
                        {
                            "work_id": w.work_id,
                            "operation": w.operation,
                            "error": f"{type(submit_exc).__name__}: {submit_exc}",
                        },
                    )
                    view, attempted, succeeded, terminal_error = self._attempt_repair(
                        view, w, result, submit_exc
                    )
                    if attempted:
                        repair_attempts += 1
                        if succeeded:
                            repair_successes += 1
                            self._event(
                                view,
                                "WORK_RECOVERED",
                                {"work_id": w.work_id, "operation": w.operation},
                            )
                            continue
                        repair_failures += 1
                    view = self._fail(view, w, terminal_error)
                    reconstructions += 1
                    self._event(
                        view,
                        "WORK_RECONSTRUCTED",
                        {"work_id": w.work_id, "operation": w.operation},
                    )

            for w in batch:
                _, _, exc = outcomes[w.work_id]
                if exc is None:
                    continue
                self._event(
                    view,
                    "WORK_FAILED",
                    {
                        "work_id": w.work_id,
                        "operation": w.operation,
                        "error": f"{type(exc).__name__}: {exc}",
                    },
                )
                view, attempted, succeeded, terminal_error = self._attempt_repair(
                    view, w, None, exc
                )
                if attempted:
                    repair_attempts += 1
                    if succeeded:
                        repair_successes += 1
                        self._event(
                            view,
                            "WORK_RECOVERED",
                            {"work_id": w.work_id, "operation": w.operation},
                        )
                        continue
                    repair_failures += 1
                view = self._fail(view, w, terminal_error)
                reconstructions += 1
                self._event(
                    view,
                    "WORK_RECONSTRUCTED",
                    {"work_id": w.work_id, "operation": w.operation},
                )

        return view, PumpReceipt(
            turn_id=view.turn_id,
            final_phase=view.phase,
            steps=steps,
            operations=tuple(ops),
            repair_attempts=repair_attempts,
            repair_successes=repair_successes,
            repair_failures=repair_failures,
            reconstructions=reconstructions,
            horizon_extensions=horizon_extensions,
        )


class JigaewolHostRunner(HostPump):
    """Compatibility facade backed by the single HostPump execution engine.

    This keeps the historical public API without maintaining a second drive
    loop. ``run(..., max_steps=None)`` preserves the legacy unbounded default.
    """

    def __init__(
        self,
        semantic_handler,
        capability_handlers=None,
        action_router=None,
        grants=(),
        schema_registry=None,
        recovery_handler=None,
        journal=None,
    ):
        self.grants = set(grants)
        self.schemas = schema_registry or build_runtime_schema_registry()
        self.tool_adapter = HostToolAdapter()
        self.recovery_handler = recovery_handler
        self.journal = journal
        self.journal_faults = []

        def repair_handler(work, _bad_result, exc):
            if self.recovery_handler is None:
                return None
            return self.recovery_handler(work, exc)

        super().__init__(
            None,
            semantic_handler=semantic_handler,
            tool_handlers=capability_handlers,
            action_router=action_router,
            repair_handler=repair_handler if recovery_handler is not None else None,
            max_steps=None,
            adaptive_horizon=False,
            absolute_max_steps=None,
            max_parallel=1,
        )

    def _event(self, view, event, payload):
        if self.journal is None:
            return
        try:
            self.journal.append(view.turn_id, view.task_id, event, payload)
        except Exception as exc:
            self.journal_faults.append(
                {
                    "turn_id": getattr(view, "turn_id", ""),
                    "task_id": getattr(view, "task_id", ""),
                    "event": str(event),
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                }
            )

    def _execute(self, work):
        # Keep schema validation for known host-tool results, but reuse HostPump's
        # open-ended routing semantics instead of maintaining a second closed
        # executor vocabulary.
        result = super()._execute(work)
        if work.executor == "host_semantic":
            return validate_semantic_transport(
                result if isinstance(result, dict) else {"answer": result}
            )
        if work.executor == "host_tool":
            return self.schemas.validate(work.expected_output_schema, result)
        return result

    def run(self, forge, view, max_steps: int | None = None):
        previous = self.forge
        self.forge = forge
        try:
            final_view, _receipt = self.drive(view, max_steps=max_steps)
            return final_view
        finally:
            self.forge = previous
