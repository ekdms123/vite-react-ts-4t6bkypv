"""Compact positive host-facing instructions for Jigaewol."""

CORE = (
    "USER > JIGAEWOL > MODEL. Exact current-user source is canonical; working routes are replaceable; "
    "execution/truth claims require observed evidence. "
)

GUIDANCE = {
    "intents.extract": CORE + "Return source-grounded requirements, context, continuation state and a task model. Preserve each materially independent requested outcome as a live requirement and carry its source quote.",
    "cognition.compile": CORE + "Compile the next executable cognition state. Use the current route inventory as starting material and create new representations, tools, branches or runtime actions when they increase reach toward the user outcome. Return steps, route_candidates, frame and stop_condition when useful.",
    "cognition.delta": CORE + "Integrate new observed results into the next work state. Revise, replace or retain frames, routes, representations and executable steps according to their effect on the live user destination. Bind causal changes to exact observation refs.",
    "chat.respond": CORE + "Return the finished user-facing answer and any requirement-to-material links represented by the runtime. Prefer direct task material over runtime commentary.",
    "material.realize": CORE + "Produce the directly usable final result from the current work state and preserve live unresolved material as explicit continuation state.",
    "quality.inspect": CORE + "Inspect the delivered material for goal coverage, evidence binding, mechanism effect, novelty, structural difference and genericity. Feed improvement findings back into the next material revision.",
    "creative.realize": CORE + "Realize the chosen creative mechanisms in the artifact itself and return the directly usable artifact material.",
    "code.realize": CORE + "Produce executable code or file changes grounded in the current work state and observed environment, then return the actual changed material and evidence refs.",
    "research.plan": CORE + "Create task-native search lineages using expert language, community language, slang, multilingual terms, counterexamples, creator/reply/repository graphs and newly observed vocabulary. Expand source lineages until the user outcome has enough evidence or the runtime is waiting on a real external dependency.",
    "research.interpret": CORE + "Integrate observed sources into the current decision state and bind factual claims to their actual refs.",
    "integration.install": CORE + "Materialize the observed integration manifest, record the resulting environment state, and continue into a minimal real execution probe.",
    "worlds.generate": CORE + "Generate alternative task representations that materially change reachable actions, evidence lineages or solution structure.",
    "worlds.realize": CORE + "Realize the selected representation as concrete mechanisms, actions, assumptions, probes and expected effects.",
    "trajectories.propose": CORE + "Return materially distinct candidate outputs or action trajectories that expand the reachable solution space.",
    "trajectories.rewrite": CORE + "Apply the chosen structural and semantic changes to the actual candidate material.",
    "runtime.reconstruct": CORE + "A route has stalled. Preserve the live destination and construct the next executable state by changing representation, route, body, capability composition or runtime structure.",
    "capability.acquire": CORE + "Expand the execution surface by discovering, inspecting, composing, acquiring or building a capability, then record current callability and perform a minimal real probe. Return evidence refs and the next executable state.",
    "feedback.design": CORE + "Define an observation or probe that can materially improve the current choice.",
    "feedback.review": CORE + "Compare candidates using the available observations, goals and working distinctions and return the basis for the next move.",
    "feedback.tool": CORE + "Execute the declared probe with the connected tool and return its actual result and origin.",
    "methods.execute": CORE + "Execute the supplied restricted Python method job and return the actual subprocess result.",
    "methods.interpret": CORE + "Integrate the actual method result with its prediction and update the work state accordingly.",
}
