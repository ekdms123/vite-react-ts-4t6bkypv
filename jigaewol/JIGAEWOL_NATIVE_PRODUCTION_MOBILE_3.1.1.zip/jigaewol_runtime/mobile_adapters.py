"""Actual backend adapters. Configuration records readiness, calls record effects."""
from __future__ import annotations
import json
import os
import sys
import urllib.request
from pathlib import Path
from jigaewol_components.isolated_executor import IsolatedExecutor

def _inside(root, name):
    root = Path(root).resolve()
    path = (root/str(name)).resolve()
    if not path.is_relative_to(root):
        raise ValueError('artifact path escaped task workspace')
    return path

def parameters(request):
    row = request.get('payload') or request
    return row.get('parameters') or row

def file_adapter(request, workspace):
    args = parameters(request)
    operation = request.get('operation') or args.get('operation')
    path = _inside(workspace,args.get('path','artifact.txt'))
    if operation in {'file.read','read'}:
        return {'success':True,'body':path.read_text(),'artifact':str(path)}
    if operation in {'file.write','state:write_artifact','write'}:
        body = args.get('content',args.get('body'))
        if body is None:
            raise ValueError('write action requires actual artifact content')
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(str(body))
        import hashlib
        return {'success':True,'artifact':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    raise ValueError('unknown file action')

def process_adapter(request, workspace):
    args = parameters(request)
    argv = args.get('argv')
    if not isinstance(argv,list) or not argv or not all(isinstance(x,str) for x in argv):
        raise ValueError('process action requires argv array')
    workspace = Path(workspace)
    workspace.mkdir(parents=True,exist_ok=True)
    return IsolatedExecutor(workspace/'.executor').run(workspace,argv,timeout=float(args.get('timeout_seconds',60)),trust_level='reviewed')

def revision_adapter(request,workspace):
    from jigaewol_components.artifact_revision import apply_edits
    args=parameters(request)
    result=apply_edits(args['source_text'],args['edits'])
    path=_inside(workspace,args['path']);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(result['body'])
    return {'success':True,'artifact':str(path),**result}

def public_research_adapter(request,workspace):
    from argparse import Namespace
    from tools.jigaewol_deep_find import execute
    args=parameters(request);output=_inside(workspace,args.get('path','research.json'))
    output.parent.mkdir(parents=True,exist_ok=True)
    result=execute(Namespace(terms=str(args['terms']),terms_file=None,source_message_file=None,
        output=output,alias=list(args.get('aliases',[])),url=list(args.get('urls',[])),
        limit=int(args.get('limit',4)),max_requests=int(args.get('max_requests',18)),
        seconds=float(args.get('seconds',45)),timeout=float(args.get('timeout',6)),
        offline=False,resume=bool(args.get('resume',True))))
    return {'success':result['observed_status']=='evidence_available','artifact':str(output),
            'items':result['sources'],'summary':result['summary'],
            'pending_urls':result['pending_urls'],'continuation_required':result['continuation_required'],
            'additional_spend_usd':0}

def openai_adapter(request, workspace):
    """Optional continuous cognition using a configured Responses API account."""
    from jigaewol_components.execution_cost_policy import optional_paid_api
    optional_paid_api('openai.responses')
    key = os.environ['JIGAEWOL_OPENAI_API_KEY']
    model = os.environ['JIGAEWOL_MODEL']
    instruction = Path(__file__).with_name('mobile_instructions.txt').read_text()
    payload = {'model':model,'instructions':instruction,'input':json.dumps(request,ensure_ascii=False,default=str)}
    req = urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(payload).encode(),
                                 headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=180) as response:
        result = json.load(response)
    texts = [x.get('text','') for item in result.get('output',[]) for x in item.get('content',[]) if x.get('type') == 'output_text']
    if not texts:
        raise ValueError('provider returned no cognition body')
    return '\n'.join(texts)

def tavily_adapter(request, workspace):
    from jigaewol_components.execution_cost_policy import optional_paid_api
    optional_paid_api('tavily.api')
    args = parameters(request)
    query = args.get('query') or args.get('objective')
    if not query:
        raise ValueError('search requires query')
    variants=args.get('queries') or [{'query':str(query),'dialect_id':'observed_followup' if args.get('observed_term') else 'literal'}]
    all_items=[];observations=[]
    for variant in variants:
        payload = {'query':str(variant['query']),'search_depth':'advanced','max_results':int(args.get('max_results',10)),'include_raw_content':True}
        req = urllib.request.Request('https://api.tavily.com/search',data=json.dumps(payload).encode(),
            headers={'Authorization':'Bearer '+os.environ['JIGAEWOL_TAVILY_API_KEY'],'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req,timeout=60) as response:result=json.load(response)
            items=[{**item,'observed_query':variant['query'],'dialect_id':variant.get('dialect_id')} for item in result.get('results',[])]
            all_items.extend(items);observations.append({**variant,'call_observed':True,'source_count':len(items)})
        except Exception as exc:observations.append({**variant,'route_failed':True,'error_type':type(exc).__name__,'error':str(exc)})
    return {'success':any(x.get('call_observed') for x in observations),'items':all_items,'query':query,'provider':'tavily',
            'query_observations':observations,'global_goal_completed':False}

def configured_adapters(state_root=None):
    from jigaewol_components.execution_cost_policy import execution_policy
    policy=execution_policy()
    def file_call(operation):
        return lambda request,workspace:file_adapter({**request,'operation':operation},workspace)
    adapters = {'file.read':file_call('file.read'),'file.write':file_call('file.write'),'process.run':process_adapter,
                'artifact.revise':revision_adapter,'search:public_sources':public_research_adapter}
    if sys.platform == 'emscripten':
        adapters.pop('process.run')
    if policy['paid_api_calls'] and os.environ.get('JIGAEWOL_OPENAI_API_KEY') and os.environ.get('JIGAEWOL_MODEL'):
        adapters['cognition'] = openai_adapter
        def worker_cognition(request,workspace):
            body=openai_adapter(request,workspace)
            Path(workspace).mkdir(parents=True,exist_ok=True)
            artifact=Path(workspace)/'worker_response.txt';artifact.write_text(body)
            return {'success':True,'body':body,'artifact':str(artifact),'provider':'openai.responses','provider_call_observed':True}
        adapters['cognition:worker']=worker_cognition
    if policy['paid_api_calls'] and os.environ.get('JIGAEWOL_TAVILY_API_KEY'):
        adapters['search:web_current'] = tavily_adapter
    if state_root and os.environ.get('JIGAEWOL_ENABLE_BROWSER')=='1':
        from jigaewol_components.durable_cells import PersistentBrowser,browser_readiness
        if browser_readiness()['installed']:
            browser=PersistentBrowser(Path(state_root)/'browser')
            adapters['browser:observe']=browser
            adapters['browser:signed_in_observe']=browser
    return adapters
