"""Provider-neutral container entrypoint with persistent state and dynamic port."""
from __future__ import annotations
import os
import sys
from pathlib import Path

def main():
    state=Path(os.environ.get('JIGAEWOL_STATE','/state'))
    state.mkdir(parents=True,exist_ok=True)
    if os.geteuid()==0:
        uid=int(os.environ.get('JIGAEWOL_UID','10001'))
        os.chown(state,uid,uid);state.chmod(0o700)
        os.setgroups([]);os.setgid(uid);os.setuid(uid)
    os.environ.setdefault('JIGAEWOL_RUNTIME_HOME',str(state/'home'))
    port=int(os.environ.get('PORT','8787'))
    args=[sys.executable,'-m','jigaewol_runtime.mcp_server','--state',str(state/'mobile'),'--host','0.0.0.0','--port',str(port),
          '--token-file',str(state/'mcp_token'),'--user',os.environ.get('JIGAEWOL_USER','owner'),'--worker']
    domain=os.environ.get('RAILWAY_PUBLIC_DOMAIN','')
    public=os.environ.get('JIGAEWOL_PUBLIC_URL') or ('https://'+domain if domain else '')
    if public:args.extend(['--public-url',public])
    for origin in filter(None,os.environ.get('JIGAEWOL_ALLOWED_ORIGINS','https://chatgpt.com,https://chat.openai.com').split(',')):args.extend(['--allow-origin',origin])
    os.execv(sys.executable,args)
if __name__=='__main__':main()
