"""Evidence and effect blackboard."""
