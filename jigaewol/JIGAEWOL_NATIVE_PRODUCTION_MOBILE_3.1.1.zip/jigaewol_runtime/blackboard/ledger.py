"""Reference grounding. A linked citation is not an independently verified claim."""
from dataclasses import dataclass, replace
import json
from jigaewol_runtime.kernel.ids import new_id


@dataclass(frozen=True)
class LedgerEntry:
    entry_id: str
    kind: str
    subject_ref: str | None
    content: object
    evidence_refs: tuple[str, ...] = ()
    exact_spans_or_diffs: tuple[object, ...] = ()
    tool_origin_refs: tuple[str, ...] = ()
    world_refs: tuple[str, ...] = ()
    intent_refs: tuple[str, ...] = ()
    verification_status: str = "unverified"

    @classmethod
    def claim(cls, content, intent_refs=(), evidence_refs=()):
        return cls(new_id("claim"), "claim", None, content, tuple(evidence_refs), intent_refs=tuple(intent_refs))


@dataclass(frozen=True)
class ClaimVerification:
    claim_ref: str
    status: str
    evidence_refs: tuple[str, ...]


class Ledger:
    def __init__(self):
        self._entries = {}

    def append(self, entry):
        if entry.entry_id in self._entries and self._entries[entry.entry_id] != entry:
            raise ValueError("ledger reference conflict")
        self._entries[entry.entry_id] = entry
        return entry.entry_id

    def get(self, ref):
        return self._entries[ref]

    def entries_for_intent(self, intent_id):
        return tuple(e for e in self._entries.values() if intent_id in e.intent_refs)

    def add_source(self, content, origin_refs=()):
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
        return self.append(LedgerEntry(new_id("source"), "source", None, content,
            tool_origin_refs=tuple(origin_refs), verification_status="observed"))

    def add_material(self, content, origin_refs=(), external_refs=()):
        kind = "artifact" if external_refs else "material"
        return self.append(LedgerEntry(new_id(kind), kind, None, content,
            exact_spans_or_diffs=tuple(external_refs), tool_origin_refs=tuple(origin_refs), verification_status="observed"))

    def add_observation(self, content, intent_refs=(), world_refs=()):
        return self.append(LedgerEntry(new_id("observation"), "observation", None, content,
            world_refs=tuple(world_refs), intent_refs=tuple(intent_refs), verification_status="observed"))

    def add_evidence(self, source_ref, start, end):
        source = self.get(source_ref)
        if source.kind not in {"source", "material", "artifact"}:
            raise ValueError("span must refer to a recorded source or material")
        text = str(source.content)
        if isinstance(start, bool) or isinstance(end, bool) or not isinstance(start, int) or not isinstance(end, int) or not 0 <= start < end <= len(text):
            raise ValueError("invalid literal evidence span")
        return self.append(LedgerEntry(new_id("evidence"), "evidence", source_ref, text[start:end],
            exact_spans_or_diffs=((source_ref, start, end),), tool_origin_refs=source.tool_origin_refs,
            verification_status="observed"))

    def add_quote(self, source_ref, quote, occurrence=None):
        from jigaewol_runtime.contract.extraction import locate_quote
        span = locate_quote(str(self.get(source_ref).content), quote, occurrence)
        return self.add_evidence(source_ref, span.start, span.end)

    def add_claim(self, content, evidence_refs, intent_refs):
        refs = tuple(evidence_refs)
        if any(ref not in self._entries or self.get(ref).kind != "evidence" for ref in refs):
            raise ValueError("claim evidence must reference recorded source spans")
        return self.append(LedgerEntry(new_id("claim"), "claim", None, content,
            evidence_refs=refs, intent_refs=tuple(intent_refs), verification_status="linked" if refs else "unverified"))

    def material_reference(self, ref):
        entry = self.get(ref)
        if entry.kind in {"material", "artifact"}:
            return True
        return entry.kind == "evidence" and self.get(entry.subject_ref).kind in {"material", "artifact"}

    def add_effect(self, content, intent_refs, exact_refs, world_refs=()):
        refs = tuple(exact_refs)
        if not str(content).strip() or not refs or any(not self.material_reference(r) for r in refs):
            raise ValueError("effect requires content and existing material or literal material-span references")
        return self.append(LedgerEntry(new_id("effect"), "effect", None, content,
            exact_spans_or_diffs=refs, intent_refs=tuple(intent_refs), world_refs=tuple(world_refs),
            verification_status="observed"))

    def verify_claim(self, ref):
        entry = self.get(ref)
        status = entry.verification_status
        if entry.kind == "claim":
            linked = bool(entry.evidence_refs) and all(self.get(r).kind == "evidence" for r in entry.evidence_refs)
            status = "linked" if linked else "unverified"
            self._entries[ref] = replace(entry, verification_status=status)
        return ClaimVerification(ref, status, entry.evidence_refs)
