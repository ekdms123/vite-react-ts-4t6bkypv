from __future__ import annotations

from jigaewol_runtime.kernel.ids import new_id
from jigaewol_runtime.bridge.host_work import HostWork


def _schema_for(operation: str, executor: str) -> str:
    if operation in {"feedback.design", "feedback.review", "methods.interpret", "cognition.compile", "cognition.delta", "integration.install", "integration.install"}:
        return operation
    if operation == "intents.extract":
        return "intents.result"
    if executor == "host_tool":
        return "capability.result"
    if operation in {"worlds.generate", "worlds.realize"}:
        return "worlds.result"
    if operation in {"trajectories.propose", "trajectories.rewrite"}:
        return "trajectories.result"
    if operation == "research.plan":
        return "research.plan"
    if operation == "research.interpret":
        return "research.interpret"
    if operation in {"chat.respond", "material.realize", "deliver", "creative.realize", "code.realize"}:
        return "material.result"
    return "host.result"


def to_host_work(node, turn_id: str, task_id: str, context_packet=None) -> HostWork:
    work_id = new_id("work")
    return HostWork(
        work_id=work_id, turn_id=turn_id, task_id=task_id,
        executor=node.executor, operation=node.operation,
        intent_refs=node.intent_refs, world_refs=node.world_refs,
        input_refs=node.inputs,
        context_slices=(getattr(context_packet, "rendered", ""),) if context_packet else (),
        expected_output_schema=_schema_for(node.operation, node.executor),
        expected_effects=node.expected_effects,
        evidence_requirements=node.evidence_requirements,
        permission_class=node.permission_class,
        cost_hint=node.cost_estimate,
        operator_ids=getattr(node, "operator_ids", ()),
        language_refs=getattr(node, "language_refs", ()),
        trigger_refs=getattr(node, "trigger_refs", ()),
        visibility_scope=getattr(node, "visibility_scope", None),
        idempotency_key=work_id,
        resume_policy=(
            "reconcile_before_replay"
            if node.executor == "host_tool" and str(getattr(node, "permission_class", "none")) not in {"none", "read"}
            else "safe_replay"
        ),
        parameters=dict(getattr(node, "parameters", {}) or {}),
    )
