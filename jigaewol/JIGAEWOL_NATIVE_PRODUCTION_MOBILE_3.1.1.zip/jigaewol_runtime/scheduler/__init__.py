"""Dependency scheduler."""
