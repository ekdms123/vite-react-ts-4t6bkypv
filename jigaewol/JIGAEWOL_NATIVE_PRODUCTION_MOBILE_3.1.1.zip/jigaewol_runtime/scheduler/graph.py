from __future__ import annotations

from dataclasses import replace


class Scheduler:
    @staticmethod
    def ready(program, ledger=None):
        done = {n.node_id for n in program.nodes if n.status == "done"}
        blocked_by = {n.node_id: set() for n in program.nodes}
        for left, right in program.edges:
            blocked_by.setdefault(right, set()).add(left)
        return tuple(
            n for n in program.nodes
            if n.status == "pending" and blocked_by.get(n.node_id, set()) <= done
        )

    @staticmethod
    def apply_result(program, node_id: str, result_ref: str):
        nodes = tuple(replace(n, status="done", outputs=tuple(n.outputs) + (result_ref,)) if n.node_id == node_id else n for n in program.nodes)
        return replace(program, nodes=nodes)
