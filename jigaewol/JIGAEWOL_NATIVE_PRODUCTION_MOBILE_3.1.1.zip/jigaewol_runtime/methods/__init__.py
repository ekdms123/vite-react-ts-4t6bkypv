"""Host-authored, bounded JSON computation methods."""

from .runner import prepare_job, run_job

__all__ = ["prepare_job", "run_job"]
