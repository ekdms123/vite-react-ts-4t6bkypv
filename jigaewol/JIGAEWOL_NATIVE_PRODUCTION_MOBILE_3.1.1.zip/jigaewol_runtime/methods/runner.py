"""Run small, host-authored and host-reviewed JSON computation functions.

AST validation and restricted builtins are deliberately a narrow data-computation
interface, NOT a security sandbox for hostile Python. Review code before passing
it here. Imports, files, network access and external actions are outside this
interface. Each job runs in a separate interpreter with a per-call time budget;
the host may revise and submit subsequent methods without a total-round ceiling.
"""

import ast
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import time
from tempfile import TemporaryDirectory
import pkgutil


_MAX_SOURCE = None
_MAX_JSON_BYTES = None
_MAX_AST_NODES = None
_REQUIRED_FIELDS = {"id", "purpose", "representation", "source", "entrypoint", "applicability"}
_SAFE_BUILTINS = {
    "abs": abs, "all": all, "any": any, "bool": bool, "dict": dict,
    "enumerate": enumerate, "filter": filter, "float": float,
    "int": int, "isinstance": isinstance, "len": len, "list": list,
    "map": map, "max": max, "min": min, "range": range,
    "reversed": reversed, "round": round, "set": set, "slice": slice,
    "sorted": sorted, "str": str, "sum": sum, "tuple": tuple, "zip": zip,
    "ValueError": ValueError, "TypeError": TypeError, "KeyError": KeyError,
    "IndexError": IndexError, "ArithmeticError": ArithmeticError,
    "ZeroDivisionError": ZeroDivisionError, "AssertionError": AssertionError,
    "Exception": Exception,
}
_METHODS = {
    "append", "extend", "insert", "remove", "pop", "clear", "index",
    "count", "sort", "reverse", "copy", "get", "keys", "values", "items",
    "setdefault", "update", "popitem", "add", "discard", "union",
    "intersection", "difference", "symmetric_difference", "issubset",
    "issuperset", "isdisjoint", "lower", "upper", "casefold", "strip",
    "lstrip", "rstrip", "split", "rsplit", "splitlines", "join", "replace",
    "startswith", "endswith", "partition", "rpartition", "find", "rfind",
    "rindex", "isalpha", "isdigit", "isalnum", "isspace", "isnumeric",
    "isdecimal", "istitle", "islower", "isupper", "title", "capitalize",
    "swapcase", "zfill", "center", "ljust", "rjust", "removeprefix", "removesuffix",
}
_NODES = {
    ast.Module, ast.FunctionDef, ast.arguments, ast.arg, ast.Return,
    ast.Assign, ast.AugAssign, ast.AnnAssign, ast.Expr, ast.Pass, ast.If,
    ast.For, ast.While, ast.Break, ast.Continue, ast.IfExp, ast.Lambda,
    ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp, ast.comprehension,
    ast.Call, ast.keyword, ast.Attribute, ast.Subscript, ast.Slice,
    ast.Name, ast.Load, ast.Store, ast.Del, ast.Delete, ast.Constant,
    ast.JoinedStr, ast.FormattedValue, ast.NamedExpr,
    ast.List, ast.Tuple, ast.Dict, ast.Set, ast.Starred,
    ast.BinOp, ast.UnaryOp, ast.BoolOp, ast.Compare,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow,
    ast.UAdd, ast.USub, ast.Not, ast.And, ast.Or, ast.Invert,
    ast.BitOr, ast.BitAnd, ast.BitXor, ast.LShift, ast.RShift,
    ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE,
    ast.Is, ast.IsNot, ast.In, ast.NotIn,
    ast.Assert, ast.Raise, ast.Try, ast.ExceptHandler,
}


def _json_text(value):
    """Canonical finite JSON with a one-megabyte serialized per-value limit."""
    try:
        # Acyclic check comes before our explicit JSON type walk.
        encoder = json.JSONEncoder(ensure_ascii=False, sort_keys=True,
                                   separators=(",", ":"), allow_nan=False)
        parts, size = [], 0
        for part in encoder.iterencode(value):
            size += len(part.encode("utf-8"))
            if _MAX_JSON_BYTES is not None and size > _MAX_JSON_BYTES:
                raise ValueError("JSON value exceeds the caller-selected transport limit")
            parts.append(part)
        pending = [value]
        while pending:
            item = pending.pop()
            if item is None or type(item) in (str, bool, int):
                continue
            if type(item) is float and math.isfinite(item):
                continue
            if type(item) is list:
                pending.extend(item)
            elif type(item) is dict and all(type(key) is str for key in item):
                pending.extend(item.values())
            else:
                raise ValueError("method input/output must be finite JSON with string object keys")
        return "".join(parts)
    except (TypeError, OverflowError, RecursionError, UnicodeError) as exc:
        raise ValueError("method input/output must be finite, serializable JSON") from exc


def _hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _validate_source(source, entrypoint):
    if _MAX_SOURCE is not None and len(source) > _MAX_SOURCE:
        raise ValueError("method source exceeds the caller-selected source limit")
    if not entrypoint.isidentifier() or "__" in entrypoint:
        raise ValueError("entrypoint must be a plain function name")
    try:
        tree = ast.parse(source, mode="exec")
    except (SyntaxError, RecursionError, ValueError) as exc:
        raise ValueError("method source must be valid Python function definitions") from exc
    if not tree.body or any(type(node) is not ast.FunctionDef for node in tree.body):
        raise ValueError("source top level may contain only function definitions")
    definitions = [node for node in tree.body if node.name == entrypoint]
    if len(definitions) != 1:
        raise ValueError("source must define the entrypoint exactly once")
    args = definitions[0].args
    if len(args.posonlyargs) + len(args.args) != 1 or args.vararg or args.kwarg or args.kwonlyargs:
        raise ValueError("entrypoint must accept exactly one JSON argument")
    nodes = list(ast.walk(tree))
    if _MAX_AST_NODES is not None and len(nodes) > _MAX_AST_NODES:
        raise ValueError("method AST exceeds the caller-selected node limit")
    defined_names = {node.name for node in nodes if isinstance(node, ast.FunctionDef)}
    defined_names.update(node.arg for node in nodes if isinstance(node, ast.arg))
    defined_names.update(node.id for node in nodes if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store))
    allowed_calls = set(_SAFE_BUILTINS) | defined_names
    for node in nodes:
        if type(node) not in _NODES:
            raise ValueError(f"unsupported data-computation syntax: {type(node).__name__}")
        if isinstance(node, ast.Name) and "__" in node.id:
            raise ValueError("dunder names are outside the computation interface")
        if isinstance(node, ast.arg) and ("__" in node.arg or node.annotation is not None):
            raise ValueError("use plain, unannotated function arguments")
        if isinstance(node, ast.FunctionDef):
            if "__" in node.name or node.decorator_list or node.returns is not None or node.type_comment:
                raise ValueError("use plain undecorated functions")
            if getattr(node, "type_params", []):
                raise ValueError("generic type parameters are outside the computation interface")
        if isinstance(node, ast.AnnAssign):
            raise ValueError("use ordinary assignments without annotations")
        if isinstance(node, ast.Constant) and not (node.value is None or type(node.value) in (str, bool, int, float)):
            raise ValueError("constants must be JSON scalar values")
        if isinstance(node, ast.comprehension) and node.is_async:
            raise ValueError("async comprehensions are outside the computation interface")
        if isinstance(node, ast.Attribute):
            if node.attr not in _METHODS or not isinstance(node.ctx, ast.Load):
                raise ValueError("only listed list/dict/set/string methods are available")
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                if node.func.id not in allowed_calls:
                    raise ValueError(f"unsupported computation call: {node.func.id}")
            elif isinstance(node.func, ast.Attribute):
                if node.func.attr not in _METHODS:
                    raise ValueError("unsupported data method")
            else:
                raise ValueError("calls must name a computation function or listed data method")
    return tree


def prepare_job(method, input):
    """Validate a method and return content-addressed copies of its JSON inputs."""
    if type(method) is not dict or not _REQUIRED_FIELDS <= set(method):
        raise ValueError("method needs id, purpose, representation, source, entrypoint, applicability")
    for key in _REQUIRED_FIELDS:
        value = method.get(key)
        if type(value) is not str or not value.strip():
            raise ValueError("required method fields must be nonempty strings")
    # Extension metadata is inert: it is preserved in the content hash but never
    # interpreted as executable authority. Canonical JSON validation below keeps
    # the transport finite and deterministic without freezing the schema.
    _validate_source(method["source"], method["entrypoint"])
    method_json, input_json = _json_text(method), _json_text(input)
    method_hash, input_hash = _hash(method_json), _hash(input_json)
    job_id = "methodjob_" + _hash(method_hash + ":" + input_hash)
    return {"job_id": job_id, "method": json.loads(method_json),
            "input": json.loads(input_json), "method_hash": method_hash,
            "input_hash": input_hash}


def _checked_job(job):
    if type(job) is not dict or set(job) != {"job_id", "method", "input", "method_hash", "input_hash"}:
        raise ValueError("job fields do not match prepare_job output")
    expected = prepare_job(job["method"], job["input"])
    if job != expected:
        raise ValueError("job content or hashes changed after preparation")
    return expected


def run_job(job, timeout_seconds=None):
    """Execute a validated job in a disposable UTF-8 Python subprocess.

    Validation/tamper errors raise ValueError. Executed jobs return ok, error,
    or timeout. Timeout terminates and waits for the child interpreter.
    """
    expected = _checked_job(job)
    if timeout_seconds is not None and (type(timeout_seconds) not in (int, float) or not math.isfinite(timeout_seconds) or timeout_seconds <= 0):
        raise ValueError("timeout_seconds must be positive when the caller supplies one")
    metadata = {key: expected[key] for key in ("job_id", "method_hash", "input_hash")}
    started = time.monotonic()
    try:
        # Materialize only this worker in a temporary directory; ZIP imports have
        # no executable filesystem __file__. No installation is required.
        with TemporaryDirectory(prefix="jigaewol_compute_") as directory:
            worker = Path(directory) / "worker.py"
            worker_source = pkgutil.get_data("jigaewol_runtime.methods", "runner.py")
            if not isinstance(worker_source, (bytes, bytearray)):
                raise OSError("computation worker source is unavailable")
            worker.write_bytes(bytes(worker_source))
            child = subprocess.run(
                [sys.executable, "-I", str(worker), "--child"],
                input=json.dumps(expected, ensure_ascii=False, allow_nan=False),
                text=True, encoding="utf-8", errors="strict", capture_output=True,
                timeout=timeout_seconds, check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if child.returncode != 0:
            result = {"status": "error", "error": "computation worker exited without a valid result"}
        elif _MAX_JSON_BYTES is not None and len(child.stdout.encode("utf-8")) > _MAX_JSON_BYTES + 8192:
            result = {"status": "error", "error": "computation worker result exceeds the caller-selected transport limit"}
        else:
            result = json.loads(child.stdout)
            if type(result) is not dict or result.get("status") not in {"ok", "error"}:
                raise ValueError("invalid computation worker result")
            if result["status"] == "ok":
                if set(result) != {"status", "output", "output_hash"} or _hash(_json_text(result["output"])) != result["output_hash"]:
                    raise ValueError("invalid computation worker output hash")
            elif set(result) != {"status", "error"} or type(result["error"]) is not str:
                raise ValueError("invalid computation worker error")
    except subprocess.TimeoutExpired:
        result = {"status": "timeout", "error": "computation exceeded its per-job time budget"}
    except (OSError, UnicodeError, ValueError) as exc:
        result = {"status": "error", "error": (type(exc).__name__ + ": " + str(exc))[:500]}
    return {**metadata, **result, "elapsed_seconds": round(time.monotonic() - started, 6)}


def _child():
    """Private worker protocol; only JSON is written to stdout."""
    try:
        sys.stdin.reconfigure(encoding="utf-8")
        sys.stdout.reconfigure(encoding="utf-8")
        payload = sys.stdin.read()
        if _MAX_JSON_BYTES is not None and len(payload.encode("utf-8")) > _MAX_JSON_BYTES * 2 + 8192:
            raise ValueError("worker payload exceeds the caller-selected transport limit")
        job = _checked_job(json.loads(payload))
        namespace = {"__builtins__": dict(_SAFE_BUILTINS)}
        code = compile(_validate_source(job["method"]["source"], job["method"]["entrypoint"]), "<host-computation>", "exec")
        exec(code, namespace, namespace)
        output = namespace[job["method"]["entrypoint"]](job["input"])
        output_json = _json_text(output)
        result = {"status": "ok", "output": json.loads(output_json), "output_hash": _hash(output_json)}
    except Exception as exc:
        result = {"status": "error", "error": (type(exc).__name__ + ": " + str(exc))[:500]}
    sys.stdout.write(json.dumps(result, ensure_ascii=False, allow_nan=False, separators=(",", ":")))


if __name__ == "__main__":
    if sys.argv[1:] != ["--child"]:
        raise SystemExit("This module is called through prepare_job/run_job.")
    _child()
