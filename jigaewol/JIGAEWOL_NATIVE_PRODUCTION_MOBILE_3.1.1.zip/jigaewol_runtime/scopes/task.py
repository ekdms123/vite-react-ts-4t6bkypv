from jigaewol_runtime.kernel.ids import new_id


class TaskScope:
    @staticmethod
    def resolve(active_task_id: str | None, requested_task_id: str | None, new_task: bool) -> str:
        if new_task:
            return new_id("task")
        return requested_task_id or active_task_id or new_id("task")
