"""Completed attempts are retained separately from user-confirmed useful methods."""
from pathlib import Path
from contextlib import closing
import hashlib
import json
import re
import sqlite3


def _terms(text):
    return {t.casefold() for t in re.findall(r"\w+", text) if len(t) >= 2}


class RepertoireStore:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.db_path = self.root / "repertoire.sqlite3"
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            conn.execute("CREATE TABLE IF NOT EXISTS repertoire(key TEXT PRIMARY KEY,value_json TEXT NOT NULL,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")

    def record_outcome(self, message, strategy, score=0.0):
        payload = {"message": message, "terms": sorted(_terms(message)), "strategy": strategy,
                   "score": 0.0, "status": "unrated", "feedback": []}
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True)
        key = hashlib.sha256(encoded.encode()).hexdigest()
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            conn.execute("INSERT OR IGNORE INTO repertoire(key,value_json) VALUES(?,?)", (key, encoded))
        return key

    def feedback(self, key, helpful, quote, origin):
        if not isinstance(helpful, bool) or not quote.strip() or not origin:
            raise ValueError("feedback needs a real user quote and its turn reference")
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            row = conn.execute("SELECT value_json FROM repertoire WHERE key=?", (key,)).fetchone()
            if not row:
                raise KeyError(key)
            payload = json.loads(row[0])
            payload["status"] = "user_helpful" if helpful else "user_unhelpful"
            payload["score"] = 1.0 if helpful else -1.0
            payload.setdefault("feedback", []).append({"helpful": helpful, "quote": quote, "origin": origin})
            conn.execute("UPDATE repertoire SET value_json=?,updated_at=CURRENT_TIMESTAMP WHERE key=?",
                         (json.dumps(payload, ensure_ascii=False), key))
        return payload

    def recall(self, message, limit=None):
        target = _terms(message)
        with closing(sqlite3.connect(self.db_path)) as conn, conn:
            rows = conn.execute("SELECT value_json FROM repertoire ORDER BY updated_at DESC,rowid DESC").fetchall()
        ranked = []
        for (encoded,) in rows:
            payload = json.loads(encoded)
            if payload.get("status") != "user_helpful":
                continue
            prior = set(payload.get("terms", ()))
            overlap = len(target & prior)
            if overlap:
                ranked.append((overlap / max(1, len(target | prior)), payload))
        ranked.sort(key=lambda row: row[0], reverse=True)
        return tuple(p for _, p in (ranked if limit is None else ranked[:max(0, int(limit))]))
