"""Turn, task, and repertoire scopes."""
