"""Small deterministic checkers. They check declared properties, not overall quality."""
import ast
import difflib
import json
from math import isfinite
from urllib.parse import urlparse

LOCAL_KINDS = {"text.contains", "text.excludes", "text.length", "json.keys", "python.syntax",
               "diff.preserved", "source.quotes", "source.domains", "facts.consistent", "math.polynomial"}


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value)


def passed(value, criterion):
    if "eq" in criterion:
        return type(value) is type(criterion["eq"]) and value == criterion["eq"]
    if not finite(value):
        return False
    return ("min" not in criterion or value >= criterion["min"]) and ("max" not in criterion or value <= criterion["max"])


def measure(probe, material, ledger):
    if not isinstance(material, dict) or not isinstance(material.get("sample"), str):
        raise ValueError("feedback material sample must be text")
    text = material["sample"]
    args = probe.get("parameters", {})
    if not isinstance(args, dict):
        raise ValueError("feedback probe parameters must be an object")
    kind = probe["kind"]
    if kind == "math.polynomial":
        from .polynomial import equivalent
        return equivalent(text, args["expected"])
    if kind == "text.contains":
        terms = args.get("terms", [])
        if not terms or any(not isinstance(t, str) or not t for t in terms):
            raise ValueError("contains requires literal terms")
        missing = [t for t in terms if t not in text]
        return not missing, {"missing": missing}
    if kind == "text.excludes":
        terms = args.get("terms", [])
        if not terms or any(not isinstance(t, str) or not t for t in terms):
            raise ValueError("excludes requires literal terms")
        found = [t for t in terms if t in text]
        return not found, {"found": found}
    if kind == "text.length":
        unit = args.get("unit", "characters")
        if unit not in {"characters", "words", "lines"}:
            raise ValueError("unknown length unit")
        values = {"characters": len(text), "words": len(text.split()), "lines": len(text.splitlines())}
        return values[unit], {"unit": unit}
    if kind == "json.keys":
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            return False, {"parse_error": str(exc)}
        keys = args.get("keys", [])
        if not isinstance(keys, list) or not keys or any(not isinstance(key, str) or not key for key in keys):
            raise ValueError("json.keys needs a list of required text keys")
        return isinstance(value, dict) and all(k in value for k in keys), {"required_keys": keys}
    if kind == "python.syntax":
        try:
            ast.parse(text)
            return True, {"scope": "syntax_only"}
        except SyntaxError as exc:
            return False, {"line": exc.lineno, "error": exc.msg}
    if kind == "diff.preserved":
        baseline = args.get("baseline", "")
        fragments = args.get("preserve", [])
        if not isinstance(baseline, str) or not isinstance(fragments, list) or any(not isinstance(fragment, str) or not fragment for fragment in fragments):
            raise ValueError("diff.preserved requires text baseline and preserve fragments")
        if not fragments or any(fragment not in baseline for fragment in fragments):
            raise ValueError("preserved fragments must exist in baseline")
        missing = [fragment for fragment in fragments if fragment not in text]
        return not missing, {"missing": missing, "diff": list(difflib.unified_diff(
            baseline.splitlines(), text.splitlines(), lineterm=""))[:80]}
    if kind in {"source.quotes", "source.domains"}:
        citations = material.get("citations", [])
        if not isinstance(citations, list) or not citations or any(not isinstance(citation, dict) for citation in citations):
            raise ValueError("candidate citations must be a nonempty list of objects")
        domains, errors = set(), []
        for citation in citations:
            source_ref = citation.get("source_ref")
            if not isinstance(source_ref, str) or not source_ref:
                raise ValueError("citation source_ref must be a nonempty id")
            entry = ledger.get(source_ref)
            if entry.kind != "source":
                raise ValueError("citation must refer to recorded source content")
            quote = citation.get("quote", "")
            if not quote or quote not in str(entry.content):
                errors.append(citation["source_ref"])
            for origin in entry.tool_origin_refs:
                host = urlparse(origin).hostname
                if host:
                    domains.add(host.lower().removeprefix("www."))
        if kind == "source.quotes":
            return not errors, {"missing_quotes": errors, "scope": "literal_linkage_not_entailment"}
        return len(domains), {"domains": sorted(domains), "scope": "domain_count_not_source_independence"}
    if kind == "facts.consistent":
        facts = material.get("facts", [])
        if not isinstance(facts, list) or not facts or any(not isinstance(fact, dict) for fact in facts):
            raise ValueError("normalized facts must be a nonempty list of objects")
        values, conflicts = {}, []
        for fact in facts:
            source_ref = fact.get("source_ref")
            if not isinstance(source_ref, str) or not source_ref:
                raise ValueError("normalized fact source_ref must be a nonempty id")
            if "key" not in fact or "value" not in fact:
                raise ValueError("normalized fact needs key and value")
            source = ledger.get(source_ref)
            quote = fact.get("quote", "")
            if source.kind != "source" or not quote or quote not in str(source.content):
                raise ValueError("normalized fact must quote a recorded source")
            key_name = fact["key"]
            unit = fact.get("unit", "")
            scope = fact.get("scope", "")
            if (not isinstance(key_name, str) or not key_name.strip() or
                    not isinstance(unit, str) or not isinstance(scope, str)):
                raise ValueError("normalized fact key must be nonempty text and unit/scope must be text")
            key = (key_name.strip(), unit, scope)
            try:
                encoded = json.dumps(fact["value"], sort_keys=True, ensure_ascii=False, allow_nan=False)
            except (TypeError, ValueError) as exc:
                raise ValueError("normalized fact value must be finite JSON") from exc
            if key in values and values[key] != encoded:
                conflicts.append({"key": key, "values": [values[key], encoded]})
            values[key] = encoded
        return not conflicts, {"conflicts": conflicts, "scope": "host_normalized_fact_consistency"}
    raise ValueError("unknown local checker: " + kind)
