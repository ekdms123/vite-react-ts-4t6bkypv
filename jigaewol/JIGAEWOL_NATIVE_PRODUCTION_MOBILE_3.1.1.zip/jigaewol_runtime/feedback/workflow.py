"""Live connection between candidate generation, real feedback and delivery."""
from copy import deepcopy
from .plane import FeedbackPlane, material_of, digest


class FeedbackWorkflow:
    def _feedback_choice_basis(self, runtime, plane, decision):
        # Classification follows the evidence actually present in the active
        # comparison, never a profile label. A recorded host review is subjective;
        # absent measurement remains explicitly unmeasured.
        if decision["chosen"] is not None:
            if decision["basis"] == "provisional_host_choice" or (
                    decision["basis"] == "provisional_only_eligible" and
                    plane.active().get("review_choice") == decision["chosen"]):
                decision["basis"] = "subjective_host_choice"
                decision["choice_reason"] = plane.active().get("review_choice_reason", "")
            elif decision["basis"] == "provisional_only_eligible":
                decision["basis"] = "only_eligible_material_without_quality_measurement"
        return decision

    def _feedback_packet(self, runtime, plane):
        packet = plane.public_packet()
        packet["decision"] = self._feedback_choice_basis(runtime, plane, packet["decision"])
        return packet

    def _plane(self, runtime):
        if "feedback_plane" not in runtime.extensions:
            runtime.extensions["feedback_plane"] = FeedbackPlane().state
            previous = runtime.extensions.get("previous_turn") or {}
            runtime.extensions["feedback_plane"]["preferences"] = deepcopy(previous.get("feedback_preferences", []))
        plane = FeedbackPlane(runtime.extensions["feedback_plane"])
        plane.state["generator_id"] = runtime.extensions.get("generator_id")
        return plane

    def _feedback_design(self, runtime, node, payload):
        plane = self._plane(runtime)
        if plane.state.get("contract_locked"):
            raise ValueError("the initial feedback contract is already locked; add a challenge probe instead")
        probes = payload.get("probes", [])
        if not isinstance(probes, list) or any(not isinstance(probe, dict) for probe in probes):
            raise ValueError("feedback probes must be a list of objects")
        reason = payload.get("reason", "")
        if not isinstance(reason, str):
            raise ValueError("feedback design reason must be text")
        if not probes and not reason.strip():
            raise ValueError("give concrete probes or explain which feedback is unavailable")
        for probe in probes:
            intent_refs = probe.get("intent_refs", [])
            if not isinstance(intent_refs, list) or any(not isinstance(ref, str) or not ref.strip() for ref in intent_refs):
                raise ValueError("feedback constraint intent_refs must be a list of nonempty ids")
            if not set(intent_refs) <= set(runtime.program.objective_refs):
                raise ValueError("feedback constraint references an unknown requirement")
        plane.register(probes, runtime.raw.message, runtime.ledger, runtime.extensions["capability_specs"])
        plane.state.update(contract_locked=True, design_reason=reason)
        return runtime.ledger.add_observation({"feedback_contract": deepcopy(plane.state["probes"]),
                                              "contract_hash": plane.state.get("contract_hash")})

    def _feedback_jobs(self, runtime, plane, target):
        tools = []
        for probe, job in plane.jobs():
            if not probe["available"]:
                plane.unavailable(job, "capability is not available in this chat")
                continue
            if not target:
                plane.unavailable(job, "no pending feedback target is available")
                continue
            sources = {}
            for case in job["cases"]:
                for citation in case["material"].get("citations", []) + case["material"].get("facts", []):
                    ref = citation["source_ref"]
                    source = runtime.ledger.get(ref)
                    if source.kind != "source":
                        raise ValueError("feedback source references must identify recorded sources")
                    sources[ref] = {"text": source.content, "origins": list(source.tool_origin_refs)}
            job["sources"] = sources
            tools.append(self._cap_node(runtime, probe["capability_id"], {"feedback_job": job}))
        if tools:
            self._replace_pending(runtime, (target.node_id,), tools + [target], count_rewrite=False, required=True)

    def _feedback_run(self, runtime, node):
        plane = self._plane(runtime)
        candidates = runtime.extensions.get("candidates", [])
        explicit_choice = runtime.extensions.get("candidate_choice") is not None
        plane.state["required_intents"] = list(runtime.program.objective_refs)
        if not candidates:
            raise ValueError("feedback.run needs candidate materials")
        if not plane.state.get("contract_locked"):
            if not explicit_choice:
                raise ValueError("design the feedback contract before generating/evaluating candidates")
            plane.register([], runtime.raw.message, runtime.ledger, runtime.extensions["capability_specs"])
            plane.state.update(contract_locked=True, design_reason="explicit material comparison without measurement probes")
        if node.parameters and dict(node.parameters).get("reuse_batch"):
            plane.assert_bound(candidates)
        else:
            plane.batch(candidates)
        if explicit_choice:
            choice = runtime.extensions.get("candidate_choice")
            row = next((r for r in plane.active()["rows"] if r["candidate_id"] == choice), None)
            reason = runtime.extensions.get("candidate_choice_reason", "")
            if row is None or not isinstance(reason, str) or not reason.strip():
                raise ValueError("user-directed candidate choice needs a current candidate and a material comparison reason")
            plane.active()["review_choice"] = row["blind"]
            plane.active()["review_choice_reason"] = reason
        plane.run_local(runtime.ledger)
        target = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "feedback.review"), None)
        if target is None and explicit_choice:
            target = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "trajectories.select"), None)
        self._feedback_jobs(runtime, plane, target)
        runtime.extensions["feedback"] = self._feedback_packet(runtime, plane)
        return runtime.ledger.add_observation({"feedback_batch": plane.active()["id"], "purpose": "candidate_comparison"})

    def _feedback_tool_result(self, runtime, node, payload, source_ref):
        job = dict(node.parameters).get("feedback_job")
        if not job:
            return
        plane = self._plane(runtime)
        plane.ingest(job, payload["output"], source_ref, payload["origin_ref"])
        runtime.extensions["feedback"] = self._feedback_packet(runtime, plane)

    def _feedback_review(self, runtime, node, payload):
        plane = self._plane(runtime)
        plane.assert_bound(runtime.extensions.get("candidates", []))
        plane.state["critic_notes"].append({"channel": "same_model_critique", "independent": False,
            "reason": payload.get("reason", ""), "critiques": deepcopy(payload.get("critiques", []))})
        challenge = payload.get("challenge")
        if challenge is not None and not isinstance(challenge, dict):
            raise ValueError("feedback challenge must be an object")
        if challenge:
            target = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "trajectories.select"), None)
            if target:
                challenge_refs = challenge.get("intent_refs", [])
                if not isinstance(challenge_refs, list) or any(not isinstance(ref, str) or not ref.strip() for ref in challenge_refs):
                    raise ValueError("challenge intent_refs must be a list of nonempty ids")
                if not set(challenge_refs) <= set(runtime.program.objective_refs):
                    raise ValueError("challenge references an unknown requirement")
                plane.register([challenge], runtime.raw.message, runtime.ledger,
                    runtime.extensions["capability_specs"], phase="adaptive_discriminator")
                challenge_count = plane.state.get("challenge_count", 0)
                if isinstance(challenge_count, bool) or not isinstance(challenge_count, int) or challenge_count < 0:
                    raise ValueError("feedback challenge_count must be a nonnegative integer")
                plane.state["challenge_count"] = challenge_count + 1
                steps = [self._node(runtime, "local", "feedback.run", parameters={"reuse_batch": True}),
                         self._node(runtime, "host_semantic", "feedback.review"), target]
                self._replace_pending(runtime, (target.node_id,), steps, count_rewrite=False, required=True)
                return runtime.ledger.add_observation({"feedback_challenge": challenge["id"]})
            runtime.extensions["notices"].append("feedback challenge retained as a suggestion; no pending selection target")
        choice = payload.get("choice")
        if choice is not None and choice not in {r["blind"] for r in plane.active()["rows"]}:
            raise ValueError("choice must be a current blinded candidate label")
        if choice is None and plane.decision(runtime.program.objective_refs)["frontier"] and not plane.decision(runtime.program.objective_refs)["chosen"]:
            raise ValueError("choose a provisional candidate from the remaining tradeoff or supply a discriminating challenge")
        plane.active()["review_choice"] = choice
        runtime.extensions["feedback"] = self._feedback_packet(runtime, plane)
        return runtime.ledger.add_observation({"review": payload, "basis": "same_model_critique_not_measurement"})

    def _feedback_choose(self, runtime, required):
        plane = self._plane(runtime)
        plane.assert_bound(runtime.extensions.get("candidates", []))
        decision = self._feedback_choice_basis(runtime, plane, plane.decision(required))
        runtime.extensions["feedback_decision"] = decision
        if "feedback" in runtime.extensions:
            runtime.extensions["feedback"]["decision"] = {k: deepcopy(v) for k, v in decision.items() if k != "candidate_id"}
        if decision["chosen"] is None:
            runtime.extensions["feedback_repair"] = {"reason": "no_decisive_eligible_candidate", "decision": decision}
        else:
            runtime.extensions.pop("feedback_repair", None)
        return decision

    def _feedback_delivery(self, runtime, payload):
        plane = self._plane(runtime)
        if not plane.state.get("contract_locked") or not plane.state["probes"]:
            runtime.extensions["delivery_feedback"] = {"status": "unmeasured", "reason": "no feedback contract for this turn"}
            return
        if not isinstance(runtime.answer, str):
            raise ValueError("delivery feedback requires delivered text")
        text = runtime.answer
        evaluation = payload.get("evaluation_quote", text)
        if not isinstance(evaluation, str) or not evaluation or evaluation not in text:
            raise ValueError("evaluation_quote must be exact delivered text, such as the delivered code block body")
        material = {"id": "delivered", "sample": evaluation, "intent_refs": list(runtime.program.objective_refs),
                    "citations": payload.get("citations", []), "facts": payload.get("facts", [])}
        plane.batch([material], purpose="delivery")
        plane.run_local(runtime.ledger)
        target = next((n for n in runtime.program.nodes if n.status == "pending" and n.operation == "closure.check"), None)
        self._feedback_jobs(runtime, plane, target)
        runtime.extensions["delivery_feedback"] = {"status": "awaiting_closure", "batch_id": plane.active()["id"],
            "material_hash": digest(material_of(material)), "scope": "exact_evaluation_quote"}

    def _feedback_closure(self, runtime):
        plane = self._plane(runtime)
        if not plane.state.get("active_batch") or plane.active()["purpose"] != "delivery":
            return set()
        matrix = plane.matrix()
        row = matrix["rows"][0]
        missing = [p for p in matrix["probes"] if p["hard"] and
                   (row["cells"][p["id"]].get("passed") is not True or not row["cells"][p["id"]].get("usable", False))]
        runtime.extensions["delivery_feedback"] = {"status": "partial" if missing else "recorded",
            "batch_id": plane.active()["id"], "matrix": matrix,
            "scope": "declared_probes_on_exact_evaluation_quote", "unmet_hard_probes": [p["id"] for p in missing]}
        refs = {ref for p in missing for ref in p.get("intent_refs", runtime.program.objective_refs)}
        if missing and not refs:
            refs.update(runtime.program.objective_refs)
        return refs

    def feedback_preference(self, turn_id, candidate_ref, *, feedback_turn_id, user_quote):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        feedback = self._runtimes.get(feedback_turn_id) or self._restore(feedback_turn_id)
        if (not isinstance(candidate_ref, str) or not candidate_ref or
                turn_id == feedback_turn_id or not isinstance(user_quote, str) or not user_quote or
                user_quote not in feedback.raw.message):
            raise ValueError("preference requires an exact text quote from a separate real user feedback turn")
        plane = self._plane(runtime)
        matches = [row for batch in plane.state["batches"] if batch["purpose"] == "candidates"
                   for row in batch["rows"] if candidate_ref in {row["blind"], row["hash"]}]
        if not matches or len({row["hash"] for row in matches}) != 1:
            raise ValueError("use a unique candidate hash or blinded label from the actual comparison")
        record = {"material_hash": matches[-1]["hash"], "quote": user_quote, "feedback_turn": feedback_turn_id,
                  "basis": "user_preference", "binding": "host_interpreted_preference"}
        plane.state["preferences"].append(record)
        self._persist(runtime)
        return deepcopy(record)

    def read_feedback(self, turn_id, section="all", candidate_ref=None):
        runtime = self._runtimes.get(turn_id) or self._restore(turn_id)
        plane = self._plane(runtime)
        if section == "all":
            return self._feedback_packet(runtime, plane)
        if section == "matrix":
            return plane.matrix()
        if section == "probes":
            return deepcopy(plane.state["probes"])
        if section == "material":
            row = next((r for r in plane.active()["rows"] if candidate_ref in {r["blind"], r["hash"]}), None)
            if row is None:
                raise ValueError("candidate_ref must identify material in the active feedback batch")
            return deepcopy(row["material"])
        raise ValueError("feedback section must be all, matrix, probes or material")
