"""Exact arithmetic for bounded polynomial identities; no eval or external solver."""
import ast
from fractions import Fraction


class UnsupportedPolynomial(ValueError):
    pass


def canonical(expression):
    if not isinstance(expression, str) or len(expression) > 8000:
        raise UnsupportedPolynomial("expression exceeds the small exact checker's scope")
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise UnsupportedPolynomial(str(exc)) from exc
    if sum(1 for _ in ast.walk(tree)) > 300:
        raise UnsupportedPolynomial("expression is too large")
    def clean(poly):
        out = {key: value for key, value in poly.items() if value}
        if len(out) > 512 or any(v.numerator.bit_length() > 8192 or v.denominator.bit_length() > 8192 for v in out.values()):
            raise UnsupportedPolynomial("polynomial exceeds arithmetic budget")
        return out
    def add(a, b, sign=1):
        out = dict(a)
        for key, value in b.items():
            out[key] = out.get(key, Fraction(0)) + sign * value
        return clean(out)
    def multiply(a, b):
        if len(a) * len(b) > 4096:
            raise UnsupportedPolynomial("polynomial product exceeds budget")
        out = {}
        for left, x in a.items():
            for right, y in b.items():
                key = tuple(sorted(left + right))
                out[key] = out.get(key, Fraction(0)) + x * y
        return clean(out)
    def read(node):
        if isinstance(node, ast.Constant) and type(node.value) is int:
            if node.value.bit_length() > 8192:
                raise UnsupportedPolynomial("integer exceeds budget")
            return clean({(): Fraction(node.value)})
        if isinstance(node, ast.Name):
            return {(node.id,): Fraction(1)}
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            sign = -1 if isinstance(node.op, ast.USub) else 1
            return {k: sign * v for k, v in read(node.operand).items()}
        if not isinstance(node, ast.BinOp):
            raise UnsupportedPolynomial("only integer/rational polynomial arithmetic is supported")
        a = read(node.left)
        if isinstance(node.op, ast.Pow):
            if not isinstance(node.right, ast.Constant) or type(node.right.value) is not int or not 0 <= node.right.value <= 12:
                raise UnsupportedPolynomial("power must be an integer from zero to twelve")
            out = {(): Fraction(1)}
            for _ in range(node.right.value):
                out = multiply(out, a)
            return out
        b = read(node.right)
        if isinstance(node.op, ast.Add):
            return add(a, b)
        if isinstance(node.op, ast.Sub):
            return add(a, b, -1)
        if isinstance(node.op, ast.Mult):
            return multiply(a, b)
        if isinstance(node.op, ast.Div) and set(b) == {()} and b[()]:
            return clean({k: v / b[()] for k, v in a.items()})
        raise UnsupportedPolynomial("unsupported operation or nonconstant divisor")
    return read(tree.body)


def equivalent(actual, expected):
    a, b = canonical(actual), canonical(expected)
    return a == b, {"scope": "exact_polynomial_identity", "actual_terms": len(a), "expected_terms": len(b)}
