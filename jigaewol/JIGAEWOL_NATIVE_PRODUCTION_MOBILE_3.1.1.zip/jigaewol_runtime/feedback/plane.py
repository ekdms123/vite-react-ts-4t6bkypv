"""Evidence plane independent of candidate self-scores; state is JSON serializable."""
from copy import deepcopy
import hashlib
import json
from random import SystemRandom
from secrets import token_hex
from .checkers import LOCAL_KINDS, measure, passed, finite
from jigaewol_runtime.contract.extraction import locate_quote


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False,
                                    separators=(",", ":")).encode()).hexdigest()


def material_of(candidate):
    return {"sample": candidate["sample"], "structure": deepcopy(candidate.get("structure", {})),
            "citations": deepcopy(candidate.get("citations", [])), "facts": deepcopy(candidate.get("facts", []))}


class FeedbackPlane:
    def __init__(self, state=None):
        self.state = state if state is not None else {"probes": [], "batches": [], "preferences": [], "critic_notes": []}

    def register(self, probes, request, ledger, capabilities, *, phase="before_candidates"):
        if not isinstance(probes, list):
            raise ValueError("feedback probes must be a list")
        if not isinstance(phase, str) or not phase.strip():
            raise ValueError("feedback phase must be nonempty text")
        existing = {p["id"]: p for p in self.state["probes"]}
        additions = []
        for raw in probes:
            p = deepcopy(raw)
            pid = p.get("id")
            if not isinstance(pid, str) or not pid.strip():
                raise ValueError("probe id must be nonempty text")
            pid = pid.strip()
            p["id"] = pid
            if pid in existing or any(q["id"] == pid for q in additions):
                raise ValueError("probe ids are immutable; use a new id for a new criterion")
            if p.get("kind") not in LOCAL_KINDS | {"tool"}:
                raise ValueError("unknown probe kind")
            if p.get("direction", "pass") not in {"pass", "min", "max"}:
                raise ValueError("direction must be pass, min or max")
            accept = p.get("accept", {"eq": True})
            if not isinstance(accept, dict) or not accept or set(accept) - {"eq", "min", "max"}:
                raise ValueError("provide an explicit measurable acceptance predicate")
            if "eq" in accept and len(accept) != 1:
                raise ValueError("eq cannot be combined with numeric bounds")
            if any(not finite(v) for k, v in accept.items() if k != "eq"):
                raise ValueError("numeric bounds must be finite")
            if "eq" in accept and not isinstance(accept["eq"], (str, bool, int, float)):
                raise ValueError("eq expects a scalar")
            if isinstance(accept.get("eq"), float) and not finite(accept["eq"]):
                raise ValueError("eq must be finite")
            if "min" in accept and "max" in accept and accept["min"] > accept["max"]:
                raise ValueError("inverted acceptance bounds")
            question = p.get("question")
            if not isinstance(question, str) or not question.strip():
                raise ValueError("state what this probe distinguishes")
            p["question"] = question.strip()
            intent_refs = p.get("intent_refs", [])
            if not isinstance(intent_refs, list) or any(not isinstance(ref, str) or not ref.strip() for ref in intent_refs):
                raise ValueError("probe intent_refs must be a list of nonempty ids")
            p["intent_refs"] = [ref.strip() for ref in intent_refs]
            p.setdefault("parameters", {})
            if not isinstance(p["parameters"], dict):
                raise ValueError("probe parameters must be an object")
            p.setdefault("hard", False)
            if not isinstance(p["hard"], bool):
                raise ValueError("hard must be boolean")
            basis = p.get("basis", {"kind": "hypothesis"})
            if not isinstance(basis, dict):
                raise ValueError("probe basis must be an object")
            if basis.get("kind") == "request":
                locate_quote(request, basis.get("quote"), basis.get("occurrence"))
            elif basis.get("kind") == "source":
                source_ref = basis.get("source_ref")
                if not isinstance(source_ref, str) or not source_ref.strip():
                    raise ValueError("source probe basis needs a nonempty source_ref")
                source = ledger.get(source_ref.strip())
                if source.kind != "source":
                    raise ValueError("criterion basis must be a recorded source")
                locate_quote(str(source.content), basis.get("quote"), basis.get("occurrence"))
            elif basis.get("kind") != "hypothesis":
                raise ValueError("basis kind must be request, source or hypothesis")
            if p["hard"] and basis["kind"] == "hypothesis":
                raise ValueError("a speculative probe cannot become a mandatory user constraint")
            p.update(accept=accept, direction=p.get("direction", "pass"), basis=basis,
                     phase=phase, oracle_scope="host_interpreted_criterion")
            if p["kind"] == "tool":
                capability_id = p.get("capability_id")
                task = p["parameters"].get("task")
                if (not isinstance(capability_id, str) or not capability_id.strip() or
                        not isinstance(task, str) or not task.strip()):
                    raise ValueError("tool probe requires text capability_id and an executable text task")
                p["capability_id"] = capability_id.strip()
                p["parameters"]["task"] = task.strip()
                cap = next((c for c in capabilities if c["id"] == p["capability_id"]), None)
                p["available"] = cap is not None
                p["signal_kind"] = cap.get("feedback_kind", "tool_observation") if cap else "unavailable"
                p["evaluator_id"] = cap.get("evaluator_id") if cap else None
            else:
                p["available"] = True
                p["signal_kind"] = "local_property"
            controls = p.get("controls", [])
            if not isinstance(controls, list):
                raise ValueError("probe controls must be a list")
            for control in controls:
                if not isinstance(control, dict) or not isinstance(control.get("sample"), str) or not isinstance(control.get("expect_pass"), bool):
                    raise ValueError("control needs sample text and an explicit expected pass/fail outcome")
            p["controls"] = controls
            p["hash"] = digest(p)
            additions.append(p)
        self.state["probes"].extend(additions)
        self.state["contract_hash"] = digest(self.state["probes"])
        return additions

    def batch(self, candidates, purpose="candidates"):
        if not isinstance(candidates, list) or not candidates:
            raise ValueError("feedback candidates must be a nonempty list of objects")
        if not isinstance(purpose, str) or not purpose.strip():
            raise ValueError("feedback batch purpose must be nonempty text")
        rows, seen_ids = [], set()
        for c in candidates:
            if not isinstance(c, dict):
                raise ValueError("feedback candidates must be objects")
            candidate_id = c.get("id")
            if not isinstance(candidate_id, str) or not candidate_id.strip():
                raise ValueError("feedback candidate id must be nonempty text")
            candidate_id = candidate_id.strip()
            if candidate_id in seen_ids:
                raise ValueError("feedback candidate ids must be unique")
            seen_ids.add(candidate_id)
            refs = c.get("intent_refs", [])
            if not isinstance(refs, list) or any(not isinstance(ref, str) or not ref.strip() for ref in refs):
                raise ValueError("feedback candidate intent_refs must be a list of nonempty ids")
            material = material_of(c)
            rows.append({"candidate_id": candidate_id, "blind": "C-" + token_hex(3),
                         "hash": digest(material), "material": material,
                         "intent_refs": [ref.strip() for ref in refs]})
        SystemRandom().shuffle(rows)
        batch = {"id": "batch-" + token_hex(8), "purpose": purpose, "rows": rows,
                 "receipts": [], "jobs": {}, "review_choice": None}
        self.state["batches"].append(batch)
        self.state["active_batch"] = batch["id"]
        return batch

    def active(self):
        return next(b for b in self.state["batches"] if b["id"] == self.state["active_batch"])

    def assert_bound(self, candidates):
        expected = {c["id"]: digest(material_of(c)) for c in candidates}
        actual = {r["candidate_id"]: r["hash"] for r in self.active()["rows"]}
        if expected != actual:
            raise ValueError("candidate material changed; evaluate a new batch before selection")

    def _cases(self, probe):
        batch = self.active()
        controls = batch.setdefault("controls", {})
        if probe["hash"] not in controls:
            controls[probe["hash"]] = []
            for control in probe.get("controls", []):
                material = material_of(control)
                controls[probe["hash"]].append({"blind": "C-" + token_hex(3), "hash": digest(material),
                    "material": material, "expect_pass": control["expect_pass"]})
        return batch["rows"] + controls[probe["hash"]]

    def run_local(self, ledger):
        batch = self.active()
        for p in self.state["probes"]:
            if p["kind"] not in LOCAL_KINDS:
                continue
            for row in self._cases(p):
                if any(r["probe_hash"] == p["hash"] and r["material_hash"] == row["hash"] and
                       r["blind"] == row["blind"] for r in batch["receipts"]):
                    continue
                try:
                    value, details = measure(p, row["material"], ledger)
                    verdict, state = passed(value, p["accept"]), "observed"
                except (ValueError, TypeError, KeyError, IndexError) as exc:
                    value, verdict, state, details = None, None, "unknown", {"reason": str(exc)}
                receipt = {"probe_id": p["id"], "probe_hash": p["hash"], "blind": row["blind"],
                    "material_hash": row["hash"], "value": value, "passed": verdict, "state": state,
                    "channel": "local_property", "usable": state == "observed", "details": details}
                ref = ledger.add_observation({"feedback_measurement": receipt})
                receipt["ledger_ref"] = ref
                batch["receipts"].append(receipt)

    def jobs(self):
        batch = self.active()
        out = []
        for p in self.state["probes"]:
            if p["kind"] != "tool" or any(j["probe_hash"] == p["hash"] for j in batch["jobs"].values()):
                continue
            job = {"job_id": "probe-" + token_hex(8), "batch_id": batch["id"], "probe_id": p["id"],
                   "probe_hash": p["hash"], "parameters": deepcopy(p["parameters"]),
                   "cases": [{"blind": row["blind"], "material_hash": row["hash"],
                              "material": deepcopy(row["material"])} for row in self._cases(p)]}
            SystemRandom().shuffle(job["cases"])
            batch["jobs"][job["job_id"]] = {**job, "status": "pending"}
            out.append((p, job))
        return out

    def unavailable(self, job, reason):
        batch = self.active()
        if not isinstance(job, dict) or not isinstance(job.get("job_id"), str):
            raise ValueError("feedback job must be the issued job object")
        if not isinstance(reason, str) or not reason.strip():
            raise ValueError("unavailable feedback reason must be nonempty text")
        registered = batch["jobs"].get(job["job_id"])
        if not registered or registered.get("status") != "pending" or registered.get("batch_id") != batch["id"]:
            raise ValueError("feedback job is stale or not pending")
        if job.get("probe_hash") != registered.get("probe_hash"):
            raise ValueError("feedback job differs from the frozen registered job")
        registered["status"] = "unavailable"
        for case in registered["cases"]:
            batch["receipts"].append({"probe_id": registered["probe_id"], "probe_hash": registered["probe_hash"],
                "blind": case["blind"], "material_hash": case["material_hash"], "value": None,
                "passed": None, "state": "unknown", "channel": "unavailable", "details": {"reason": reason.strip()}})

    def ingest(self, job, output, source_ref, origin):
        batch = self.active()
        if not isinstance(job, dict) or not isinstance(job.get("job_id"), str):
            raise ValueError("feedback job must be the issued job object")
        registered = batch["jobs"].get(job["job_id"])
        if not registered or registered["status"] != "pending" or registered.get("batch_id") != batch["id"]:
            raise ValueError("feedback receipt is stale or the job is not pending")
        # The stored job is authoritative. A caller cannot swap frozen cases while
        # retaining a valid job id/probe hash.
        if (job.get("batch_id") != registered.get("batch_id") or
                job.get("probe_hash") != registered.get("probe_hash")):
            raise ValueError("feedback job differs from the frozen registered job")
        if not isinstance(output, dict) or output.get("job_id") != registered["job_id"] or output.get("probe_hash") != registered["probe_hash"]:
            raise ValueError("tool output must identify the exact issued job and frozen probe")
        p = next((p for p in self.state["probes"] if p["hash"] == registered["probe_hash"]), None)
        if p is None:
            raise ValueError("feedback job references an unavailable frozen probe")
        expected = {r["blind"]: r["material_hash"] for r in registered["cases"]}
        results = output.get("results")
        if not isinstance(results, list) or len(results) != len(expected):
            raise ValueError("a common probe must report every candidate, including errors")
        seen, receipts = set(), []
        for result in results:
            if not isinstance(result, dict):
                raise ValueError("each feedback tool result must be an object")
            label = result.get("blind")
            if label not in expected or label in seen or result.get("material_hash") != expected[label]:
                raise ValueError("tool result must match each frozen candidate exactly once")
            seen.add(label)
            state = result.get("state", "observed")
            if state not in {"observed", "unknown"}:
                raise ValueError("report observed measurements or unknown with a reason")
            value = result.get("value")
            if state == "observed" and not (isinstance(value, (bool, str)) or finite(value)):
                raise ValueError("measurement value must be a finite scalar")
            if not result.get("details"):
                raise ValueError("retain actual result details, logs or tool artifact references")
            declared_channel = str(p.get("signal_kind") or "tool_observation").strip()
            channel = declared_channel or "tool_observation"
            trust_class = "host_tool_observation"
            if channel in {"execution", "browser", "solver", "renderer"}:
                usable = True
                trust_class = "recognized_independent_tool_channel"
            elif channel == "external_semantic":
                evaluator = p.get("evaluator_id")
                generator = self.state.get("generator_id")
                usable = bool(evaluator and generator and evaluator != generator)
                trust_class = "independent_external_semantic" if usable else "semantic_independence_unconfirmed"
                if not usable:
                    channel = "semantic_independence_unconfirmed"
            elif channel == "unavailable":
                usable = False
                trust_class = "unavailable"
            else:
                # JIGAEWOL 10: a new sensor/evaluator kind is not discarded merely
                # because this runtime predates its channel name.  The actual
                # host-tool origin and frozen candidate binding are preserved,
                # while the channel remains explicitly unclassified rather than
                # being upgraded to platform-attested truth.
                usable = True
                trust_class = "unclassified_host_tool_observation"
            receipts.append({"probe_id": p["id"], "probe_hash": p["hash"], "blind": label,
                "material_hash": expected[label], "value": value if state == "observed" else None,
                "passed": passed(value, p["accept"]) if state == "observed" else None,
                "state": state, "channel": channel, "usable": usable, "trust_class": trust_class, "evaluator_id": p.get("evaluator_id"),
                "details": deepcopy(result["details"]), "ledger_ref": source_ref, "origin": origin,
                "provenance": "actual_host_tool_report_required; not_platform_attested"})
        batch["receipts"].extend(receipts)
        registered["status"] = "observed"

    def matrix(self):
        batch = self.active()
        probes = {p["id"]: p for p in self.state["probes"]}
        rows = []
        for row in batch["rows"]:
            cells = {}
            for pid, p in probes.items():
                receipts = [v for v in batch["receipts"] if v["blind"] == row["blind"] and
                            v["material_hash"] == row["hash"] and v["probe_hash"] == p["hash"]]
                cell = deepcopy(receipts[-1]) if receipts else {"state": "unknown", "passed": None, "value": None, "usable": False}
                controls = batch.get("controls", {}).get(p["hash"], [])
                health = "no_control"
                if controls:
                    health = "controls_passed"
                    for control in controls:
                        observed = [v for v in batch["receipts"] if v["blind"] == control["blind"] and v["probe_hash"] == p["hash"]]
                        if not observed or observed[-1]["state"] != "observed":
                            health = "control_unmeasured"
                            break
                        if observed[-1]["passed"] is not control["expect_pass"]:
                            health = "control_failed"
                            break
                    if health != "controls_passed":
                        cell["usable"] = False
                cell["probe_health"] = health
                cells[pid] = cell
            rows.append({"blind": row["blind"], "material_hash": row["hash"], "cells": cells})
        return {"batch_id": batch["id"], "purpose": batch["purpose"], "probes": deepcopy(list(probes.values())), "rows": rows}

    def decision(self, required=()):
        batch, matrix = self.active(), self.matrix()
        source = {r["blind"]: r for r in batch["rows"]}
        eligible, rejected = [], []
        for row in matrix["rows"]:
            misses = not set(required) <= set(source[row["blind"]]["intent_refs"])
            failed = [p["id"] for p in matrix["probes"] if p["hard"] and row["cells"][p["id"]].get("usable") and row["cells"][p["id"]]["passed"] is False]
            if misses or failed:
                rejected.append({"blind": row["blind"], "failed": failed, "missing_requirements": misses})
            else:
                eligible.append(row)
        # Unknown is not a zero or a pass. Only common observed properties can rank candidates.
        common = [p for p in matrix["probes"] if eligible and all(r["cells"][p["id"]]["state"] == "observed" and r["cells"][p["id"]].get("usable") for r in eligible)]
        def score(row, p):
            cell = row["cells"][p["id"]]
            value = cell["value"]
            if p["direction"] == "pass" or not finite(value):
                return int(cell["passed"] is True)
            return value if p["direction"] == "max" else -value
        def dominates(a, b):
            pairs = [(score(a, p), score(b, p)) for p in common]
            return bool(pairs) and all(x >= y for x, y in pairs) and any(x > y for x, y in pairs)
        frontier = [r for r in eligible if not any(dominates(o, r) for o in eligible if o is not r)]
        chosen, basis = None, "no_eligible_candidate"
        if len(frontier) == 1:
            chosen = frontier[0]["blind"]
            basis = "observed_properties" if common else "provisional_only_eligible"
        elif frontier:
            basis = "unresolved_tradeoff"
            preference = next((p for p in reversed(self.state["preferences"]) if p["material_hash"] in
                               {source[r["blind"]]["hash"] for r in frontier}), None)
            if preference:
                chosen = next(r["blind"] for r in frontier if source[r["blind"]]["hash"] == preference["material_hash"])
                basis = "user_preference"
            elif batch.get("review_choice") in {r["blind"] for r in frontier}:
                chosen, basis = batch["review_choice"], "provisional_host_choice"
        remaining = []
        if chosen:
            row = next(r for r in matrix["rows"] if r["blind"] == chosen)
            remaining = [p["id"] for p in matrix["probes"] if p["hard"] and (row["cells"][p["id"]]["passed"] is not True or not row["cells"][p["id"]].get("usable"))]
        return {"chosen": chosen, "candidate_id": source[chosen]["candidate_id"] if chosen else None,
                "basis": basis, "frontier": [r["blind"] for r in frontier], "rejected": rejected,
                "unverified_hard_probes": remaining, "common_observed_probes": [p["id"] for p in common]}

    def public_packet(self):
        batch = self.active()
        decision = self.decision(self.state.get("required_intents", ()))
        decision.pop("candidate_id", None)
        return {"matrix": self.matrix(), "decision": decision,
                "candidates": [{"blind": r["blind"], "material_hash": r["hash"], "material": deepcopy(r["material"])} for r in batch["rows"]],
                "critic_notes": deepcopy(self.state["critic_notes"][-6:]),
                "blinding_scope": "labels_and_scores_removed; same_chat_memory_is_not_isolated"}
