from __future__ import annotations

"""Compile cross-domain mechanism transfers into executable structural operators."""

from copy import deepcopy

from jigaewol_runtime.operators.spec import OperatorSpec
from jigaewol_runtime.operators.generated import validate_generated_operator


def _text(value, name):
    value = str(value or "").strip()
    if not value:
        raise ValueError(f"{name} is required")
    return value


def compile_transfer_plans(plans):
    if not isinstance(plans, list):
        raise ValueError("transfer_plans must be a list")
    compiled = []
    seen = set()
    for raw in plans:
        if not isinstance(raw, dict):
            raise ValueError("each transfer plan must be an object")
        transfer_id = _text(raw.get("id"), "transfer id")
        if transfer_id in seen:
            raise ValueError("transfer ids must be unique")
        seen.add(transfer_id)
        mapping = raw.get("target_mapping") or {}
        if not isinstance(mapping, dict) or not mapping:
            raise ValueError("target_mapping must be a nonempty object")
        preserved = raw.get("preserved_conditions") or []
        broken = raw.get("break_conditions") or []
        if not isinstance(preserved, list) or not isinstance(broken, list):
            raise ValueError("transfer conditions must be lists")

        result = {
            "id": transfer_id,
            "source_domain": _text(raw.get("source_domain"), "source_domain"),
            "source_mechanism": _text(raw.get("source_mechanism"), "source_mechanism"),
            "target_mapping": deepcopy(mapping),
            "preserved_conditions": [str(x) for x in preserved if str(x).strip()],
            "break_conditions": [str(x) for x in broken if str(x).strip()],
            "target_action": _text(raw.get("target_action"), "target_action"),
            "status": "mapped",
        }
        operator = raw.get("operator")
        if operator is not None:
            if not isinstance(operator, dict):
                raise ValueError("transfer operator must be an object")
            steps = operator.get("steps") or []
            raw_cost = operator.get("cost_hint", 0.1)
            if isinstance(raw_cost, bool):
                raise ValueError("transfer operator cost_hint must be a finite nonnegative number")
            try:
                cost_hint = float(raw_cost)
            except (TypeError, ValueError, OverflowError) as exc:
                raise ValueError("transfer operator cost_hint must be a finite nonnegative number") from exc
            spec = OperatorSpec(
                operator_id=_text(operator.get("operator_id"), "operator_id"),
                input_schema=str(operator.get("input_schema") or "proposed_structure"),
                output_schema=str(operator.get("output_schema") or "proposed_structure"),
                applicability=tuple(str(x) for x in operator.get("applicability", preserved or ["target mapping applies"])),
                transformation_claim=_text(operator.get("transformation_claim") or result["target_action"], "transformation_claim"),
                verifier=str(operator.get("verifier") or "executed data edit changes the proposed structure as claimed"),
                cost_hint=cost_hint,
                origin=str(operator.get("origin") or f"cross_domain_transfer:{transfer_id}"),
                steps=tuple(deepcopy(steps)),
            )
            result["operator"] = validate_generated_operator(spec)
            result["status"] = "compiled"
        compiled.append(result)
    return compiled


def transfer_operator_specs(plans):
    return tuple(row["operator"] for row in compile_transfer_plans(plans) if row.get("status") == "compiled")
