"""Compile a finite design space by executing declarative JSON interventions.

This pure, deterministic stdlib compiler produces structural alternatives, not
creativity, truth, usefulness, policy, or semantic novelty scores. The host still
owns meaningful mechanism proposals, preservation of user intent, evidence, and
the material realization of a selected structure. No source strings are executed.
``exhausted`` covers only the declared moves and configured combination depth.
"""

from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
import json
import math

from ..operators.generated import apply_generated_operator
from ..operators.spec import OperatorSpec


def _json(value, label="value"):
    """Require genuine finite JSON values, including string-only object keys."""
    pending = [value]
    while pending:
        item = pending.pop()
        if item is None or type(item) in (str, bool, int):
            continue
        if type(item) is float and math.isfinite(item):
            continue
        if type(item) is list:
            pending.extend(item)
        elif type(item) is dict and all(type(key) is str for key in item):
            pending.extend(item.values())
        else:
            raise ValueError(f"{label} must contain only finite JSON values")
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"), allow_nan=False)
    except (ValueError, TypeError, RecursionError) as exc:
        raise ValueError(f"{label} must be acyclic, serializable JSON") from exc


def _path(value, label):
    if type(value) is not list or not value:
        raise ValueError(f"{label} must be a nonempty JSON path list")
    if any(not (type(part) is str or (type(part) is int and part >= 0))
           for part in value):
        raise ValueError(f"{label} segments must be strings or nonnegative integers")
    return tuple(value)


def _overlap(left, right):
    return left[:len(right)] == right or right[:len(left)] == left


def _get(structure, path):
    value = structure
    for key in path:
        if type(value) is dict and type(key) is str:
            value = value[key]
        elif type(value) is list and type(key) is int and 0 <= key < len(value):
            value = value[key]
        else:
            raise KeyError(path)
    return value


def _step_footprint(structure, step):
    """Validate actual addresses; list deletion also affects later indices."""
    path = tuple(step["path"])
    parent = _get(structure, path[:-1])
    key = path[-1]
    if type(parent) is dict and type(key) is str:
        exists = key in parent
    elif type(parent) is list and type(key) is int and 0 <= key < len(parent):
        exists = True
    else:
        raise KeyError(path)
    if step["op"] != "set" and not exists:
        raise KeyError(path)
    if step["op"] in {"append", "insert", "merge", "exchange", "move"}:
        target = _get(structure, path)
        if step["op"] == "merge":
            if type(target) is not dict:
                raise ValueError("merge requires an object target")
        elif type(target) is not list:
            raise ValueError("append/insert/exchange/move require a list target")
        if step["op"] == "exchange" and any(index >= len(target) for index in step.get("indices", [0, 1])):
            raise ValueError("exchange indices must exist")
        if step["op"] == "insert":
            index=step.get("index")
            if type(index) is not int or not 0 <= index <= len(target):
                raise ValueError("insert index must be within list insertion bounds")
        if step["op"] == "move":
            left,right=step.get("from_index"),step.get("to_index")
            if type(left) is not int or type(right) is not int or not 0 <= left < len(target) or not 0 <= right <= len(target):
                raise ValueError("move indices must address the list")
    if step["op"] == "delete" and type(parent) is list:
        return path[:-1]
    return path


def _validate(spec):
    if type(spec) is not dict:
        raise ValueError("design space must be an object")
    extra = set(spec) - {"base", "protected_paths", "moves", "max_combination", "max_variants", "max_attempts"}
    if extra:
        raise ValueError(f"unknown design space fields: {sorted(extra)}")
    if type(spec.get("base")) is not dict:
        raise ValueError("base must be a JSON object")
    # Serialization checks cycles before the iterative JSON type walk.
    try:
        json.dumps(spec, allow_nan=False)
    except (TypeError, ValueError, RecursionError) as exc:
        raise ValueError("design space must be finite, acyclic JSON") from exc
    _json(spec, "design space")
    depth = spec.get("max_combination")
    limit = spec.get("max_variants")
    attempts = spec.get("max_attempts")
    if depth is not None and (type(depth) is not int or depth < 1):
        raise ValueError("max_combination must be a positive integer when explicitly supplied")
    if limit is not None and (type(limit) is not int or limit < 1):
        raise ValueError("max_variants must be a positive integer when explicitly supplied")
    if attempts is not None and (type(attempts) is not int or attempts < 1):
        raise ValueError("max_attempts must be a positive integer when explicitly supplied")
    protected = spec.get("protected_paths", [])
    if type(protected) is not list:
        raise ValueError("protected_paths must be a list")
    protected = tuple(_path(path, "protected path") for path in protected)
    for path in protected:
        try:
            _get(spec["base"], path)
        except KeyError as exc:
            raise ValueError(f"protected path does not exist in base: {list(path)}") from exc
    moves = spec.get("moves")
    if type(moves) is not list:
        raise ValueError("moves must be a list")
    ids = set()
    for move in moves:
        if type(move) is not dict or set(move) - {
                "id", "mechanism", "steps", "incompatible_with", "requires"}:
            raise ValueError("move fields are id, mechanism, steps, incompatible_with, requires")
        identifier = move.get("id")
        if type(identifier) is not str or not identifier.strip() or identifier != identifier.strip():
            raise ValueError("move id must be a nonempty, trimmed string")
        if identifier in ids:
            raise ValueError(f"duplicate move id: {identifier}")
        ids.add(identifier)
        if type(move.get("mechanism")) is not str or not move["mechanism"].strip():
            raise ValueError("each move needs a nonempty mechanism description")
        steps = move.get("steps")
        if type(steps) is not list or not steps:
            raise ValueError("each move needs a nonempty steps list")
        for step in steps:
            if type(step) is not dict or step.get("op") not in {"set", "delete", "append", "insert", "merge", "exchange", "move"}:
                raise ValueError("steps require a supported deterministic structural edit")
            allowed = {"op", "path"}
            if step["op"] in {"set", "append", "insert", "merge"}:
                allowed.add("value")
                if "value" not in step:
                    raise ValueError(f"{step['op']} requires value")
            if step["op"] == "insert":
                allowed.add("index")
                if type(step.get("index")) is not int or step["index"] < 0:
                    raise ValueError("insert index must be a nonnegative integer")
            if step["op"] == "merge" and type(step.get("value")) is not dict:
                raise ValueError("merge value must be an object")
            if step["op"] == "exchange":
                allowed.add("indices")
                indices = step.get("indices", [0, 1])
                if type(indices) is not list or len(indices) != 2 or any(
                        type(index) is not int or index < 0 for index in indices):
                    raise ValueError("exchange indices must be two nonnegative integers")
            if step["op"] == "move":
                allowed.update({"from_index","to_index"})
                if any(type(step.get(k)) is not int or step[k] < 0 for k in ("from_index","to_index")):
                    raise ValueError("move indices must be nonnegative integers")
            if set(step) - allowed:
                raise ValueError(f"unknown fields for {step['op']} step")
            _path(step.get("path"), "step path")
        incompatible = move.get("incompatible_with", [])
        if type(incompatible) is not list or any(type(item) is not str for item in incompatible):
            raise ValueError("incompatible_with must be a list of move ids")
        requires = move.get("requires", [])
        if type(requires) is not list:
            raise ValueError("requires must be a list")
        for requirement in requires:
            if type(requirement) is not dict or set(requirement) != {"path", "eq"}:
                raise ValueError("each requirement needs exactly path and eq")
            _path(requirement["path"], "requirement path")
    for move in moves:
        unknown = set(move.get("incompatible_with", [])) - ids
        if unknown:
            raise ValueError(f"unknown incompatible move ids: {sorted(unknown)}")
        if move["id"] in move.get("incompatible_with", []):
            raise ValueError("a move cannot be incompatible with itself")
    return protected, (len(moves) if depth is None else depth), limit, attempts


def _changed_paths(before, after, path=()):
    if _json(before) == _json(after):
        return []
    if type(before) is dict and type(after) is dict:
        result = []
        for key in sorted(set(before) | set(after)):
            if key not in before or key not in after:
                result.append(path + (key,))
            else:
                result.extend(_changed_paths(before[key], after[key], path + (key,)))
        return result
    if type(before) is list and type(after) is list and len(before) == len(after):
        result = []
        for index, (left, right) in enumerate(zip(before, after)):
            result.extend(_changed_paths(left, right, path + (index,)))
        return result
    return [path]


def _select(variants, limit):
    """Return every variant unless the caller explicitly requests a scheduling window."""
    if limit is None:
        return list(variants)
    buckets = {}
    for index, variant in enumerate(variants):
        buckets.setdefault(len(variant["move_ids"]), []).append((index, variant))
    selected, selected_sets, seen_paths = [], [], set()
    while len(selected) < limit and any(buckets.values()):
        for size in sorted(buckets):
            bucket = buckets[size]
            if not bucket or len(selected) >= limit:
                continue

            def rank(item):
                index, variant = item
                paths = {tuple(path) for path in variant["changed_paths"]}
                distance = min((Fraction(len(paths ^ previous), len(paths | previous))
                                for previous in selected_sets), default=Fraction(1))
                return distance, len(paths - seen_paths), len(paths), -index

            chosen = max(bucket, key=rank)
            bucket.remove(chosen)
            variant = chosen[1]
            selected.append(variant)
            paths = {tuple(path) for path in variant["changed_paths"]}
            selected_sets.append(paths)
            seen_paths.update(paths)
    return selected


def compile_space(spec):
    """Execute declarative move combinations without mutating ``spec``.

    ``max_combination`` and ``max_variants`` are open positive budgets rather than
    architecture ceilings. ``max_attempts`` is the explicit per-call execution
    resource boundary, so adding new moves or deeper compositions does not require
    changing the runtime's ontology. Each move has id, mechanism, steps and optional incompatible_with ids
    and requires [{path: [...], eq: JSON value}]. Paths use string object keys or
    nonnegative integer list indices. Preconditions are checked when each move
    starts; moves execute in declaration order. Malformed schemas raise
    ValueError before exploration. Valid but inapplicable combinations are
    reported in rejected. Omitted count covers unique valid structures not
    selected, separately from rejected duplicate/unchanged combinations.
    """
    protected, depth, limit, max_attempts = _validate(spec)
    base = deepcopy(spec["base"])
    base_json = _json(base)
    base_hash = sha256(base_json.encode("utf-8")).hexdigest()
    baseline = {"id": "baseline", "structure": deepcopy(base), "move_ids": [],
                "mechanisms": [], "changed_paths": [], "steps": [],
                "structure_hash": base_hash, "basis": "input_copy"}
    seen = {base_json}
    variants, rejected, attempted = [], [], 0
    capped = False
    moves = deepcopy(spec["moves"])
    for size in range(1, min(depth, len(moves)) + 1):
        for group in combinations(moves, size):
            if max_attempts is not None and attempted >= max_attempts:
                capped = True
                break
            attempted += 1
            move_ids = [move["id"] for move in group]
            reason = None
            if any(set(move.get("incompatible_with", [])) & set(move_ids) for move in group):
                reason = "incompatible_moves"
            current, prior_paths, executed_steps = deepcopy(base), [], []
            if reason is None:
                for move in group:
                    for requirement in move.get("requires", []):
                        try:
                            matches = _json(_get(current, requirement["path"])) == _json(requirement["eq"])
                        except KeyError:
                            matches = False
                        if not matches:
                            reason = "requirement_not_met"
                            break
                    if reason:
                        break
                    move_paths = []
                    for step in move["steps"]:
                        path = tuple(step["path"])
                        if any(_overlap(path, saved) for saved in protected):
                            reason = "protected_path_overlap"
                            break
                        if any(_overlap(path, previous) for previous in prior_paths):
                            reason = "overlapping_move_edits"
                            break
                        try:
                            footprint = _step_footprint(current, step)
                            if any(_overlap(footprint, saved) for saved in protected):
                                reason = "protected_path_overlap"
                                break
                            if any(_overlap(footprint, previous) for previous in prior_paths):
                                reason = "overlapping_move_edits"
                                break
                            operator = OperatorSpec(
                                operator_id=move["id"], input_schema="JSON structure",
                                output_schema="Edited JSON structure", applicability=(),
                                transformation_claim=move["mechanism"],
                                verifier="Observe exact JSON edits and protected path equality",
                                cost_hint=0.0, origin="design_space", steps=(step,))
                            current = apply_generated_operator(operator, current)["structure"]
                            # Equal JSON values are required even across type changes.
                            if any(_json(_get(current, saved)) != _json(_get(base, saved))
                                   for saved in protected):
                                reason = "protected_value_changed"
                                break
                        except (KeyError, IndexError, TypeError, ValueError, AttributeError):
                            reason = "inapplicable_edit"
                            break
                        move_paths.append(footprint)
                        executed_steps.append(deepcopy(step))
                    if reason:
                        break
                    prior_paths.extend(move_paths)
            if reason:
                rejected.append({"move_ids": move_ids, "reason": reason})
                continue
            canonical = _json(current)
            if canonical in seen:
                rejected.append({"move_ids": move_ids,
                                 "reason": "unchanged_structure" if canonical == base_json else "duplicate_structure"})
                continue
            seen.add(canonical)
            digest = sha256(canonical.encode("utf-8")).hexdigest()
            variants.append({"id": "variant_" + digest,
                             "move_ids": move_ids,
                             "mechanisms": [move["mechanism"] for move in group],
                             "structure": current,
                             "changed_paths": [list(path) for path in _changed_paths(base, current)],
                             "steps": executed_steps, "structure_hash": digest,
                             "basis": "executed_data_edits"})
        if capped:
            break
    selected = _select(variants, limit)
    exhausted = not capped
    return {"baseline": baseline, "variants": selected, "rejected": rejected,
            "attempted": attempted, "max_attempts": max_attempts, "exhausted": exhausted,
            "omitted_count": len(variants) - len(selected),
            "continuation_hint": None if exhausted else "continue from the preserved variants or explicitly widen the caller-owned scheduling window"}
