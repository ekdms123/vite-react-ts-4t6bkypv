from __future__ import annotations
from contextlib import closing
from pathlib import Path
import math
import sqlite3

def _finite_score(value, default=0.0):
    if isinstance(value, bool):
        return float(default)
    try:
        number = float(value if value is not None else 0.0)
    except (TypeError, ValueError, OverflowError):
        return float(default)
    return number if math.isfinite(number) else float(default)


def trajectory_credit(runtime) -> dict:
    """Credit only observable execution consequences and explicit feedback.

    A semantic epoch receives no positive score merely for existing. Routes,
    tools and registered extensions earn mechanical credit from observation/material binding;
    user feedback is stored separately by ``CreditStore.update``.
    """
    epochs=[x for x in runtime.extensions.get("semantic_epochs",[]) if isinstance(x,dict)]
    routes={}
    for epoch in epochs:
        if epoch.get("kind")!="compile": continue
        for rid in epoch.get("route_ids",[]) or []:
            if rid: routes[str(rid)]=0.0
    selected=set()
    decision=runtime.extensions.get("decision_state",{}) or {}
    last_delta=decision.get("last_delta",{}) if isinstance(decision,dict) else {}
    if isinstance(last_delta,dict):
        for key in ("selected_route_id","chosen_route_id","route_id"):
            if last_delta.get(key): selected.add(str(last_delta[key]))
    for rid in routes:
        routes[rid]=1.0 if rid in selected else 0.0

    tool_rows=[x for x in runtime.extensions.get("tool_submissions",[]) if isinstance(x,dict)]
    tools={str(x.get("operation")):0.2 for x in tool_rows if x.get("operation")}
    integrations={str(x):0.2 for x in runtime.extensions.get("integration_ids_used",[]) if str(x)}
    search=runtime.extensions.get("search_adaptation",{}) or {}
    search_nodes=(search.get("nodes",{}) or {}).values() if isinstance(search.get("nodes",{}),dict) else []
    search_components={str(x.get("mechanism","search")):0.25 for x in search_nodes if isinstance(x,dict) and x.get("status") in {"observed","interpreted"}}

    material_bound=bool(runtime.answer is not None and not runtime.extensions.get("unresolved"))
    residual=bool(runtime.extensions.get("judgment_plane",{}).get("residuals"))
    components={"routes":routes,"tools":tools,"integrations":integrations,"search_mechanisms":search_components}
    vectors={}
    for kind,items in components.items():
        vectors[kind]={iid:{
            "selection_survival":1.0 if (kind=="routes" and iid in selected) else 0.0,
            "evidence_binding":1.0 if kind in {"tools","integrations","search_mechanisms"} else 0.0,
            "novelty":0.5 if kind in {"routes","search_mechanisms"} else 0.1,
            "execution_cost":1.0 if kind in {"tools","integrations"} else 0.25,
            "dominated":0.0,
        } for iid in items}
    return {
        "version":4,
        "signals":{"semantic_epochs":len(epochs),"tool_observations":len(tool_rows),
                   "material_bound":material_bound,"residual_available":residual},
        "components":components,"component_vectors":vectors,
    }


_VECTOR_COLUMNS=("selection_score","evidence_score","novelty_score","cost_score","dominated_score")


class CreditStore:
    """Multi-axis trajectory credit with a Pareto-preserving selection view."""
    def __init__(self, root):
        root=Path(root); root.mkdir(parents=True,exist_ok=True); self.db_path=root/"credit.sqlite3"
        with closing(sqlite3.connect(self.db_path)) as c,c:
            c.execute("CREATE TABLE IF NOT EXISTS component_credit(kind TEXT,id TEXT,score REAL NOT NULL DEFAULT 0,uses INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(kind,id))")
            cols={row[1] for row in c.execute("PRAGMA table_info(component_credit)")}
            migrations={
                "mechanical_score":"REAL NOT NULL DEFAULT 0","user_score":"REAL NOT NULL DEFAULT 0","feedbacks":"INTEGER NOT NULL DEFAULT 0",
                "selection_score":"REAL NOT NULL DEFAULT 0","evidence_score":"REAL NOT NULL DEFAULT 0","novelty_score":"REAL NOT NULL DEFAULT 0",
                "cost_score":"REAL NOT NULL DEFAULT 0","dominated_score":"REAL NOT NULL DEFAULT 0",
            }
            for name,decl in migrations.items():
                if name not in cols: c.execute(f"ALTER TABLE component_credit ADD COLUMN {name} {decl}")

    @staticmethod
    def _vec(credit,kind,iid):
        raw=(((credit.get("component_vectors") or {}).get(kind) or {}).get(str(iid)) or {})
        return {
            "selection":_finite_score(raw.get("selection_survival",0.0)),
            "evidence":_finite_score(raw.get("evidence_binding",0.0)),
            "novelty":_finite_score(raw.get("novelty",0.0)),
            "cost":_finite_score(raw.get("execution_cost",0.0)),
            "dominated":_finite_score(raw.get("dominated",0.0)),
        }

    def update(self, credit:dict, helpful:bool|None=None):
        if helpful is not None and not isinstance(helpful, bool):
            raise ValueError("helpful must be boolean or None")
        with closing(sqlite3.connect(self.db_path)) as c,c:
            for kind,items in (credit.get("components") or {}).items():
                for iid,raw in (items or {}).items():
                    raw=_finite_score(raw); iid=str(iid); v=self._vec(credit,kind,iid)
                    c.execute("INSERT OR IGNORE INTO component_credit(kind,id,score,uses,mechanical_score,user_score,feedbacks,selection_score,evidence_score,novelty_score,cost_score,dominated_score) VALUES(?,?,0,0,0,0,0,0,0,0,0,0)",(kind,iid))
                    if helpful is None:
                        c.execute("""UPDATE component_credit SET mechanical_score=mechanical_score+?,uses=uses+1,
                            selection_score=selection_score+?,evidence_score=evidence_score+?,novelty_score=novelty_score+?,
                            cost_score=cost_score+?,dominated_score=dominated_score+? WHERE kind=? AND id=?""",
                            (raw,v["selection"],v["evidence"],v["novelty"],v["cost"],v["dominated"],kind,iid))
                    else:
                        # Explicit feedback is the strongest channel. Every
                        # actually-used component receives a bounded share so a
                        # zero mechanical score does not erase user preference.
                        share=max(.20,min(2.0,abs(raw)+.20))
                        c.execute("UPDATE component_credit SET user_score=user_score+?,feedbacks=feedbacks+1 WHERE kind=? AND id=?",
                                  ((1.0 if helpful else -1.0)*share,kind,iid))
                    c.execute("""UPDATE component_credit SET score=
                        (CASE WHEN feedbacks>0 THEN 2.5*user_score/feedbacks ELSE 0 END)+
                        (CASE WHEN uses>0 THEN 1.15*selection_score/uses + .35*evidence_score/uses + .25*novelty_score/uses - .10*cost_score/uses - .35*dominated_score/uses ELSE 0 END)
                        WHERE kind=? AND id=?""",(kind,iid))
        return self.snapshot()

    @staticmethod
    def _mark_pareto(rows):
        by_kind={}
        for r in rows: by_kind.setdefault(r["kind"],[]).append(r)
        for group in by_kind.values():
            for r in group:
                a=(r["user_mean"],r["selection_mean"],r["evidence_mean"],r["novelty_mean"],-r["cost_mean"],-r["dominated_mean"])
                dominated=False
                for o in group:
                    if o is r: continue
                    b=(o["user_mean"],o["selection_mean"],o["evidence_mean"],o["novelty_mean"],-o["cost_mean"],-o["dominated_mean"])
                    if all(y>=x for x,y in zip(a,b)) and any(y>x for x,y in zip(a,b)):
                        dominated=True; break
                r["pareto_nondominated"]=not dominated
        return rows

    def snapshot(self, limit=None):
        if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit < 1):
            raise ValueError("limit must be a positive integer when explicitly supplied")
        query = """SELECT kind,id,score,uses,mechanical_score,user_score,feedbacks,
                selection_score,evidence_score,novelty_score,cost_score,dominated_score
                FROM component_credit ORDER BY score DESC,feedbacks DESC,uses DESC"""
        params = ()
        if limit is not None:
            query += " LIMIT ?"
            params = (int(limit),)
        with closing(sqlite3.connect(self.db_path)) as c:
            rows=c.execute(query, params).fetchall()
        out=[]
        for k,i,s,u,m,us,f,sel,ev,nov,cost,dom in rows:
            den=max(1,int(u)); fden=max(1,int(f))
            out.append({"kind":k,"id":i,"score":s,"uses":u,"mechanical_score":m,"user_score":us,"feedbacks":f,
                        "user_mean":us/fden if f else 0.0,"selection_mean":sel/den,"evidence_mean":ev/den,
                        "novelty_mean":nov/den,"cost_mean":cost/den,"dominated_mean":dom/den})
        return self._mark_pareto(out)
