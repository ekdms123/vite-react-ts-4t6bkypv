"""Public 지개월 command-line entrypoint."""
from jigaewol_run import main

if __name__ == "__main__":
    main()
