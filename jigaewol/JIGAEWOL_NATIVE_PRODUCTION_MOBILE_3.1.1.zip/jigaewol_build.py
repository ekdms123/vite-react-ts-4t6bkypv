"""Wheel builder preserving the ZIP's sealed executable/data membership."""
from pathlib import Path
from shutil import copy2
from setuptools.command.build_py import build_py

class BuildPy(build_py):
    def run(self):
        super().run()
        source = Path(__file__).resolve().parent
        import sys
        sys.path.insert(0,str(source))
        from tools.build_zip import personal_files
        for name in personal_files(source):
            target = Path(self.build_lib)/name
            target.parent.mkdir(parents=True,exist_ok=True)
            copy2(source/name,target)
