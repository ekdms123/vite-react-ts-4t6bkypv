from __future__ import annotations
import argparse, json
from pathlib import Path
from jigaewol_core import CoreRuntime, architecture_snapshot
from jigaewol_core.canonical_entrypoint import admit_exact_user_message

def main():
    p=argparse.ArgumentParser(description="JIGAEWOL V2 strict-ingress + live operational status bootstrap")
    p.add_argument("command", nargs="?", default="diagnose the runtime")
    p.add_argument("--state", default=".jigaewol_v2_state")
    p.add_argument("--user", default="user")
    p.add_argument("--project", default="project")
    p.add_argument("--session", default="chat")
    p.add_argument("--architecture", action="store_true")
    p.add_argument("--stream", action="store_true", help="stream public runtime phase/tool/receipt events")
    args=p.parse_args()
    if args.architecture:
        print(json.dumps(architecture_snapshot(),ensure_ascii=False,indent=2))
        return
    def listener(row):
        if args.stream:
            print(json.dumps({"runtime_event":row},ensure_ascii=False,default=str),flush=True)
    admission = admit_exact_user_message(
        state_root=Path(args.state), raw_message_bytes=args.command.encode("utf-8"),
        user_id=args.user, project_id=args.project, session_id=args.session,
        origin_ref="local:jigaewol_bootstrap:new_user_message",
    )
    rt=CoreRuntime(
        Path(args.state),user_id=args.user,project_id=args.project,session_id=args.session,trace_listener=listener,
        require_gateway_turn=True, gateway_envelope=admission["gateway_envelope"],
    )
    turn=rt.ingress(args.command)
    snapshot=turn.public_snapshot()
    snapshot["runtime_turn_id"] = turn.core_turn_id
    status = rt.status(turn)
    print(json.dumps({"turn":snapshot,"runtime_status":status},ensure_ascii=False,indent=2,default=str))

if __name__ == "__main__": main()
