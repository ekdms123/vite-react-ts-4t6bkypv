from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path
from typing import Any

from jigaewol_core import CoreRuntime, PUBLIC_RUNTIME_ID
from jigaewol_core.canonical_entrypoint import admit_exact_user_message

def load_callable(spec: str | None):
    if not spec:
        return None
    if ":" not in spec:
        raise ValueError("adapter must be module:function")
    module_name, func_name = spec.split(":", 1)
    module = importlib.import_module(module_name)
    fn = getattr(module, func_name)
    if not callable(fn):
        raise TypeError(spec + " is not callable")
    return fn

def main():
    p=argparse.ArgumentParser(description="지개월 Quiet Kernel + Exploration Escalation operational loop")
    p.add_argument("command")
    p.add_argument("--state", default=".jigaewol_state")
    p.add_argument("--user", default="user")
    p.add_argument("--project", default="project")
    p.add_argument("--session", default="chat")
    p.add_argument("--generator", help="Python model/solver adapter as module:function")
    p.add_argument("--executor", help="Python host-work adapter as module:function")
    p.add_argument("--capabilities-json", help="JSON file containing currently exposed callable capability specs")
    p.add_argument("--latency-target-ms", type=int, default=2500)
    p.add_argument("--max-host-steps", type=int, default=None,
                   help="cap host-work steps; default is derived from the resource envelope")
    p.add_argument("--host-unavailable", choices=("raise", "preserve_open"), default="raise",
                   help="what to do when host work is still pending and nothing can run it. "
                        "raise keeps the turn resumable for a caller that can connect a host; "
                        "preserve_open returns an explicit incomplete state without generating "
                        "a downgraded answer from unexecuted work")
    p.add_argument("--quiet-trace", action="store_true")
    args=p.parse_args()
    capabilities=()
    if args.capabilities_json:
        capabilities=json.loads(Path(args.capabilities_json).read_text(encoding="utf-8"))
    def stream(row: dict[str,Any]):
        if not args.quiet_trace:
            print(json.dumps({"runtime_event":row},ensure_ascii=False,default=str), flush=True)
    admission = admit_exact_user_message(
        state_root=Path(args.state), raw_message_bytes=args.command.encode("utf-8"),
        user_id=args.user, project_id=args.project, session_id=args.session,
        origin_ref="local:jigaewol_run:new_user_message",
    )
    rt=CoreRuntime(
        Path(args.state), user_id=args.user, project_id=args.project, session_id=args.session,
        capabilities=capabilities, candidate_generator=load_callable(args.generator),
        latency_target_ms=args.latency_target_ms, trace_listener=stream,
        require_gateway_turn=True, gateway_envelope=admission["gateway_envelope"],
        require_finalization_permit=True,
    )
    result=rt.run_turn(args.command, capabilities=capabilities, host_executor=load_callable(args.executor),
                       max_host_steps=args.max_host_steps, host_unavailable=args.host_unavailable)
    released=result["released"]
    print(json.dumps({
        "runtime":PUBLIC_RUNTIME_ID,
        "status":"released",
        "body":getattr(released,"body",None),
        "trace":result["trace"],
        "trace_digest":result["trace_digest"],
    },ensure_ascii=False,indent=2,default=str))

if __name__ == "__main__": main()
