"""Hostless/mobile adapters for the JIGAEWOL personal runtime.

These adapters preserve execution truth: model_handoff emits a structured brief rather
than pretending to be a final semantic answer, while local_host rejects work it cannot
actually execute. They intentionally require no external model API.
"""
from __future__ import annotations

import json
from typing import Any, Mapping

HANDOFF_MARKER = "[JIGAEWOL_MODEL_HANDOFF]"


def _plain(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_plain(v) for v in value]
    if hasattr(value, "__dict__"):
        return {str(k): _plain(v) for k, v in vars(value).items() if not str(k).startswith("_")}
    return str(value)


def model_handoff(request: Any) -> str:
    """Return a model-facing brief, never fake final prose.

    The outer/host model is expected to read this brief and perform semantic generation.
    No network or external paid model API is invoked here.
    """
    objective = str(getattr(request, "objective", "") or "")
    contract = _plain(getattr(request, "response_contract", {}) or {})
    evidence = _plain(getattr(request, "evidence", {}) or {})
    worlds = _plain(getattr(request, "cognitive_worlds", ()) or ())
    payload = {
        "objective": objective,
        "execution_profile": str(getattr(request, "execution_profile", "DEEP") or "DEEP"),
        "response_contract": contract,
        "evidence": evidence,
        "cognitive_worlds": worlds,
        "instruction": "Host model: write the actual answer. Preserve open requirements and do not convert unexecuted work into success.",
    }
    return HANDOFF_MARKER + "\n" + json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)


def is_handoff(value: Any) -> bool:
    return str(value or "").lstrip().startswith(HANDOFF_MARKER)


def local_host(work: Any) -> Any:
    """Keep work explicitly unexecuted when no real host actuator exists."""
    name = (
        getattr(work, "executor", None)
        or getattr(work, "action", None)
        or getattr(work, "work_id", None)
        or getattr(work, "id", None)
        or type(work).__name__
    )
    raise LookupError(f"THIS_HOST_PATH_REJECTED:{name!s}:work_remains_live_and_unexecuted")


def fixed_answer(text: str):
    """Return a deterministic generator for tests/replay."""
    body = str(text)
    def generate(_request: Any) -> str:
        return body
    return generate


def make_writer(bodies: Mapping[str, Any]):
    """Deterministic tournament writer keyed by frame_id."""
    rows = dict(bodies)
    def writer(frame: Mapping[str, Any], _context: Mapping[str, Any]):
        frame_id = str(frame.get("frame_id") or "")
        return rows.get(frame_id, "")
    return writer


def make_refuter(objections: Mapping[str, Mapping[str, Any]]):
    """Deterministic refuter keyed by attacker frame_id.

    Each configured frame carries the objection it raises against the next tournament
    target, matching the runtime chassis fixtures.
    """
    rows = {str(k): dict(v) for k, v in objections.items()}
    def refuter(attacker: Mapping[str, Any], _target: Mapping[str, Any], _context: Mapping[str, Any]):
        return rows.get(str(attacker.get("frame_id") or ""))
    return refuter
