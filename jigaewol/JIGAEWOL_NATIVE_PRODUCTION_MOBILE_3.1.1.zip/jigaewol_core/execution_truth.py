from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class ExecutionOutcome:
    executed: bool
    successful: bool | None
    exit_state: str
    failure_family: str | None
    evidence: dict[str, Any]


_FAILURE_STATUSES = {"fail", "failed", "failure", "error", "errored", "cancelled", "canceled", "timeout", "timed_out"}
_SUCCESS_STATUSES = {"ok", "success", "succeeded", "complete", "completed", "passed"}
_EXIT_KEYS = ("exit_code", "returncode", "return_code")
_BOOL_KEYS = ("success", "ok")
_NEST_KEYS = ("output", "result", "execution", "process", "response")


def _walk_mapping(value: Any):
    if not isinstance(value, Mapping):
        return
    yield value
    for key in _NEST_KEYS:
        child = value.get(key)
        if isinstance(child, Mapping):
            yield from _walk_mapping(child)


def classify_execution_result(result: Any, error: BaseException | None = None) -> ExecutionOutcome:
    """Classify execution truth without collapsing indeterminate outcomes into success or failure."""
    if error is not None:
        return ExecutionOutcome(
            executed=True,
            successful=False,
            exit_state=f"exception:{type(error).__name__}",
            failure_family=type(error).__name__,
            evidence={"error": str(error)[:1200]},
        )

    mappings = tuple(_walk_mapping(result) or ())
    exit_rows: list[tuple[str, int]] = []
    indeterminate_exit_keys: list[str] = []
    explicit_false = False
    explicit_true = False
    failed_status: str | None = None
    success_status: str | None = None

    for row in mappings:
        for key in _EXIT_KEYS:
            if key in row:
                try:
                    if row[key] is None:
                        indeterminate_exit_keys.append(key)
                    else:
                        exit_rows.append((key, int(row[key])))
                except (TypeError, ValueError):
                    indeterminate_exit_keys.append(key)
        for key in _BOOL_KEYS:
            if isinstance(row.get(key), bool):
                explicit_true = explicit_true or bool(row[key])
                explicit_false = explicit_false or not bool(row[key])
        status = row.get("status")
        if isinstance(status, str):
            normalized = status.strip().casefold()
            if normalized in _FAILURE_STATUSES:
                failed_status = normalized
            elif normalized in _SUCCESS_STATUSES:
                success_status = normalized

    for key, code in exit_rows:
        if code != 0:
            return ExecutionOutcome(True, False, f"exit_code:{code}", "nonzero_exit", {"exit_key": key, "exit_code": code})
    if explicit_false:
        return ExecutionOutcome(True, False, "explicit_success:false", "explicit_failure", {"explicit_success": False})
    if failed_status is not None:
        return ExecutionOutcome(True, False, f"status:{failed_status}", "failed_status", {"status": failed_status})
    if exit_rows:
        key, code = exit_rows[0]
        return ExecutionOutcome(True, True, f"exit_code:{code}", None, {"exit_key": key, "exit_code": code})
    if explicit_true:
        return ExecutionOutcome(True, True, "explicit_success:true", None, {"explicit_success": True})
    if success_status is not None:
        return ExecutionOutcome(True, True, f"status:{success_status}", None, {"status": success_status})
    if indeterminate_exit_keys:
        return ExecutionOutcome(True, None, "indeterminate_exit", "indeterminate_execution", {"exit_keys": tuple(indeterminate_exit_keys)})
    return ExecutionOutcome(True, None, "indeterminate_return", "indeterminate_execution", {"normal_return_observed": True, "success_not_proven": True})
