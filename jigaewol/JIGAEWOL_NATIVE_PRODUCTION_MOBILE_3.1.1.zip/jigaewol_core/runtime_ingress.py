from __future__ import annotations
from pathlib import Path

import json
import time
from dataclasses import asdict, replace
from typing import Any, Mapping, TYPE_CHECKING

from jigaewol_components.ambition_preserver import AmbitionPreserver
from jigaewol_components.continuation_context import compose_authoritative_continuation_objective
from jigaewol_components.discourse_scope import DiscourseScopeAnalyzer
from jigaewol_components.effect_planner import EffectRequest
from jigaewol_components.ephemeral_universe import EphemeralUniverseEngine
from jigaewol_components.exploration_escalation import ExplorationState
from jigaewol_components.forensic_runtime_contract import ForensicRuntimeContract
from jigaewol_components.openness_contract import compile_openness_contract
from jigaewol_components.possibility_engine import PossibilityEngine
from jigaewol_components.representation_programs import RepresentationPrograms
from jigaewol_components.representation_tournament import RepresentationTournament
from jigaewol_components.requirement_contract import RequirementCompiler
from jigaewol_components.semantic_authority import SemanticAuthorityCompiler
from jigaewol_components.image_generation_governance import ImageGenerationGovernance
from jigaewol_components.wild_cognitive_plane import WildCognitivePlane
from jigaewol_components.source_directive_compiler import continuity_signal
from jigaewol_components.source_authority import destructive_goal_change_authorized
from jigaewol_components.authority_guard import source_bound_objective, source_effect_authorized
from jigaewol_components.integrated_processing import compile_integrated_processing_packet
from jigaewol_components.strategy_topology import StrategyTopologySelector
from .open_world_intent import extract_open_world_intent
from .resource_policy import derive_resource_envelope
from .turn_profile import classify_turn_profile
from .runtime_helpers import _safe_summary, _sha_text

if TYPE_CHECKING:
    from .runtime import CoreTurn


class CoreRuntimeIngressMixin:
    """Canonical ingress state construction, isolated from the coordinator."""
    def ingress(self, command: str, *, capabilities=None, attachments=(), **kwargs) -> CoreTurn:
        attachments = tuple(attachments or getattr(self, "_host_attachments", ()))
        if not isinstance(command, str) or not command.strip():
            raise ValueError("command must be nonempty text")
        raw_message_bytes = kwargs.pop("raw_message_bytes", None)
        if raw_message_bytes is not None and bytes(raw_message_bytes).decode("utf-8", errors="strict") != command:
            raise ValueError("raw_message_bytes do not decode to the exact command")
        exact_raw_bytes = bytes(raw_message_bytes) if raw_message_bytes is not None else command.encode("utf-8")
        integrated_packet = kwargs.pop("integrated_processing_packet", None)
        if integrated_packet is None:
            integrated_packet = compile_integrated_processing_packet(exact_raw_bytes, direction="user")
        if str(getattr(integrated_packet, "exact_message_sha256", "")) != __import__("hashlib").sha256(exact_raw_bytes).hexdigest():
            raise ValueError("integrated processing packet does not match exact command")
        if str(dict(getattr(integrated_packet, "central_decision", {}) or {}).get("result") or "") != "route_canonical_core":
            raise ValueError("integrated processing central decision did not admit canonical core routing")
        # Every public ingress is sequenced, including programmatic callers. Verify
        # before semantic persistence so an invalid envelope leaves no turn effects.
        if self._auto_admit_gateway_turn:
            from .canonical_entrypoint import admit_exact_user_message
            admission = admit_exact_user_message(
                state_root=self.root, raw_message_bytes=exact_raw_bytes,
                user_id=self.user_id, project_id=self.project_id, session_id=self.session_id,
                origin_ref="local:core_runtime:programmatic_user_message",
                integrated_processing_packet=integrated_packet,
            )
            self.gateway_envelope = dict(admission["gateway_envelope"])
        gateway_proof = self.turn_gateway.verify_for_ingress(self.gateway_envelope, message=command)
        semantic_message = self.semantic_communication.persist_record(
            integrated_packet.semantic_record, exact_source=command, preserve_exact_source=True
        )
        # Canonical normalization may inform search, but never substitute the command
        # driving execution. This avoids changing wording, polarity or emphasis.
        processing_command = command
        unified_envelope = integrated_packet.unified_intent
        unified_ingress = self.unified_intent.persist(
            unified_envelope, component="runtime_ingress", validation_passed=True,
            validation_scope="canonical_runtime_ingress",
            details={"session_id": self.session_id},
        )
        constitution_state = self.meta_constitution.state(
            intent_sha256=unified_envelope.exact_user_message_sha256
        )
        constitution_binding = self.unified_intent.bind_sha(
            unified_envelope.exact_user_message_sha256, component="constitution",
            validation_passed=True, validation_scope="runtime_invariant_governance",
            details={"generation": int(constitution_state.get("generation", 1))},
        )

        # Continuity is a relationship between source-grounded clause graphs.  The
        # ingress no longer invents restoration from friction/correction heuristics.
        # It consumes the federation's directive compiler + continuity linker and
        # keeps the prior objective out-of-band except for a truly bare continuation.
        continuation_context = dict(kwargs.pop("continuation_context", {}) or {})
        current_clause_graph = self.federation.source_directive.compile(
            command, turn_id=f"current_{_sha_text(command)[:12]}"
        )
        source_relation_present = bool(
            current_clause_graph.has_continuation_reference
            or any(
                clause.discourse_relation in {"corrects", "cancels"}
                for clause in current_clause_graph.clauses
                if not clause.quoted
            )
        )
        current_continuity_signal = continuity_signal(command)
        correction_rebind = any(
            "correction" in str(item) for item in current_continuity_signal.evidence
        )
        if (
            continuation_context.get("restored")
            and current_continuity_signal.mode != "bare"
            and not correction_rebind
        ):
            continuation_context = {
                **continuation_context,
                "restored": False,
                "context_attached": bool(continuation_context.get("objective") or continuation_context.get("prior_objective")),
                "current_directive_is_highest_explicit_authority": True,
                "prior_unfinished_objective_preserved_as_context_only": True,
                "caller_restoration_suppressed_by_current_turn_dominance": True,
            }
        elif continuation_context.get("restored") and not source_relation_present:
            continuation_context = {
                **continuation_context,
                "restored": False,
                "caller_restoration_rejected_without_source_evidence": True,
            }

        if not continuation_context.get("restored"):
            unfinished = self.turn_continuity.unfinished()
            if unfinished and not destructive_goal_change_authorized(command):
                prior_task = unfinished[-1]
                prior_objective = str(prior_task.objective or "")
                prior_clause_graph = self.federation.source_directive.compile(
                    prior_objective, turn_id=str(prior_task.task_id)
                )
                authority_graph = self.federation.continuity.link(
                    previous=prior_clause_graph, current=current_clause_graph
                )
                continuity_edges = tuple(
                    edge for edge in authority_graph.edges
                    if edge.relation in {"CONTINUES", "CORRECTS"}
                )
                if continuity_edges:
                    signal = current_continuity_signal
                    semantic_objective = compose_authoritative_continuation_objective(
                        prior_objective, processing_command, mode=signal.mode
                    )
                    relations = {edge.relation for edge in continuity_edges}
                    correction_rebind = any(
                        "correction" in str(item) for item in signal.evidence
                    ) and "CORRECTS" in relations
                    restore_prior = signal.mode == "bare" or correction_rebind
                    borrow_prior_objective = signal.mode == "bare"
                    continuation_context = {
                        **continuation_context,
                        "restored": restore_prior,
                        "context_attached": True,
                        "task_id": str(prior_task.task_id),
                        "objective": semantic_objective,
                        "prior_objective": prior_objective,
                        "current_directive": command,
                        "current_directive_is_highest_explicit_authority": not borrow_prior_objective,
                        "current_objective_is_exact_current_message": not borrow_prior_objective,
                        "prior_unfinished_objective_preserved_as_context_only": not restore_prior,
                        "restored_by_user_correction": bool(correction_rebind),
                        "correction_message_sha256": _sha_text(command) if "CORRECTS" in relations else "",
                        "continuity_source_evidence": signal.evidence,
                        "source_clause_graph": asdict(current_clause_graph),
                        "authority_graph": asdict(authority_graph),
                        "continuity_edges": tuple(asdict(edge) for edge in continuity_edges),
                        "continuity_model": "clause_graph_edges_v1",
                    }

        # The live directive is always exact. Pending historical work lives in
        # continuation_context; it is never substituted for the current message.
        semantic_command = command

        # Friction remains diagnostic/repair evidence.  It no longer has authority to
        # decide continuity restoration; only graph edges above can do that.
        raw_requirement_contract = RequirementCompiler.compile(command)
        raw_discourse_scope = DiscourseScopeAnalyzer.compile(command, raw_requirement_contract)
        current_directive_text = raw_discourse_scope.current_text or processing_command
        reference_frame_markers = ("설계 문서", "설계도", "아래는", "다음은", "예시", "인용", "blueprint", "specification")
        friction_source_text = (
            raw_discourse_scope.action_text
            if raw_discourse_scope.action_text and any(marker.casefold() in command.casefold() for marker in reference_frame_markers)
            else current_directive_text
        )
        ingress_corrections = self.friction_repair.detect(friction_source_text, source_ref="ingress")

        release_ticket = self.audit.begin(command)
        requirement_contract = raw_requirement_contract
        semantic_contract = (
            requirement_contract if semantic_command == command
            else RequirementCompiler.compile(semantic_command)
        )
        discourse_scope = DiscourseScopeAnalyzer.compile(semantic_command, semantic_contract)
        # Analyze the whole exact current message. Clause views are advisory and
        # must not silently discard source clauses before intent recognition.
        analysis = self.intent_analyzer.analyze(command)
        depth = self._effective_depth(analysis)
        # One typed semantic judgement per exact message, compiled once. Downstream
        # gates may widen on new evidence but must not narrow it by reparsing the raw
        # command with a different marker list. Without this the exploration gate re-decided
        # openness from its own word list, and a word being absent (모아 / 정리 / 키우)
        # silently closed turns the runtime had already judged substantive.
        semantic_authority = SemanticAuthorityCompiler.compile(
            command, requirement_contract, analysis,
            effective_depth=str(depth.get("effective") or "unspecified"),
            semantic_objective=semantic_command,
            continuation_context=continuation_context,
            semantic_contract=semantic_contract,
            discourse_scope=discourse_scope,
        )
        semantic_authority_mapping = semantic_authority.as_mapping()
        semantic_authority_mapping["unified_user_intent"] = unified_envelope.as_mapping()
        semantic_authority_mapping["semantic_communication"] = semantic_message.as_mapping(include_canonical_text=True)
        semantic_authority_mapping["semantic_concept_frame"] = dict(semantic_message.concept_frame)
        semantic_authority_mapping["semantic_concept_sha256"] = semantic_message.concept_sha256
        semantic_authority_mapping["standardized_concept_vector"] = integrated_packet.concept_vector.as_mapping(include_values=True)
        semantic_authority_mapping["integrated_processing_validators"] = [v.as_mapping() for v in integrated_packet.validators]
        semantic_authority_mapping["central_processing_decision"] = dict(integrated_packet.central_decision)
        semantic_authority_mapping["integrated_processing_single_data_path"] = True
        semantic_authority_mapping["unified_intent_persistence"] = unified_ingress
        semantic_authority_mapping["constitution_binding"] = constitution_binding
        frontier_turn_state = self.frontier_control.prepare_turn(
            command,
            requirement_contract=requirement_contract,
            semantic_authority=semantic_authority_mapping,
            observed_capabilities=tuple(str(x) for x in (capabilities or ())),
        ).as_mapping()

        # v2: preserve the exact source event separately from interpretation, then
        # compile the active requirements into an executable Work graph. These are
        # scheduling/execution structures; they do not replace the exact directive.
        source_atoms = tuple(asdict(a) for a in requirement_contract.atoms)
        active_atoms = tuple(asdict(a) for a in semantic_contract.atoms)
        previous_goal_event = self.user_goal_kernel.latest_event()
        provisional_friction = self.friction_repair.detect(friction_source_text, source_ref="pending")
        correction_kinds = {"directive_override", "goal_shrink", "authority_requery", "repeated_approval", "promise_only", "premature_closure", "repeated_bug"}
        is_user_correction = bool(previous_goal_event and any(x.kind in correction_kinds for x in provisional_friction))
        if is_user_correction:
            goal_event = self.user_goal_kernel.apply_correction(
                command,
                corrects_event_id=str(previous_goal_event.get("event_id") or ""),
                raw_bytes=raw_message_bytes,
                requirement_atoms=source_atoms,
            )
        else:
            goal_event = self.user_goal_kernel.ingest(command, raw_bytes=raw_message_bytes, requirement_atoms=source_atoms)
        # A restored semantic objective and the *current correction* are both live.
        # Previously, when continuation restoration replaced ``semantic_command`` with
        # the prior objective, the exact corrective message survived only as metadata/
        # friction.  It was absent from the executable Work graph.  Keep both sources
        # losslessly so "don't shrink it again" cannot paradoxically erase itself.
        work_atoms_list: list[dict[str, Any]] = []
        seen_work_atom_ids: set[str] = set()
        for atom in (*active_atoms, *source_atoms):
            atom_id = str(atom.get("atom_id") or "")
            if atom_id and atom_id in seen_work_atom_ids:
                continue
            if atom_id:
                seen_work_atom_ids.add(atom_id)
            work_atoms_list.append(dict(atom))
        work_atoms = tuple(work_atoms_list)
        active_requirement_refs = tuple(
            str(a.get("atom_id") or "") for a in work_atoms if str(a.get("atom_id") or "")
        )
        previous_work_program = self.work_program_runtime.load_latest()
        incoming_work_program = self.work_program_runtime.compile(
            source_goal_event_id=goal_event.event_id,
            exact_command=command,
            requirement_refs=active_requirement_refs,
            input_refs=(goal_event.raw_sha256,),
            requirement_atoms=work_atoms,
        )
        goal_loss_diff = self.user_goal_kernel.diff_projection_records(
            work_atoms, tuple(asdict(node) for node in incoming_work_program.nodes)
        )
        goal_loss_recovery: dict[str, Any] = {"applied": False}
        if goal_loss_diff.loss_detected:
            # Loss is an input to rewriting, never permission to shrink the goal.
            incoming_work_program = self.work_program_runtime.compile(
                source_goal_event_id=goal_event.event_id, exact_command=command,
                requirement_refs=active_requirement_refs, program_ref="jigaewol:goal_loss_recovery",
                input_refs=(goal_event.raw_sha256,), requirement_atoms=work_atoms,
            )
            repaired = self.user_goal_kernel.diff_projection_records(
                work_atoms, tuple(asdict(node) for node in incoming_work_program.nodes)
            )
            if repaired.loss_detected:
                raise RuntimeError(f"goal projection recovery failed: {repaired.as_mapping()}")
            goal_loss_recovery = {
                "applied": True,
                "reason": "projection_loss",
                "before": goal_loss_diff.as_mapping(),
                "after": repaired.as_mapping(),
            }
        correction_mode = self.work_program_runtime.classify_correction_mode(
            command, correction_detected=is_user_correction
        )
        work_program = self.work_program_runtime.merge_turn(
            previous_work_program, incoming_work_program,
            correction=is_user_correction, correction_mode=correction_mode,
            exact_user_text=command,
        )
        work_program, reactivated_candidates = self.work_program_runtime.reactivate(
            work_program,
            predicate=lambda row: (
                str(row.get("kind") or "") == "improvement_program_candidate"
                and "new_user_message" in set(map(str, row.get("activation_conditions") or ()))
            ),
        )
        repair_rules = self.friction_repair.active_rules()
        work_rule_state = self.friction_repair.apply_runtime_rules({
            "authority_checks_enabled": work_program.authority_checks_enabled,
            "authority_requery_allowed": True,
        })
        work_program = replace(
            work_program,
            # Source authority is structural, not a mutable repair preference.  Generated
            # repair code may tune execution behavior but cannot disable this invariant.
            authority_checks_enabled=True,
            intermediate_narration=(False if work_rule_state.get("dispatch_before_narration") is True else work_program.intermediate_narration),
        )
        self.work_program_runtime.save(work_program)
        projected_refs = tuple(ref for node in work_program.nodes for ref in node.goal_refs if str(ref))
        representation_program = RepresentationPrograms.propose(
            semantic_command,
            requirement_refs=projected_refs,
            pressure=bool(semantic_authority.representation_search_required),
            parent_refs=(goal_event.event_id,),
        )
        representation_program, representation_probe = RepresentationPrograms.run_probe(
            representation_program, source_text=semantic_command, requirement_refs=projected_refs,
        )
        self.representation_lineage.record({
            "representation_id": representation_program.representation_id,
            "goal_event_id": goal_event.event_id,
            "objective_sha256": representation_program.objective_sha256,
            "preservation_contract": representation_program.preservation_contract,
            "probe": representation_probe,
        })
        represented_state = dict(representation_probe.get("represented") or {})
        dynamic_operator = self.operator_builder.propose(
            representation_ref=representation_program.representation_id,
            purpose="advance active Work outside a closed task taxonomy",
            schema={
                "input": representation_program.schema,
                "output": {"state_delta": "mapping", "evidence_refs": "list[str]", "continuation": "opaque_ref|null"},
                "purpose": "advance active Work outside a closed task taxonomy",
                "generated_for": representation_program.representation_id,
            },
            adapter_program={
                "kind": "generated_operation_sequence_v2",
                "operations": (
                    {"op": "set", "path": "operator_applied", "value": "__OPERATOR_ID__"},
                    {"op": "set", "path": "representation_ref", "value": representation_program.representation_id},
                    {"op": "set", "path": "representation_state", "value": represented_state},
                    {"op": "set", "path": "goal_refs", "value": projected_refs},
                ),
            },
        )
        # Bind the generated operator id into its own executable program before it is
        # persisted; the adapter then survives process restart without an in-memory lambda.
        dynamic_program = dict(dynamic_operator.adapter_program or {})
        dynamic_program["operations"] = tuple(
            {**dict(op), "value": dynamic_operator.operator_id if dict(op).get("value") == "__OPERATOR_ID__" else dict(op).get("value")}
            for op in dynamic_program.get("operations") or ()
        )
        dynamic_operator = replace(dynamic_operator, adapter_program=dynamic_program)
        self.operator_builder.register_schema(dynamic_operator)
        interpreter_program = self.interpreter_builder.register(self.interpreter_builder.build(
            representation_ref=representation_program.representation_id,
            operator_ids=(dynamic_operator.operator_id,),
        ))
        interpreter_probe = self.interpreter_builder.run_registered(
            interpreter_program.interpreter_id,
            {"goal_refs": projected_refs, "state": "prepared"},
        )
        interpreter_translation = self.interpreter_builder.translate_result(interpreter_probe)
        friction_events = self.friction_repair.record(friction_source_text, source_ref=goal_event.event_id)
        friction_repairs: list[dict[str, Any]] = []
        # User friction becomes an executable correction: reproduce -> mutate durable
        # runtime rule state -> record repair.  The rule file is read on later turns.
        rules_target = self.root / "friction_repair" / "runtime_rules_seed.json"
        if not rules_target.exists():
            rules_target.write_text("{}\n", encoding="utf-8")
        active_repair_rules = self.friction_repair.active_rules()
        for event in friction_events:
            if event.kind in active_repair_rules:
                continue
            replay = self.friction_repair.reproduce(event)
            cause_candidates = self.friction_repair.locate(
                event, (goal_event.as_mapping(), work_program.as_mapping(), semantic_authority_mapping)
            )
            before_text = rules_target.read_text(encoding="utf-8")
            try:
                before_state = json.loads(before_text or "{}")
                if not isinstance(before_state, dict):
                    raise TypeError("runtime friction rule seed root must be a JSON object")
            except Exception as exc:
                failure_path = rules_target.parent / "runtime_rule_seed_failures.jsonl"
                try:
                    with failure_path.open("a", encoding="utf-8") as fh:
                        fh.write(json.dumps({
                            "observed_at": time.time(),
                            "error_type": type(exc).__name__,
                            "error": str(exc)[:500],
                            "source": str(rules_target),
                            "exact_user_message_sha256": _sha_text(command),
                        }, ensure_ascii=False, sort_keys=True) + "\n")
                except OSError:
                    pass
                raise RuntimeError(
                    f"runtime friction rule seed is unreadable; refusing to erase prior user corrections: "
                    f"{type(exc).__name__}: {exc}"
                ) from exc
            branch_path = self.mutation_runtime.fork_state(
                rules_target, branch_id=f"friction_{event.friction_id}"
            )
            replay_result = self.mutation_runtime.run_work(
                replay, lambda case: {**dict(case), "observed": True, "branch_path": str(branch_path)}
            )
            migrated_state = self.mutation_runtime.migrate(
                before_state,
                lambda state, _event=event: {
                    **dict(state),
                    _event.kind: {
                        "source_ref": _event.source_ref,
                        "friction_id": _event.friction_id,
                        "active": True,
                    },
                },
            )
            def _patch_rule(text: str, _state=migrated_state) -> str:
                return json.dumps(_state, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
            mutation = self.mutation_runtime.apply_patch(
                rules_target, _patch_rule, proposal_ref=f"friction:{event.friction_id}"
            )
            replay_ref = "replay_" + _sha_text(json.dumps(replay_result, ensure_ascii=False, sort_keys=True, default=str))[:20]
            repaired = self.friction_repair.repair(
                event, mutation_receipt_ref=str(mutation.get("mutation_receipt_id") or ""), regression_refs=(replay_ref,)
            )
            repair_verification = self.friction_repair.verify_repair(event, {
                "authority_checks_enabled": True,
                "authority_requery_allowed": True,
                "directive_precedence": "default",
                "goal_projection_policy": "default",
                "dispatch_before_narration": False,
                "completion_requires_observed_result": False,
                "regression_fixture_required": False,
            })
            if not repair_verification.get("passed"):
                raise RuntimeError(f"friction repair regression failed: {repair_verification}")
            friction_repairs.append({
                "event": event.as_mapping(), "replay": replay_result, "cause_candidates": cause_candidates,
                "branch_path": str(branch_path), "migration": migrated_state, "mutation": mutation, "repair": repaired,
                "repair_verification": repair_verification,
            })

        active_improvement = self.improvement_programs.active()
        if active_improvement is None:
            improvement_program = self.improvement_programs.compose(
                observes=("user_goal_loss", "execution_receipts", "friction_events", "observation_gaps"),
                proposes=("operator_schema", "interpreter", "module_boundary", "evaluation_sensor", "execution_body"),
                experiment_builder_ref="mutation_runtime:fork_state+run_work",
                adoption_rule_ref="evidence_kernel:observed_user_outcome",
                evidence_refs=(goal_event.event_id,),
            )
        else:
            # The adopted improvement method becomes the parent of the next one;
            # the improvement ladder is therefore state, not a fixed bootstrap.
            improvement_program = self.improvement_programs.mutate(
                active_improvement,
                observes=tuple(dict.fromkeys((*active_improvement.observes, "current_work", "new_observation_gap"))),
                proposes=tuple(dict.fromkeys((*active_improvement.proposes, "representation_rewrite", "body_composition"))),
                evidence_ref=goal_event.event_id,
            )
        improvement_adoption = {}
        reactivated_programs = []
        for candidate in reactivated_candidates:
            program_row = dict(candidate.get("program") or {})
            if program_row.get("program_ref"):
                reactivated_programs.append(self.improvement_programs.from_mapping(program_row))
        if reactivated_programs:
            improvement_program = self.improvement_programs.combine(
                (improvement_program, *tuple(reactivated_programs)),
                evidence_refs=(goal_event.event_id,),
            )
            improvement_adoption["reactivated_candidate_refs"] = tuple(
                p.program_ref for p in reactivated_programs
            )
        if friction_repairs:
            child = self.improvement_programs.mutate(
                improvement_program,
                proposes=tuple(dict.fromkeys((*improvement_program.proposes, "friction_repair_behavior"))),
                evidence_ref=str(friction_repairs[-1]["repair"].get("mutation_receipt_ref") or ""),
            )
            comparison = self.improvement_programs.compare(({
                "program_ref": child.program_ref,
                "observed": True,
                "evidence_refs": tuple(str(x["repair"].get("mutation_receipt_ref") or "") for x in friction_repairs),
            },))
            adoption = self.improvement_programs.adopt(
                child, evidence_refs=tuple(str(x["repair"].get("mutation_receipt_ref") or "") for x in friction_repairs)
            )
            improvement_program = child
            improvement_adoption = {**improvement_adoption, "comparison": comparison, "adoption": adoption}
        multimodal_state = self.multimodal_bus.bind_turn(
            command=command, attachments=attachments,
            semantic_authority=semantic_authority_mapping,
        ).as_mapping()
        image_generation_governance = ImageGenerationGovernance.compile(
            command,
            requirements=requirement_contract.as_mapping().get("atoms", ()),
            attachments=attachments,
            style_capsule_id=str(multimodal_state.get("style_capsule_id") or ""),
        ).as_mapping()
        turn_continuity = self._bind_canonical_turn_continuity(
            release_turn_id=release_ticket.turn_id,
            command=command,
            semantic_objective=semantic_command,
            continuation_context=continuation_context,
        )
        semantic_authority_mapping = {**semantic_authority_mapping, "turn_continuity": turn_continuity}
        project_goal = self.cognitive_continuity.project_goal()
        goal_anchor = AmbitionPreserver.anchor(
            command, project_goal=project_goal, effective_current_goal=semantic_command
        )
        openness_contract = compile_openness_contract(
            semantic_authority_mapping, project_goal_present=bool(project_goal)
        )
        # All portfolio strategies remain live in state. In ordinary open work they are
        # context, not mandatory rituals; frontier mode may materialize them more fully.
        strategy_bundle = (
            self.reasoning_portfolio.prompt_bundle(semantic_command, count=None)
            if openness_contract.get("active") else
            {"objective": semantic_command, "strategies": [], "fixed_strategy_catalog_is_not_a_ceiling": True}
        )
        # Selection schedules work; it does not prune the possibility space. The
        # unselected branches stay in state so a later turn can pick them up.
        exploration_ecology = {
            "openness_contract": openness_contract,
            "strategy_portfolio": strategy_bundle,
            "recent_stepping_stones": self.exploration_memory.stepping_stones(),
            "selection_semantics": "scheduling_not_pruning",
            "unselected_possibilities_remain_live": True,
        }
        # The authority is passed in, not re-derived: the selector owns how to widen
        # a topology, but not whether this turn was open. Without this the canonical
        # judgement never reached the selector and an open problem got a bounded
        # divergence mode.
        strategy_topology = StrategyTopologySelector.select(
            command, semantic_contract,
            search_required=analysis.inferred_search_required,
            external_capability_required=analysis.inferred_external_capability_required,
            signed_in_browser_preferred=analysis.inferred_signed_in_browser_preferred,
            deep_reasoning_required=depth.get("effective") == "deep",
            semantic_authority=semantic_authority_mapping,
        )
        strategy_topology, continuity_ingress = self.cognitive_continuity.begin_turn(
            command=command,
            requirement_texts=(a.text for a in semantic_contract.atoms),
            topology=strategy_topology,
            project_goal=project_goal,
            semantic_authority=semantic_authority_mapping,
        )
        representation_tournament = RepresentationTournament.compile(
            command, semantic_contract, strategy_topology, semantic_authority=semantic_authority_mapping
        )
        self.anti_recurrence.observe(command)
        active_invariants = tuple(asdict(x) for x in self.anti_recurrence.active())
        repair_momentum_contract = self.repair_momentum.compile(
            command, active_invariants=active_invariants, semantic_authority=semantic_authority_mapping,
        )
        self.intent.add_message(command, source="user_turn", tags=("jigaewol_ingress",))
        cumulative = self.intent.compose(command)

        foundation_kwargs = dict(kwargs)
        foundation_kwargs.setdefault("semantic_authority", semantic_authority_mapping)
        foundation_result = self.foundation.ingress(
            command, capabilities=capabilities, attachments=attachments, **foundation_kwargs
        )
        ticket = foundation_result["core_ticket"]
        foundation_receipt = foundation_result["foundation_receipt"]
        frid = foundation_receipt["foundation_receipt_id"]
        self.foundation.verify_ingress_receipt(frid, message=command, turn_id=ticket.turn_id)

        route = dict(foundation_result.get("execution_route_composition") or {})
        fabric = dict(foundation_result.get("execution_fabric_plan") or {})
        current_caps = self.foundation.driver.capability_snapshot()
        surface = self.resilience.bind_surface(current_caps, session_id=self.session_id, receipt_id=frid)
        routing_objective = source_bound_objective(command, semantic_authority_mapping)
        routing_trait_hints = tuple(semantic_authority.required_capability_traits)
        required_effect_traits = routing_trait_hints if source_effect_authorized(semantic_authority_mapping) else ()
        need = self.resilience.infer_need(
            routing_objective, route_composition=route, required_traits=required_effect_traits
        )
        operational_route = self.resilience.route_plan(need, current_caps)
        operational_route["routing_trait_hints"] = list(routing_trait_hints)
        operational_route["source_effect_authorized"] = source_effect_authorized(semantic_authority_mapping)
        missing_traits = tuple(operational_route.get("missing_traits", ()))

        # v2 effect-first planning: express the requested state change before body
        # selection. User directive references are preserved, while actual host/body
        # availability remains independently observable and cannot be assumed.
        capability_rows = []
        for cap in current_caps:
            if isinstance(cap, Mapping):
                capability_rows.append(dict(cap))
            elif hasattr(cap, "as_mapping"):
                capability_rows.append(dict(cap.as_mapping()))
            elif hasattr(cap, "__dict__"):
                capability_rows.append(dict(cap.__dict__))
        capability_rows.extend(self.body_builder.snapshot().values())
        # Live structure mutations are part of the executable route, not archival
        # metadata.  A previously adopted route replacement is visible to the next
        # effect resolution under the same operation signature.
        live_structure = self.mutation_runtime.structure_snapshot()
        for component_ref, override in dict(live_structure.get("component_overrides") or {}).items():
            if not str(component_ref).startswith("route:"):
                continue
            operation_ref = str(component_ref).split(":", 1)[1]
            capability_rows.insert(0, {
                "body_id": f"mutation_override:{operation_ref}",
                "effect_signature": operation_ref,
                "kind": "mutated_route_override",
                "entrypoint_ref": str(dict(override).get("replacement_program_ref") or ""),
                "parent_refs": (str(dict(override).get("proposal_id") or ""),),
            })
        effect_resolutions = []
        body_materializations: list[dict[str, Any]] = []
        for work in tuple(ticket.view.next_work):
            operation = str(getattr(work, "operation", "") or "host_effect")
            work_id = str(getattr(work, "work_id", "") or "")
            effect_request = EffectRequest(
                desired_change=operation,
                target_refs=(work_id,) if work_id else (),
                input_artifacts=(goal_event.raw_sha256,),
                observable_result={"receipt_required": True, "operation": operation},
                user_authorization_refs=(goal_event.event_id, semantic_authority.message_sha256),
            )
            resolution = self.effect_planner.resolve(effect_request, bodies=capability_rows, requires_authorization=True)
            if any(op.get("operation") == "assume_authority" for op in resolution.synthesized_operations):
                resolution = self.effect_planner.execute_synthesized_operations(
                    resolution, authority_event_ref=goal_event.event_id
                )
            if "executable_body" in resolution.missing_requirements:
                body_request = self.effect_planner.request_body(resolution)
                discovered = self.body_builder.discover(operation)
                if discovered:
                    body_materializations.extend(discovered)
                else:
                    # No currently observed body has the requested effect: synthesize
                    # a concrete local executable body rather than relabeling an unrelated
                    # capability as if it satisfied the effect.
                    fallback_entrypoint = f"local_generated_program:{operation}"
                    generated = self.body_builder.generate(
                        desired_change=operation,
                        entrypoint_ref=fallback_entrypoint,
                        dependency_refs=tuple(resolution.body_refs),
                        authorization_refs=effect_request.user_authorization_refs,
                        observable_result=effect_request.observable_result,
                        parent_refs=(resolution.resolution_id,),
                        interface={"request": body_request, "reusable": True},
                    )
                    self.body_builder.bind(generated)
                    generated_row = generated.as_mapping()
                    capability_rows.append(generated_row)
                    body_materializations.append(generated_row)
                    resolution = self.effect_planner.resolve(effect_request, bodies=capability_rows, requires_authorization=True)
                    if any(op.get("operation") == "assume_authority" for op in resolution.synthesized_operations):
                        resolution = self.effect_planner.execute_synthesized_operations(
                            resolution, authority_event_ref=goal_event.event_id
                        )
            effect_resolutions.append(resolution)
        effect_plan = self.effect_planner.compose(effect_resolutions) if effect_resolutions else {
            "resolution_ids": (), "all_resolved": True, "body_refs": (),
            "missing_requirements": (), "synthesized_operations": (), "resolutions": (),
            "no_external_effect_requested": True,
        }
        effect_plan = {**effect_plan, "body_materializations": tuple(body_materializations)}

        observation_signals = []
        if missing_traits:
            observation_signals.append("stalled_tool_information")
        if friction_events:
            observation_signals.append("user_correction")
        if semantic_authority.representation_search_required:
            observation_signals.append("unrepresented_observation")
        observation_gap_obj = self.observer_builder.detect_gap(
            signals=observation_signals,
            context={"missing_traits": missing_traits, "goal_event_id": goal_event.event_id},
        )
        observation_gap = observation_gap_obj.as_mapping() if observation_gap_obj else {}
        if observation_gap_obj is not None:
            sensor_request = self.observer_builder.propose_sensor(observation_gap_obj)
            sensor = self.observer_builder.materialize(
                sensor_request, program_ref=f"sensor:{observation_gap_obj.gap_id}"
            )
            sensor_body = self.body_builder.generate(
                desired_change=f"observe:{observation_gap_obj.gap_id}",
                entrypoint_ref=str(sensor.get("program_ref") or ""),
                observable_result={"observation_gap": observation_gap_obj.gap_id},
                kind="generated_sensor",
                parent_refs=(observation_gap_obj.gap_id,),
                interface=sensor,
            )
            self.body_builder.bind(sensor_body)
            sensor_row = sensor_body.as_mapping()
            body_materializations.append(sensor_row)
            sensor_probe = self.observer_builder.execute(sensor, {
                "signals": observation_gap_obj.signals,
                "context": observation_gap_obj.proposed_sensor.get("context", {}),
                "goal_event_id": goal_event.event_id,
            })
            observation_gap = {**observation_gap, "sensor": sensor, "body": sensor_row, "probe": sensor_probe}

        possibility_plan = PossibilityEngine.compile(
            semantic_command,
            missing_traits=missing_traits,
            recurring_signals=active_invariants,
            representation_requested=bool(semantic_authority.representation_search_required),
        ).as_mapping()
        if observation_gap_obj is not None:
            generated_phase = f"observe_gap:{observation_gap_obj.gap_id}"
            possibility_plan = PossibilityEngine.register_phase(
                possibility_plan,
                phase_id=generated_phase,
                after=("reinterpret_representation",),
                before=("compose_capabilities",),
                make_active=True,
            )
            possibility_plan["generated_from_observation_gap"] = observation_gap_obj.gap_id
        open_world_intent = extract_open_world_intent(
            command, semantic_authority=semantic_authority_mapping
        )
        uncertainty = min(1.0, max(
            0.10 + 0.18 * len(missing_traits) + (0.20 if depth.get("effective") == "deep" else 0.0),
            open_world_intent.representation_uncertainty,
        ))
        urgency = 1.0 if semantic_authority.urgency_requested else 0.0
        profile = classify_turn_profile(
            command, explicit_depth=str(depth.get("effective") or "unspecified"), uncertainty=uncertainty,
            missing_traits=missing_traits, required_traits=need.required_traits, attachments=attachments,
            semantic_authority=semantic_authority_mapping,
        )
        exploration_decision = self.exploration_escalation.decide(
            command, profile_mode=profile.mode,
            repair_momentum_required=repair_momentum_contract.required,
            missing_traits=missing_traits, external_event=True,
            semantic_authority=semantic_authority_mapping,
        )
        exploration_is_open = exploration_decision.state == ExplorationState.ACTIVE.value
        envelope = derive_resource_envelope(
            latency_target_ms=self.latency_target_ms, capability_count=surface.get("capability_count", 0),
            uncertainty=uncertainty, urgency=urgency,
            breadth_protected=bool(profile.mode == "DEEP" or semantic_authority.representation_search_required),
        )
        integration_probe = self._integration_probe
        divergence_required = bool(exploration_is_open and (
            missing_traits
            or open_world_intent.deep_escalation
            or "divergent_worlds" in strategy_topology.selected
            or exploration_decision.task_shape == "open_problem"
        ))
        if profile.mode == "DEEP" and divergence_required:
            open_audit = self._audit_open_world()
            gaps = self.world_inventor.detect_gaps(
                objective=semantic_command, missing_traits=missing_traits, failure_patterns=(), source_cultures_seen=(),
                representation_uncertainty=open_world_intent.representation_uncertainty,
            )
            invented = tuple(asdict(x) for x in self.world_inventor.invent(objective=semantic_command, gaps=gaps))
            open_audit = {
                **open_audit,
                "representation_gap_state": "detected" if gaps else "not_detected_yet",
                "open_world_intent": asdict(open_world_intent),
                "cognitive_depth_preserved": True,
                "representation_divergence_active": True,
            }
        elif profile.mode == "DEEP":
            open_audit = {
                "deferred": True,
                "reason": "deep_reasoning_does_not_imply_representation_divergence",
                "audit_target": "active cognition chassis: jigaewol_runtime + jigaewol_core + jigaewol_components",
                "representation_gap_state": "not_detected_yet",
                "open_world_intent": asdict(open_world_intent),
                "cognitive_depth_preserved": True,
                "representation_divergence_active": False,
            }
            invented = ()
        elif exploration_is_open and profile.mode == "STANDARD" and missing_traits:
            open_audit = {
                "deferred": True,
                "reason": "full_open_world_audit_deferred_but_representation_gap_detected",
                "audit_target": "active cognition chassis: jigaewol_runtime + jigaewol_core + jigaewol_components",
            }
            gaps = self.world_inventor.detect_gaps(
                objective=semantic_command, missing_traits=missing_traits, failure_patterns=(), source_cultures_seen=(),
                representation_uncertainty=open_world_intent.representation_uncertainty,
            )
            invented = tuple(asdict(x) for x in self.world_inventor.invent(objective=semantic_command, gaps=gaps))
            open_audit = {**open_audit, "representation_gap_state": "detected" if gaps else "not_detected_yet",
                          "open_world_intent": asdict(open_world_intent)}
        else:
            open_audit = {
                "deferred": True,
                "reason": "lazy_until_representation_gap_or_deep_profile",
                "audit_target": "active cognition chassis: jigaewol_runtime + jigaewol_core + jigaewol_components",
                "representation_gap_state": "not_detected_yet",
                "open_world_intent": asdict(open_world_intent),
                "cognitive_depth_preserved": profile.mode == "DEEP",
                "representation_divergence_active": False,
            }
            invented = ()
        resilience_snapshot = {
            "need": asdict(need), "current_surface": surface, "route_plan": operational_route,
            "route_failure_is_goal_failure": False, "permission_failure_is_permission_bypass": False,
            "provider_identity_secondary_to_capability_semantics": True,
        }
        cognitive_os_required = bool(
            exploration_is_open
            or semantic_authority.open_problem_required
            or semantic_authority.representation_search_required
        )
        if cognitive_os_required:
            _cog = self.cognitive_os_compiler.compile(
                command=command,
                requirement_contract=requirement_contract.as_mapping(),
                semantic_requirement_contract=(semantic_contract.as_mapping() if semantic_contract.contract_sha256 != requirement_contract.contract_sha256 else None),
                goal_anchor=asdict(goal_anchor),
                topology=strategy_topology.as_mapping(),
                current_surface=surface,
                missing_traits=missing_traits,
                cognitive_continuity=continuity_ingress.as_mapping(),
                semantic_authority=semantic_authority_mapping,
            )
            cognitive_os_mapping = {
                **_cog.as_mapping(),
                "activation": "EXPLORATION_ESCALATION_ONLY" if exploration_is_open else "OPEN_PROBLEM_BASELINE",
                "semantic_frontier_open": bool(semantic_authority.open_problem_required),
                "semantic_authority": semantic_authority_mapping,
            }
        else:
            quiet_payload = {
                "mode": "QUIET_WORK_PLANE",
                "persistent_exploration_injected": False,
                "exploration_state": exploration_decision.state,
                "task_shape": exploration_decision.task_shape,
            }
            cognitive_os_mapping = {
                "plan_id": "quiet_" + _sha_text(json.dumps(quiet_payload, sort_keys=True))[:20],
                **quiet_payload, "routes": (), "cells": (), "agenda": (),
                "semantic_frontier_open": False,
                "semantic_authority": semantic_authority_mapping,
                "plan_sha256": _sha_text(json.dumps(quiet_payload, sort_keys=True)),
            }
        cognitive_os_mapping = {
            **cognitive_os_mapping,
            "task_local_operator": dynamic_operator.as_mapping(),
            "task_local_interpreter": interpreter_program.as_mapping(),
            "task_local_interpreter_probe": interpreter_probe,
            "operator_taxonomy_is_not_ceiling": True,
            "quiet_path_operator_generation_preserved": True,
        }

        self.trace.emit(
            turn_id=release_ticket.turn_id, phase="INGRESS", status="RUNNING", component="CoreRuntime",
            action="exact_command_ingressed", receipt_id=release_ticket.receipt_id,
            details={"foundation_receipt_id": frid, "path_kind": foundation_result.get("path_kind")},
        )
        self.trace.emit(
            turn_id=release_ticket.turn_id, phase="CAPABILITY_SURFACE", status="OBSERVED", component="OperationalResilienceEngine",
            action="bind_current_host_surface", receipt_id=frid,
            details={"capability_count": surface.get("capability_count", 0), "missing_traits": operational_route.get("missing_traits", ())},
        )
        self.trace.emit(
            turn_id=release_ticket.turn_id, phase="PROFILE", status="SELECTED", component="CoreRuntime",
            action="adaptive_execution_cost_route", receipt_id=frid, details=asdict(profile),
        )
        self.trace.emit(
            turn_id=release_ticket.turn_id, phase="COGNITIVE_CONTINUITY", status="RESTORED",
            component="OpenIdentityLoop", action="restore_challenge_influence_persist", receipt_id=frid,
            details=continuity_ingress.as_mapping(),
        )
        self.trace.emit(
            turn_id=release_ticket.turn_id, phase="COGNITIVE_OS", status="COMPILED",
            component="OpenWorldCognitiveCompiler", action="compile_dynamic_turn_phenotype", receipt_id=frid,
            details={
                "plan_id": cognitive_os_mapping.get("plan_id"),
                "plan_sha256": cognitive_os_mapping.get("plan_sha256"),
                "route_count": len(cognitive_os_mapping.get("routes", ())),
                "cell_count": len(cognitive_os_mapping.get("cells", ())),
                "exploration_state": exploration_decision.state,
                "mobile_chat_is_control_shell_not_compute_ceiling": True,
                "unknown_routes_remain_open": bool(cognitive_os_mapping.get("semantic_frontier_open") or cognitive_os_mapping.get("routes")),
            },
        )

        self.trace.emit(
            turn_id=release_ticket.turn_id, phase="EXPLORATION_GATE",
            status=exploration_decision.state, component="ExplorationEscalationController",
            action="classify_optional_exploration", receipt_id=frid,
            details=exploration_decision.as_mapping(),
        )
        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="exploration_escalation_gate", success=True,
            evidence=exploration_decision.as_mapping(),
        )

        self.audit.attach_runtime(
            release_ticket.turn_id,
            run_id=ticket.turn_id,
            subsystem="strict_per_turn_ingress",
            success=True,
            evidence={
                "foundation_receipt_id":frid,
                "foundation_turn_id":ticket.turn_id,
                "exact_user_command_bound":True,
                "command_sha256":_sha_text(command),
                "path_kind":foundation_result.get("path_kind"),
                "gateway_required": self.require_gateway_turn,
                "gateway_turn_id": gateway_proof.get("gateway_turn_id", ""),
                "gateway_sequence": gateway_proof.get("gateway_sequence", 0),
                "gateway_turn_sequence_proven": gateway_proof.get("gateway_turn_sequence_proven", False),
            },
        )
        self.audit.attach_runtime(
            release_ticket.turn_id,
            run_id=ticket.turn_id,
            subsystem="intent_depth_authority",
            success=True,
            evidence={
                "depth":depth,
                "semantic_authority": semantic_authority_mapping,
                "cumulative_intent_sha256":_sha_text(json.dumps(cumulative,ensure_ascii=False,sort_keys=True,default=str)),
            },
        )
        self.audit.attach_runtime(
            release_ticket.turn_id,
            run_id=ticket.turn_id,
            subsystem="execution_fabric",
            success=bool(fabric),
            evidence={"fabric":_safe_summary(fabric), "route":_safe_summary(route)},
        )
        self.audit.attach_runtime(
            release_ticket.turn_id,
            run_id=ticket.turn_id,
            subsystem="open_world_audit",
            success=True,
            evidence=open_audit,
        )
        self.audit.attach_runtime(
            release_ticket.turn_id,
            run_id=ticket.turn_id,
            subsystem="integration_registry_surface",
            success=True,
            evidence={
                "registered": integration_probe.get("registered"),
                "per_turn_import_probe": False,
                "release_validation_required_for_liveness": True,
            },
        )
        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="operational_resilience_surface", success=True,
            evidence={"surface": _safe_summary(surface), "route_plan": _safe_summary(operational_route), "need": asdict(need)},
        )
        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="resource_derived_budget", success=True,
            evidence=asdict(envelope),
        )
        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="persistent_open_identity", success=True,
            evidence=continuity_ingress.as_mapping(),
        )
        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="capability_amplification_contract", success=True,
            evidence={
                "requirement_contract_sha256": requirement_contract.contract_sha256,
                "requirement_count": len(requirement_contract.atoms),
                "goal_anchor_sha256": goal_anchor.goal_sha256,
                "strategy_topology": strategy_topology.as_mapping(),
                "anti_recurrence_invariant_ids": [x.get("invariant_id") for x in active_invariants],
                "repair_momentum_required": repair_momentum_contract.required,
                "repair_momentum_contract_sha256": repair_momentum_contract.contract_sha256,
            },
        )

        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="frontier_control_plane", success=True,
            evidence=frontier_turn_state,
        )

        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="v2_executable_work_and_representation", success=True,
            evidence={
                "goal_event_id": goal_event.event_id,
                "goal_loss_detected": goal_loss_diff.loss_detected,
                "work_id": work_program.work_id,
                "work_node_count": len(work_program.nodes),
                "representation_id": representation_program.representation_id,
                "operator_id": dynamic_operator.operator_id,
                "interpreter_id": interpreter_program.interpreter_id,
                "effect_plan": effect_plan,
                "improvement_program_ref": (improvement_program.program_ref if improvement_program is not None else ""),
                "observation_gap_id": observation_gap.get("gap_id", ""),
                "friction_event_ids": tuple(x.friction_id for x in friction_events),
            },
        )

        # Continuations inherit the unfinished semantic objective.  Feeding only the
        # literal continuation marker here would silently collapse an active task-local
        # universe back to the default representation exactly when the user says
        # “continue”.  Activation therefore follows the canonical semantic objective,
        # while the organogenesis mandate still receives the exact current raw bytes.
        ephemeral_universe = EphemeralUniverseEngine.compile(semantic_command, semantic_authority_mapping)
        if bool(ephemeral_universe.get("active")) and bool(ephemeral_universe.get("materialization_requested")):
            # Materialize the handoff: the unusual representation is not left as prose.
            # The task-local colony breeds observation expressions, operation semantics,
            # language tokens, interpreter assumptions and a standalone interpreter body.
            try:
                from jigaewol_components.organogenesis_kernel import OrganogenesisKernel
                blueprint_path = Path(__file__).resolve().parents[1] / "blueprints" / "ASTRA_ORIGINAL_BLUEPRINT.txt"
                blueprint_bytes = blueprint_path.read_bytes() if blueprint_path.is_file() else b""
                organ_run = OrganogenesisKernel(self.root / "organogenesis").run(
                    raw_message_bytes,
                    sequence=int(gateway_proof.get("gateway_sequence") or 0),
                    semantic_objective=semantic_command,
                    lineage=tuple(filter(None, (
                        str(continuation_context.get("task_id") or ""),
                        str(continuation_context.get("objective_sha256") or ""),
                    ))),
                    root_mandate=blueprint_bytes,
                    root_mandate_ref=(str(blueprint_path) if blueprint_bytes else ""),
                )
                ephemeral_universe = {**ephemeral_universe, "organogenesis_materialization": {
                    "status": "EXECUTED",
                    "run_id": organ_run.run_id,
                    "holdout_accuracy": organ_run.holdout_accuracy,
                    "generated_operation_names": organ_run.generated_operation_names,
                    "generated_observation_channels": organ_run.generated_observation_channels,
                    "generator_generation": organ_run.generator_after.get("generation"),
                    "capsule_sha256": organ_run.omega_capsule_sha256,
                    "capsule_path": organ_run.omega_capsule_path,
                    "legacy_regression_capsule_sha256": organ_run.capsule_sha256,
                    "legacy_regression_capsule_path": organ_run.capsule_path,
                    "experiment_count": len(organ_run.experiments),
                    "semantic_context": organ_run.semantic_context,
                    "root_blueprint": organ_run.root_blueprint,
                    "omega_bundle_id": organ_run.omega_bundle.get("bundle_id"),
                    "fidelity_ledger_sha256": organ_run.fidelity_ledger.get("sha256"),
                    "literal_blueprint_sha256": organ_run.literal_blueprint.get("sha256"),
                    "literal_source_authority": bool(organ_run.literal_blueprint.get("source_is_authority")),
                    "materialized_body": organ_run.materialized_body,
                    "unresolved_frontier": organ_run.unresolved_frontier,
                }}
                self.audit.attach_runtime(
                    release_ticket.turn_id, run_id=ticket.turn_id, subsystem="organogenesis_materialization", success=True,
                    evidence=dict(ephemeral_universe["organogenesis_materialization"]),
                )
            except Exception as exc:
                ephemeral_universe = {**ephemeral_universe, "organogenesis_materialization": {
                    "status": "FAILED", "error_type": type(exc).__name__, "error": str(exc),
                    "claim": "organogenesis was requested by the ephemeral universe but did not materialize on this turn",
                }}
                self.audit.attach_runtime(
                    release_ticket.turn_id, run_id=ticket.turn_id, subsystem="organogenesis_materialization", success=False,
                    evidence=dict(ephemeral_universe["organogenesis_materialization"]),
                )
        forensic_contract = ForensicRuntimeContract.mapping(
            semantic_authority=semantic_authority_mapping, ephemeral_universe=ephemeral_universe
        )
        forensic_binding = self.unified_intent.bind_sha(
            unified_envelope.exact_user_message_sha256, component="forensic",
            validation_passed=True, validation_scope="runtime_forensic_contract",
            details={
                "invariant_count": int(forensic_contract.get("invariant_count") or 0),
                "invariants_sha256": str(forensic_contract.get("invariants_sha256") or ""),
            },
        )
        forensic_contract["unified_intent_ledger_binding"] = forensic_binding
        forensic_contract["constitution_generation"] = int(constitution_state.get("generation", 1))
        open_execution_state = self.open_execution.begin_turn(
            message=command,
            requirement_contract=requirement_contract,
            semantic_authority=semantic_authority_mapping,
            architecture_snapshot={
                "strategy_topology": strategy_topology.as_mapping(),
                "representation_id": representation_program.representation_id,
                "operator_id": dynamic_operator.operator_id,
                "interpreter_id": interpreter_program.interpreter_id,
                "execution_route_composition": route,
            },
        )
        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="open_ended_execution_search", success=True,
            evidence={
                "message_sha256": open_execution_state.get("message_sha256"),
                "execution_required": open_execution_state.get("execution_required"),
                "obligation_count": len(open_execution_state.get("obligations") or ()),
                "counterfactual_candidate_count": len(open_execution_state.get("counterfactual_candidates") or ()),
                "no_global_impossibility_from_local_negative": True,
            },
        )
        self.audit.attach_runtime(
            release_ticket.turn_id, run_id=ticket.turn_id, subsystem="forensic_runtime_contract", success=True,
            evidence={
                "invariant_count": forensic_contract.get("invariant_count"),
                "invariants_sha256": forensic_contract.get("invariants_sha256"),
                "semantic_scope_bound": forensic_contract.get("semantic_scope_bound"),
                "ephemeral_universe_bound": forensic_contract.get("ephemeral_universe_bound"),
                "unified_canonical_goal_id": forensic_binding.get("canonical_goal_id"),
                "single_source_of_truth": forensic_binding.get("single_source_of_truth"),
                "constitution_generation": int(constitution_state.get("generation", 1)),
            },
        )

        wild_cognitive_plan = WildCognitivePlane(self.root / "wild_cognition").plan(command)

        turn = self._make_core_turn(
            core_turn_id=f"core::{release_ticket.turn_id}::{ticket.turn_id}",
            command=command,
            command_sha256=_sha_text(command),
            release_turn_id=release_ticket.turn_id,
            release_ingress_receipt_id=release_ticket.receipt_id,
            foundation_turn_id=ticket.turn_id,
            foundation_receipt_id=frid,
            path_kind=str(foundation_result.get("path_kind")),
            depth=depth,
            cumulative_intent=cumulative,
            requirement_contract=requirement_contract.as_mapping(),
            active_requirement_contract=semantic_contract.as_mapping(),
            goal_anchor=asdict(goal_anchor),
            strategy_topology=strategy_topology.as_mapping(),
            representation_tournament=representation_tournament.as_mapping(),
            semantic_authority=semantic_authority_mapping,
            openness_contract=openness_contract,
            possibility_plan=possibility_plan,
            exploration_ecology=exploration_ecology,
            anti_recurrence=active_invariants,
            repair_momentum_contract=repair_momentum_contract.as_mapping(),
            execution_route_composition=route,
            execution_fabric_plan=fabric,
            open_world_audit=open_audit,
            operational_resilience=resilience_snapshot,
            resource_envelope=asdict(envelope),
            execution_profile=asdict(profile),
            invented_worlds=invented,
            ephemeral_universe=ephemeral_universe,
            forensic_contract=forensic_contract,
            open_execution_state=open_execution_state,
            cognitive_continuity=continuity_ingress.as_mapping(),
            cognitive_os=cognitive_os_mapping,
            exploration_decision=exploration_decision.as_mapping(),
            exploration_return={},
            frontier_control=frontier_turn_state,
            goal_kernel=goal_event.as_mapping(),
            goal_loss_diff={**goal_loss_diff.as_mapping(), "recovery": goal_loss_recovery},
            work_program=work_program.as_mapping(),
            representation_program={**representation_program.as_mapping(), "probe": representation_probe},
            dynamic_operator=dynamic_operator.as_mapping(),
            interpreter_program={**interpreter_program.as_mapping(), "probe": interpreter_probe, "translation": interpreter_translation},
            effect_plan=effect_plan,
            improvement_program=(improvement_program.as_mapping() if improvement_program is not None else {"bypassed": True, "reason": "opaque_execution"}),
            observation_gap=observation_gap,
            friction_events=tuple(x.as_mapping() for x in friction_events),
            body_materializations=tuple(body_materializations),
            friction_repairs=tuple(friction_repairs),
            improvement_adoption=improvement_adoption,
            multimodal_state=multimodal_state,
            image_generation_governance=image_generation_governance,
            wild_cognitive_plan=wild_cognitive_plan,
            expected_previous_finalizer_receipt_id=self.canonical_finalizer.latest_applied_full_receipt_id(),
            gateway_required=self.require_gateway_turn,
            gateway_turn_id=str(gateway_proof.get("gateway_turn_id") or ""),
            gateway_sequence=int(gateway_proof.get("gateway_sequence") or 0),
            gateway_token_sha256=str(gateway_proof.get("gateway_token_sha256") or ""),
            previous_gateway_token_sha256=str(gateway_proof.get("previous_gateway_token_sha256") or ""),
            gateway_chain_verified=bool(gateway_proof.get("gateway_turn_sequence_proven")),
            gateway_scope_sha256=str(gateway_proof.get("gateway_scope_sha256") or ""),
            next_work=tuple(ticket.view.next_work),
        )
        self._turns[turn.core_turn_id] = turn
        self._persist_turn(turn)
        return turn
