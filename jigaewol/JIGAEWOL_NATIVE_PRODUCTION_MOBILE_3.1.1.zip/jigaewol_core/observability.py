from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from jigaewol_components.semantic_communication import SemanticCommunicationLayer


@dataclass(frozen=True)
class TraceEvent:
    event_id: str
    turn_id: str
    phase: str
    status: str
    component: str
    action: str
    capability_id: str | None
    provider: str | None
    receipt_id: str | None
    details: dict[str, Any]
    created_at: float


class PublicExecutionTrace:
    """Observable execution/provenance telemetry.

    This is deliberately operational: phases, routes, tools/providers, receipts,
    failures, retries and release state. It is designed so a user/operator can see
    that the runtime is alive and what it actually executed.
    """

    def __init__(self, path: str | Path, *, listener=None) -> None:
        self.path = Path(path)
        self.delivery_path = self.path.with_name(self.path.stem + "_delivery.jsonl")
        self.listener = listener
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")
        if not self.delivery_path.exists():
            self.delivery_path.write_text("", encoding="utf-8")

    def emit(self, *, turn_id: str, phase: str, status: str, component: str, action: str,
             capability_id: str | None = None, provider: str | None = None,
             receipt_id: str | None = None, details: dict[str, Any] | None = None) -> TraceEvent:
        safe_details = dict(SemanticCommunicationLayer.normalize_audit_payload(dict(details or {})))
        row = TraceEvent(
            event_id="trace_" + uuid.uuid4().hex[:16], turn_id=str(turn_id), phase=str(phase),
            status=str(status), component=str(component), action=str(action),
            capability_id=None if capability_id is None else str(capability_id),
            provider=None if provider is None else str(provider),
            receipt_id=None if receipt_id is None else str(receipt_id),
            details=safe_details, created_at=time.time(),
        )
        payload=asdict(row)
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str) + "\n")
            fh.flush()
        delivery = {
            "event_id": row.event_id,
            "turn_id": row.turn_id,
            "runtime_event_persisted": True,
            "listener_present": self.listener is not None,
            "listener_invoked": False,
            "host_forwarding_observed": False,
            "ui_rendering_observed": False,
            "listener_error": "",
            "observed_at": 0.0,
            "created_at": row.created_at,
        }
        if self.listener is not None:
            delivery["listener_invoked"] = True
            try:
                ack = self.listener(dict(payload))
                if isinstance(ack, dict):
                    delivery["host_forwarding_observed"] = ack.get("host_forwarding_observed") is True
                    delivery["ui_rendering_observed"] = ack.get("ui_rendering_observed") is True
                    observed_at = ack.get("observed_at")
                    if isinstance(observed_at, (int, float)) and float(observed_at) >= row.created_at:
                        delivery["observed_at"] = float(observed_at)
            except Exception as exc:  # progress observers must never kill the task
                delivery["listener_error"] = f"{type(exc).__name__}: {exc}"[:1000]
        with self.delivery_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(delivery, ensure_ascii=False, sort_keys=True, default=str) + "\n")
            fh.flush()
        return row

    def events(self, turn_id: str | None = None, *, limit: int = 200) -> tuple[dict[str, Any], ...]:
        if limit < 1:
            return ()
        rows=[]
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row=json.loads(line)
            if turn_id is None or row.get("turn_id") == turn_id:
                rows.append(row)
        return tuple(rows[-limit:])


    def deliveries(self, turn_id: str | None = None, *, limit: int = 500) -> tuple[dict[str, Any], ...]:
        if limit < 1 or not self.delivery_path.exists():
            return ()
        rows=[]
        for line in self.delivery_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row=json.loads(line)
            if turn_id is None or row.get("turn_id") == turn_id:
                rows.append(row)
        return tuple(rows[-limit:])

    def digest(self, turn_id: str) -> dict[str, Any]:
        rows=self.events(turn_id)
        ingress_rows=[r for r in rows if r.get("phase")=="INGRESS"]
        surface_rows=[r for r in rows if r.get("phase")=="CAPABILITY_SURFACE"]
        profile_rows=[r for r in rows if r.get("phase")=="PROFILE"]
        execution_rows=[r for r in rows if r.get("phase")=="EXECUTION" and r.get("status") in {"SUCCEEDED","FAILED"} and r.get("capability_id")]
        route_rows=[r for r in rows if r.get("phase")=="ROUTE_REVISION"]
        verify_rows=[r for r in rows if r.get("phase")=="VERIFICATION"]
        release_rows=[r for r in rows if r.get("phase")=="RELEASE"]
        generation_rows=[r for r in rows if r.get("phase")=="CANDIDATE_GENERATION"]
        successes=[r for r in execution_rows if r.get("status")=="SUCCEEDED"]
        failures=[r for r in execution_rows if r.get("status")=="FAILED"]
        used=[]
        for r in execution_rows:
            cid=r.get("capability_id")
            if cid and cid not in used:
                used.append(cid)
        surface_details=(surface_rows[-1].get("details") or {}) if surface_rows else {}
        profile_details=(profile_rows[-1].get("details") or {}) if profile_rows else {}
        verification_details=(verify_rows[-1].get("details") or {}) if verify_rows else {}
        generation_details=(generation_rows[-1].get("details") or {}) if generation_rows else {}
        release_details=(release_rows[-1].get("details") or {}) if release_rows else {}
        delivery_rows=list(self.deliveries(turn_id))
        listener_invocations=sum(1 for r in delivery_rows if r.get("listener_invoked") is True)
        host_forwarded=sum(1 for r in delivery_rows if r.get("host_forwarding_observed") is True)
        ui_rendered=sum(1 for r in delivery_rows if r.get("ui_rendering_observed") is True)
        listener_errors=[str(r.get("listener_error")) for r in delivery_rows if str(r.get("listener_error") or "").strip()]
        return {
            "turn_id": str(turn_id),
            "ingress": {
                "admitted": bool(ingress_rows),
                "receipt_id": ingress_rows[-1].get("receipt_id") if ingress_rows else None,
            },
            "surface": {
                "callable_count": int(surface_details.get("capability_count", 0) or 0),
                "missing_traits": list(surface_details.get("missing_traits", ()) or ()),
            },
            "profile": {
                "mode": profile_details.get("mode"),
                "reason": profile_details.get("reason"),
            },
            "execution": {
                "external_execution_occurred": bool(execution_rows),
                "actually_used_capabilities": used,
                "successes": [{"capability_id":r.get("capability_id"),"provider":r.get("provider"),"receipt_id":r.get("receipt_id")} for r in successes],
                "failures": [{"capability_id":r.get("capability_id"),"provider":r.get("provider"),"receipt_id":r.get("receipt_id"),"details":r.get("details") or {}} for r in failures],
            },
            "route_revisions": [{"receipt_id":r.get("receipt_id"),"details":r.get("details") or {}} for r in route_rows],
            "cognition": {
                "world_ids_used_in_synthesis": list((generation_details.get("generation_metadata") or {}).get("world_ids_used_in_synthesis", ()) or ()),
            },
            "verification": {
                "state": verify_rows[-1].get("status") if verify_rows else None,
                "coverage_state": verification_details.get("coverage_state"),
                "applicable_verifier_count": verification_details.get("applicable_verifier_count"),
            },
            "release": {
                "state": release_rows[-1].get("status") if release_rows else None,
                "receipt_id": release_rows[-1].get("receipt_id") if release_rows else None,
                "integrity_receipt_id": release_rows[-1].get("receipt_id") if release_rows else None,
                "response_sha256_prefix": str(release_details.get("candidate_sha256") or "")[:12] or None,
            },
            "progress_delivery": {
                "runtime_event_count": len(rows),
                "delivery_record_count": len(delivery_rows),
                "listener_invocation_count": listener_invocations,
                "host_forwarding_observed_count": host_forwarded,
                "ui_rendering_observed_count": ui_rendered,
                "realtime_user_visibility_proven": ui_rendered > 0,
                "final_burst_or_buffering_risk": bool(rows) and ui_rendered == 0,
                "listener_errors": listener_errors,
                "truth_rule": "runtime_emitted != host_forwarded != ui_rendered",
            },
            "platform_ui_labels_controlled": False,
        }

    def status(self, turn_id: str) -> dict[str, Any]:
        rows=self.events(turn_id)
        tools=[]
        for row in rows:
            cid=row.get("capability_id")
            if cid and cid not in tools:
                tools.append(cid)
        latest=rows[-1] if rows else None
        return {
            "turn_id": str(turn_id),
            "alive": bool(rows),
            "latest_phase": latest.get("phase") if latest else None,
            "latest_status": latest.get("status") if latest else None,
            "tools_or_capabilities_used": tools,
            "event_count": len(rows),
            "events": rows,
        }
