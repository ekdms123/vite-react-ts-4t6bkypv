from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from typing import Iterable

from .open_world_intent import extract_open_world_intent


@dataclass(frozen=True)
class InventedWorld:
    world_id: str
    missing_dimension: str
    mechanism: str
    substrate_hint: str
    falsification_question: str


class RepresentationGapWorldGenerator:
    """Invents worlds from detected representational gaps, not a pre-labelled alien slot."""

    def detect_gaps(self, *, objective: str, missing_traits: Iterable[str] = (),
                    failure_patterns: Iterable[str] = (), source_cultures_seen: Iterable[str] = (),
                    representation_uncertainty: float = 0.0) -> tuple[str, ...]:
        gaps=[]
        gaps.extend("capability:"+str(x) for x in missing_traits if str(x))
        gaps.extend("mechanism:"+str(x) for x in failure_patterns if str(x))
        cultures={str(x) for x in source_cultures_seen if str(x)}
        if cultures and len(cultures) == 1:
            gaps.append("evidence_culture_diversity")
        words=set(re.findall(r"[A-Za-z가-힣_]{4,}", str(objective).casefold()))
        if {"독립", "independent", "self-contained"} & words:
            gaps.append("execution_ownership")
        if {"속도", "speed", "latency"} & words:
            gaps.append("latency_tradeoff")
        folded=str(objective).casefold()
        if any(x in folded for x in ("깊게", "창의", "반례", "여러 관점", "deep", "creative", "counterexample", "multiple perspective")):
            gaps.append("perspective_diversity")
        intent = extract_open_world_intent(objective)
        for facet in intent.facets:
            gaps.append("open_world:" + facet)
        return tuple(dict.fromkeys(gaps))

    def invent(self, *, objective: str, gaps: Iterable[str]) -> tuple[InventedWorld, ...]:
        worlds=[]
        for gap in tuple(dict.fromkeys(str(x) for x in gaps if str(x))):
            token=gap.split(":",1)[-1]
            worlds.append(InventedWorld(
                world_id="invented_"+uuid.uuid4().hex[:14],
                missing_dimension=gap,
                mechanism=f"construct_route_or_representation_for_{token}",
                substrate_hint=f"discover_current_host_substrate_matching_{token}",
                falsification_question=f"What observation would show that solving {token} does not improve the original objective?",
            ))
        return tuple(worlds)
