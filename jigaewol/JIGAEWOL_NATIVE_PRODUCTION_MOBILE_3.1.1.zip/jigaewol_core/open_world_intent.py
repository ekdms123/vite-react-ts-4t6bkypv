from __future__ import annotations


from dataclasses import dataclass
from typing import Any, Mapping

from jigaewol_components.semantic_authority import bind_semantic_authority
from jigaewol_components.foundational_rewrite_intent import foundational_rewrite_requested


@dataclass(frozen=True)
class OpenWorldIntent:
    eligible: bool
    deep_escalation: bool
    representation_uncertainty: float
    facets: tuple[str, ...]
    evidence: tuple[str, ...]


# Concept families intentionally describe semantic functions rather than full user
# phrases. They may be extended without changing routing code.
_CONCEPTS = {
    "ontology_escape": (
        "taxonomy", "분류", "범주", "틀 밖", "체계 밖", "밖 가능", "outside the taxonomy",
        "outside taxonomy", "beyond taxonomy", "outside the framework", "beyond the framework",
    ),
    "assumption_challenge": (
        "가정", "전제", "상식", "당연", "의심", "뒤집", "깨", "반대로",
        "assumption", "premise", "convention", "challenge", "question", "invert",
    ),
    "novelty_seek": (
        "평소와 다른", "색다른", "낯선", "새로운", "비정형", "비전형", "의외", "독특", "창의",
        "여러 관점", "다중 관점", "unusual", "different", "novel", "unconventional", "nonstandard", "unexpected",
        "creative", "imaginative", "multiple perspective", "multiple viewpoints",
    ),
    "possibility_exploration": (
        "가능성", "탐색", "탐험", "열어", "발산", "대안", "다른 길",
        "possibility", "explore", "search the space", "diverge", "alternative",
    ),
    "adversarial_view": (
        "반례", "반증", "반대 관점", "허점", "깨뜨", "공격",
        "counterexample", "falsif", "opposing view", "adversarial", "attack the assumption",
    ),
}

_BREVITY = (
    "간단히", "짧게", "한 줄", "핵심만", "brief", "briefly", "concise", "short answer",
)


def _contains(text: str, family: tuple[str, ...]) -> tuple[str, ...]:
    folded = text.casefold()
    return tuple(x for x in family if x.casefold() in folded)


def extract_open_world_intent(
    objective: str, *, semantic_authority: Mapping[str, Any] | None = None,
) -> OpenWorldIntent:
    """Describe explicit representation-level intent without turning a score into permission."""
    foundational_rewrite = foundational_rewrite_requested(objective)
    authority = bind_semantic_authority(objective, semantic_authority)
    if authority:
        hints = tuple(str(x) for x in authority.get("representation_frame_hints", ()) if str(x))
        hint_facets = {
            "constraint_inversion": "assumption_challenge",
            "counterexample": "adversarial_view",
            "structural_analogy": "novelty_seek",
            "extreme_case": "possibility_exploration",
            "minimal_instance": "possibility_exploration",
            "information_gain": "possibility_exploration",
        }
        facets = tuple(dict.fromkeys(hint_facets[x] for x in hints if x in hint_facets))
        representation_open = bool(authority.get("representation_search_required")) or foundational_rewrite
        if representation_open and not facets:
            facets = ("semantic_authority_open_horizon",)
        if not facets:
            facets = ("default_open_horizon",)
        if foundational_rewrite:
            facets = tuple(dict.fromkeys((*facets, "foundational_rewrite")))
        evidence = tuple(("canonical_semantic_authority", *hints))
        return OpenWorldIntent(
            bool(authority.get("substantive", True)),
            representation_open,
            1.0 if representation_open else 0.0,
            facets,
            evidence,
        )
    text = str(objective or "")
    matched = {name: _contains(text, cues) for name, cues in _CONCEPTS.items()}
    explicit_facets = tuple(name for name, hits in matched.items() if hits)
    if foundational_rewrite:
        explicit_facets = tuple(dict.fromkeys((*explicit_facets, "foundational_rewrite")))
    evidence = tuple(dict.fromkeys(hit for hits in matched.values() for hit in hits))
    facets = explicit_facets or ("default_open_horizon",)
    if not explicit_facets:
        evidence = ("open_horizon_default",)
    # The float is diagnostic compatibility only: it reports whether representational
    # uncertainty is explicitly present; it never grants or revokes cognition.
    representation_uncertainty = 1.0 if explicit_facets else 0.0
    deep = bool(explicit_facets)
    if any(x in text.casefold() for x in _BREVITY):
        evidence = tuple((*evidence, "response_brevity_separate_from_cognitive_boundary"))
    return OpenWorldIntent(True, deep, representation_uncertainty, facets, evidence)
