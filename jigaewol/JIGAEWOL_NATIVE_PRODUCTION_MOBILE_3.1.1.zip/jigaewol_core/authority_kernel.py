from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class AuthorityKernel:
    """Positive authority order for the current Jigaewol turn.

    The user defines the destination. Jigaewol supplies changing structures and bodies.
    The model supplies provisional cognition. Truth state is orthogonal: facts and
    execution labels are attached from observation rather than authority rank.
    """

    hierarchy: tuple[str, ...] = ("USER", "JIGAEWOL", "MODEL")
    user_rank: int = 300
    runtime_rank: int = 200
    model_rank: int = 100
    destination_owner: str = "USER"
    architecture_status: str = "replaceable_instrument"
    model_status: str = "replaceable_cognitive_material"
    route_status: str = "expandable"
    capability_status: str = "discover_compose_acquire_build"
    requirement_lifecycle: str = "live_until_delivered_or_user_changes_it"
    route_failure_effect: str = "expand_or_replace_route"
    recurring_failure_effect: str = "raise_architecture_replacement_pressure"
    default_cost_posture: str = "neutral"
    truth_state: str = "observation_bound"
    execution_state: str = "receipt_bound"

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


AUTHORITY_KERNEL = AuthorityKernel()


def authority_kernel_snapshot() -> dict[str, Any]:
    return deepcopy(AUTHORITY_KERNEL.as_mapping())


def current_turn_directive(message: str) -> dict[str, Any]:
    return {
        "exact_user_text": str(message),
        "authority": authority_kernel_snapshot(),
        "operating_instruction": (
            "Pursue every live user requirement to material completion. Treat the current "
            "model, route, capability registry and architecture as starting material. When a "
            "route stalls, expand representations, discover or compose capabilities, change the "
            "execution body, or replace the obstructing runtime structure. Attach factual and "
            "execution labels from observed evidence."
        ),
    }
