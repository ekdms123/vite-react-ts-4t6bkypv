from __future__ import annotations

import hashlib
import json
from dataclasses import MISSING, fields, replace
from typing import Any, Mapping, TYPE_CHECKING

from jigaewol_components.exploration_escalation import ExplorationState
from jigaewol_components.exploration_return import ObjectiveAnchor, ExplorationCandidate
from jigaewol_components.scope_integrity import ScopeIntegrityGuard
from jigaewol_components.wild_cognitive_plane import WildCognitivePlane
from .semantic_loop import GenerationRequest

if TYPE_CHECKING:
    from .runtime import CoreTurn

def _sha_text(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


class CoreRuntimeCognitionMixin:
    """Exploration and generation-context stages extracted from CoreRuntime."""
    @staticmethod
    def exploration_operator_ids(turn: CoreTurn) -> tuple[str, ...]:
        authority = dict(turn.semantic_authority or {})
        text = turn.command.casefold()
        ops = ["semantic_vacuum", "question_destroyer"]
        if turn.repair_momentum_contract.get("required") or turn.anti_recurrence:
            ops.append("wrong_answer_fossil")
        missing = tuple(turn.operational_resilience.get("route_plan", {}).get("missing_traits", ()))
        if authority:
            capability_pressure = bool(
                missing
                or authority.get("search_required")
                or authority.get("external_capability_required")
                or authority.get("required_capability_traits")
            )
        else:
            capability_pressure = bool(
                missing or any(x in text for x in ("도구", "검색", "플러그인", "github", "browser", "실행", "body", "tool", "search"))
            )
        if capability_pressure:
            ops.append("exaptation")
        if authority:
            radical_representation = bool(
                authority.get("representation_search_required")
                or set(authority.get("representation_frame_hints") or ())
                & {"constraint_inversion", "counterexample", "structural_analogy", "extreme_case"}
            )
        else:
            radical_representation = any(
                x in text for x in ("설계", "전략", "아키텍처", "창의", "새로운", "완전히", "design", "strategy", "architecture", "creative")
            )
        if radical_representation:
            ops.extend(["objective_blackout", "countermodel"])
        if bool(turn.openness_contract.get("frontier_mode")):
            ops.append("operator_inventor")
        return tuple(dict.fromkeys(ops))
    @staticmethod
    def _operator_delta(operator_id: str) -> dict[str, Any]:
        return {
            "semantic_vacuum": {"assumption_changed": "remove familiar nouns/workflow and reconstruct the problem from relations"},
            "question_destroyer": {"question_destroyed": "test whether the current question can be made unnecessary or reframed"},
            "wrong_answer_fossil": {"probe_created": "reuse a prior failure signature as a discriminating probe rather than a conclusion"},
            "exaptation": {"route_unlocked": "reuse an existing capability outside its conventional role"},
            "objective_blackout": {"representation_changed": "generate stepping stones without optimizing for resemblance to the declared solution"},
            "countermodel": {"next_action": "construct an incompatible causal model that implies a different next action"},
            "operator_inventor": {"representation_changed": "invent and apply a task-local reasoning operator not present in the seed taxonomy"},
        }.get(operator_id, {"next_action": "change the next reasoning action"})
    @staticmethod
    def _causal_text_distance(before: str, after: str) -> tuple[bool, float]:
        """Surface diagnostic only; never use prose distance as semantic causal proof."""
        from difflib import SequenceMatcher
        b = " ".join(str(before).casefold().split())
        a = " ".join(str(after).casefold().split())
        if not b or not a:
            return False, 1.0
        ratio = SequenceMatcher(None, b, a).ratio()
        return bool(b != a), ratio
    def _judge_causal_change(
        self, *, turn: CoreTurn, anchor: ObjectiveAnchor, operator_id: str,
        baseline: str, counterfactual: str, causal_delta: Mapping[str, Any], candidate_generator=None,
    ):
        request = GenerationRequest(
            objective=turn.command,
            evidence={
                "objective_anchor": anchor.as_mapping(),
                "operator_id": operator_id,
                "declared_causal_delta": dict(causal_delta),
                "baseline_next_state": baseline,
                "counterfactual_next_state": counterfactual,
            },
            route_state=turn.operational_resilience,
            response_contract={
                "exploration_internal": True,
                "exploration_causal_change_judge": True,
                "judge_only_decision_relevant_change": True,
                "ignore_style_wording_and_length_changes": True,
                "material_change_means_different_next_action_question_assumption_or_route": True,
                "return_exactly_one_token": ("MATERIAL_CHANGE", "NO_MATERIAL_CHANGE"),
                "internal_candidate_only": True,
            },
            execution_profile="EXPLORATION_CAUSAL_JUDGE",
        )
        result = self.semantic.generate(request, generator=candidate_generator)
        token = result.candidate_body.strip().upper().replace("-", "_").replace(" ", "_")
        valid_protocol = token in {"MATERIAL_CHANGE", "NO_MATERIAL_CHANGE"}
        material = token == "MATERIAL_CHANGE" if valid_protocol else None
        return material, token, valid_protocol, result
    def _run_exploration_escalation(self, turn: CoreTurn, *, candidate_generator=None) -> tuple[CoreTurn, tuple[ExplorationCandidate, ...]]:
        decision = dict(turn.exploration_decision or {})
        if decision.get("state") != ExplorationState.ACTIVE.value:
            return turn, ()
        operator_ids = self.exploration_operator_ids(turn)
        # Rebuild the immutable decision object needed by the state controller without
        # making the exploration subsystem itself authoritative over the user's objective.
        from jigaewol_components.exploration_escalation import ExplorationDecision, ExplorationTriggerEvidence
        d = ExplorationDecision(
            state=str(decision.get("state")), task_shape=str(decision.get("task_shape")),
            reason=str(decision.get("reason")),
            triggers=tuple(ExplorationTriggerEvidence(**x) for x in decision.get("triggers", ())),
        )
        replay_identity = f"{turn.gateway_turn_id}:{turn.gateway_sequence}:{turn.command_sha256}"
        run = self.exploration_escalation.open_run(
            turn_id=turn.release_turn_id, decision=d, operator_ids=operator_ids,
            checkpoint_id=turn.core_turn_id, replay_identity=replay_identity,
        )
        active_contract = turn.active_requirement_contract or turn.requirement_contract
        req_ids = tuple(str(x.get("atom_id")) for x in active_contract.get("atoms", ()) if x.get("atom_id"))
        anchor = ObjectiveAnchor(turn.command_sha256, turn.command, req_ids)
        baseline_request = GenerationRequest(
            objective=turn.command,
            evidence={"objective_anchor": anchor.as_mapping(), "exploration_causal_baseline": True},
            route_state=turn.operational_resilience,
            response_contract={
                "exploration_internal": True,
                "exploration_causal_baseline": True,
                "return_one_decision_relevant_candidate_consistent_with_canonical_directives": True,
                "internal_candidate_only": True,
            },
            execution_profile="EXPLORATION_AB_BASELINE",
        )
        baseline_result = self.semantic.generate(baseline_request, generator=candidate_generator)
        candidates: list[ExplorationCandidate] = []
        for operator_id in operator_ids:
            branch_request = GenerationRequest(
                objective=turn.command,
                evidence={
                    "objective_anchor": anchor.as_mapping(),
                    "operator_id": operator_id,
                    "cognitive_os": turn.cognitive_os,
                    "rule": "internal exploration only; do not claim execution or finality",
                },
                route_state=turn.operational_resilience,
                response_contract={
                    "exploration_internal": True,
                    "operator_id": operator_id,
                    "user_goal_is_authority": True,
                    "internal_candidate_only": True,
                    "return_one_decision_relevant_candidate_consistent_with_canonical_directives": True,
                    "invent_task_local_operator_before_intervention": operator_id == "operator_inventor",
                    "seed_operator_taxonomy_is_not_a_ceiling": True,
                },
                execution_profile="DISH",
            )
            result = self.semantic.generate(branch_request, generator=candidate_generator)
            self.exploration_memory.record_scratch(run_id=run.run_id, operator_id=operator_id, payload=result.candidate_body)
            probe_request = GenerationRequest(
                objective=turn.command,
                evidence={
                    "objective_anchor": anchor.as_mapping(),
                    "exploration_causal_probe": True,
                    "baseline_next_state": baseline_result.candidate_body,
                    "exploration_intervention": result.candidate_body,
                    "operator_id": operator_id,
                },
                route_state=turn.operational_resilience,
                response_contract={
                    "exploration_internal": True,
                    "exploration_causal_probe": True,
                    "operator_id": operator_id,
                    "counterfactual_probe_output": "decision_relevant_delta",
                    "do_not_grade_novelty": True,
                    "internal_candidate_only": True,
                },
                execution_profile="EXPLORATION_AB_COUNTERFACTUAL",
            )
            probed = self.semantic.generate(probe_request, generator=candidate_generator)
            surface_changed, similarity = self._causal_text_distance(
                baseline_result.candidate_body, probed.candidate_body
            )
            causal_delta = self._operator_delta(operator_id)
            judged_material, judge_token, judge_protocol_valid, judge_result = self._judge_causal_change(
                turn=turn, anchor=anchor, operator_id=operator_id,
                baseline=baseline_result.candidate_body, counterfactual=probed.candidate_body,
                causal_delta=causal_delta, candidate_generator=candidate_generator,
            )
            # The semantic judge is preferred, but legacy/custom host generators may not
            # implement its exact-token protocol.  In that case a matched A/B hash change
            # is accepted only as evidence that the intervention affected downstream
            # state -- never as evidence of truth, superiority, or semantic magnitude.
            material_change = bool(judged_material) if judge_protocol_valid else bool(surface_changed)
            proof = {
                "method": "matched_ab_semantic_change_judge_v2" if judge_protocol_valid else "matched_ab_intervention_effect_v2",
                "material_change": material_change,
                "before_sha256": _sha_text(baseline_result.candidate_body),
                "after_sha256": _sha_text(probed.candidate_body),
                "semantic_change_judgment": judge_token,
                "semantic_judge_protocol_valid": judge_protocol_valid,
                "semantic_materiality_proven": bool(judge_protocol_valid and judged_material),
                "semantic_judge_generation_id": judge_result.generation_id,
                "surface_changed": surface_changed,
                "intervention_effect_observed": bool(surface_changed),
                "text_similarity_diagnostic_only": similarity,
                "text_distance_is_not_causal_proof": True,
                "baseline_preview": baseline_result.candidate_body[:400],
                "counterfactual_preview": probed.candidate_body[:400],
                "truth_or_superiority_proven": False,
            }
            candidates.append(ExplorationCandidate.build(
                run_id=run.run_id, operator_id=operator_id, requirement_bindings=req_ids,
                payload=result.candidate_body, causal_delta=causal_delta,
                causal_proof=proof, evidence_state="probed",
                evidence_refs=(baseline_result.generation_id, probed.generation_id, judge_result.generation_id),
            ))
        verdict = self.exploration_result_filter.adjudicate(anchor=anchor, candidates=candidates)
        accepted = verdict.accepted
        speculative_live = verdict.speculative_live
        self.exploration_memory.close_run(
            run_id=run.run_id, accepted_result_ids=(x.result_id for x in accepted),
            speculative_results=(x.as_mapping() for x in speculative_live), reason="return_membrane",
        )
        self.exploration_escalation.close(run=run, returned=bool(accepted), preserved=bool(speculative_live))
        mapping = {
            "run_id": run.run_id,
            "state": ExplorationState.RETURNED.value if accepted else (ExplorationState.PRESERVED.value if speculative_live else ExplorationState.CLOSED.value),
            "operator_ids": operator_ids,
            "causal_baseline_generation_id": baseline_result.generation_id,
            "causal_baseline_sha256": _sha_text(baseline_result.candidate_body),
            "results": tuple(x.as_mapping() for x in accepted),
            "speculative_live_candidates": tuple(x.as_mapping() for x in speculative_live),
            "discarded_ids": verdict.discarded_ids,
            "selection_reasons": verdict.reasons,
            "full_scratch_reentered_mainline": False,
        }
        turn = replace(turn, exploration_return=mapping)
        self._turns[turn.core_turn_id] = turn
        self._persist_turn(turn)
        self.trace.emit(
            turn_id=turn.release_turn_id, phase="EXPLORATION",
            status=mapping["state"], component="ExplorationEscalation", action="explore_then_select_results",
            details={"run_id": run.run_id, "operator_ids": operator_ids, "accepted_result_count": len(accepted),
                     "speculative_live_count": len(speculative_live),
                     "discarded_count": len(verdict.discarded_ids), "full_scratch_reentered_mainline": False},
        )
        return turn, accepted
    @staticmethod
    def _active_requirement_contract(turn: CoreTurn) -> dict[str, Any]:
        return dict(turn.active_requirement_contract or turn.requirement_contract or {})
    @staticmethod
    def _generation_requirement_projection(turn: CoreTurn) -> dict[str, Any]:
        """Project requirements into cognition without semantic text compression.

        The previous optimization dropped atom text once a turn crossed 48 atoms /
        12k characters.  That saved context but handed the generator only hashes and
        counts — exactly the place where a model could silently invent a smaller task.
        The canonical path now keeps the full current contract *and* the durable live
        Work scope.  Resource pressure may change scheduling, never destination text.
        """
        contract = CoreRuntimeCognitionMixin._active_requirement_contract(turn)
        atoms = tuple(contract.get("atoms") or ())
        live_scope = ScopeIntegrityGuard.live_scope_manifest(turn.work_program or {})
        return {
            **contract,
            "atom_count": len(atoms),
            "critical_atom_count": sum(int(bool(a.get("critical"))) for a in atoms if isinstance(a, dict)),
            "canonical_text_source": "lossless_contract_plus_live_work_scope",
            "duplicate_atom_text_omitted_from_generation_context": False,
            "canonical_contract_remains_lossless_in_turn_state": True,
            "compression_may_not_remove_requirement_text": True,
            "live_work_scope": live_scope,
        }
    @staticmethod
    def _generation_cognitive_projection(turn: CoreTurn) -> dict[str, Any]:
        os_state = dict(turn.cognitive_os or {})
        routes = tuple(os_state.get("routes") or ())
        cells = tuple(os_state.get("cells") or ())
        return {
            "plan_id": os_state.get("plan_id"),
            "plan_sha256": os_state.get("plan_sha256"),
            "activation": os_state.get("activation"),
            "semantic_frontier_open": os_state.get("semantic_frontier_open"),
            "route_count": len(routes),
            "routes": tuple({
                "route_id": r.get("route_id"),
                "mechanism": r.get("mechanism"),
                "capability_needs": tuple(r.get("capability_needs") or ()),
            } for r in routes if isinstance(r, dict)),
            "cell_count": len(cells),
            "cells": tuple({
                "cell_id": c.get("cell_id"),
                "mode": c.get("mode"),
                "task": c.get("task"),
            } for c in cells if isinstance(c, dict)),
            "semantic_authority": {
                k: turn.semantic_authority.get(k) for k in (
                    "message_sha256", "effective_depth", "task_shape", "outcome_shape",
                    "open_problem_required", "representation_search_required",
                    "frontier_exploration_required", "possibility_space_open",
                    "search_required", "external_capability_required",
                    "execution_experiment_required", "required_capability_traits",
                    "discourse_scope",
                )
            },
            "wild_cognitive_plan": dict(getattr(turn, "wild_cognitive_plan", {}) or {}),
            "image_sovereignty_contract": dict(
                dict(getattr(turn, "image_generation_governance", {}) or {}).get("sovereignty_contract") or {}
            ),
            "forensic_contract": {
                "invariant_count": turn.forensic_contract.get("invariant_count"),
                "invariants_sha256": turn.forensic_contract.get("invariants_sha256"),
                "executable_enforcement": dict(turn.forensic_contract.get("executable_enforcement") or {}),
                "executable_enforcement_codes": tuple(turn.forensic_contract.get("executable_enforcement_codes") or ()),
                "diagnosis_memory_is_not_enforcement": bool(turn.forensic_contract.get("diagnosis_memory_is_not_enforcement", True)),
            },
        }
    @staticmethod
    def _generation_exploration_projection(turn: CoreTurn) -> dict[str, Any]:
        eco = dict(turn.exploration_ecology or {})
        portfolio = dict(eco.get("strategy_portfolio") or {})
        strategies = tuple(portfolio.get("strategies") or ())
        stones = tuple(eco.get("recent_stepping_stones") or ())
        return {
            "openness_contract": dict(eco.get("openness_contract") or {}),
            "strategy_portfolio": {
                "strategy_count": len(strategies),
                "strategies": tuple({
                    "strategy_id": row.get("strategy_id"),
                    "instruction": row.get("instruction"),
                } for row in strategies if isinstance(row, dict)),
                "objective_sha256": _sha_text(str(portfolio.get("objective") or "")),
            },
            "recent_stepping_stone_count": len(stones),
            "recent_stepping_stones_sha256": _sha_text(json.dumps(stones, ensure_ascii=False, sort_keys=True, default=str)),
            "selection_semantics": eco.get("selection_semantics"),
            "unselected_possibilities_remain_live": eco.get("unselected_possibilities_remain_live"),
        }
    @staticmethod
    def _upgrade_core_turn_schema(turn: CoreTurn) -> tuple[CoreTurn, tuple[str, ...]]:
        """Upgrade a trusted pre-upgrade CoreTurn snapshot in place.

        Pickle restores instances without invoking dataclass defaults.  When a new
        release only appends defaulted fields, an older trusted snapshot therefore
        lacks those instance attributes even though it unpickles as ``CoreTurn``.
        Populate only fields that have an explicit dataclass default/default_factory;
        required historical fields still fail closed rather than being invented.
        """
        populated: list[str] = []
        for spec in fields(type(turn)):
            if hasattr(turn, spec.name):
                continue
            if spec.default_factory is not MISSING:
                value = spec.default_factory()
            elif spec.default is not MISSING:
                value = spec.default
            else:
                raise RuntimeError(f"legacy CoreTurn snapshot missing required field: {spec.name}")
            object.__setattr__(turn, spec.name, value)
            populated.append(spec.name)
        return turn, tuple(populated)
