from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, is_dataclass
from pathlib import Path
from typing import Any, Protocol


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def work_payload(work: Any) -> dict[str, Any]:
    if is_dataclass(work):
        raw = asdict(work)
    elif hasattr(work, "__dict__"):
        raw = dict(vars(work))
    else:
        raw = {"repr": repr(work)}
    # Runtime-local object identity is not authority. Semantic request material is.
    return {
        "executor": str(getattr(work, "executor", raw.get("executor", "")) or ""),
        "operation": str(getattr(work, "operation", raw.get("operation", "")) or ""),
        "payload": raw,
    }


def work_request_sha256(work: Any) -> str:
    return hashlib.sha256(_canonical(work_payload(work)).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class RuntimeActionRequest:
    """First-class effect request derived by CoreRuntime, not by the host bridge."""

    action_id: str
    turn_id: str
    capability: str
    executor: str
    operation: str
    required_traits: tuple[str, ...] = ()
    parameters: dict[str, Any] | None = None
    expected_effects: tuple[str, ...] = ()
    evidence_requirements: tuple[str, ...] = ()
    permission_class: str = "none"
    idempotency_key: str = ""
    route_state: dict[str, Any] | None = None

    @property
    def work_id(self) -> str:
        return self.action_id


@dataclass(frozen=True)
class ActionInvocation:
    invocation_id: str
    request_sha256: str
    parent_step_sha256: str
    request_payload: dict[str, Any]


@dataclass(frozen=True)
class ActionReceipt:
    invocation_id: str
    request_sha256: str
    executor_id: str
    parent_step_sha256: str
    dispatched_at: float
    origin_ref: str
    host_call_observed: bool
    receipt_sha256: str


@dataclass(frozen=True)
class ObservationReceipt:
    invocation_id: str
    request_sha256: str
    result_sha256: str
    success: bool | None
    executor_id: str
    parent_step_sha256: str
    observed_at: float
    origin_ref: str
    result: Any
    action_receipt_sha256: str = ""
    receipt_sha256: str = ""


@dataclass(frozen=True)
class PendingAction:
    invocation_id: str
    request_sha256: str
    request_payload: dict[str, Any]
    parent_step_sha256: str = ""
    kind: str = "action"


@dataclass(frozen=True)
class CompletedAction:
    receipt: ObservationReceipt
    action_receipt: ActionReceipt | None = None


class ActionPort(Protocol):
    def execute(self, request: ActionInvocation) -> CompletedAction | PendingAction: ...


class ActionPending(RuntimeError):
    def __init__(self, pending: PendingAction) -> None:
        super().__init__(f"action receipt required for request_sha256={pending.request_sha256}")
        self.pending = pending


class ActionReceiptLedger:
    """Observed external-effect receipts. Planning is never execution."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "action_receipts.json"
        if not self.path.exists():
            self._write({})

    def _read(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("action receipt ledger root must be a JSON object")
            return data
        except Exception as exc:
            failure_path = self.root / "action_receipt_ledger_failures.jsonl"
            try:
                with failure_path.open("a", encoding="utf-8") as fh:
                    fh.write(json.dumps({
                        "observed_at": time.time(),
                        "error_type": type(exc).__name__,
                        "error": str(exc)[:500],
                        "source": str(self.path),
                    }, ensure_ascii=False, sort_keys=True) + "\n")
            except OSError:
                pass
            raise RuntimeError(f"action receipt ledger is unreadable: {type(exc).__name__}: {exc}") from exc

    def _write(self, rows: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(rows, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    def record(self, *, request_sha256: str, invocation_id: str, result: Any,
               success: bool | None, executor_id: str, parent_step_sha256: str,
               origin_ref: str, host_call_observed: bool) -> dict[str, Any]:
        if success is True and host_call_observed is not True:
            raise PermissionError("successful external action requires observed host-call evidence")
        result_sha = hashlib.sha256(_canonical(result).encode("utf-8")).hexdigest()
        observed_at = time.time()
        action_body = {
            "invocation_id": str(invocation_id),
            "request_sha256": str(request_sha256),
            "executor_id": str(executor_id),
            "parent_step_sha256": str(parent_step_sha256),
            "dispatched_at": observed_at,
            "origin_ref": str(origin_ref),
            "host_call_observed": bool(host_call_observed),
        }
        action_receipt_sha = hashlib.sha256(_canonical(action_body).encode("utf-8")).hexdigest()
        observation_body = {
            "invocation_id": str(invocation_id),
            "request_sha256": str(request_sha256),
            "result_sha256": result_sha,
            "success": success,
            "executor_id": str(executor_id),
            "parent_step_sha256": str(parent_step_sha256),
            "observed_at": observed_at,
            "origin_ref": str(origin_ref),
            "action_receipt_sha256": action_receipt_sha,
        }
        observation_receipt_sha = hashlib.sha256(_canonical(observation_body).encode("utf-8")).hexdigest()
        row = {
            **observation_body,
            "result": result,
            "host_call_observed": bool(host_call_observed),
            "action_receipt": {**action_body, "receipt_sha256": action_receipt_sha},
            "observation_receipt_sha256": observation_receipt_sha,
        }
        rows = self._read(); rows[str(request_sha256)] = row; self._write(rows)
        return row

    def consume(self, request_sha256: str) -> dict[str, Any] | None:
        return self._read().get(str(request_sha256))


class ReceiptActionPort:
    def __init__(self, ledger: ActionReceiptLedger) -> None:
        self.ledger = ledger

    def execute(self, request: ActionInvocation) -> CompletedAction | PendingAction:
        row = self.ledger.consume(request.request_sha256)
        if row is None:
            return PendingAction(request.invocation_id, request.request_sha256, request.request_payload, request.parent_step_sha256)
        if str(row.get("invocation_id")) != request.invocation_id:
            raise PermissionError("action invocation id mismatch")
        if str(row.get("parent_step_sha256") or "") != str(request.parent_step_sha256 or ""):
            raise PermissionError("action receipt parent-step binding mismatch")
        action_row = dict(row.get("action_receipt") or {})
        action_receipt = ActionReceipt(
            invocation_id=str(action_row.get("invocation_id") or request.invocation_id),
            request_sha256=str(action_row.get("request_sha256") or request.request_sha256),
            executor_id=str(action_row.get("executor_id") or row.get("executor_id") or ""),
            parent_step_sha256=str(action_row.get("parent_step_sha256") or request.parent_step_sha256),
            dispatched_at=float(action_row.get("dispatched_at") or row.get("observed_at") or time.time()),
            origin_ref=str(action_row.get("origin_ref") or row.get("origin_ref") or ""),
            host_call_observed=bool(action_row.get("host_call_observed", row.get("host_call_observed"))),
            receipt_sha256=str(action_row.get("receipt_sha256") or ""),
        )
        observation = ObservationReceipt(
            invocation_id=request.invocation_id,
            request_sha256=request.request_sha256,
            result_sha256=str(row.get("result_sha256") or ""),
            success=row.get("success"), executor_id=str(row.get("executor_id") or ""),
            parent_step_sha256=request.parent_step_sha256,
            observed_at=float(row.get("observed_at") or time.time()),
            origin_ref=str(row.get("origin_ref") or ""), result=row.get("result"),
            action_receipt_sha256=str(action_receipt.receipt_sha256 or ""),
            receipt_sha256=str(row.get("observation_receipt_sha256") or ""),
        )
        return CompletedAction(observation, action_receipt=action_receipt)

    def executor(self, *, parent_step_sha256_getter=lambda: ""):
        def run(work: Any):
            req_sha = work_request_sha256(work)
            existing = self.ledger.consume(req_sha)
            bound_parent = (str(existing.get("parent_step_sha256") or "") if existing else "") or str(parent_step_sha256_getter() or "")
            invocation = ActionInvocation(
                invocation_id="act_" + uuid.uuid5(uuid.NAMESPACE_URL, req_sha).hex[:20],
                request_sha256=req_sha,
                parent_step_sha256=bound_parent,
                request_payload=work_payload(work),
            )
            outcome = self.execute(invocation)
            if isinstance(outcome, PendingAction):
                raise ActionPending(outcome)
            # Preserve the receipt-proven execution truth when handing the observation
            # back to CoreRuntime. The old path stripped the receipt and forced the
            # runtime to guess success from arbitrary result payload shape.
            result = outcome.receipt.result
            receipt_meta = {
                "invocation_id": outcome.receipt.invocation_id,
                "request_sha256": outcome.receipt.request_sha256,
                "result_sha256": outcome.receipt.result_sha256,
                "success": outcome.receipt.success,
                "executor_id": outcome.receipt.executor_id,
                "origin_ref": outcome.receipt.origin_ref,
                "receipt_sha256": outcome.receipt.receipt_sha256,
                "action_receipt_sha256": outcome.receipt.action_receipt_sha256,
                "host_call_observed": bool(outcome.action_receipt and outcome.action_receipt.host_call_observed),
            }
            if isinstance(result, dict):
                return {**result, "success": outcome.receipt.success, "_observed_action_receipt": receipt_meta}
            return {"success": outcome.receipt.success, "result": result, "_observed_action_receipt": receipt_meta}
        return run
