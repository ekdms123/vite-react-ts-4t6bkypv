from __future__ import annotations


import hashlib
import json
import operator
import re
import time
import uuid
from dataclasses import asdict, dataclass, field, replace
from typing import Any, Iterable, Protocol


@dataclass(frozen=True)
class GenerationRequest:
    objective: str
    evidence: dict[str, Any]
    route_state: dict[str, Any]
    response_contract: dict[str, Any]
    execution_profile: str = "STANDARD"
    cognitive_worlds: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    active_world: dict[str, Any] | None = None
    falsification_questions: tuple[str, ...] = field(default_factory=tuple)
    counterframes: tuple[str, ...] = field(default_factory=tuple)

    def canonical_payload(self) -> dict[str, Any]:
        return {
            "objective": str(self.objective),
            "evidence": self.evidence,
            "route_state": self.route_state,
            "response_contract": self.response_contract,
            "execution_profile": str(self.execution_profile),
            "cognitive_worlds": list(self.cognitive_worlds),
            "active_world": self.active_world,
            "falsification_questions": list(self.falsification_questions),
            "counterframes": list(self.counterframes),
        }

    def sha256(self) -> str:
        raw = json.dumps(self.canonical_payload(), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class GenerationResult:
    generation_id: str
    candidate_body: str
    producer_id: str
    metadata: dict[str, Any]
    created_at: float


@dataclass(frozen=True)
class VerificationResult:
    verifier_id: str
    failure_family: str
    success: bool | None
    findings: tuple[str, ...]
    evidence: dict[str, Any]


class CandidateGenerator(Protocol):
    def __call__(self, request: GenerationRequest) -> str | GenerationResult: ...


class CandidateVerifier(Protocol):
    verifier_id: str
    failure_family: str
    def __call__(self, objective: str, candidate: str, evidence: dict[str, Any]) -> VerificationResult: ...


class BasicResponseVerifier:
    verifier_id = "basic_response_contract"
    failure_family = "structural_validation"

    def __call__(self, objective: str, candidate: str, evidence: dict[str, Any]) -> VerificationResult:
        findings=[]
        if not isinstance(candidate, str) or not candidate.strip(): findings.append("empty_candidate")
        if len(candidate.strip()) < 1: findings.append("zero_information")
        return VerificationResult(self.verifier_id, self.failure_family, not findings, tuple(findings), {"candidate_chars": len(candidate or "")})


class ArithmeticVerifier:
    verifier_id = "deterministic_arithmetic"
    failure_family = "deterministic_execution"
    _simple = re.compile(r"^\s*(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)\s*(?:=|은|는|\?|？)?\s*$")

    def __call__(self, objective: str, candidate: str, evidence: dict[str, Any]) -> VerificationResult:
        text=str(objective).strip().replace("얼마야", "").replace("계산해", "").strip()
        m=self._simple.match(text)
        if not m:
            return VerificationResult(self.verifier_id, self.failure_family, True, ("not_applicable",), {"applicable": False})
        a=float(m.group(1)); b=float(m.group(3)); op=m.group(2)
        funcs={"+":operator.add,"-":operator.sub,"*":operator.mul,"/":operator.truediv}
        try: expected=funcs[op](a,b)
        except Exception as exc:
            return VerificationResult(self.verifier_id, self.failure_family, False, (type(exc).__name__,), {"applicable": True})
        numbers=[float(x) for x in re.findall(r"-?\d+(?:\.\d+)?", candidate)]
        ok=any(abs(x-expected) < 1e-9 for x in numbers)
        return VerificationResult(self.verifier_id, self.failure_family, ok, (() if ok else ("expected_result_not_present",)), {"applicable": True, "expected": expected})


class ObjectiveRelevanceVerifier:
    verifier_id = "objective_relevance"
    failure_family = "semantic_relevance"
    _explanation_markers = ("설명", "분석", "비교", "왜", "어떻게", "explain", "analy", "compare", "why", "how")
    _brevity_markers = ("한 단어", "한단어", "one word", "짧게", "briefly", "yes/no")
    _creative_markers = ("비유", "창의", "상상", "metaphor", "creative", "analogy")
    _obvious_nonsense = {"바나나", "banana", "asdf", "qwerty", "???", "n/a", "몰라", "모름"}
    _stop = {"the","a","an","and","or","to","of","in","on","for","with","is","are","을","를","이","가","은","는","에","의","로","으로","해줘","해주세요"}
    _domains = {
        "physics": ("양자", "중력", "시공간", "물리", "quantum", "gravity", "spacetime", "relativity", "mechanics", "particle"),
        "automotive": ("자동차", "타이어", "엔진", "브레이크", "차량", "car", "tire", "tyre", "engine", "brake", "vehicle"),
        "cooking": ("요리", "레시피", "재료", "오븐", "recipe", "cook", "ingredient", "oven"),
        "finance": ("주식", "채권", "금리", "투자", "stock", "bond", "interest rate", "portfolio", "investment"),
        "software": ("코드", "함수", "버그", "파이썬", "code", "function", "bug", "python", "compiler", "api"),
        "biology": ("세포", "유전자", "단백질", "생물", "cell", "gene", "protein", "biology", "genome"),
        "law": ("법률", "계약", "판례", "법원", "law", "legal", "contract", "court", "statute"),
    }

    @classmethod
    def _tokens(cls, text: str) -> tuple[str, ...]:
        return tuple(t for t in re.findall(r"[A-Za-z0-9가-힣_]+", str(text).casefold()) if len(t) > 1 and t not in cls._stop)

    @classmethod
    def _domain_hits(cls, text: str) -> tuple[str, ...]:
        folded=str(text).casefold()
        return tuple(name for name, cues in cls._domains.items() if any(cue.casefold() in folded for cue in cues))

    def __call__(self, objective: str, candidate: str, evidence: dict[str, Any]) -> VerificationResult:
        obj = str(objective or "").strip()
        cand = str(candidate or "").strip()
        obj_tokens = set(self._tokens(obj))
        cand_tokens = set(self._tokens(cand))
        overlap = sorted(obj_tokens & cand_tokens)
        explanatory = any(x in obj.casefold() for x in self._explanation_markers)
        brevity_requested = any(x in obj.casefold() for x in self._brevity_markers)
        creative_requested = any(x in obj.casefold() for x in self._creative_markers)
        tiny = len(cand) <= 24 or len(cand_tokens) <= 2
        obvious = cand.casefold() in self._obvious_nonsense
        no_overlap = bool(obj_tokens) and not overlap
        obj_domains=set(self._domain_hits(obj)); cand_domains=set(self._domain_hits(cand))
        aligned_domains=bool(obj_domains & cand_domains)
        disjoint_clear_domains=bool(obj_domains and cand_domains and not aligned_domains)

        success: bool | None = True
        findings: tuple[str, ...] = ()
        decision="pass"
        if obvious or (explanatory and not brevity_requested and tiny and no_overlap):
            success=False
            findings=("manifestly_irrelevant_nonsense",)
            decision="fail"
        elif explanatory and not creative_requested and len(cand) >= 80 and no_overlap and disjoint_clear_domains:
            # A deterministic lexical/domain heuristic is not allowed to declare
            # semantic falsehood. It requests a second semantic check; unresolved
            # uncertainty is labeled rather than turned into release permission.
            success=None
            findings=("secondary_semantic_check_required",)
            decision="escalate"

        return VerificationResult(
            self.verifier_id, self.failure_family, success, findings,
            {
                "truth_claimed": False,
                "lexical_overlap": overlap,
                "candidate_chars": len(cand),
                "objective_domains": sorted(obj_domains),
                "candidate_domains": sorted(cand_domains),
                "decision": decision,
                "heuristic_scope": "relevance_only_not_truth",
                "cross_language_or_creative_longform_not_failed_for_lexical_mismatch": True,
            },
        )


class SemanticCandidateEngine:
    """Owns candidate generation in the canonical runtime hot path.

    A model/provider is a replaceable component supplied to this engine. The caller no
    longer hands the release gate an already-finished answer. Verification families
    are kept separate so materially different checkers can be attached without
    turning provenance checks into semantic-quality claims.
    """

    def __init__(self, generator: CandidateGenerator | None = None, *, producer_id: str = "semantic_generator",
                 verifiers: Iterable[CandidateVerifier] = ()) -> None:
        self.generator=generator
        self.producer_id=str(producer_id)
        default=(BasicResponseVerifier(), ArithmeticVerifier(), ObjectiveRelevanceVerifier())
        provided=tuple(verifiers)
        self.verifiers=provided or default

    def generate(self, request: GenerationRequest, *, generator: CandidateGenerator | None = None) -> GenerationResult:
        provider=generator or self.generator
        if provider is None:
            raise RuntimeError("semantic candidate generation requires a connected model/solver/generator component")
        value=provider(request)
        if isinstance(value, GenerationResult):
            return value
        return GenerationResult(
            generation_id="generation_" + uuid.uuid4().hex[:16],
            candidate_body=str(value), producer_id=self.producer_id,
            metadata={
                "active_world_id": (request.active_world or {}).get("world_id") if request.active_world else None,
                "execution_profile": request.execution_profile,
            }, created_at=time.time(),
        )

    def generate_portfolio(self, request: GenerationRequest, *, generator: CandidateGenerator | None = None, max_worlds: int | None = None) -> tuple[GenerationResult, ...]:
        rows=[self.generate(replace(request, active_world=None), generator=generator)]
        worlds=tuple(request.cognitive_worlds) if max_worlds is None else tuple(request.cognitive_worlds)[:max(0,int(max_worlds))]
        for world in worlds:
            rows.append(self.generate(replace(request, active_world=dict(world)), generator=generator))
        return tuple(rows)

    def synthesize(self, request: GenerationRequest, portfolio: Iterable[GenerationResult], *, generator: CandidateGenerator | None = None) -> GenerationResult:
        rows=tuple(portfolio)
        if not rows:
            raise ValueError("cannot synthesize an empty candidate portfolio")
        if len(rows) == 1:
            only=rows[0]
            return replace(only, metadata={**dict(only.metadata), "world_ids_exposed": tuple(w.get("world_id") for w in request.cognitive_worlds if w.get("world_id")), "world_ids_used_in_synthesis": ()})
        world_ids=tuple(dict.fromkeys(str(r.metadata.get("active_world_id")) for r in rows if r.metadata.get("active_world_id")))
        synthesis_evidence={
            **dict(request.evidence),
            "candidate_portfolio": tuple({"candidate_body": r.candidate_body, "producer_id": r.producer_id, "active_world_id": r.metadata.get("active_world_id")} for r in rows),
        }
        synthesis_request=replace(
            request, active_world=None, evidence=synthesis_evidence,
            response_contract={**dict(request.response_contract), "synthesis": True, "preserve_incompatible_worlds_until_evidence": True},
        )
        final=self.generate(synthesis_request, generator=generator)
        return replace(final, metadata={**dict(final.metadata), "world_ids_exposed": tuple(w.get("world_id") for w in request.cognitive_worlds if w.get("world_id")), "world_ids_used_in_synthesis": world_ids})

    def verify(self, *, objective: str, candidate: str, evidence: dict[str, Any],
               verifiers: Iterable[CandidateVerifier] | None = None) -> tuple[VerificationResult, ...]:
        checks=tuple(verifiers) if verifiers is not None else self.verifiers
        rows=tuple(v(objective, candidate, evidence) for v in checks)
        material=[x for x in rows if "not_applicable" not in x.findings]
        families={x.failure_family for x in material}
        # Diversity is reported, not fabricated. Some tasks genuinely have only one
        # applicable deterministic verifier until another verifier component is connected.
        return rows

    @staticmethod
    def summary(rows: Iterable[VerificationResult]) -> dict[str, Any]:
        rows=tuple(rows)
        applicable=[x for x in rows if "not_applicable" not in x.findings]
        return {
            "all_applicable_passed": all(x.success is True for x in applicable),
            "unknown_verifier_count": sum(x.success is None for x in applicable),
            "applicable_verifier_count": len(applicable),
            "failure_family_count": len({x.failure_family for x in applicable}),
            "verifiers": [asdict(x) for x in rows],
        }
