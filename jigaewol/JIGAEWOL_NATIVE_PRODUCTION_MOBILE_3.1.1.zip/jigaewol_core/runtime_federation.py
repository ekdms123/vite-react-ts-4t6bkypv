from __future__ import annotations

"""Federated runtime components communicating through immutable artifacts.

The federation owns source compilation, continuity, capability observation, planning,
execution receipts, evidence, release receipts, and open-world audit boundaries.
CoreRuntime may remain a compatibility facade while these contracts progressively own
canonical execution.
"""

import hashlib
import json
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable, Mapping

from jigaewol_components.capability_runtime import (
    CapabilityRuntime,
    CapabilitySnapshot,
    CapabilityTruth,
    HostAdapter,
    HostObservationContext,
)
from jigaewol_components.continuity_linker import AuthorityGraph, ContinuityLinker
from jigaewol_components.open_world_guard import ConstraintAuditReport, OpenWorldConstraintAuditor
from jigaewol_components.source_directive_compiler import ClauseGraph, DirectiveClause, SourceDirectiveCompiler


def _hash_payload(payload: Mapping[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _norm(value: str) -> str:
    return re.sub(r"[^0-9a-zA-Z가-힣]+", " ", str(value or "").casefold()).strip()


def _tokens(value: str) -> set[str]:
    return {token for token in _norm(value).split() if token}


def _lexical_similarity(left: str, right: str) -> float:
    a, b = _norm(left), _norm(right)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    if a in b or b in a:
        return 0.92
    ta, tb = _tokens(a), _tokens(b)
    overlap = len(ta & tb) / max(1, len(ta | tb))
    sequence = SequenceMatcher(None, a, b).ratio()
    return max(overlap, sequence * 0.65)


@dataclass(frozen=True)
class CapabilityMatch:
    capability_id: str
    score: float
    provider_score: float
    semantic_score: float
    target_score: float
    action_score: float
    historical_score: float
    matched_semantics: tuple[str, ...]
    matched_actions: tuple[str, ...]
    eligible: bool
    rejection_reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class PlannedOperation:
    operation_id: str
    clause_id: str
    effect: str
    target: str
    selected_capability_id: str | None
    candidate_matches: tuple[CapabilityMatch, ...]
    status: str
    authority_graph_id: str
    capability_snapshot_id: str


@dataclass(frozen=True)
class ExecutionPlanArtifact:
    artifact_id: str
    authority_graph_id: str
    capability_snapshot_id: str
    operations: tuple[PlannedOperation, ...]
    status: str = "planned"


@dataclass(frozen=True)
class ExecutionReceiptArtifact:
    artifact_id: str
    plan_id: str
    observations: tuple[tuple[str, str], ...]
    status: str


@dataclass(frozen=True)
class EvidenceGraphArtifact:
    artifact_id: str
    receipt_ids: tuple[str, ...]
    verified: bool
    facts: tuple[tuple[str, str], ...]


@dataclass(frozen=True)
class ReleaseReceiptArtifact:
    artifact_id: str
    authority_graph_id: str
    evidence_graph_id: str
    releasable: bool


@dataclass(frozen=True)
class FederatedTurnState:
    clause_graph: ClauseGraph
    authority_graph: AuthorityGraph
    capability_snapshot: CapabilitySnapshot


class SourceDirectiveRuntime:
    def __init__(self, compiler: SourceDirectiveCompiler | None = None) -> None:
        self.compiler = compiler or SourceDirectiveCompiler()

    def compile(self, source_text: str, *, turn_id: str = "") -> ClauseGraph:
        return self.compiler.compile(source_text, turn_id=turn_id)


class ContinuityRuntime:
    def __init__(self, linker: ContinuityLinker | None = None) -> None:
        self.linker = linker or ContinuityLinker()

    def link(self, *, previous: ClauseGraph | None, current: ClauseGraph) -> AuthorityGraph:
        return self.linker.link(previous=previous, current=current)


class CapabilityMatcher:
    """Evidence-bounded clause-to-capability matcher.

    The matcher may rank already-authorized clause effects against the current capability
    snapshot. It cannot invent an effect, promote historical evidence to liveness, or
    bind a negative/non-authoritative clause to an executable provider.
    """

    def __init__(self, *, min_score: float = 0.50, min_margin: float = 0.10) -> None:
        self.min_score = float(min_score)
        self.min_margin = float(min_margin)

    @staticmethod
    def _eligibility(clause: DirectiveClause, capability: CapabilityTruth) -> tuple[bool, tuple[str, ...]]:
        reasons: list[str] = []
        if not clause.authoritative:
            reasons.append("clause_not_authoritative")
        if clause.polarity == "negative":
            reasons.append("negative_clause_is_constraint")
        if clause.quoted or clause.hypothetical:
            reasons.append("non_executable_discourse")
        if not capability.currently_exposed:
            reasons.append("not_currently_exposed")
        if not capability.currently_callable:
            reasons.append("not_currently_callable")
        return not reasons, tuple(reasons)

    @staticmethod
    def _best_against(query: str, candidates: tuple[str, ...]) -> tuple[float, tuple[str, ...]]:
        scored = sorted(
            ((_lexical_similarity(query, candidate), candidate) for candidate in candidates if candidate),
            reverse=True,
        )
        if not scored:
            return 0.0, ()
        best = scored[0][0]
        matches = tuple(candidate for score, candidate in scored if score == best and score > 0.0)
        return best, matches

    def match_one(self, *, clause: DirectiveClause, capability: CapabilityTruth) -> CapabilityMatch:
        eligible, reasons = self._eligibility(clause, capability)
        if not eligible:
            return CapabilityMatch(
                capability_id=capability.capability_id,
                score=0.0,
                provider_score=0.0,
                semantic_score=0.0,
                target_score=0.0,
                action_score=0.0,
                historical_score=1.0 if capability.historical_success else 0.0,
                matched_semantics=(),
                matched_actions=(),
                eligible=False,
                rejection_reasons=reasons,
            )

        source = f"{clause.source_text} {clause.target} {clause.effect}"
        source_norm = _norm(source).replace(" ", "")
        provider_labels = tuple(dict.fromkeys((capability.capability_id, capability.provider)))
        provider_score = max(
            (
                1.0
                if _norm(label).replace(" ", "") and _norm(label).replace(" ", "") in source_norm
                else _lexical_similarity(clause.target, label) * 0.5
            )
            for label in provider_labels
            if label
        ) if provider_labels else 0.0

        semantic_query = f"{clause.effect} {clause.target}"
        semantic_score, matched_semantics = self._best_against(
            semantic_query,
            tuple(capability.semantic_capabilities),
        )
        target_score, _ = self._best_against(
            clause.target or clause.source_text,
            tuple((*capability.target_domains, capability.provider, capability.capability_id)),
        )
        action_score, matched_actions = self._best_against(
            clause.effect or clause.source_text,
            tuple(capability.exposed_actions),
        )
        historical_score = 1.0 if capability.historical_success else 0.0

        # Provider mention is a strong source-grounded signal, while history is only a
        # weak tie-breaker.  Unknown semantics remain unbound rather than being forced.
        base = (
            0.40 * semantic_score
            + 0.25 * target_score
            + 0.25 * action_score
            + 0.05 * historical_score
        )
        score = min(1.0, base + 0.55 * provider_score)
        return CapabilityMatch(
            capability_id=capability.capability_id,
            score=round(score, 6),
            provider_score=round(provider_score, 6),
            semantic_score=round(semantic_score, 6),
            target_score=round(target_score, 6),
            action_score=round(action_score, 6),
            historical_score=historical_score,
            matched_semantics=matched_semantics,
            matched_actions=matched_actions,
            eligible=True,
        )

    def rank(self, *, clause: DirectiveClause, snapshot: CapabilitySnapshot) -> tuple[CapabilityMatch, ...]:
        matches = tuple(
            self.match_one(clause=clause, capability=capability)
            for capability in snapshot.capabilities
        )
        return tuple(sorted(
            matches,
            key=lambda row: (
                row.eligible,
                row.score,
                row.provider_score,
                row.semantic_score,
                row.action_score,
                row.capability_id,
            ),
            reverse=True,
        ))

    def select(self, matches: tuple[CapabilityMatch, ...]) -> tuple[str | None, str]:
        eligible = tuple(row for row in matches if row.eligible)
        if not eligible:
            return None, "unbound"
        best = eligible[0]
        if best.score < self.min_score:
            return None, "unbound"
        if len(eligible) > 1 and best.score - eligible[1].score < self.min_margin:
            return None, "ambiguous"
        return best.capability_id, "bound"


class PlanningRuntime:
    """Bind source-authorized clauses to current capabilities without positional bias."""

    def __init__(self, matcher: CapabilityMatcher | None = None) -> None:
        self.matcher = matcher or CapabilityMatcher()

    def plan(self, authority: AuthorityGraph, capabilities: CapabilitySnapshot) -> ExecutionPlanArtifact:
        operations: list[PlannedOperation] = []
        for clause in authority.active_clauses:
            if clause.polarity == "negative":
                matches = self.matcher.rank(clause=clause, snapshot=capabilities)
                selected, status = None, "prohibited"
            else:
                matches = self.matcher.rank(clause=clause, snapshot=capabilities)
                selected, status = self.matcher.select(matches)
            op_payload = {
                "clause_id": clause.clause_id,
                "effect": clause.effect,
                "target": clause.target,
                "selected": selected,
                "status": status,
                "authority": authority.graph_id,
                "snapshot": capabilities.snapshot_id,
                "candidates": [(m.capability_id, m.score, m.eligible) for m in matches],
            }
            operations.append(PlannedOperation(
                operation_id="op_" + _hash_payload(op_payload)[:20],
                clause_id=clause.clause_id,
                effect=clause.effect,
                target=clause.target,
                selected_capability_id=selected,
                candidate_matches=matches,
                status=status,
                authority_graph_id=authority.graph_id,
                capability_snapshot_id=capabilities.snapshot_id,
            ))
        payload = {
            "authority": authority.graph_id,
            "capability": capabilities.snapshot_id,
            "operations": [op.operation_id for op in operations],
        }
        return ExecutionPlanArtifact(
            artifact_id="plan_" + _hash_payload(payload)[:20],
            authority_graph_id=authority.graph_id,
            capability_snapshot_id=capabilities.snapshot_id,
            operations=tuple(operations),
        )


class ExecutionRuntime:
    """Execute only through an injected host executor; otherwise preserve pending truth."""

    def execute(
        self,
        plan: ExecutionPlanArtifact,
        *,
        executor: Callable[[ExecutionPlanArtifact], Mapping[str, Any]] | None = None,
    ) -> ExecutionReceiptArtifact:
        executable = tuple(op for op in plan.operations if op.status == "bound" and op.selected_capability_id)
        if executor is None:
            observations = (("execution", "not_observed"),)
            status = "pending_external_host" if executable else "no_executable_binding"
        else:
            result = dict(executor(plan))
            observations = tuple(sorted((str(k), str(v)) for k, v in result.items()))
            status = str(result.get("status") or "observed")
        payload = {"plan": plan.artifact_id, "status": status, "observations": observations}
        return ExecutionReceiptArtifact(
            artifact_id="exec_" + _hash_payload(payload)[:20],
            plan_id=plan.artifact_id,
            observations=observations,
            status=status,
        )


class EvidenceRuntime:
    def verify(self, *receipts: ExecutionReceiptArtifact) -> EvidenceGraphArtifact:
        verified = bool(receipts) and all(
            row.status not in {"pending_external_host", "failed"}
            for row in receipts
        )
        facts = tuple((row.artifact_id, row.status) for row in receipts)
        payload = {"receipts": [r.artifact_id for r in receipts], "verified": verified, "facts": facts}
        return EvidenceGraphArtifact(
            artifact_id="evidence_" + _hash_payload(payload)[:20],
            receipt_ids=tuple(r.artifact_id for r in receipts),
            verified=verified,
            facts=facts,
        )


class ReleaseRuntime:
    def finalize(self, authority: AuthorityGraph, evidence: EvidenceGraphArtifact) -> ReleaseReceiptArtifact:
        payload = {"authority": authority.graph_id, "evidence": evidence.artifact_id, "verified": evidence.verified}
        return ReleaseReceiptArtifact(
            artifact_id="release_" + _hash_payload(payload)[:20],
            authority_graph_id=authority.graph_id,
            evidence_graph_id=evidence.artifact_id,
            releasable=evidence.verified,
        )


class OpenWorldAuditRuntime:
    def __init__(self, auditor: OpenWorldConstraintAuditor | None = None) -> None:
        self.auditor = auditor or OpenWorldConstraintAuditor()

    def scan(self, root: str | Path) -> ConstraintAuditReport:
        return self.auditor.scan_tree(Path(root))


@dataclass(frozen=True)
class FederatedTurnResult:
    clause_graph: ClauseGraph
    authority_graph: AuthorityGraph
    capability_snapshot: CapabilitySnapshot
    execution_plan: ExecutionPlanArtifact
    execution_receipt: ExecutionReceiptArtifact
    evidence_graph: EvidenceGraphArtifact
    release_receipt: ReleaseReceiptArtifact


@dataclass(frozen=True)
class RuntimeFederation:
    source_directive: SourceDirectiveRuntime
    continuity: ContinuityRuntime
    capability: CapabilityRuntime
    planning: PlanningRuntime
    execution: ExecutionRuntime
    evidence: EvidenceRuntime
    release: ReleaseRuntime
    open_world_audit: OpenWorldAuditRuntime

    def begin_turn(
        self,
        source_text: str,
        *,
        turn_id: str = "",
        previous: ClauseGraph | None = None,
        historical_truth=(),
        observation_context: HostObservationContext | None = None,
    ) -> FederatedTurnState:
        clause_graph = self.source_directive.compile(source_text, turn_id=turn_id)
        authority_graph = self.continuity.link(previous=previous, current=clause_graph)
        context = observation_context or HostObservationContext(turn_id=turn_id)
        capability_snapshot = self.capability.snapshot(
            context=context,
            historical_truth=historical_truth,
        )
        return FederatedTurnState(
            clause_graph=clause_graph,
            authority_graph=authority_graph,
            capability_snapshot=capability_snapshot,
        )

    def run(
        self,
        source_text: str,
        *,
        turn_id: str = "",
        previous: ClauseGraph | None = None,
        historical_truth=(),
        observation_context: HostObservationContext | None = None,
        executor: Callable[[ExecutionPlanArtifact], Mapping[str, Any]] | None = None,
    ) -> FederatedTurnResult:
        state = self.begin_turn(
            source_text,
            turn_id=turn_id,
            previous=previous,
            historical_truth=historical_truth,
            observation_context=observation_context,
        )
        execution_plan = self.planning.plan(state.authority_graph, state.capability_snapshot)
        execution_receipt = self.execution.execute(execution_plan, executor=executor)
        evidence_graph = self.evidence.verify(execution_receipt)
        release_receipt = self.release.finalize(state.authority_graph, evidence_graph)
        return FederatedTurnResult(
            clause_graph=state.clause_graph,
            authority_graph=state.authority_graph,
            capability_snapshot=state.capability_snapshot,
            execution_plan=execution_plan,
            execution_receipt=execution_receipt,
            evidence_graph=evidence_graph,
            release_receipt=release_receipt,
        )

    # Canonical naming for callers migrating away from the old CoreRuntime loop.
    run_canonical_turn = run

    @property
    def component_names(self) -> tuple[str, ...]:
        return (
            "source_directive", "continuity", "capability", "planning",
            "execution", "evidence", "release", "open_world_audit",
        )


def build_runtime_federation(root: str | Path, *, host_adapter: HostAdapter | None = None) -> RuntimeFederation:
    Path(root).mkdir(parents=True, exist_ok=True)
    return RuntimeFederation(
        source_directive=SourceDirectiveRuntime(),
        continuity=ContinuityRuntime(),
        capability=CapabilityRuntime(host_adapter),
        planning=PlanningRuntime(),
        execution=ExecutionRuntime(),
        evidence=EvidenceRuntime(),
        release=ReleaseRuntime(),
        open_world_audit=OpenWorldAuditRuntime(),
    )
