from __future__ import annotations

import hashlib
import json
from typing import Any

def _sha_text(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()
def _safe_summary(value: Any, *, limit: int = 6000) -> dict[str, Any]:
    try:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    except Exception:
        raw = repr(value)
    if len(raw) <= limit:
        preview = raw
        tail = ""
    else:
        head_n = max(1, int(limit * 0.72))
        tail_n = max(1, limit - head_n)
        preview = raw[:head_n]
        tail = raw[-tail_n:]
    return {
        "sha256":_sha_text(raw), "bytes":len(raw.encode("utf-8")),
        "preview":preview, "tail_preview":tail, "complete":len(raw) <= limit,
    }
def _model_observation(value: Any, *, limit: int | None = None) -> dict[str, Any]:
    """Lossless model-facing observation by default. Explicit limits are caller-owned telemetry choices."""
    try:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    except Exception:
        raw = repr(value)
    size = len(raw.encode("utf-8"))
    if limit is None or size <= int(limit):
        return {"sha256": _sha_text(raw), "bytes": size, "complete": True, "payload": value}
    limit = max(1, int(limit))
    head_n = max(1, int(limit * 0.68))
    tail_n = max(1, limit - head_n)
    return {
        "sha256": _sha_text(raw), "bytes": size, "complete": False,
        "head": raw[:head_n], "tail": raw[-tail_n:],
        "truncation": "bounded_head_tail_for_model_context",
    }
