from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from jigaewol_components.failure_router import FailureRouter
from jigaewol_runtime.capabilities.execution_routes import capability_traits, compose_execution_routes, infer_required_traits
from jigaewol_runtime.capabilities.manifest import normalize_capabilities


def _sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# Runtime-visible lifecycle states are evidence states only.
LIFECYCLE = (
    "DISCOVERED", "INSTALLED", "CONNECTED", "CALLABLE",
    "EXECUTED", "SUCCESSFUL", "PROVEN", "INTEGRATED",
)


@dataclass(frozen=True)
class CapabilityNeed:
    need_id: str
    semantic_need: str
    required_traits: tuple[str, ...]
    objective_sha256: str
    created_at: float


@dataclass(frozen=True)
class ProviderState:
    capability_id: str
    provider: str
    role: str
    operation: str
    permission: str
    traits: tuple[str, ...]
    action_schema_sha256: str
    installed: bool | None
    connected: bool | None
    callable_now: bool
    executed_this_session: bool
    successful_this_session: bool | None
    proven_this_session: bool | None
    integrated: bool
    last_receipt_id: str | None = None
    last_observed_at: float | None = None


@dataclass(frozen=True)
class RouteRevision:
    revision_id: str
    objective_sha256: str
    failed_route_id: str
    failure_family: str
    preserved_goal: bool
    requested_traits: tuple[str, ...]
    alternate_patterns: tuple[str, ...]
    created_at: float


class RouteExperienceLibrary:
    """Provider-neutral operational lessons distilled from real route revisions."""

    RULES = (
        {
            "id": "network_to_remote_substrate",
            "signals": ("network", "dns", "outbound", "connection"),
            "patterns": ("remote_executable_environment", "outbound_network_execution", "alternate_compute_substrate"),
        },
        {
            "id": "vcs_to_structured_repo_transport",
            "signals": ("git", "clone", "repository", "vcs"),
            "patterns": ("structured_repository_connector", "file_level_materialization", "local_execution"),
        },
        {
            "id": "quota_to_read_model_split",
            "signals": ("quota", "sql", "notion", "database"),
            "patterns": ("bulk_enumeration_route", "shadow_index", "precise_authoritative_fetch", "cursor_or_export_recovery"),
        },
        {
            "id": "installed_not_callable",
            "signals": ("installed", "callable", "plugin", "connector"),
            "patterns": ("current_surface_reprobe", "alternate_provider_same_semantics", "promotion_follows_execution_evidence"),
        },
        {
            "id": "wrapper_without_engine",
            "signals": ("dependency", "runtime", "engine", "python", "node", "missing executable"),
            "patterns": ("dependency_probe", "alternate_runtime_substrate", "execution_probe_before_integration"),
        },
        {
            "id": "write_requires_readback",
            "signals": ("write", "change", "update", "create", "move", "upload"),
            "patterns": ("write", "read_back", "compare", "commit_as_proven"),
        },
    )

    def suggest(self, *, failure_text: str, missing_traits: Iterable[str] = ()) -> tuple[str, ...]:
        text = str(failure_text or "").casefold()
        out: list[str] = []
        for row in self.RULES:
            if any(token in text for token in row["signals"]):
                out.extend(row["patterns"])
        out.extend(str(x) for x in missing_traits if str(x))
        return tuple(dict.fromkeys(out))


_MEMORY_POLICY_BINDINGS = {
    "local_network_to_remote_execution": "network_to_remote_substrate",
    "git_clone_to_structured_repository_transport": "vcs_to_structured_repo_transport",
    "wrapper_installed_engine_missing": "wrapper_without_engine",
    "plugin_installed_not_callable": "installed_not_callable",
    "notion_sql_quota_to_read_model_split": "quota_to_read_model_split",
    "drive_write_readback": "write_requires_readback",
}


class OperationalResilienceEngine:
    """Hot-path route resilience layer.

    Stable anchor: the user objective. Concrete providers are provisional. A route
    failure produces a route-adjustment directive and a new capability need while the
    objective stays live. Current-session observation establishes liveness.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.surface_path = self.root / "capability_surface_snapshot.json"
        self.state_path = self.root / "provider_states.json"
        self.revision_path = self.root / "route_revisions.jsonl"
        self.failure_router = FailureRouter(self.root / "failure_events.json")
        self.experience = RouteExperienceLibrary()
        if not self.state_path.exists():
            self.state_path.write_text(json.dumps({"version": 1, "providers": {}}, indent=2) + "\n", encoding="utf-8")

    def _states(self) -> dict[str, Any]:
        return json.loads(self.state_path.read_text(encoding="utf-8"))

    def _write_states(self, data: dict[str, Any]) -> None:
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.state_path)

    def bind_surface(self, capabilities: Iterable[Any], *, session_id: str, receipt_id: str | None = None) -> dict[str, Any]:
        specs = tuple(normalize_capabilities(capabilities or ()))
        now = time.time()
        state = self._states()
        providers = state.setdefault("providers", {})
        current_ids = set()
        rows = []
        for spec in specs:
            cid = str(spec["id"])
            current_ids.add(cid)
            prior = providers.get(cid, {})
            row = ProviderState(
                capability_id=cid,
                provider=str(spec.get("provider") or spec.get("plugin") or "host"),
                role=str(spec.get("role") or ""),
                operation=str(spec.get("operation") or cid),
                permission=str(spec.get("permission") or "unknown"),
                traits=tuple(sorted(capability_traits(spec))),
                action_schema_sha256=_sha({k:v for k,v in spec.items() if k not in {"health","last_seen","observed_at"}}),
                installed=prior.get("installed"),
                connected=True,
                callable_now=True,
                executed_this_session=bool(prior.get("session_id") == session_id and prior.get("executed_this_session")),
                successful_this_session=(prior.get("successful_this_session") if prior.get("session_id") == session_id else False),
                proven_this_session=(prior.get("proven_this_session") if prior.get("session_id") == session_id else False),
                integrated=bool(prior.get("integrated", False)),
                last_receipt_id=prior.get("last_receipt_id"),
                last_observed_at=now,
            )
            providers[cid] = {**asdict(row), "session_id": session_id}
            rows.append(asdict(row))
        for cid, prior in list(providers.items()):
            if cid not in current_ids:
                prior["callable_now"] = False
                prior["connected"] = False if prior.get("session_id") == session_id else prior.get("connected")
                if prior.get("session_id") != session_id:
                    prior["executed_this_session"] = False
                    prior["successful_this_session"] = False
                    prior["proven_this_session"] = False
                providers[cid] = prior
        self._write_states(state)
        snapshot = {
            "version": 1,
            "session_id": str(session_id),
            "observed_at": now,
            "receipt_id": receipt_id,
            "capability_count": len(rows),
            "capabilities": rows,
            "truth": "current_exposed_callable_surface_only",
            "historical_success_does_not_imply_current_liveness": True,
        }
        tmp = self.surface_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(snapshot, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.surface_path)
        return snapshot

    def infer_need(
        self, objective: str, *, route_composition: dict[str, Any] | None = None,
        required_traits: Iterable[str] | None = None,
    ) -> CapabilityNeed:
        # When the canonical semantic authority already established the required
        # traits, they are used verbatim. Re-deriving them from the raw text here is
        # exactly the kind of downstream reparse that narrowed an upstream judgement.
        # (merged from the GPT lineage)
        explicit_semantic_traits = required_traits is not None
        required = set(
            infer_required_traits(objective) if required_traits is None
            else (str(x) for x in required_traits if str(x))
        )
        if route_composition and not explicit_semantic_traits:
            # A Foundation route compiled from broader/raw context is diagnostic only
            # once canonical semantic authority has supplied an explicit trait set.
            # Re-merging lexical missing traits here would let quoted/history text
            # regain actuator authority after discourse scoping already removed it.
            required.update(str(x) for x in route_composition.get("missing_traits", ()) if str(x))
        return CapabilityNeed(
            need_id="need_" + uuid.uuid4().hex[:16],
            semantic_need=str(objective),
            required_traits=tuple(sorted(required)),
            objective_sha256=hashlib.sha256(str(objective).encode("utf-8")).hexdigest(),
            created_at=time.time(),
        )

    def route_plan(self, need: CapabilityNeed, capabilities: Iterable[Any], *, avoid_capability_ids: Iterable[str] = ()) -> dict[str, Any]:
        low = str(need.semantic_need).casefold()
        explicit_free_only = any(marker in low for marker in ("0원", "무료만", "추가 비용 없이", "zero-cost", "zero cost", "free-only"))
        explicit_prefer_free = any(marker in low for marker in ("무료 우선", "공짜 우선", "가능하면 무료", "free first", "prefer free"))
        zero_cost_policy = (
            "proven_free_only" if explicit_free_only
            else "prefer_proven_free" if explicit_prefer_free
            else "cost_agnostic"
        )
        return compose_execution_routes(
            need.semantic_need,
            capabilities,
            required_traits=need.required_traits,
            avoid_capability_ids=tuple(avoid_capability_ids),
            zero_cost_policy=zero_cost_policy,
        )

    def record_execution(
        self,
        *,
        capability_id: str,
        success: bool | None,
        receipt_id: str,
        evidence: dict[str, Any] | None = None,
        read_back_verified: bool | None = None,
        integrated: bool | None = None,
        session_id: str,
    ) -> dict[str, Any]:
        state = self._states()
        providers = state.setdefault("providers", {})
        row = dict(providers.get(str(capability_id), {}))
        row.update({
            "capability_id": str(capability_id),
            "session_id": str(session_id),
            "executed_this_session": True,
            "successful_this_session": success,
            "proven_this_session": (True if success is True and read_back_verified is not False else (False if success is False else None)),
            "last_receipt_id": str(receipt_id),
            "last_observed_at": time.time(),
            "last_evidence_sha256": _sha(evidence or {}),
        })
        if integrated is not None:
            row["integrated"] = bool(integrated)
        providers[str(capability_id)] = row
        self._write_states(state)
        return row

    def lifecycle(self, capability_id: str) -> tuple[str, ...]:
        row = self._states().get("providers", {}).get(str(capability_id), {})
        stages = ["DISCOVERED"] if row else []
        if row.get("installed") is True: stages.append("INSTALLED")
        if row.get("connected") is True: stages.append("CONNECTED")
        if row.get("callable_now") is True: stages.append("CALLABLE")
        if row.get("executed_this_session") is True: stages.append("EXECUTED")
        if row.get("successful_this_session") is True: stages.append("SUCCESSFUL")
        if row.get("proven_this_session") is True: stages.append("PROVEN")
        if row.get("integrated") is True: stages.append("INTEGRATED")
        return tuple(stages)

    def revise_after_failure(
        self,
        *,
        objective: str,
        route_id: str,
        operation: str,
        error: Exception | str,
        missing_traits: Iterable[str] = (),
        context: dict[str, Any] | None = None,
    ) -> RouteRevision:
        exc = error if isinstance(error, BaseException) else RuntimeError(str(error))
        event = self.failure_router.record(
            exc, operation=operation, route_id=route_id,
            failure_family=type(exc).__name__, context=context or {},
        )
        directive = self.failure_router.directive(event)
        patterns = self.experience.suggest(
            failure_text=f"{operation} {exc}",
            missing_traits=tuple(missing_traits),
        )
        revision = RouteRevision(
            revision_id="revision_" + uuid.uuid4().hex[:16],
            objective_sha256=hashlib.sha256(str(objective).encode("utf-8")).hexdigest(),
            failed_route_id=str(route_id),
            failure_family=event.failure_family,
            preserved_goal=True,
            requested_traits=tuple(dict.fromkeys((*directive.requested_traits, *(str(x) for x in missing_traits)))),
            alternate_patterns=tuple(dict.fromkeys(patterns)),
            created_at=time.time(),
        )
        with self.revision_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(asdict(revision), ensure_ascii=False, sort_keys=True) + "\n")
        return revision


    def audit_experience_memory(self, memory_path: str | Path) -> dict[str, Any]:
        """Classify recorded resilience lessons without equating documentation with execution."""
        data=json.loads(Path(memory_path).read_text(encoding="utf-8"))
        rule_by_id={str(row["id"]): row for row in self.experience.RULES}
        used_patterns:set[str]=set()
        used_revisions:list[str]=[]
        source_path = self.revision_path
        if source_path.exists():
            for line in source_path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                row=json.loads(line)
                used_revisions.append(str(row.get("revision_id") or ""))
                used_patterns.update(str(x) for x in row.get("alternate_patterns", ()) if str(x))
        cases=[]
        counts={"document_only":0,"policy_available":0,"actually_used":0}
        for item in data.get("route_revision_cases", ()) or ():
            case=str(item.get("case") or "")
            binding=_MEMORY_POLICY_BINDINGS.get(case)
            state="document_only"
            evidence={"policy_binding": binding, "route_revision_ids": []}
            if binding and binding in rule_by_id:
                state="policy_available"
                patterns=set(str(x) for x in rule_by_id[binding].get("patterns", ()) if str(x))
                if patterns & used_patterns:
                    state="actually_used"
                    evidence["matched_patterns"]=sorted(patterns & used_patterns)
                    evidence["route_revision_ids"]=list(used_revisions)
            counts[state]+=1
            cases.append({
                "case":case,
                "state":state,
                "policy_binding":binding,
                "evidence":evidence,
            })
        return {
            "memory_status": data.get("status"),
            "counts": counts,
            "cases": cases,
            "claim_boundary": "document_only != policy_available != actually_used",
        }

    @staticmethod
    def verify_external_change(*, expected: Any, read_back: Any) -> dict[str, Any]:
        ok = expected == read_back
        return {
            "write_acknowledged": True,
            "read_back_performed": True,
            "matches_expected": ok,
            "expected_sha256": _sha(expected),
            "read_back_sha256": _sha(read_back),
            "proven": ok,
        }

    def snapshot(self) -> dict[str, Any]:
        surface = json.loads(self.surface_path.read_text(encoding="utf-8")) if self.surface_path.exists() else None
        state = self._states()
        revisions = []
        source_path = self.revision_path
        if source_path.exists():
            for line in source_path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    revisions.append(json.loads(line))
        return {"surface": surface, "providers": state.get("providers", {}), "recent_route_revisions": revisions}


