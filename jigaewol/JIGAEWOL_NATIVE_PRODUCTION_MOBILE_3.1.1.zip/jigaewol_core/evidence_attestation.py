from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ExecutionReceipt:
    receipt_id: str
    session_id: str
    work_id: str
    provider: str
    operation: str
    success: bool | None
    input_sha256: str
    output_sha256: str
    exit_state: str
    read_back_verified: bool | None
    created_at: float
    receipt_sha256: str


class ExecutionReceiptLedger:
    """Append-only structural evidence for host/tool execution.

    A boolean host assertion is not itself execution evidence. This ledger binds the
    observable work descriptor and result envelope into a durable receipt that can be
    referenced by the turn gate and re-verified later.
    """

    def __init__(self, path: str | Path, *, session_id: str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.session_id = str(session_id)
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")

    def record(
        self,
        *,
        work: Any,
        result: Any,
        success: bool | None,
        provider: str | None = None,
        operation: str | None = None,
        read_back_verified: bool | None = None,
    ) -> ExecutionReceipt:
        work_id = str(getattr(work, "work_id", None) or "host_work")
        provider = str(provider or getattr(work, "executor", None) or "host")
        operation = str(operation or getattr(work, "operation", None) or "host_work")
        work_descriptor = {
            "work_id": work_id,
            "provider": provider,
            "operation": operation,
            "parameters": getattr(work, "parameters", None),
            "executor": getattr(work, "executor", None),
        }
        exit_state = "success" if success is True else ("failure" if success is False else "indeterminate")
        if isinstance(result, dict):
            if "exit_code" in result:
                exit_state = f"exit_code:{result.get('exit_code')}"
            elif "status" in result:
                exit_state = str(result.get("status"))
        base = {
            "receipt_id": "exec_" + uuid.uuid4().hex[:18],
            "session_id": self.session_id,
            "work_id": work_id,
            "provider": provider,
            "operation": operation,
            "success": success,
            "input_sha256": _digest(work_descriptor),
            "output_sha256": _digest(result),
            "exit_state": exit_state,
            "read_back_verified": read_back_verified,
            "created_at": time.time(),
        }
        receipt = ExecutionReceipt(**base, receipt_sha256=_digest(base))
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(asdict(receipt), ensure_ascii=False, sort_keys=True) + "\n")
        return receipt

    def get(self, receipt_id: str) -> dict[str, Any]:
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if row.get("receipt_id") == receipt_id:
                return row
        raise KeyError(receipt_id)

    def verify(self, receipt_id: str) -> bool:
        row = self.get(receipt_id)
        digest = row.pop("receipt_sha256")
        return digest == _digest(row)

    def recent(self, limit: int = 100) -> tuple[dict[str, Any], ...]:
        rows = [json.loads(x) for x in self.path.read_text(encoding="utf-8").splitlines() if x.strip()]
        return tuple(rows[-max(1, int(limit)):])
