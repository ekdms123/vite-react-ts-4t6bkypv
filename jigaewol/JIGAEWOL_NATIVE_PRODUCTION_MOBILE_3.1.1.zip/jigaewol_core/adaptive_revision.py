from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable
import json

from jigaewol_components.cognitive_lift import CognitiveLiftGate, LiftTask


@dataclass(frozen=True)
class RevisionProposal:
    proposal_id: str
    weakness: str
    implementation_ref: str
    parent_version: str
    created_at: float


class EvidenceClosedRevisionLoop:
    """Runtime revision promotion loop with measured lift and regression evidence."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("[]", encoding="utf-8")
        self.lift = CognitiveLiftGate()

    def propose(self, *, weakness: str, implementation_ref: str, parent_version: str) -> RevisionProposal:
        row = RevisionProposal("proposal_" + uuid.uuid4().hex[:16], str(weakness), str(implementation_ref), str(parent_version), time.time())
        data = json.loads(self.path.read_text(encoding="utf-8"))
        data.append({"proposal": asdict(row), "status": "proposed"})
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return row

    def benchmark(
        self,
        proposal: RevisionProposal,
        *,
        tasks: Iterable[LiftTask],
        baseline: Callable,
        candidate: Callable,
        minimum_absolute_lift: float = 0.0,
    ) -> dict[str, Any]:
        audit = self.lift.evaluate(tasks, baseline=baseline, candidate=candidate, minimum_absolute_lift=minimum_absolute_lift)
        row = {
            "proposal_id": proposal.proposal_id,
            "status": "promotion_allowed" if audit.promotion_allowed else "rejected_no_lift",
            "audit": asdict(audit),
            "benchmarked_at": time.time(),
        }
        data = json.loads(self.path.read_text(encoding="utf-8"))
        data.append(row)
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
        return row


