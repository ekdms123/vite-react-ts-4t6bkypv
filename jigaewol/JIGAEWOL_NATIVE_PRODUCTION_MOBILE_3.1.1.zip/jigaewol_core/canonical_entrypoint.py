from __future__ import annotations

"""Shared exact-source admission for every user-facing executable entrypoint.

The outer gateway remains the richest harness, but alternate CLIs must not create a
second authority path.  They all pass exact bytes through the same integrated ingress
packet and a message-bound TurnGateway envelope before invoking their runtime body.
"""

import json
import hashlib
from pathlib import Path
from typing import Any

from jigaewol_components.integrated_processing import compile_integrated_processing_packet
from .turn_gateway import TurnGateway


def admit_exact_user_message(
    *,
    state_root: str | Path,
    raw_message_bytes: bytes,
    user_id: str,
    project_id: str,
    session_id: str,
    origin_ref: str,
    integrated_processing_packet: Any | None = None,
) -> dict[str, Any]:
    root = Path(state_root)
    root.mkdir(parents=True, exist_ok=True)
    message = bytes(raw_message_bytes).decode("utf-8")
    packet = integrated_processing_packet or compile_integrated_processing_packet(bytes(raw_message_bytes), direction="user")
    if packet.exact_message_sha256 != hashlib.sha256(raw_message_bytes).hexdigest():
        raise ValueError("canonical admission packet does not match exact user bytes")
    failed = tuple(v.as_mapping() for v in packet.validators if not v.passed)
    if failed:
        raise PermissionError(f"canonical ingress validators failed: {failed}")

    user = str(user_id or "").strip()
    project = str(project_id or "").strip()
    session = str(session_id or "chat").strip()
    if not user or not project:
        raise ValueError("canonical entrypoint requires explicit/nonempty user_id and project_id")

    gateway = TurnGateway(root / "turn_gateway", user_id=user, project_id=project, session_id=session)
    admission = gateway.admit_new_message(
        root / "canonical_finalizer",
        message=message,
        origin_ref=str(origin_ref),
    )
    if admission.get("action") == "reuse_pending":
        envelope = gateway.latest_verified_turn()
    else:
        envelope = gateway.issue(message)

    envelope_dir = root / "turn_gateway" / "envelopes"
    envelope_dir.mkdir(parents=True, exist_ok=True)
    envelope_path = envelope_dir / f"{envelope['gateway_turn_id']}.json"
    if not envelope_path.exists():
        envelope_path.write_text(
            json.dumps(envelope, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
        )
    exact_dir = root / "turn_gateway" / "exact_messages"
    exact_dir.mkdir(parents=True, exist_ok=True)
    exact_path = exact_dir / f"{packet.exact_message_sha256}.bin"
    if exact_path.exists() and exact_path.read_bytes() != raw_message_bytes:
        raise RuntimeError("exact-message digest collision or state corruption")
    if not exact_path.exists():
        exact_path.write_bytes(bytes(raw_message_bytes))

    return {
        "message": message,
        "exact_message_sha256": packet.exact_message_sha256,
        "gateway_envelope": dict(envelope),
        "gateway_admission": dict(admission),
        "integrated_processing": packet.as_mapping(include_canonical_text=True, include_vector_values=True),
        "turn_ingress_receipt": {
            "exact_message_sha256": packet.exact_message_sha256,
            "validator_passed": True,
            "canonical_core_routed": True,
            "gateway_turn_id": envelope["gateway_turn_id"],
            "gateway_sequence": envelope["gateway_sequence"],
        },
        "envelope_path": str(envelope_path),
        "exact_message_path": str(exact_path),
    }
