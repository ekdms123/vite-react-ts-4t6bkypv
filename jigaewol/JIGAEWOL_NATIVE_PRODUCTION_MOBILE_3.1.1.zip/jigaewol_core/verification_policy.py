from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable, Any


@dataclass(frozen=True)
class VerificationCoverageDecision:
    state: str
    reason: str
    applicable_failure_families: tuple[str, ...]
    independent_semantic_connected: bool = False


_ARITHMETIC = re.compile(r"^\s*-?\d+(?:\.\d+)?\s*[+\-*/]\s*-?\d+(?:\.\d+)?")


def classify_task_kind(objective: str, evidence: dict[str, Any] | None = None) -> str:
    text = str(objective or "").strip().casefold()
    ev = dict(evidence or {})
    if _ARITHMETIC.match(text):
        return "deterministic"
    if ev.get("source_text") or ev.get("source_documents"):
        return "source_grounded"
    if ev.get("execution_receipts"):
        return "execution"
    return "general"


def evaluate_verification_coverage(
    task_kind: str,
    rows: Iterable[Any],
    independent_semantic_connected: bool = False,
) -> VerificationCoverageDecision:
    rows = tuple(rows)
    applicable = tuple(x for x in rows if "not_applicable" not in tuple(getattr(x, "findings", ())))
    families = tuple(sorted({str(getattr(x, "failure_family", "unknown")) for x in applicable}))
    if any(getattr(x, "success", None) is False for x in applicable):
        return VerificationCoverageDecision("failed", "applicable_verifier_failed", families, independent_semantic_connected)
    if any(getattr(x, "success", None) is None for x in applicable):
        return VerificationCoverageDecision("insufficient_coverage", "secondary_semantic_check_required", families, independent_semantic_connected)

    kind = str(task_kind)
    if kind == "deterministic" and "deterministic_execution" in families:
        return VerificationCoverageDecision("verified", "deterministic_result_checked", families, independent_semantic_connected)
    if kind in {"source_grounded", "execution"}:
        required = "source_entailment" if kind == "source_grounded" else "execution_evidence"
        if required in families:
            return VerificationCoverageDecision("verified", f"{kind}_evidence_checked", families, independent_semantic_connected)
    if independent_semantic_connected and "semantic_relevance" in families:
        return VerificationCoverageDecision("verified", "independent_semantic_checker_connected", families, True)
    if "semantic_relevance" in families:
        return VerificationCoverageDecision("plausible_unproven", "relevance_passed_without_independent_truth_proof", families, False)
    return VerificationCoverageDecision("insufficient_coverage", "no_applicable_semantic_or_domain_verifier", families, independent_semantic_connected)
