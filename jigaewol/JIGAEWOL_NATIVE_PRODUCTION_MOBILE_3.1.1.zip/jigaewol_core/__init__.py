"""Canonical public API for the JIGAEWOL personal runtime.

The public package is deliberately lazy. Importing a narrow control-plane module
(e.g. :mod:`jigaewol_core.turn_gateway`) must not initialize the entire cognition
runtime. Public symbols are resolved on first access and cached in this module.
"""
from __future__ import annotations

from importlib import import_module

from .constants import VERSION as __version__, PUBLIC_RUNTIME_NAME, PUBLIC_RUNTIME_ID

_EXPORTS = {
    "CoreRuntime": ("runtime", "CoreRuntime"),
    "CoreTurn": ("runtime", "CoreTurn"),
    "architecture_snapshot": ("architecture", "architecture_snapshot"),
    "IntegrationRegistry": ("integration_registry", "IntegrationRegistry"),
    "IntegratedComponent": ("integration_registry", "IntegratedComponent"),
    "verify_active_artifact": ("integrity", "verify_active_artifact"),
    "OperationalResilienceEngine": ("operational_resilience", "OperationalResilienceEngine"),
    "RouteExperienceLibrary": ("operational_resilience", "RouteExperienceLibrary"),
    "PublicExecutionTrace": ("observability", "PublicExecutionTrace"),
    "SemanticCandidateEngine": ("semantic_loop", "SemanticCandidateEngine"),
    "GenerationRequest": ("semantic_loop", "GenerationRequest"),
    "GenerationResult": ("semantic_loop", "GenerationResult"),
    "VerificationResult": ("semantic_loop", "VerificationResult"),
    "ResourceEnvelope": ("resource_policy", "ResourceEnvelope"),
    "derive_resource_envelope": ("resource_policy", "derive_resource_envelope"),
    "derive_execution_horizon": ("resource_policy", "derive_execution_horizon"),
    "RepresentationGapWorldGenerator": ("world_invention", "RepresentationGapWorldGenerator"),
    "InventedWorld": ("world_invention", "InventedWorld"),
    "ExecutionReceiptLedger": ("evidence_attestation", "ExecutionReceiptLedger"),
    "ExecutionReceipt": ("evidence_attestation", "ExecutionReceipt"),
    "EvidenceClosedRevisionLoop": ("adaptive_revision", "EvidenceClosedRevisionLoop"),
    "RevisionProposal": ("adaptive_revision", "RevisionProposal"),
    "ExecutionOutcome": ("execution_truth", "ExecutionOutcome"),
    "classify_execution_result": ("execution_truth", "classify_execution_result"),
    "TurnExecutionProfile": ("turn_profile", "TurnExecutionProfile"),
    "classify_turn_profile": ("turn_profile", "classify_turn_profile"),
    "escalate_profile": ("turn_profile", "escalate_profile"),
    "VerificationCoverageDecision": ("verification_policy", "VerificationCoverageDecision"),
    "classify_task_kind": ("verification_policy", "classify_task_kind"),
    "evaluate_verification_coverage": ("verification_policy", "evaluate_verification_coverage"),
    "TurnGateway": ("turn_gateway", "TurnGateway"),
    "CanonicalReleaseRuntime": ("release_runtime", "CanonicalReleaseRuntime"),
    "CausalLoopCoordinator": ("causal_loop", "CausalLoopCoordinator"),
    "LoopState": ("causal_loop", "LoopState"),
    "LoopOutcome": ("causal_loop", "LoopOutcome"),
    "VerificationReceipt": ("causal_loop", "VerificationReceipt"),
    "CausalJournal": ("causal_journal", "CausalJournal"),
    "CausalStepReceipt": ("causal_journal", "CausalStepReceipt"),
    "LoopHandle": ("causal_journal", "LoopHandle"),
    "CognitionPort": ("cognition_port", "CognitionPort"),
    "CognitiveInvocation": ("cognition_port", "CognitiveInvocation"),
    "CognitionReceipt": ("cognition_port", "CognitionReceipt"),
    "ActionPort": ("action_port", "ActionPort"),
    "ActionInvocation": ("action_port", "ActionInvocation"),
    "ActionReceipt": ("action_port", "ActionReceipt"),
    "ObservationReceipt": ("action_port", "ObservationReceipt"),
}

__all__ = [*_EXPORTS, "PUBLIC_RUNTIME_NAME", "PUBLIC_RUNTIME_ID"]


def __getattr__(name: str):
    spec = _EXPORTS.get(name)
    if spec is None:
        raise AttributeError(name)
    module_name, symbol = spec
    value = getattr(import_module(f"{__name__}.{module_name}"), symbol)
    globals()[name] = value
    return value
