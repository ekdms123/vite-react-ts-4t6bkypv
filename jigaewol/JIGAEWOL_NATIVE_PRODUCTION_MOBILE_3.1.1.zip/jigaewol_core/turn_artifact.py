from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class CoreTurn:
    core_turn_id: str
    command: str
    command_sha256: str
    release_turn_id: str
    release_ingress_receipt_id: str
    foundation_turn_id: str
    foundation_receipt_id: str
    path_kind: str
    depth: dict[str, Any]
    cumulative_intent: dict[str, Any]
    requirement_contract: dict[str, Any]
    active_requirement_contract: dict[str, Any]
    goal_anchor: dict[str, Any]
    strategy_topology: dict[str, Any]
    representation_tournament: dict[str, Any]
    semantic_authority: dict[str, Any]
    openness_contract: dict[str, Any]
    possibility_plan: dict[str, Any]
    exploration_ecology: dict[str, Any]
    anti_recurrence: tuple[dict[str, Any], ...]
    repair_momentum_contract: dict[str, Any]
    execution_route_composition: dict[str, Any]
    execution_fabric_plan: dict[str, Any]
    open_world_audit: dict[str, Any]
    operational_resilience: dict[str, Any]
    resource_envelope: dict[str, Any]
    execution_profile: dict[str, Any]
    invented_worlds: tuple[dict[str, Any], ...]
    ephemeral_universe: dict[str, Any] = field(default_factory=dict)
    forensic_contract: dict[str, Any] = field(default_factory=dict)
    open_execution_state: dict[str, Any] = field(default_factory=dict)
    cognitive_continuity: dict[str, Any] = field(default_factory=dict)
    cognitive_os: dict[str, Any] = field(default_factory=dict)
    exploration_decision: dict[str, Any] = field(default_factory=dict)
    exploration_return: dict[str, Any] = field(default_factory=dict)
    frontier_control: dict[str, Any] = field(default_factory=dict)
    goal_kernel: dict[str, Any] = field(default_factory=dict)
    goal_loss_diff: dict[str, Any] = field(default_factory=dict)
    work_program: dict[str, Any] = field(default_factory=dict)
    representation_program: dict[str, Any] = field(default_factory=dict)
    dynamic_operator: dict[str, Any] = field(default_factory=dict)
    interpreter_program: dict[str, Any] = field(default_factory=dict)
    effect_plan: dict[str, Any] = field(default_factory=dict)
    improvement_program: dict[str, Any] = field(default_factory=dict)
    observation_gap: dict[str, Any] = field(default_factory=dict)
    friction_events: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    body_materializations: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    friction_repairs: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    improvement_adoption: dict[str, Any] = field(default_factory=dict)
    executable_memory_state: dict[str, Any] = field(default_factory=dict)
    evidence_bindings: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    multimodal_state: dict[str, Any] = field(default_factory=dict)
    image_generation_governance: dict[str, Any] = field(default_factory=dict)
    wild_cognitive_plan: dict[str, Any] = field(default_factory=dict)
    expected_previous_finalizer_receipt_id: str = ""
    gateway_required: bool = False
    gateway_turn_id: str = ""
    gateway_sequence: int = 0
    gateway_token_sha256: str = ""
    previous_gateway_token_sha256: str = ""
    gateway_chain_verified: bool = False
    gateway_scope_sha256: str = ""
    foundation_semantic_agenda: tuple[dict[str, Any], ...] = field(default_factory=tuple, repr=False, compare=False)
    host_observations: tuple[dict[str, Any], ...] = field(default_factory=tuple, repr=False, compare=False)
    next_work: tuple[Any, ...] = field(default_factory=tuple, repr=False, compare=False)

    def public_snapshot(self) -> dict[str, Any]:
        return {
            "core_turn_id": self.core_turn_id,
            "command_sha256": self.command_sha256,
            "release_turn_id": self.release_turn_id,
            "foundation_turn_id": self.foundation_turn_id,
            "foundation_receipt_id": self.foundation_receipt_id,
            "path_kind": self.path_kind,
            "depth": self.depth,
            "cumulative_intent": self.cumulative_intent,
            "requirement_contract": self.requirement_contract,
            "active_requirement_contract": self.active_requirement_contract,
            "goal_anchor": self.goal_anchor,
            "strategy_topology": self.strategy_topology,
            "representation_tournament": self.representation_tournament,
            "semantic_authority": self.semantic_authority,
            "openness_contract": self.openness_contract,
            "possibility_plan": self.possibility_plan,
            "exploration_ecology": self.exploration_ecology,
            "anti_recurrence": self.anti_recurrence,
            "repair_momentum_contract": self.repair_momentum_contract,
            "execution_route_composition": self.execution_route_composition,
            "execution_fabric_plan": self.execution_fabric_plan,
            "open_world_audit": self.open_world_audit,
            "operational_resilience": self.operational_resilience,
            "resource_envelope": self.resource_envelope,
            "execution_profile": self.execution_profile,
            "invented_worlds": self.invented_worlds,
            "ephemeral_universe": self.ephemeral_universe,
            "forensic_contract": self.forensic_contract,
            "open_execution_state": self.open_execution_state,
            "cognitive_continuity": self.cognitive_continuity,
            "cognitive_os": self.cognitive_os,
            "exploration_decision": self.exploration_decision,
            "exploration_return": self.exploration_return,
            "frontier_control": self.frontier_control,
            "goal_kernel": self.goal_kernel,
            "goal_loss_diff": self.goal_loss_diff,
            "work_program": self.work_program,
            "representation_program": self.representation_program,
            "dynamic_operator": self.dynamic_operator,
            "interpreter_program": self.interpreter_program,
            "effect_plan": self.effect_plan,
            "improvement_program": self.improvement_program,
            "observation_gap": self.observation_gap,
            "friction_events": self.friction_events,
            "body_materializations": self.body_materializations,
            "friction_repairs": self.friction_repairs,
            "improvement_adoption": self.improvement_adoption,
            "executable_memory_state": self.executable_memory_state,
            "evidence_bindings": self.evidence_bindings,
            "multimodal_state": self.multimodal_state,
            "image_generation_governance": self.image_generation_governance,
            "wild_cognitive_plan": self.wild_cognitive_plan,
            "expected_previous_finalizer_receipt_id": self.expected_previous_finalizer_receipt_id,
            "gateway_required": self.gateway_required,
            "gateway_turn_id": self.gateway_turn_id,
            "gateway_sequence": self.gateway_sequence,
            "gateway_token_sha256": self.gateway_token_sha256,
            "previous_gateway_token_sha256": self.previous_gateway_token_sha256,
            "gateway_chain_verified": self.gateway_chain_verified,
            "gateway_scope_sha256": self.gateway_scope_sha256,
            "foundation_semantic_agenda": self.foundation_semantic_agenda,
            "next_work": tuple({
                "work_id":getattr(w,"work_id",None),
                "executor":getattr(w,"executor",None),
                "operation":getattr(w,"operation",None),
            } for w in self.next_work),
        }
