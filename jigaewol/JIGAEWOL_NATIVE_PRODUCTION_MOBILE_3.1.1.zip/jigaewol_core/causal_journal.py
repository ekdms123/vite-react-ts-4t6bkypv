from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from jigaewol_components.file_lock import exclusive_lock


def _canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")


def _sha(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


@dataclass(frozen=True)
class LoopHandle:
    turn_id: str
    state_token: str


@dataclass(frozen=True)
class CausalStepReceipt:
    turn_id: str
    step_no: int
    phase: str
    previous_head_sha256: str
    state: dict[str, Any]
    transition: dict[str, Any]
    recorded_at: float
    payload_sha256: str
    causal_head_sha256: str
    mac_sha256: str

    @classmethod
    def from_mapping(cls, row: Mapping[str, Any]) -> "CausalStepReceipt":
        return cls(
            turn_id=str(row.get("turn_id") or ""),
            step_no=int(row.get("step_no") or 0),
            phase=str(row.get("phase") or ""),
            previous_head_sha256=str(row.get("previous_head_sha256") or ""),
            state=dict(row.get("state") or {}),
            transition=dict(row.get("transition") or {}),
            recorded_at=float(row.get("recorded_at") or 0.0),
            payload_sha256=str(row.get("payload_sha256") or ""),
            causal_head_sha256=str(row.get("causal_head_sha256") or ""),
            mac_sha256=str(row.get("mac_sha256") or ""),
        )


@dataclass(frozen=True)
class VerifiedJournalHead:
    turn_id: str
    step_no: int
    phase: str
    causal_head_sha256: str
    state: dict[str, Any]
    record_count: int
    latest_step: CausalStepReceipt | None = None


@dataclass(frozen=True)
class CausalCheckpoint:
    turn_id: str
    step_no: int
    phase: str
    causal_head_sha256: str
    record_count: int
    issued_at: float
    checkpoint_sha256: str
    mac_sha256: str


class JournalIntegrityError(RuntimeError):
    pass


class CausalJournal:
    """Authenticated append-only per-turn causal journal.

    The journal is not trusted by name. Every read that yields authority replays the
    hash/MAC chain. External callers receive only opaque handles; state is resolved
    inside this store.
    """

    ALLOWED_TRANSITIONS: dict[str, frozenset[str]] = {
        "GENESIS": frozenset({"INGRESS"}),
        "INGRESS": frozenset({"AWAIT_COGNITION", "AWAIT_ACTION", "VERIFY", "FAILED_INTEGRITY"}),
        "AWAIT_COGNITION": frozenset({"COGNITION", "FAILED_INTEGRITY"}),
        "COGNITION": frozenset({"AWAIT_COGNITION", "AWAIT_ACTION", "VERIFY", "FAILED_INTEGRITY"}),
        "AWAIT_ACTION": frozenset({"OBSERVATION", "FAILED_INTEGRITY"}),
        "OBSERVATION": frozenset({"AWAIT_COGNITION", "AWAIT_ACTION", "VERIFY", "FAILED_INTEGRITY"}),
        "VERIFY": frozenset({"AWAIT_COGNITION", "FINALIZE_PREPARE", "INCOMPLETE", "FAILED_INTEGRITY"}),
        "FINALIZE_PREPARE": frozenset({"RELEASE", "FAILED_INTEGRITY"}),
        "RELEASE": frozenset({"COMMIT", "INCOMPLETE", "FAILED_INTEGRITY"}),
        "COMMIT": frozenset(),
        "INCOMPLETE": frozenset({"AWAIT_COGNITION", "AWAIT_ACTION", "FAILED_INTEGRITY"}),
        "FAILED_INTEGRITY": frozenset(),
    }

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.turns_dir = self.root / "turns"
        self.turns_dir.mkdir(exist_ok=True)
        self.handle_path = self.root / "handles.json"
        self.handle_lock_path = self.root / ".handles.lock"
        self.checkpoints_dir = self.root / "checkpoints"
        self.checkpoints_dir.mkdir(exist_ok=True)
        self.anchors_path = self.root / "checkpoint_anchors.jsonl"
        self.anchors_path.touch(exist_ok=True)
        self.key_path = self.root / "journal_hmac.key"
        if not self.handle_path.exists():
            self._atomic_json(self.handle_path, {"version": 1, "handles": {}})
        if not self.key_path.exists():
            self.key_path.write_bytes(secrets.token_bytes(32))
            try:
                os.chmod(self.key_path, 0o600)
            except OSError:
                pass

    @property
    def _key(self) -> bytes:
        data = self.key_path.read_bytes()
        if len(data) < 32:
            raise JournalIntegrityError("causal journal authentication key is invalid")
        return data

    @staticmethod
    def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(path)

    def _turn_path(self, turn_id: str) -> Path:
        safe = str(turn_id).replace("/", "_")
        return self.turns_dir / f"{safe}.jsonl"

    def _turn_lock_path(self, turn_id: str) -> Path:
        safe = str(turn_id).replace("/", "_")
        return self.turns_dir / f".{safe}.lock"

    def _handle_mac(self, *, token: str, row: Mapping[str, Any]) -> str:
        body = {
            "turn_id": str(row.get("turn_id") or ""),
            "issued_at": float(row.get("issued_at") or 0.0),
            "revoked": bool(row.get("revoked")),
        }
        material = str(token).encode("utf-8") + b"\0" + _canonical(body)
        return hmac.new(self._key, material, hashlib.sha256).hexdigest()

    def _verify_handle_row(self, *, token: str, row: Mapping[str, Any]) -> None:
        supplied = str(row.get("mac_sha256") or "")
        expected = self._handle_mac(token=token, row=row)
        if not supplied or not hmac.compare_digest(expected, supplied):
            raise JournalIntegrityError("loop handle registry authentication failed")

    def issue_handle(self, turn_id: str) -> LoopHandle:
        with exclusive_lock(self.handle_lock_path) as status:
            if status.get("mutual_exclusion_proven") is not True:
                raise JournalIntegrityError("loop handle registry lock unavailable")
            rows = json.loads(self.handle_path.read_text(encoding="utf-8"))
            for token, row in rows.get("handles", {}).items():
                self._verify_handle_row(token=str(token), row=row)
                if row.get("turn_id") == turn_id and row.get("revoked") is not True:
                    return LoopHandle(turn_id=turn_id, state_token=str(token))
            token = secrets.token_urlsafe(32)
            row = {
                "turn_id": str(turn_id),
                "issued_at": time.time(),
                "revoked": False,
            }
            row["mac_sha256"] = self._handle_mac(token=token, row=row)
            rows.setdefault("handles", {})[token] = row
            self._atomic_json(self.handle_path, rows)
            return LoopHandle(turn_id=str(turn_id), state_token=token)

    def resolve_handle(self, handle: LoopHandle) -> str:
        with exclusive_lock(self.handle_lock_path) as status:
            if status.get("mutual_exclusion_proven") is not True:
                raise JournalIntegrityError("loop handle registry lock unavailable")
            rows = json.loads(self.handle_path.read_text(encoding="utf-8"))
            row = rows.get("handles", {}).get(str(handle.state_token))
            if not row:
                raise JournalIntegrityError("invalid or revoked loop handle")
            self._verify_handle_row(token=str(handle.state_token), row=row)
            if row.get("revoked") is True or str(row.get("turn_id")) != str(handle.turn_id):
                raise JournalIntegrityError("invalid or revoked loop handle")
            return str(row["turn_id"])

    def _record_body(self, *, turn_id: str, step_no: int, phase: str, previous_head: str,
                     state: Mapping[str, Any], transition: Mapping[str, Any]) -> dict[str, Any]:
        payload = {
            "schema": "jigaewol_causal_step_v1",
            "turn_id": str(turn_id),
            "step_no": int(step_no),
            "phase": str(phase),
            "previous_head_sha256": str(previous_head),
            "state": dict(state),
            "transition": dict(transition),
            "recorded_at": time.time(),
        }
        payload_sha = _sha(payload)
        causal_head = hashlib.sha256((str(previous_head) + payload_sha).encode("ascii")).hexdigest()
        mac = hmac.new(self._key, (causal_head + payload_sha).encode("ascii"), hashlib.sha256).hexdigest()
        return {**payload, "payload_sha256": payload_sha, "causal_head_sha256": causal_head, "mac_sha256": mac}

    def verify_chain(self, turn_id: str) -> VerifiedJournalHead:
        path = self._turn_path(turn_id)
        if not path.exists() or not path.read_text(encoding="utf-8").strip():
            return VerifiedJournalHead(str(turn_id), 0, "GENESIS", "", {}, 0, None)
        previous_head = ""
        previous_phase = "GENESIS"
        previous_step = 0
        last: dict[str, Any] = {}
        count = 0
        for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if not raw.strip():
                continue
            try:
                row = json.loads(raw)
            except Exception as exc:
                raise JournalIntegrityError(f"causal journal unreadable at line {line_no}") from exc
            if str(row.get("turn_id")) != str(turn_id):
                raise JournalIntegrityError("cross-turn journal substitution detected")
            step = int(row.get("step_no") or 0)
            phase = str(row.get("phase") or "")
            if step != previous_step + 1:
                raise JournalIntegrityError("causal journal step monotonicity violation")
            if str(row.get("previous_head_sha256") or "") != previous_head:
                raise JournalIntegrityError("causal journal parent head mismatch")
            if phase not in self.ALLOWED_TRANSITIONS.get(previous_phase, frozenset()):
                raise JournalIntegrityError(f"illegal causal phase transition {previous_phase}->{phase}")
            body = {k: v for k, v in row.items() if k not in {"payload_sha256", "causal_head_sha256", "mac_sha256"}}
            payload_sha = _sha(body)
            if payload_sha != str(row.get("payload_sha256") or ""):
                raise JournalIntegrityError("causal journal payload digest mismatch")
            expected_head = hashlib.sha256((previous_head + payload_sha).encode("ascii")).hexdigest()
            if expected_head != str(row.get("causal_head_sha256") or ""):
                raise JournalIntegrityError("causal journal head mismatch")
            expected_mac = hmac.new(self._key, (expected_head + payload_sha).encode("ascii"), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(expected_mac, str(row.get("mac_sha256") or "")):
                raise JournalIntegrityError("causal journal authentication failed")
            previous_head, previous_phase, previous_step = expected_head, phase, step
            last = row
            count += 1
        return VerifiedJournalHead(
            str(turn_id), previous_step, previous_phase, previous_head,
            dict(last.get("state") or {}), count, CausalStepReceipt.from_mapping(last) if last else None,
        )

    def _checkpoint_path(self, turn_id: str) -> Path:
        safe = str(turn_id).replace("/", "_")
        return self.checkpoints_dir / f"{safe}.jsonl"

    def issue_checkpoint(self, turn_id: str) -> CausalCheckpoint:
        """Seal the currently verified head for later local/external anchoring."""
        head = self.verify_chain(turn_id)
        if not head.causal_head_sha256:
            raise JournalIntegrityError("cannot checkpoint an empty causal journal")
        body = {
            "schema": "jigaewol_causal_checkpoint_v1",
            "turn_id": str(turn_id),
            "step_no": int(head.step_no),
            "phase": str(head.phase),
            "causal_head_sha256": str(head.causal_head_sha256),
            "record_count": int(head.record_count),
            "issued_at": time.time(),
        }
        checkpoint_sha = _sha(body)
        mac = hmac.new(self._key, checkpoint_sha.encode("ascii"), hashlib.sha256).hexdigest()
        checkpoint = CausalCheckpoint(
            turn_id=str(turn_id), step_no=head.step_no, phase=head.phase,
            causal_head_sha256=head.causal_head_sha256, record_count=head.record_count,
            issued_at=float(body["issued_at"]), checkpoint_sha256=checkpoint_sha, mac_sha256=mac,
        )
        path = self._checkpoint_path(turn_id)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(asdict(checkpoint), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        return checkpoint

    def verify_checkpoint(self, checkpoint: CausalCheckpoint, *, require_current_head: bool = False) -> bool:
        body = {
            "schema": "jigaewol_causal_checkpoint_v1",
            "turn_id": checkpoint.turn_id,
            "step_no": checkpoint.step_no,
            "phase": checkpoint.phase,
            "causal_head_sha256": checkpoint.causal_head_sha256,
            "record_count": checkpoint.record_count,
            "issued_at": checkpoint.issued_at,
        }
        digest = _sha(body)
        if digest != checkpoint.checkpoint_sha256:
            return False
        expected = hmac.new(self._key, digest.encode("ascii"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, checkpoint.mac_sha256):
            return False
        if require_current_head:
            head = self.verify_chain(checkpoint.turn_id)
            return (head.step_no == checkpoint.step_no and head.phase == checkpoint.phase
                    and head.causal_head_sha256 == checkpoint.causal_head_sha256
                    and head.record_count == checkpoint.record_count)
        return True

    def latest_checkpoint(self, turn_id: str) -> CausalCheckpoint | None:
        path = self._checkpoint_path(turn_id)
        if not path.exists():
            return None
        rows = [x for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
        if not rows:
            return None
        checkpoint = CausalCheckpoint(**json.loads(rows[-1]))
        if not self.verify_checkpoint(checkpoint):
            raise JournalIntegrityError("causal checkpoint authentication failed")
        return checkpoint

    def record_external_anchor(self, *, checkpoint: CausalCheckpoint, origin_ref: str,
                               anchor_receipt_sha256: str, host_call_observed: bool) -> dict[str, Any]:
        """Bind a signed checkpoint to a separately observed external anchor receipt."""
        if host_call_observed is not True:
            raise JournalIntegrityError("external checkpoint anchor requires observed host-call evidence")
        if not self.verify_checkpoint(checkpoint):
            raise JournalIntegrityError("cannot anchor an invalid causal checkpoint")
        row = {
            "schema": "jigaewol_causal_checkpoint_anchor_v1",
            "turn_id": checkpoint.turn_id,
            "checkpoint_sha256": checkpoint.checkpoint_sha256,
            "causal_head_sha256": checkpoint.causal_head_sha256,
            "origin_ref": str(origin_ref),
            "anchor_receipt_sha256": str(anchor_receipt_sha256),
            "observed_at": time.time(),
        }
        row["anchor_record_sha256"] = _sha(row)
        with self.anchors_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
        return row


    def perform_effect_transition(
        self, *, turn_id: str, expected_parent_head: str, phase: str,
        state: Mapping[str, Any], effect: Callable[[], Any],
        transition_factory: Callable[[Any], Mapping[str, Any]],
    ) -> tuple[Any, VerifiedJournalHead]:
        """Publish an external/durable effect only while the expected head is current.

        The per-turn journal lock stays held across the head check, effect, and RELEASE
        record append.  This closes the check-then-publish race where a permit could
        be valid at PREPARE time but stale by the moment the response is committed.
        """
        with exclusive_lock(self._turn_lock_path(turn_id)) as status:
            if status.get("mutual_exclusion_proven") is not True:
                raise JournalIntegrityError("causal journal lock unavailable")
            head = self.verify_chain(turn_id)
            if str(expected_parent_head or "") != str(head.causal_head_sha256 or ""):
                raise JournalIntegrityError("compare-and-swap parent head mismatch before effect")
            if str(phase) not in self.ALLOWED_TRANSITIONS.get(head.phase, frozenset()):
                raise JournalIntegrityError(f"illegal causal phase transition {head.phase}->{phase}")
            result = effect()
            transition = dict(transition_factory(result) or {})
            row = self._record_body(
                turn_id=str(turn_id), step_no=head.step_no + 1, phase=str(phase),
                previous_head=head.causal_head_sha256, state=state, transition=transition,
            )
            path = self._turn_path(turn_id)
            with path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
                fh.flush()
                try:
                    os.fsync(fh.fileno())
                except OSError:
                    pass
            return result, self.verify_chain(turn_id)

    def append_transition(self, *, turn_id: str, expected_parent_head: str, phase: str,
                          state: Mapping[str, Any], transition: Mapping[str, Any]) -> VerifiedJournalHead:
        with exclusive_lock(self._turn_lock_path(turn_id)) as status:
            if status.get("mutual_exclusion_proven") is not True:
                raise JournalIntegrityError("causal journal lock unavailable")
            head = self.verify_chain(turn_id)
            if str(expected_parent_head or "") != str(head.causal_head_sha256 or ""):
                raise JournalIntegrityError("compare-and-swap parent head mismatch")
            if str(phase) not in self.ALLOWED_TRANSITIONS.get(head.phase, frozenset()):
                raise JournalIntegrityError(f"illegal causal phase transition {head.phase}->{phase}")
            row = self._record_body(
                turn_id=str(turn_id), step_no=head.step_no + 1, phase=str(phase),
                previous_head=head.causal_head_sha256, state=state, transition=transition,
            )
            path = self._turn_path(turn_id)
            with path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
                fh.flush()
                try:
                    os.fsync(fh.fileno())
                except OSError:
                    pass
            return self.verify_chain(turn_id)

    def current(self, handle: LoopHandle) -> VerifiedJournalHead:
        turn_id = self.resolve_handle(handle)
        return self.verify_chain(turn_id)
