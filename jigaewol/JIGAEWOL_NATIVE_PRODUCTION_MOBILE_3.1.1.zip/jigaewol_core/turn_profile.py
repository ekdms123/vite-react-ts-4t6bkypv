from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable, Any, Mapping

from .open_world_intent import extract_open_world_intent
from jigaewol_components.semantic_authority import bind_semantic_authority
from jigaewol_components.foundational_rewrite_intent import foundational_rewrite_requested


@dataclass(frozen=True)
class TurnExecutionProfile:
    mode: str
    reason: str
    uncertainty: float
    explicit_depth: str
    missing_traits: tuple[str, ...]
    escalation_history: tuple[str, ...] = ()


_DEEP_MARKERS = (
    "깊게", "심층", "철저", "반례", "반증", "여러 관점", "다각도", "창의적으로", "새로운 관점", "서로 다른 해법",
    "deep", "exhaustive", "thorough", "counterexample", "falsif", "multiple perspective", "multiple viewpoints",
    "creative", "non-obvious", "alternative worlds", "parallel worlds",
)
_SIMPLE_ARITHMETIC = re.compile(r"^\s*-?\d+(?:\.\d+)?\s*[+\-*/]\s*-?\d+(?:\.\d+)?\s*(?:=|\?|？|은|는)?\s*$")
_ORDER = {"FAST": 0, "STANDARD": 1, "DEEP": 2}


def _attachment_count(attachments: Iterable[Any] | None) -> int:
    if attachments is None:
        return 0
    try:
        return len(tuple(attachments))
    except TypeError:
        return 1


def classify_turn_profile(
    objective: str,
    *,
    explicit_depth: str = "unspecified",
    uncertainty: float = 0.5,
    missing_traits: Iterable[str] = (),
    required_traits: Iterable[str] = (),
    attachments: Iterable[Any] = (),
    semantic_authority: Mapping[str, Any] | None = None,
) -> TurnExecutionProfile:
    """Describe execution effort from task structure; diagnostic uncertainty is not a gate."""
    text = str(objective or "")
    folded = text.casefold()
    depth = str(explicit_depth or "unspecified").casefold()
    u = min(1.0, max(0.0, float(uncertainty)))
    missing = tuple(dict.fromkeys(str(x) for x in missing_traits if str(x)))
    required = tuple(dict.fromkeys(str(x) for x in required_traits if str(x)))
    authority = bind_semantic_authority(objective, semantic_authority)
    open_intent = extract_open_world_intent(text, semantic_authority=authority)
    # Derived metadata may expand a source directive, never suppress a depth
    # instruction appearing in the user's exact words.
    explicit_deep = bool(
        depth == "deep"
        or any(marker in folded for marker in _DEEP_MARKERS)
        or str(authority.get("effective_depth") or "").casefold() == "deep"
        or authority.get("frontier_exploration_required")
        or authority.get("representation_search_required")
    )
    structurally_deep = open_intent.deep_escalation or foundational_rewrite_requested(text) or len(missing) >= 2
    if explicit_deep or structurally_deep:
        reason = "explicit_or_structural_deep_requirement"
        return TurnExecutionProfile("DEEP", reason, u, depth, missing)
    if required or missing or _attachment_count(attachments):
        return TurnExecutionProfile("STANDARD", "evidence_or_capability_work_required", u, depth, missing)
    if _SIMPLE_ARITHMETIC.match(text.strip()):
        return TurnExecutionProfile("FAST", "deterministic_direct_path", u, depth, missing)
    return TurnExecutionProfile("STANDARD", "default_general_path", u, depth, missing)


def escalate_profile(current: str | TurnExecutionProfile, reason: str) -> TurnExecutionProfile:
    if isinstance(current, TurnExecutionProfile):
        base = current
        mode = base.mode
    else:
        mode = str(current).upper()
        base = TurnExecutionProfile(mode, "existing_profile", 0.5, "unspecified", ())
    if mode not in _ORDER:
        raise ValueError(f"unknown execution profile: {mode}")
    target = "DEEP" if mode in {"STANDARD", "DEEP"} else "STANDARD"
    if _ORDER[target] < _ORDER[mode]:
        target = mode
    return TurnExecutionProfile(
        target,
        f"escalated:{reason}" if target != mode else f"preserved_deep:{reason}",
        base.uncertainty,
        base.explicit_depth,
        base.missing_traits,
        base.escalation_history + (str(reason),),
    )
