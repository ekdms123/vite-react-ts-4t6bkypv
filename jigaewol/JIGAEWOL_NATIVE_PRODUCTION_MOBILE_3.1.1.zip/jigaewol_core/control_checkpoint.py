from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from pathlib import Path
from typing import Any


def _digest(row: dict[str, Any]) -> str:
    body = {k: v for k, v in row.items() if k != "receipt_sha256"}
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _valid_sha256(value: str) -> bool:
    value = str(value or "").strip().lower()
    return len(value) == 64 and all(ch in "0123456789abcdef" for ch in value)


class ControlCheckpointLedger:
    """Tamper-evident cache of externally observed control-plane revisions.

    A cached checkpoint is not a fresh external read. It is only a locally verified
    reuse of a prior fresh observation, bounded by both TTL and the exact active
    artifact content-set SHA. Freshness requirements come from the active user
    contract and current task; this ledger only makes reuse precise and auditable.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "control_checkpoints.jsonl"

    def _history(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        rows: list[dict[str, Any]] = []
        previous = ""
        for line_number, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            row = json.loads(line)
            if not isinstance(row, dict):
                raise RuntimeError(f"control checkpoint ledger contains non-object at line {line_number}")
            if str(row.get("previous_receipt_sha256") or "") != previous:
                raise RuntimeError("control checkpoint chain discontinuity")
            actual = _digest(row)
            if actual != str(row.get("receipt_sha256") or ""):
                raise RuntimeError("control checkpoint receipt digest mismatch")
            previous = actual
            rows.append(row)
        return rows

    def verify_chain(self) -> bool:
        try:
            self._history()
            return True
        except (OSError, ValueError, json.JSONDecodeError, RuntimeError):
            return False

    def record_fresh(
        self,
        *,
        page_id: str,
        page_revision: str,
        origin_ref: str,
        artifact_content_set_sha256: str,
        observed_at: float | None = None,
    ) -> dict[str, Any]:
        page_id = str(page_id or "").strip()
        page_revision = str(page_revision or "").strip()
        origin_ref = str(origin_ref or "").strip()
        artifact_sha = str(artifact_content_set_sha256 or "").strip().lower()
        if not page_id or not page_revision or not origin_ref:
            raise ValueError("page_id, page_revision, and origin_ref are required")
        if not _valid_sha256(artifact_sha):
            raise ValueError("artifact_content_set_sha256 must be a SHA-256 digest")
        history = self._history()
        previous = str(history[-1].get("receipt_sha256") or "") if history else ""
        ts = float(time.time() if observed_at is None else observed_at)
        row = {
            "receipt_id": f"control_checkpoint_{uuid.uuid4().hex[:20]}",
            "source_kind": "notion",
            "page_id": page_id,
            "page_revision": page_revision,
            "origin_ref": origin_ref,
            "artifact_content_set_sha256": artifact_sha,
            "fresh_observation": True,
            "observed_at": ts,
            "previous_receipt_sha256": previous,
        }
        row["receipt_sha256"] = _digest(row)
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        return dict(row)

    def latest_valid(
        self,
        *,
        page_id: str,
        artifact_content_set_sha256: str,
        max_age_seconds: float = 300.0,
        now: float | None = None,
    ) -> dict[str, Any]:
        page_id = str(page_id or "").strip()
        artifact_sha = str(artifact_content_set_sha256 or "").strip().lower()
        if not page_id or not _valid_sha256(artifact_sha):
            return {}
        ttl = max(0.0, float(max_age_seconds))
        current = float(time.time() if now is None else now)
        for row in reversed(self._history()):
            if str(row.get("page_id") or "") != page_id:
                continue
            if str(row.get("artifact_content_set_sha256") or "").lower() != artifact_sha:
                continue
            age = current - float(row.get("observed_at") or 0.0)
            if age < -5.0 or age > ttl:
                continue
            out = dict(row)
            out.update({
                "cache_valid": True,
                "cache_age_seconds": max(0.0, age),
                "max_age_seconds": ttl,
                "checkpoint_mode": "cached_verified",
                "checkpoint_id": (
                    f"notion:cached_verified:{row['receipt_id']}:{row['page_revision']}"
                ),
            })
            return out
        return {}
