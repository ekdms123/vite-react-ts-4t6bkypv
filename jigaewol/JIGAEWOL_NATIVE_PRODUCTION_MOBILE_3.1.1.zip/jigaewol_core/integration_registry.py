from __future__ import annotations

import importlib
from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True)
class IntegratedComponent:
    """Canonical component descriptor mapping runtime services to implementation."""

    component_id: str
    module: str
    symbol: str
    layer: str
    lineage: str
    purpose: str


COMPONENTS = (
    IntegratedComponent("foundation", "jigaewol_runtime.foundation.runtime", "OperatingFoundation", "ingress", "2.1.0", "durable operating boundary"),
    IntegratedComponent("per_turn_gate", "jigaewol_runtime.bridge.turn_gate", "PerTurnGate", "ingress", "2.1.0", "strict every-turn ingress"),
    IntegratedComponent("action_router", "jigaewol_runtime.capabilities.action_router", "HostActionRouter", "execution", "2.1.0", "exact host-action dispatch"),
    IntegratedComponent("fabric_plan", "jigaewol_runtime.capabilities.fabric_plan", "build_execution_fabric_plan", "execution", "2.1.0", "composed execution route planning"),
    IntegratedComponent("agent_pool", "jigaewol_runtime.capabilities.agent_pool", "agent_pool_plan", "execution", "2.1.0", "external delegate composition"),
    IntegratedComponent("evidence_graph", "jigaewol_runtime.cognition.evidence_graph", "apply_evidence_graph_delta", "cognition", "2.1.0", "scoped evidence propagation"),
    IntegratedComponent("delta_recompiler", "jigaewol_runtime.compiler.recompile", "recompile", "cognition", "2.1.0", "affected-state recompilation"),
    IntegratedComponent("self_maintenance", "jigaewol_runtime.foundation.self_maintenance", "SelfMaintenanceController", "revision", "2.1.0", "lineage-preserving self maintenance"),
    IntegratedComponent("turn_audit", "jigaewol_components.turn_audit", "TurnAuditLedger", "audit", "1", "append-only observations and repair signals"),
    IntegratedComponent("semantic_communication", "jigaewol_components.semantic_communication", "SemanticCommunicationLayer", "communication", "R26", "canonical semantic ingress/egress and normalized-only audit"),
    IntegratedComponent("response_sink", "jigaewol_components.response_sink", "ResponseSink", "release", "current", "CAS-backed single-use release"),
    IntegratedComponent("intent_analyzer", "jigaewol_components.intent_deep_analyzer", "IntentDeepAnalyzer", "intent", "current", "auditable latent intent/depth facet"),
    IntegratedComponent("cumulative_intent", "jigaewol_components.cumulative_intent", "CumulativeIntentLedger", "intent", "current", "persistent requirement ledger"),
    IntegratedComponent("intent_fidelity", "jigaewol_components.intent_fidelity", "IntentFidelityProjector", "fidelity", "current", "shadow/reference intent verification"),
    IntegratedComponent("objective_fidelity", "jigaewol_components.objective_fidelity", "ObjectiveFidelity", "fidelity", "current", "objective preservation checks"),
    IntegratedComponent("open_world_guard", "jigaewol_components.open_world_guard", "OpenWorldGuard", "open_world", "current", "closed-population detection"),
    IntegratedComponent("open_world_auditor", "jigaewol_components.open_world_guard", "OpenWorldConstraintAuditor", "open_world", "current", "source constraint audit"),
    IntegratedComponent("meta_control", "jigaewol_components.meta_control", "MetaControlPlane", "control", "current", "replaceable control topologies"),
    IntegratedComponent("capability_bus", "jigaewol_components.capability_bus", "UniversalCapabilityBus", "execution", "current", "models/tools below orchestrator"),
    IntegratedComponent("revision_kernel", "jigaewol_components.revision_kernel", "RevisionKernel", "revision", "current", "versioned self-revising state"),
    IntegratedComponent("quality_diversity", "jigaewol_components.quality_diversity", "QualityDiversityArchive", "revision", "current", "diversity-preserving archive"),
    IntegratedComponent("coordination_blackboard", "jigaewol_components.coordination_blackboard", "CoordinationBlackboard", "revision", "current", "indirect coordination memory"),
    IntegratedComponent("git_lineage", "jigaewol_components.git_lineage", "GitLineage", "revision", "current", "code lineage graph"),
    IntegratedComponent("environment_lineage", "jigaewol_components.environment_lineage", "EnvironmentLineage", "revision", "current", "environment-selected lineage"),
    IntegratedComponent("thought_tree", "jigaewol_components.thought_tree", "DivergentThoughtTree", "cognition", "current", "branching hypothesis topology"),
    IntegratedComponent("reasoning_portfolio", "jigaewol_components.reasoning_portfolio", "AdaptiveReasoningPortfolio", "cognition", "current", "adaptive strategy portfolio"),
    IntegratedComponent("verification_loop_breaker", "jigaewol_components.reflexive_breaker", "VerificationLoopBreaker", "fidelity", "current", "self-supporting verification-loop detector"),
    IntegratedComponent("search_portfolio", "jigaewol_components.search_portfolio", "SearchPortfolio", "open_world", "current", "heterogeneous search portfolio"),
    IntegratedComponent("browser_plane", "jigaewol_components.browser_plane", "BrowserPlane", "execution", "current", "persistent browser/perception plane"),
    IntegratedComponent("terminal_backplane", "jigaewol_components.terminal_backplane", "TerminalBackplane", "execution", "current", "external terminal substrate"),
    IntegratedComponent("operational_resilience", "jigaewol_core.operational_resilience", "OperationalResilienceEngine", "execution", "current", "provider-neutral route revision and lifecycle truth"),
    IntegratedComponent("public_execution_trace", "jigaewol_core.observability", "PublicExecutionTrace", "observability", "current", "live phase/tool/receipt telemetry"),
    IntegratedComponent("semantic_candidate_engine", "jigaewol_core.semantic_loop", "SemanticCandidateEngine", "cognition", "current", "runtime-owned semantic candidate generation"),
    IntegratedComponent("adaptive_resource_envelope", "jigaewol_core.resource_policy", "derive_resource_envelope", "governor", "current", "resource-derived cognition/execution budget"),
    IntegratedComponent("representation_gap_worlds", "jigaewol_core.world_invention", "RepresentationGapWorldGenerator", "open_world", "current", "gap-driven world invention without a pre-labelled slot"),
    IntegratedComponent("execution_receipt_ledger", "jigaewol_core.evidence_attestation", "ExecutionReceiptLedger", "evidence", "current", "structural host execution attestation"),
    IntegratedComponent("revision_promotion_loop", "jigaewol_core.adaptive_revision", "EvidenceClosedRevisionLoop", "revision", "current", "revision promotion only after measured lift"),
)


class IntegrationRegistry:
    """Resolve and probe integrated runtime components dynamically.

    Import resolution is lazy: components are imported only when requested.
    """

    def __init__(self, components=COMPONENTS) -> None:
        self.components = tuple(components)
        self._resolved: dict[str, Any] = {}

    def resolve(self, component_id: str) -> Any:
        if component_id in self._resolved:
            return self._resolved[component_id]
        spec = next((x for x in self.components if x.component_id == component_id), None)
        if spec is None:
            raise KeyError(component_id)
        module = importlib.import_module(spec.module)
        obj = getattr(module, spec.symbol)
        self._resolved[component_id] = obj
        self._resolved[spec.component_id] = obj
        return obj

    def descriptor_snapshot(self) -> dict[str, Any]:
        """Return the declared internal component surface without importing it.

        This is the hot-path view. Full import resolution remains available through
        :meth:`canonical_probe` and is run during release validation, not redundantly
        on every conversational turn.
        """
        rows = tuple({**asdict(spec), "live": None, "probe_state": "deferred_to_release_validation"} for spec in self.components)
        return {
            "registered": len(rows),
            "live": None,
            "failed": None,
            "all_live": None,
            "probe_scope": "declared_internal_component_surface",
            "per_turn_import_probe": False,
            "release_validation_required_for_liveness": True,
            "host_tool_execution_truth": "receipt_bound_not_inferred_from_internal_imports",
            "execution_model": "declaration is hot-path metadata; import liveness is release-validation evidence",
            "components": rows,
        }

    def canonical_probe(self) -> dict[str, Any]:
        """Probe the canonical component surface with verified status."""
        rows = []
        for spec in self.components:
            try:
                obj = self.resolve(spec.component_id)
                row = {**asdict(spec), "live": True, "resolved_type": type(obj).__name__}
            except Exception as exc:
                row = {**asdict(spec), "live": False, "error_type": type(exc).__name__, "error": str(exc)[:400]}
            rows.append(row)
        live = sum(1 for x in rows if x["live"])
        return {
            "registered": len(rows),
            "live": live,
            "failed": len(rows) - live,
            "all_live": live == len(rows),
            "probe_scope": "internal_component_import_resolution",
            "host_tool_execution_truth": "verified_receipts_define_execution",
            "execution_model": "internal component resolution verified; host tool execution confirmed via verified receipts",
            "components": tuple(rows),
        }

    def probe(self) -> dict[str, Any]:
        """Canonical probe alias retained for backward compatibility."""
        return self.canonical_probe()
