from __future__ import annotations

import json
from dataclasses import replace
from typing import Any, TYPE_CHECKING

from .semantic_loop import GenerationRequest
from jigaewol_components.authority_guard import source_bound_objective

if TYPE_CHECKING:
    from .runtime import CoreTurn


class CoreRuntimeDeliberationMixin:
    """Incubation, tournament, and verification side-lane orchestration."""
    def _incubate_generation_portfolio(self, turn: CoreTurn, request: GenerationRequest, portfolio, *, candidate_generator=None):
        """Give fragile frame candidates a score-free growth pass before adversarial comparison."""
        rows = []
        frame_map = {
            str(frame.get("frame_id")): dict(frame)
            for frame in (turn.representation_tournament or {}).get("frames", ())
        }
        for index, seed_result in enumerate(tuple(portfolio)):
            frame_id = str(seed_result.metadata.get("active_world_id") or ("original" if index == 0 else ""))
            frame = frame_map.get(frame_id, {"frame_id": frame_id})
            incubation_request = replace(
                request,
                active_world=None,
                evidence={
                    **dict(request.evidence),
                    "incubation_seed": seed_result.candidate_body,
                    "incubation_frame": frame,
                },
                response_contract={
                    **dict(request.response_contract),
                    "incubation": True,
                    "pre_adversarial_growth_only": True,
                    "preserve_frame_and_user_goal": True,
                    "return_json_object": {
                        "text": "elaborated candidate",
                        "mechanisms": ["concrete mechanism"],
                        "assumptions": ["explicit assumption"],
                        "causal_links": ["cause -> effect"],
                        "tensions": ["known tension"],
                    },
                    "artifact_role": "internal_candidate",
                },
                execution_profile="INCUBATION",
            )
            elaborated_result = self.semantic.generate(incubation_request, generator=candidate_generator)
            payload = None
            try:
                payload = json.loads(elaborated_result.candidate_body)
            except Exception:
                payload = None
            if isinstance(payload, dict):
                elaboration = str(payload.get("text") or payload.get("elaboration") or "").strip()
                mechanisms = payload.get("mechanisms") or ()
                assumptions = payload.get("assumptions") or ()
                causal_links = payload.get("causal_links") or ()
                tensions = payload.get("tensions") or ()
            else:
                elaboration = elaborated_result.candidate_body.strip()
                mechanisms = assumptions = causal_links = tensions = ()
            if not elaboration:
                rows.append(seed_result)
                continue
            idea = self.incubator.incubate(
                frame_id or f"frame_{index}", seed_result.candidate_body, elaboration,
                mechanisms=mechanisms, assumptions=assumptions, causal_links=causal_links, tensions=tensions,
            )
            self.trace.emit(
                turn_id=turn.release_turn_id, phase="CANDIDATE_GENERATION",
                status="TRAVERSED" if idea.ready_for_adversarial else "BLOCKED",
                component="IncubationEngine", action="canonical_pre_adversarial_incubation",
                receipt_id=idea.idea_id,
                details={"frame_id": frame_id, "ready": idea.ready_for_adversarial, "findings": idea.maturity_findings},
            )
            if idea.ready_for_adversarial:
                rows.append(replace(
                    elaborated_result,
                    metadata={
                        **dict(elaborated_result.metadata),
                        "active_world_id": None if frame_id == "original" else frame_id,
                        "incubated": True, "incubation_idea_id": idea.idea_id,
                        "incubated_from_generation_id": seed_result.generation_id,
                    },
                ))
            else:
                rows.append(replace(
                    seed_result, metadata={**dict(seed_result.metadata), "incubated": False, "incubation_findings": idea.maturity_findings}
                ))
        return tuple(rows)
    def _adjudicate_generation_portfolio(self, turn: CoreTurn, request: GenerationRequest, portfolio, *, candidate_generator=None):
        """Run the canonical representation portfolio through the existing tournament ledger.

        This does not expose hidden reasoning. It compares user-facing candidate artifacts
        produced under distinct representation frames, records cross-frame objections when
        there are enough candidates, and feeds the verdict back into synthesis. A failed
        adjudication widens/repairs synthesis instead of pretending the tournament succeeded.
        """
        rows = tuple(portfolio)
        if len(rows) < 2:
            return {"active": False, "reason": "insufficient_portfolio"}
        round_row = self.open_tournament(turn, min_candidates=len(rows))
        if round_row is None:
            return {"active": False, "reason": "single_frame_plan"}
        submitted = []
        for index, result in enumerate(rows):
            frame_id = str(result.metadata.get("active_world_id") or ("original" if index == 0 else ""))
            if not frame_id or frame_id not in round_row.expected_frames:
                continue
            self.tournament.submit_candidate(round_row.round_id, frame_id, result.candidate_body)
            submitted.append((frame_id, result.candidate_body))
        if round_row.refutation_required and len(submitted) >= 3:
            for index, (attacker_id, attacker_text) in enumerate(submitted):
                target_id, target_text = submitted[(index + 1) % len(submitted)]
                refute_request = replace(
                    request,
                    active_world=None,
                    evidence={
                        **dict(request.evidence),
                        "tournament_refutation": {
                            "attacker_frame": attacker_id, "target_frame": target_id,
                            "attacker_candidate": attacker_text, "target_candidate": target_text,
                        },
                    },
                    response_contract={
                        **dict(request.response_contract),
                        "tournament_refutation": True,
                        "return_one_specific_material_objection_only": True,
                        "artifact_role": "internal_candidate",
                    },
                    execution_profile="TOURNAMENT_REFUTATION",
                )
                objection = self.semantic.generate(refute_request, generator=candidate_generator)
                claim = objection.candidate_body.strip()
                if claim:
                    self.tournament.submit_refutation(
                        round_row.round_id, attacker_id, target_id, claim, severity="major", answered=False
                    )
        verdict = self.adjudicate_tournament(turn, round_row.round_id)
        mapping = verdict.as_mapping() if hasattr(verdict, "as_mapping") else {
            "round_id": verdict.round_id, "decided": verdict.decided,
            "findings": tuple(verdict.findings), "winner_frame": verdict.winner_frame,
            "merge_candidates": tuple(verdict.merge_candidates),
            "convergence_detected": verdict.convergence_detected,
        }
        return {"active": True, **mapping}
    @property
    def tournament(self):
        """Ledger for representation rounds, created on first use."""
        from jigaewol_components.tournament_engine import TournamentEngine
        if getattr(self, "_tournament", None) is None:
            self._tournament = TournamentEngine(self.root)
        return self._tournament
    @property
    def incubator(self):
        """Score-free pre-adversarial growth ledger, created on first use."""
        from jigaewol_components.incubation import IncubationEngine
        if getattr(self, "_incubator", None) is None:
            self._incubator = IncubationEngine(self.root)
        return self._incubator
    def incubate_tournament_candidates(self, turn: CoreTurn, *, seed_writer, elaborator, max_frames: int | None = None):
        """Grow representation seeds before adversarial comparison.

        `seed_writer(frame, context)` may return text or a mapping with `seed`.
        `elaborator(seed, frame, context)` returns either elaborated text or a mapping
        carrying `text`, `mechanisms`, `assumptions`, `causal_links`, and `tensions`.
        Incubation never chooses a winner and never counts as verification.
        """
        payload = turn.representation_tournament or {}
        frames = list(payload.get("frames") or ())[: max_frames or None]
        if len(frames) < 2:
            return ()
        context = {
            "objective": source_bound_objective(turn.command, turn.semantic_authority),
            "requirement_contract": self._active_requirement_contract(turn),
            "goal_anchor": turn.goal_anchor,
            "stage": "pre_adversarial_incubation",
        }
        ideas = []
        for raw_frame in frames:
            frame = dict(raw_frame)
            frame_id = str(frame.get("frame_id") or "").strip()
            if not frame_id:
                continue
            try:
                raw_seed = seed_writer(frame, dict(context))
                seed = str(raw_seed.get("seed") if isinstance(raw_seed, dict) else raw_seed or "").strip()
                if not seed:
                    continue
                raw = elaborator(seed, frame, dict(context))
            except Exception as exc:
                self.trace.emit(turn_id=turn.release_turn_id, phase="CANDIDATE_GENERATION",
                                status="BLOCKED", component="IncubationEngine",
                                action="incubation_writer_failed",
                                details={"frame_id": frame_id, "error": f"{type(exc).__name__}: {exc}"[:200]})
                continue
            if isinstance(raw, dict):
                elaboration = str(raw.get("text") or raw.get("elaboration") or "").strip()
                kw = {name: raw.get(name) for name in ("mechanisms", "assumptions", "causal_links", "tensions")}
            else:
                elaboration = str(raw or "").strip()
                kw = {}
            if not elaboration:
                continue
            idea = self.incubator.incubate(frame_id, seed, elaboration, **kw)
            ideas.append(idea)
        self.trace.emit(turn_id=turn.release_turn_id, phase="CANDIDATE_GENERATION",
                        status="TRAVERSED", component="IncubationEngine",
                        action="pre_adversarial_incubation_completed",
                        details={"ideas": len(ideas), "ready": sum(i.ready_for_adversarial for i in ideas)})
        return tuple(ideas)
    @property
    def verification(self):
        """Claim ledger for this runtime, created on first use."""
        from jigaewol_components.verification_loop import VerificationLoop
        if getattr(self, "_verification", None) is None:
            self._verification = VerificationLoop()
        return self._verification
    def verification_report(self, turn: CoreTurn | None = None) -> dict[str, Any]:
        """Settle-state of every claim registered this session.

        A turn can be traced, gated and released while carrying a claim nobody checked;
        `settled` is false whenever a critical claim is still open, so the caller finds
        out before the answer ships rather than after a reader acts on it.
        """
        report = self.verification.report()
        if turn is not None:
            self.trace.emit(turn_id=turn.release_turn_id, phase="VERIFICATION",
                            status="TRAVERSED" if report.settled else "BLOCKED",
                            component="VerificationLoop", action="claim_ledger_reported",
                            details={"settled": report.settled,
                                     "open_critical": list(report.open_critical),
                                     "findings": list(report.findings)})
        return report.as_mapping()
    def open_tournament(self, turn: CoreTurn, *, min_candidates: int | None = None):
        """Open a scored round over the frames this turn already compiled.

        Ingress compiles frames and hands them on as instruction text, which means a
        turn can be called deliberated without any alternative ever being written down.
        Opening a round makes the comparison a thing with a record: candidates are
        submitted per frame, refutations are recorded between them, and adjudication
        refuses a round whose candidates never materially differed or where nothing was
        attacked. Callers that only want the frames can keep ignoring this.

        Returns None when the turn's plan holds a single frame — a baseline alone has
        no competition to hold, and pretending otherwise is the failure this guards.
        """
        from jigaewol_components.representation_tournament import (
            RepresentationFrame, RepresentationTournamentPlan,
        )
        from jigaewol_components.requirement_contract import RequirementCompiler

        payload = turn.representation_tournament or {}
        frames = tuple(
            RepresentationFrame(
                frame_id=str(f.get("frame_id")), mode=str(f.get("mode")),
                instruction=str(f.get("instruction")), purpose=str(f.get("purpose")),
                preserve_goal=bool(f.get("preserve_goal", True)),
            )
            for f in (payload.get("frames") or ())
        )
        if len(frames) < 2:
            return None
        plan = RepresentationTournamentPlan(
            active=bool(payload.get("active")), frames=frames,
            synthesis_rule=str(payload.get("synthesis_rule") or ""),
            rejection_rule=str(payload.get("rejection_rule") or ""),
        )
        contract = RequirementCompiler.from_mapping(self._active_requirement_contract(turn))
        objective = source_bound_objective(turn.command, turn.semantic_authority)
        row = self.tournament.open_round(objective, contract, plan, min_candidates=min_candidates)
        self.trace.emit(turn_id=turn.release_turn_id, phase="CANDIDATE_GENERATION", status="RUNNING",
                        component="TournamentEngine", action="representation_round_opened",
                        details={"round_id": row.round_id, "frames": len(frames),
                                 "min_candidates": row.min_candidates})
        return row
    def run_tournament(self, turn: CoreTurn, *, candidate_writer, refuter=None,
                       min_candidates: int | None = None, max_frames: int | None = None):
        """Play the round, not just referee it.

        The engine could already judge a round, but nothing filled one: candidates had
        to be submitted by hand, so in practice a turn still shipped whatever the first
        frame produced. This drives the loop — one candidate per frame, then cross-
        examination between them, then adjudication — with the model supplied as
        `candidate_writer`. The runtime owns the procedure; the model does the writing.

        `candidate_writer(frame, context) -> str` is called once per frame and is told
        which frame it is answering as. `refuter(attacker, target, context) -> mapping`
        may return `{"claim": ..., "severity": ...}` or None for no objection. Leaving
        `refuter` out is allowed and is not silently forgiven: adjudication then reports
        `no_refutation_recorded`, because a round nobody contested was not a contest.

        A writer that returns the same text for every frame is caught by the engine's
        similarity floor rather than passing as deliberation.
        """
        row = self.open_tournament(turn, min_candidates=min_candidates)
        if row is None:
            return None
        payload = turn.representation_tournament or {}
        by_id = {str(f.get("frame_id")): f for f in (payload.get("frames") or ())}
        frames = list(row.expected_frames)[: max_frames or len(row.expected_frames)]
        context = {
            "objective": source_bound_objective(turn.command, turn.semantic_authority),
            "requirement_contract": self._active_requirement_contract(turn),
            "goal_anchor": turn.goal_anchor,
            "synthesis_rule": row.synthesis_rule,
        }

        written: dict[str, str] = {}
        for frame_id in frames:
            frame = dict(by_id.get(frame_id) or {"frame_id": frame_id})
            try:
                body = candidate_writer(frame, dict(context))
            except Exception as exc:
                self.trace.emit(turn_id=turn.release_turn_id, phase="CANDIDATE_GENERATION",
                                status="BLOCKED", component="TournamentEngine",
                                action="candidate_writer_failed",
                                details={"frame_id": frame_id, "error": f"{type(exc).__name__}: {exc}"[:200]})
                continue
            semantic_profile = None
            if isinstance(body, dict):
                semantic_profile = body.get("semantic_profile")
                body = body.get("text") or body.get("body") or ""
            if not str(body or "").strip():
                continue
            self.tournament.submit_candidate(
                row.round_id, frame_id, str(body), semantic_profile=semantic_profile
            )
            written[frame_id] = str(body)

        if refuter is not None and len(written) >= 2:
            ordered = list(written)
            for index, attacker in enumerate(ordered):
                target = ordered[(index + 1) % len(ordered)]
                try:
                    objection = refuter(
                        {"frame_id": attacker, "text": written[attacker]},
                        {"frame_id": target, "text": written[target]},
                        dict(context),
                    )
                except Exception as exc:
                    self.trace.emit(turn_id=turn.release_turn_id, phase="CANDIDATE_GENERATION",
                                    status="BLOCKED", component="TournamentEngine",
                                    action="refuter_failed",
                                    details={"attacker": attacker, "error": f"{type(exc).__name__}: {exc}"[:200]})
                    continue
                if not objection:
                    continue
                claim = str(objection.get("claim") or "").strip()
                if not claim:
                    continue
                self.tournament.submit_refutation(
                    row.round_id, attacker, target, claim,
                    severity=str(objection.get("severity") or "major"),
                    answered=bool(objection.get("answered")),
                )
        return self.adjudicate_tournament(turn, row.round_id)
    def adjudicate_tournament(self, turn: CoreTurn, round_id: str):
        """Score a round and trace the verdict, including a refusal to decide."""
        from jigaewol_components.requirement_contract import RequirementCompiler
        contract = RequirementCompiler.from_mapping(self._active_requirement_contract(turn))
        verdict = self.tournament.adjudicate(round_id, contract)
        self.trace.emit(turn_id=turn.release_turn_id, phase="CANDIDATE_GENERATION",
                        status="TRAVERSED" if verdict.decided else "BLOCKED",
                        component="TournamentEngine", action="representation_round_adjudicated",
                        details={"round_id": round_id, "decided": verdict.decided,
                                 "winner": verdict.winner_frame, "findings": list(verdict.findings)})
        return verdict
