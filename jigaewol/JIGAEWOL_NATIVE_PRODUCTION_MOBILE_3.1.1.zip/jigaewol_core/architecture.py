from __future__ import annotations
def _layer(layer_id: str, components: tuple[str, ...] | list[str], rule: str) -> dict:
    canonical = list(components)
    return {
        "id": layer_id,
        "components": canonical,
        "rule": rule,
    }


LAYERS = (
    _layer("L0_INGRESS", ("OperatingFoundation", "PerTurnGate", "TurnAuditLedger"),
           "Every supported user turn is durably hashed before cognition or release."),
    _layer("L1_OBJECTIVE_ANCHOR", ("CumulativeIntentLedger", "IntentDeepAnalyzer", "literal-command pin"),
           "The user objective is the stable anchor. Route failure may mutate mechanisms, never silently shrink the destination."),
    _layer("L2_CURRENT_HOST_SURFACE", ("CapabilitySurfaceLedger", "OperationalResilienceEngine", "provider lifecycle"),
           "Capabilities are re-probed per session/turn. Installed, connected, callable, executed, successful, proven and integrated are distinct states."),
    _layer("L3_ROUTE_REVISION", ("RouteExperienceLibrary", "FailureRouter", "trait route composition", "capability acquisition"),
           "Need semantics precede provider identity. A failed implementation route triggers alternate legitimate routes and acquisition, not goal reduction."),
    _layer("L4_OPEN_COGNITION", ("cognition generation", "RepresentationGapWorldGenerator", "OpenCognitionEngine", "DivergentSpark", "QualitativeTension", "search portfolio", "evidence graph", "judgment memory"),
           "Evidence-free speculative sparks may enter cognition; qualitative paradoxes can be protected independently of numeric/Pareto domination."),
    _layer("L5_EXECUTION_FABRIC", ("FabricPlan", "exact action router", "agent pool", "provider handles", "virtual workstation", "terminal bridge"),
           "Destination coverage outranks convenience. External changes should use WRITE -> READ-BACK -> COMPARE -> PROVEN when possible."),
    _layer("L6_RESOURCE_GOVERNOR", ("Adaptive Resource Envelope", "latency target", "uncertainty", "CPU/capability headroom"),
           "Budgets are derived from live resources and decision pressure rather than arbitrary cognitive ceilings."),
    _layer("L7_SEMANTIC_CANDIDATE_LOOP", ("SemanticCandidateEngine", "replaceable model/solver components", "heterogeneous verifiers"),
           "Canonical run_turn owns answer generation. Semantic quality and provenance are separate evidence properties."),
    _layer("L8_FIDELITY", ("objective fidelity", "shadow/reference verification primitives", "open-world auditor", "response CAS"),
           "Verification diversity is tracked by failure family; verification repairs evidence without reducing cognition."),
    _layer("L9_PUBLIC_OBSERVABILITY", ("PublicExecutionTrace", "route/tool/receipt telemetry"),
           "Operators can see active phases, capabilities executed, failures, route changes, verification and release status."),
    _layer("L10_RELEASE", ("CandidateResponse", "ResponseSink", "ResponseCAS"),
           "INGRESSED -> TRAVERSED -> CANDIDATE_BOUND -> RELEASED; release integrity is response-hash bound."),
    _layer("L11_REVISION_AND_LIFT", ("CognitiveLiftGate", "quality diversity", "InvariantGovernanceLab", "InvariantAblationExperiment", "hot swap", "self-maintenance lineage"),
           "Runtime invariants support empirical revision: shadow ablation evaluates proposals against measured benchmarks while preserving objective anchors."),
    _layer("L12_RESIDENT_OPEN_WORLD", ("ResidentCognitionLoop", "ExogenousStimulus", "StimulusRequest", "resident lease/checkpoint"),
           "Resident cognition may continue between turns when a persistent host is present; closed-cycle debt requests exogenous friction before self-confirming iteration continues."),
    _layer("L13_GENERATIVE_SUBSTRATE", ("GenerativeSubstrateEvent", "raw spark reservoir", "host model bridge"),
           "The host model is a generative substrate. Raw divergent output may be preserved before schema/ranking compression."),
)


def architecture_snapshot():
    return {
        "name": "JIGAEWOL",
        "candidate": "2.1.0 user-directed runtime",
        "release_state": "stable",
        "version": "2.1.0",
        "layers": LAYERS,
    }
