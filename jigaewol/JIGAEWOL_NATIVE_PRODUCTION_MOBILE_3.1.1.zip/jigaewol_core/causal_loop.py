from __future__ import annotations

import hashlib
import json
import pickle
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any

from .action_port import ActionInvocation, ActionPending, ActionReceiptLedger, CompletedAction, ReceiptActionPort
from .causal_journal import CausalJournal, JournalIntegrityError, LoopHandle, VerifiedJournalHead
from .cognition_port import CognitiveInvocation, CognitionPending, CompletedInvocation, ReceiptCognitionPort
from jigaewol_components.response_protocol import sha256_text


def _json_sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class LoopState:
    turn_id: str
    original_directive_sha256: str
    semantic_scope_root: str
    step_no: int
    phase: str
    causal_head_sha256: str
    snapshot_sha256: str
    pending_kind: str = ""
    pending_invocation_id: str = ""
    pending_request_sha256: str = ""
    candidate_sha256: str = ""
    verification_state: str = "pending"
    verification_receipt_sha256: str = ""
    requirements_state: str = "PENDING"
    observation_state: str = "PENDING"
    authority_model: str = "user_directive_truth_kernel"
    self_authorized: bool = False
    terminal: bool = False
    terminal_semantics: str = ""
    open_obligations: tuple[str, ...] = ()


@dataclass(frozen=True)
class LoopOutcome:
    status: str
    handle: LoopHandle
    state: LoopState
    pending: dict[str, Any]
    released: Any | None = None
    finalization_commit: dict[str, Any] | None = None
    checkpoint: dict[str, Any] | None = None


@dataclass(frozen=True)
class VerificationReceipt:
    turn_id: str
    request_sha256: str
    candidate_sha256: str
    requirement_contract_sha256: str
    verifier_input_root: str
    verification_summary_sha256: str
    parent_causal_head_sha256: str
    verdict: str
    verifier_identity: str
    authority_model: str
    attestation_kind: str
    self_issued: bool
    observed_at: float
    receipt_sha256: str

    @classmethod
    def issue(cls, *, turn_id: str, request_sha256: str, candidate_sha256: str,
              requirement_contract_sha256: str, verification_summary: dict[str, Any],
              parent_causal_head_sha256: str, verdict: str,
              verifier_identity: str = "runtime_semantic_verifier",
              authority_model: str = "user_directive_truth_kernel",
              attestation_kind: str = "self_issued_attestation",
              self_issued: bool = True) -> "VerificationReceipt":
        observed_at = time.time()
        verifier_input_root = _json_sha({
            "request_sha256": str(request_sha256),
            "candidate_sha256": str(candidate_sha256),
            "requirement_contract_sha256": str(requirement_contract_sha256),
        })
        body = {
            "schema": "jigaewol_verification_receipt_v2",
            "turn_id": str(turn_id),
            "request_sha256": str(request_sha256),
            "candidate_sha256": str(candidate_sha256),
            "requirement_contract_sha256": str(requirement_contract_sha256),
            "verifier_input_root": verifier_input_root,
            "verification_summary_sha256": _json_sha(verification_summary),
            "parent_causal_head_sha256": str(parent_causal_head_sha256),
            "verdict": str(verdict),
            "verifier_identity": str(verifier_identity),
            "authority_model": str(authority_model),
            "attestation_kind": str(attestation_kind),
            "self_issued": bool(self_issued),
            "observed_at": observed_at,
        }
        return cls(**{k: v for k, v in body.items() if k != "schema"}, receipt_sha256=_json_sha(body))

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class CausalLoopCoordinator:
    """Canonical owner of suspend/resume cognition-action lifecycle.

    External actors can submit only a result for the exact pending invocation. They
    never submit LoopState. Every authoritative state load verifies the local causal
    journal and the trusted snapshot hash before the runtime advances.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.journal = CausalJournal(self.root / "journal")
        self.snapshots = self.root / "snapshots"
        self.snapshots.mkdir(exist_ok=True)

    def _snapshot_path(self, turn_id: str) -> Path:
        return self.snapshots / (str(turn_id).replace("/", "_") + ".pickle")

    def _save_snapshot(self, turn: Any) -> str:
        data = pickle.dumps(turn, protocol=pickle.HIGHEST_PROTOCOL)
        digest = hashlib.sha256(data).hexdigest()
        path = self._snapshot_path(str(turn.release_turn_id))
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
        return digest

    def _load_snapshot(self, turn_id: str, expected_sha256: str) -> Any:
        path = self._snapshot_path(turn_id)
        data = path.read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        if actual != str(expected_sha256):
            raise JournalIntegrityError("trusted CoreTurn snapshot hash mismatch")
        turn = pickle.loads(data)
        if str(getattr(turn, "release_turn_id", "")) != str(turn_id):
            raise JournalIntegrityError("trusted CoreTurn snapshot cross-turn substitution")
        return turn

    @staticmethod
    def _scope_root(turn: Any) -> str:
        scope = dict((getattr(turn, "semantic_authority", {}) or {}).get("discourse_scope") or {})
        return _json_sha(scope)

    def _state_from_head(self, head: VerifiedJournalHead) -> LoopState:
        row = dict(head.state or {})
        return LoopState(
            turn_id=head.turn_id,
            original_directive_sha256=str(row.get("original_directive_sha256") or ""),
            semantic_scope_root=str(row.get("semantic_scope_root") or ""),
            step_no=head.step_no,
            phase=head.phase,
            causal_head_sha256=head.causal_head_sha256,
            snapshot_sha256=str(row.get("snapshot_sha256") or ""),
            pending_kind=str(row.get("pending_kind") or ""),
            pending_invocation_id=str(row.get("pending_invocation_id") or ""),
            pending_request_sha256=str(row.get("pending_request_sha256") or ""),
            candidate_sha256=str(row.get("candidate_sha256") or ""),
            verification_state=str(row.get("verification_state") or "pending"),
            verification_receipt_sha256=str(row.get("verification_receipt_sha256") or ""),
            requirements_state=str(row.get("requirements_state") or "PENDING"),
            observation_state=str(row.get("observation_state") or "PENDING"),
            authority_model=str(row.get("authority_model") or "user_directive_truth_kernel"),
            self_authorized=bool(row.get("self_authorized")),
            terminal=bool(row.get("terminal")),
            terminal_semantics=str(row.get("terminal_semantics") or ""),
            open_obligations=tuple(row.get("open_obligations") or ()),
        )

    def _append(self, *, head: VerifiedJournalHead, phase: str, state: dict[str, Any], transition: dict[str, Any]) -> VerifiedJournalHead:
        advanced = self.journal.append_transition(
            turn_id=head.turn_id, expected_parent_head=head.causal_head_sha256,
            phase=phase, state=state, transition=transition,
        )
        # Periodic authenticated checkpoints reduce replay cost without making the
        # checkpoint itself the source of truth. Authority remains verify_chain().
        if advanced.step_no % 8 == 0 or phase in {"COMMIT", "INCOMPLETE", "FAILED_INTEGRITY"}:
            self.journal.issue_checkpoint(advanced.turn_id)
        return advanced

    def _ensure_ingress(self, turn: Any, *, snapshot_sha: str) -> tuple[LoopHandle, VerifiedJournalHead]:
        turn_id = str(turn.release_turn_id)
        handle = self.journal.issue_handle(turn_id)
        head = self.journal.current(handle)
        if head.phase == "GENESIS":
            state = {
                "original_directive_sha256": str(turn.command_sha256),
                "semantic_scope_root": self._scope_root(turn),
                "snapshot_sha256": snapshot_sha,
                "pending_kind": "",
                "pending_invocation_id": "",
                "pending_request_sha256": "",
                "pending_parent_step_sha256": "",
                "candidate_sha256": "",
                "verification_state": "pending",
                "verification_receipt_sha256": "",
                "requirements_state": "PENDING",
                "observation_state": "PENDING",
                "authority_model": "user_directive_truth_kernel",
                "self_authorized": False,
                "terminal": False,
                "terminal_semantics": "",
                "open_obligations": [],
            }
            head = self._append(
                head=head, phase="INGRESS", state=state,
                transition={
                    "kind": "ingress",
                    "foundation_receipt_id": str(turn.foundation_receipt_id),
                    "core_turn_id": str(turn.core_turn_id),
                    "directive_sha256": str(turn.command_sha256),
                    "semantic_scope_root": state["semantic_scope_root"],
                },
            )
        return handle, head

    def _snapshot_turn_from_runtime(self, runtime: Any, fallback: Any | None = None) -> Any:
        if fallback is not None:
            found = runtime._turns.get(getattr(fallback, "core_turn_id", ""))
            if found is not None:
                return found
        if not runtime._turns:
            raise RuntimeError("causal loop has no runtime turn to snapshot")
        return tuple(runtime._turns.values())[-1]

    def _pending_outcome(self, *, runtime: Any, turn: Any, kind: str, pending: Any,
                         prior_handle: LoopHandle | None = None) -> LoopOutcome:
        turn = self._snapshot_turn_from_runtime(runtime, turn)
        snapshot_sha = self._save_snapshot(turn)
        handle, head = self._ensure_ingress(turn, snapshot_sha=snapshot_sha)
        if prior_handle is not None:
            if prior_handle.turn_id != handle.turn_id or prior_handle.state_token != handle.state_token:
                raise JournalIntegrityError("resume handle changed across canonical loop")
            head = self.journal.current(handle)
        if kind == "cognition":
            payload = dict(getattr(pending, "request_payload", {}) or {})
            evidence = dict(payload.get("evidence") or {})
            feedback = tuple(evidence.get("verification_feedback") or ())
            if feedback and head.phase != "VERIFY":
                subject_request_sha = str(evidence.get("verification_subject_request_sha256") or "")
                subject_candidate_sha = str(evidence.get("verification_subject_candidate_sha256") or "")
                requirement_sha = str((turn.active_requirement_contract or turn.requirement_contract or {}).get("contract_sha256") or "")
                verification_receipt = VerificationReceipt.issue(
                    turn_id=turn.release_turn_id, request_sha256=subject_request_sha,
                    candidate_sha256=subject_candidate_sha, requirement_contract_sha256=requirement_sha,
                    verification_summary={"failed_findings": feedback, "repair_attempt": int(evidence.get("repair_attempt") or 0)},
                    parent_causal_head_sha256=head.causal_head_sha256, verdict="FAILED",
                )
                verify_state = dict(head.state)
                verify_state.update({
                    "snapshot_sha256": snapshot_sha,
                    "verification_state": "failed",
                    "verification_receipt_sha256": verification_receipt.receipt_sha256,
                    "candidate_sha256": subject_candidate_sha,
                })
                head = self._append(
                    head=head, phase="VERIFY", state=verify_state,
                    transition={"kind": "verification_failed_repair_required",
                                "verification_receipt": verification_receipt.as_mapping(),
                                "verification_receipt_sha256": verification_receipt.receipt_sha256},
                )
        phase = "AWAIT_COGNITION" if kind == "cognition" else "AWAIT_ACTION"
        state = dict(head.state)
        state.update({
            "snapshot_sha256": snapshot_sha,
            "pending_kind": kind,
            "pending_invocation_id": str(pending.invocation_id),
            "pending_request_sha256": str(pending.request_sha256),
            "pending_parent_step_sha256": str(getattr(pending, "parent_step_sha256", "") or ""),
            "terminal": False,
            "terminal_semantics": "",
        })
        head = self._append(
            head=head, phase=phase, state=state,
            transition={
                "kind": f"suspend_{kind}",
                "invocation_id": str(pending.invocation_id),
                "request_sha256": str(pending.request_sha256),
                "request_payload_sha256": _json_sha(pending.request_payload),
            },
        )
        return LoopOutcome(
            status="SUSPENDED_AWAITING_COGNITION" if kind == "cognition" else "SUSPENDED_AWAITING_TOOL",
            handle=handle, state=self._state_from_head(head),
            pending={
                "kind": kind,
                "invocation_id": str(pending.invocation_id),
                "request_sha256": str(pending.request_sha256),
                "request_payload": pending.request_payload,
                "parent_step_sha256": str(getattr(pending, "parent_step_sha256", "") or ""),
            },
        )

    def _drive(self, *, message: str, runtime: Any, cognition_port: ReceiptCognitionPort,
               action_port: ReceiptActionPort, handle: LoopHandle | None = None,
               semantic_verifiers=None, capabilities=None, continuation_context=None, raw_message_bytes: bytes | None = None, integrated_processing_packet: Any | None = None) -> LoopOutcome:
        resume_turn = None
        if handle is not None:
            head = self.journal.current(handle)
            if str(head.state.get("original_directive_sha256") or "") != hashlib.sha256(message.encode("utf-8")).hexdigest():
                raise JournalIntegrityError("opaque handle directive binding mismatch")
            resume_turn = self._load_snapshot(handle.turn_id, str(head.state.get("snapshot_sha256") or ""))
        else:
            # Coordinator owns ingress. This creates the canonical turn before any
            # external cognition/action is requested, so every invocation can bind
            # to an already-verified causal parent.
            resume_turn = runtime.ingress(
                message, capabilities=capabilities, continuation_context=continuation_context or {},
                raw_message_bytes=raw_message_bytes, integrated_processing_packet=integrated_processing_packet,
            )
            snapshot_sha = self._save_snapshot(resume_turn)
            handle, _ = self._ensure_ingress(resume_turn, snapshot_sha=snapshot_sha)

        parent_getter = lambda: self.journal.current(handle).causal_head_sha256
        generator = cognition_port.candidate_generator(parent_step_sha256_getter=parent_getter)
        executor = action_port.executor(parent_step_sha256_getter=parent_getter)
        try:
            result = runtime.run_turn(
                message,
                capabilities=capabilities,
                host_executor=executor,
                candidate_generator=generator,
                semantic_verifiers=semantic_verifiers,
                host_unavailable="raise",
                resume_turn=resume_turn,
                defer_release=True,
            )
        except CognitionPending as exc:
            turn = self._snapshot_turn_from_runtime(runtime, resume_turn)
            return self._pending_outcome(runtime=runtime, turn=turn, kind="cognition", pending=exc.pending, prior_handle=handle)
        except ActionPending as exc:
            turn = self._snapshot_turn_from_runtime(runtime, resume_turn)
            return self._pending_outcome(runtime=runtime, turn=turn, kind="action", pending=exc.pending, prior_handle=handle)

        turn = result["turn"]
        snapshot_sha = self._save_snapshot(turn)
        use_handle, head = self._ensure_ingress(turn, snapshot_sha=snapshot_sha)
        if handle is not None:
            use_handle = handle; head = self.journal.current(handle)
        generation_metadata = dict(result["generation"].metadata or {})
        verification_summary = dict(result.get("verification") or {})
        verification_satisfied = bool(
            verification_summary.get("all_applicable_passed") is True
            and not bool(verification_summary.get("frontier_closure_claim_unproven"))
        )
        finalization_prep = dict(result.get("finalization_prep") or {})
        objective_satisfied = bool(
            finalization_prep.get("user_objective_satisfied") is True
            and verification_summary.get("requirement_response_coverage_ok", True) is True
            and not generation_metadata.get("truth_candidate_suppressed")
        )
        execution_open_obligations = tuple(finalization_prep.get("open_execution_obligation_ids") or ())
        if head.phase != "VERIFY":
            candidate_sha = sha256_text(result["generation"].candidate_body)
            requirement_sha = str((turn.active_requirement_contract or turn.requirement_contract or {}).get("contract_sha256") or "")
            verification_receipt = VerificationReceipt.issue(
                turn_id=turn.release_turn_id,
                request_sha256=str(generation_metadata.get("request_sha256") or ""),
                candidate_sha256=candidate_sha, requirement_contract_sha256=requirement_sha,
                verification_summary=verification_summary,
                parent_causal_head_sha256=head.causal_head_sha256,
                verdict="PASSED" if verification_satisfied else "FAILED",
            )
            state=dict(head.state); state.update({
                "snapshot_sha256":snapshot_sha,
                "candidate_sha256":candidate_sha,
                "verification_state":"passed" if verification_satisfied else "open",
                "verification_receipt_sha256":verification_receipt.receipt_sha256,
                "requirements_state":"SATISFIED" if objective_satisfied else "ACTIVE",
                "observation_state":"COMPLETED",
                "authority_model":"user_directive_truth_kernel",
                "self_authorized":False,
                "open_obligations": (
                    ([] if verification_satisfied else ["semantic_verification"])
                    + ([] if objective_satisfied else ["user_objective_unsatisfied"])
                    + list(execution_open_obligations)
                ),
                "pending_kind":"", "pending_invocation_id":"", "pending_request_sha256":"",
            })
            head=self._append(head=head, phase="VERIFY", state=state, transition={
                "kind":"verification_passed" if verification_satisfied else "verification_open_response_allowed",
                "verification_receipt": verification_receipt.as_mapping(),
                "verification_receipt_sha256": verification_receipt.receipt_sha256,
                "candidate_preserved_with_truth_annotation": bool(generation_metadata.get("unverified_candidate_preserved")),
                "candidate_suppressed_for_truth_or_nonsense": bool(generation_metadata.get("truth_candidate_suppressed")),
            })
        response_sha=sha256_text(result["generation"].candidate_body)
        requirement_sha=str((turn.active_requirement_contract or turn.requirement_contract or {}).get("contract_sha256") or "")
        observation_sha=_json_sha(list(turn.host_observations or ())) if turn.host_observations else ""

        # One finality authority: the same full canonical finalizer used by explicit
        # release tooling must approve a final result before the thin integrity permit
        # can carry SOLVED semantics.  This closes the former causal-loop bypass.
        strong_finalizer_receipt = runtime.finalize_canonical_turn(
            turn.release_turn_id,
            ingress_verified=bool(turn.release_ingress_receipt_id),
            control_checkpoint_id=str(runtime.control_checkpoint_id or ""),
            final_response_sha256=response_sha,
            expected_response_sha256=response_sha,
            expected_previous_finalizer_receipt_id=(turn.expected_previous_finalizer_receipt_id or None),
            requirement_manifest=generation_metadata,
            final_response_text=result["generation"].candidate_body,
        )
        if strong_finalizer_receipt.get("final_response_allowed") is not True:
            objective_satisfied = False
        terminal_semantics = "SOLVED" if objective_satisfied else "INCOMPLETE"
        state=dict(head.state)
        state["strong_finalizer_receipt_id"] = str(strong_finalizer_receipt.get("receipt_id") or "")
        state["strong_finalizer_application_state"] = str(strong_finalizer_receipt.get("application_state") or "")
        head=self._append(head=head, phase="FINALIZE_PREPARE", state=state, transition={
            "kind":"prepare_finalization",
            "terminal_semantics": terminal_semantics,
            "strong_finalizer_receipt_id": str(strong_finalizer_receipt.get("receipt_id") or ""),
            "strong_finalizer_final_response_allowed": strong_finalizer_receipt.get("final_response_allowed") is True,
        })
        permit=runtime.canonical_finalizer.prepare(
            turn_id=turn.release_turn_id,
            response_sha256=response_sha,
            loop_chain_sha256=head.causal_head_sha256,
            requirement_contract_sha256=requirement_sha,
            observation_chain_sha256=observation_sha,
            terminal_semantics=terminal_semantics,
            strong_finalizer_receipt_id=str(strong_finalizer_receipt.get("receipt_id") or ""),
        )
        # Finalization permits are valid only for the exact verified journal head
        # at PREPARE time. Keep the journal's per-turn lock across the final head
        # check, ResponseSink publication, and RELEASE transition append so no hidden
        # journal mutation can slip between validation and the physical effect.
        verified_prepare_head = self.journal.current(use_handle)
        if verified_prepare_head.causal_head_sha256 != permit.loop_chain_sha256:
            raise JournalIntegrityError("finalization permit no longer matches verified causal head")
        release_state=dict(head.state); release_state.update({"terminal":False,"terminal_semantics":"","candidate_sha256":response_sha})
        released, head = self.journal.perform_effect_transition(
            turn_id=head.turn_id, expected_parent_head=permit.loop_chain_sha256, phase="RELEASE",
            state=release_state,
            effect=lambda: runtime.release(
                turn, result["generation"].candidate_body, producer=result["generation"].producer_id,
                finalization_permit=permit, expected_loop_chain_sha256=permit.loop_chain_sha256,
            ),
            transition_factory=lambda released_response: {
                "kind":"release", "permit_sha256":permit.permit_sha256,
                "release_integrity_receipt_id":released_response.integrity_receipt_id,
            },
        )
        commit=runtime.canonical_finalizer.commit_permit(
            permit=permit, release_receipt=released,
            expected_loop_chain_sha256=permit.loop_chain_sha256,
        )
        state=dict(head.state); state.update({
            "terminal":True,
            "terminal_semantics":terminal_semantics,
            "open_obligations": (
                ([] if verification_satisfied else ["semantic_verification"])
                + ([] if objective_satisfied else ["user_objective_unsatisfied"])
                + list(execution_open_obligations)
            ),
        })
        terminal_phase = "COMMIT" if objective_satisfied else "INCOMPLETE"
        # The response may finish while the user's task remains active. The
        # production lane consumes this distinction and prepares further work.
        state['task_terminal']=bool(objective_satisfied)
        state['continuation_required']=not objective_satisfied
        head=self._append(head=head, phase=terminal_phase, state=state, transition={
            "kind":"finalization_commit" if objective_satisfied else "incomplete_response_commit",
            "commit_sha256":commit["commit_sha256"],
            "response_released":True,
            "user_objective_satisfied":objective_satisfied,
            "verification_satisfied":verification_satisfied,
        })
        checkpoint = self.journal.issue_checkpoint(head.turn_id)
        return LoopOutcome(
            "COMPLETED" if objective_satisfied else "INCOMPLETE",
            use_handle, self._state_from_head(head), {},
            released=released, finalization_commit=commit, checkpoint=asdict(checkpoint),
        )

    def run_until_blocked(self, *, message: str, runtime: Any, cognition_port: ReceiptCognitionPort,
                          action_port: ReceiptActionPort, semantic_verifiers=None, capabilities=None, continuation_context=None,
                          raw_message_bytes: bytes | None = None, integrated_processing_packet: Any | None = None) -> LoopOutcome:
        return self._drive(message=message, runtime=runtime, cognition_port=cognition_port, action_port=action_port,
                           semantic_verifiers=semantic_verifiers, capabilities=capabilities, continuation_context=continuation_context,
                           raw_message_bytes=raw_message_bytes, integrated_processing_packet=integrated_processing_packet)

    def resume(self, *, handle: LoopHandle, message: str, runtime: Any,
               cognition_port: ReceiptCognitionPort, action_port: ReceiptActionPort,
               observed_result: dict[str, Any], semantic_verifiers=None, capabilities=None, continuation_context=None,
               raw_message_bytes: bytes | None = None, integrated_processing_packet: Any | None = None) -> LoopOutcome:
        head=self.journal.current(handle)
        state=self._state_from_head(head)
        kind=str(observed_result.get("kind") or "")
        invocation_id=str(observed_result.get("invocation_id") or "")
        request_sha=str(observed_result.get("request_sha256") or "")
        if kind != state.pending_kind or invocation_id != state.pending_invocation_id or request_sha != state.pending_request_sha256:
            raise JournalIntegrityError("submitted receipt does not match the exact pending invocation")
        if kind == "cognition":
            body=str(observed_result.get("body") or "")
            if not body.strip():
                raise ValueError("cognition body must be non-empty")
            parent_step = str(head.state.get("pending_parent_step_sha256") or "")
            origin_ref = str(observed_result.get("origin_ref") or "host:cognition")
            cognition_port.ledger.record(
                request_sha=request_sha, body=body, note="causal_loop_resume",
                invocation_id=invocation_id, parent_step_sha256=parent_step, origin_ref=origin_ref,
            )
            invocation = CognitiveInvocation(
                invocation_id=invocation_id, request_sha256=request_sha, parent_step_sha256=parent_step,
                request_payload=dict(observed_result.get("request_payload") or {}),
            )
            completed = cognition_port.invoke(invocation)
            if not isinstance(completed, CompletedInvocation):
                raise JournalIntegrityError("recorded cognition receipt did not become consumable")
            cognition_receipt = completed.receipt
            new_state=dict(head.state); new_state.update({"pending_kind":"","pending_invocation_id":"","pending_request_sha256":"","pending_parent_step_sha256":""})
            head=self._append(head=head, phase="COGNITION", state=new_state, transition={
                "kind":"cognition_receipt", "cognition_receipt": asdict(cognition_receipt),
                "cognition_receipt_sha256": cognition_receipt.receipt_sha256,
            })
        elif kind == "action":
            parent_step = str(head.state.get("pending_parent_step_sha256") or "")
            origin_ref = str(observed_result.get("origin_ref") or "host:action")
            row = action_port.ledger.record(
                request_sha256=request_sha, invocation_id=invocation_id,
                result=observed_result.get("result"), success=observed_result.get("success"),
                executor_id=str(observed_result.get("executor_id") or "host"),
                parent_step_sha256=parent_step, origin_ref=origin_ref,
                host_call_observed=observed_result.get("host_call_observed") is True,
            )
            action_invocation = ActionInvocation(
                invocation_id=invocation_id, request_sha256=request_sha, parent_step_sha256=parent_step,
                request_payload=dict(observed_result.get("request_payload") or {}),
            )
            completed_action = action_port.execute(action_invocation)
            if not isinstance(completed_action, CompletedAction):
                raise JournalIntegrityError("recorded action receipt did not become consumable")
            new_state=dict(head.state); new_state.update({
                "pending_kind":"", "pending_invocation_id":"", "pending_request_sha256":"",
                "pending_parent_step_sha256":"", "observation_state":"COMPLETED",
            })
            head=self._append(head=head, phase="OBSERVATION", state=new_state, transition={
                "kind":"action_observation",
                "action_receipt": asdict(completed_action.action_receipt) if completed_action.action_receipt else {},
                "action_receipt_sha256": str(row.get("action_receipt", {}).get("receipt_sha256") or ""),
                "observation_receipt": asdict(completed_action.receipt),
                "observation_receipt_sha256": completed_action.receipt.receipt_sha256,
            })
        else:
            raise ValueError("observed_result.kind must be cognition or action")
        return self._drive(message=message, runtime=runtime, cognition_port=cognition_port, action_port=action_port, handle=handle, semantic_verifiers=semantic_verifiers, capabilities=capabilities, continuation_context=continuation_context, raw_message_bytes=raw_message_bytes, integrated_processing_packet=integrated_processing_packet)
