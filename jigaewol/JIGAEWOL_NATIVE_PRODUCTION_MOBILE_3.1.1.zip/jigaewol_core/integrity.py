from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "CANONICAL_ARTIFACT.json"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _verify_once(data: dict[str, Any]) -> dict[str, Any]:
    failures = []
    checked = 0
    members=tuple(data.get('active_files') or ())
    if not members or data.get('active_file_count',len(members))!=len(members):
        failures.append({'path':'CANONICAL_ARTIFACT.json','error':'empty_or_inconsistent_membership'})
    observed_rows=[]
    seen=set()
    for row in members:
        rel = str(row.get("path") or "")
        expected = str(row.get("sha256") or "")
        if rel in seen:failures.append({'path':rel,'error':'duplicate_manifest_member'})
        seen.add(rel)
        path = (ROOT / rel).resolve()
        if ROOT.resolve() not in path.parents:
            failures.append({"path": rel, "error": "path_escape"})
            continue
        if not path.is_file():
            failures.append({"path": rel, "error": "missing"})
            continue
        actual = sha256_file(path)
        actual_size=path.stat().st_size
        observed_rows.append({'path':rel,'sha256':actual,'size':actual_size})
        checked += 1
        if row.get('size')!=actual_size:failures.append({'path':rel,'error':'size_mismatch'})
        if actual != expected:
            failures.append({"path": rel, "error": "sha256_mismatch", "expected": expected, "actual": actual})
    observed_digest=hashlib.sha256(json.dumps(observed_rows,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if observed_digest!=data.get('content_set_sha256') and not any(x['error'] in {'missing','sha256_mismatch','size_mismatch'} for x in failures):
        failures.append({'path':'CANONICAL_ARTIFACT.json','error':'content_set_digest_mismatch'})
    return {
        "runtime_identity": data.get("runtime_identity"),
        "checked": checked,
        "expected_file_count": len(data.get("active_files", ())),
        "ok": not failures and checked == len(data.get("active_files", ())),
        "failures": tuple(failures),
        "content_set_sha256": observed_digest,
    }


def verify_active_artifact(
    *, raise_on_failure: bool = True, stability_retries: int = 60, retry_delay_seconds: float = 0.05
) -> dict[str, Any]:
    """Verify the sealed runtime, tolerating only demonstrably transient read races.

    The gate never accepts a persistent mismatch. A missing/hash-mismatched file is
    re-read within a short I/O-stability window because live checkpoint export can briefly expose
    a truncate/write window. This window is transport hygiene only; exhausting it never
    becomes evidence that the user goal or a capability is impossible. Path escapes and any mismatch surviving the bound still
    fail closed.
    """
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    attempts = 0
    first_failures: tuple[dict[str, Any], ...] = ()
    max_attempts = max(1, int(stability_retries) + 1)
    while attempts < max_attempts:
        attempts += 1
        result = _verify_once(data)
        if attempts == 1:
            first_failures = tuple(result["failures"])
        if result["ok"]:
            result = {
                **result,
                "stability_attempts": attempts,
                "transient_race_recovered": attempts > 1,
                "initial_failure_count": len(first_failures),
            }
            return result
        retryable = bool(result["failures"]) and all(
            row.get("error") in {"missing", "sha256_mismatch", "size_mismatch"} for row in result["failures"]
        )
        if not retryable or attempts >= max_attempts:
            break
        time.sleep(max(0.0, float(retry_delay_seconds)))

    result = {
        **result,
        "stability_attempts": attempts,
        "transient_race_recovered": False,
        "initial_failure_count": len(first_failures),
    }
    if raise_on_failure:
        raise RuntimeError(f"active artifact integrity mismatch: {list(result['failures'])[:4]}")
    return result
