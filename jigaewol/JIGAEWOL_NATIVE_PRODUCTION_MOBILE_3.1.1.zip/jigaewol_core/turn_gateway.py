from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Mapping

try:  # POSIX in the current runtime; guarded for portability.
    import fcntl  # type: ignore
except Exception:  # pragma: no cover - non-POSIX fallback
    fcntl = None


def _sha_text(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _canonical_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


class TurnGateway:
    """Local, zero-cost authenticated turn sequencer for canonical ingress.

    This gateway proves continuity only for turns that pass through this local
    sequencer. It does not claim access to an opaque host application's internal
    turn counter. Each issued envelope is message-bound, scope-bound, HMAC-signed,
    monotonically sequenced, and chained to the prior gateway token.
    """

    version = "jigaewol_local_turn_gateway_v1"

    def __init__(self, root: str | Path, *, user_id: str, project_id: str, session_id: str) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.user_id = str(user_id)
        self.project_id = str(project_id)
        self.session_id = str(session_id)
        self.secret_path = self.root / "gateway_secret.bin"
        self.ledger_path = self.root / "gateway_turns.jsonl"
        self.lock_path = self.root / ".gateway.lock"
        self.ledger_path.touch(exist_ok=True)
        self._ensure_secret()

    def _ensure_secret(self) -> None:
        if self.secret_path.exists():
            return
        data = secrets.token_bytes(32)
        try:
            fd = os.open(self.secret_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            return
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())

    def _secret(self) -> bytes:
        data = self.secret_path.read_bytes()
        if len(data) < 32:
            raise RuntimeError("gateway secret is invalid")
        return data

    @contextmanager
    def _lock(self):
        from jigaewol_components.file_lock import exclusive_lock
        with exclusive_lock(self.lock_path) as status:
            if not status['mutual_exclusion_proven']:
                raise RuntimeError('use an observed native or private-worker transaction lock')
            yield

    def _body(self, row: Mapping[str, Any]) -> dict[str, Any]:
        return {
            "gateway_version": str(row.get("gateway_version") or ""),
            "gateway_turn_id": str(row.get("gateway_turn_id") or ""),
            "gateway_sequence": int(row.get("gateway_sequence") or 0),
            "user_id": str(row.get("user_id") or ""),
            "project_id": str(row.get("project_id") or ""),
            "session_id": str(row.get("session_id") or ""),
            "message_sha256": str(row.get("message_sha256") or ""),
            "previous_gateway_token_sha256": str(row.get("previous_gateway_token_sha256") or ""),
            "issued_at": float(row.get("issued_at") or 0.0),
        }

    def _token(self, body: Mapping[str, Any]) -> str:
        return hmac.new(self._secret(), _canonical_bytes(body), hashlib.sha256).hexdigest()

    @property
    def gateway_scope_sha256(self) -> str:
        """Stable digest for the local gateway identity scope.

        Finalizer receipts are global to the state root, while a gateway ledger may be
        intentionally restarted for a corrected user/project/session scope. Binding
        terminal receipts to this digest prevents an older scope's sequence from being
        mistaken for the current scope's terminal history.
        """
        payload = {
            "user_id": self.user_id,
            "project_id": self.project_id,
            "session_id": self.session_id,
        }
        return hashlib.sha256(_canonical_bytes(payload)).hexdigest()

    def _verified_history(self) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        previous_token_sha256 = ""
        expected_sequence = 1
        for line_number, raw in enumerate(self.ledger_path.read_text(encoding="utf-8").splitlines(), start=1):
            if not raw.strip():
                continue
            try:
                row = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"gateway ledger unreadable at line {line_number}") from exc
            if not isinstance(row, dict):
                raise RuntimeError(f"gateway ledger contains non-object at line {line_number}")
            body = self._body(row)
            # Historical signed turns may come from an earlier runtime label.
            # The version string is part of the HMAC-signed body, so integrity is
            # proven by the signature instead of forcing old state to impersonate
            # the current runtime version. New turns are always issued with self.version.
            if not body["gateway_version"]:
                raise RuntimeError("gateway version missing")
            if (body["user_id"], body["project_id"], body["session_id"]) != (
                self.user_id,
                self.project_id,
                self.session_id,
            ):
                raise RuntimeError("gateway scope mismatch")
            if body["gateway_sequence"] != expected_sequence:
                raise RuntimeError("gateway sequence discontinuity")
            if body["previous_gateway_token_sha256"] != previous_token_sha256:
                raise RuntimeError("gateway predecessor token mismatch")
            token = str(row.get("gateway_token") or "")
            if not token or not hmac.compare_digest(token, self._token(body)):
                raise RuntimeError("gateway token signature mismatch")
            token_sha256 = _sha_text(token)
            if str(row.get("gateway_token_sha256") or "") != token_sha256:
                raise RuntimeError("gateway token digest mismatch")
            previous_token_sha256 = token_sha256
            expected_sequence += 1
            rows.append(row)
        return rows

    def verify_ledger(self) -> bool:
        try:
            self._verified_history()
            return True
        except (OSError, RuntimeError, ValueError):
            return False

    def latest_verified_turn(self) -> dict[str, Any]:
        with self._lock():
            history = self._verified_history()
            return dict(history[-1]) if history else {}

    def assert_previous_finalized(self, finalizer_root: str | Path) -> dict[str, Any]:
        """Fail closed unless the latest issued gateway turn is applied_full.

        The finalizer ledger is independently hash-chain verified before its
        latest applied_full receipt is trusted. This does not prove opaque host
        turns; it closes the local gateway admission loop so an issued turn
        cannot be silently skipped before the next local gateway turn.
        """
        from .canonical_finalizer import CanonicalTurnFinalizer

        with self._lock():
            history = self._verified_history()
            if not history:
                return {
                    "gateway_sequence": 0,
                    "gateway_turn_id": "",
                    "finalizer_receipt_id": "",
                    "previous_gateway_finalized": True,
                    "state": "gateway_genesis",
                }
            latest_gateway = history[-1]
            finalizer = CanonicalTurnFinalizer(Path(finalizer_root))
            latest_finalizer = finalizer.latest_gateway_terminal_receipt(gateway_scope_sha256=self.gateway_scope_sha256)
            if not latest_finalizer:
                legacy = finalizer.latest_gateway_terminal_receipt()
                if (
                    legacy
                    and not str(legacy.get("gateway_scope_sha256") or "").strip()
                    and str(legacy.get("gateway_turn_id") or "") == str(latest_gateway.get("gateway_turn_id") or "")
                    and int(legacy.get("gateway_sequence") or 0) == int(latest_gateway.get("gateway_sequence") or 0)
                    and str(legacy.get("gateway_token_sha256") or "") == str(latest_gateway.get("gateway_token_sha256") or "")
                ):
                    latest_finalizer = legacy
            exact_gateway_match = bool(
                latest_finalizer
                and latest_finalizer.get("gateway_required") is True
                and str(latest_finalizer.get("gateway_turn_id") or "")
                    == str(latest_gateway.get("gateway_turn_id") or "")
                and int(latest_finalizer.get("gateway_sequence") or 0)
                    == int(latest_gateway.get("gateway_sequence") or 0)
                and str(latest_finalizer.get("gateway_token_sha256") or "")
                    == str(latest_gateway.get("gateway_token_sha256") or "")
            )
            applied_full = bool(
                exact_gateway_match
                and latest_finalizer.get("application_state") == "applied_full"
                and latest_finalizer.get("final_response_allowed") is True
            )
            recovered_incomplete = bool(
                exact_gateway_match
                and latest_finalizer.get("application_state") == "recovered_incomplete"
                and latest_finalizer.get("gateway_recovery") is True
                and latest_finalizer.get("gateway_terminal") is True
            )
            aborted_before_release = bool(
                exact_gateway_match
                and latest_finalizer.get("application_state") == "aborted_before_release"
                and latest_finalizer.get("gateway_abort") is True
                and latest_finalizer.get("gateway_terminal") is True
            )
            superseded_unfinalized = bool(
                exact_gateway_match
                and latest_finalizer.get("application_state") == "superseded_unfinalized"
                and latest_finalizer.get("gateway_superseded") is True
                and latest_finalizer.get("gateway_terminal") is True
            )
            continued_unfinalized = bool(
                exact_gateway_match
                and latest_finalizer.get("application_state") == "continued_unfinalized"
                and latest_finalizer.get("gateway_continued_unfinalized") is True
                and latest_finalizer.get("gateway_terminal") is True
            )
            previous_open_unfinalized = not (
                applied_full or recovered_incomplete or aborted_before_release
                or superseded_unfinalized or continued_unfinalized
            )
            return {
                "gateway_sequence": int(latest_gateway["gateway_sequence"]),
                "gateway_turn_id": str(latest_gateway["gateway_turn_id"]),
                "gateway_token_sha256": str(latest_gateway["gateway_token_sha256"]),
                "finalizer_receipt_id": str(latest_finalizer.get("receipt_id") or ""),
                "finalizer_receipt_sha256": str(latest_finalizer.get("receipt_sha256") or ""),
                "previous_gateway_finalized": applied_full,
                "previous_gateway_recovery_closed": recovered_incomplete,
                "previous_gateway_aborted_before_release": aborted_before_release,
                "previous_gateway_superseded_unfinalized": superseded_unfinalized,
                "previous_gateway_continued_unfinalized": continued_unfinalized,
                "previous_gateway_open_unfinalized": previous_open_unfinalized,
                "state": (
                    "previous_gateway_applied_full" if applied_full
                    else "previous_gateway_recovered_incomplete" if recovered_incomplete
                    else "previous_gateway_aborted_before_release" if aborted_before_release
                    else "previous_gateway_superseded_unfinalized" if superseded_unfinalized
                    else "previous_gateway_continued_unfinalized" if continued_unfinalized
                    else "previous_gateway_open_unfinalized_observed"
                ),
            }


    def _reconcile_terminal_gap(
        self,
        finalizer_root: str | Path,
        *,
        history: list[dict[str, Any]],
        target_sequence: int,
        origin_ref: str,
        successor_message_sha256: str,
    ) -> tuple[int, ...]:
        """Terminal-close missing gateway sequences in order without cancelling work.

        A prior runtime failure can issue multiple authenticated gateway envelopes before
        their matching terminal bookkeeping receipts are written.  The canonical
        finalizer intentionally rejects sequence jumps, so a later user message used to
        deadlock forever on the newest unfinalized envelope.  Repair the *bookkeeping*
        chain by replaying every missing gateway sequence in order as
        ``continued_unfinalized``.  This preserves each unfinished user objective and
        never upgrades it to executed/finalized work.
        """
        from .canonical_finalizer import CanonicalTurnFinalizer

        finalizer = CanonicalTurnFinalizer(Path(finalizer_root))
        terminal = finalizer.latest_gateway_terminal_receipt(
            gateway_scope_sha256=self.gateway_scope_sha256
        )
        terminal_sequence = int(terminal.get("gateway_sequence") or 0) if terminal else 0
        target = int(target_sequence or 0)
        if target <= terminal_sequence:
            return ()

        by_sequence = {int(row.get("gateway_sequence") or 0): row for row in history}
        reconciled: list[int] = []
        for sequence in range(terminal_sequence + 1, target + 1):
            row = by_sequence.get(sequence)
            if row is None:
                raise RuntimeError(
                    f"gateway ledger is missing sequence {sequence} required for terminal reconciliation"
                )
            finalizer.continue_unfinalized_gateway_turn(
                gateway_turn_id=str(row.get("gateway_turn_id") or ""),
                gateway_sequence=sequence,
                gateway_token_sha256=str(row.get("gateway_token_sha256") or ""),
                reason=(
                    "reconciled previously issued gateway envelope after interrupted "
                    f"terminal bookkeeping; successor_message_sha256={successor_message_sha256}"
                ),
                continuation_origin_ref=str(origin_ref),
                gateway_scope_sha256=self.gateway_scope_sha256,
            )
            reconciled.append(sequence)
        return tuple(reconciled)

    def admit_new_message(self, finalizer_root: str | Path, *, message: str, origin_ref: str) -> dict[str, Any]:
        """Prioritize a newer exact user message over an unfinalized local turn.

        Same-message retries never create a duplicate sequence. A distinct message
        advances the exact-message gateway sequence without treating the older unfinished
        user task as cancelled. Cancellation is a separate explicit user action.
        """
        if not isinstance(message, str) or not message.strip():
            raise ValueError("gateway message must be nonempty text")
        from .canonical_finalizer import CanonicalTurnFinalizer

        with self._lock():
            history = self._verified_history()
        latest = dict(history[-1]) if history else {}
        if not latest:
            return {"state": "gateway_genesis", "action": "issue_new", "superseded": False, "reconciled_gateway_sequences": ()}
        finalizer = CanonicalTurnFinalizer(Path(finalizer_root))
        new_sha = _sha_text(message)
        same_message_retry = str(latest.get("message_sha256") or "") == new_sha
        # A same-message retry keeps the newest envelope pending, but any older
        # interrupted envelopes still have to be terminally reconciled in order.
        reconcile_target = int(latest.get("gateway_sequence") or 0) - (1 if same_message_retry else 0)
        reconciled_gateway_sequences = self._reconcile_terminal_gap(
            finalizer_root,
            history=history,
            target_sequence=max(0, reconcile_target),
            origin_ref=origin_ref,
            successor_message_sha256=new_sha,
        )
        terminal = finalizer.latest_gateway_terminal_receipt(gateway_scope_sha256=self.gateway_scope_sha256)
        if not terminal:
            legacy = finalizer.latest_gateway_terminal_receipt()
            if (
                legacy
                and not str(legacy.get("gateway_scope_sha256") or "").strip()
                and str(legacy.get("gateway_turn_id") or "") == str(latest.get("gateway_turn_id") or "")
                and int(legacy.get("gateway_sequence") or 0) == int(latest.get("gateway_sequence") or 0)
                and str(legacy.get("gateway_token_sha256") or "") == str(latest.get("gateway_token_sha256") or "")
            ):
                terminal = legacy
        exact_terminal = bool(
            terminal
            and str(terminal.get("gateway_turn_id") or "") == str(latest.get("gateway_turn_id") or "")
            and int(terminal.get("gateway_sequence") or 0) == int(latest.get("gateway_sequence") or 0)
            and str(terminal.get("gateway_token_sha256") or "") == str(latest.get("gateway_token_sha256") or "")
        )
        if exact_terminal:
            proof = self.assert_previous_finalized(finalizer_root)
            return {
                **proof,
                "action": "issue_new",
                "superseded": False,
                "reconciled_gateway_sequences": reconciled_gateway_sequences,
                "prior_user_work_preserved": bool(reconciled_gateway_sequences) or proof.get("previous_gateway_continued_unfinalized") is True,
            }
        if str(latest.get("message_sha256") or "") == new_sha:
            return {
                "state": "duplicate_pending_message",
                "action": "reuse_pending",
                "superseded": False,
                "gateway_sequence": int(latest.get("gateway_sequence") or 0),
                "gateway_turn_id": str(latest.get("gateway_turn_id") or ""),
                "message_sha256": new_sha,
                "reconciled_gateway_sequences": reconciled_gateway_sequences,
            }
        from jigaewol_components.source_authority import destructive_goal_change_authorized
        if destructive_goal_change_authorized(message):
            receipt = finalizer.supersede_unfinalized_gateway_turn(
                gateway_turn_id=str(latest.get("gateway_turn_id") or ""),
                gateway_sequence=int(latest.get("gateway_sequence") or 0),
                gateway_token_sha256=str(latest.get("gateway_token_sha256") or ""),
                reason=f"user explicitly cancelled/replaced prior unfinished work; successor_message_sha256={new_sha}",
                supersede_origin_ref=str(origin_ref),
                gateway_scope_sha256=self.gateway_scope_sha256,
            )
            return {
                "state": "previous_gateway_cancelled_by_user",
                "action": "issue_new",
                "superseded": True,
                "superseded_gateway_turn_id": str(latest.get("gateway_turn_id") or ""),
                "superseded_gateway_sequence": int(latest.get("gateway_sequence") or 0),
                "supersede_receipt_id": str(receipt.get("receipt_id") or ""),
                "successor_message_sha256": new_sha,
                "host_release_status": "unproven",
                "reconciled_gateway_sequences": reconciled_gateway_sequences,
            }

        # A later message is not cancellation. Close only the old ingress token so
        # exact-message sequencing can advance; the old user task and pending host
        # actions remain alive.
        receipt = finalizer.continue_unfinalized_gateway_turn(
            gateway_turn_id=str(latest.get("gateway_turn_id") or ""),
            gateway_sequence=int(latest.get("gateway_sequence") or 0),
            gateway_token_sha256=str(latest.get("gateway_token_sha256") or ""),
            reason=f"new exact user message continued while prior work remains open; successor_message_sha256={new_sha}",
            continuation_origin_ref=str(origin_ref),
            gateway_scope_sha256=self.gateway_scope_sha256,
        )
        return {
            "state": "previous_gateway_continued_unfinalized",
            "action": "issue_new",
            "superseded": False,
            "continued_unfinalized": True,
            "prior_user_work_preserved": True,
            "previous_gateway_turn_id": str(latest.get("gateway_turn_id") or ""),
            "previous_gateway_sequence": int(latest.get("gateway_sequence") or 0),
            "continuation_receipt_id": str(receipt.get("receipt_id") or ""),
            "successor_message_sha256": new_sha,
            "host_release_status": "prior_work_still_open",
            "reconciled_gateway_sequences": reconciled_gateway_sequences,
        }

    def pending_envelope_for_message(self, message: str) -> dict[str, Any]:
        """Return the newest still-issued envelope when the exact source is retried.

        This method never creates a sequence.  The caller is responsible for using it
        only after admission has established that the latest envelope is the pending
        exact-message turn.
        """
        if not isinstance(message, str) or not message.strip():
            raise ValueError("gateway message must be nonempty text")
        with self._lock():
            history = self._verified_history()
        if not history:
            raise RuntimeError("no pending gateway envelope exists")
        latest = dict(history[-1])
        if str(latest.get("message_sha256") or "") != _sha_text(message):
            raise RuntimeError("latest gateway envelope does not match exact message")
        return latest

    def issue(self, message: str) -> dict[str, Any]:
        if not isinstance(message, str) or not message.strip():
            raise ValueError("gateway message must be nonempty text")
        with self._lock():
            history = self._verified_history()
            previous = history[-1] if history else {}
            sequence = len(history) + 1
            body = {
                "gateway_version": self.version,
                "gateway_turn_id": f"gateway_turn_{sequence:08d}_{uuid.uuid4().hex[:12]}",
                "gateway_sequence": sequence,
                "user_id": self.user_id,
                "project_id": self.project_id,
                "session_id": self.session_id,
                "message_sha256": _sha_text(message),
                "previous_gateway_token_sha256": str(previous.get("gateway_token_sha256") or ""),
                "issued_at": time.time(),
            }
            token = self._token(body)
            row = {
                **body,
                "gateway_token": token,
                "gateway_token_sha256": _sha_text(token),
            }
            with self.ledger_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
                fh.flush()
                os.fsync(fh.fileno())
            return dict(row)

    def verify_for_ingress(self, envelope: Mapping[str, Any], *, message: str) -> dict[str, Any]:
        if not isinstance(message, str) or not message.strip():
            raise PermissionError("gateway verification requires nonempty message")
        with self._lock():
            history = self._verified_history()
            if not history:
                raise PermissionError("gateway has no issued turn")
            candidate = dict(envelope or {})
            gateway_turn_id = str(candidate.get("gateway_turn_id") or "")
            matches = [row for row in history if str(row.get("gateway_turn_id") or "") == gateway_turn_id]
            if len(matches) != 1:
                raise PermissionError("gateway envelope is not present in the issued ledger")
            issued = matches[0]
            if candidate != issued:
                raise PermissionError("gateway envelope does not match issued immutable record")
            if issued is not history[-1]:
                raise PermissionError("gateway envelope is not the latest issued turn")
            if str(issued.get("message_sha256") or "") != _sha_text(message):
                raise PermissionError("gateway envelope message hash mismatch")
            return {
                "gateway_verified": True,
                "gateway_turn_id": str(issued["gateway_turn_id"]),
                "gateway_sequence": int(issued["gateway_sequence"]),
                "gateway_token_sha256": str(issued["gateway_token_sha256"]),
                "previous_gateway_token_sha256": str(issued.get("previous_gateway_token_sha256") or ""),
                "message_sha256": str(issued["message_sha256"]),
                "gateway_turn_sequence_proven": True,
                "gateway_gap_absence_proven": True,
                "gateway_scope_sha256": self.gateway_scope_sha256,
                "proof_scope": "local_gateway_issued_sequence",
                "host_internal_turn_sequence_proven": False,
            }
