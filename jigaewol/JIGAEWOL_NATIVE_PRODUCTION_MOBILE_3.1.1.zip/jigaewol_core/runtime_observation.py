from __future__ import annotations

from dataclasses import replace
from jigaewol_components.image_quality_governor import ImageQualityGovernor
from typing import Any, TYPE_CHECKING

from jigaewol_components.representation_programs import RepresentationPrograms
from jigaewol_components.unified_user_intent import reference_for_sha
from .action_port import RuntimeActionRequest, work_request_sha256
from .execution_truth import classify_execution_result
from .runtime_helpers import _model_observation

if TYPE_CHECKING:
    from .runtime import CoreTurn


class CoreRuntimeObservationMixin:
    """Host observation assimilation, isolated from the coordinator."""
    @staticmethod
    def _bind_image_asset(action, result):
        if action.operation not in {'media:image_generate','media:image_review'} or not isinstance(result,dict):
            return result
        from pathlib import Path
        import hashlib
        result = dict(result)
        if action.operation == 'media:image_generate' and result.get('success') is True:
            asset = result.get('generated_ref') or result.get('artifact') or result.get('url')
            if not isinstance(asset,str) or not asset:
                return {**result,'success':False,'error':'image render has no observed asset reference'}
            if Path(asset).is_file():
                actual = hashlib.sha256(Path(asset).read_bytes()).hexdigest()
                if result.get('artifact_sha256') and result['artifact_sha256'] != actual:
                    return {**result,'success':False,'error':'image asset hash differs from observed bytes'}
                result.update(artifact_sha256=actual,asset_bytes_observed=True)
        elif action.operation == 'media:image_review':
            render = dict(action.parameters.get('render_observation') or {})
            render = dict(render.get('payload') or render)
            expected = render.get('artifact_sha256')
            ref = render.get('generated_ref') or render.get('artifact') or render.get('url')
            matches = (bool(expected) and result.get('reviewed_artifact_sha256') == expected) or (not expected and bool(ref) and result.get('reviewed_ref') == ref)
            if not matches or not result.get('review_ref'):
                return {**result,'success':False,'image_quality_observation':{},'error':'review does not identify the exact rendered asset and observer'}
            if isinstance(ref,str) and Path(ref).is_file() and expected and hashlib.sha256(Path(ref).read_bytes()).hexdigest() != expected:
                return {**result,'success':False,'image_quality_observation':{},'error':'rendered asset changed before review'}
        return result

    def accept_observation(self, turn: CoreTurn, action: RuntimeActionRequest, result: Any) -> CoreTurn:
        """Feed an observed external effect back into the same canonical turn."""
        result = self._bind_image_asset(action,result)
        outcome = classify_execution_result(result)
        success = outcome.successful
        execution_receipt = self.execution_receipts.record(
            work=action, result=result, success=success, provider=action.executor, operation=action.operation,
        )
        self.resilience.record_execution(
            capability_id=action.capability, success=success, receipt_id=execution_receipt.receipt_id,
            evidence=result if isinstance(result, dict) else {"result": result},
            read_back_verified=(bool(result.get("read_back_verified")) if isinstance(result, dict) and "read_back_verified" in result else None),
            session_id=self.session_id,
        )
        if success is not True:
            self.resilience.revise_after_failure(
                objective=turn.command, route_id=action.executor, operation=action.operation,
                error=RuntimeError(f"observed action did not prove success: {outcome.exit_state}"),
                missing_traits=tuple(turn.operational_resilience.get("route_plan", {}).get("missing_traits", ())),
                context={"action_id": action.action_id, "capability": action.capability, "exit_state": outcome.exit_state},
            )
        try:
            intent_binding = self.unified_intent.bind_sha(
                turn.command_sha256, component="observation", validation_passed=True,
                validation_scope="execution_observation_bound_to_canonical_turn",
                evidence_refs=(execution_receipt.receipt_id,),
                details={"action_id": action.action_id, "exit_state": outcome.exit_state},
            )
        except Exception as exc:
            intent_binding = reference_for_sha(
                turn.command_sha256, component="observation", validation_passed=False,
                validation_scope="execution_observation_binding_persistence_failed",
                evidence_refs=(execution_receipt.receipt_id,),
                details={"action_id": action.action_id, "exit_state": outcome.exit_state,
                         "binding_error": f"{type(exc).__name__}:{exc}"},
            ).as_mapping()
        observation = {
            "unified_intent": intent_binding,
            "action_id": action.action_id,
            "action_request_sha256": work_request_sha256(action),
            "capability": action.capability,
            "executor": action.executor,
            "operation": action.operation,
            "success": success,
            "exit_state": outcome.exit_state,
            "execution_receipt_id": execution_receipt.receipt_id,
            "execution_receipt_sha256": execution_receipt.receipt_sha256,
            "result": _model_observation(result),
        }
        action_parameters = dict(action.parameters or {})
        observation["parameters"] = action_parameters
        quality_verdict = None
        if action.operation == "media:image_review":
            quality_verdict = ImageQualityGovernor.review_observation(
                dict(result.get("image_quality_observation") or {}) if isinstance(result,dict) else {},
                contract=dict(action_parameters.get("image_generation_governance") or {}).get("quality_contract"))
            observation["image_quality_verdict"] = quality_verdict
            if quality_verdict.get("accepted") is not True:
                success = False
            observation['success'] = success
        if action.operation.startswith("search:"):
            self.search_evidence_graph.observe(goal=turn.command_sha256,
                family=action_parameters.get("source_family") or action.operation[7:],
                action_id=action.action_id, result=result, frontier_id=action_parameters.get("frontier_id",""))
        if success is True:
            self.audit.attach_runtime(turn.release_turn_id,run_id=execution_receipt.receipt_id,
                subsystem="attested_host_execution",success=True,evidence={
                    "execution_receipt_id":execution_receipt.receipt_id,"receipt_sha256":execution_receipt.receipt_sha256,
                    "provider":action.executor,"operation":action.operation,
                    "capability":"media:image_generate" if quality_verdict else action.capability,
                    "requirement_message_sha256":turn.command_sha256,
                    "requirement_ids":action_parameters.get("requirement_ids",[]),
                    "image_quality_verdict":quality_verdict,
                    "render_action_id":action_parameters.get("render_action_id","")})
        if success is True:
            covered_open_ids = tuple(action_parameters.get("open_execution_obligation_ids") or ())
            open_execution_state = self.open_execution.record_success(
                message_sha256=turn.command_sha256,
                receipt_id=execution_receipt.receipt_id,
                operation=action.operation,
                covered_obligation_ids=covered_open_ids,
                effect_observed=bool(covered_open_ids and action_parameters.get("open_execution_effect_candidate")),
                evidence={
                    "receipt_sha256": execution_receipt.receipt_sha256,
                    "host_call_observed": True,
                    "exit_state": outcome.exit_state,
                    "expected_effects": tuple(action.expected_effects or ()),
                    "result": _model_observation(result),
                },
            )
        else:
            open_execution_state = self.open_execution.record_negative(
                message_sha256=turn.command_sha256,
                scope_kind="host_action",
                scope_ref=action.action_id,
                detail=f"{outcome.exit_state}: {action.operation} via {action.executor}",
                representation_ref=str((turn.representation_program or {}).get("representation_id") or ""),
                provider_ref=action.executor,
                code=f"FAILED_UNDER_HOST_ACTION_{action.operation}",
            )
        # v2 closed loop: observed execution changes Work, evidence, executable
        # memory, body lineage, observation sensors and the improvement program.
        work_mapping = dict(turn.work_program or {})
        evidence_bindings = list(turn.evidence_bindings or ())
        executable_memory_state = dict(turn.executable_memory_state or {})
        body_materializations = list(turn.body_materializations or ())
        observation_gap = dict(turn.observation_gap or {})
        improvement_adoption = dict(turn.improvement_adoption or {})
        structure_mutation: dict[str, Any] = {}

        try:
            work_program = self.work_program_runtime.from_mapping(work_mapping)
            ready_nodes = self._schedule_ready_nodes(work_program)
            if not ready_nodes:
                ready_nodes = self.work_program_runtime.resume(work_program)

            # Host evidence may mutate a user goal only when the receipt is bound to
            # a concrete Work node.  Scheduler order is not semantic authority.
            # For a single live node the binding is unambiguous; with multiple live
            # nodes an explicit work_node_id/target_work_node_id is required.
            requested_node_id = str(
                action_parameters.get("work_node_id")
                or action_parameters.get("target_work_node_id")
                or ""
            )
            active_node = None
            if requested_node_id:
                active_node = next((n for n in ready_nodes if n.node_id == requested_node_id), None)
                if active_node is None:
                    structure_mutation = {
                        "unbound_host_observation": True,
                        "goal_state_changed": False,
                        "requested_work_node_id": requested_node_id,
                        "reason": "requested_work_node_not_currently_ready",
                        "evidence_refs": (execution_receipt.receipt_id,),
                    }
            elif len(ready_nodes) == 1:
                active_node = ready_nodes[0]
            elif ready_nodes:
                structure_mutation = {
                    "unbound_host_observation": True,
                    "goal_state_changed": False,
                    "ready_work_node_ids": tuple(n.node_id for n in ready_nodes),
                    "reason": "multiple_live_goals_require_explicit_receipt_binding",
                    "evidence_refs": (execution_receipt.receipt_id,),
                }

            if active_node is not None:
                work_program = self.work_program_runtime.advance(
                    work_program, node_id=active_node.node_id,
                    observation_ref=execution_receipt.receipt_id, success=(success is True),
                )
                if success is not True:
                    alternate = self.body_builder.discover(action.operation)
                    alternate_row = dict(alternate[0]) if alternate else {}
                    alternate_ref = str(alternate_row.get("entrypoint_ref") or "")
                    alternate_executable = bool(alternate_row.get("effect_executable", bool(alternate_ref)))
                    if not alternate_ref or alternate_ref in {str(action.executor), str(action.capability)}:
                        generated = self.body_builder.generate(
                            desired_change=action.operation,
                            entrypoint_ref=f"local_generated_program:repair:{action.operation}",
                            observable_result={"operation": action.operation, "failed_route_replaced": True},
                            kind="generated_failure_repair_body",
                            parent_refs=(execution_receipt.receipt_id,),
                            interface={"input": "failed_execution", "output": "alternate_execution", "reusable": True},
                        )
                        self.body_builder.bind(generated)
                        body_materializations.append(generated.as_mapping())
                        alternate_ref = generated.entrypoint_ref
                        alternate_executable = bool(generated.effect_executable)

                    if alternate_executable:
                        structure_mutation = self.mutation_runtime.replace_component(
                            component_ref=f"route:{action.operation}",
                            replacement_program_ref=alternate_ref,
                            affected_work_refs=(work_program.work_id, active_node.node_id),
                            comparison_task_refs=(action.action_id,),
                            evidence_refs=(execution_receipt.receipt_id,),
                        )
                        retry_program_ref = alternate_ref
                        retry_effect = {
                            "desired_change": active_node.effect_request.get("desired_change", "satisfy_goal_ref"),
                            "failed_route_ref": action.executor,
                            "retry_with": alternate_ref,
                            "mutation_proposal_ref": structure_mutation["proposal"]["proposal_id"],
                        }
                    else:
                        # A non-executable placeholder is evidence of a capability gap,
                        # not evidence that the failed route was replaced. Keep the Work
                        # open until a concrete executable body is materialized.
                        structure_mutation = {
                            "pending_body_synthesis": True,
                            "component_ref": f"route:{action.operation}",
                            "failed_route_ref": str(action.executor),
                            "placeholder_body_ref": alternate_ref,
                            "evidence_refs": (execution_receipt.receipt_id,),
                        }
                        retry_program_ref = "jigaewol:effect_body_synthesis"
                        retry_effect = {
                            "desired_change": "materialize_effect_body",
                            "requested_effect": action.operation,
                            "original_desired_change": active_node.effect_request.get("desired_change", "satisfy_goal_ref"),
                            "failed_route_ref": action.executor,
                            "placeholder_body_ref": alternate_ref,
                            "effect_executable_required": True,
                            "success_receipt_required": True,
                        }

                    work_program = self.work_program_runtime.split_node(
                        work_program, node_id=active_node.node_id,
                        child_specs=(
                            {
                                "goal_refs": active_node.goal_refs,
                                "program_ref": "jigaewol:observe_failure",
                                "effect_request": {"desired_change": "record_failed_route", "failed_action": action.action_id},
                                "state": "completed",
                            },
                            {
                                "goal_refs": active_node.goal_refs,
                                "program_ref": retry_program_ref,
                                "effect_request": retry_effect,
                                "state": "ready",
                            },
                        ),
                        lineage_ref=execution_receipt.receipt_id,
                    )
                self.work_program_runtime.save(work_program)
                work_mapping = {
                    **work_program.as_mapping(),
                    "resume_node_ids": tuple(x.node_id for x in self.work_program_runtime.resume(work_program)),
                    "structure_mutation": structure_mutation,
                }
            elif structure_mutation.get("unbound_host_observation"):
                # Preserve the entire live Work graph; attach the receipt as an
                # observation only, never as guessed goal completion.
                work_mapping = {
                    **work_program.as_mapping(),
                    "resume_node_ids": tuple(x.node_id for x in self.work_program_runtime.resume(work_program)),
                    "structure_mutation": structure_mutation,
                }
        except Exception as exc:
            work_mapping = {**work_mapping, "closure_error": f"{type(exc).__name__}:{exc}"}

        binding = self.evidence_kernel.bind(
            claim_ref=f"execution:{action.action_id}",
            observation_refs=(execution_receipt.receipt_id,),
            status="observed",
        )
        binding_verified = self.evidence_kernel.verify(binding)
        traced_bindings = self.evidence_kernel.trace_claim(f"execution:{action.action_id}")
        evidence_bindings.append({**binding.as_mapping(), "verified": binding_verified, "trace_count": len(traced_bindings)})
        bodies = self.body_builder.snapshot()
        matched_body = next((row for row in bodies.values() if str(row.get("body_id") or "") in {action.capability, action.executor}
                             or str(row.get("entrypoint_ref") or "") in {action.capability, action.executor}
                             or str(row.get("effect_signature") or "") == str(action.operation)), None)
        trace_program_ref = str((matched_body or {}).get("entrypoint_ref") or action.executor or action.operation)
        trace_row = self.executable_memory.store_trace(
            program_ref=trace_program_ref,
            input_ref=turn.command_sha256,
            receipt_refs=(execution_receipt.receipt_id,),
            result_ref=execution_receipt.receipt_id,
        )
        operator_ref = str((turn.dynamic_operator or {}).get("operator_id") or "")
        recipe = self.executable_memory.compile_recipe(
            traces=(trace_row,), operator_refs=((operator_ref,) if operator_ref else ()),
        )
        recalled = self.executable_memory.recall_structure((action.operation, action.executor, operator_ref))
        recipe_probe = self.executable_memory.execute_recipe(
            recipe, input_payload={"operation": action.operation, "receipt_ref": execution_receipt.receipt_id}
        )
        executable_memory_state = {
            "latest_trace": trace_row, "latest_recipe": recipe,
            "recipe_probe": recipe_probe,
            "recalled_structure_count": len(recalled),
        }

        if matched_body is not None:
            body_observation = self.body_builder.observe(
                matched_body, receipt_ref=execution_receipt.receipt_id, success=(success is True), result=_model_observation(result),
            )
            executable_memory_state["body_observation"] = body_observation

        if success is not True:
            gap = self.observer_builder.detect_gap(
                signals=("prediction_execution_mismatch", "past_success_new_failure"),
                context={"action_id": action.action_id, "operation": action.operation, "receipt_ref": execution_receipt.receipt_id},
            )
            if gap is not None:
                sensor_request = self.observer_builder.propose_sensor(gap)
                sensor = self.observer_builder.materialize(sensor_request, program_ref=f"sensor:{gap.gap_id}")
                sensor_body = self.body_builder.generate(
                    desired_change=f"observe:{gap.gap_id}", entrypoint_ref=str(sensor.get("program_ref") or ""),
                    observable_result={"gap_id": gap.gap_id}, kind="generated_sensor",
                    parent_refs=(gap.gap_id,), interface=sensor,
                )
                self.body_builder.bind(sensor_body)
                body_materializations.append(sensor_body.as_mapping())
                sensor_probe = self.observer_builder.execute(sensor, {
                    "action_id": action.action_id,
                    "operation": action.operation,
                    "receipt_ref": execution_receipt.receipt_id,
                    "result": _model_observation(result),
                })
                observation_gap = {**gap.as_mapping(), "sensor": sensor, "body": sensor_body.as_mapping(), "probe": sensor_probe}

        # A parked improvement candidate may explicitly wait for a new execution
        # body.  Reactivate it in the same causal turn in which that body becomes
        # observable, instead of forcing a later user message to wake it up.
        body_reactivated_candidates: tuple[dict[str, Any], ...] = ()
        new_body_event = bool(
            matched_body is not None
            or len(body_materializations) > len(tuple(turn.body_materializations or ()))
        )
        if new_body_event:
            try:
                live_work = self.work_program_runtime.from_mapping(work_mapping)
                live_work, body_reactivated_candidates = self.work_program_runtime.reactivate(
                    live_work,
                    predicate=lambda row: (
                        str(row.get("kind") or "") == "improvement_program_candidate"
                        and "new_body" in set(map(str, row.get("activation_conditions") or ()))
                    ),
                )
                if body_reactivated_candidates:
                    self.work_program_runtime.save(live_work)
                    work_mapping = {
                        **live_work.as_mapping(),
                        "resume_node_ids": tuple(x.node_id for x in self.work_program_runtime.resume(live_work)),
                        "structure_mutation": structure_mutation,
                    }
            except Exception as exc:
                improvement_adoption["body_reactivation_error"] = f"{type(exc).__name__}:{exc}"

        improvement_mapping = dict(turn.improvement_program or {})
        if improvement_mapping and not improvement_mapping.get("bypassed"):
            base_program = self.improvement_programs.from_mapping(improvement_mapping)
            reactivated_body_programs = []
            for candidate in body_reactivated_candidates:
                program_row = dict(candidate.get("program") or {})
                if program_row.get("program_ref"):
                    reactivated_body_programs.append(self.improvement_programs.from_mapping(program_row))
            if reactivated_body_programs:
                base_program = self.improvement_programs.combine(
                    (base_program, *tuple(reactivated_body_programs)),
                    evidence_refs=(execution_receipt.receipt_id,),
                )
                improvement_adoption["reactivated_by_new_body_refs"] = tuple(
                    p.program_ref for p in reactivated_body_programs
                )
            primary_program = self.improvement_programs.mutate(
                base_program,
                observes=tuple(dict.fromkeys((*base_program.observes, "structure_mutation" if structure_mutation else "recipe_reuse"))),
                proposes=tuple(dict.fromkeys((*base_program.proposes, "route_repair" if success is not True else "successful_trace_reuse"))),
                experiment_builder_ref=(
                    f"mutation_runtime:branch_compare:{action.operation}" if success is not True
                    else "executable_memory:replay_recipe_then_transfer_probe"
                ),
                adoption_rule_ref=(
                    "evidence_kernel:observed_causal_improvement" if success is not True
                    else "evidence_kernel:observed_user_outcome_and_reuse"
                ),
                evidence_ref=execution_receipt.receipt_id,
            )
            alternate_program = self.improvement_programs.mutate(
                base_program,
                observes=tuple(dict.fromkeys((*base_program.observes, "representation_transfer_probe"))),
                proposes=tuple(dict.fromkeys((*base_program.proposes, "representation_transfer"))),
                experiment_builder_ref="representation_programs:regenerate_and_probe",
                adoption_rule_ref="evidence_kernel:preservation_plus_observed_execution",
                evidence_ref=execution_receipt.receipt_id,
            )
            start_state = {
                "work": work_mapping,
                "receipt_ref": execution_receipt.receipt_id,
                "action": {
                    "action_id": action.action_id,
                    "operation": action.operation,
                    "executor": action.executor,
                },
            }

            def _run_improvement_candidate(program, branch_state):
                proposes = set(program.proposes)
                if "route_repair" in proposes and structure_mutation:
                    mutation = dict(structure_mutation.get("mutation") or {})
                    changed = bool(mutation.get("before_sha256") and mutation.get("after_sha256") and mutation.get("before_sha256") != mutation.get("after_sha256"))
                    return {
                        "observed": True,
                        "success": changed,
                        "reusable": changed,
                        "change_kind": "route_structure",
                        "evidence_ref": str(mutation.get("mutation_receipt_id") or execution_receipt.receipt_id),
                        "state": branch_state,
                    }
                if "successful_trace_reuse" in proposes:
                    replayed = bool(recipe_probe.get("executed"))
                    return {
                        "observed": replayed,
                        "success": replayed,
                        "reusable": replayed,
                        "change_kind": "executable_recipe",
                        "evidence_ref": execution_receipt.receipt_id if replayed else "",
                        "recipe_probe": recipe_probe,
                        "state": branch_state,
                    }
                if "representation_transfer" in proposes:
                    raw_text = str((turn.goal_kernel or {}).get("raw_text") or "")
                    refs = tuple(
                        str(ref) for node in (work_mapping.get("nodes") or ())
                        for ref in (node.get("goal_refs") or ()) if str(ref)
                    )
                    candidate_rep = RepresentationPrograms.propose(
                        raw_text, requirement_refs=refs, pressure=True,
                        parent_refs=(execution_receipt.receipt_id, program.program_ref),
                    )
                    candidate_rep, candidate_probe = RepresentationPrograms.run_probe(
                        candidate_rep, source_text=raw_text, requirement_refs=refs,
                    )
                    observed = bool(candidate_probe)
                    valid = bool(candidate_probe.get("preservation_ok"))
                    return {
                        "observed": observed,
                        "success": valid,
                        "reusable": valid,
                        "change_kind": "representation_transfer",
                        "evidence_ref": execution_receipt.receipt_id,
                        "representation_id": candidate_rep.representation_id,
                        "probe": candidate_probe,
                        "state": branch_state,
                    }
                return {"observed": False, "success": False, "reusable": False, "state": branch_state}

            tournament = self.improvement_programs.run_competition(
                (primary_program, alternate_program),
                start_state=start_state,
                runner=_run_improvement_candidate,
            )
            try:
                adopted_program = self.improvement_programs.combine_useful(
                    (primary_program, alternate_program),
                    tournament=tournament,
                    evidence_refs=(execution_receipt.receipt_id,),
                )
            except ValueError:
                adopted_program = alternate_program
            adoption = self.improvement_programs.adopt(
                adopted_program, evidence_refs=(execution_receipt.receipt_id,)
            )
            improvement_mapping = adopted_program.as_mapping()
            improvement_adoption = {
                **improvement_adoption,
                "comparison": tournament,
                "adoption": adoption,
                "structure_mutation": structure_mutation,
                "candidate_program_refs": (primary_program.program_ref, alternate_program.program_ref),
                "combined": len(adopted_program.parent_program_refs) > 1,
            }
            try:
                live_work = self.work_program_runtime.from_mapping(work_mapping)
                program_by_ref = {
                    primary_program.program_ref: primary_program,
                    alternate_program.program_ref: alternate_program,
                }
                adopted_lineage = set(adopted_program.parent_program_refs) | {adopted_program.program_ref}
                parked_refs = []
                for result_row in tournament.get("results") or ():
                    pref = str(result_row.get("program_ref") or "")
                    if not pref or pref in adopted_lineage or pref not in program_by_ref:
                        continue
                    live_work = self.work_program_runtime.park_candidate(
                        live_work,
                        {
                            "kind": "improvement_program_candidate",
                            "program": program_by_ref[pref].as_mapping(),
                            "result": dict(result_row),
                            "activation_conditions": ("new_user_message", "new_representation", "new_body"),
                        },
                        reason="not_selected_this_round",
                        evidence_refs=(execution_receipt.receipt_id,),
                    )
                    parked_refs.append(pref)
                if parked_refs:
                    self.work_program_runtime.save(live_work)
                    work_mapping = {
                        **live_work.as_mapping(),
                        "resume_node_ids": tuple(x.node_id for x in self.work_program_runtime.resume(live_work)),
                        "structure_mutation": structure_mutation,
                    }
                    improvement_adoption["parked_candidate_refs"] = tuple(parked_refs)
            except Exception as exc:
                improvement_adoption["reservoir_error"] = f"{type(exc).__name__}:{exc}"

        updated = replace(
            turn,
            host_observations=tuple((*turn.host_observations, observation)),
            operational_resilience=self.resilience.snapshot(),
            open_execution_state=open_execution_state,
            work_program=work_mapping,
            body_materializations=tuple(body_materializations),
            observation_gap=observation_gap,
            improvement_program=improvement_mapping,
            improvement_adoption=improvement_adoption,
            executable_memory_state=executable_memory_state,
            evidence_bindings=tuple(evidence_bindings),
        )
        self._turns[turn.core_turn_id] = updated
        self._persist_turn(updated)
        self.audit.attach_runtime(
            turn.release_turn_id, run_id=execution_receipt.receipt_id, subsystem="causal_loop_observation",
            success=(success is True), evidence={
                "action_id": action.action_id, "capability": action.capability,
                "request_sha256": observation["action_request_sha256"],
                "execution_receipt_sha256": execution_receipt.receipt_sha256, "exit_state": outcome.exit_state,
            },
        )
        self.trace.emit(
            turn_id=turn.release_turn_id, phase="OBSERVATION",
            status="SUCCEEDED" if success is True else ("FAILED" if success is False else "INDETERMINATE"),
            component="CausalLoopCoordinator", action=action.operation, capability_id=action.capability,
            provider=action.executor, receipt_id=execution_receipt.receipt_id,
            details={"action_id": action.action_id, "request_sha256": observation["action_request_sha256"], "exit_state": outcome.exit_state},
        )
        return updated
