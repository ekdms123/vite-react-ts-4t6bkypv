from __future__ import annotations

import math
import os
from dataclasses import dataclass

@dataclass(frozen=True)
class ResourceEnvelope:
    latency_target_ms: int
    cpu_count: int
    capability_count: int
    uncertainty: float
    urgency: float
    branch_budget: int
    worker_budget: int
    verification_budget: int
    reason: str
    semantic_horizon_open: bool = True
    branch_budget_semantics: str = 'telemetry_window_not_semantic_ceiling'


def derive_resource_envelope(*, latency_target_ms: int = 2500, capability_count: int = 0,
                             uncertainty: float = 0.5, urgency: float = 0.5,
                             cpu_count: int | None = None, breadth_protected: bool = False) -> ResourceEnvelope:
    """Describe current execution headroom without granting it authority over scope."""
    cpu=max(1,int(cpu_count or os.cpu_count() or 1))
    latency=max(1,int(latency_target_ms))
    u=min(1.0,max(0.0,float(uncertainty)))
    g=min(1.0,max(0.0,float(urgency)))
    time_factor=max(1.0, math.log2(1.0 + latency/250.0))
    branch=max(1,int(round(time_factor*(1.0+2.2*u))))
    workers=max(1,min(cpu,max(1,int(round(branch**0.5 + capability_count**0.25)))))
    verification=max(1,int(round(1.0+3.0*u)))
    return ResourceEnvelope(latency,cpu,int(capability_count),u,g,branch,workers,verification,
        'execution_headroom_telemetry_only',True,'telemetry_window_not_semantic_ceiling')


def derive_execution_horizon(envelope: ResourceEnvelope, profile: str, *, pending_work_count: int) -> int:
    """By default schedule the full finite pending set. Profiles never silently prune it."""
    pending=max(0,int(pending_work_count))
    return pending
