from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass
from typing import Any, Protocol

from jigaewol_core.semantic_loop import GenerationRequest, GenerationResult


@dataclass(frozen=True)
class CognitiveInvocation:
    invocation_id: str
    request_sha256: str
    parent_step_sha256: str
    request_payload: dict[str, Any]


@dataclass(frozen=True)
class CognitionReceipt:
    invocation_id: str
    request_sha256: str
    response_sha256: str
    provider_id: str
    model_id: str
    parent_step_sha256: str
    observed_at: float
    origin_ref: str
    body: str
    receipt_sha256: str = ""


def _cognition_receipt_sha(*, invocation_id: str, request_sha256: str, response_sha256: str,
                           provider_id: str, model_id: str, parent_step_sha256: str,
                           observed_at: float, origin_ref: str) -> str:
    payload = {
        "invocation_id": str(invocation_id), "request_sha256": str(request_sha256),
        "response_sha256": str(response_sha256), "provider_id": str(provider_id),
        "model_id": str(model_id), "parent_step_sha256": str(parent_step_sha256),
        "observed_at": float(observed_at), "origin_ref": str(origin_ref),
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class CompletedInvocation:
    receipt: CognitionReceipt


@dataclass(frozen=True)
class PendingInvocation:
    invocation_id: str
    request_sha256: str
    request_payload: dict[str, Any]
    parent_step_sha256: str = ""
    kind: str = "cognition"


class CognitionPort(Protocol):
    def invoke(self, request: CognitiveInvocation) -> CompletedInvocation | PendingInvocation: ...


class CognitionPending(RuntimeError):
    def __init__(self, pending: PendingInvocation) -> None:
        super().__init__(f"cognition receipt required for request_sha256={pending.request_sha256}")
        self.pending = pending



class CallbackCognitionPort:
    """In-process cognition body used by tests/local providers while keeping receipts."""

    def __init__(self, callback, *, provider_id: str = "callback_cognition", model_id: str = "callback_model") -> None:
        self.callback = callback
        self.provider_id = provider_id
        self.model_id = model_id

    @staticmethod
    def _request_from_payload(payload: dict[str, Any]) -> GenerationRequest:
        return GenerationRequest(
            objective=str(payload.get("objective") or ""),
            evidence=dict(payload.get("evidence") or {}),
            route_state=dict(payload.get("route_state") or {}),
            response_contract=dict(payload.get("response_contract") or {}),
            execution_profile=str(payload.get("execution_profile") or "DEEP"),
            cognitive_worlds=tuple(payload.get("cognitive_worlds") or ()),
            active_world=payload.get("active_world"),
            falsification_questions=tuple(payload.get("falsification_questions") or ()),
            counterframes=tuple(payload.get("counterframes") or ()),
        )

    def invoke(self, request: CognitiveInvocation) -> CompletedInvocation:
        req = self._request_from_payload(request.request_payload)
        value = self.callback(req)
        if isinstance(value, GenerationResult):
            body = str(value.candidate_body)
            model_id = str(value.producer_id or self.model_id)
        else:
            body = str(value)
            model_id = self.model_id
        response_sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
        observed_at = time.time()
        origin_ref = "inprocess:cognition_callback"
        receipt_sha = _cognition_receipt_sha(
            invocation_id=request.invocation_id, request_sha256=request.request_sha256, response_sha256=response_sha,
            provider_id=self.provider_id, model_id=model_id, parent_step_sha256=request.parent_step_sha256,
            observed_at=observed_at, origin_ref=origin_ref,
        )
        return CompletedInvocation(CognitionReceipt(
            invocation_id=request.invocation_id, request_sha256=request.request_sha256,
            response_sha256=response_sha, provider_id=self.provider_id, model_id=model_id,
            parent_step_sha256=request.parent_step_sha256, observed_at=observed_at,
            origin_ref=origin_ref, body=body, receipt_sha256=receipt_sha,
        ))

    def candidate_generator(self, *, parent_step_sha256_getter=lambda: ""):
        def generate(request: GenerationRequest) -> GenerationResult:
            invocation = CognitiveInvocation(
                invocation_id="cog_" + uuid.uuid5(uuid.NAMESPACE_URL, request.sha256()).hex[:20],
                request_sha256=request.sha256(), parent_step_sha256=str(parent_step_sha256_getter() or ""),
                request_payload=request.canonical_payload(),
            )
            receipt = self.invoke(invocation).receipt
            return GenerationResult(
                generation_id="generation_" + receipt.request_sha256[:16],
                candidate_body=receipt.body, producer_id=receipt.model_id,
                metadata={"request_sha256":receipt.request_sha256,"body_sha256":receipt.response_sha256,
                          "cognition_receipt":True,"cognition_invocation_id":receipt.invocation_id,
                          "parent_step_sha256":receipt.parent_step_sha256,"origin_ref":receipt.origin_ref,
                          "cognition_receipt_sha256":receipt.receipt_sha256,
                          "full_generation_request_bound":True},
                created_at=receipt.observed_at,
            )
        return generate

class ReceiptCognitionPort:
    """Receipt-backed host cognition transport."""

    def __init__(self, ledger: Any, *, provider_id: str = "host_receipt", model_id: str = "host_session") -> None:
        self.ledger = ledger
        self.provider_id = str(provider_id)
        self.model_id = str(model_id)

    def invoke(self, request: CognitiveInvocation) -> CompletedInvocation | PendingInvocation:
        try:
            row = self.ledger.consume(request.request_sha256)
        except Exception as exc:
            if exc.__class__.__name__ == "HostReceiptMissing":
                return PendingInvocation(request.invocation_id, request.request_sha256, request.request_payload, request.parent_step_sha256)
            raise
        if row.get("invocation_id") and str(row.get("invocation_id")) != request.invocation_id:
            raise PermissionError("cognition invocation id mismatch")
        if row.get("parent_step_sha256") and str(row.get("parent_step_sha256")) != str(request.parent_step_sha256):
            raise PermissionError("cognition receipt parent-step binding mismatch")
        body = str(row.get("body") or "")
        response_sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
        model_id = str(row.get("model_id") or self.model_id)
        observed_at = float(row.get("recorded_at") or time.time())
        origin_ref = str(row.get("origin_ref") or f"host_generation:{request.request_sha256}")
        receipt_sha = _cognition_receipt_sha(
            invocation_id=request.invocation_id, request_sha256=request.request_sha256, response_sha256=response_sha,
            provider_id=self.provider_id, model_id=model_id, parent_step_sha256=request.parent_step_sha256,
            observed_at=observed_at, origin_ref=origin_ref,
        )
        return CompletedInvocation(CognitionReceipt(
            invocation_id=request.invocation_id, request_sha256=request.request_sha256,
            response_sha256=response_sha, provider_id=self.provider_id, model_id=model_id,
            parent_step_sha256=request.parent_step_sha256, observed_at=observed_at,
            origin_ref=origin_ref, body=body, receipt_sha256=receipt_sha,
        ))

    def candidate_generator(self, *, parent_step_sha256_getter=lambda: ""):
        def generate(request: GenerationRequest) -> GenerationResult:
            request_sha = request.sha256()
            existing = self.ledger._read().get(request_sha) if hasattr(self.ledger, "_read") else None
            bound_parent = (str(existing.get("parent_step_sha256") or "") if existing else "") or str(parent_step_sha256_getter() or "")
            invocation = CognitiveInvocation(
                invocation_id="cog_" + uuid.uuid5(uuid.NAMESPACE_URL, request_sha).hex[:20],
                request_sha256=request_sha,
                parent_step_sha256=bound_parent,
                request_payload=request.canonical_payload(),
            )
            outcome = self.invoke(invocation)
            if isinstance(outcome, PendingInvocation):
                raise CognitionPending(outcome)
            receipt = outcome.receipt
            return GenerationResult(
                generation_id="generation_" + receipt.request_sha256[:16],
                candidate_body=receipt.body,
                producer_id=receipt.model_id,
                metadata={
                    "request_sha256": receipt.request_sha256,
                    "body_sha256": receipt.response_sha256,
                    "cognition_receipt": True,
                    "cognition_invocation_id": receipt.invocation_id,
                    "parent_step_sha256": receipt.parent_step_sha256,
                    "origin_ref": receipt.origin_ref,
                    "cognition_receipt_sha256": receipt.receipt_sha256,
                    "full_generation_request_bound": True,
                },
                created_at=receipt.observed_at,
            )
        return generate
