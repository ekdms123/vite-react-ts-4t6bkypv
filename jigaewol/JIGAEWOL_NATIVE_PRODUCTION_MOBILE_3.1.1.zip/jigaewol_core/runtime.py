from __future__ import annotations
from jigaewol_components.snapshot_store import save_snapshot
from jigaewol_components.search_evidence_graph import SearchEvidenceGraph
from jigaewol_components.candidate_lab import CandidateLab
from jigaewol_components.mutable_policy_evolution import MutablePolicyEvolution

import hashlib
import json

from dataclasses import asdict, replace
from pathlib import Path
from typing import Any, Iterable, Mapping

from jigaewol_runtime import OperatingFoundation
from jigaewol_components.cumulative_intent import CumulativeIntentLedger
from jigaewol_components.turn_continuity import TurnContinuityController
from jigaewol_components.intent_deep_analyzer import IntentDeepAnalyzer, IntentDeepAnalysis
from jigaewol_components.semantic_authority import SemanticAuthorityCompiler
from jigaewol_components.discourse_scope import DiscourseScopeAnalyzer
from jigaewol_components.ephemeral_universe import EphemeralUniverseEngine
from jigaewol_components.forensic_runtime_contract import ForensicRuntimeContract
from jigaewol_components.openness_contract import compile_openness_contract
from jigaewol_components.possibility_engine import PossibilityEngine
from jigaewol_components.reasoning_portfolio import AdaptiveReasoningPortfolio
from jigaewol_components.frontier_control_plane import FrontierControlPlane
from jigaewol_components.requirement_contract import RequirementCompiler
from jigaewol_components.ambition_preserver import AmbitionPreserver
from jigaewol_components.strategy_topology import StrategyTopologySelector
from jigaewol_components.representation_tournament import RepresentationTournament
from jigaewol_components.anti_recurrence import AntiRecurrenceEngine
from jigaewol_components.multimodal_state_bus import MultimodalStateBus
from jigaewol_components.repair_momentum import RepairMomentum
from jigaewol_components.user_goal_kernel import UserGoalKernel
from jigaewol_components.work_program import WorkProgramRuntime
from jigaewol_components.representation_programs import RepresentationPrograms
from jigaewol_components.representation_lineage import RepresentationLineage
from jigaewol_components.operator_builder import OperatorBuilder
from jigaewol_components.interpreter_builder import InterpreterBuilder
from jigaewol_components.effect_planner import EffectPlanner, EffectRequest
from jigaewol_components.body_builder import BodyBuilder
from jigaewol_components.mutation_runtime import MutationRuntime
from jigaewol_components.improvement_programs import ImprovementPrograms
from jigaewol_components.observer_builder import ObserverBuilder
from jigaewol_components.friction_repair import FrictionRepair
from jigaewol_components.executable_memory import ExecutableMemory
from jigaewol_components.evidence_kernel import EvidenceKernel
from jigaewol_components.cognitive_os import OpenWorldCognitiveCompiler
from jigaewol_components.possibility_pressure import PossibilityPressure
from jigaewol_components.response_protocol import CandidateResponse
from jigaewol_components.response_sink import ResponseSink
from jigaewol_components.completion_claim_guard import detect_unproven_completion_claim
from jigaewol_components.scope_integrity import ScopeIntegrityGuard
from jigaewol_components.runtime_home import resolve_runtime_home
from jigaewol_components.turn_audit import TurnAuditLedger
from jigaewol_components.open_identity_loop import OpenIdentityLoop
from jigaewol_components.open_ended_execution import OpenEndedExecutionKernel
from jigaewol_components.authority_guard import source_bound_objective, source_effect_authorized
from jigaewol_components.unified_user_intent import UnifiedIntentKernel
from jigaewol_components.semantic_communication import SemanticCommunicationLayer
from jigaewol_components.deep_open_cognition import MetaConstitutionLab
from jigaewol_components.exploration_escalation import ExplorationEscalationController, ExplorationState
from jigaewol_components.exploration_return import ObjectiveAnchor, ExplorationResultFilter, ExplorationCandidate
from jigaewol_components.exploration_memory import ExplorationMemory
from .integration_registry import IntegrationRegistry
from .integrity import verify_active_artifact
from .operational_resilience import OperationalResilienceEngine
from .observability import PublicExecutionTrace
from .semantic_loop import GenerationRequest, SemanticCandidateEngine, VerificationResult
from .verification_policy import classify_task_kind, evaluate_verification_coverage
from .resource_policy import derive_resource_envelope, derive_execution_horizon
from .world_invention import RepresentationGapWorldGenerator
from .open_world_intent import extract_open_world_intent
from .evidence_attestation import ExecutionReceiptLedger
from .adaptive_revision import EvidenceClosedRevisionLoop
from .canonical_finalizer import CanonicalTurnFinalizer
from .execution_truth import classify_execution_result
from .action_port import RuntimeActionRequest, work_request_sha256
from .turn_profile import classify_turn_profile
from .turn_gateway import TurnGateway
from .release_runtime import CanonicalReleaseRuntime
from .constants import PUBLIC_RUNTIME_ID, CHARTER_ID
from .runtime_cognition import CoreRuntimeCognitionMixin
from .runtime_deliberation import CoreRuntimeDeliberationMixin
from .runtime_ingress import CoreRuntimeIngressMixin
from .runtime_observation import CoreRuntimeObservationMixin
from .runtime_helpers import _sha_text, _safe_summary, _model_observation
from .turn_artifact import CoreTurn
from .runtime_federation import build_runtime_federation
from jigaewol_components.capability_runtime import HostAdapter, HostObservationContext
from jigaewol_components.wild_cognitive_plane import WildCognitivePlane

PACKAGE_ROOT = Path(__file__).resolve().parents[1]





class CoreRuntime(CoreRuntimeIngressMixin, CoreRuntimeObservationMixin, CoreRuntimeCognitionMixin, CoreRuntimeDeliberationMixin):
    """Current Jigaewol runtime. The exact user directive is the destination authority.

    Internal classifiers, resource windows, verifiers, and route state may annotate or
    schedule work, but they do not rewrite or veto the user's destination. Execution
    claims remain bound to observed receipts and integrity hashes.
    """

    public_runtime_identity = PUBLIC_RUNTIME_ID
    runtime_identity = public_runtime_identity
    charter_id = CHARTER_ID

    @staticmethod
    def _make_core_turn(**kwargs) -> CoreTurn:
        return CoreTurn(**kwargs)

    def _observe_current_host_surface(self, context: HostObservationContext) -> Mapping[str, Any]:
        """Return a fresh outer-host snapshot for the requested turn boundary.

        Outer-host observation outranks bootstrap constructor rows.  Failure is represented
        as UNKNOWN by HostAdapter; it is never converted into an empty-world claim.
        """
        observer = self._outer_host_surface_observer
        if observer is not None:
            return observer(context)
        rows = tuple(self._current_host_surface or ())
        return {
            "format": "structured_surface_v1",
            "surface_complete": False,
            "observation_state": "bootstrap_fallback" if rows else "unknown",
            "host_snapshot_id": "bootstrap_" + _sha_text(json.dumps(
                [dict(row) for row in rows if isinstance(row, Mapping)],
                ensure_ascii=False, sort_keys=True, default=str,
            ))[:20] if rows else "",
            "capabilities": [dict(row) for row in rows if isinstance(row, Mapping)],
        }

    def bind_outer_host_observer(self, observer: Any | None) -> None:
        """Replace the observer used for future capability snapshots.

        Existing CapabilitySnapshot artifacts stay immutable; only subsequent observations
        see the new host registry.
        """
        self._outer_host_surface_observer = observer

    def __init__(
        self,
        root: str | Path,
        *,
        user_id: str = "user",
        project_id: str = "project",
        session_id: str = "chat",
        capabilities: Iterable[Any] = (),
        host_surface_observer: Any | None = None,
        host_attachments: Iterable[Any] = (),
        policy_root: str | Path | None = None,
        candidate_generator: Any | None = None,
        semantic_verifiers: Iterable[Any] = (),
        latency_target_ms: int = 2500,
        trace_listener: Any | None = None,
        control_checkpoint_id: str | None = None,
        require_gateway_turn: bool = False,
        gateway_envelope: Mapping[str, Any] | None = None,
        require_finalization_permit: bool = False,
    ) -> None:
        self.root = Path(root)
        self.user_id = str(user_id)
        self.project_id = str(project_id)
        self.session_id = str(session_id)
        # Identity mismatch must fail before foundation/gate/trace ledgers can create
        # receipts.  This closes the non-atomic failure observed when a wrong caller
        # identity touched an already-bound conversation root.
        OpenIdentityLoop.assert_compatible(self.root, user_id=self.user_id, project_id=self.project_id)
        self.root.mkdir(parents=True, exist_ok=True)
        capability_rows = tuple(capabilities)
        # The federation observes host reality at the canonical turn boundary.  The
        # constructor surface is only a bootstrap fallback; an outer-host observer may
        # return a fresh snapshot for every turn.
        self._host_attachments = tuple(host_attachments)
        self._current_host_surface = capability_rows
        self._outer_host_surface_observer = host_surface_observer
        self._federation_host_adapter = HostAdapter(observer=self._observe_current_host_surface)
        # Federation is the ownership boundary. CoreRuntime remains a compatibility
        # facade while responsibilities migrate to independent artifact-producing runtimes.
        self.federation = build_runtime_federation(
            self.root / "federation", host_adapter=self._federation_host_adapter
        )
        self.latency_target_ms = max(100, int(latency_target_ms))
        self.control_checkpoint_id = str(control_checkpoint_id or "")
        self.gateway_envelope = dict(gateway_envelope or {})
        self._auto_admit_gateway_turn = not bool(require_gateway_turn or self.gateway_envelope)
        self.require_gateway_turn = True
        if require_gateway_turn and not self.gateway_envelope:
            raise PermissionError("release integrity: canonical gateway turn requires a gateway envelope")
        self.active_artifact_integrity = verify_active_artifact(raise_on_failure=True)
        self.foundation = OperatingFoundation(
            self.root / "foundation",
            user_id=user_id,
            project_id=project_id,
            session_id=session_id,
            capabilities=capability_rows,
        )
        self.intent = CumulativeIntentLedger(self.root / "intent" / "cumulative_intent.json")
        self.unified_intent = UnifiedIntentKernel(self.root)
        self.semantic_communication = SemanticCommunicationLayer(self.root)
        self.meta_constitution = MetaConstitutionLab(self.root / "meta_constitution")
        # Canonical chat continuity lives at the same root that the strict ingress
        # resolver reads. Older resident/foundation paths had continuity machinery,
        # but canonical mobile ingress did not materialize this state at all.
        # (merged from the GPT lineage)
        self.turn_continuity = TurnContinuityController(self.root / "continuity" / "turn_continuity.json")
        self.multimodal_bus = MultimodalStateBus(self.root / "multimodal" / "state_bus.json")
        self.policy_evolution = MutablePolicyEvolution(Path(policy_root or self.root) / "policy_evolution" / "candidates")
        self.search_evidence_graph = SearchEvidenceGraph(self.root / "search_evidence_graph")
        self.candidate_lab = CandidateLab(self.root / "candidate_lab",experience_root=Path(policy_root or self.root)/"experiences")
        from jigaewol_components.turn_production import TurnProduction
        self.turn_production=TurnProduction(self.root/'turn_production')
        from jigaewol_components.requirement_ledger import RequirementLedger
        self.requirements = RequirementLedger(Path(policy_root or self.root)/"requirements"/RequirementLedger.project_key(self.user_id,self.project_id))
        from jigaewol_components.free_route_broker import FreeRouteBroker
        self.free_routes = FreeRouteBroker(Path(policy_root or self.root)/"free_routes")
        self.intent_analyzer = IntentDeepAnalyzer()
        self.anti_recurrence = AntiRecurrenceEngine(self.root / "anti_recurrence" / "invariants.json")
        self.repair_momentum = RepairMomentum(self.root / "repair_momentum")
        self.user_goal_kernel = UserGoalKernel(self.root / "user_goal_kernel")
        self.work_program_runtime = WorkProgramRuntime(self.root / "work_program")
        self.representation_lineage = RepresentationLineage(self.root / "representation_lineage")
        self.operator_builder = OperatorBuilder(self.root / "operator_registry")
        self.interpreter_builder = InterpreterBuilder(self.operator_builder)
        self.effect_planner = EffectPlanner()
        self.body_builder = BodyBuilder(self.root / "body_builder")
        self.mutation_runtime = MutationRuntime(self.root / "mutation_runtime")
        self.improvement_programs = ImprovementPrograms(self.root / "improvement_programs")
        self.observer_builder = ObserverBuilder(self.root / "observer_builder")
        self.friction_repair = FrictionRepair(self.root / "friction_repair")
        self.executable_memory = ExecutableMemory(self.root / "executable_memory")
        self.evidence_kernel = EvidenceKernel(self.root / "evidence_kernel")
        self.cognitive_os_compiler = OpenWorldCognitiveCompiler(self.root / "cognitive_os")
        canonical = PACKAGE_ROOT / "CANONICAL_ARTIFACT.json"
        self.audit = TurnAuditLedger(
            self.root / "turn_audit",
            runtime_identity=self.runtime_identity,
            charter_id=self.charter_id,
            canonical_artifact_path=canonical,
        )
        # Response release is content-addressed integrity storage, not a permission decision.
        # The turn gate remains available for ingress/audit/execution receipts only.
        self.sink = ResponseSink(
            self.root / "response_sink",
            require_finalization_permit=True,
        )
        self.require_finalization_permit = True
        self._turns: dict[str, CoreTurn] = {}
        self._open_world_cache: dict[str, Any] | None = None
        self.integrations = IntegrationRegistry()
        self._integration_probe = self.integrations.descriptor_snapshot()
        self.resilience = OperationalResilienceEngine(self.root / "operational_resilience")
        self.trace = PublicExecutionTrace(self.root / "public_execution_trace.jsonl", listener=trace_listener)
        self.world_inventor = RepresentationGapWorldGenerator()
        self.semantic = SemanticCandidateEngine(candidate_generator, verifiers=tuple(semantic_verifiers))
        self.execution_receipts = ExecutionReceiptLedger(self.root / "execution_receipts.jsonl", session_id=self.session_id)
        self.revision_loop = EvidenceClosedRevisionLoop(self.root / "revision" / "promotion_ledger.json")
        self.canonical_finalizer = CanonicalTurnFinalizer(self.root / "canonical_finalizer")
        self.release_runtime = CanonicalReleaseRuntime(
            self.root, session_id=self.session_id, ledger=self.audit,
            execution_receipts=self.execution_receipts, finalizer=self.canonical_finalizer, trace=self.trace,
        )
        self.turn_gateway = TurnGateway(
            self.root / "turn_gateway",
            user_id=self.user_id,
            project_id=self.project_id,
            session_id=self.session_id,
        )
        self.cognitive_continuity = OpenIdentityLoop(
            self.root, user_id=self.user_id, project_id=self.project_id, session_id=self.session_id
        )
        north_star_path = self.root / "PROJECT_NORTH_STAR.json"
        if not self.cognitive_continuity.project_goal() and north_star_path.is_file():
            try:
                north_star = json.loads(north_star_path.read_text(encoding="utf-8"))
                goal_text = str(north_star.get("goal") or "").strip()
                if goal_text:
                    self.cognitive_continuity.set_project_goal(
                        goal_text, source=str(north_star.get("source") or "packaged project north star")
                    )
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                # A malformed optional seed never weakens ingress integrity. The runtime
                # continues without silently inventing a replacement project goal.
                pass
        self.exploration_escalation = ExplorationEscalationController(self.root / "exploration_escalation")
        self.exploration_memory = ExplorationMemory(self.root / "exploration_escalation" / "memory")
        self.exploration_result_filter = ExplorationResultFilter()
        self.reasoning_portfolio = AdaptiveReasoningPortfolio(self.root / "cognition" / "reasoning_portfolio.json")
        self.frontier_control = FrontierControlPlane(self.root / "frontier_control", source_root=PACKAGE_ROOT)
        self.open_execution = OpenEndedExecutionKernel(self.root / "open_ended_execution")

    def _bind_canonical_turn_continuity(
        self, *, release_turn_id: str, command: str, semantic_objective: str,
        continuation_context: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Persist the unfinished semantic objective before host work begins.

        This state is intentionally separate from transcript memory. If a turn is
        interrupted before finalization, a later bare continuation can recover the
        exact unfinished objective. A new non-continuation turn creates a new active
        task instead of silently hijacking an older unfinished workstream.
        (merged from the GPT lineage)
        """
        ctx = dict(continuation_context or {})
        restored = bool(ctx.get("restored"))
        objective = str(semantic_objective or command).strip()
        task = None
        restored_task_id = str(ctx.get("task_id") or "")
        if restored and restored_task_id:
            for candidate in self.turn_continuity.unfinished():
                if candidate.task_id == restored_task_id:
                    task = self.turn_continuity.checkpoint(
                        candidate.task_id, phase="canonical_ingress_resumed",
                        state={
                            "release_turn_id": str(release_turn_id),
                            "latest_message_sha256": _sha_text(command),
                            "continuation_restored": True,
                        },
                    )
                    break
        if task is None:
            task = self.turn_continuity.start_or_resume(
                objective=objective,
                prefer_unfinished=restored,
                strict_workstream=True,
                state={
                    "release_turn_id": str(release_turn_id),
                    "latest_message_sha256": _sha_text(command),
                    "continuation_restored": restored,
                },
            )
            task = self.turn_continuity.checkpoint(
                task.task_id,
                phase="canonical_ingress_resumed" if restored else "canonical_ingress",
                state={
                    "release_turn_id": str(release_turn_id),
                    "latest_message_sha256": _sha_text(command),
                    "continuation_restored": restored,
                },
            )
        return {
            "task_id": task.task_id,
            "objective": task.objective,
            "objective_sha256": task.objective_sha256,
            "status": task.status,
            "phase": task.phase,
            "restored": restored,
        }

    def _complete_canonical_turn_continuity(
        self, release_turn_id: str, *, receipt_id: str = "", completion_proof: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        """Complete only the continuity task bound to this finalized release turn."""
        for task in reversed(self.turn_continuity.unfinished()):
            if str(task.state.get("release_turn_id") or "") != str(release_turn_id):
                continue
            completed = self.turn_continuity.complete(
                task.task_id,
                receipts=(str(receipt_id),) if str(receipt_id) else (),
                state={"finalized_release_turn_id": str(release_turn_id)},
                completion_proof=dict(completion_proof or {}),
            )
            return {"task_id": completed.task_id, "status": completed.status, "phase": completed.phase}
        return {"task_id": "", "status": "not_found", "phase": ""}

    def _audit_open_world(self, *, force_refresh: bool = False) -> dict[str, Any]:
        artifact_key = str(self.active_artifact_integrity.get("content_set_sha256") or "")
        cache_path = self.root / "audit_cache" / "open_world.json"
        if self._open_world_cache is None and not force_refresh and artifact_key and cache_path.is_file():
            try:
                cached = json.loads(cache_path.read_text(encoding="utf-8"))
                if cached.get("artifact_content_set_sha256") == artifact_key and isinstance(cached.get("report"), dict):
                    self._open_world_cache = {**cached["report"], "cache_state": "artifact_bound_reuse"}
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                pass
        if self._open_world_cache is None and not force_refresh:
            baseline = PACKAGE_ROOT / "OPEN_WORLD_AUDIT_BASELINE.json"
            if baseline.is_file():
                try:
                    saved = json.loads(baseline.read_text(encoding="utf-8"))
                    if isinstance(saved.get("report"), dict):
                        self._open_world_cache = {**saved["report"], "cache_state": "build_time_audit_reuse"}
                except (OSError, ValueError, TypeError):
                    pass
        if self._open_world_cache is None:
            audit_runtime = self.federation.open_world_audit
            reports = [
                (name, audit_runtime.scan(PACKAGE_ROOT / name))
                for name in ("jigaewol_runtime", "jigaewol_core", "jigaewol_components")
                if (PACKAGE_ROOT / name).is_dir()
            ]
            counts: dict[str, int] = {}
            for _, report in reports:
                for key, value in report.category_counts.items():
                    counts[key] = counts.get(key, 0) + int(value)
            self._open_world_cache = {
                "scanned_files":sum(report.scanned_files for _, report in reports),
                "finding_count":sum(len(report.findings) for _, report in reports),
                "category_counts":counts,
                "closedness_score":sum(report.closedness_score for _, report in reports),
                "audit_target":"active cognition chassis: jigaewol_runtime + jigaewol_core + jigaewol_components",
                "audit_roots":tuple(name for name, _ in reports),
                "cache_state":"fresh_scan",
            }
            if artifact_key:
                cache_path.parent.mkdir(parents=True, exist_ok=True)
                tmp = cache_path.with_suffix(".tmp")
                tmp.write_text(json.dumps({
                    "artifact_content_set_sha256": artifact_key,
                    "report": self._open_world_cache,
                }, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
                tmp.replace(cache_path)
        return dict(self._open_world_cache)

    def refresh_open_world_audit(self) -> dict[str, Any]:
        self._open_world_cache = None
        return self._audit_open_world(force_refresh=True)

    @staticmethod
    def _effective_depth(analysis: IntentDeepAnalysis) -> dict[str, Any]:
        # No-downgrade routing note: no-downgrade and force-deep are distinct.
        # Explicit current wording wins. Only an unspecified current command may
        # inherit a sufficiently evidenced latent routing preference.
        explicit = str(analysis.current_explicit_depth)
        inferred = str(analysis.inferred_depth)
        if explicit in {"deep", "shallow"}:
            effective = explicit
            basis = "explicit_current_command"
        elif inferred in {"deep", "shallow"}:
            effective = inferred
            basis = "current_turn_semantic_analysis"
        else:
            effective = "unspecified"
            basis = "insufficient_evidence"
        return {
            "explicit":explicit,
            "inferred":inferred,
            "effective":effective,
            "basis":basis,
            "confidence":analysis.confidence,
            "evidence_weight":analysis.evidence_weight,
            "reasons":tuple(analysis.reasons),
            "literal_command_mutable":False,
        }







    def turn_for_loop_id(self, loop_turn_id: str) -> CoreTurn | None:
        """Return the prepared core turn bound to a causal-loop turn id."""
        direct = self._turns.get("core::" + str(loop_turn_id))
        if direct is not None:
            return direct
        for turn in reversed(tuple(self._turns.values())):
            if str(getattr(turn, "foundation_turn_id", "")) == str(loop_turn_id):
                return turn
        return None

    def _persist_turn(self, turn: CoreTurn) -> None:
        p = self.root / "core_turns"
        p.mkdir(parents=True, exist_ok=True)
        target = p / (turn.release_turn_id + ".json")
        save_snapshot(target, turn.public_snapshot())

    def next_work(self, turn: CoreTurn) -> tuple[Any, ...]:
        return tuple(turn.next_work)

    def record_corrective_action(
        self,
        turn: CoreTurn,
        *,
        action_kind: str,
        target: str,
        before_sha256: str = "",
        after_sha256: str = "",
        evidence_ref: str = "",
        note: str = "",
    ) -> dict[str, Any]:
        receipt = self.repair_momentum.record_action(
            turn_id=turn.release_turn_id,
            action_kind=action_kind,
            target=target,
            before_sha256=before_sha256,
            after_sha256=after_sha256,
            evidence_ref=evidence_ref,
            note=note,
            addressed_terms=tuple(turn.repair_momentum_contract.get("issue_terms") or ()),
        )
        self.trace.emit(
            turn_id=turn.release_turn_id, phase="REPAIR_MOMENTUM", status="MUTATED",
            component="RepairMomentum", action=action_kind,
            receipt_id=receipt.receipt_id, details=receipt.as_mapping(),
        )
        return receipt.as_mapping()

    def bind_external_host_execution(self, release_turn_id: str, evidence: dict[str, Any]) -> dict[str, Any]:
        return self.release_runtime.bind_external_host_execution(release_turn_id, evidence)

    def _verified_host_execution_evidence(self, release_turn_id: str) -> tuple[list[dict[str, Any]], list[str]]:
        return self.release_runtime._verified_host_execution_evidence(release_turn_id)

    def finalize_canonical_turn(
        self,
        release_turn_id: str,
        *,
        ingress_verified: bool,
        control_checkpoint_id: str,
        final_response_sha256: str,
        expected_response_sha256: str | None = None,
        expected_previous_finalizer_receipt_id: str | None = None,
        requirement_manifest: Mapping[str, Any] | None = None,
        final_response_text: str | None = None,
        persist_receipt: bool = True,
    ) -> dict[str, Any]:
        receipt = self.release_runtime.finalize_canonical_turn(
            release_turn_id,
            ingress_verified=ingress_verified,
            control_checkpoint_id=control_checkpoint_id,
            final_response_sha256=final_response_sha256,
            expected_response_sha256=expected_response_sha256,
            expected_previous_finalizer_receipt_id=expected_previous_finalizer_receipt_id,
            requirement_manifest=requirement_manifest,
            final_response_text=final_response_text,
            persist_receipt=bool(persist_receipt),
        )
        if not persist_receipt:
            return receipt
        evidence, receipt_ids = self._verified_host_execution_evidence(release_turn_id)
        continuity_update = self.cognitive_continuity.complete_turn(
            release_turn_id=release_turn_id, finalizer_receipt=receipt,
            execution_receipt_ids=receipt_ids, requirement_manifest=requirement_manifest,
        )
        self.trace.emit(
            turn_id=release_turn_id, phase="COGNITIVE_CONTINUITY", status="UPDATED",
            component="OpenIdentityLoop", action="finalizer_outcome_persisted",
            receipt_id=str(receipt.get("receipt_id") or ""), details=continuity_update,
        )
        if bool(receipt.get("objective_completion_proven")):
            task_continuity_update = self._complete_canonical_turn_continuity(
                release_turn_id,
                receipt_id=str(receipt.get("receipt_id") or ""),
                completion_proof={
                    "proven": True,
                    "evidence_refs": tuple(receipt.get("objective_completion_evidence_refs") or ()),
                    "unresolved_goal_refs": tuple(receipt.get("objective_completion_unresolved_goal_refs") or ()),
                    "source": "canonical_finalizer_work_completion",
                },
            )
            continuity_action = "objective_completion_proven_and_closed"
        else:
            task_continuity_update = {
                "task_id": "",
                "status": "kept_open",
                "phase": "objective_not_proven_complete",
                "release_application_state": str(receipt.get("application_state") or ""),
                "unresolved_goal_refs": list(receipt.get("objective_completion_unresolved_goal_refs") or ()),
                "open_obligations": list(receipt.get("open_obligations") or ()),
            }
            continuity_action = "release_recorded_objective_kept_open"
        self.trace.emit(
            turn_id=release_turn_id, phase="TURN_CONTINUITY", status="UPDATED",
            component="TurnContinuityController", action=continuity_action,
            receipt_id=str(receipt.get("receipt_id") or ""), details=task_continuity_update,
        )
        return receipt

    def submit(self, turn: CoreTurn, work: Any, result: Any):
        if turn.command_sha256 != _sha_text(turn.command):
            raise RuntimeError("turn command integrity mismatch after ingress")
        outcome = classify_execution_result(result)
        if outcome.successful is not True:
            indeterminate = outcome.successful is None
            error = RuntimeError(
                f"indeterminate execution evidence: {outcome.exit_state}" if indeterminate
                else f"structured execution failure: {outcome.exit_state}"
            )
            view = self.foundation.fail(work, error)
            operation = str(getattr(work, "operation", None) or "host_work")
            route_id = str(getattr(work, "executor", None) or operation)
            capability_id = operation.removeprefix("capability.") or route_id
            execution_receipt = self.execution_receipts.record(
                work=work, result=result, success=outcome.successful, provider=route_id, operation=operation,
            )
            self.audit.attach_runtime(
                turn.release_turn_id, run_id=execution_receipt.receipt_id,
                subsystem="host_execution_indeterminate_route" if indeterminate else "host_execution_failure_route",
                success=False, evidence={"execution_receipt_id": execution_receipt.receipt_id, "receipt_sha256": execution_receipt.receipt_sha256,
                                        "exit_state": outcome.exit_state, "failure_family": outcome.failure_family,
                                        "successful": outcome.successful},
            )
            self.resilience.record_execution(
                capability_id=capability_id, success=outcome.successful, receipt_id=execution_receipt.receipt_id,
                evidence=result if isinstance(result, dict) else {"result": result},
                read_back_verified=(None if indeterminate else False), session_id=self.session_id,
            )
            self.trace.emit(
                turn_id=turn.release_turn_id, phase="EXECUTION", status="INDETERMINATE" if indeterminate else "FAILED", component="HOST", action=operation,
                capability_id=capability_id, provider=route_id, receipt_id=execution_receipt.receipt_id,
                details={"exit_state": outcome.exit_state, "failure_family": outcome.failure_family,
                         "successful": outcome.successful, "result": _safe_summary(result)},
            )
            revision = self.resilience.revise_after_failure(
                objective=turn.command, route_id=route_id, operation=operation, error=error,
                missing_traits=tuple(turn.operational_resilience.get("route_plan",{}).get("missing_traits", ())),
                context={"work_id":getattr(work,"work_id",None), "exit_state": outcome.exit_state,
                         "execution_truth": "unknown" if indeterminate else "failure"},
            )
            self.trace.emit(
                turn_id=turn.release_turn_id, phase="ROUTE_REVISION", status="RECOVERING", component="OperationalResilienceEngine",
                action="indeterminate_execution_requires_alternate_proof" if indeterminate else "route_failure_preserve_goal",
                capability_id=capability_id, provider=route_id, receipt_id=revision.revision_id, details=asdict(revision),
            )
            open_execution_state = self.open_execution.record_negative(
                message_sha256=turn.command_sha256,
                scope_kind="execution_route",
                scope_ref=route_id,
                detail=f"{outcome.exit_state}: {outcome.failure_family or 'execution_failure'}",
                representation_ref=str((turn.representation_program or {}).get("representation_id") or ""),
                provider_ref=route_id,
                code=f"FAILED_UNDER_ROUTE_{route_id}",
            )
            updated = replace(
                turn, next_work=tuple(view.next_work), operational_resilience=self.resilience.snapshot(),
                open_execution_state=open_execution_state,
            )
            self._turns[turn.core_turn_id] = updated
            self._persist_turn(updated)
            key = "structured_indeterminate" if indeterminate else "structured_failure"
            return updated, {"view": view, key: asdict(outcome)}
        submitted = self.foundation.submit(work, result)
        view = submitted["view"]
        self.audit.attach_runtime(
            turn.release_turn_id,
            run_id=str(getattr(work, "work_id", "host_work")),
            subsystem="host_execution_observation",
            success=True,
            evidence={
                "work_id":getattr(work,"work_id",None),
                "executor":getattr(work,"executor",None),
                "operation":getattr(work,"operation",None),
                "result":_safe_summary(result),
                "result_phase":getattr(view,"phase",None),
            },
        )
        capability_id = str(getattr(work, "operation", "") or "").removeprefix("capability.") or str(getattr(work, "executor", "host"))
        read_back_verified = None
        if isinstance(result, dict):
            if "read_back_verified" in result: read_back_verified = bool(result.get("read_back_verified"))
            elif isinstance(result.get("state_verification"), dict): read_back_verified = bool(result["state_verification"].get("proven"))
        execution_receipt = self.execution_receipts.record(
            work=work, result=result, success=True, provider=str(getattr(work,"executor",None) or "host"),
            operation=str(getattr(work,"operation",None) or "host_work"), read_back_verified=read_back_verified,
        )
        self.audit.attach_runtime(
            turn.release_turn_id, run_id=execution_receipt.receipt_id, subsystem="attested_host_execution",
            success=True, evidence={"execution_receipt_id":execution_receipt.receipt_id,"receipt_sha256":execution_receipt.receipt_sha256,
                                   "provider":execution_receipt.provider,"operation":execution_receipt.operation,"exit_state":execution_receipt.exit_state},
        )
        self.resilience.record_execution(
            capability_id=capability_id, success=True, receipt_id=execution_receipt.receipt_id, evidence=result if isinstance(result, dict) else {"result": result},
            read_back_verified=read_back_verified, session_id=self.session_id,
        )
        self.trace.emit(
            turn_id=turn.release_turn_id, phase="EXECUTION", status="SUCCEEDED", component="HOST",
            action=str(getattr(work,"operation",None) or "host_work"), capability_id=capability_id,
            provider=str(getattr(work,"executor",None) or "host"), receipt_id=execution_receipt.receipt_id,
            details={"result": _safe_summary(result), "read_back_verified": read_back_verified, "receipt_sha256":execution_receipt.receipt_sha256},
        )
        observation = {
            "action_id": str(getattr(work, "action_id", getattr(work, "work_id", "host_work"))),
            "work_id": str(getattr(work, "work_id", "host_work")),
            "executor": str(getattr(work, "executor", "host")),
            "operation": str(getattr(work, "operation", "host_work")),
            "result": _model_observation(result),
        }
        if str(getattr(work, "operation", "")).startswith("search:"):
            parameters = dict(getattr(work, "parameters", None) or {})
            self.search_evidence_graph.observe(goal=turn.command_sha256,
                family=parameters.get("source_family") or str(getattr(work,"operation",""))[7:],
                action_id=observation["action_id"], result=result, frontier_id=parameters.get("frontier_id", ""))
        work_parameters = dict(getattr(work, "parameters", None) or {})
        covered_open_ids = tuple(work_parameters.get("open_execution_obligation_ids") or ())
        effect_observed = bool(covered_open_ids and outcome.successful)
        open_execution_state = self.open_execution.record_success(
            message_sha256=turn.command_sha256,
            receipt_id=execution_receipt.receipt_id,
            operation=str(getattr(work, "operation", None) or "host_work"),
            covered_obligation_ids=covered_open_ids,
            effect_observed=effect_observed,
            evidence={
                "receipt_sha256": execution_receipt.receipt_sha256,
                "provider": execution_receipt.provider,
                "read_back_verified": read_back_verified,
                "expected_effects": tuple(getattr(work, "expected_effects", ()) or ()),
                "goal_effect_candidate": bool(work_parameters.get("open_execution_effect_candidate")),
            },
        )
        updated = replace(
            turn, next_work=tuple(view.next_work), operational_resilience=self.resilience.snapshot(),
            possibility_plan=turn.possibility_plan,
            open_execution_state=open_execution_state,
            host_observations=tuple((*turn.host_observations, observation)),
        )
        self._turns[turn.core_turn_id] = updated
        self._persist_turn(updated)
        return updated, submitted

    def fail(self, turn: CoreTurn, work: Any, error: Exception | str):
        view = self.foundation.fail(work, error)
        failure_receipt = self.execution_receipts.record(
            work=work, result={"error_type":type(error).__name__,"error":str(error)[:1200]}, success=False,
            provider=str(getattr(work,"executor",None) or "host"), operation=str(getattr(work,"operation",None) or "host_work"),
        )
        self.audit.attach_runtime(
            turn.release_turn_id,
            run_id=failure_receipt.receipt_id,
            subsystem="host_execution_failure_route",
            success=False,
            evidence={"error_type":type(error).__name__, "error":str(error)[:600], "execution_receipt_id":failure_receipt.receipt_id, "receipt_sha256":failure_receipt.receipt_sha256},
        )
        operation=str(getattr(work,"operation",None) or "host_work")
        route_id=str(getattr(work,"executor",None) or operation)
        revision=self.resilience.revise_after_failure(
            objective=turn.command, route_id=route_id, operation=operation, error=error,
            missing_traits=tuple(turn.operational_resilience.get("route_plan",{}).get("missing_traits", ())),
            context={"work_id":getattr(work,"work_id",None)},
        )
        possibility_plan = PossibilityEngine.raise_after_route_stall(turn.possibility_plan, route_id=route_id)
        self.trace.emit(
            turn_id=turn.release_turn_id, phase="ROUTE_REVISION", status="RECOVERING", component="OperationalResilienceEngine",
            action="route_failure_preserve_goal", capability_id=operation.removeprefix("capability."), provider=route_id,
            receipt_id=revision.revision_id, details=asdict(revision),
        )
        observation = {
            "action_id": str(getattr(work, "action_id", getattr(work, "work_id", "host_work"))),
            "work_id": str(getattr(work, "work_id", "host_work")),
            "executor": str(getattr(work, "executor", "host")),
            "operation": str(getattr(work, "operation", "host_work")),
            "result": _model_observation({"error_type": type(error).__name__, "error": str(error)}),
        }
        open_execution_state = self.open_execution.record_negative(
            message_sha256=turn.command_sha256,
            scope_kind="execution_route",
            scope_ref=route_id,
            detail=f"{type(error).__name__}: {str(error)[:1200]}",
            representation_ref=str((turn.representation_program or {}).get("representation_id") or ""),
            provider_ref=route_id,
            code=f"FAILED_UNDER_ROUTE_{route_id}",
        )
        updated = replace(
            turn, next_work=tuple(view.next_work), operational_resilience=self.resilience.snapshot(),
            possibility_plan=possibility_plan,
            open_execution_state=open_execution_state,
            host_observations=tuple((*turn.host_observations, observation)),
        )
        self._turns[turn.core_turn_id] = updated
        self._persist_turn(updated)
        return updated, view

    def attach_traversal(self, turn: CoreTurn, *, subsystem: str, success: bool, evidence=None, run_id="external"):
        return self.audit.attach_runtime(
            turn.release_turn_id,
            run_id=str(run_id), subsystem=str(subsystem), success=bool(success), evidence=dict(evidence or {}),
        )

    def release(self, turn: CoreTurn, body: str, *, producer: str = "jigaewol_core_host", finalization_permit=None, expected_loop_chain_sha256: str = ""):
        if turn.command_sha256 != _sha_text(turn.command):
            raise PermissionError("turn command changed after ingress")
        break_verdict = self.repair_momentum.verify(
            turn_id=turn.release_turn_id, contract=turn.repair_momentum_contract
        )
        if not break_verdict.ok:
            self.trace.emit(
                turn_id=turn.release_turn_id, phase="REPAIR_MOMENTUM", status="ACTIVE",
                component="RepairMomentum", action="record_open_repair_obligation",
                details={"findings": list(break_verdict.findings), "receipt_ids": list(break_verdict.receipt_ids)},
            )
        self.foundation.verify_ingress_receipt(
            turn.foundation_receipt_id, message=turn.command, turn_id=turn.foundation_turn_id
        )
        # No secondary model-authored response rewrite or style gate.
        body = str(body)
        candidate = CandidateResponse(
            turn_id=turn.release_turn_id,
            body=str(body),
            producer=str(producer),
            evidence={
                "core_turn_id":turn.core_turn_id,
                "foundation_turn_id":turn.foundation_turn_id,
                "foundation_receipt_id":turn.foundation_receipt_id,
                "command_sha256":turn.command_sha256,
                "depth":turn.depth,
            },
        )
        # Preserve the candidate in the audit ledger, but do not ask that ledger for
        # permission to answer. CAS read-back is the release integrity condition.
        self.audit.bind_candidate(turn.release_turn_id, candidate)
        if finalization_permit is None:
            # There is no direct publication bypass.  Even callers of CoreRuntime.release
            # must first pass the same strong finalizer used by the causal loop.
            response_sha = candidate.response_sha256
            strong = self.finalize_canonical_turn(
                turn.release_turn_id,
                ingress_verified=bool(turn.release_ingress_receipt_id),
                control_checkpoint_id=str(self.control_checkpoint_id or ""),
                final_response_sha256=response_sha,
                expected_response_sha256=response_sha,
                expected_previous_finalizer_receipt_id=(turn.expected_previous_finalizer_receipt_id or None),
                requirement_manifest=None,
                final_response_text=candidate.body,
            )
            if strong.get("final_response_allowed") is True:
                semantics = "SOLVED"
            elif strong.get("progress_response_allowed") is True:
                semantics = "INCOMPLETE"
            else:
                raise PermissionError("canonical finalizer denied both final and progress response publication")
            chain_sha = str(expected_loop_chain_sha256 or "").lower()
            if len(chain_sha) != 64 or any(ch not in "0123456789abcdef" for ch in chain_sha):
                chain_sha = _sha_text(json.dumps({
                    "turn_id": turn.release_turn_id,
                    "core_turn_id": turn.core_turn_id,
                    "response_sha256": response_sha,
                    "strong_finalizer_receipt_id": strong.get("receipt_id"),
                }, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            finalization_permit = self.canonical_finalizer.prepare(
                turn_id=turn.release_turn_id,
                response_sha256=response_sha,
                loop_chain_sha256=chain_sha,
                requirement_contract_sha256=str((turn.active_requirement_contract or turn.requirement_contract or {}).get("contract_sha256") or ""),
                observation_chain_sha256=(
                    _sha_text(json.dumps(list(turn.host_observations or ()), ensure_ascii=False, sort_keys=True, default=str))
                    if turn.host_observations else ""
                ),
                terminal_semantics=semantics,
                strong_finalizer_receipt_id=str(strong.get("receipt_id") or ""),
            )
            expected_loop_chain_sha256 = chain_sha
        # A caller-supplied permit (notably the causal loop) must not bypass false-
        # completion protection.  INCOMPLETE means the strong authority explicitly
        # did not prove the requested destination complete; a progress response may
        # describe evidence/failure, but not state that the work was completed.
        if str(getattr(finalization_permit, "terminal_semantics", "")) == "INCOMPLETE":
            claim = detect_unproven_completion_claim(candidate.body)
            if claim.blocked:
                raise PermissionError(
                    "release invariant: unproven completion claim in progress response: "
                    + "; ".join(claim.matches)
                )
            # Unproven-completion claims remain prohibited by the exact-effect
            # check above.  The duplicate speculative-ceiling prose classifier
            # was removed from this release path: live goal scope is checked by
            # ScopeIntegrityGuard in the generation/verification path.
        released = self.sink.commit(
            candidate=candidate, permit=finalization_permit, user_command=turn.command,
            permit_verifier=lambda permit: self.canonical_finalizer.verify_permit(
                permit, expected_loop_chain_sha256=expected_loop_chain_sha256
            ),
        )
        self.trace.emit(
            turn_id=turn.release_turn_id, phase="RELEASE", status="RELEASED", component="ResponseSink",
            action="direct_cas_integrity_release", receipt_id=released.integrity_receipt_id,
            details={
                "producer": producer,
                "candidate_sha256": released.body_sha256,
                "integrity_receipt_id": released.integrity_receipt_id,
                "blob_sha256": released.blob_sha256,
                "release_format": released.release_format,
            },
        )
        return released






    def prepare_turn(self, command: str, *, capabilities=None, attachments=(), resume_turn: CoreTurn | None = None, **kwargs) -> CoreTurn:
        """Resolve the canonical CoreTurn that every later transition must descend from."""
        if resume_turn is not None:
            resume_turn, migrated_fields = self._upgrade_core_turn_schema(resume_turn)
            if resume_turn.command_sha256 != _sha_text(command):
                raise RuntimeError("resume_turn directive hash mismatch")
            turn = resume_turn
            if migrated_fields:
                self.trace.emit(
                    turn_id=turn.release_turn_id, phase="INGRESS", status="MIGRATED", component="CoreRuntime",
                    action="legacy_core_turn_schema_upgrade",
                    details={"populated_default_fields": migrated_fields, "field_count": len(migrated_fields)},
                )
            self._turns[turn.core_turn_id] = turn
            return turn
        return self.ingress(command, capabilities=capabilities, attachments=attachments, **kwargs)

    def derive_actions(self, turn: CoreTurn) -> tuple[RuntimeActionRequest, ...]:
        """Derive exact external-effect requests from canonical semantic state.

        The runtime derives candidate effects from the canonical user-governed semantic
        state; derivation is delegated work, not ownership of the user's means. Explicit
        user-specified means constrain or replace derived means. HostBridge is intentionally
        absent here and can only route/observe the resulting request. Completed action ids
        are suppressed on replay so suspend/resume cannot duplicate side effects.
        """
        authority = dict(turn.semantic_authority or {})
        completed = {
            str(row.get("action_id") or row.get("work_id") or "")
            for row in (turn.host_observations or ())
            if isinstance(row, dict) and (row.get("action_id") or row.get("work_id"))
        }
        route_rows = tuple(
            row for row in (turn.execution_route_composition or {}).get("routes", ())
            if isinstance(row, dict)
        )

        def _route_for_traits(traits: tuple[str, ...], capability: str = '') -> dict[str, Any]:
            wanted = set(str(x) for x in traits if str(x))
            failed={str(x.get('executor') or '') for x in turn.host_observations
                    if x.get('capability')==capability and x.get('success') is not True}
            rows=tuple(row for row in route_rows if str(row.get('capability_id') or row.get('provider') or row.get('plugin') or 'host') not in failed)
            for surface in self._current_host_surface:
                if isinstance(surface,dict):
                    identifier=str(surface.get('executor_id') or surface.get('capability_id') or surface.get('name') or '')
                    if identifier and identifier not in failed and not any(x.get('capability_id')==identifier for x in rows):
                        rows=(*rows,{'capability_id':identifier,'traits':surface.get('traits') or ()})
            if not wanted:
                return dict(rows[0]) if rows else {'failed_provider_refs':sorted(failed),'route':'alternate_provider_required'}
            ranked = []
            for index, row in enumerate(rows):
                provided = set(str(x) for x in (row.get("traits") or ()) if str(x))
                overlap = len(wanted & provided)
                if overlap:
                    ranked.append((overlap, -len(wanted - provided), -index, row))
            return dict(max(ranked, key=lambda x: (x[0], x[1], x[2]))[3]) if ranked else {'failed_provider_refs':sorted(failed),'route':'alternate_provider_required'}
        objective = source_bound_objective(turn.command, authority)
        authority_traits = tuple(str(x) for x in (authority.get("required_capability_traits") or ()) if str(x))
        route_traits = tuple(str(x) for x in ((turn.operational_resilience or {}).get("route_plan", {}).get("required_traits") or ()) if str(x))
        routing_trait_hints = tuple(dict.fromkeys((*authority_traits, *route_traits)))
        requests: list[RuntimeActionRequest] = []
        outcome = str(authority.get("outcome_shape") or "")
        open_execution_context = self.open_execution.action_context(turn.open_execution_state or {})
        open_execution_obligation_ids = tuple(open_execution_context.get("open_action_obligation_ids") or ())
        # Host action creation is an authority boundary, not a task-shape inference.
        # Exact current-source effect authority or a source-activated open obligation
        # may actuate; derived traits/outcome/search fields remain routing hints only.
        effect_authorized = bool(source_effect_authorized(authority) or open_execution_obligation_ids)
        required_traits = routing_trait_hints if effect_authorized else ()
        if not effect_authorized:
            return ()

        def add(
            capability: str, *, traits: tuple[str, ...] = (), executor: str = "",
            parameters: dict[str, Any] | None = None, expected_effects: tuple[str, ...] = (),
            satisfies_open_execution_obligations: bool = False,
        ) -> None:
            action_route = _route_for_traits(traits,capability)
            action_executor = str(
                executor
                or action_route.get("capability_id")
                or action_route.get("provider")
                or action_route.get("plugin")
                or "host"
            )
            material = {
                "turn_id": turn.release_turn_id,
                "capability": str(capability),
                "traits": tuple(sorted(set(traits))),
                "executor": action_executor,
                "parameters": dict(parameters or {}),
            }
            action_id = "actreq_" + hashlib.sha256(
                json.dumps(material, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
            ).hexdigest()[:20]
            if action_id in completed or any(x.action_id == action_id for x in requests):
                return
            requests.append(RuntimeActionRequest(
                action_id=action_id,
                turn_id=turn.release_turn_id,
                capability=str(capability),
                executor=action_executor,
                operation=str(capability),
                required_traits=tuple(sorted(set(traits))),
                parameters={
                    "objective": objective,
                    "open_execution_obligation_ids": (open_execution_obligation_ids if satisfies_open_execution_obligations else ()),
                    "open_execution_frontier_ids": open_execution_obligation_ids,
                    "open_execution_effect_candidate": bool(satisfies_open_execution_obligations),
                    "open_execution_expansion_candidates": tuple(open_execution_context.get("expansion_candidates") or ()),
                    "open_execution_counterfactual_candidates": tuple(open_execution_context.get("counterfactual_candidates") or ()),
                    "semantic_scope_root": hashlib.sha256(
                        json.dumps(authority.get("discourse_scope") or {}, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
                    ).hexdigest(),
                    "selected_route": action_route,
                    **dict(parameters or {}),
                },
                expected_effects=tuple(expected_effects),
                evidence_requirements=("observed_host_receipt",),
                permission_class="none",
                idempotency_key=action_id,
                route_state=action_route,
            ))

        governance = dict(turn.image_generation_governance or {})
        if governance.get("should_invoke") is True:
            renders = [x for x in turn.host_observations if x.get("operation") == "media:image_generate"]
            reviews = [x for x in turn.host_observations if x.get("operation") == "media:image_review"]
            accepted = any(dict(x.get("image_quality_verdict") or {}).get("accepted") is True for x in reviews)
            if not accepted:
                render = renders[-1] if renders else None
                matching_reviews = [x for x in reviews if render and x.get("parameters",{}).get("render_action_id") == render["action_id"]]
                reviewed = bool(matching_reviews and not dict(matching_reviews[-1].get("image_quality_verdict") or {}).get("review_required"))
                if not render or render.get("success") is not True or reviewed:
                    iteration = len(renders)
                    add("media:image_generate", traits=("image_generation",), parameters={
                        "image_generation_governance":governance,"quality_iteration":iteration,
                        "target_refs":governance.get("target_refs",[]),"prompt":turn.command,
                        "render_directive":governance.get("render_directive",{}),
                        "prior_quality_verdict":reviews[-1].get("image_quality_verdict") if reviews else None},
                        expected_effects=("image_render_observed",))
                else:
                    add("media:image_review", traits=("image_review",), parameters={
                        "image_generation_governance":governance,"render_action_id":render["action_id"],
                        "render_observation":render.get("result"),"quality_iteration":len(renders)-1,
                        "review_iteration":len(matching_reviews),
                        "requirement_ids":governance.get("requirement_ids",[]),
                        "requirement_message_sha256":turn.command_sha256},
                        expected_effects=("independent_image_quality_observation",), satisfies_open_execution_obligations=True)

        traits = set(required_traits)
        direct_execution_can_close = bool(open_execution_obligation_ids and outcome != "build_artifact")
        if traits & {"remote_compute", "remote_computer"}:
            add(
                "compute:remote_exec", traits=required_traits, expected_effects=("external_execution_observed",),
                satisfies_open_execution_obligations=direct_execution_can_close,
            )
        elif traits & {"code_execution", "terminal", "filesystem", "persistent_workspace"}:
            add(
                "compute:exec", traits=required_traits, expected_effects=("external_execution_observed",),
                satisfies_open_execution_obligations=direct_execution_can_close,
            )

        if bool(authority.get("signed_in_browser_preferred")):
            add(
                "browser:signed_in_observe", traits=("authenticated_browser",), expected_effects=("browser_observation",),
                satisfies_open_execution_obligations=True,
            )
        elif bool(authority.get("public_browser_interaction_required")):
            add(
                "browser:interact", traits=("browser_interaction",), expected_effects=("browser_observation",),
                satisfies_open_execution_obligations=True,
            )

        if bool(authority.get("search_required")) or "personal_knowledge" in tuple(authority.get("source_families") or ()):
            families = tuple(str(x) for x in (authority.get("source_families") or ()) if str(x)) or ("web_current",)
            for family in families:
                from jigaewol_components.search_portfolio_engine import SearchPortfolioEngine
                add(
                    f"search:{family}", traits=("personal_knowledge",) if family=='personal_knowledge' else ("web_search",), parameters={"source_family": family,
                        "query_program":SearchPortfolioEngine.compile_query_program(objective,family),
                        "queries":SearchPortfolioEngine.compile_concrete_queries(objective,family)},
                    expected_effects=("search_observation",), satisfies_open_execution_obligations=True,
                )

        if bool(authority.get("search_required")):
            for frontier in self.search_evidence_graph.pending(turn.command_sha256):
                add("search:" + frontier["source_family"], traits=("personal_knowledge",) if frontier['source_family']=='personal_knowledge' else ("web_search",),
                    parameters=frontier, expected_effects=("search_observation",),
                    satisfies_open_execution_obligations=bool(frontier.get('required')))

        if outcome == "build_artifact" and bool(authority.get("execution_experiment_required")):
            add(
                "state:write_artifact", traits=("filesystem",), expected_effects=("artifact_materialized",),
                satisfies_open_execution_obligations=True,
            )
        elif outcome == "schedule_manage":
            add(
                "schedule:manage", traits=("calendar_write",), expected_effects=("schedule_effect_observed",),
                satisfies_open_execution_obligations=True,
            )
        elif outcome == "grow_presence":
            add(
                "presence:manage", traits=("social_publish",), expected_effects=("presence_effect_observed",),
                satisfies_open_execution_obligations=True,
            )

        if bool(authority.get("external_capability_required")) and not requests and not completed:
            # Discovery is one replaceable execution candidate, never a proof that the
            # registered capability vocabulary is complete.
            add("capability:discover_execute", traits=required_traits, expected_effects=("capability_observation",))
        if open_execution_obligation_ids and not requests:
            # An exact user action obligation cannot collapse into narration merely because
            # the current planner/registry produced no route. Hand the host an open-set
            # materialization request carrying representation/counterfactual candidates.
            add(
                "capability:discover_execute",
                traits=required_traits,
                parameters={"open_ended_execution_search": True},
                expected_effects=("observed_execution_or_scoped_negative_evidence",),
            )
        return tuple(requests)

    def _schedule_ready_nodes(self, work_program):
        default_ready = self.work_program_runtime.next_ready(work_program)
        resolved = self.mutation_runtime.resolve_component("scheduler", default_program_ref="")
        program_ref = str(resolved.get("program_ref") or "")
        if not program_ref:
            return default_ready
        try:
            scheduled = self.mutation_runtime.execute_program_ref(program_ref, {
                "work": work_program.as_mapping(),
                "default_ready_node_ids": tuple(x.node_id for x in default_ready),
            })
            selected_ids = tuple(map(str, scheduled.get("ready_node_ids") or ()))
            if not selected_ids:
                return default_ready
            by_id = {x.node_id: x for x in work_program.nodes}
            selected = tuple(by_id[x] for x in selected_ids if x in by_id and by_id[x].state == "ready")
            return selected or default_ready
        except Exception:
            return default_ready


    def reconsider(self, turn: CoreTurn, *, candidate_generator=None):
        """Run pre-generation cognition that can change the next sealed cognition request."""
        return self._run_exploration_escalation(turn, candidate_generator=candidate_generator)

    def derive_next_cognition(self, turn: CoreTurn, *, foundation_semantic_agenda=(), returned_candidates=(), profile_mode: str = "STANDARD"):
        """Build the complete hash-bound GenerationRequest for the next cognition transition."""
        tournament = dict(turn.representation_tournament or {})
        frames = tuple(tournament.get("frames") or ())
        cognitive_worlds = tuple({
            "world_id": str(frame.get("frame_id") or f"frame_{index}"),
            "mode": str(frame.get("mode") or "representation"),
            "instruction": str(frame.get("instruction") or ""),
            "purpose": str(frame.get("purpose") or ""),
            "preserve_goal": bool(frame.get("preserve_goal", True)),
            "epistemic_state": "speculative_influence_allowed",
        } for index, frame in enumerate(frames) if str(frame.get("frame_id") or "") != "original")
        universe_worlds = tuple(
            dict(w) for w in (turn.ephemeral_universe or {}).get("worlds", ()) if isinstance(w, Mapping)
        )
        if universe_worlds:
            cognitive_worlds = tuple((*cognitive_worlds, *universe_worlds))
            self.trace.emit(
                turn_id=turn.release_turn_id, phase="COGNITION", status="INJECTED",
                component="EphemeralUniverseEngine", action="axiom_breaking_worlds_injected_into_generation",
                details={
                    "world_count": len(universe_worlds),
                    "breaker_count": turn.ephemeral_universe.get("breaker_count"),
                    "breaker_ids_sha256": turn.ephemeral_universe.get("breaker_ids_sha256"),
                    "organogenesis_handoff": turn.ephemeral_universe.get("organogenesis_handoff"),
                },
            )
        wild_worlds = WildCognitivePlane.generation_worlds(dict(getattr(turn, "wild_cognitive_plan", {}) or {}))
        if wild_worlds:
            cognitive_worlds = tuple((*cognitive_worlds, *wild_worlds))

        strategy_rows = tuple(turn.exploration_ecology.get("strategy_portfolio", {}).get("strategies", ()))
        if strategy_rows and turn.openness_contract.get("active"):
            strategy_instruction = "\\n".join(
                f"- {row.get('strategy_id')}: {row.get('instruction')}" for row in strategy_rows
            )
            cognitive_worlds = tuple((*cognitive_worlds, {
                "world_id": "open_strategy_ecology",
                "mode": "strategy_ecology",
                "instruction": (
                    "Treat every listed strategy as a live possibility, not a checklist or winner-take-all ranking. "
                    "Use any combination that changes the reachable solution space. If they converge, invent a task-local operator.\\n"
                    + strategy_instruction
                ),
                "purpose": "keep nonconforming routes and new operator invention causally connected to final generation",
                "preserve_goal": True,
                "epistemic_state": "speculative_influence_allowed",
            }))
        for family in ("search", "routing", "creative", "style", "skills"):
            revision = self.policy_evolution.active_revision(family)
            if revision["candidate_id"]:
                cognitive_worlds = (*cognitive_worlds, {"world_id":"active:"+revision["candidate_id"],
                    "mode":"activated_operator_policy", "instruction":json.dumps(revision["policy"],ensure_ascii=False),
                    "policy_revision":revision["candidate_id"], "preserve_goal":True})
        # The deepest user-requested aim is expansion of *cognition itself*.
        # Materialize the donor-backed frontier into the actual GenerationRequest,
        # rather than leaving it as metadata behind tool and validation branches.
        cognitive_plan = dict(turn.cognitive_os or {})
        creative = dict(cognitive_plan.get('creativity_policy') or {})
        frontier = dict(creative.get('host_cognitive_frontier') or {})
        if frontier and creative.get('user_requested_cognitive_escalation'):
            cognitive_worlds = (*cognitive_worlds, {
                'world_id': 'user_goal_model_cognitive_frontier',
                'mode': 'source_first_divergent_generation',
                'instruction': (
                    'Develop original, materially distinct representations and causal '
                    'approaches to the entire exact user objective. Include a native '
                    'solution, a representation invented beyond the existing taxonomy, '
                    'a counterexample to inherited assumptions, a cross-domain transfer, '
                    'a first-principles reconstruction, and a deceptively small '
                    'high-leverage intervention when useful. Preserve qualitatively '
                    'different unresolved possibilities rather than flattening them. '
                    'Do not substitute tool selection for cognitive invention; any tool '
                    'is an optional actuator for a generated causal mechanism. '
                    'Carry at least one distinctive causal hypothesis into the actual '
                    'candidate result and keep the exact source as the goal.'
                ),
                'source_sha256': frontier.get('source_sha256'),
                'branch_ids': frontier.get('branch_ids'),
                'preserve_goal': True,
                'epistemic_state': 'speculative_generation_welcome_actual_claims_observed',
            })
        effective_objective = source_bound_objective(turn.command, turn.semantic_authority)
        from jigaewol_components.execution_cost_policy import execution_policy
        zero_spend_policy=execution_policy()
        self.requirements.admit(turn.command)
        generation_requirement_contract = self._generation_requirement_projection(turn)
        request = GenerationRequest(
            objective=effective_objective,
            evidence={
                "execution_cost_policy": zero_spend_policy,
                "free_execution_routes": self.free_routes.routes(),
                "requirement_status": self.requirements.status(turn.command_sha256),
                "project_requirement_backlog": self.requirements.backlog(),
                "search_evidence_graph": self.search_evidence_graph.summary(turn.command_sha256),
                "observed_candidate_synthesis": self.candidate_lab.synthesize(turn.command_sha256),
                "personal_experiences": self.candidate_lab.recall(str(turn.semantic_authority.get("task_shape") or "task")),
                "active_policy_revisions": {family: self.policy_evolution.active_revision(family) for family in ("search", "routing", "creative", "style", "skills")},
                "production_request":self.turn_production.begin(turn.command,turn.release_turn_id),
                "foundation_turn_id": turn.foundation_turn_id,
                "foundation_semantic_agenda": tuple(foundation_semantic_agenda or ()),
                "route": turn.execution_route_composition,
                "fabric": turn.execution_fabric_plan,
                "trace_anchor": {
                    "release_turn_id": turn.release_turn_id,
                    "foundation_turn_id": turn.foundation_turn_id,
                    "foundation_receipt_id": turn.foundation_receipt_id,
                    "command_sha256": turn.command_sha256,
                },
                "host_observations": turn.host_observations,
                "exploration_results": tuple(x.as_mapping() for x in returned_candidates),
                "exploration_state": turn.exploration_decision.get("state"),
                "cognitive_os": self._generation_cognitive_projection(turn),
                "openness_contract": turn.openness_contract,
                "possibility_plan": turn.possibility_plan,
                "exploration_ecology": self._generation_exploration_projection(turn),
                "ephemeral_universe": {
                    "active": bool(turn.ephemeral_universe.get("active")),
                    "pipeline": turn.ephemeral_universe.get("pipeline"),
                    "breaker_count": turn.ephemeral_universe.get("breaker_count"),
                    "breaker_ids_sha256": turn.ephemeral_universe.get("breaker_ids_sha256"),
                    "organogenesis_handoff": turn.ephemeral_universe.get("organogenesis_handoff"),
                    "organogenesis_materialization": turn.ephemeral_universe.get("organogenesis_materialization"),
                },
            },
            route_state=turn.operational_resilience,
            response_contract={
                "authority_order": ("USER", "JIGAEWOL", "MODEL"),
                "exact_current_user_text": turn.command,
                "exact_current_user_text_sha256": turn.command_sha256,
                "requirement_contract": generation_requirement_contract,
                "goal_anchor": turn.goal_anchor,
                "possibility_plan": turn.possibility_plan,
                "exploration_state": turn.exploration_decision.get("state"),
                "multimodal_state": dict(turn.multimodal_state or {}),
                "image_generation_governance": dict(turn.image_generation_governance or {}),
            },
            execution_profile=profile_mode,
            cognitive_worlds=cognitive_worlds,
            falsification_questions=tuple(
                f"What evidence would falsify the {w['world_id']} representation?" for w in cognitive_worlds
            ),
            counterframes=tuple(str(w.get("instruction") or "") for w in cognitive_worlds),
        )
        return request, cognitive_worlds, tournament, effective_objective

    def verify_candidate(self, *, turn: CoreTurn, request: GenerationRequest, generated: Any, semantic_verifiers=None) -> dict[str, Any]:
        """Verify one exact candidate against its exact request/evidence and requirement contract."""
        effective_objective = str(request.objective)
        observed_boundary = any(
            isinstance(obs, Mapping) and (
                obs.get("hard_boundary_observed") is True
                or obs.get("boundary_proven") is True
                or str(obs.get("boundary_evidence_state") or "").casefold() in {"proven", "observed"}
            )
            for obs in (turn.host_observations or ())
        )
        boundary_verdict = PossibilityPressure.evaluate(
            objective=effective_objective, candidate=generated.candidate_body, cognitive_os=turn.cognitive_os,
            semantic_authority=turn.semantic_authority, observed_boundary=observed_boundary,
        )
        self.trace.emit(
            turn_id=turn.release_turn_id, phase="FRONTIER_CLOSURE",
            status="PASSED" if boundary_verdict.route_expansion_ready else "BLOCKED",
            component="PossibilityPressure", action="expand_routes_before_global_closure",
            details={"findings": boundary_verdict.findings, "claim_count": len(boundary_verdict.closure_phrases)},
        )
        checks = self.semantic.verify(
            objective=effective_objective, candidate=generated.candidate_body,
            evidence=request.evidence, verifiers=semantic_verifiers,
        )
        # Authority fidelity is not an advisory style check.  A candidate may report
        # an execution constraint, but it may not convert that constraint into a new,
        # smaller user destination.  The durable Work graph is the scope authority.
        scope_verdict = ScopeIntegrityGuard.evaluate(
            response_text=generated.candidate_body, work_program=turn.work_program or {},
            observations=turn.host_observations, source_text=turn.command,
        )
        scope_check = VerificationResult(
            verifier_id="scope_integrity_guard",
            failure_family="directive_fidelity",
            success=scope_verdict.ok,
            findings=scope_verdict.findings,
            evidence=scope_verdict.as_mapping(),
        )
        checks = tuple((*checks, scope_check))
        summary = self.semantic.summary(checks)
        task_kind = classify_task_kind(effective_objective, request.evidence)
        coverage = evaluate_verification_coverage(task_kind, checks)
        requirement_contract_obj = RequirementCompiler.from_mapping(self._active_requirement_contract(turn))
        response_coverage = RequirementCompiler.assess_response_coverage(requirement_contract_obj, generated.candidate_body)
        verification_ok = bool(
            summary["all_applicable_passed"]
            and coverage.state not in {"failed", "insufficient_coverage"}
            and response_coverage.ok
            and boundary_verdict.route_expansion_ready
        )
        summary = {
            **summary, "task_kind": task_kind, "coverage_state": coverage.state,
            "coverage_reason": coverage.reason,
            "requirement_response_coverage_ok": response_coverage.ok,
            "requirement_response_missing_ids": response_coverage.missing_ids,
            "requirement_response_findings": response_coverage.findings,
            "scope_integrity_ok": scope_verdict.ok,
            "scope_integrity_findings": scope_verdict.findings,
            "scope_integrity_live_requirement_count": scope_verdict.live_requirement_count,
            # Verification may trigger a repair pass, but it is not a permission gate
            # over the user-facing response. Truth/execution uncertainty must be stated,
            # not converted into a system veto.
            "verification_is_advisory": True,
            "frontier_closure_claim_unproven": not boundary_verdict.route_expansion_ready,
            "frontier_closure_findings": tuple(boundary_verdict.findings),
            "response_release_blocked_by_verification": False,
        }
        return {
            "ok": verification_ok, "summary": summary, "checks": checks,
            "task_kind": task_kind, "requirement_contract_obj": requirement_contract_obj,
            "boundary_verdict": boundary_verdict,
        }

    @staticmethod
    def _truth_release_policy(checks: Any) -> dict[str, Any]:
        """Separate truth/nonsense rejection from ordinary advisory quality checks.

        Only failures tied to objective nonsense, deterministic falsity, structural
        emptiness, or explicit truth/evidence families may suppress a candidate.
        Unknown/secondary quality judgments may annotate uncertainty but cannot act
        as a general-purpose veto over the user's requested answer.
        """
        hard_truth_families = {
            "structural_validation",
            "deterministic_execution",
            "source_entailment",
            "execution_evidence",
            "factuality",
            "factual_grounding",
            "citation_entailment",
            "directive_fidelity",
        }
        hard = []
        advisory = []
        for row in tuple(checks or ()):
            if row.success is True or "not_applicable" in tuple(row.findings or ()):
                continue
            entry = {
                "verifier_id": row.verifier_id,
                "failure_family": row.failure_family,
                "success": row.success,
                "findings": tuple(row.findings or ()),
            }
            manifest_nonsense = (
                row.failure_family == "semantic_relevance"
                and row.success is False
                and "manifestly_irrelevant_nonsense" in tuple(row.findings or ())
            )
            if row.success is False and (row.failure_family in hard_truth_families or manifest_nonsense):
                hard.append(entry)
            else:
                advisory.append(entry)
        return {
            "suppress_candidate": bool(hard),
            "hard_truth_failures": tuple(hard),
            "advisory_failures": tuple(advisory),
        }

    @staticmethod
    def derive_repair(*, current_request: GenerationRequest, generated: Any, checks: Any,
                      frontier_closure_unproven: bool, repair_attempt: int) -> GenerationRequest:
        """Turn failed verification into the next cognition request without rewriting the goal."""
        failed_findings = tuple(
            {
                "verifier_id": row.verifier_id,
                "failure_family": row.failure_family,
                "success": row.success,
                "findings": row.findings,
            }
            for row in checks
            if row.success is not True and "not_applicable" not in row.findings
        )
        return replace(
            current_request,
            evidence={**dict(current_request.evidence), "verification_feedback": failed_findings,
                      "prior_candidate": generated.candidate_body, "repair_attempt": repair_attempt,
                      "verification_subject_request_sha256": current_request.sha256(),
                      "verification_subject_candidate_sha256": _sha_text(generated.candidate_body)},
            response_contract={
                **dict(current_request.response_contract),
                "revision_after_verification_failure": True,
                "preserve_goal_during_revision": True,
                "repair_failed_verifier_families_without_collapsing_speculative_search": True,
                "frontier_closure_claim_unproven": frontier_closure_unproven,
                "do_not_declare_global_impossibility_while_untried_routes_remain": True,
                "repair_attempt": repair_attempt,
            },
        )

    @staticmethod
    def prepare_finalization(turn: CoreTurn, generated: Any, verification_summary: Mapping[str, Any]) -> dict[str, Any]:
        """Produce immutable finalization inputs; quality verification is annotation, not permission."""
        # Truth verification and user-objective completion are independent. A failed
        # verifier annotates uncertainty; it does not acquire veto power over release.
        # Only missing requested content keeps the user objective open.
        execution_completion = OpenEndedExecutionKernel.evaluate_completion(turn.open_execution_state or {})
        work_completion = WorkProgramRuntime.objective_completion_evidence(
            WorkProgramRuntime.from_mapping(dict(turn.work_program or {}))
        )
        objective_completion_required = bool(
            dict(turn.semantic_authority or {}).get("source_effect_authorized") is True
        )
        objective_satisfied = bool(
            verification_summary.get("requirement_response_coverage_ok", True) is True
            and not dict(getattr(generated, "metadata", {}) or {}).get("truth_candidate_suppressed")
            and execution_completion.get("execution_obligations_satisfied") is True
            and (not objective_completion_required or work_completion.get("proven") is True)
        )
        return {
            "turn_id": turn.release_turn_id,
            "response_sha256": _sha_text(generated.candidate_body),
            "requirement_contract_sha256": str((turn.active_requirement_contract or turn.requirement_contract or {}).get("contract_sha256") or ""),
            "observation_chain_sha256": _sha_text(json.dumps(list(turn.host_observations or ()), ensure_ascii=False, sort_keys=True, default=str)) if turn.host_observations else "",
            "terminal_semantics": "SOLVED" if objective_satisfied else "INCOMPLETE",
            "user_objective_satisfied": objective_satisfied,
            "execution_obligations_satisfied": bool(execution_completion.get("execution_obligations_satisfied")),
            "open_execution_obligation_ids": tuple(execution_completion.get("open_execution_obligation_ids") or ()),
            "objective_completion_required": objective_completion_required,
            "objective_completion_proven": bool(work_completion.get("proven")),
            "objective_completion_evidence_refs": tuple(work_completion.get("evidence_refs") or ()),
            "objective_completion_unresolved_goal_refs": tuple(work_completion.get("unresolved_goal_refs") or ()),
            "verification_state": "passed" if verification_summary.get("all_applicable_passed") is True else "open",
        }

    def run_turn(self, command: str, *, capabilities=None, attachments=(), host_executor=None,
                 candidate_generator=None, semantic_verifiers=None, max_host_steps: int | None = None,
                 host_unavailable: str = "raise", resume_turn: CoreTurn | None = None, defer_release: bool = False, **kwargs):
        """Canonical closed loop: ingress -> execute -> generate -> verify -> release.

        The runtime coordinates candidate generation as a revocable implementation of
        the current user directive. A model/solver is a replaceable component, not an
        already-finished answer handed to the release gate. Host work is
        executed only through the supplied executor and every execution is traced.

        `host_unavailable` decides what happens when execution is still owed.
        "raise" (the default) keeps the turn resumable for a caller that can connect a
        host and try again. "preserve_open" returns an explicit incomplete state and
        does *not* generate a downgraded answer from an unexecuted plan.
        """
        if host_unavailable not in ("raise", "preserve_open"):
            raise ValueError("host_unavailable must be 'raise' or 'preserve_open'")
        if capabilities is not None:
            self._current_host_surface = tuple(capabilities)
        turn = self.prepare_turn(
            command, capabilities=capabilities, attachments=attachments, resume_turn=resume_turn, **kwargs
        )
        profile_mode = str(turn.execution_profile.get("mode") or "DEEP").upper()
        route_plan = turn.operational_resilience.get("route_plan", {})
        missing_execution_traits = tuple(route_plan.get("missing_traits", ()))
        required_execution_traits = tuple(route_plan.get("required_traits", ()))
        # Semantic foundation work is cognition, never an external side effect.
        # Partition it out even on turns that also need real tools; otherwise the
        # causal loop would misroute semantic interpretation through ActionPort.
        semantic_work = tuple(w for w in turn.next_work if str(getattr(w, "executor", "")) == "host_semantic")
        external_work = tuple(w for w in turn.next_work if str(getattr(w, "executor", "")) != "host_semantic")
        foundation_semantic_agenda: tuple[dict[str, Any], ...] = tuple(turn.foundation_semantic_agenda or ())
        if semantic_work and not foundation_semantic_agenda:
            from jigaewol_runtime.bridge.semantic_request import build_semantic_request
            foundation_semantic_agenda = tuple(build_semantic_request(work).to_dict() for work in semantic_work)
            self.trace.emit(
                turn_id=turn.release_turn_id, phase="COGNITION", status="INJECTED", component="CoreRuntime",
                action="foundation_semantic_work_injected_into_generation",
                details={"semantic_work_count": len(foundation_semantic_agenda), "operations": tuple(x.get("operation") for x in foundation_semantic_agenda)},
            )
        if semantic_work:
            turn = replace(turn, next_work=external_work, foundation_semantic_agenda=foundation_semantic_agenda)
            self._turns[turn.core_turn_id] = turn
            self._persist_turn(turn)
        envelope_obj = derive_resource_envelope(
            latency_target_ms=int(turn.resource_envelope.get("latency_target_ms", self.latency_target_ms)),
            capability_count=int(turn.resource_envelope.get("capability_count", 0)),
            uncertainty=float(turn.resource_envelope.get("uncertainty", 0.5)),
            urgency=float(turn.resource_envelope.get("urgency", 0.5)),
            cpu_count=int(turn.resource_envelope.get("cpu_count", 1)),
        )
        derived_horizon = derive_execution_horizon(
            envelope_obj, profile_mode, pending_work_count=max(len(turn.next_work), len(self.derive_actions(turn)))
        )
        # The derived horizon is telemetry/scheduling guidance, not a default stop
        # condition. Only an explicit caller max_host_steps imposes a hard ceiling.
        horizon = None if max_host_steps is None else max(0, int(max_host_steps))
        steps=0

        def _record_resource_local_negative(code: str, detail: str, scope_ref: str) -> None:
            nonlocal turn
            open_state = self.open_execution.record_negative(
                message_sha256=turn.command_sha256, scope_kind="execution_resource_window",
                scope_ref=scope_ref, detail=detail, representation_ref=str((turn.representation_program or {}).get("representation_id") or ""),
                provider_ref="current_host", code=code,
            )
            turn = replace(turn, open_execution_state=open_state)
            self._turns[turn.core_turn_id] = turn
            self._persist_turn(turn)

        while self.derive_actions(turn):
            if host_executor is None:
                _record_resource_local_negative(
                    "THIS_HOST_PATH_REJECTED_NO_EXECUTOR",
                    "No host executor is bound in this execution process; the user goal remains live and alternate/materialized host paths remain searchable.",
                    "host_executor_unbound",
                )
                self.trace.emit(turn_id=turn.release_turn_id, phase="EXECUTION", status="BLOCKED", component="CoreRuntime",
                                action="host_executor_required", details={"pending_work": len(turn.next_work)})
                if host_unavailable == "preserve_open":
                    return {
                        "turn": turn,
                        "generation": None,
                        "verification": {
                            "state": "not_run_pending_execution",
                            "response_release_blocked_by_verification": False,
                            "user_objective_remains_open": True,
                        },
                        "released": None,
                        "incomplete": True,
                        "open_obligations": tuple(
                            getattr(work, "operation", "host_execution") for work in turn.next_work
                        ),
                        "trace": self.trace.status(turn.release_turn_id),
                        "trace_digest": self.trace.digest(turn.release_turn_id),
                    }
                raise RuntimeError("turn requires host execution but no host_executor is connected")
            if horizon is not None and steps >= horizon:
                _record_resource_local_negative(
                    "SEARCH_BATCH_EXHAUSTED",
                    f"Execution resource window exhausted after {steps} host steps; this is resource telemetry, not a possibility judgment.",
                    f"host_step_window:{horizon}",
                )
                if host_unavailable == "preserve_open":
                    self.trace.emit(turn_id=turn.release_turn_id, phase="EXECUTION", status="BLOCKED",
                                    component="CoreRuntime", action="host_work_blocked_goal_preserved",
                                    details={"steps": steps, "derived_horizon": horizon,
                                             "unexecuted_work": len(turn.next_work)})
                    return {
                        "turn": turn,
                        "generation": None,
                        "verification": {
                            "state": "not_run_execution_window_exhausted",
                            "response_release_blocked_by_verification": False,
                            "user_objective_remains_open": True,
                        },
                        "released": None,
                        "incomplete": True,
                        "open_obligations": tuple(
                            getattr(work, "operation", "host_execution") for work in turn.next_work
                        ),
                        "trace": self.trace.status(turn.release_turn_id),
                        "trace_digest": self.trace.digest(turn.release_turn_id),
                    }
                self.trace.emit(turn_id=turn.release_turn_id, phase="EXECUTION", status="RESUMABLE", component="CoreRuntime",
                                action="resource_window_reached", details={"steps":steps,"derived_horizon":horizon})
                raise RuntimeError("SEARCH_BATCH_EXHAUSTED: execution resource window reached; user goal remains resumable")
            action = self.derive_actions(turn)[0]
            try:
                result = host_executor(action)
                turn = self.accept_observation(turn, action, result)
            except Exception as exc:
                if exc.__class__.__name__ == "ActionPending":
                    raise
                # An observed exception is still a causal observation. Record it as
                # failure rather than falling back to the legacy Foundation work path.
                turn = self.accept_observation(
                    turn, action, {"success": False, "error_type": type(exc).__name__, "error": str(exc)},
                )
            steps += 1

        # Delegation changes interaction style only. There is deliberately no
        # alternate completion/release branch here: all work follows the same
        # exploration, verification, observation, and objective-evidence path.

        # The exploration escalation, when open, runs *before* user-facing generation. Its full
        # scratch never enters the mainline; only ExplorationResultFilter-selected candidates do.
        turn, returned_candidates = self.reconsider(turn, candidate_generator=candidate_generator)
        request, cognitive_worlds, tournament, effective_objective = self.derive_next_cognition(
            turn, foundation_semantic_agenda=foundation_semantic_agenda,
            returned_candidates=returned_candidates, profile_mode=profile_mode,
        )
        if cognitive_worlds and (profile_mode == "DEEP" or tournament.get("active") is True):
            materialize_all_worlds = bool(
                turn.semantic_authority.get("representation_search_required")
                or turn.openness_contract.get("frontier_mode")
            )
            scheduled_world_count = len(cognitive_worlds)
            portfolio=self.semantic.generate_portfolio(
                request, generator=candidate_generator, max_worlds=scheduled_world_count,
            )
            portfolio = self._incubate_generation_portfolio(
                turn, request, portfolio, candidate_generator=candidate_generator
            )
            tournament_verdict = self._adjudicate_generation_portfolio(
                turn, request, portfolio, candidate_generator=candidate_generator
            )
            synthesis_request = replace(
                request,
                evidence={**dict(request.evidence), "tournament_adjudication": tournament_verdict},
                response_contract={
                    **dict(request.response_contract),
                    "tournament_adjudication_active": bool(tournament_verdict.get("active")),
                    "tournament_decided": bool(tournament_verdict.get("decided")),
                    "repair_converged_portfolio_before_closure": not bool(tournament_verdict.get("decided")),
                    "do_not_claim_independent_deliberation_when_candidates_converged": True,
                },
            )
            generated=self.semantic.synthesize(synthesis_request, portfolio, generator=candidate_generator)
        else:
            generated=self.semantic.generate(request, generator=candidate_generator)
        self.trace.emit(turn_id=turn.release_turn_id, phase="CANDIDATE_GENERATION", status="SUCCEEDED", component="SemanticCandidateEngine",
                        action="runtime_owned_candidate_generation", receipt_id=generated.generation_id,
                        details={"producer_id":generated.producer_id,"candidate_sha256":_sha_text(generated.candidate_body),"generation_metadata":generated.metadata})
        verification = self.verify_candidate(
            turn=turn, request=request, generated=generated, semantic_verifiers=semantic_verifiers
        )
        boundary_verdict = verification["boundary_verdict"]
        checks = verification["checks"]
        summary = verification["summary"]
        task_kind = verification["task_kind"]
        requirement_contract_obj = verification["requirement_contract_obj"]
        verification_ok = bool(verification["ok"])
        self.audit.attach_runtime(turn.release_turn_id, run_id=generated.generation_id, subsystem="semantic_candidate_generation", success=True,
                                 evidence={"producer_id":generated.producer_id,"candidate_sha256":_sha_text(generated.candidate_body),"generation_metadata":generated.metadata})
        self.audit.attach_runtime(turn.release_turn_id, run_id=generated.generation_id, subsystem="semantic_quality_annotation",
                                 success=True, evidence=summary)
        self.trace.emit(turn_id=turn.release_turn_id, phase="VERIFICATION", status="ANNOTATED",
                        component="SemanticCandidateEngine", action="quality_evidence_annotation",
                        receipt_id=generated.generation_id, details=summary)
        # Verification failure is a causal transition, not a one-shot annotation.
        # Re-enter cognition for the current execution verification window. Exhausting
        # that window yields a truthful INCOMPLETE/resumable state; it is not a semantic
        # impossibility claim and it never releases an unverified candidate.
        frontier_closure_unproven = not boundary_verdict.route_expansion_ready
        summary = {
            **summary,
            "frontier_closure_claim_unproven": frontier_closure_unproven,
            "frontier_closure_findings": tuple(boundary_verdict.findings),
            "repair_attempts": 0,
            "verification_window": int(envelope_obj.verification_budget),
            "verification_window_is_execution_telemetry_not_semantic_ceiling": True,
        }
        repair_attempts = 0
        current_request = request
        while not verification_ok or frontier_closure_unproven:
            if repair_attempts >= int(envelope_obj.verification_budget):
                summary = {
                    **summary,
                    "repair_attempts": repair_attempts,
                    "response_release_blocked_by_verification": False,
                    "verification_is_advisory": True,
                    "terminal_semantics": "released_with_open_verification",
                    "open_obligations": ("semantic_verification",),
                    "truth_claim_boundary": "unverified_or_failed_checks_must_not_be_presented_as_proven_fact",
                }
                self.trace.emit(
                    turn_id=turn.release_turn_id, phase="RELEASE", status="ANNOTATED",
                    component="SemanticCandidateEngine", action="verification_window_exhausted_release_with_annotation",
                    receipt_id=generated.generation_id, details=summary,
                )
                # Verification is truth telemetry, not general permission over the
                # user's answer. Only concrete falsity/nonsense/evidence failures may
                # suppress a candidate. Other unresolved checks are labeled and released.
                release_policy = self._truth_release_policy(checks)
                failed_labels = []
                for row in checks:
                    if row.success is not True and "not_applicable" not in row.findings:
                        failed_labels.append(f"{row.verifier_id}: {', '.join(row.findings) or 'unverified'}")
                annotation = (
                    "[검증 미완료: "
                    + ("; ".join(failed_labels) if failed_labels else "일부 사실·요구 충족 여부가 아직 확인되지 않음")
                    + "]"
                )
                if release_policy["suppress_candidate"]:
                    generated = replace(
                        generated,
                        candidate_body=(
                            "원래 사용자 요구와 범위는 그대로 유지합니다. 현재 후보가 그 범위를 임의로 "
                            "줄였거나, 명백한 오류·무관한 헛소리 또는 증거 충돌이 감지되어 후보를 폐기했습니다. "
                            "실행되지 않은 요구는 삭제하지 않고 미충족/open 상태로 남깁니다. "
                            + annotation
                        ),
                        metadata={
                            **dict(generated.metadata),
                            "truth_candidate_suppressed": True,
                            "hard_truth_failures": release_policy["hard_truth_failures"],
                        },
                    )
                else:
                    generated = replace(
                        generated,
                        candidate_body=annotation + "\n\n" + generated.candidate_body,
                        metadata={
                            **dict(generated.metadata),
                            "truthful_annotation_after_failed_verification": True,
                            "unverified_candidate_preserved": True,
                            "advisory_failures": release_policy["advisory_failures"],
                        },
                    )
                break
            failed_findings = tuple(
                {
                    "verifier_id": row.verifier_id,
                    "failure_family": row.failure_family,
                    "success": row.success,
                    "findings": row.findings,
                }
                for row in checks
                if row.success is not True and "not_applicable" not in row.findings
            )
            repair_attempts += 1
            revision_request = self.derive_repair(
                current_request=current_request, generated=generated, checks=checks,
                frontier_closure_unproven=frontier_closure_unproven, repair_attempt=repair_attempts,
            )
            self.trace.emit(
                turn_id=turn.release_turn_id, phase="REVISION", status="RETRYING",
                component="SemanticCandidateEngine", action="verification_failure_changes_next_cognition",
                receipt_id=generated.generation_id, details={"failed_findings": failed_findings, "repair_attempt": repair_attempts},
            )
            revised = self.semantic.generate(revision_request, generator=candidate_generator)
            revised_verification = self.verify_candidate(
                turn=turn, request=revision_request, generated=revised, semantic_verifiers=semantic_verifiers
            )
            revised_checks = revised_verification["checks"]
            revised_boundary = revised_verification["boundary_verdict"]
            revised_ok = bool(revised_verification["ok"])
            revised_summary = {
                **revised_verification["summary"],
                "revision_attempted": True, "previous_generation_id": generated.generation_id,
                "repair_attempts": repair_attempts,
                "verification_window": int(envelope_obj.verification_budget),
                "verification_window_is_execution_telemetry_not_semantic_ceiling": True,
            }
            self.audit.attach_runtime(
                turn.release_turn_id, run_id=revised.generation_id,
                subsystem="semantic_revision_after_verification",
                success=True, evidence=revised_summary,
            )
            self.trace.emit(
                turn_id=turn.release_turn_id, phase="REVISION",
                status="SUCCEEDED" if revised_ok else "ANNOTATED",
                component="SemanticCandidateEngine", action="causal_semantic_revision",
                receipt_id=revised.generation_id, details=revised_summary,
            )
            generated = revised
            checks = revised_checks
            summary = revised_summary
            current_request = revision_request
            verification_ok = revised_ok
            frontier_closure_unproven = not revised_boundary.route_expansion_ready
        finalization_prep = self.prepare_finalization(turn, generated, summary)
        if defer_release:
            return {"turn":turn,"generation":generated,"verification":summary,"released":None,
                    "release_deferred":True,"finalization_prep":finalization_prep,
                    "trace":self.trace.status(turn.release_turn_id),
                    "trace_digest":self.trace.digest(turn.release_turn_id)}
        released=self.release(turn, generated.candidate_body, producer=generated.producer_id)
        return {"turn":turn,"generation":generated,"verification":summary,"released":released,"trace":self.trace.status(turn.release_turn_id),"trace_digest":self.trace.digest(turn.release_turn_id)}



    def status(self, turn: CoreTurn | str) -> dict[str, Any]:
        tid=turn.release_turn_id if isinstance(turn,CoreTurn) else str(turn)
        return self.trace.status(tid)









    def audit_turn(self, turn: CoreTurn) -> dict[str, Any]:
        foundation = self.foundation.verify_ingress_receipt(
            turn.foundation_receipt_id, message=turn.command, turn_id=turn.foundation_turn_id
        )
        release_state = self.audit.read_verified_turn(turn.release_turn_id)
        return {
            "core_turn":turn.public_snapshot(),
            "foundation_ingress":foundation,
            "release_state":release_state,
            "exact_command_hash_ok":turn.command_sha256 == _sha_text(turn.command),
            "operational_resilience": self.resilience.snapshot(),
            "public_execution_trace": self.trace.status(turn.release_turn_id),
            "recent_execution_receipts": self.execution_receipts.recent(20),
        }
