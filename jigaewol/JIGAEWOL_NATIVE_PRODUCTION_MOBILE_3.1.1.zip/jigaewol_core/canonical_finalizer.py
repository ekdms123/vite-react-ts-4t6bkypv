from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

_HEX = frozenset("0123456789abcdef")


def _valid_sha256(value: str) -> bool:
    text = str(value).lower()
    return len(text) == 64 and all(ch in _HEX for ch in text)


def _receipt_digest(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()




@dataclass(frozen=True)
class FinalizationPermit:
    turn_id: str
    response_sha256: str
    loop_chain_sha256: str
    requirement_contract_sha256: str
    observation_chain_sha256: str
    terminal_semantics: str
    strong_finalizer_receipt_id: str
    strong_finalizer_receipt_sha256: str
    issued_at: float
    nonce: str
    permit_sha256: str
    mac_sha256: str

class CanonicalTurnFinalizer:
    """Fail-closed evidence binder for canonical full-turn application.

    This component records evidence; it does not control or impersonate the host
    dispatcher. A host adapter must explicitly call it with current-turn evidence.
    Finalizer receipts are hash-chained, and applied-full turns must name the
    applied-full receipt that was current when their ingress snapshot was taken.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.receipts_path = self.root / "receipts.jsonl"
        self.receipts_path.touch(exist_ok=True)
        self.permits_path = self.root / "permits.jsonl"
        self.permits_path.touch(exist_ok=True)
        self.permit_commits_path = self.root / "permit_commits.jsonl"
        self.permit_commits_path.touch(exist_ok=True)
        self.permit_key_path = self.root / "finalization_permit_hmac.key"
        if not self.permit_key_path.exists():
            self.permit_key_path.write_bytes(secrets.token_bytes(32))
            try:
                os.chmod(self.permit_key_path, 0o600)
            except OSError:
                pass

    @property
    def _permit_key(self) -> bytes:
        key = self.permit_key_path.read_bytes()
        if len(key) < 32:
            raise RuntimeError("finalization permit authentication key invalid")
        return key

    @staticmethod
    def _permit_body(*, turn_id: str, response_sha256: str, loop_chain_sha256: str,
                     requirement_contract_sha256: str, observation_chain_sha256: str,
                     terminal_semantics: str, strong_finalizer_receipt_id: str,
                     strong_finalizer_receipt_sha256: str, issued_at: float, nonce: str) -> dict[str, Any]:
        return {
            "turn_id": str(turn_id),
            "response_sha256": str(response_sha256).lower(),
            "loop_chain_sha256": str(loop_chain_sha256).lower(),
            "requirement_contract_sha256": str(requirement_contract_sha256).lower(),
            "observation_chain_sha256": str(observation_chain_sha256).lower(),
            "terminal_semantics": str(terminal_semantics),
            "strong_finalizer_receipt_id": str(strong_finalizer_receipt_id),
            "strong_finalizer_receipt_sha256": str(strong_finalizer_receipt_sha256).lower(),
            "issued_at": float(issued_at),
            "nonce": str(nonce),
        }

    def prepare(self, *, turn_id: str, response_sha256: str, loop_chain_sha256: str,
                requirement_contract_sha256: str, observation_chain_sha256: str = "",
                terminal_semantics: str = "SOLVED", strong_finalizer_receipt_id: str = "") -> FinalizationPermit:
        if terminal_semantics not in {"SOLVED", "INCOMPLETE", "FAILED_INTEGRITY", "SUPERSEDED"}:
            raise ValueError("unsupported terminal semantics")
        if not _valid_sha256(response_sha256):
            raise ValueError("response_sha256 must be SHA-256")
        if not _valid_sha256(loop_chain_sha256):
            raise ValueError("loop_chain_sha256 must be SHA-256")
        if requirement_contract_sha256 and not _valid_sha256(requirement_contract_sha256):
            raise ValueError("requirement_contract_sha256 must be empty or SHA-256")
        if terminal_semantics == "SOLVED" and not requirement_contract_sha256:
            raise PermissionError("SOLVED permit requires requirement-contract binding")
        if observation_chain_sha256 and not _valid_sha256(observation_chain_sha256):
            raise ValueError("observation_chain_sha256 must be empty or SHA-256")

        # The permit is no longer a second, weaker finality authority.  Any publishable
        # SOLVED/INCOMPLETE response must bind to a durable strong-finalizer receipt for
        # the same turn and exact response hash.  This removes the old thin-permit bypass.
        strong_id = str(strong_finalizer_receipt_id or "").strip()
        strong_receipt: dict[str, Any] = {}
        if terminal_semantics in {"SOLVED", "INCOMPLETE"}:
            if not strong_id:
                raise PermissionError("publishable permit requires strong finalizer receipt")
            history, _prev, _legacy = self._verified_history()
            strong_receipt = next(
                (dict(row) for row in reversed(history) if str(row.get("receipt_id") or "") == strong_id),
                {},
            )
            if not strong_receipt:
                raise PermissionError("strong finalizer receipt not found in verified ledger")
            if str(strong_receipt.get("turn_id") or "") != str(turn_id):
                raise PermissionError("strong finalizer receipt turn mismatch")
            if str(strong_receipt.get("final_response_sha256") or "").lower() != str(response_sha256).lower():
                raise PermissionError("strong finalizer receipt response hash mismatch")
            strong_contract = str(strong_receipt.get("requirement_contract_sha256") or "").lower()
            if requirement_contract_sha256 and strong_contract and strong_contract != str(requirement_contract_sha256).lower():
                raise PermissionError("strong finalizer receipt requirement-contract mismatch")
            if strong_receipt.get("integrity_verified") is not True:
                raise PermissionError("strong finalizer receipt integrity not verified")
            if terminal_semantics == "SOLVED":
                if strong_receipt.get("final_response_allowed") is not True or str(strong_receipt.get("application_state") or "") != "applied_full":
                    raise PermissionError("SOLVED permit requires strong finalizer final approval")
            elif strong_receipt.get("progress_response_allowed") is not True:
                raise PermissionError("INCOMPLETE permit requires strong finalizer progress approval")
        strong_sha = str(strong_receipt.get("receipt_sha256") or "").lower()
        if terminal_semantics in {"SOLVED", "INCOMPLETE"} and not _valid_sha256(strong_sha):
            raise PermissionError("strong finalizer receipt digest missing or invalid")
        issued_at=time.time(); nonce=uuid.uuid4().hex
        body=self._permit_body(
            turn_id=turn_id, response_sha256=response_sha256, loop_chain_sha256=loop_chain_sha256,
            requirement_contract_sha256=requirement_contract_sha256,
            observation_chain_sha256=observation_chain_sha256, terminal_semantics=terminal_semantics,
            strong_finalizer_receipt_id=strong_id, strong_finalizer_receipt_sha256=strong_sha,
            issued_at=issued_at, nonce=nonce,
        )
        permit_sha256=_receipt_digest(body)
        mac_sha256=hmac.new(self._permit_key, permit_sha256.encode("ascii"), hashlib.sha256).hexdigest()
        permit=FinalizationPermit(**body, permit_sha256=permit_sha256, mac_sha256=mac_sha256)
        with self.permits_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(asdict(permit), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
        return permit

    def verify_permit(self, permit: FinalizationPermit, *, expected_loop_chain_sha256: str = "") -> bool:
        body=self._permit_body(
            turn_id=permit.turn_id, response_sha256=permit.response_sha256,
            loop_chain_sha256=permit.loop_chain_sha256,
            requirement_contract_sha256=permit.requirement_contract_sha256,
            observation_chain_sha256=permit.observation_chain_sha256,
            terminal_semantics=permit.terminal_semantics,
            strong_finalizer_receipt_id=permit.strong_finalizer_receipt_id,
            strong_finalizer_receipt_sha256=permit.strong_finalizer_receipt_sha256,
            issued_at=permit.issued_at, nonce=permit.nonce,
        )
        digest=_receipt_digest(body)
        if digest != permit.permit_sha256:
            return False
        expected=hmac.new(self._permit_key, digest.encode("ascii"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, permit.mac_sha256):
            return False
        if expected_loop_chain_sha256 and str(permit.loop_chain_sha256) != str(expected_loop_chain_sha256):
            return False
        # A valid MAC proves issuance by this finalizer key, but the durable permit
        # ledger also prevents accepting a synthetic in-memory permit that was never
        # actually staged for this runtime.
        if permit.terminal_semantics in {"SOLVED", "INCOMPLETE"}:
            try:
                history, _prev, _legacy = self._verified_history()
            except Exception:
                return False
            strong = next(
                (dict(row) for row in reversed(history) if str(row.get("receipt_id") or "") == str(permit.strong_finalizer_receipt_id)),
                {},
            )
            if not strong:
                return False
            if str(strong.get("receipt_sha256") or "").lower() != str(permit.strong_finalizer_receipt_sha256).lower():
                return False
            if str(strong.get("turn_id") or "") != str(permit.turn_id):
                return False
            if str(strong.get("final_response_sha256") or "").lower() != str(permit.response_sha256).lower():
                return False
            if strong.get("integrity_verified") is not True:
                return False
            if permit.terminal_semantics == "SOLVED" and not (
                strong.get("final_response_allowed") is True and str(strong.get("application_state") or "") == "applied_full"
            ):
                return False
            if permit.terminal_semantics == "INCOMPLETE" and strong.get("progress_response_allowed") is not True:
                return False
        issued = False
        for raw in self.permits_path.read_text(encoding="utf-8").splitlines():
            if not raw.strip():
                continue
            try:
                row = json.loads(raw)
            except json.JSONDecodeError:
                return False
            if str(row.get("permit_sha256") or "") == permit.permit_sha256:
                issued = dict(row) == asdict(permit)
                break
        return issued

    def commit_permit(self, *, permit: FinalizationPermit, release_receipt: Any, expected_loop_chain_sha256: str = "") -> dict[str, Any]:
        if not self.verify_permit(permit, expected_loop_chain_sha256=expected_loop_chain_sha256):
            raise RuntimeError("invalid or stale finalization permit")
        for raw in self.permit_commits_path.read_text(encoding="utf-8").splitlines():
            if not raw.strip():
                continue
            row = json.loads(raw)
            if str(row.get("permit_sha256") or "") == permit.permit_sha256:
                raise RuntimeError("finalization permit replay detected")
        body_sha=str(getattr(release_receipt, "body_sha256", "") or "").lower()
        turn_id=str(getattr(release_receipt, "turn_id", "") or "")
        if body_sha != permit.response_sha256 or turn_id != permit.turn_id:
            raise RuntimeError("release receipt does not match finalization permit")
        row={
            "commit_id":"finalization_commit_"+uuid.uuid4().hex[:20],
            "turn_id":permit.turn_id,
            "permit_sha256":permit.permit_sha256,
            "response_sha256":permit.response_sha256,
            "loop_chain_sha256":permit.loop_chain_sha256,
            "terminal_semantics":permit.terminal_semantics,
            "strong_finalizer_receipt_id": permit.strong_finalizer_receipt_id,
            "strong_finalizer_receipt_sha256": permit.strong_finalizer_receipt_sha256,
            "release_integrity_receipt_id":str(getattr(release_receipt, "integrity_receipt_id", "") or ""),
            "committed_at":time.time(),
        }
        row["commit_sha256"]=_receipt_digest(row)
        with self.permit_commits_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
        return row

    @staticmethod
    def _proven_host_evidence(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
        proven = []
        for row in rows:
            item = dict(row)
            origin_ref = str(item.get("origin_ref", "")).strip()
            status = str(item.get("status", "")).lower().strip()
            success = item.get("success") is True
            if origin_ref and success and status in {"proven", "verified", "successful"}:
                proven.append(item)
        return proven

    def _verified_history(self) -> tuple[list[dict[str, Any]], str, int]:
        rows: list[dict[str, Any]] = []
        previous_digest = ""
        legacy_prefix_count = 0
        chain_started = False
        for line_number, raw in enumerate(self.receipts_path.read_text(encoding="utf-8").splitlines(), start=1):
            if not raw.strip():
                continue
            try:
                row = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"canonical finalizer receipt log is unreadable at line {line_number}") from exc
            if not isinstance(row, dict):
                raise RuntimeError(f"canonical finalizer receipt log contains non-object at line {line_number}")
            stored_digest = str(row.get("receipt_sha256") or "").strip()
            if not stored_digest:
                if chain_started:
                    raise RuntimeError("unchained canonical finalizer receipt found after hash chain began")
                legacy_prefix_count += 1
                previous_digest = _receipt_digest(row)
                rows.append(row)
                continue
            chain_started = True
            if str(row.get("previous_receipt_sha256") or "") != previous_digest:
                raise RuntimeError("canonical finalizer receipt predecessor hash mismatch")
            body = {key: value for key, value in row.items() if key != "receipt_sha256"}
            actual_digest = _receipt_digest(body)
            if stored_digest != actual_digest:
                raise RuntimeError("canonical finalizer receipt hash mismatch")
            previous_digest = stored_digest
            rows.append(row)
        return rows, previous_digest, legacy_prefix_count

    def verify_receipt_chain(self) -> bool:
        try:
            self._verified_history()
            return True
        except (OSError, RuntimeError):
            return False

    def latest_applied_full_receipt(self) -> dict[str, Any]:
        rows, _, _ = self._verified_history()
        for row in reversed(rows):
            if row.get("application_state") == "applied_full" and row.get("final_response_allowed") is True:
                return dict(row)
        return {}

    def latest_applied_full_receipt_id(self) -> str:
        return str(self.latest_applied_full_receipt().get("receipt_id") or "")

    def latest_gateway_terminal_receipt(self, *, gateway_scope_sha256: str = "") -> dict[str, Any]:
        """Return the latest verified receipt that terminally closes a gateway turn.

        A terminal receipt is either a normal ``applied_full`` receipt or an
        explicit recovery closure for a turn that was already released without
        canonical finalization. Recovery closure preserves that historical truth:
        it never sets ``final_response_allowed`` and is not an applied-full turn.
        """
        rows, _, _ = self._verified_history()
        scope = str(gateway_scope_sha256 or "").strip().lower()
        for row in reversed(rows):
            if scope and str(row.get("gateway_scope_sha256") or "").strip().lower() != scope:
                continue
            if row.get("gateway_terminal") is True:
                return dict(row)
            if (
                row.get("application_state") == "applied_full"
                and row.get("final_response_allowed") is True
                and row.get("gateway_required") is True
            ):
                return dict(row)
        return {}

    def _terminal_close_gateway_turn(
        self,
        *,
        gateway_turn_id: str,
        gateway_sequence: int,
        gateway_token_sha256: str,
        application_state: str,
        reason: str,
        origin_ref: str,
        historical_gap: bool,
        gateway_scope_sha256: str = "",
    ) -> dict[str, Any]:
        history, previous_receipt_sha256, legacy_prefix_count = self._verified_history()
        gateway_turn_id = str(gateway_turn_id or "").strip()
        gateway_sequence = int(gateway_sequence or 0)
        gateway_token_sha256 = str(gateway_token_sha256 or "").strip().lower()
        reason = str(reason or "").strip()
        origin_ref = str(origin_ref or "").strip()
        gateway_scope_sha256 = str(gateway_scope_sha256 or "").strip().lower()
        if gateway_scope_sha256 and not _valid_sha256(gateway_scope_sha256):
            raise ValueError("gateway_scope_sha256 must be a SHA-256 digest")
        if not gateway_turn_id:
            raise ValueError("gateway_turn_id is required")
        if gateway_sequence <= 0:
            raise ValueError("gateway_sequence must be positive")
        if not _valid_sha256(gateway_token_sha256):
            raise ValueError("gateway_token_sha256 must be a SHA-256 digest")
        if not reason:
            raise ValueError("terminal-close reason is required")
        if not origin_ref:
            raise ValueError("terminal-close origin_ref is required")
        if application_state not in {"recovered_incomplete", "aborted_before_release", "superseded_unfinalized", "continued_unfinalized"}:
            raise ValueError("unsupported gateway terminal application_state")

        latest_terminal = self.latest_gateway_terminal_receipt(gateway_scope_sha256=gateway_scope_sha256)
        if latest_terminal:
            terminal_sequence = int(latest_terminal.get("gateway_sequence") or 0)
            if gateway_sequence <= terminal_sequence:
                if (
                    gateway_sequence == terminal_sequence
                    and str(latest_terminal.get("gateway_turn_id") or "") == gateway_turn_id
                    and str(latest_terminal.get("gateway_token_sha256") or "") == gateway_token_sha256
                ):
                    return latest_terminal
                raise RuntimeError("gateway terminal closure would fork or move terminal sequence backwards")
            if gateway_sequence != terminal_sequence + 1:
                raise RuntimeError("gateway terminal closure sequence is not contiguous with terminal history")

        previous_applied_full_receipt_id = ""
        previous_applied_full_gateway_sequence = 0
        for old in reversed(history):
            if old.get("application_state") == "applied_full" and old.get("final_response_allowed") is True:
                previous_applied_full_receipt_id = str(old.get("receipt_id") or "")
                previous_applied_full_gateway_sequence = int(old.get("gateway_sequence") or 0)
                break

        aborted = application_state == "aborted_before_release"
        superseded = application_state == "superseded_unfinalized"
        continued = application_state == "continued_unfinalized"
        prefix = "abort" if aborted else "supersede" if superseded else "continue" if continued else "recovery"
        receipt = {
            "receipt_id": f"canonical_{prefix}_{uuid.uuid4().hex[:20]}",
            "turn_id": "",
            "application_state": application_state,
            "final_response_allowed": False,
            "progress_response_allowed": True,
            "response_permission_not_modeled": False,
            "ingress_verified": False,
            "control_checkpoint_id": "",
            "host_execution_evidence_count": 0,
            "host_execution_evidence_sha256": hashlib.sha256(b"[]").hexdigest(),
            "execution_receipt_ids": [],
            "final_response_sha256": "",
            "missing": [
                "gateway_ingress_aborted_before_release" if aborted
                else "superseded_unfinalized_host_release_status_unproven" if superseded
                else "continued_unfinalized_user_work_preserved" if continued
                else "historical_pre_release_finalization"
            ],
            "mismatches": [],
            "continuity_state": (
                "pre_release_abort" if aborted
                else "superseded_unfinalized" if superseded
                else "continued_unfinalized" if continued
                else "historical_incomplete_recovery"
            ),
            "continuous_application_proven": False,
            "gap_detected": bool(historical_gap),
            "gateway_required": True,
            "gateway_turn_id": gateway_turn_id,
            "gateway_sequence": gateway_sequence,
            "gateway_token_sha256": gateway_token_sha256,
            "gateway_scope_sha256": gateway_scope_sha256,
            "gateway_chain_verified": True,
            "gateway_continuity_state": ("aborted_terminal" if aborted else "superseded_terminal" if superseded else "continued_terminal" if continued else "recovered_terminal"),
            "gateway_gap_detected": bool(historical_gap),
            "previous_applied_full_gateway_sequence": previous_applied_full_gateway_sequence,
            "gateway_turn_sequence_proven": True,
            "gateway_gap_absence_proven": not historical_gap,
            "previous_applied_full_receipt_id": previous_applied_full_receipt_id,
            "expected_previous_finalizer_receipt_id": previous_applied_full_receipt_id,
            "gap_detection_scope": "local_gateway_issued_sequence_plus_instrumented_finalizer_chain",
            "host_turn_sequence_proven": False,
            "host_gap_absence_proven": False,
            "legacy_unchained_receipt_prefix_count": legacy_prefix_count,
            "previous_receipt_sha256": previous_receipt_sha256,
            "finalized_at": time.time(),
            "dispatch_state": "gateway_terminal_recorded",
            "gateway_terminal": True,
            "gateway_recovery": (not aborted and not superseded and not continued),
            "gateway_abort": aborted,
            "gateway_superseded": superseded,
            "gateway_continued_unfinalized": continued,
            "prior_user_work_preserved": continued,
            "terminal_reason": reason,
            "terminal_origin_ref": origin_ref,
        }
        if aborted:
            receipt["abort_reason"] = reason
            receipt["abort_origin_ref"] = origin_ref
        elif superseded:
            receipt["supersede_reason"] = reason
            receipt["supersede_origin_ref"] = origin_ref
            receipt["host_release_status"] = "unproven"
        elif continued:
            receipt["continuation_reason"] = reason
            receipt["continuation_origin_ref"] = origin_ref
            receipt["host_release_status"] = "prior_work_still_open"
        else:
            receipt["recovery_reason"] = reason
            receipt["recovery_origin_ref"] = origin_ref
        receipt["receipt_sha256"] = _receipt_digest(receipt)
        with self.receipts_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
        return receipt

    def recover_unreleased_gateway_turn(
        self,
        *,
        gateway_turn_id: str,
        gateway_sequence: int,
        gateway_token_sha256: str,
        reason: str,
        recovery_origin_ref: str,
        gateway_scope_sha256: str = "",
    ) -> dict[str, Any]:
        """Close a historical turn whose response escaped before finalization."""
        return self._terminal_close_gateway_turn(
            gateway_turn_id=gateway_turn_id,
            gateway_sequence=gateway_sequence,
            gateway_token_sha256=gateway_token_sha256,
            application_state="recovered_incomplete",
            reason=reason,
            origin_ref=recovery_origin_ref,
            historical_gap=True,
            gateway_scope_sha256=gateway_scope_sha256,
        )


    def continue_unfinalized_gateway_turn(
        self,
        *,
        gateway_turn_id: str,
        gateway_sequence: int,
        gateway_token_sha256: str,
        reason: str,
        continuation_origin_ref: str,
        gateway_scope_sha256: str = "",
    ) -> dict[str, Any]:
        """Close only the old ingress token while preserving its unfinished user work.

        This is sequencing bookkeeping, not cancellation: pending host actions and the
        prior user objective remain alive and may still receive their own receipts.
        """
        return self._terminal_close_gateway_turn(
            gateway_turn_id=gateway_turn_id,
            gateway_sequence=gateway_sequence,
            gateway_token_sha256=gateway_token_sha256,
            application_state="continued_unfinalized",
            reason=reason,
            origin_ref=continuation_origin_ref,
            historical_gap=False,
            gateway_scope_sha256=gateway_scope_sha256,
        )


    def supersede_unfinalized_gateway_turn(
        self,
        *,
        gateway_turn_id: str,
        gateway_sequence: int,
        gateway_token_sha256: str,
        reason: str,
        supersede_origin_ref: str,
        gateway_scope_sha256: str = "",
    ) -> dict[str, Any]:
        """Terminal-close an unfinalized turn when a newer user message takes priority.

        The host may have rendered non-final or even escaped output outside this
        local finalizer, so this state is deliberately conservative: it allows the
        newer turn to proceed but does not claim uninterrupted application.
        """
        return self._terminal_close_gateway_turn(
            gateway_turn_id=gateway_turn_id,
            gateway_sequence=gateway_sequence,
            gateway_token_sha256=gateway_token_sha256,
            application_state="superseded_unfinalized",
            reason=reason,
            origin_ref=supersede_origin_ref,
            historical_gap=True,
            gateway_scope_sha256=gateway_scope_sha256,
        )

    def abort_gateway_turn(
        self,
        *,
        gateway_turn_id: str,
        gateway_sequence: int,
        gateway_token_sha256: str,
        reason: str,
        abort_origin_ref: str,
        gateway_scope_sha256: str = "",
    ) -> dict[str, Any]:
        """Terminal-close an issued gateway turn that failed before any response release.

        Unlike historical recovery, this is not a continuity gap: no response was
        released and the local sequence is explicitly closed before the next turn.
        """
        return self._terminal_close_gateway_turn(
            gateway_turn_id=gateway_turn_id,
            gateway_sequence=gateway_sequence,
            gateway_token_sha256=gateway_token_sha256,
            application_state="aborted_before_release",
            reason=reason,
            origin_ref=abort_origin_ref,
            historical_gap=False,
            gateway_scope_sha256=gateway_scope_sha256,
        )

    def finalize(
        self,
        *,
        turn_id: str,
        ingress_verified: bool,
        control_checkpoint_id: str,
        host_execution_evidence: Iterable[Mapping[str, Any]],
        host_execution_required: bool = True,
        final_response_sha256: str,
        expected_response_sha256: str | None = None,
        execution_receipt_ids: Iterable[str] = (),
        expected_previous_finalizer_receipt_id: str | None = None,
        gateway_required: bool = False,
        gateway_turn_id: str = "",
        gateway_sequence: int = 0,
        gateway_token_sha256: str = "",
        previous_gateway_token_sha256: str = "",
        gateway_chain_verified: bool = False,
        gateway_scope_sha256: str = "",
        requirement_contract_sha256: str = "",
        requirement_coverage_ok: bool = True,
        requirement_accounted_ids: Iterable[str] = (),
        requirement_missing_ids: Iterable[str] = (),
        requirement_findings: Iterable[str] = (),
        repair_momentum_required: bool = False,
        repair_momentum_ok: bool = True,
        repair_momentum_receipt_ids: Iterable[str] = (),
        repair_momentum_findings: Iterable[str] = (),
        directive_fidelity_ok: bool = True,
        directive_fidelity_findings: Iterable[str] = (),
        directive_fidelity_live_requirement_count: int = 0,
        objective_completion_required: bool = False,
        objective_completion_proven: bool = False,
        objective_completion_evidence_refs: Iterable[str] = (),
        objective_completion_unresolved_goal_refs: Iterable[str] = (),
        persist_receipt: bool = True,
    ) -> dict[str, Any]:
        history, previous_receipt_sha256, legacy_prefix_count = self._verified_history()
        previous_applied_full_receipt_id = ""
        previous_applied_full_gateway_sequence = 0
        for old in reversed(history):
            if old.get("application_state") == "applied_full" and old.get("final_response_allowed") is True:
                previous_applied_full_receipt_id = str(old.get("receipt_id") or "")
                previous_applied_full_gateway_sequence = int(old.get("gateway_sequence") or 0)
                break
        scope_filter = str(gateway_scope_sha256 or "").strip().lower()
        predecessor_gateway_token = str(previous_gateway_token_sha256 or "").strip().lower()
        current_gateway_sequence = int(gateway_sequence or 0)
        previous_gateway_terminal = {}
        for old in reversed(history):
            if scope_filter and str(old.get("gateway_scope_sha256") or "").strip().lower() != scope_filter:
                continue
            if old.get("gateway_terminal") is True or (
                old.get("application_state") == "applied_full"
                and old.get("final_response_allowed") is True
                and old.get("gateway_required") is True
            ):
                previous_gateway_terminal = dict(old)
                break
        # Backward compatibility for a legacy unscoped predecessor: accept it only
        # when the current signed gateway envelope explicitly chains to its token.
        if not previous_gateway_terminal and predecessor_gateway_token and current_gateway_sequence > 1:
            for old in reversed(history):
                if str(old.get("gateway_scope_sha256") or "").strip():
                    continue
                if not (old.get("gateway_terminal") is True or (
                    old.get("application_state") == "applied_full"
                    and old.get("final_response_allowed") is True
                    and old.get("gateway_required") is True
                )):
                    continue
                if (
                    int(old.get("gateway_sequence") or 0) == current_gateway_sequence - 1
                    and str(old.get("gateway_token_sha256") or "").strip().lower() == predecessor_gateway_token
                ):
                    previous_gateway_terminal = dict(old)
                    break
        previous_gateway_terminal_sequence = int(previous_gateway_terminal.get("gateway_sequence") or 0)
        previous_gateway_terminal_state = str(previous_gateway_terminal.get("application_state") or "")

        missing: list[str] = []
        mismatches: list[str] = []
        turn_id = str(turn_id).strip()
        checkpoint = str(control_checkpoint_id).strip()
        response_sha = str(final_response_sha256).lower().strip()
        expected_sha = str(expected_response_sha256 or "").lower().strip()
        expected_predecessor = str(expected_previous_finalizer_receipt_id or "").strip()
        proven = self._proven_host_evidence(host_execution_evidence)
        receipt_ids = [str(value).strip() for value in execution_receipt_ids if str(value).strip()]
        gateway_required = bool(gateway_required)
        gateway_turn_id = str(gateway_turn_id or "").strip()
        gateway_sequence = int(gateway_sequence or 0)
        gateway_token_sha256 = str(gateway_token_sha256 or "").strip().lower()
        previous_gateway_token_sha256 = predecessor_gateway_token
        gateway_chain_verified = bool(gateway_chain_verified)
        gateway_scope_sha256 = scope_filter
        if gateway_scope_sha256 and not _valid_sha256(gateway_scope_sha256):
            mismatches.append("gateway_scope_sha256_invalid")
        host_execution_required = bool(host_execution_required)
        requirement_contract_sha256 = str(requirement_contract_sha256 or "").strip().lower()
        requirement_coverage_ok = bool(requirement_coverage_ok)
        requirement_accounted_ids = tuple(str(x) for x in requirement_accounted_ids if str(x))
        requirement_missing_ids = tuple(str(x) for x in requirement_missing_ids if str(x))
        requirement_findings = tuple(str(x) for x in requirement_findings if str(x))
        repair_momentum_required = bool(repair_momentum_required)
        repair_momentum_ok = bool(repair_momentum_ok)
        repair_momentum_receipt_ids = tuple(str(x) for x in repair_momentum_receipt_ids if str(x))
        repair_momentum_findings = tuple(str(x) for x in repair_momentum_findings if str(x))
        directive_fidelity_ok = bool(directive_fidelity_ok)
        directive_fidelity_findings = tuple(str(x) for x in directive_fidelity_findings if str(x))
        directive_fidelity_live_requirement_count = max(0, int(directive_fidelity_live_requirement_count or 0))
        objective_completion_required = bool(objective_completion_required)
        objective_completion_proven = bool(objective_completion_proven)
        objective_completion_evidence_refs = tuple(str(x) for x in objective_completion_evidence_refs if str(x))
        objective_completion_unresolved_goal_refs = tuple(str(x) for x in objective_completion_unresolved_goal_refs if str(x))
        if objective_completion_proven and not objective_completion_evidence_refs:
            mismatches.append("objective_completion_claim_without_evidence")
            objective_completion_proven = False
        if objective_completion_required and not objective_completion_proven:
            missing.append("objective_completion_evidence")

        if not turn_id:
            missing.append("turn_id")
        if ingress_verified is not True:
            missing.append("ingress_verified")
        if host_execution_required and not proven:
            missing.append("host_execution_evidence")
        if not _valid_sha256(response_sha):
            missing.append("final_response_sha256")
        if expected_sha:
            if not _valid_sha256(expected_sha):
                mismatches.append("expected_response_sha256_invalid")
            elif response_sha != expected_sha:
                mismatches.append("final_response_sha256_mismatch")
        if repair_momentum_required:
            if not repair_momentum_ok:
                missing.append("repair_momentum_corrective_action")
            if not repair_momentum_receipt_ids:
                missing.append("repair_momentum_receipt")

        if not requirement_coverage_ok:
            missing.append("requirement_coverage")
            if requirement_missing_ids or requirement_findings:
                missing.append("requirement_atoms_unaccounted")
        if not directive_fidelity_ok:
            # Unlike ordinary verification uncertainty, this is an authority/integrity
            # failure: the candidate tried to replace the live user scope with a smaller
            # one.  It must not be released as the answer for that canonical turn.
            mismatches.append("directive_fidelity_scope_rewrite")

        if not previous_applied_full_receipt_id:
            continuity_state = "genesis"
            gap_detected = False
        elif not expected_predecessor:
            continuity_state = "unproven_predecessor"
            gap_detected = False
            missing.append("previous_finalizer_receipt_id")
        elif expected_predecessor != previous_applied_full_receipt_id:
            continuity_state = "gap_or_fork_detected"
            gap_detected = True
            mismatches.append("finalizer_predecessor_mismatch")
        else:
            continuity_state = "continuous"
            gap_detected = False

        if not gateway_required:
            gateway_continuity_state = "not_required"
            gateway_gap_detected = False
        else:
            if not gateway_chain_verified:
                missing.append("gateway_chain_verified")
            if not gateway_turn_id:
                missing.append("gateway_turn_id")
            if gateway_sequence <= 0:
                missing.append("gateway_sequence")
            if not _valid_sha256(gateway_token_sha256):
                missing.append("gateway_token_sha256")
            if previous_gateway_terminal_sequence <= 0:
                gateway_continuity_state = "gateway_genesis"
                gateway_gap_detected = False
            elif gateway_sequence == previous_gateway_terminal_sequence + 1:
                if previous_gateway_terminal_state == "recovered_incomplete":
                    gateway_continuity_state = "gateway_continuous_after_recovery"
                    gateway_gap_detected = False
                elif previous_gateway_terminal_state == "aborted_before_release":
                    gateway_continuity_state = "gateway_continuous_after_abort"
                    gateway_gap_detected = False
                elif previous_gateway_terminal_state == "continued_unfinalized":
                    gateway_continuity_state = "gateway_continuous_after_continuation"
                    gateway_gap_detected = False
                else:
                    gateway_continuity_state = "gateway_continuous"
                    gateway_gap_detected = False
            else:
                gateway_continuity_state = "gateway_gap_detected"
                gateway_gap_detected = True
                mismatches.append("gateway_sequence_gap")

        # Verification annotates; it does not hold the user's answer hostage.
        #
        # Two different things were conflated here. An *integrity* failure means the
        # runtime cannot prove what it is about to record (unverified ingress, a
        # response-hash mismatch, a receipt-chain gap) — that must still block, or the
        # ledger becomes fiction. An *obligation* is work that is still open (a
        # requirement not yet covered, an unrepaired behavioral break, host execution
        # not yet observed). Those are recorded and carried forward; they never make
        # the response itself unreleasable. Blocking on them is the verification-as-
        # censorship layer the GPT lineage removed, and it is removed here too — but
        # without giving up the integrity proofs that make the receipt worth anything.
        _OBLIGATION_KEYS = {
            "host_execution_evidence": "external_execution_open",
            "requirement_coverage": "requirement_coverage_open",
            "requirement_contract_sha256": "requirement_coverage_open",
            "requirement_atoms_unaccounted": "requirement_coverage_open",
            "repair_momentum_corrective_action": "repair_obligation_open",
            "repair_momentum_receipt": "repair_obligation_open",
            "objective_completion_evidence": "objective_completion_open",
        }
        obligation_missing = [x for x in missing if x in _OBLIGATION_KEYS]
        obligation_mismatches = [x for x in mismatches if x in _OBLIGATION_KEYS]
        integrity_missing = [x for x in missing if x not in _OBLIGATION_KEYS]
        integrity_mismatches = [x for x in mismatches if x not in _OBLIGATION_KEYS]
        verification_notes = sorted({
            _OBLIGATION_KEYS[x] for x in (*obligation_missing, *obligation_mismatches)
        })
        # Two different questions, two different answers:
        #
        # `application_state` asks "can this turn be recorded as fully applied?" An
        # unobserved host execution, an uncovered requirement or an unrepaired break
        # means no — recording applied_full there would be the "실행한 척" fabrication
        # this ledger exists to prevent. So it needs everything.
        #
        # A final result is different from an interim/failure-truth update. Older
        # revisions allowed a candidate to leave through the final-response path even
        # while exact user requirements or required execution remained open. That made
        # an incomplete route look like the user's destination had been satisfied.
        # Finality now requires source fidelity + requirement coverage + any requested
        # execution evidence + repair closure. An incomplete turn remains resumable and
        # may be surfaced separately as progress truth, but it cannot impersonate the
        # final requested result.
        integrity_verified = not integrity_missing and not integrity_mismatches
        host_execution_complete = (
            not host_execution_required
            or "host_execution_evidence" not in missing
            and "host_execution_evidence" not in mismatches
        )
        objective_completion_gate = bool(
            (not objective_completion_required) or objective_completion_proven
        )
        applied = bool(not missing and not mismatches and objective_completion_gate)
        response_allowed = bool(
            directive_fidelity_ok
            and requirement_coverage_ok
            and host_execution_complete
            and repair_momentum_ok
            and integrity_verified
            and objective_completion_gate
        )
        progress_response_allowed = bool(integrity_verified and directive_fidelity_ok)
        evidence_digest = hashlib.sha256(
            json.dumps(proven, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        receipt = {
            "receipt_id": f"canonical_finalizer_{uuid.uuid4().hex[:20]}",
            "turn_id": turn_id,
            "application_state": "applied_full" if applied else "incomplete",
            "final_response_allowed": bool(response_allowed),
            "progress_response_allowed": bool(progress_response_allowed),
            "finality_requires_full_user_requirement_coverage": True,
            "finality_requires_requested_execution_evidence": True,
            "objective_completion_required": bool(objective_completion_required),
            "objective_completion_proven": bool(objective_completion_proven),
            "objective_completion_evidence_refs": list(objective_completion_evidence_refs),
            "objective_completion_unresolved_goal_refs": list(objective_completion_unresolved_goal_refs),
            "release_success_does_not_imply_objective_completion": True,
            "integrity_verified": bool(integrity_verified),
            "ingress_verified": ingress_verified is True,
            "control_checkpoint_id": checkpoint,
            "host_execution_required": host_execution_required,
            "host_execution_evidence_count": len(proven),
            "host_execution_evidence_sha256": evidence_digest,
            "execution_receipt_ids": receipt_ids,
            "final_response_sha256": response_sha,
            "requirement_contract_sha256": requirement_contract_sha256,
            "requirement_coverage_ok": requirement_coverage_ok,
            "requirement_accounted_ids": list(requirement_accounted_ids),
            "requirement_missing_ids": list(requirement_missing_ids),
            "requirement_findings": list(requirement_findings),
            "repair_momentum_required": repair_momentum_required,
            "repair_momentum_ok": repair_momentum_ok,
            "repair_momentum_receipt_ids": list(repair_momentum_receipt_ids),
            "repair_momentum_findings": list(repair_momentum_findings),
            "directive_fidelity_ok": directive_fidelity_ok,
            "directive_fidelity_findings": list(directive_fidelity_findings),
            "directive_fidelity_live_requirement_count": directive_fidelity_live_requirement_count,
            "missing": missing,
            "mismatches": mismatches,
            "integrity_missing": integrity_missing,
            "integrity_mismatches": integrity_mismatches,
            "open_obligations": sorted({*obligation_missing, *obligation_mismatches}),
            "verification_notes": verification_notes,
            "verification_is_annotation_not_permission": True,
            "continuity_state": continuity_state,
            "continuous_application_proven": bool(
                applied
                and continuity_state in {"genesis", "continuous"}
                and (not gateway_required or gateway_continuity_state in {"gateway_genesis", "gateway_continuous", "gateway_continuous_after_abort", "gateway_continuous_after_continuation"})
            ),
            "gap_detected": gap_detected,
            "gateway_required": gateway_required,
            "gateway_turn_id": gateway_turn_id,
            "gateway_sequence": gateway_sequence,
            "gateway_token_sha256": gateway_token_sha256,
            "previous_gateway_token_sha256": previous_gateway_token_sha256,
            "gateway_scope_sha256": gateway_scope_sha256,
            "gateway_chain_verified": gateway_chain_verified,
            "gateway_continuity_state": gateway_continuity_state,
            "gateway_gap_detected": gateway_gap_detected,
            "previous_applied_full_gateway_sequence": previous_applied_full_gateway_sequence,
            "previous_gateway_terminal_sequence": previous_gateway_terminal_sequence,
            "previous_gateway_terminal_state": previous_gateway_terminal_state,
            "gateway_turn_sequence_proven": bool(
                applied
                and gateway_required
                and gateway_chain_verified
                and gateway_continuity_state in {"gateway_genesis", "gateway_continuous", "gateway_continuous_after_recovery", "gateway_continuous_after_abort", "gateway_continuous_after_continuation"}
            ),
            "gateway_gap_absence_proven": bool(
                applied
                and gateway_required
                and gateway_chain_verified
                and not gateway_gap_detected
            ),
            "previous_applied_full_receipt_id": previous_applied_full_receipt_id,
            "expected_previous_finalizer_receipt_id": expected_predecessor,
            "gap_detection_scope": (
                "local_gateway_issued_sequence_plus_instrumented_finalizer_chain"
                if gateway_required
                else "instrumented_finalizer_chain_only"
            ),
            "host_turn_sequence_proven": False,
            "host_gap_absence_proven": False,
            "legacy_unchained_receipt_prefix_count": legacy_prefix_count,
            "previous_receipt_sha256": previous_receipt_sha256,
            "finalized_at": time.time(),
            "dispatch_state": "finalizer_receipt_recorded",
            "gateway_terminal": bool(applied and gateway_required),
            "gateway_recovery": False,
            "receipt_persisted": bool(persist_receipt),
            "pre_release_evaluation_only": not bool(persist_receipt),
        }
        receipt["receipt_sha256"] = _receipt_digest(receipt)
        if persist_receipt:
            with self.receipts_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
                fh.flush()
        return receipt
