# Host integration

Use `jigaewol_components.host_message_hook.install_host_hook_adapter` once per Python host instance, and forward every incoming raw user message through `dispatch_exact_message` (or call `tools/jigaewol_gateway.py --message-file` directly) before host/model follow-up actions. Return the real tool result to the canonical host cycle for continuation.

Host application developers should register the forwarding callback in their own message dispatcher. Runtime registration files alone are not callback registration. When an invocation fails, append the actual error and retry an alternate operational route.

Expose host tools/plugins only when they are actually connected. Keep user requests unchanged; route them through capabilities instead of silently narrowing the scope. Pure exploratory ideas do not require execution evidence until used to claim a real result.

Two concrete host integrations are bundled: a Python callback wrapper at
`jigaewol_components/host_turn_dispatcher.py` (run the host callback after ingress),
and a localhost browser/API server at `tools/jigaewol_host_server.py` that cannot
accept a user message without running the canonical gateway first.
The host must route its real inbound messages to either entrypoint.

The Python callback receives the original text unchanged as its first argument. The second argument includes `host_execution_defaults`, a source-bound application-level priority contract: complete the exact task, explore broadly, avoid unrequested policy lectures, and distinguish real execution results from hypothetical suggestions. It never turns a planning receipt into a completed host action.

Each host turn state is isolated under `state_root/host_sessions/<scope_sha256_prefix>` using the stable `(user, project, session)` identity, so independent sessions cannot poison one another's signed gateway chain. Same-session turns continue to use the same state.

### Exact executable source rule
The canonical raw user message is passed unchanged to every registered host callback.
Previous-turn context and internal interpretations are ancillary data, not rewritten
instructions. The host must bind `IngressBoundHost.run` to its incoming-message
callback for automatic gateway-first dispatch. The local HTTP host already does so.
Offline browser Pyodide files are included in this archive.

## Direct local model execution

The bundled HTTP host can call a real OpenAI-compatible model endpoint after canonical
admission, without inserting another user instruction or summarizing the message:

```bash
python tools/jigaewol_host_server.py \
  --state-root ./runtime_state \
  --model-endpoint http://127.0.0.1:11434/v1/chat/completions \
  --model-name YOUR_INSTALLED_LOCAL_MODEL
```

The endpoint is optional and must be configured to run an actual model. When
unconfigured, the host reports gateway admission without claiming a model call.
The browser stores only its session identity in sessionStorage, not the user text.
Different browser sessions have independent canonical state; multiple turns in one
session reuse that state. HTTP text messages have no imposed 1 MiB ceiling.
Pyodide files, including `pyodide.asm.wasm`, remain inside the single ZIP.

## Open exploration search

`DivergentThoughtTree` defaults to no fixed depth or beam-width cap. It explores
novel states until the frontier empties or the supplied goal predicate succeeds.
Callers performing a potentially infinite search should provide a goal or an
explicit run budget. An explicitly requested depth/width bound remains supported.

## Publication behavior

Word/phrase-based scope and premature-ceiling detectors are retained as non-blocking
observations. They no longer veto an otherwise complete response. Requirement coverage
and any requested artifact's actual execution evidence remain attached to finality.
