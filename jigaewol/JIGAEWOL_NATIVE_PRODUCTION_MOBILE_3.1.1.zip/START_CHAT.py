#!/usr/bin/env python3
"""Zero-account ZIP activation in an existing chat execution tool."""
from __future__ import annotations
import argparse,hashlib,json,os,stat,sys,tempfile,zipfile
from pathlib import Path,PurePosixPath

def activate(archive_path,destination='/tmp/JIGAEWOL_CHAT_RUNTIME',state_root=None):
    archive_path=Path(archive_path);destination=Path(destination).resolve();state=Path(state_root if state_root is not None else tempfile.mkdtemp(prefix='jigaewol-chat-state-')).resolve()
    if state==destination or destination in state.parents or state in destination.parents:raise ValueError('keep source and mutable state separate')
    for name,loaded in tuple(sys.modules.items()):
        if name.split('.')[0] in {'jigaewol_core','jigaewol_components','jigaewol_runtime','model_host'} and getattr(loaded,'__file__',None):
            if destination not in Path(loaded.__file__).resolve().parents:
                raise ValueError('activate this ZIP in a fresh Python process; a different runtime is already imported')
    with zipfile.ZipFile(archive_path) as archive:
        infos=[x for x in archive.infolist() if not x.is_dir()];names=[x.filename for x in infos]
        if len(names)!=len(set(names)) or len(infos)>20000 or sum(x.file_size for x in infos)>128*1024*1024:raise ValueError('invalid archive membership or size')
        manifest=json.loads(archive.read('CANONICAL_ARTIFACT.json'));rows=manifest['active_files']
        if not rows or 'jigaewol_core/integrity.py' not in {x['path'] for x in rows}:raise ValueError('executable source manifest required')
        if set(names)-({x['path'] for x in rows}|{'CANONICAL_ARTIFACT.json','PERSONAL_MANIFEST.json','PORTABLE_RECOVERY_CAPSULE.json'}):raise ValueError('unmanifested executable or source entry')
        computed=[]
        for row in rows:
            data=archive.read(row['path']);actual={'path':row['path'],'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}
            if actual!=row:raise ValueError('sealed member mismatch')
            computed.append(actual)
        digest=hashlib.sha256(json.dumps(computed,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        if digest!=manifest['content_set_sha256'] or len(rows)!=manifest['active_file_count'] or len({x['path'] for x in rows})!=len(rows):raise ValueError('sealed content identity mismatch')
        verified=[]
        for info in infos:
            target=(destination/info.filename).resolve()
            if destination not in target.parents or '\\' in info.filename or '..' in PurePosixPath(info.filename).parts or info.filename!=PurePosixPath(info.filename).as_posix() or stat.S_ISLNK((info.external_attr>>16)&0xffff):raise ValueError('unsafe ZIP member')
            verified.append((target,archive.read(info)))
        if destination.exists():
            existing=[p for p in destination.rglob('*') if p.is_file() or p.is_symlink()]
            if any(p.is_symlink() or p.relative_to(destination).as_posix() not in names for p in existing):
                raise ValueError('activate into a clean source directory without unsealed files')
        # Extract only after preflight and all sealed bytes validate.
        destination.mkdir(parents=True,exist_ok=True)
        for target,data in verified:
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    sys.path.insert(0,str(destination));sys.dont_write_bytecode=True;os.environ['JIGAEWOL_RUNTIME_HOME']=str(state/'home')
    from jigaewol_core.integrity import verify_active_artifact
    checked=verify_active_artifact()
    from jigaewol_runtime.inchat_sandbox import InChatSandbox
    runtime=InChatSandbox(state)
    from jigaewol_components.host_message_hook import install_host_hook_adapter
    hook=install_host_hook_adapter(runtime_root=destination,state_root=state,host_kind='local_python')
    return {'source_digest':checked['content_set_sha256'],'verified_files':checked['checked'],'state_root':str(state),'runtime_root':str(destination),'authority':['USER','JIGAEWOL','MODEL'],'additional_spend_usd':0,'external_server_started':False,'paid_api_registered':False,'execution_tool_observed':True,'host_hook_adapter':hook},runtime

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--zip',required=True);parser.add_argument('--root',default='/tmp/JIGAEWOL_CHAT_RUNTIME');parser.add_argument('--state',help='explicit state to retain or load; otherwise start a fresh chat state');args=parser.parse_args()
    receipt,runtime=activate(args.zip,args.root,args.state);print(json.dumps(receipt,ensure_ascii=False))
if __name__=='__main__':main()
