from __future__ import annotations

"""Lossless source-directive compiler.

The compiler deliberately treats lexical meaning as open data.  It extracts discourse
structure (clause boundaries, modality, polarity, quotation, conditionality and
cross-turn reference signals) without choosing from a closed task/outcome vocabulary.
The original source span is carried on every clause so downstream authority can always
be traced back to exact user text.
"""

import hashlib
import re
from dataclasses import dataclass, field
from typing import Iterable


_QUOTE_RE = re.compile(r'(?P<open>["“\'‘])(?P<body>[^"“”\'‘’]+)(?P<close>["”\'’])')
_SENTENCE_BOUNDARY_RE = re.compile(r'(?<=[.!?。！？])\s+|[\n;]+')
_NEGATIVE_RE = re.compile(r'(?:지\s*마|하지\s*말|말고|아니라|않(?:아|고|게|도록)|못\s*하)', re.IGNORECASE)
_CONDITIONAL_RE = re.compile(r'(?:^|\s)만약(?:\s|$)|(?:다|라|으라|는|은|을)?면(?:\s|,|$)|(?:다|라)면', re.IGNORECASE)
_QUESTION_RE = re.compile(
    r'(?:\?|？)\s*$|(?:나요|인가|일까|어떻게|왜|무엇|뭐|which|what|why|how)\b|(?:니|냐)\s*[.!?~…]*$',
    re.IGNORECASE,
)
_IMPERATIVE_END_RE = re.compile(
    r'(?:해|해줘|해주세요|하라|하세요|하자|줘|주세요|말해|알려줘|보여줘|봐|해봐|읽어|고쳐|바꿔|만들어|설계해|분석해|설명해|구현해|적용해|진행해|계속해|이어가|찾아내|끝내|해내|해라)\s*[.!?~…]*$',
    re.IGNORECASE,
)
_CONJUNCTIVE_END_RE = re.compile(r'(?:고|뒤|후|면서)\s*$', re.IGNORECASE)
_ACTION_INTENT_RE = re.compile(
    r'(?:해줘|해주세요|구현(?:해|하자|하세요|해줘)|수정(?:해|하자|하세요|해줘)|교체(?:해|하자|하세요|해줘)|만들(?:자|어줘|어주세요)|실행(?:해|하자|하세요|해줘)|적용(?:해|하자|하세요|해줘)|통합(?:해|하자|하세요|해줘)|출력(?:해|하자|하세요|해줘)|찾아(?:줘|내|봐|보자)?|검색(?:해|하자|하세요|해줘)|조사(?:해|하자|하세요|해줘)|봐|보고해|읽어|확인(?:해|하자|하세요|해줘)|고쳐|설계(?:해|하자|하세요|해줘)|붙여|가져와|연결(?:해|하자|하세요|해줘)|검증(?:해|하자|하세요|해줘)|학습(?:해|하자|하세요|해줘)|기록(?:해|하자|하세요|해줘)|저장(?:해|하자|하세요|해줘)|업데이트(?:해|하자|하세요|해줘)|커밋(?:해|하자|하세요|해줘)|푸시(?:해|하자|하세요|해줘)|복구(?:해|하자|하세요|해줘)|'
    r'\b(?:implement|modify|replace|build|run|execute|apply|integrate|create|search|find|fix|connect|use)\b)',
    re.IGNORECASE,
)
_PREFERENCE_REQUEST_RE = re.compile(
    r'(?:원해|원한다|원하는\s*건|했으면\s*해|해줬으면|좋겠어|바라(?:고|면|는)|하고\s*싶어|필요해)',
    re.IGNORECASE,
)
_DIRECT_PROHIBITION_RE = re.compile(
    r'(?:하지\s*마|하지말|하지\s*말아|말아줘|빼지\s*마|축소하지\s*마|무시하지\s*마|금지(?:해|한다)?|do\s+not|don[\'’]?t|never)',
    re.IGNORECASE,
)
_REQUEST_QUESTION_RE = re.compile(
    r'(?:해줄래|줄래|해줄\s*수\s*있|할\s*수\s*있|해볼래|가능(?:해|할까|한가)|would\s+you|could\s+you|can\s+you)',
    re.IGNORECASE,
)
_CORRECTION_RE = re.compile(r'^\s*(?:아니|아니야|정정|수정해서|rather|no[, ]|instead)\b', re.IGNORECASE)
_REPORTED_DIRECTIVE_CORRECTION_RE = re.compile(
    r'(?:말라고\s*(?:했|했는데|했잖)|말랬(?:지|는데)?|(?:하|해)라고\s*(?:했|했는데|했잖))'
    r'[^\n]{0,96}(?:또|무시|축소|어기|반대로|멋대로)|'
    r'(?:또|다시)[^\n]{0,64}(?:무시|축소|어기)[^\n]{0,64}(?:했|말|랬)',
    re.IGNORECASE,
)
_CANCEL_RE = re.compile(r'(?:취소|철회|없던\s*걸로|하지\s*마|중단)', re.IGNORECASE)
_CONTINUATION_RE = re.compile(
    r'(?:^|\s|,)(?:그거|그걸|아까|방금|앞에서|이전|위에서)(?:\s|,|$)|'
    r'(?:이|그)\s*(?:파일|코드|부분|문제)[^\n]{0,36}(?:찾|고치|고쳐|수정|분석|확인|봐|이어|계속)|'
    r'(?:previous|earlier|the\s+previous|the\s+earlier)',
    re.IGNORECASE,
)
_ADDITIVE_CONTINUATION_RE = re.compile(
    r'^\s*(?:그리고|또|거기에|여기에|그(?:것|거)에)\s+[^\n]{0,160}?(?:도\s*)?(?:추가|더\s*해|포함|같이|함께|반영)',
    re.IGNORECASE,
)
_PERSISTENCE_CONTINUATION_RE = re.compile(
    r"^\s*(?:쭉\s*밀라고\s*)?왜\s*자꾸(?:\s*처)?\s*멈추냐고[~!?.…\s]*$|"
    r"^\s*끝까지\s*밀어[~!?.…\s]*$|"
    r"^\s*멈추지\s*말고\s*계속해[~!?.…\s]*$|"
    r"^\s*keep\s+pushing[~!?.…\s]*$|"
    r"^\s*don['’]?t\s+stop[~!?.…\s]*$",
    re.IGNORECASE,
)
_BARE_CONTINUATION_RE = re.compile(
    r'^\s*(?:(?:생각|작업|답변|진행)?[^\n]{0,28}(?:멈춘|멈췄|끊긴|중단된)[^\n]{0,20})?'
    r'(?:(?:그거|그걸|아까(?:거|꺼)?)\s*)?(?:이어서|이어가|이어거|계속|계속해서|진행)'
    r'(?:\s*(?:해|해줘|하자|가자|진행해))?[~!?.…,\s-]*$',
    re.IGNORECASE,
)


def explicit_request_present(text: str) -> bool:
    """Recognize a source request without letting topic/context labels veto it.

    A question about a capability remains information-seeking; a polite request,
    current preference, or imperative is an instruction to act on its exact target.
    """
    raw = str(text).strip()
    return bool(
        _IMPERATIVE_END_RE.search(raw)
        or _REQUEST_QUESTION_RE.search(raw)
        or _PREFERENCE_REQUEST_RE.search(raw)
        or re.search(r"\b(?:i\s+(?:want|need)\s+(?:you\s+)?to|please|would\s+you|could\s+you|can\s+you)\b", raw, re.I)
        or re.match(r"\s*(?:now\s+|then\s+|also\s+)?(?:implement|modify|replace|build|run|execute|apply|integrate|create|search|find|fix|connect|use|preserve|keep|write|read|remove|deploy)\b", raw, re.I)
    )


def quote_adoption_requested(text: str) -> bool:
    raw = str(text).strip()
    return bool(_QUOTE_RE.fullmatch(raw) or re.search(
        r"(?:그대로|인용(?:한|된)?\s*(?:요구|지시|명령).{0,16}(?:따라|실행|적용)|"
        r"(?:follow|execute|apply|implement)\s+(?:this|that|the\s+quoted)|as\s+quoted)", raw, re.I
    ))


@dataclass(frozen=True)
class DirectiveClause:
    clause_id: str
    turn_id: str
    source_span: tuple[int, int]
    source_text: str
    modality: str
    polarity: str
    target: str
    effect: str
    quoted: bool = False
    hypothetical: bool = False
    authoritative: bool = False
    discourse_relation: str = "asserts"
    reference_kind: str = "none"
    metadata: tuple[tuple[str, str], ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class ClauseGraph:
    graph_id: str
    turn_id: str
    source_sha256: str
    source_text: str
    clauses: tuple[DirectiveClause, ...]

    @property
    def authoritative_clauses(self) -> tuple[DirectiveClause, ...]:
        return tuple(c for c in self.clauses if c.authoritative)

    @property
    def has_continuation_reference(self) -> bool:
        return any(c.reference_kind != "none" for c in self.clauses if not c.quoted)


@dataclass(frozen=True)
class ContinuitySignal:
    mode: str
    evidence: tuple[str, ...]


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _trim_span(text: str, start: int, end: int) -> tuple[int, int]:
    while start < end and text[start].isspace():
        start += 1
    while end > start and text[end - 1].isspace():
        end -= 1
    return start, end


def _iter_segments(text: str, masked: str) -> Iterable[tuple[int, int]]:
    """Yield source spans using punctuation and discourse conjunction boundaries.

    We intentionally avoid an action dictionary.  Splits are grammatical/discourse
    boundaries only.  `하지 말고` is a polarity-bearing coordination boundary and is
    kept with the negative clause so the following positive directive remains separate.
    """
    base = 0
    for sentence in _SENTENCE_BOUNDARY_RE.split(masked):
        if not sentence:
            base += 1
            continue
        located = masked.find(sentence, base)
        if located < 0:
            continue
        s_start, s_end = located, located + len(sentence)
        # Commas are strong clause boundaries.  Additionally split after a negative
        # `...하지 말고` coordinator and after `...취소하고` correction coordinators.
        cursor = s_start
        local = text[s_start:s_end]
        boundary_re = re.compile(r',|(?<=말고)\s+|(?<=취소하고)\s+', re.IGNORECASE)
        for match in boundary_re.finditer(local):
            end = s_start + match.start()
            if match.group(0) != ',':
                end = s_start + match.start()
            a, b = _trim_span(text, cursor, end)
            if a < b:
                yield a, b
            cursor = s_start + match.end()
        a, b = _trim_span(text, cursor, s_end)
        if a < b:
            yield a, b
        base = s_end


def _effect_and_target(clause: str) -> tuple[str, str]:
    clean = clause.strip().rstrip(".!?~…")
    if not clean:
        return "", ""
    tokens = clean.split()
    if len(tokens) == 1:
        return tokens[0], ""
    effect = tokens[-1]
    target = " ".join(tokens[:-1])
    return effect, target


def _modality(clause: str, *, sentence_imperative: bool) -> str:
    # Final directive morphology owns the clause. Embedded conditionals such as
    # "무료면 ... 끝까지 보고해" constrain execution but do not downgrade the
    # current user's directive into a non-authoritative hypothetical.
    if _IMPERATIVE_END_RE.search(clause) or (sentence_imperative and _CONJUNCTIVE_END_RE.search(clause)):
        return "imperative"
    if _QUESTION_RE.search(clause):
        return "interrogative"
    if _CONDITIONAL_RE.search(clause):
        return "conditional"
    # Negative coordination (`하지 말고`) is an imperative prohibition when the
    # surrounding sentence is directive.
    if sentence_imperative and _NEGATIVE_RE.search(clause):
        return "imperative"
    return "declarative"


def _speech_act(
    clause: str, *, modality: str, relation: str, continuation_mode: str
) -> str:
    """Classify what the user is doing with the clause, independent of morphology.

    Morphology remains useful metadata, but authority is granted by the current
    speech act/intent.  This keeps polite Korean question requests, preferences and
    conditional directives from being downgraded merely because they do not end in
    a finite imperative suffix.
    """
    raw = str(clause).strip()
    if relation == "cancels":
        return "cancellation"
    if relation == "corrects":
        return "correction"
    if _DIRECT_PROHIBITION_RE.search(raw):
        return "prohibition"
    if _PREFERENCE_REQUEST_RE.search(raw):
        return "preference_request"
    is_question = bool(_QUESTION_RE.search(raw))
    has_action = bool(_ACTION_INTENT_RE.search(raw))
    if is_question and (_REQUEST_QUESTION_RE.search(raw) or has_action):
        return "request_with_question"
    if is_question:
        return "question"
    if explicit_request_present(raw) or has_action or modality == "imperative":
        return "directive"
    if continuation_mode != "none":
        return "continuation"
    return "assertion"


def _speech_act_authoritative(speech_act: str) -> bool:
    return str(speech_act) in {
        "directive", "request_with_question", "question", "preference_request",
        "prohibition", "correction", "cancellation", "continuation",
    }


def continuity_signal(message: str) -> ContinuitySignal:
    text = str(message or "").strip()
    if not text:
        return ContinuitySignal("none", ())
    if _BARE_CONTINUATION_RE.match(text):
        return ContinuitySignal("bare", ("source_clause:bare_continuation",))
    if _PERSISTENCE_CONTINUATION_RE.match(text):
        return ContinuitySignal("referential_extension", ("source_clause:persistence_continuation",))
    if re.match(r'^\s*(?:이어서|이어가|계속해서|continue(?:\s+with)?)\s+\S',text,re.I) and explicit_request_present(text):
        return ContinuitySignal("referential_extension",("source_clause:continuation_with_current_change",))
    if _CONTINUATION_RE.search(text):
        return ContinuitySignal("referential_extension", ("source_clause:cross_turn_reference",))
    if _ADDITIVE_CONTINUATION_RE.search(text):
        return ContinuitySignal("referential_extension", ("source_clause:additive_continuation",))
    if _REPORTED_DIRECTIVE_CORRECTION_RE.search(text):
        return ContinuitySignal("referential_extension", ("source_clause:reported_directive_correction",))
    if _CORRECTION_RE.search(text) and re.search(r'(?:아까|방금|이전|앞에서|그거|그걸)', text):
        return ContinuitySignal("referential_extension", ("source_clause:referential_correction",))
    return ContinuitySignal("none", ())


class SourceDirectiveCompiler:
    """Compile exact user source into an open clause graph.

    `effect` and `target` remain source-derived open strings.  No finite outcome/task
    taxonomy is used here.  Downstream components may form hypotheses from them, but
    only authoritative clauses can grant or constrain current-turn effects.
    """

    def compile(self, source_text: str, *, turn_id: str = "") -> ClauseGraph:
        text = str(source_text)
        tid = str(turn_id or ("turn_" + _sha(text)[:12]))
        quoted_spans: list[tuple[int, int, str]] = []
        adopted_quote = quote_adoption_requested(text)
        mask = list(text)
        for match in _QUOTE_RE.finditer(text):
            if match.group("close") != {'"': '"', "“": "”", "'": "'", "‘": "’"}[match.group("open")]:
                continue
            start, end = match.span()
            inner_start, inner_end = match.start("body"), match.end("body")
            quoted_spans.append((inner_start, inner_end, match.group("body")))
            for i in range(start, end):
                mask[i] = " "
        masked = "".join(mask)

        clauses: list[DirectiveClause] = []
        for q_start, q_end, q_text in quoted_spans:
            effect, target = _effect_and_target(q_text)
            material = f"{tid}:{q_start}:{q_end}:{q_text}:quoted"
            clauses.append(DirectiveClause(
                clause_id="clause_" + _sha(material)[:16],
                turn_id=tid,
                source_span=(q_start, q_end),
                source_text=q_text,
                modality="mention",
                polarity="positive",
                target=target,
                effect=effect,
                quoted=True,
                hypothetical=False,
                authoritative=adopted_quote and explicit_request_present(q_text),
                discourse_relation="mentions",
                metadata=(("adopted_as_current_requirement", str(adopted_quote).lower()),),
            ))

        sentence_imperative = bool(_IMPERATIVE_END_RE.search(text.strip()))
        signal = continuity_signal(text)
        for start, end in _iter_segments(text, masked):
            raw = text[start:end].strip()
            if not raw:
                continue
            modality = _modality(raw, sentence_imperative=sentence_imperative)
            # Conditional language is recorded as a condition, not used as an
            # authority veto.  The current speech act decides authority below.
            hypothetical = modality == "conditional"
            effect, target = _effect_and_target(raw)
            relation = "asserts"
            if (
                _CORRECTION_RE.search(raw)
                or (_CORRECTION_RE.search(text) and start > 0)
                or _REPORTED_DIRECTIVE_CORRECTION_RE.search(raw)
                or (_REPORTED_DIRECTIVE_CORRECTION_RE.search(text) and start > 0)
            ):
                relation = "corrects"
            # Cancellation is a speech act.  Embedded negation elsewhere must not
            # flip the whole clause into a prohibition (e.g. "설치하지 않고 ... 원해").
            if _CANCEL_RE.search(raw) and signal.mode != "none":
                relation = "cancels"
            elif signal.mode != "none" and relation == "asserts":
                relation = "continues"
            reference_kind = signal.mode if signal.mode != "none" else "none"
            speech_act = _speech_act(raw, modality=modality, relation=relation, continuation_mode=signal.mode)
            polarity = "negative" if speech_act == "prohibition" else "positive"
            authoritative = _speech_act_authoritative(speech_act)
            material = f"{tid}:{start}:{end}:{raw}:{modality}:{polarity}:{relation}:{speech_act}"
            clauses.append(DirectiveClause(
                clause_id="clause_" + _sha(material)[:16],
                turn_id=tid,
                source_span=(start, end),
                source_text=raw,
                modality=modality,
                polarity=polarity,
                target=target,
                effect=effect,
                quoted=False,
                hypothetical=hypothetical,
                authoritative=authoritative,
                discourse_relation=relation,
                reference_kind=reference_kind,
                metadata=(("speech_act", speech_act), ("authority_basis", "speech_act_intent")),
            ))

        clauses.sort(key=lambda c: (c.source_span[0], c.source_span[1], c.quoted))
        graph_material = "|".join(c.clause_id for c in clauses)
        return ClauseGraph(
            graph_id="clause_graph_" + _sha(f"{tid}:{_sha(text)}:{graph_material}")[:20],
            turn_id=tid,
            source_sha256=_sha(text),
            source_text=text,
            clauses=tuple(clauses),
        )
