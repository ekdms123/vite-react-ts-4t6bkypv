from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ResourceSample:
    route_id: str
    objective_fidelity: float
    quality_score: float
    duration_s: float | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    cpu_time_s: float | None = None
    peak_memory_bytes: int | None = None
    energy_joules: float | None = None
    thermal_state: str | None = None
    metadata: dict[str, Any] = None
    observed_at: float = 0.0


class ResourceTelemetry:
    """Records empirical resource and performance measurements without assumptions."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(json.dumps({"samples": []}, indent=2), encoding="utf-8")

    def record(self, *, route_id: str, objective_fidelity: float, quality_score: float, **metrics: Any) -> ResourceSample:
        row = ResourceSample(
            route_id=str(route_id),
            objective_fidelity=float(objective_fidelity),
            quality_score=float(quality_score),
            duration_s=metrics.get("duration_s"),
            input_tokens=metrics.get("input_tokens"),
            output_tokens=metrics.get("output_tokens"),
            cpu_time_s=metrics.get("cpu_time_s"),
            peak_memory_bytes=metrics.get("peak_memory_bytes"),
            energy_joules=metrics.get("energy_joules"),
            thermal_state=metrics.get("thermal_state"),
            metadata=dict(metrics.get("metadata") or {}),
            observed_at=time.time(),
        )
        data = json.loads(self.path.read_text(encoding="utf-8"))
        data["samples"].append(asdict(row))
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return row

    def pareto_candidates(self, *, minimum_fidelity: float = 1.0) -> tuple[ResourceSample, ...]:
        rows = []
        for raw in json.loads(self.path.read_text(encoding="utf-8")).get("samples", []):
            row = ResourceSample(**raw)
            if row.objective_fidelity >= float(minimum_fidelity):
                rows.append(row)
        rows.sort(key=lambda x: (
            -x.quality_score,
            float("inf") if x.duration_s is None else x.duration_s,
            float("inf") if x.output_tokens is None else x.output_tokens,
        ))
        return tuple(rows)
