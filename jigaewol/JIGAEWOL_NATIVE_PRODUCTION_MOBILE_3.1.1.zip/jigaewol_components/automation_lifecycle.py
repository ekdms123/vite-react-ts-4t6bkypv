from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Mapping


def _sha(value: Any) -> str:
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),default=str)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


@dataclass(frozen=True)
class AutomationBinding:
    binding_id: str
    objective: str
    mode: str
    schedule_spec: str
    work_node_id: str
    state: str
    external_task_ref: str
    creation_evidence_refs: tuple[str,...]
    created_at: float
    updated_at: float
    last_run_id: str=''


@dataclass(frozen=True)
class AutomationRun:
    run_id: str
    binding_id: str
    observed: bool
    success: bool | None
    result: Any
    evidence_refs: tuple[str,...]
    observed_at: float


class AutomationLifecycleRegistry:
    """Bind real scheduled/conditional host tasks to JIGAEWOL work continuity."""

    FORMAT='jigaewol_automation_lifecycle_v1'
    MODES=frozenset({'exact_schedule','flexible_schedule','condition_watch'})

    def __init__(self, root: str | Path) -> None:
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'automations.json'; self.runs_path=self.root/'runs.jsonl'
        if not self.path.exists(): self._write({'format':self.FORMAT,'bindings':{}})
        self.runs_path.touch(exist_ok=True)

    def _read(self):
        data=json.loads(self.path.read_text(encoding='utf-8'))
        if data.get('format')!=self.FORMAT: raise ValueError('automation lifecycle format mismatch')
        data.setdefault('bindings',{}); return data

    def _write(self,data):
        tmp=self.path.with_suffix('.tmp'); tmp.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8'); tmp.replace(self.path)

    def plan(self, *, objective: str, mode: str, schedule_spec: str, work_node_id: str='') -> AutomationBinding:
        mode=str(mode).strip()
        if not mode:
            raise ValueError('automation mode must be nonempty text')
        # MODES are native host hints, not the ontology of all schedulable behavior.
        # Emergent modes remain planned and are proven/rejected at the actual host execution interface.
        seed={'objective':str(objective),'mode':mode,'schedule_spec':str(schedule_spec),'work_node_id':str(work_node_id)}
        bid='auto_'+_sha(seed)[:20]; now=time.time(); data=self._read(); old=data['bindings'].get(bid)
        row=AutomationBinding(bid,str(objective),mode,str(schedule_spec),str(work_node_id),str((old or {}).get('state') or 'planned'),str((old or {}).get('external_task_ref') or ''),tuple((old or {}).get('creation_evidence_refs') or ()),float((old or {}).get('created_at') or now),now,str((old or {}).get('last_run_id') or ''))
        data['bindings'][bid]=asdict(row); self._write(data); return row

    def get(self,binding_id: str) -> AutomationBinding:
        raw=self._read()['bindings'].get(str(binding_id))
        if raw is None: raise KeyError(binding_id)
        row=dict(raw); row['creation_evidence_refs']=tuple(row.get('creation_evidence_refs') or ())
        return AutomationBinding(**row)

    def bind_scheduled(self, binding_id: str, *, external_task_ref: str, evidence_refs: Iterable[str]) -> AutomationBinding:
        current=self.get(binding_id); ext=str(external_task_ref).strip(); refs=tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x).strip()))
        if not ext or not refs: raise ValueError('scheduled state requires external task ref and observed creation evidence')
        row=replace(current,state='scheduled',external_task_ref=ext,creation_evidence_refs=refs,updated_at=time.time())
        data=self._read(); data['bindings'][binding_id]=asdict(row); self._write(data); return row

    def record_run(self, binding_id: str, *, observed: bool, success: bool | None, result: Any, evidence_refs: Iterable[str]) -> AutomationRun:
        current=self.get(binding_id)
        if current.state!='scheduled': raise ValueError('automation must be scheduled before runs can be recorded')
        refs=tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x).strip()))
        if observed is not True or not refs: raise ValueError('automation run requires observed host evidence')
        material={'binding_id':binding_id,'result':result,'refs':refs,'time_bucket':int(time.time()*1000)}
        run=AutomationRun('autorun_'+_sha(material)[:20],binding_id,True,success,result,refs,time.time())
        with self.runs_path.open('a',encoding='utf-8') as fh: fh.write(json.dumps(asdict(run),ensure_ascii=False,sort_keys=True,default=str)+'\n')
        data=self._read(); row=dict(data['bindings'][binding_id]); row['last_run_id']=run.run_id; row['updated_at']=time.time(); data['bindings'][binding_id]=row; self._write(data)
        return run

    def runs(self,binding_id: str | None=None) -> tuple[AutomationRun,...]:
        out=[]
        for line in self.runs_path.read_text(encoding='utf-8').splitlines():
            if not line.strip(): continue
            raw=json.loads(line); raw['evidence_refs']=tuple(raw.get('evidence_refs') or ())
            row=AutomationRun(**raw)
            if binding_id is None or row.binding_id==str(binding_id): out.append(row)
        return tuple(out)

    def turn_context(self) -> dict[str,Any]:
        bindings=[self.get(k) for k in self._read()['bindings']]
        scheduled=[x for x in bindings if x.state=='scheduled']
        latest={}
        for run in self.runs(): latest[run.binding_id]=run
        return {
            'scheduled':[asdict(x) for x in scheduled],
            'latest_runs':{k:asdict(v) for k,v in latest.items()},
            'execution_results_are_receipts_not_schedule_claims':True,
        }
