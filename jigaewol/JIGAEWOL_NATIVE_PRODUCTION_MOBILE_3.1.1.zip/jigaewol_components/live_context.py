from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ContextObservation:
    observation_id: str
    modality: str
    source: str
    payload_ref: str
    payload_sha256: str
    summary: str
    observed_at: float
    metadata: dict[str, Any] = field(default_factory=dict)


class LiveContextTimeline:
    """Persistent multimodal and event timeline with flexible modality support.

    Accommodates text, image, browser, system, file, and newly discovered sensory data
    consistently without constraining inputs to an arbitrary predefined list.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"observations": []})

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def append(
        self,
        *,
        modality: str,
        source: str,
        payload_ref: str = "",
        payload_bytes: bytes | None = None,
        summary: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> ContextObservation:
        digest = hashlib.sha256(
            payload_bytes if payload_bytes is not None else str(payload_ref).encode("utf-8")
        ).hexdigest()
        row = ContextObservation(
            observation_id=f"obs_{uuid.uuid4().hex[:16]}",
            modality=str(modality),
            source=str(source),
            payload_ref=str(payload_ref),
            payload_sha256=digest,
            summary=str(summary),
            observed_at=time.time(),
            metadata=dict(metadata or {}),
        )
        data = self._read()
        data.setdefault("observations", []).append(asdict(row))
        self._write(data)
        return row

    def recent(self, limit: int | None = None) -> tuple[ContextObservation, ...]:
        rows = self._read().get("observations", [])
        if limit is not None:
            rows = rows[-max(0, int(limit)) :]
        return tuple(ContextObservation(**x) for x in rows)
