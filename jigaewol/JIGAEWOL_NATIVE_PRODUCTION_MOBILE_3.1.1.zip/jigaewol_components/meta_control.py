from __future__ import annotations

import copy
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from .capability_bus import (
    CapabilityAcquirer,
    CapabilityDescriptor,
    CapabilityInvocation,
    CapabilityComponent,
    CapabilityRequirement,
    CapabilityResult,
    UniversalCapabilityBus,
)
from .runtime_orchestrator import GoalEnvelope
from .revision_kernel import RevisionKernel
from .work_capsule import WorkCapsule
from .protocol_codec import ProtocolCodecRegistry
from .failure_router import FailureRouter
from .open_world_guard import OpenWorldConstraintAuditor, OpenWorldGuard, ThoughtAudit, ThoughtCandidate
from .user_contract import UserObjectiveContract, load_user_objective_contract


@dataclass(frozen=True)
class ControlTopologyRequest:
    goal: GoalEnvelope
    self_model: dict[str, Any]
    capability_snapshot: dict[str, Any]
    neutral_state: dict[str, Any]
    run_id: str
    extensions: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ControlTopologyOutcome:
    completed: bool
    output: Any
    topology_id: str
    trace: tuple[dict[str, Any], ...] = ()
    observations: tuple[dict[str, Any], ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class MetaControlResult:
    run_id: str
    objective: str
    completed: bool
    output: Any
    topology_id: str
    selector_id: str | None
    trace: tuple[dict[str, Any], ...]
    capability_snapshot: dict[str, Any]
    self_model: dict[str, Any]


TopologySelector = Callable[[ControlTopologyRequest, tuple[CapabilityDescriptor, ...]], str | None]
TopologyExpander = Callable[[ControlTopologyRequest, tuple[CapabilityDescriptor, ...], ThoughtAudit], Iterable[CapabilityComponent]]


def _goal_completion_authorized(goal: GoalEnvelope) -> tuple[bool, tuple[str, ...]]:
    """Completion authority comes from outer observed Work, never topology output.

    A planner/control topology may report that it believes the objective is done, but
    that belief cannot close the user's destination. The caller must already carry a
    separate observed completion proof into the GoalEnvelope.
    """
    refs = tuple(
        str(x) for x in (goal.extensions.get("objective_completion_evidence_refs") or ())
        if str(x)
    )
    proven = bool(goal.extensions.get("objective_completion_proven")) and bool(refs)
    return proven, refs


class MetaControlPlane:
    federated_role = "optional_controller"
    """Orchestrates interchangeable control topologies dynamically.

    Topologies can be model-backed, solver-directed, simulation-driven, or rule-based.
    Separates objective pursuit from rigid grammar constraints and allows modular expansion.
    """

    def __init__(
        self,
        root: Path,
        *,
        kernel: RevisionKernel,
        bus: UniversalCapabilityBus,
        acquirer: CapabilityAcquirer | None = None,
        open_world_guard: OpenWorldGuard | None = None,
        topology_expander: TopologyExpander | None = None,
        audit_source_root: Path | None = None,
        user_contract: UserObjectiveContract | None = None,
        protocol_codecs: ProtocolCodecRegistry | None = None,
    ) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.kernel = kernel
        self.bus = bus
        self.acquirer = acquirer
        self.open_world_guard = open_world_guard or OpenWorldGuard()
        self.topology_expander = topology_expander
        self.audit_source_root = (audit_source_root or Path(__file__).resolve().parent).resolve()
        self.user_contract = user_contract or load_user_objective_contract()
        self.protocol_codecs = protocol_codecs or ProtocolCodecRegistry()
        self.failure_router = FailureRouter(self.root / "failure_events.json")
        self.control_codec = self.protocol_codecs.ensure("meta_control", {
            "completed": ("done", "finished"), "output": ("result", "answer"),
            "topology_id": ("topology", "controller_id"), "trace": ("events",),
            "observations": ("evidence",), "metadata": ("meta",),
            "direct_route": ("route",), "requirement": ("need",),
            "provides": ("offers",), "kinds": ("types",), "tags": ("facets",),
            "location": ("where",), "payload": ("args",), "score": ("fitness",),
            "content": ("value",), "messages": ("turns",),
        })

    def _self_model(self) -> dict[str, Any]:
        model = self.kernel.refresh_self_model()
        model.capabilities = [x.capability_id for x in self.bus.descriptors()]
        self.kernel.self_store.save(model)
        return asdict(model)

    def _request(self, goal: GoalEnvelope, run_id: str) -> ControlTopologyRequest:
        return ControlTopologyRequest(
            goal=goal,
            self_model=self._self_model(),
            capability_snapshot=self.bus.snapshot(),
            neutral_state=copy.deepcopy(self.kernel.neutral_state.facts),
            run_id=run_id,
        )

    @staticmethod
    def _topology_descriptors(bus: UniversalCapabilityBus) -> tuple[CapabilityDescriptor, ...]:
        return bus.discover(
            CapabilityRequirement(provides=("goal_pursuit",), kinds=("control_topology",))
        )

    @staticmethod
    def _topology_population(topologies: tuple[CapabilityDescriptor, ...]) -> tuple[ThoughtCandidate, ...]:
        rows = []
        for item in topologies:
            rows.append(ThoughtCandidate(
                candidate_id=item.capability_id,
                payload=asdict(item),
                frame=str(item.metadata.get("frame", item.metadata.get("topology", item.capability_id))),
                mechanism=str(item.metadata.get("mechanism", item.metadata.get("topology", item.kind))),
                source_family=str(item.metadata.get("source_family", item.location)),
                topology=str(item.metadata.get("topology", item.capability_id)),
                failure_family=str(item.metadata.get("failure_family", item.metadata.get("topology", item.kind))),
                substrate=str(item.metadata.get("substrate", item.location)),
                outside_taxonomy=bool(item.metadata.get("outside_taxonomy", False)),
                score=float(item.priority),
            ))
        return tuple(rows)

    def _expand_topologies_if_closed(
        self,
        request: ControlTopologyRequest,
        topologies: tuple[CapabilityDescriptor, ...],
    ) -> tuple[CapabilityDescriptor, ...]:
        audit = self.open_world_guard.thoughts.audit(self._topology_population(topologies))
        audit_row = {"phase": "before", **asdict(audit)}
        self.kernel.neutral_state.facts["control_topology_thought_audit"] = asdict(audit)
        self.kernel.neutral_state.facts.setdefault("control_topology_audit_history", []).append(audit_row)
        if audit.closed and self.topology_expander is not None:
            for component in self.topology_expander(request, topologies, audit):
                self.bus.register(component)
            topologies = self._topology_descriptors(self.bus)
            audit = self.open_world_guard.thoughts.audit(self._topology_population(topologies))
            self.kernel.neutral_state.facts["control_topology_thought_audit_after_expansion"] = asdict(audit)
            self.kernel.neutral_state.facts.setdefault("control_topology_audit_history", []).append({"phase": "after_expansion", **asdict(audit)})
        runtime_findings = self.open_world_guard.runtime_findings(self.bus, self.kernel.neutral_state.facts)
        self.kernel.neutral_state.facts["open_world_runtime_findings"] = [asdict(x) for x in runtime_findings]
        if self.audit_source_root is not None:
            report = OpenWorldConstraintAuditor().scan_tree(self.audit_source_root)
            self.kernel.neutral_state.facts["open_world_source_audit"] = {
                "scanned_files": report.scanned_files,
                "finding_count": len(report.findings),
                "category_counts": copy.deepcopy(report.category_counts),
                "closedness_score": report.closedness_score,
            }
        return topologies

    def _invoke_topology_once(
        self,
        topology_id: str,
        *,
        goal: GoalEnvelope,
        request: ControlTopologyRequest,
        run_id: str,
        selector_id: str | None,
    ) -> ControlTopologyOutcome:
        outcome_result = self.bus.invoke(
            topology_id,
            objective=goal.objective,
            payload={
                "goal": asdict(goal),
                "self_model": request.self_model,
                "capability_snapshot": request.capability_snapshot,
                "neutral_state": request.neutral_state,
                "run_id": run_id,
            },
            context={"run_id": run_id, "selector_id": selector_id},
        )
        if not outcome_result.success:
            outcome = ControlTopologyOutcome(
                completed=False,
                output=None,
                topology_id=topology_id,
                trace=({"error": outcome_result.error},),
            )
        else:
            raw = outcome_result.output
            outer_completion_proven, outer_completion_refs = _goal_completion_authorized(goal)
            if isinstance(raw, ControlTopologyOutcome):
                topology_completion_claim = bool(raw.completed)
                metadata = copy.deepcopy(raw.metadata)
                if topology_completion_claim and not outer_completion_proven:
                    metadata["completion_claim_rejected"] = "topology_cannot_self_authorize_user_goal_completion"
                metadata["objective_completion_evidence_refs"] = list(outer_completion_refs)
                outcome = ControlTopologyOutcome(
                    completed=bool(topology_completion_claim and outer_completion_proven),
                    output=copy.deepcopy(raw.output),
                    topology_id=raw.topology_id,
                    trace=tuple(copy.deepcopy(raw.trace)),
                    observations=tuple(copy.deepcopy(raw.observations)),
                    metadata=metadata,
                )
            elif isinstance(raw, dict):
                topology_completion_claim = bool(self.control_codec.read(raw, "objective_completion_proven", False))
                metadata = copy.deepcopy(self.control_codec.read(raw, "metadata", {}))
                if topology_completion_claim and not outer_completion_proven:
                    metadata["completion_claim_rejected"] = "topology_cannot_self_authorize_user_goal_completion"
                metadata["objective_completion_evidence_refs"] = list(outer_completion_refs)
                outcome = ControlTopologyOutcome(
                    completed=bool(topology_completion_claim and outer_completion_proven),
                    output=copy.deepcopy(self.control_codec.read(raw, "output")),
                    topology_id=str(self.control_codec.read(raw, "topology_id") or topology_id),
                    trace=tuple(copy.deepcopy(self.control_codec.read(raw, "trace", ()))),
                    observations=tuple(copy.deepcopy(self.control_codec.read(raw, "observations", ()))),
                    metadata=metadata,
                )
            else:
                outcome = ControlTopologyOutcome(False, copy.deepcopy(raw), topology_id)

        findings = self.user_contract.alignment_findings(goal.objective, outcome.metadata)
        if findings:
            metadata = copy.deepcopy(outcome.metadata)
            metadata["user_alignment_findings"] = list(findings)
            blocking = self.user_contract.release_blocking_findings(findings)
            metadata["user_alignment_release_blocking_findings"] = list(blocking)
            metadata["derived_result_may_not_self_authorize_destination_drift"] = True
            trace = tuple(outcome.trace) + tuple({"user_alignment_repair_signal": x} for x in findings)
            self.kernel.neutral_state.facts.setdefault("user_alignment_history", []).append({
                "run_id": run_id,
                "topology_id": topology_id,
                "objective": goal.objective,
                "findings": list(findings),
                "blocking_findings": list(blocking),
                "timestamp": time.time(),
            })
            # Alignment violations are not merely diagnostics.  Preserve the candidate
            # output as inspectable non-authoritative evidence, but revoke completion
            # authority so the control plane must repair/switch route instead of letting
            # A->B drift pass through as a completed result.
            if blocking:
                metadata["quarantined_non_authoritative_output"] = copy.deepcopy(outcome.output)
            outcome = ControlTopologyOutcome(
                completed=bool(outcome.completed and not blocking),
                output=(None if blocking else copy.deepcopy(outcome.output)),
                topology_id=outcome.topology_id,
                trace=trace,
                observations=outcome.observations,
                metadata=metadata,
            )
        return outcome

    def pursue(
        self,
        goal: GoalEnvelope,
        *,
        selector_requirement: CapabilityRequirement | None = None,
        topology_requirement: CapabilityRequirement | None = None,
    ) -> MetaControlResult:
        run_id = f"meta_{uuid.uuid4().hex[:16]}"
        self.kernel.neutral_state.facts["user_objective_contract"] = self.user_contract.snapshot()
        self.kernel.neutral_state.facts["objective_anchor"] = goal.objective
        capsule = WorkCapsule.load(self.kernel.capsule_path)
        capsule.objective = goal.objective
        capsule.inputs.update(copy.deepcopy(goal.inputs))
        capsule.completion_conditions = list(goal.completion_conditions)
        capsule.budgets.update(copy.deepcopy(goal.budgets))
        capsule.permissions.update(copy.deepcopy(goal.permissions))
        capsule.save(self.kernel.capsule_path)

        request = self._request(goal, run_id)
        topologies = self._topology_descriptors(self.bus)
        topologies = self._expand_topologies_if_closed(request, topologies)
        selector_id: str | None = None
        topology_id: str | None = None

        if topology_requirement is not None:
            topology_id = self.bus.resolve(
                topology_requirement,
                objective=goal.objective,
                context={"run_id": run_id},
                acquirer=self.acquirer,
            ).capability_id
        else:
            selector_req = selector_requirement or CapabilityRequirement(
                provides=("control_topology_selection",),
                kinds=("meta_control",),
            )
            try:
                selector_desc = self.bus.resolve(
                    selector_req,
                    objective=goal.objective,
                    context={"run_id": run_id},
                    acquirer=self.acquirer,
                )
                selector_id = selector_desc.capability_id
                selector_result = self.bus.invoke(
                    selector_id,
                    objective=goal.objective,
                    payload={
                        "goal": asdict(goal),
                        "topologies": [asdict(x) for x in topologies],
                        "self_model": request.self_model,
                        "capability_snapshot": request.capability_snapshot,
                    },
                    context={"run_id": run_id},
                )
                if selector_result.success:
                    value = selector_result.output
                    if isinstance(value, dict):
                        topology_id = self.control_codec.read(value, "topology_id")
                    elif value is not None:
                        topology_id = str(value)
            except LookupError:
                selector_id = None

        if topology_id is None and not topologies:
            error = LookupError("no control topology is currently available")
            event = self.failure_router.record(error, operation="meta_control", route_id="topology_resolution", failure_family="no_topology", context={"objective": goal.objective})
            directive = self.failure_router.directive(event)
            self.kernel.neutral_state.facts.setdefault("route_revision_requests", []).append(asdict(directive))
            outcome = ControlTopologyOutcome(
                completed=False, output=None, topology_id="unresolved_topology",
                trace=({"failure_event": asdict(event), "route_mutation": asdict(directive)},),
                metadata={"failure_event_id": event.event_id, "objective_anchor": goal.objective},
            )
            topology_id = outcome.topology_id
        else:
            if topology_id is None:
                usage = copy.deepcopy(self.kernel.neutral_state.facts.get("control_topology_usage", {}))
                topology_id = self.open_world_guard.choose_least_used(topologies, usage).capability_id
            outcome = self._invoke_topology_once(
                topology_id, goal=goal, request=request, run_id=run_id, selector_id=selector_id,
            )

        enforcement = self.user_contract.data.get("enforcement", {})
        if bool(enforcement.get("retry_on_incomplete_route", False)) and not outcome.completed:
            usage = copy.deepcopy(self.kernel.neutral_state.facts.get("control_topology_usage", {}))
            primary = next((x for x in topologies if x.capability_id == topology_id), None)
            primary_failure_family = str((primary.metadata if primary else {}).get("failure_family", ""))
            alternatives = [x for x in topologies if x.capability_id != topology_id]
            alternatives.sort(key=lambda x: (
                0 if str(x.metadata.get("failure_family", "")) != primary_failure_family else 1,
                int(usage.get(x.capability_id, 0)),
                -float(x.priority),
                x.capability_id,
            ))
            route_history = self.kernel.neutral_state.facts.setdefault("contract_route_switch_history", [])
            for alternative in alternatives:
                route_history.append({
                    "run_id": run_id,
                    "from_topology": outcome.topology_id,
                    "to_topology": alternative.capability_id,
                    "reason": "contract_enforced_route_mutation",
                    "timestamp": time.time(),
                })
                candidate = self._invoke_topology_once(
                    alternative.capability_id,
                    goal=goal,
                    request=request,
                    run_id=run_id,
                    selector_id=selector_id,
                )
                outcome = candidate
                topology_id = candidate.topology_id
                if candidate.completed:
                    break

        self.kernel.neutral_state.facts["active_control_topology"] = outcome.topology_id
        usage = self.kernel.neutral_state.facts.setdefault("control_topology_usage", {})
        usage[outcome.topology_id] = int(usage.get(outcome.topology_id, 0)) + 1
        self.kernel.neutral_state.facts["last_meta_control_run"] = run_id
        self.kernel.neutral_state.observations.extend(copy.deepcopy(list(outcome.observations)))
        self.kernel.checkpoint_capsule()

        capsule = WorkCapsule.load(self.kernel.capsule_path)
        capsule.completed_actions.append(
            {
                "kind": "meta_control_run",
                "run_id": run_id,
                "topology_id": outcome.topology_id,
                "selector_id": selector_id,
                "completed": outcome.completed,
                "timestamp": time.time(),
            }
        )
        capsule.save(self.kernel.capsule_path)

        return MetaControlResult(
            run_id=run_id,
            objective=goal.objective,
            completed=outcome.completed,
            output=copy.deepcopy(outcome.output),
            topology_id=outcome.topology_id,
            selector_id=selector_id,
            trace=outcome.trace,
            capability_snapshot=self.bus.snapshot(),
            self_model=self._self_model(),
        )


class TopologySelectorComponent:
    """Replaceable selector that chooses among control topologies."""

    def __init__(
        self,
        capability_id: str,
        selector: TopologySelector,
        *,
        priority: float = 0.0,
    ) -> None:
        self.capability_id = capability_id
        self.selector = selector
        self.priority = priority

    def as_component(self) -> CapabilityComponent:
        descriptor = CapabilityDescriptor(
            self.capability_id,
            "meta_control",
            ("control_topology_selection",),
            tags=("replaceable_meta_control",),
            priority=self.priority,
        )

        def handler(call: CapabilityInvocation) -> dict[str, Any]:
            goal_row = call.payload["goal"]
            goal = GoalEnvelope(
                objective=str(goal_row["objective"]),
                inputs=copy.deepcopy(goal_row.get("inputs", {})),
                completion_conditions=tuple(goal_row.get("completion_conditions", ())),
                budgets=copy.deepcopy(goal_row.get("budgets", {})),
                permissions=copy.deepcopy(goal_row.get("permissions", {})),
            )
            topologies = tuple(CapabilityDescriptor(**row) for row in call.payload.get("topologies", ()))
            request = ControlTopologyRequest(
                goal=goal,
                self_model=copy.deepcopy(call.payload.get("self_model", {})),
                capability_snapshot=copy.deepcopy(call.payload.get("capability_snapshot", {})),
                neutral_state={},
                run_id=str(call.context.get("run_id", "")),
            )
            return {"topology_id": self.selector(request, topologies)}

        return CapabilityComponent(descriptor, handler)


class DirectCapabilityTopology:
    """Planner-free topology: invoke a semantically requested component directly."""

    def __init__(
        self,
        *,
        capability_id: str,
        bus: UniversalCapabilityBus,
        acquirer: CapabilityAcquirer | None = None,
        priority: float = 0.0,
    ) -> None:
        self.capability_id = capability_id
        self.bus = bus
        self.acquirer = acquirer
        self.priority = priority
        self.protocol = ProtocolCodecRegistry().ensure("direct_topology", {
            "direct_route": ("route",), "requirement": ("need",), "provides": ("offers",),
            "kinds": ("types",), "tags": ("facets",), "location": ("where",), "payload": ("args",)
        })

    def as_component(self) -> CapabilityComponent:
        descriptor = CapabilityDescriptor(
            self.capability_id,
            "control_topology",
            ("goal_pursuit", "brain_free_control"),
            tags=("direct", "no_brain"),
            priority=self.priority,
            metadata={"topology": "direct_capability"},
        )

        def handler(call: CapabilityInvocation) -> ControlTopologyOutcome:
            goal = call.payload["goal"]
            route = copy.deepcopy(self.protocol.read(goal.get("inputs", {}), "direct_route", {}) or {})
            req_row = self.protocol.read(route, "requirement", {}) or {}
            requirement = CapabilityRequirement(
                provides=tuple(self.protocol.read(req_row, "provides", ()) or ()),
                kinds=tuple(self.protocol.read(req_row, "kinds", ()) or ()),
                tags=tuple(self.protocol.read(req_row, "tags", ()) or ()),
                location=self.protocol.read(req_row, "location"),
            )
            result = self.bus.invoke_requirement(
                requirement,
                objective=call.objective,
                payload=copy.deepcopy(self.protocol.read(route, "payload", {}) or {}),
                context={"run_id": call.context.get("run_id"), "topology": self.capability_id},
                acquirer=self.acquirer,
            )
            return ControlTopologyOutcome(
                completed=result.success,
                output=copy.deepcopy(result.output),
                topology_id=self.capability_id,
                trace=(
                    {
                        "phase": "direct",
                        "capability_id": result.capability_id,
                        "success": result.success,
                    },
                ),
                observations=(
                    {
                        "capability_id": result.capability_id,
                        "success": result.success,
                        "output": copy.deepcopy(result.output),
                    },
                ),
            )

        return CapabilityComponent(descriptor, handler)


class ModelMarketTopology:
    """Run several model components independently, then select/synthesize a candidate."""

    def __init__(
        self,
        *,
        capability_id: str,
        bus: UniversalCapabilityBus,
        model_requirement: CapabilityRequirement,
        max_workers: int | None = None,
        priority: float = 0.0,
    ) -> None:
        self.capability_id = capability_id
        self.bus = bus
        self.model_requirement = model_requirement
        self.max_workers = None if max_workers is None else max(1, int(max_workers))
        self.priority = priority

    @staticmethod
    def _score(output: Any) -> float:
        if isinstance(output, dict):
            for key in ("score", "fitness"):
                if key in output and isinstance(output[key], (int, float)):
                    return float(output[key])
            content = output["content"] if "content" in output else output["value"] if "value" in output else None
            if isinstance(content, dict):
                for key in ("score", "fitness"):
                    if key in content and isinstance(content[key], (int, float)):
                        return float(content[key])
        return 0.0

    def as_component(self) -> CapabilityComponent:
        descriptor = CapabilityDescriptor(
            self.capability_id,
            "control_topology",
            ("goal_pursuit", "model_market_control"),
            tags=("market", "multi_model", "blind_population"),
            priority=self.priority,
            metadata={"topology": "model_market"},
        )

        def handler(call: CapabilityInvocation) -> ControlTopologyOutcome:
            models = self.bus.discover(self.model_requirement)
            if not models:
                return ControlTopologyOutcome(False, None, self.capability_id, trace=({"phase": "market", "error": "no_models"},))

            def invoke_model(desc: CapabilityDescriptor) -> CapabilityResult:
                return self.bus.invoke(
                    desc.capability_id,
                    objective=call.objective,
                    payload={
                        "messages": [
                            {"role": "user", "content": call.objective},
                        ],
                        "context": {
                            "market_mode": "blind_independent",
                            "goal": copy.deepcopy(call.payload.get("goal", {})),
                        },
                        "response_contract": {"kind": "candidate_with_optional_score"},
                    },
                    context={"run_id": call.context.get("run_id"), "topology": self.capability_id},
                )

            results: list[CapabilityResult] = []
            worker_count = len(models) if self.max_workers is None else min(self.max_workers, len(models))
            with ThreadPoolExecutor(max_workers=max(1, worker_count)) as pool:
                futures = {pool.submit(invoke_model, desc): desc for desc in models}
                for future in as_completed(futures):
                    results.append(future.result())

            successful = [x for x in results if x.success]
            if not successful:
                return ControlTopologyOutcome(False, None, self.capability_id, trace=tuple({"model": x.capability_id, "success": False} for x in results))

            winner = max(successful, key=lambda x: (self._score(x.output), x.capability_id))
            return ControlTopologyOutcome(
                completed=False,
                output=copy.deepcopy(winner.output),
                topology_id=self.capability_id,
                trace=tuple(
                    {
                        "phase": "market_candidate",
                        "capability_id": x.capability_id,
                        "success": x.success,
                        "score": self._score(x.output) if x.success else None,
                    }
                    for x in sorted(results, key=lambda x: x.capability_id)
                ),
                observations=tuple(
                    {
                        "capability_id": x.capability_id,
                        "success": x.success,
                        "output": copy.deepcopy(x.output),
                    }
                    for x in results
                ),
                metadata={"winner": winner.capability_id, "population": len(models)},
            )

        return CapabilityComponent(descriptor, handler)


class SimulationTopology:
    """Control by simulation component rather than a language-model planner."""

    def __init__(
        self,
        *,
        capability_id: str,
        bus: UniversalCapabilityBus,
        simulation_requirement: CapabilityRequirement,
        priority: float = 0.0,
    ) -> None:
        self.capability_id = capability_id
        self.bus = bus
        self.simulation_requirement = simulation_requirement
        self.priority = priority

    def as_component(self) -> CapabilityComponent:
        descriptor = CapabilityDescriptor(
            self.capability_id,
            "control_topology",
            ("goal_pursuit", "simulation_control"),
            tags=("simulation", "brain_optional"),
            priority=self.priority,
            metadata={"topology": "simulation"},
        )

        def handler(call: CapabilityInvocation) -> ControlTopologyOutcome:
            goal = call.payload["goal"]
            sim_payload = copy.deepcopy(goal.get("inputs", {}).get("simulation_payload", {}))
            result = self.bus.invoke_requirement(
                self.simulation_requirement,
                objective=call.objective,
                payload=sim_payload,
                context={"run_id": call.context.get("run_id"), "topology": self.capability_id},
            )
            return ControlTopologyOutcome(
                completed=result.success,
                output=copy.deepcopy(result.output),
                topology_id=self.capability_id,
                trace=({"phase": "simulation", "capability_id": result.capability_id, "success": result.success},),
            )

        return CapabilityComponent(descriptor, handler)
