from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable


@dataclass(frozen=True)
class ExplorationStrategy:
    strategy_id: str
    instruction: str
    family: str


_seed_strategies: tuple[ExplorationStrategy, ...] = (
    ExplorationStrategy("first_principles", "Rebuild the problem from first principles and derive the smallest set of assumptions needed.", "decomposition"),
    ExplorationStrategy("inversion", "Assume the obvious framing is wrong. Invert the objective, causal direction, or representation and search from there.", "reframing"),
    ExplorationStrategy("cross_domain", "Import a mechanism from a distant field and map it structurally rather than metaphorically.", "analogy"),
    ExplorationStrategy("counterexample_hunt", "Search for the smallest concrete case that breaks the leading explanation, then redesign around that evidence.", "falsification"),
    ExplorationStrategy("constraint_release", "List inherited assumptions beyond the user request, release them one by one, and inspect the newly reachable solution space.", "reframing"),
    ExplorationStrategy("extreme_scale", "Push the problem to an absurdly small, large, fast, slow, cheap, or expensive scale and carry back any mechanism that survives.", "boundary"),
    ExplorationStrategy("tool_transposition", "Ask what becomes possible if the problem is expressed as code, search, simulation, optimization, theorem proving, browser action, or data transformation instead of prose.", "representation"),
    ExplorationStrategy("parallel_worlds", "Produce mutually incompatible solution worlds and preserve them long enough to compare their downstream consequences.", "divergence"),
    ExplorationStrategy("failure_family_shift", "Move to an approach whose likely failure mode is materially different from the current approach.", "independence"),
    ExplorationStrategy("empirical_probe", "Replace an argument with the cheapest real execution, measurement, or artifact that can settle the disputed point.", "execution"),
    ExplorationStrategy("orthogonal_perturbation", "Generate a question or representation maximally unlike the current framing, then test whether it exposes a mechanism the main line cannot see.", "reframing"),
    ExplorationStrategy("architecture_erasure", "Delete the subsystem, assumption, or abstraction believed to be necessary and redesign the destination so the original problem no longer exists.", "architecture"),
    ExplorationStrategy("absurd_simplification", "Assume the answer is embarrassingly simple; search for one invariant, state transition, or interface mistake that would explain the whole failure.", "reframing"),
    ExplorationStrategy("recursive_tool_creation", "If the available tools force a bad representation, design or acquire a new tool/adapter/probe that changes the reachable solution space before solving the task.", "tool_creation"),
    ExplorationStrategy("contrasting_reframe", "Construct alternative formulation candidates and seek executable distinctions between them.", "divergence"),
)


@dataclass(frozen=True)
class StrategySelection:
    strategy_id: str
    family: str
    instruction: str
    score: float
    attempts: int
    mean_reward: float


StrategyGenerator = Callable[[str, tuple[ExplorationStrategy, ...]], Iterable[ExplorationStrategy]]


class AdaptiveReasoningPortfolio:
    """Open-ended strategy portfolio with dynamic expansion and persistent lineage."""

    def __init__(self, state_path: Path, strategies: tuple[ExplorationStrategy, ...] | None = None) -> None:
        self.state_path = state_path
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.state_path.exists():
            self.state_path.write_text(json.dumps({"stats": {}, "dynamic_strategies": {}, "lineage": {}}, indent=2), encoding="utf-8")
        data = self._read()
        data.setdefault("stats", {})
        data.setdefault("dynamic_strategies", {})
        data.setdefault("lineage", {})
        seed_rows = _seed_strategies if strategies is None else strategies
        self.strategies = {s.strategy_id: s for s in seed_rows}
        for sid, row in data["dynamic_strategies"].items():
            self.strategies[sid] = ExplorationStrategy(
                strategy_id=sid,
                instruction=str(row["instruction"]),
                family=str(row["family"]),
            )
        self._write(data)

    def _read(self) -> dict:
        return json.loads(self.state_path.read_text(encoding="utf-8"))

    def _write(self, data: dict) -> None:
        self.state_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def register(
        self,
        strategy: ExplorationStrategy,
        *,
        parents: Iterable[str] = (),
        note: str | None = None,
    ) -> ExplorationStrategy:
        if not strategy.strategy_id.strip():
            raise ValueError("strategy_id must be non-empty")
        self.strategies[strategy.strategy_id] = strategy
        data = self._read()
        data.setdefault("dynamic_strategies", {})[strategy.strategy_id] = {
            "instruction": strategy.instruction,
            "family": strategy.family,
        }
        data.setdefault("lineage", {})[strategy.strategy_id] = {
            "parents": sorted(set(str(x) for x in parents)),
            "note": note,
        }
        self._write(data)
        return strategy

    def expand(self, objective: str, generator: StrategyGenerator) -> tuple[ExplorationStrategy, ...]:
        generated = tuple(generator(objective, tuple(self.strategies.values())))
        for strategy in generated:
            self.register(strategy, note=f"generated for objective: {objective}")
        return generated

    def select(self, count: int | None = None) -> tuple[StrategySelection, ...]:
        data = self._read()
        stats = data.setdefault("stats", {})
        total = sum(int(v.get("attempts", 0)) for v in stats.values()) + 1
        scored: list[StrategySelection] = []
        for strategy in self.strategies.values():
            entry = stats.get(strategy.strategy_id, {})
            attempts = int(entry.get("attempts", 0))
            reward_sum = float(entry.get("reward_sum", 0.0))
            mean = reward_sum / attempts if attempts else 0.0
            score = 1_000_000.0 if attempts == 0 else mean + math.sqrt(2.0 * math.log(total) / attempts)
            scored.append(
                StrategySelection(
                    strategy_id=strategy.strategy_id,
                    family=strategy.family,
                    instruction=strategy.instruction,
                    score=score,
                    attempts=attempts,
                    mean_reward=mean,
                )
            )
        scored.sort(key=lambda x: (-x.score, x.strategy_id))
        limit = len(scored) if count is None else max(1, int(count))
        return tuple(scored[:limit])

    def record(self, strategy_id: str, reward: float, *, note: str | None = None) -> None:
        if strategy_id not in self.strategies:
            raise KeyError(strategy_id)
        data = self._read()
        entry = data.setdefault("stats", {}).setdefault(
            strategy_id, {"attempts": 0, "reward_sum": 0.0, "history": []}
        )
        entry["attempts"] += 1
        entry["reward_sum"] += float(reward)
        event = {"reward": float(reward)}
        if note is not None:
            event["note"] = note
        entry.setdefault("history", []).append(event)
        self._write(data)

    def prompt_bundle(self, objective: str, count: int | None = None) -> dict:
        selected = self.select(count=count)
        return {
            "objective": objective,
            "instruction": "Preserve the user's destination while expanding search breadth. Keep competing hypotheses distinct until evidence distinguishes them. If selected strategies converge, synthesize a novel reasoning operator rather than narrowing the inquiry.",
            "strategy_synthesis_allowed": True,
            "strategy_synthesis_trigger": "representation_convergence_or_repeated_failure_family",
            "fixed_strategy_catalog_is_not_a_ceiling": True,
            "strategies": [asdict(s) for s in selected],
        }
