from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable


@dataclass(frozen=True)
class ProbeCandidate:
    probe_id: str
    expected_information_gain: float
    incremental_cost: float = 0.0
    novelty: float = 0.0
    blocking_power: float = 0.0
    risk: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


class InformationGainScheduler:
    """Select the cheapest falsifier that can most reduce uncertainty.

    It deliberately rewards novelty and ability to resolve a blocker, while penalizing
    monetary/latency cost and risk. Discovery stays open; an explicit user cost cap
    filters proposals. Scheduling a probe does not authorize a charge.
    """

    def __init__(self, *, hard_spend_cap: float | None = None) -> None:
        import math
        self.hard_spend_cap = None if hard_spend_cap is None else float(hard_spend_cap)
        if self.hard_spend_cap is not None and (not math.isfinite(self.hard_spend_cap) or self.hard_spend_cap<0):
            raise ValueError('cost cap must be finite and nonnegative')

    def score(self, p: ProbeCandidate) -> float:
        return (
            2.5 * float(p.expected_information_gain)
            + 1.25 * float(p.blocking_power)
            + 0.75 * float(p.novelty)
            - 1.5 * float(p.incremental_cost)
            - 1.0 * float(p.risk)
        )

    def schedule(self, probes: Iterable[ProbeCandidate]) -> tuple[ProbeCandidate, ...]:
        import math
        allowed=[]
        for p in probes:
            values=[float(p.expected_information_gain),float(p.incremental_cost),float(p.novelty),float(p.blocking_power),float(p.risk)]
            if not all(math.isfinite(x) for x in values) or values[1]<0:raise ValueError('probe observations need finite metrics and a nonnegative cost')
            if self.hard_spend_cap is None or values[1]<=self.hard_spend_cap:allowed.append(p)
        allowed.sort(key=lambda p: (-self.score(p), p.incremental_cost, p.probe_id))
        return tuple(allowed)

    def next(self, probes: Iterable[ProbeCandidate]) -> ProbeCandidate | None:
        rows = self.schedule(probes)
        return rows[0] if rows else None
