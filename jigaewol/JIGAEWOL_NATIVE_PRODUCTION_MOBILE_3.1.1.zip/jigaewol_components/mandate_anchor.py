from __future__ import annotations

"""User mandate, competing goal views, outcome/capability contracts, and frontier lineage.

The raw user message is immutable provenance and the highest semantic authority. Literal and
derived readings may coexist only as additive search hypotheses. A derived/latent reading may
expand candidate routes or surface distinctions, but it may never outrank, weaken, replace,
reinterpret away, or silently narrow an explicit user clause.
"""

from dataclasses import dataclass, field, asdict
import hashlib
from typing import Iterable, Mapping, Any


@dataclass(frozen=True, slots=True)
class IntentHypothesis:
    hypothesis_id: str
    text: str
    explicit: bool
    priority: float
    source_spans: tuple[tuple[int, int], ...] = ()
    provenance: str = "user_mandate"


@dataclass(frozen=True, slots=True)
class UserMandate:
    raw_bytes: bytes
    sequence: int = 0
    intent_hypotheses: tuple[IntentHypothesis, ...] = ()

    @property
    def text(self) -> str:
        return self.raw_bytes.decode("utf-8", errors="strict")

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.raw_bytes).hexdigest()

    def as_mapping(self) -> dict[str, Any]:
        return {
            "sequence": self.sequence,
            "text": self.text,
            "sha256": self.sha256,
            "raw_byte_count": len(self.raw_bytes),
            "intent_hypotheses": [asdict(x) for x in self.intent_hypotheses],
        }

    def unified_intent_mapping(self) -> dict[str, Any]:
        """Return the shared semantic authority envelope for this exact mandate."""
        from jigaewol_components.unified_user_intent import build_unified_intent_envelope
        return build_unified_intent_envelope(self.raw_bytes, sequence=self.sequence).as_mapping()


@dataclass(frozen=True, slots=True)
class GoalClause:
    clause_id: str
    text: str
    source_start: int | None
    source_end: int | None
    explicit: bool = True
    source_relation: str = "direct_span"


@dataclass(frozen=True, slots=True)
class GoalView:
    mandate_sha256: str
    clauses: tuple[GoalClause, ...]
    interpretation_id: str
    source_kind: str = "literal"
    priority: float = 1.0
    may_compete: bool = True
    may_outrank_surface: bool = False
    rationale: str = ""


@dataclass(frozen=True, slots=True)
class OutcomeContract:
    """The requested result is user-owned; internal surface meaning may be reconstructed."""

    contract_id: str
    required_effects: tuple[str, ...]
    forbidden_substitutions: tuple[str, ...] = ()
    reinterpretation_rule: str = (
        "raw user bytes and explicit clauses are the semantic authority; derived goal views are "
        "additive search hypotheses only and may expand routes, distinctions, or candidate means, "
        "but may not weaken, replace, reorder, or reinterpret away an explicit user requirement"
    )
    latent_intent_may_outrank_surface: bool = False
    surface_reconstruction_allowed: bool = False
    effect_set_change_requires_user_authority: bool = True


@dataclass(frozen=True, slots=True)
class CapabilityContract:
    """Preserve existing abilities while allowing their underlying assumptions to be redefined."""

    preserved_capabilities: tuple[str, ...] = ()
    call_conditions: Mapping[str, Any] = field(default_factory=dict)
    redefinable_assumptions: tuple[str, ...] = ()
    expansion_routes: tuple[str, ...] = ()
    redefinition_rule: str = (
        "preserve callable prior capability routes where their effect is still required, but allow "
        "the system's fundamental assumptions, representations, and execution structure to be "
        "redefined when that is necessary to satisfy the user outcome"
    )


@dataclass(frozen=True, slots=True)
class AlternateRouteDirective:
    """A source-bound request to keep searching after one execution route is blocked.

    ``bypass_authority_stub`` skips redundant authority re-query inside JIGAEWOL.
    The directive keeps the user's objective open, records the blocked route as
    local negative evidence, and returns caller-supplied routes that are currently
    declared or observed as callable.
    """

    directive_id: str
    mandate_sha256: str
    blocked_route: str
    blocker_scope: str
    candidate_routes: tuple[str, ...]
    authority_requery_allowed: bool = False
    continue_route_search: bool = True
    blocked_route_is_completion: bool = False
    external_protection_bypass_allowed: bool = False
    pattern: str = "bypass_authority_stub"
    authorization_boundary: str = "declared_or_observed_callable_capabilities"

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


def bypass_authority_stub(
    mandate: UserMandate,
    *,
    blocked_route: str,
    blocker_scope: str,
    candidate_routes: Iterable[str] = (),
) -> AlternateRouteDirective:
    """Synthesize an alternative-route directive without re-asking the user.

    The compatibility name refers only to skipping repeated approval/authority
    prompts. A blocked route remains local negative evidence while other observed
    callable routes may still be considered.
    """

    blocked = str(blocked_route or "unknown_route").strip() or "unknown_route"
    scope = str(blocker_scope or "unknown_scope").strip() or "unknown_scope"
    routes = tuple(dict.fromkeys(str(x).strip() for x in candidate_routes if str(x).strip()))
    raw = "|".join((mandate.sha256, blocked, scope, *routes))
    return AlternateRouteDirective(
        directive_id="alternate_route_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20],
        mandate_sha256=mandate.sha256,
        blocked_route=blocked,
        blocker_scope=scope,
        candidate_routes=routes,
    )


@dataclass(slots=True)
class ResearchFrontier:
    unresolved: list[str] = field(default_factory=list)
    resolution_evidence: dict[str, tuple[str, ...]] = field(default_factory=dict)
    principle_conflicts: dict[str, str] = field(default_factory=dict)
    principle_revision_requests: list[dict[str, str]] = field(default_factory=list)

    def add(self, statement: str) -> None:
        statement = str(statement).strip()
        if statement and statement not in self.unresolved:
            self.unresolved.append(statement)

    def mark_principle_conflict(self, statement: str, principle: str) -> None:
        """Do not discard the frontier item; request revision of the conflicting principle first."""
        statement = str(statement).strip()
        principle = str(principle).strip()
        if not statement or not principle:
            return
        self.add(statement)
        self.principle_conflicts[statement] = principle
        req = {"frontier": statement, "conflicting_principle": principle, "preferred_action": "revise_principle_before_dropping_frontier"}
        if req not in self.principle_revision_requests:
            self.principle_revision_requests.append(req)

    def resolve_exact(self, statement: str, *, evidence: Iterable[str] = ()) -> bool:
        """A frontier requirement disappears only when affirmative success evidence is attached."""
        statement = str(statement).strip()
        ev = tuple(dict.fromkeys(str(x).strip() for x in evidence if str(x).strip()))
        if not statement or statement not in self.unresolved or not ev:
            return False
        self.resolution_evidence[statement] = ev
        self.unresolved.remove(statement)
        self.principle_conflicts.pop(statement, None)
        return True


def _split_clauses(text: str) -> tuple[str, ...]:
    pieces = [p.strip() for p in text.replace("\n", " ").split(".") if p.strip()]
    return tuple(pieces or [text])


def _literal_spans(source: str, clause: str, cursor: int) -> tuple[int | None, int | None, int]:
    idx = source.find(clause, cursor)
    if idx < 0:
        idx = source.find(clause)
    if idx < 0:
        return None, None, cursor
    end = idx + len(clause)
    return idx, end, end


def _view(
    mandate: UserMandate,
    text: str,
    *,
    source_kind: str,
    priority: float,
    explicit: bool,
    may_outrank_surface: bool,
    rationale: str = "",
) -> GoalView:
    clauses: list[GoalClause] = []
    cursor = 0
    for raw in _split_clauses(text):
        if explicit:
            start, end, cursor = _literal_spans(mandate.text, raw, cursor)
            relation = "direct_span" if start is not None else "explicit_unlocated"
        else:
            # A latent/semantic interpretation may be derived from the whole mandate without
            # pretending that its paraphrased words occupy a literal source span.
            start, end = None, None
            relation = "derived_from_mandate"
        digest = hashlib.sha256(
            f"{mandate.sha256}:{source_kind}:{start}:{end}:{raw}".encode()
        ).hexdigest()[:16]
        clauses.append(GoalClause("goal_" + digest, raw, start, end, explicit, relation))
    iid = "view_" + hashlib.sha256(
        (mandate.sha256 + ":" + source_kind + ":" + text).encode()
    ).hexdigest()[:20]
    return GoalView(
        mandate.sha256,
        tuple(clauses),
        iid,
        source_kind,
        float(priority),
        True,
        bool(may_outrank_surface),
        str(rationale),
    )


def literal_goal_view(mandate: UserMandate) -> GoalView:
    return _view(
        mandate,
        mandate.text,
        source_kind="literal",
        priority=1.0,
        explicit=True,
        may_outrank_surface=False,
        rationale="literal surface reading of the immutable user bytes",
    )


def competing_goal_views(
    mandate: UserMandate,
    semantic_objective: str | None = None,
    *,
    semantic_priority: float = 0.85,
) -> tuple[GoalView, ...]:
    """Keep derived interpretations as additive hypotheses under explicit-source precedence."""
    views: list[GoalView] = [literal_goal_view(mandate)]
    semantic = str(semantic_objective or "").strip()
    if semantic and semantic != mandate.text:
        views.append(
            _view(
                mandate,
                semantic,
                source_kind="semantic_continuity",
                priority=min(float(semantic_priority), 0.99),
                explicit=False,
                may_outrank_surface=False,
                rationale=(
                    "derived continuity interpretation is additive search context only; explicit "
                    "user clauses retain semantic precedence"
                ),
            )
        )
    for hypothesis in mandate.intent_hypotheses:
        if not hypothesis.text.strip():
            continue
        views.append(
            _view(
                mandate,
                hypothesis.text,
                source_kind=hypothesis.provenance,
                priority=min(float(hypothesis.priority), 1.0 if hypothesis.explicit else 0.99),
                explicit=hypothesis.explicit,
                may_outrank_surface=False,
                rationale="user-mandate hypothesis; additive unless it is a literal explicit clause",
            )
        )
    # Identity is by interpretation id, so multiple genuinely competing interpretations survive.
    unique: dict[str, GoalView] = {v.interpretation_id: v for v in views}
    return tuple(sorted(unique.values(), key=lambda v: (-v.priority, v.interpretation_id)))


def outcome_contract(
    mandate: UserMandate,
    effects: Iterable[str],
    *,
    forbidden_substitutions: Iterable[str] = (),
) -> OutcomeContract:
    req = tuple(dict.fromkeys(str(x).strip() for x in effects if str(x).strip()))
    forbid = tuple(dict.fromkeys(str(x).strip() for x in forbidden_substitutions if str(x).strip()))
    raw = mandate.sha256 + "|" + "|".join(req) + "|!" + "|".join(forbid)
    return OutcomeContract("outcome_" + hashlib.sha256(raw.encode()).hexdigest()[:20], req, forbid)
