from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable


def default_state_ranks() -> dict[str, int]:
    return {
        "discovered": 0,
        "installed_available": 1,
        "callable": 2,
        "attempted": 2,
        "execution_failed": 2,
        "executed_successfully": 3,
        "proven": 4,
        "installed_not_connected": 0,
        "enabled": 1,
    }


@dataclass(frozen=True)
class HostSurface:
    surface_id: str
    kind: str
    state: str
    capabilities: tuple[str, ...]
    connector_ref: str = ""
    evidence: dict[str, Any] = field(default_factory=dict)
    observed_at: float = 0.0
    evidence_strength: float = 0.0
    failure_family: str = ""
    last_error: str = ""

    @property
    def state_rank(self) -> int:
        return default_state_ranks().get(self.state, -1)


class HostSurfaceRegistry:
    """Dynamic inventory of host connectors, extensions, browsers, and execution surfaces.

    Maintains distinct lifecycle stages (discovery, availability, callability, execution verification)
    while preserving open-world horizons without arbitrary tool suppression.
    """

    def __init__(self, path: Path, *, state_ranks: dict[str, int] | None = None) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.state_ranks = dict(state_ranks or default_state_ranks())
        if not self.path.exists():
            self._write({"surfaces": {}})

    def register_state_rank(self, state: str, rank: int) -> None:
        self.state_ranks[str(state)] = int(rank)

    def state_rank(self, state: str) -> int:
        return int(self.state_ranks.get(str(state), -1))

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _coerce(raw: dict[str, Any]) -> HostSurface:
        return HostSurface(
            surface_id=str(raw.get("surface_id", "")),
            kind=str(raw.get("kind", "")),
            state=str(raw.get("state", "discovered")),
            capabilities=tuple(raw.get("capabilities", ())),
            connector_ref=str(raw.get("connector_ref", "")),
            evidence=dict(raw.get("evidence") or {}),
            observed_at=float(raw.get("observed_at", 0.0)),
            evidence_strength=float(raw.get("evidence_strength", 0.0)),
            failure_family=str(raw.get("failure_family", "")),
            last_error=str(raw.get("last_error", "")),
        )

    def upsert(
        self,
        surface_id: str,
        *,
        kind: str,
        state: str,
        capabilities: Iterable[str],
        connector_ref: str = "",
        evidence: dict[str, Any] | None = None,
        evidence_strength: float | None = None,
        failure_family: str = "",
        last_error: str = "",
    ) -> HostSurface:
        data = self._read()
        existing = (
            self._coerce(data.get("surfaces", {}).get(str(surface_id), {}))
            if str(surface_id) in data.get("surfaces", {})
            else None
        )
        if evidence_strength is None:
            evidence_strength = existing.evidence_strength if existing is not None else 0.0
        merged_caps = tuple(
            dict.fromkeys([*(existing.capabilities if existing else ()), *(str(x) for x in capabilities)])
        )
        merged_evidence = {**(existing.evidence if existing else {}), **dict(evidence or {})}
        row = HostSurface(
            str(surface_id),
            str(kind),
            str(state),
            merged_caps,
            str(connector_ref or (existing.connector_ref if existing else "")),
            merged_evidence,
            time.time(),
            float(evidence_strength),
            str(failure_family or (existing.failure_family if existing else "")),
            str(last_error),
        )
        data.setdefault("surfaces", {})[row.surface_id] = asdict(row)
        self._write(data)
        return row

    def record_probe(
        self,
        surface_id: str,
        *,
        success: bool,
        executor: str,
        evidence: dict[str, Any] | None = None,
        error: str = "",
    ) -> HostSurface:
        current = self.get(surface_id)
        if current is None:
            raise KeyError(surface_id)
        ev = {**current.evidence, **dict(evidence or {}), "probe_executor": str(executor)}
        return self.upsert(
            surface_id,
            kind=current.kind,
            state="executed_successfully" if success else "execution_failed",
            capabilities=current.capabilities,
            connector_ref=current.connector_ref,
            evidence=ev,
            evidence_strength=(1.0 if success else current.evidence_strength),
            failure_family=current.failure_family,
            last_error="" if success else str(error),
        )

    def get(self, surface_id: str) -> HostSurface | None:
        raw = self._read().get("surfaces", {}).get(str(surface_id))
        return self._coerce(raw) if raw else None

    def discover(
        self,
        *capabilities: str,
        state: str | None = None,
        minimum_evidence_strength: float | None = None,
        minimum_state_rank: int | None = None,
    ) -> tuple[HostSurface, ...]:
        need = set(map(str, capabilities))
        rows = []
        for raw in self._read().get("surfaces", {}).values():
            row = self._coerce(raw)
            if state is not None and row.state != state:
                continue
            if minimum_evidence_strength is not None and row.evidence_strength < float(minimum_evidence_strength):
                continue
            if minimum_state_rank is not None and self.state_rank(row.state) < int(minimum_state_rank):
                continue
            if need.issubset(set(row.capabilities)):
                rows.append(row)
        callable_states={"callable","executed_successfully","proven"}
        rows.sort(key=lambda x: (x.state in callable_states, bool(x.evidence), x.observed_at), reverse=True)
        return tuple(rows)

    def select(
        self,
        capability: str,
        *,
        minimum_evidence_strength: float | None = None,
        kinds: Iterable[str] = (),
    ) -> HostSurface | None:
        allowed = set(map(str, kinds))
        rows = self.discover(str(capability), minimum_evidence_strength=minimum_evidence_strength)
        rows = tuple(x for x in rows if not allowed or x.kind in allowed)
        return rows[0] if rows else None

    def all(self) -> tuple[HostSurface, ...]:
        return tuple(self._coerce(x) for x in self._read().get("surfaces", {}).values())
