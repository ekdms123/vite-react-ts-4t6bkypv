from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Generic, Hashable, Iterable, TypeVar

StateT = TypeVar("StateT", bound=Hashable)


@dataclass(frozen=True)
class ThoughtBranch(Generic[StateT]):
    state: StateT
    route_family: str
    local_score: float
    note: str = ""


@dataclass(frozen=True)
class ThoughtNode(Generic[StateT]):
    node_id: int
    parent_id: int | None
    depth: int
    state: StateT
    route_family: str
    local_score: float
    cumulative_score: float
    note: str = ""


@dataclass(frozen=True)
class ThoughtTreeResult(Generic[StateT]):
    best: ThoughtNode[StateT]
    explored: tuple[ThoughtNode[StateT], ...]
    final_frontier: tuple[ThoughtNode[StateT], ...]
    route_families: tuple[str, ...]


ExpandFn = Callable[[ThoughtNode[StateT]], Iterable[ThoughtBranch[StateT]]]
GoalFn = Callable[[ThoughtNode[StateT]], bool]


class DivergentThoughtTree(Generic[StateT]):
    """Model-neutral tree search that preserves distinct reasoning pathways.

    Implements multi-path reasoning without rigid computational ceilings.
    Selection rewards cumulative quality and route-family diversity, preventing
    premature convergence onto a single framing.
    """

    def __init__(
        self,
        *,
        beam_width: int | None = None,
        max_depth: int | None = None,
        diversity_bonus: float = 0.2,
    ) -> None:
        # None explores every novel path until the candidate frontier is exhausted.
        # Limits are supported only when the caller explicitly requests them.
        self.beam_width = None if beam_width is None else max(1, int(beam_width))
        self.max_depth = None if max_depth is None else max(1, int(max_depth))
        self.diversity_bonus = float(diversity_bonus)

    def search(
        self,
        initial_state: StateT,
        expand: ExpandFn[StateT],
        *,
        goal: GoalFn[StateT] | None = None,
        initial_family: str = "root",
    ) -> ThoughtTreeResult[StateT]:
        root = ThoughtNode(
            node_id=0,
            parent_id=None,
            depth=0,
            state=initial_state,
            route_family=initial_family,
            local_score=0.0,
            cumulative_score=0.0,
            note="",
        )
        frontier = [root]
        explored = [root]
        nodes_by_id = {0: root}
        # A state reached earlier is not necessarily the best route to that state.
        # Reopen it when cumulative quality improves; callers can include route
        # context in StateT when the same apparent state has different futures.
        best_state_score: dict[StateT, float] = {initial_state: 0.0}
        next_id = 1
        best = root

        depth = 0
        while frontier and (self.max_depth is None or depth < self.max_depth):
            depth += 1
            candidates: list[ThoughtNode[StateT]] = []
            for parent in frontier:
                for branch in expand(parent):
                    ancestor=parent
                    cyclic=False
                    while ancestor is not None:
                        if ancestor.state==branch.state:
                            cyclic=True;break
                        ancestor=nodes_by_id.get(ancestor.parent_id)
                    if cyclic:continue
                    cumulative = parent.cumulative_score + float(branch.local_score)
                    if cumulative <= best_state_score.get(branch.state, float('-inf')):
                        continue
                    best_state_score[branch.state] = cumulative
                    node = ThoughtNode(
                        node_id=next_id,
                        parent_id=parent.node_id,
                        depth=depth,
                        state=branch.state,
                        route_family=branch.route_family,
                        local_score=float(branch.local_score),
                        cumulative_score=cumulative,
                        note=branch.note,
                    )
                    next_id += 1
                    nodes_by_id[node.node_id]=node
                    candidates.append(node)
                    explored.append(node)
                    if (node.cumulative_score, -node.depth, -node.node_id) > (
                        best.cumulative_score,
                        -best.depth,
                        -best.node_id,
                    ):
                        best = node
                    if goal is not None and goal(node):
                        return ThoughtTreeResult(
                            best=node,
                            explored=tuple(explored),
                            final_frontier=(node,),
                            route_families=tuple(sorted({n.route_family for n in explored})),
                        )

            if not candidates:
                break

            selected: list[ThoughtNode[StateT]] = []
            family_counts: dict[str, int] = {}
            remaining = list(candidates)
            while remaining and (self.beam_width is None or len(selected) < self.beam_width):
                def rank(node: ThoughtNode[StateT]) -> tuple[float, float, int]:
                    reuse = family_counts.get(node.route_family, 0)
                    diversity = self.diversity_bonus / (1.0 + reuse)
                    return node.cumulative_score + diversity, node.local_score, -node.node_id

                chosen = max(remaining, key=rank)
                remaining.remove(chosen)
                selected.append(chosen)
                family_counts[chosen.route_family] = family_counts.get(chosen.route_family, 0) + 1
            frontier = selected

        return ThoughtTreeResult(
            best=best,
            explored=tuple(explored),
            final_frontier=tuple(frontier),
            route_families=tuple(sorted({n.route_family for n in explored})),
        )
