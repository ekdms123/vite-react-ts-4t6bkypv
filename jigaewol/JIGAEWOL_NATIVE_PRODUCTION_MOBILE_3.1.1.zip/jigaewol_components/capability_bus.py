from __future__ import annotations

import copy
import json
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Protocol


@dataclass(frozen=True)
class CapabilityRequirement:
    """A semantic need expressed without naming a concrete provider."""

    provides: tuple[str, ...] = ()
    kinds: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    location: str | None = None
    facets: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CapabilityDescriptor:
    capability_id: str
    kind: str
    provides: tuple[str, ...]
    accepts: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    location: str = "local"
    priority: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)
    facets: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CapabilityInvocation:
    call_id: str
    capability_id: str
    objective: str
    payload: dict[str, Any]
    context: dict[str, Any]
    started_at: float


@dataclass(frozen=True)
class CapabilityResult:
    call_id: str
    capability_id: str
    success: bool
    output: Any
    observations: tuple[dict[str, Any], ...] = ()
    artifacts: tuple[str, ...] = ()
    error: str | None = None
    finished_at: float = 0.0


class CapabilityHandler(Protocol):
    def __call__(self, invocation: CapabilityInvocation) -> CapabilityResult | Any: ...


@dataclass(frozen=True)
class CapabilityComponent:
    descriptor: CapabilityDescriptor
    handler: CapabilityHandler


CapabilityAcquirer = Callable[
    [CapabilityRequirement, str, dict[str, Any]],
    Iterable[CapabilityComponent],
]


CapabilitySelectionPolicy = Callable[[CapabilityRequirement, tuple[CapabilityDescriptor, ...], str, dict[str, Any]], CapabilityDescriptor]


class UniversalCapabilityBus:
    """Runtime capability fabric addressed by semantic capability instead of hard-coded names.

    The bus intentionally knows nothing about GPT, browsers, solvers, local programs,
    clouds, or models.  Each of those is merely a component advertising what it provides.
    Missing requirements can be handed to an acquisition hook which may attach a new
    component while the event loop is live.
    """

    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.events_path = self.root / "capability_bus_events.jsonl"
        self._components: dict[str, CapabilityComponent] = {}
        self._selection_counts: dict[str, int] = {}
        self._lock = threading.RLock()

    def register(self, component: CapabilityComponent) -> None:
        with self._lock:
            self._components[component.descriptor.capability_id] = component
            self._event(
                "register",
                {
                    "descriptor": asdict(component.descriptor),
                },
            )

    def unregister(self, capability_id: str) -> None:
        with self._lock:
            existed = self._components.pop(capability_id, None)
            if existed is not None:
                self._event("unregister", {"capability_id": capability_id})

    def descriptors(self) -> tuple[CapabilityDescriptor, ...]:
        with self._lock:
            return tuple(
                sorted(
                    (x.descriptor for x in self._components.values()),
                    key=lambda x: x.capability_id,
                )
            )

    @staticmethod
    def _matches(descriptor: CapabilityDescriptor, requirement: CapabilityRequirement) -> bool:
        if requirement.kinds and descriptor.kind not in set(requirement.kinds):
            return False
        if requirement.location is not None and descriptor.location != requirement.location:
            return False
        if not set(requirement.provides).issubset(set(descriptor.provides)):
            return False
        if not set(requirement.tags).issubset(set(descriptor.tags)):
            return False
        for key, expected in requirement.facets.items():
            if key not in descriptor.facets:
                return False
            actual = descriptor.facets[key]
            if isinstance(expected, (tuple, list, set)):
                actual_values = set(actual) if isinstance(actual, (tuple, list, set)) else {actual}
                if not set(expected).issubset(actual_values):
                    return False
            elif actual != expected:
                return False
        return True

    def discover(self, requirement: CapabilityRequirement) -> tuple[CapabilityDescriptor, ...]:
        with self._lock:
            matches = [
                component.descriptor
                for component in self._components.values()
                if self._matches(component.descriptor, requirement)
            ]
        matches.sort(key=lambda x: (-x.priority, x.capability_id))
        return tuple(matches)

    def _default_select(self, matches: tuple[CapabilityDescriptor, ...]) -> CapabilityDescriptor:
        if not matches:
            raise LookupError("no capability candidates available")
        best_priority = max(x.priority for x in matches)
        eligible = tuple(x for x in matches if x.priority == best_priority)
        chosen = min(eligible, key=lambda x: (self._selection_counts.get(x.capability_id, 0), x.capability_id))
        self._selection_counts[chosen.capability_id] = self._selection_counts.get(chosen.capability_id, 0) + 1
        return chosen

    def resolve(
        self,
        requirement: CapabilityRequirement,
        *,
        objective: str,
        context: dict[str, Any] | None = None,
        acquirer: CapabilityAcquirer | None = None,
        selector: CapabilitySelectionPolicy | None = None,
    ) -> CapabilityDescriptor:
        matches = self.discover(requirement)
        if matches:
            if selector is not None:
                chosen = selector(requirement, matches, objective, copy.deepcopy(context or {}))
                self._selection_counts[chosen.capability_id] = self._selection_counts.get(chosen.capability_id, 0) + 1
                return chosen
            return self._default_select(matches)

        if acquirer is not None:
            acquired = tuple(acquirer(requirement, objective, copy.deepcopy(context or {})))
            for component in acquired:
                self.register(component)
            matches = self.discover(requirement)
            if matches:
                self._event(
                    "acquire",
                    {
                        "objective": objective,
                        "requirement": asdict(requirement),
                        "acquired": [x.descriptor.capability_id for x in acquired],
                    },
                )
                if selector is not None:
                    chosen = selector(requirement, matches, objective, copy.deepcopy(context or {}))
                    self._selection_counts[chosen.capability_id] = self._selection_counts.get(chosen.capability_id, 0) + 1
                    return chosen
                return self._default_select(matches)

        raise LookupError(f"no capability component satisfies {requirement}")

    def invoke(
        self,
        capability_id: str,
        *,
        objective: str,
        payload: dict[str, Any] | None = None,
        context: dict[str, Any] | None = None,
    ) -> CapabilityResult:
        with self._lock:
            component = self._components[capability_id]

        invocation = CapabilityInvocation(
            call_id=f"call_{uuid.uuid4().hex[:16]}",
            capability_id=capability_id,
            objective=objective,
            payload=copy.deepcopy(payload or {}),
            context=copy.deepcopy(context or {}),
            started_at=time.time(),
        )
        self._event("invoke", asdict(invocation))
        try:
            value = component.handler(invocation)
            if isinstance(value, CapabilityResult):
                result = value
            else:
                result = CapabilityResult(
                    call_id=invocation.call_id,
                    capability_id=capability_id,
                    success=True,
                    output=copy.deepcopy(value),
                    finished_at=time.time(),
                )
        except Exception as exc:
            result = CapabilityResult(
                call_id=invocation.call_id,
                capability_id=capability_id,
                success=False,
                output=None,
                error=f"{type(exc).__name__}: {exc}",
                finished_at=time.time(),
            )
        self._event("result", asdict(result))
        return result

    def invoke_requirement(
        self,
        requirement: CapabilityRequirement,
        *,
        objective: str,
        payload: dict[str, Any] | None = None,
        context: dict[str, Any] | None = None,
        acquirer: CapabilityAcquirer | None = None,
        selector: CapabilitySelectionPolicy | None = None,
    ) -> CapabilityResult:
        descriptor = self.resolve(
            requirement,
            objective=objective,
            context=context,
            acquirer=acquirer,
            selector=selector,
        )
        return self.invoke(
            descriptor.capability_id,
            objective=objective,
            payload=payload,
            context=context,
        )

    def snapshot(self) -> dict[str, Any]:
        return {
            "components": [asdict(x) for x in self.descriptors()],
        }

    def _event(self, kind: str, payload: dict[str, Any]) -> None:
        row = {
            "kind": kind,
            "timestamp": time.time(),
            "payload": payload,
        }
        with self._lock:
            with self.events_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

