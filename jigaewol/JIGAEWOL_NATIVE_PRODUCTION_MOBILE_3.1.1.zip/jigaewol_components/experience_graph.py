from __future__ import annotations
import hashlib, json, time, uuid
from pathlib import Path
from typing import Any, Iterable


def _tokens(x: str):
    import re
    return set(re.findall(r"[A-Za-z0-9가-힣_+.-]{2,}", x.casefold()))

def _sha(x: Any):
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()

class ExperienceGraph:
    """Stores success, failure, surprise, analogy and composition as equally queryable experience."""
    def __init__(self, root: str|Path):
        self.root=Path(root); self.root.mkdir(parents=True, exist_ok=True); self.path=self.root/'experience_graph.json'
        if not self.path.exists(): self.path.write_text(json.dumps({"version":1,"nodes":[]}, indent=2)+"\n")
    def _read(self): return json.loads(self.path.read_text())
    def _write(self,d):
        p=self.path.with_suffix('.tmp'); p.write_text(json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2,default=str)+"\n"); p.replace(self.path)
    def add(self, *, objective:str, mechanism:str, outcome:str, bindings:Iterable[str]=(), evidence_refs:Iterable[str]=(), surprise:str="", analogy_tags:Iterable[str]=()):
        row={"node_id":"exp_"+uuid.uuid4().hex[:18],"objective":objective,"mechanism":mechanism,"outcome":outcome,
             "bindings":tuple(bindings),"evidence_refs":tuple(evidence_refs),"surprise":surprise,"analogy_tags":tuple(analogy_tags),"at":time.time()}
        row['sha256']=_sha(row); d=self._read(); d['nodes'].append(row); self._write(d); return row
    def recall(self, objective:str, *, limit:int | None=None):
        q=_tokens(objective); rows=[]
        for r in self._read().get('nodes',[]):
            lex=len(q & _tokens(r.get('objective','')+' '+r.get('mechanism','')))
            # Cross-domain bridges are deliberately first-class, even with zero lexical overlap.
            bridge=1 if r.get('analogy_tags') else 0
            surprise=1 if r.get('surprise') else 0
            rows.append((lex,bridge,surprise,r))
        rows.sort(key=lambda x:(-x[0],-x[1],-x[2],-float(x[3].get('at',0))))
        return tuple(dict(x[3]) for x in rows[:limit] if x[0] or x[1] or x[2])
