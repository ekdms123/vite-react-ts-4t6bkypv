from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

from .host_syscall import HostSyscallIntent, HostSyscallQueue


@dataclass(frozen=True)
class AcquisitionCandidate:
    candidate_id: str
    source_kind: str
    source_ref: str
    capability_claims: tuple[str, ...]
    inspection: dict[str, Any]
    discovered_at: float
    execution_state: str = "not_attempted"
    risk_state: str = "unassessed"
    execution_isolation: str = "unassigned"
    evidence: dict[str, Any] = field(default_factory=dict)


class CapabilityAcquisitionBroker:
    """Open-world host-facing capability acquisition protocol.

    Source kinds are free-form and never constitute a whitelist. Empty source_kinds means
    unrestricted discovery across known, newly discovered, generated, remote, local, model,
    agent, software, hardware, data, or future substrate families. Host actions that actually
    report external connection requirements as observations when they occur. Discovery
    stays open and execution state is established separately from discovery.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
        self.queue = HostSyscallQueue(self.root / "syscalls")
        self.path = self.root / "candidates.json"
        if not self.path.exists(): self.path.write_text(json.dumps({"candidates": {}}, indent=2), encoding="utf-8")

    def _read(self) -> dict[str, Any]: return json.loads(self.path.read_text(encoding="utf-8"))
    def _write(self, data: dict[str, Any]) -> None:
        tmp=self.path.with_suffix(".tmp"); tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8"); tmp.replace(self.path)

    def discover(self, *, objective: str, capabilities: Iterable[str], source_kinds: Iterable[str] = ()) -> HostSyscallIntent:
        resolved_capabilities = tuple(map(str, capabilities))
        resolved_source_kinds = tuple(map(str, source_kinds))
        return self.queue.request(
            "capability.discover",
            capability_need="external_capability_discovery",
            arguments={
                "objective": str(objective),
                "capabilities": list(resolved_capabilities),
                "source_kinds": list(resolved_source_kinds),
                "source_kinds_semantics": "non_exhaustive_hints" if resolved_source_kinds else "unrestricted",
                "allow_unknown_source_kinds": True,
                "allow_generated_tools": True,
                "allow_new_executors": True,
                "allow_new_model_or_agent_backends": True,
            },
            failure_family="external_discovery",
        )

    def register_candidate(self, *, source_kind: str, source_ref: str, capability_claims: Iterable[str],
                           inspection: dict[str, Any] | None = None, evidence: dict[str, Any] | None = None) -> AcquisitionCandidate:
        row=AcquisitionCandidate(
            candidate_id=f"candidate_{uuid.uuid4().hex[:16]}", source_kind=str(source_kind), source_ref=str(source_ref),
            capability_claims=tuple(map(str,capability_claims)), inspection=dict(inspection or {}), discovered_at=time.time(),
            evidence=dict(evidence or {}),
        )
        data=self._read(); data["candidates"][row.candidate_id]=asdict(row); self._write(data); return row

    def get(self, candidate_id: str) -> AcquisitionCandidate:
        raw=self._read()["candidates"][str(candidate_id)];
        raw["capability_claims"]=tuple(raw.get("capability_claims",()))
        return AcquisitionCandidate(**raw)

    def execution_route(self, candidate_id: str) -> dict[str, Any]:
        """Choose isolation without deleting an uncertain candidate from the ontology."""
        row = self.get(candidate_id)
        inspection = dict(row.inspection or {})
        trusted = bool(inspection.get("trusted_distribution") or inspection.get("signed_release_verified"))
        network = str(inspection.get("network_effect") or "unknown")
        credentials = bool(inspection.get("credential_access_required"))
        destructive = bool(inspection.get("destructive_effect_possible"))
        if trusted and not credentials and not destructive and network in {"none", "read_only", "unknown"}:
            isolation = "disposable_vm_no_secrets"
        else:
            isolation = "strong_isolated_cell_no_secrets_no_personal_mounts"
        return {
            "candidate_id": row.candidate_id,
            "risk_state": "route_assessed",
            "execution_isolation": isolation,
            "candidate_remains_discoverable": True,
            "unknown_risk_keeps_candidate_open": True,
            "first_execution_has_no_user_credentials": True,
            "first_execution_has_no_personal_filesystem_mount": True,
            "network_observation_required": True,
            "filesystem_diff_required": True,
            "process_exit_receipt_required": True,
            "promotion_requires_observed_success": True,
        }

    def materialization_plan(self, candidate_id: str, capabilities, *, execution_handles=()) -> dict[str, Any]:
        from jigaewol_runtime.capabilities.materializer import plan_open_source_materialization
        row=self.get(candidate_id)
        plan = plan_open_source_materialization(row, capabilities, execution_handles=execution_handles)
        return {**dict(plan), "execution_route": self.execution_route(candidate_id),
                "discovery_policy": "allow_by_default_then_isolate_execution",
                "documentation_is_not_execution": True}

    def request_materialization(self, candidate_id: str, *, capabilities=(), execution_handles=()) -> HostSyscallIntent:
        row=self.get(candidate_id)
        arguments={"candidate_id":row.candidate_id,"source_kind":row.source_kind,"source_ref":row.source_ref,"inspection":row.inspection,
                   "execution_route": self.execution_route(candidate_id),
                   "discovery_policy": "allow_by_default_then_isolate_execution"}
        if capabilities:
            arguments["materialization_plan"]=self.materialization_plan(candidate_id, capabilities, execution_handles=execution_handles)
        arguments["host_must_execute_explicit_plan_steps_when_available"]=True
        return self.queue.request(
            "capability.materialize_and_execute", capability_need="external_materialization",
            arguments=arguments,
            failure_family="external_materialization",
        )

    def record_execution(self, candidate_id: str, *, success: bool, evidence: dict[str, Any]) -> AcquisitionCandidate:
        data=self._read(); raw=data["candidates"][str(candidate_id)]
        raw["execution_state"]="executed_successfully" if success else "execution_failed"
        raw["evidence"]={**raw.get("evidence",{}),**dict(evidence)}
        data["candidates"][str(candidate_id)]=raw; self._write(data); return self.get(candidate_id)
