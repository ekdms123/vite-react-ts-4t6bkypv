"""Durable execution cells with exclusive profiles, checkpoints and real effects."""
from __future__ import annotations
import hashlib
import json
import os
import sqlite3
import time
from pathlib import Path
from .state_transaction import state_transaction
from .snapshot_store import _atomic

class DurableCells:
    def __init__(self,root):
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'cells.sqlite3'
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS cells(id TEXT PRIMARY KEY, body TEXT)')

    def db(self):
        db=sqlite3.connect(self.path,timeout=30);db.execute('PRAGMA journal_mode=WAL');return db

    def checkpoint(self,task_id,*,kind,workspace,capability_digest,state,artifacts=(),lease=0):
        cid=hashlib.sha256((str(task_id)+'\0'+kind).encode()).hexdigest()
        files=[]
        workspace=Path(workspace).resolve()
        for path in artifacts:
            path=Path(path).resolve()
            if not path.is_relative_to(workspace):raise ValueError('cell artifact escaped task workspace')
            if path.is_file():files.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':path.stat().st_size})
        row=dict(cell_id=cid,task_id=str(task_id),kind=kind,workspace_ref=str(workspace),capability_digest=capability_digest,
                 lease=lease,state=state,artifacts=files,updated_at=time.time(),process_liveness_claim=False)
        encoded=json.dumps(row,ensure_ascii=False,sort_keys=True).encode();digest=hashlib.sha256(encoded).hexdigest()
        _atomic(self.root/'checkpoints'/(digest+'.json'),encoded)
        row['checkpoint']=digest
        with self.db() as db:db.execute('INSERT OR REPLACE INTO cells VALUES (?,?)',(cid,json.dumps(row,ensure_ascii=False)))
        return row

    def restore(self,task_id,kind):
        cid=hashlib.sha256((str(task_id)+'\0'+kind).encode()).hexdigest()
        with self.db() as db:row=db.execute('SELECT body FROM cells WHERE id=?',(cid,)).fetchone()
        if not row:return None
        row=json.loads(row[0]);path=self.root/'checkpoints'/(row['checkpoint']+'.json')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=row['checkpoint']:raise ValueError('cell checkpoint changed')
        for artifact in row['artifacts']:
            if hashlib.sha256(Path(artifact['path']).read_bytes()).hexdigest()!=artifact['sha256']:raise ValueError('cell artifact changed')
        return row

class PersistentBrowser:
    def __init__(self,root):
        self.root=Path(root).resolve();self.cells=DurableCells(self.root/'cells')

    def __call__(self,request,workspace):
        from jigaewol_runtime.mobile_adapters import parameters
        from playwright.sync_api import sync_playwright
        from urllib.parse import urlsplit
        args=parameters(request);workspace=Path(workspace).resolve();workspace.mkdir(parents=True,exist_ok=True)
        profile=str(args.get('profile','owner'))
        profile_id=hashlib.sha256((str(workspace)+'\0'+profile).encode()).hexdigest()
        task_id=str(request.get('action_id') or args.get('task_id') or profile_id)
        profile_path=self.root/'profiles'/profile_id;profile_path.mkdir(parents=True,exist_ok=True);profile_path.chmod(0o700)
        steps=list(args.get('steps') or ([{'op':'navigate','url':args['url']},{'op':'extract'}] if args.get('url') else []))
        if not steps:raise ValueError('browser needs actual navigation or interaction steps')
        outputs=[];artifacts=[]
        with state_transaction(self.root/'profile_locks'/profile_id),sync_playwright() as engine:
            context=engine.chromium.launch_persistent_context(str(profile_path),headless=True,accept_downloads=False)
            try:
                page=context.pages[0] if context.pages else context.new_page()
                for i,step in enumerate(steps):
                    operation=step['op']
                    if operation=='navigate':
                        if urlsplit(step['url']).scheme not in {'https','http'}:raise ValueError('browser navigation requires a web URL')
                        response=page.goto(step['url'],wait_until='domcontentloaded',timeout=60000)
                        outputs.append({'op':operation,'url':page.url,'status':response.status if response else None})
                    elif operation=='extract':
                        outputs.append({'op':operation,'url':page.url,'title':page.title(),'text':page.locator('body').inner_text(),
                                        'links':page.locator('a[href]').evaluate_all('(rows)=>rows.map(a=>({title:a.textContent,url:a.href}))')})
                    elif operation=='screenshot':
                        path=workspace/('browser_'+str(i)+'.png');page.screenshot(path=str(path),full_page=True);artifacts.append(path)
                        outputs.append({'op':operation,'artifact':str(path)})
                    elif operation=='click':page.locator(step['selector']).click(timeout=30000);outputs.append({'op':operation,'url':page.url})
                    elif operation=='fill':page.locator(step['selector']).fill(str(step['value']));outputs.append({'op':operation,'field':step['selector']})
                    else:raise ValueError('unknown browser step: '+operation)
                    self.cells.checkpoint(task_id,kind='browser',workspace=workspace,capability_digest='playwright-chromium-persistent',
                        state={'profile_ref':str(profile_path),'last_completed_step':i,'url':page.url,'observed_results':outputs},artifacts=artifacts)
                state_path=profile_path/'storage_state.json';context.storage_state(path=str(state_path));state_path.chmod(0o600)
                return {'success':True,'items':outputs,'profile_ref':str(profile_path),'checkpoint':self.cells.restore(task_id,'browser'),
                        'observed_browser_session':True,'authenticated_identity_claim':False}
            finally:context.close()

def browser_readiness():
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as engine:
            path=Path(engine.chromium.executable_path)
            return {'installed':path.is_file(),'executable_ref':str(path),'execution_observed':False}
    except ImportError:return {'installed':False,'execution_observed':False,'next_route':'install_browser_extra_and_chromium'}
