from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .capability_bus import CapabilityRequirement, UniversalCapabilityBus
from .delegate_mesh import Delegate, DelegateTask
from .runtime_foundation import RuntimeFoundation


class CapabilityDelegateResolver:
    """Resolve a delegate into real capability-bus execution without a fixed message grammar.

    A task may carry a CapabilityRequirement object and any mapping payload inside its
    extensible context. If no explicit requirement object is supplied, the free-form
    delegate role is treated as the desired provided capability.
    """

    def __init__(self, bus: UniversalCapabilityBus, *, foundation: RuntimeFoundation | None = None) -> None:
        self.bus = bus
        self.foundation = foundation

    @staticmethod
    def _decode_context(task: DelegateTask, role: str) -> tuple[CapabilityRequirement, dict[str, Any]]:
        requirement = next((value for value in task.context.values() if isinstance(value, CapabilityRequirement)), None)
        if requirement is None:
            requirement = CapabilityRequirement(provides=(str(role),))
        payload = next((dict(value) for value in task.context.values() if isinstance(value, dict)), {})
        return requirement, payload

    def __call__(self, role: str, tasks: tuple[DelegateTask, ...]) -> Delegate | None:
        def delegate(task: DelegateTask) -> Any:
            requirement, payload = self._decode_context(task, role)
            try:
                result = self.bus.invoke_requirement(
                    requirement,
                    objective=task.objective,
                    payload=payload,
                    context={"delegate_role": role, "delegate_task_id": task.task_id},
                )
                return asdict(result)
            except LookupError as exc:
                if self.foundation is not None:
                    need = self.foundation.open_world.declare_need(
                        objective=task.objective,
                        desired_outcomes=requirement.provides,
                        context={"delegate_role": role, "capability_descriptor": asdict(requirement)},
                    )
                    syscall = self.foundation.open_world.request_discovery(need)
                    return {"success": False, "pending_open_world_discovery": syscall.syscall_id, "error": str(exc)}
                raise
        return delegate
