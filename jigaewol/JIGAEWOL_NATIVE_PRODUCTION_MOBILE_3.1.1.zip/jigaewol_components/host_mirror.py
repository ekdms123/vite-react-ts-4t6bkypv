from __future__ import annotations

"""Host-native tool definition mirror.

This module does not pretend Python can discover ChatGPT host tools by itself.  The
outer host captures its own live tool definitions and writes a compact, fingerprinted
manifest here.  Canonical ingress then consumes that manifest before historical cache,
preventing the split-brain state where the host exposes tools while JIGAEWOL sees zero.
"""

import hashlib
import json
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Iterable, Mapping


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    tmp_path = Path(tmp)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(dict(payload), fh, ensure_ascii=False, sort_keys=True, indent=2, default=str)
            fh.write("\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, path)
    finally:
        tmp_path.unlink(missing_ok=True)


def _namespace(name: str) -> str:
    value = str(name)
    if value.startswith("mcp__") and "__" in value[5:]:
        return value[5:].split("__", 1)[0]
    if "__" in value:
        return value.split("__", 1)[0]
    return value.split(".", 1)[0]


class HostMirror:
    SCHEMA = "jigaewol_host_tool_mirror_v1"

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.path = self.root / "host_surface" / "host_tool_mirror.json"

    def exists(self) -> bool:
        return self.path.is_file()

    def read(self) -> dict[str, Any]:
        if not self.path.is_file():
            return {}
        return json.loads(self.path.read_text(encoding="utf-8"))

    def capture(self, definitions: Iterable[Mapping[str, Any]], *, source: str = "outer_host") -> dict[str, Any]:
        rows: list[dict[str, Any]] = []
        for raw in definitions:
            name = str(raw.get("name") or raw.get("id") or "").strip()
            if not name:
                continue
            description = str(raw.get("description") or "")
            description_hash = str(raw.get("description_hash") or hashlib.sha256(description.encode("utf-8")).hexdigest())
            rows.append({
                "name": name,
                "namespace": str(raw.get("namespace") or _namespace(name)),
                "description_hash": description_hash,
                "definition_hash": str(raw.get("definition_hash") or hashlib.sha256(
                    json.dumps(dict(raw), ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
                ).hexdigest()),
            })
        rows.sort(key=lambda row: row["name"])
        canonical = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        namespace_counts: dict[str, int] = {}
        for row in rows:
            ns = row["namespace"]
            namespace_counts[ns] = namespace_counts.get(ns, 0) + 1
        payload = {
            "schema": self.SCHEMA,
            "source": str(source),
            "observed_at": time.time(),
            "definition_count": len(rows),
            "catalog_fingerprint": hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
            "namespace_counts": namespace_counts,
            "tools": rows,
        }
        _atomic_json(self.path, payload)
        return payload

    def capture_summary(
        self,
        *,
        definition_count: int,
        catalog_fingerprint: str,
        namespace_counts: Mapping[str, int],
        source: str = "outer_host",
        fingerprint_algorithm: str = "host_supplied",
    ) -> dict[str, Any]:
        """Persist an authoritative host-side catalog summary.

        Some hosts expose the live tool catalog to the orchestrator but do not make
        the raw schemas directly readable from the Python runtime.  In that case we
        preserve the host-observed count/fingerprint plus namespace cardinalities
        rather than pretending Python rediscovered those tools.  The resulting
        namespace capabilities are sufficient to prevent the historical-cache
        split-brain while retaining truthful provenance about where the observation
        was made.
        """

        count = int(definition_count)
        if count < 0:
            raise ValueError("definition_count must be non-negative")
        fingerprint = str(catalog_fingerprint).strip()
        if count and not fingerprint:
            raise ValueError("catalog_fingerprint is required for a non-empty host catalog")

        normalized_counts: dict[str, int] = {}
        for namespace, raw_count in namespace_counts.items():
            ns = str(namespace).strip()
            if not ns:
                continue
            value = int(raw_count)
            if value < 0:
                raise ValueError(f"namespace count must be non-negative: {ns}")
            normalized_counts[ns] = value

        observed_namespace_total = sum(normalized_counts.values())
        if observed_namespace_total > count:
            raise ValueError(
                "namespace_counts cannot exceed definition_count "
                f"({observed_namespace_total} > {count})"
            )

        payload = {
            "schema": self.SCHEMA,
            "source": str(source),
            "observed_at": time.time(),
            "definition_count": count,
            "catalog_fingerprint": fingerprint,
            "fingerprint_algorithm": str(fingerprint_algorithm),
            "namespace_counts": dict(sorted(normalized_counts.items())),
            "unattributed_definition_count": count - observed_namespace_total,
            "manifest_level": "definition_fingerprint_plus_namespace_counts",
            "raw_definitions_host_side": True,
            "tools": [],
        }
        _atomic_json(self.path, payload)
        return payload


    def register_native_actuators(
        self, definitions: Iterable[Mapping[str, Any]], *, source: str = "outer_host_native"
    ) -> dict[str, Any]:
        """Attach host-native actuators that are not present in the plugin catalog.

        Native tools (for example image generation) live in the outer harness rather
        than the Python/plugin catalog.  The outer host can truthfully register the
        currently exposed actuator here without changing or erasing the 1,500-tool
        plugin-catalog observation.
        """
        mirror = self.read()
        if not mirror:
            mirror = {
                "schema": self.SCHEMA, "source": str(source), "observed_at": time.time(),
                "definition_count": 0, "catalog_fingerprint": "", "namespace_counts": {}, "tools": [],
            }
        rows: list[dict[str, Any]] = []
        for raw in definitions:
            name = str(raw.get("name") or raw.get("id") or "").strip()
            if not name:
                continue
            description = str(raw.get("description") or "")
            material = dict(raw)
            rows.append({
                "name": name,
                "namespace": str(raw.get("namespace") or _namespace(name)),
                "description": description,
                "description_hash": str(raw.get("description_hash") or hashlib.sha256(description.encode("utf-8")).hexdigest()),
                "definition_hash": str(raw.get("definition_hash") or hashlib.sha256(
                    json.dumps(material, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
                ).hexdigest()),
                "actions": list(raw.get("actions") or (name,)),
                "semantic_capabilities": list(raw.get("semantic_capabilities") or ()),
                "executor": str(raw.get("executor") or raw.get("namespace") or _namespace(name)),
            })
        rows.sort(key=lambda row: row["name"])
        canonical = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        mirror["native_source"] = str(source)
        mirror["native_observed_at"] = time.time()
        mirror["native_definition_count"] = len(rows)
        mirror["native_catalog_fingerprint"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        mirror["native_tools"] = rows
        _atomic_json(self.path, mirror)
        return mirror

    @staticmethod
    def _namespace_semantics(namespace: str) -> list[str]:
        ns = str(namespace)
        mapping = {
            "GitHub": ["repository", "source_code", "ci"],
            "Firecrawl": ["web_search", "web_extract", "web_crawl"],
            "Tavily": ["web_search", "web_extract"],
            "Exa": ["web_search", "web_extract"],
            "Parallel_Search": ["web_search", "web_extract"],
            "TinyFish": ["browser", "web_search", "web_interaction"],
            "Opera_Browser_Connector": ["browser", "signed_in_browser"],
            "Remote_Desktop_Commander": ["compute", "filesystem", "terminal", "process"],
            "DigitalOcean": ["compute", "remote_workspace"],
            "Vercel": ["deploy", "compute", "source_code"],
            "Railway": ["deploy", "compute", "database"],
            "Render": ["deploy", "compute", "database"],
            "Replit": ["deploy", "compute", "source_code"],
            "Floot": ["deploy", "compute", "source_code", "database"],
            "Hatchable": ["deploy", "compute", "source_code", "database"],
            "Base44": ["deploy", "source_code", "database"],
            "Lovable": ["deploy", "source_code", "database"],
            "Notion": ["knowledge_base", "documents"],
            "Google_Drive": ["filesystem", "documents", "spreadsheets", "presentations"],
            "Dropbox": ["filesystem", "documents"],
            "Coda": ["knowledge_base", "structured_data"],
            "Gmail": ["email"],
            "Google_Calendar": ["calendar"],
            "Figma": ["design", "artifact_generation"],
            "Canva": ["design", "artifact_generation"],
            "Higgsfield": ["design", "image_generation", "video_generation", "audio_generation"],
            "Plugin_Management": ["capability_discovery", "plugin_management"],
            "Wolfram": ["exact_compute"],
            "Manus": ["agent_delegate", "research"],
            "Linear": ["project_management", "source_review"],
            "Supabase": ["database", "auth", "storage", "serverless"],
            "Neon": ["database", "auth", "storage", "serverless"],
            "Metricool": ["social_analytics", "social_publishing"],
            "vidIQ": ["social_research", "video_research", "instagram_research"],
            "Context7": ["developer_docs"],
            "Windsor_ai": ["analytics", "connectors"],
        }
        return [f"host_namespace:{ns}", *mapping.get(ns, ())]

    def as_capability_surface(self) -> dict[str, Any]:
        mirror = self.read()
        tools = list(mirror.get("tools", ()))
        native_tools = list(mirror.get("native_tools", ()))
        capabilities = []
        for tool in (*tools, *native_tools):
            name = str(tool.get("name") or "")
            namespace = str(tool.get("namespace") or _namespace(name))
            capabilities.append({
                "id": name,
                "provider": namespace,
                "executor": namespace,
                "state": "callable",
                "description": f"live host tool definition: {name}",
                "semantic_capabilities": list(dict.fromkeys((
                    f"host_tool:{name}", f"host_namespace:{namespace}",
                    *tuple(str(x) for x in tool.get("semantic_capabilities") or () if str(x)),
                ))),
                "actions": list(tool.get("actions") or (name,)),
                "currently_exposed": True,
                "currently_callable": True,
                "connection_state": "host_exposed",
                "auth_state": "unknown",
                "evidence": {
                    "origin_ref": f"host_mirror:{mirror.get('catalog_fingerprint', '')}",
                    "definition_hash": str(tool.get("definition_hash") or ""),
                    "description_hash": str(tool.get("description_hash") or ""),
                },
            })
        if not tools:
            for namespace, action_count in sorted(dict(mirror.get("namespace_counts") or {}).items()):
                capabilities.append({
                    "id": f"host_namespace::{namespace}",
                    "provider": namespace,
                    "executor": namespace,
                    "state": "callable",
                    "description": (
                        f"live host namespace mirror: {namespace} "
                        f"({int(action_count)} tool definitions observed host-side)"
                    ),
                    "semantic_capabilities": self._namespace_semantics(namespace),
                    "actions": [f"host_namespace:{namespace}"],
                    "action_count": int(action_count),
                    "currently_exposed": True,
                    "currently_callable": True,
                    "connection_state": "host_exposed",
                    "auth_state": "unknown",
                    "evidence": {
                        "origin_ref": f"host_mirror:{mirror.get('catalog_fingerprint', '')}",
                        "manifest_level": str(mirror.get("manifest_level") or ""),
                        "raw_definitions_host_side": bool(mirror.get("raw_definitions_host_side")),
                    },
                })
        return {
            "format": "structured_surface_v1",
            "surface_complete": True,
            "observation_state": "observed",
            "observed_at": float(mirror.get("observed_at") or time.time()),
            "host_snapshot_id": str(mirror.get("catalog_fingerprint") or ""),
            "capabilities": capabilities,
            "host_mirror": {
                "definition_count": int(mirror.get("definition_count") or 0),
                "catalog_fingerprint": str(mirror.get("catalog_fingerprint") or ""),
                "fingerprint_algorithm": str(mirror.get("fingerprint_algorithm") or "sha256_canonical_rows"),
                "manifest_level": str(mirror.get("manifest_level") or "full_compact_tool_manifest"),
                "raw_definitions_host_side": bool(mirror.get("raw_definitions_host_side")),
                "unattributed_definition_count": int(mirror.get("unattributed_definition_count") or 0),
                "namespace_counts": dict(mirror.get("namespace_counts") or {}),
                "native_definition_count": int(mirror.get("native_definition_count") or 0),
                "native_catalog_fingerprint": str(mirror.get("native_catalog_fingerprint") or ""),
            },
        }
