from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .acquisition_broker import CapabilityAcquisitionBroker
from .capability_acquisition_pipeline import CapabilityAcquisitionPipeline
from .autobiographical_self import AutobiographicalSelf
from .foundation_components import FoundationComponentBridge
from .host_resource_probe import HostResourceProbe
from .live_context import LiveContextTimeline
from .cumulative_intent import CumulativeIntentLedger
from .host_surface_registry import HostSurfaceRegistry
from .host_action_truth import HostActionTruthLedger
from .host_capability_matrix import HostCapabilityMatrix
from .open_world_fabric import OpenWorldFabric
from .open_world_resolver import LocalOpenWorldResolver
from .prebuilt_computer_fabric import PrebuiltComputerFabric
from .resource_telemetry import ResourceTelemetry
from .runtime_home import resolve_runtime_home
from .search_portfolio_engine import SearchPortfolioEngine
from .search_surface_bridge import sync_search_surfaces
from .search_run_bridge import SearchRunBridge
from .search_swarm_policy import SearchSwarmPolicy
from .body_federation import BodyFederationRegistry
from .turn_continuity import TurnContinuityController
from .capability_bus import UniversalCapabilityBus
from .anti_recurrence import AntiRecurrenceEngine
from .execution_plane import ExecutionPlane
from .capability_compiler import UniversalCapabilityCompiler
from .mutable_policy_evolution import MutablePolicyEvolution
from .trajectory_evaluator import TrajectoryEvaluator
from .mobile_cockpit import MobileCockpit
from .artifact_execution import ArtifactExecutionRegistry
from .automation_lifecycle import AutomationLifecycleRegistry
from .durable_run_protocol import DurableRunLedger
from .agent_cli_runtime import AgentCliCatalog
from .agent_event_normalizer import AgentEventJournal
from .agent_worktree import AgentWorktreeManager
from .cognitive_worker_federation import CognitiveWorkerFederation
from .jir import JIGAEWOLIR
from .unwritten_machine import UnwrittenMachine
from .self_heal import SelfHealSupervisor
from .hunt_graph import HuntGraph
from .live_discovery_bridge import LiveDiscoveryBridge
from .free_first_router import FreeFirstRouter
from .free_provider_catalog import FreeProviderCatalog
from .probe_scheduler import InformationGainScheduler
from .wild_cognitive_plane import WildCognitivePlane
from .image_quality_governor import ImageQualityGovernor


@dataclass(frozen=True)
class FoundationSnapshot:
    runtime_root: str
    cumulative_requirement_count: int
    current_delta_id: str
    continuity_task_id: str
    continuity_status: str
    continuity_phase: str
    computer_fabric: dict[str, Any]
    open_world_need_id: str
    open_world_discovery_syscall_id: str
    search_expansion_syscall_id: str
    local_open_world_candidates: tuple[dict[str, Any], ...]
    local_open_world_reservoir: dict[str, Any]
    live_context_observation_id: str
    resource_snapshot: dict[str, Any]
    wild_cognitive_plan: dict[str, Any]
    prepared_at: float


class RuntimeFoundation:
    """Persistent host substrate shared by fresh artifact extractions.

    This is deliberately outside the ZIP extraction tree: fresh code is disposable;
    user intent, continuity, host capability inventory, browser/session-adjacent state,
    acquisition requests, and performance evidence survive extraction boundaries.
    """

    def __init__(self, project_root: Path, *, runtime_identity: str = "JIGAEWOL", persistent_root: str | Path | None = None) -> None:
        self.project_root = Path(project_root).resolve()
        self.runtime_identity = str(runtime_identity)
        self.root = resolve_runtime_home(runtime_identity=self.runtime_identity, explicit_root=persistent_root)
        self.intent = CumulativeIntentLedger(self.root / "intent" / "cumulative_intent.json")
        self.continuity = TurnContinuityController(self.root / "continuity" / "turn_continuity.json")
        self.computer = PrebuiltComputerFabric(self.root / "computer_fabric")
        self.open_world = OpenWorldFabric(self.root / "open_world")
        self.acquisition = CapabilityAcquisitionBroker(self.root / "acquisition")
        self.acquisition_pipeline = CapabilityAcquisitionPipeline(self.root / "acquisition_pipeline")
        self.surfaces = HostSurfaceRegistry(self.root / "surfaces" / "host_surfaces.json")
        self.host_action_truth = HostActionTruthLedger(self.root, body_root=self.root)
        self.host_capability_matrix = HostCapabilityMatrix(self.root, action_state_root=self.root)
        body_path = self.root / "canonical_host_bridge" / "bodies.json"
        if body_path.exists():
            sync_search_surfaces(BodyFederationRegistry(body_path), self.surfaces)
        self.hunt_graph = HuntGraph(self.root / "search" / "hunt_graph")
        self.live_discovery = LiveDiscoveryBridge(self.root / "search" / "live_discovery", self.hunt_graph)
        self.search = SearchPortfolioEngine(self.root / "search", surfaces=self.surfaces, hunt_graph=self.hunt_graph)
        self.search.bootstrap_from_surfaces()
        self.resources = ResourceTelemetry(self.root / "telemetry" / "resources.json")
        self.local_resolver = LocalOpenWorldResolver(self.root / "computer_fabric")
        self.live_context = LiveContextTimeline(self.root / "context" / "timeline.json")
        self.resource_probe = HostResourceProbe()
        self.self_history = AutobiographicalSelf(self.root / "self" / "autobiographical.json", identity_id=self.runtime_identity)
        self.component_bridge = FoundationComponentBridge(self.root / "active_components")
        self.anti_recurrence = AntiRecurrenceEngine(self.root / "anti_recurrence" / "invariants.json")
        self.execution_plane = ExecutionPlane(self.root / "execution_plane")
        self.capability_compiler = UniversalCapabilityCompiler(self.root / "capability_compiler", self.execution_plane)
        self.trajectory_evaluator = TrajectoryEvaluator(self.root / "policy_evolution" / "trajectory")
        self.policy_evolution = MutablePolicyEvolution(self.root / "policy_evolution" / "candidates")
        self.mobile_cockpit = MobileCockpit(self.root / "mobile_cockpit")
        self.artifacts = ArtifactExecutionRegistry(self.root / "artifacts")
        self.automations = AutomationLifecycleRegistry(self.root / "automations")
        self.runs = DurableRunLedger(self.root / "durable_runs")
        self.search_runs = SearchRunBridge(self.runs)
        self.agent_clis = AgentCliCatalog(self.root / "agent_cli_registry")
        self.agent_events = AgentEventJournal(self.root / "agent_events")
        self.agent_worktrees = AgentWorktreeManager(self.root / "agent_worktrees")
        self.cognitive_workers = CognitiveWorkerFederation(self.root)
        self.jir = JIGAEWOLIR(self.root / "jir")
        self.unwritten_machine = UnwrittenMachine(self.root / "unwritten_machine")
        self.self_heal = SelfHealSupervisor(self.root / "self_heal")
        self.free_first_router = FreeFirstRouter()
        self.free_provider_catalog = FreeProviderCatalog(evidence_root=self.root / "free_provider_evidence")
        self.probe_scheduler = InformationGainScheduler()
        self.wild_cognition = WildCognitivePlane(self.root / "wild_cognition")
        self._seed_constitution()

    def execution_fabric_snapshot(self, *, prepare_computer: bool = False, session_id: str = '', objective: str = '') -> dict[str, Any]:
        """Return one evidence-oriented view of the bodies behind mobile chat.

        This does not rename registries into execution.  It exposes the actual durable
        components that may carry work and, when requested, runs the computer fabric's
        real preparation probes before reporting it.
        """
        computer = (
            self.computer.ensure_prepared()
            if prepare_computer
            else (self.computer.read_snapshot() or {
                "state": "not_prepared_this_snapshot",
                "baseline_components": list(self.computer.baseline_components()),
            })
        )
        cockpit_data = self.mobile_cockpit._read()
        routes = [asdict(x) for x in self.mobile_cockpit.routes()]
        sessions = [dict(x) for _, x in sorted((cockpit_data.get("sessions") or {}).items())]
        acquisition_state = self.acquisition._read()
        search_state = {"observations": []}
        if self.search.path.is_file():
            try:
                search_state = json.loads(self.search.path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                search_state = {"observations": []}
        workers = dict(self.cognitive_workers.as_mapping())
        workers["actual_worker_requires_observed_independent_execution"] = True
        workers["roleplay_or_same_context_branch_is_not_counted_as_worker"] = True
        wild_plan = self.wild_cognition.plan(str(objective)) if str(objective).strip() else self.wild_cognition.snapshot()
        orchestration_plan = self.mobile_cockpit.orchestration_plan(session_id) if str(session_id).strip() else None
        if orchestration_plan is not None:
            orchestration_plan = dict(orchestration_plan)
            orchestration_plan["worker_federation"] = workers
        runs = [asdict(x) for x in self.runs.list_runs(limit=100)]
        return {
            "schema": "jigaewol_execution_fabric_v1",
            "runtime_root": str(self.root),
            "computer": computer,
            "mobile_cockpit": {
                "mobile_chat_role": "control_cockpit",
                "routes": routes,
                "sessions": sessions,
                "durable_session_resume_supported": True,
                "route_plan": self.mobile_cockpit.route_plan(session_id) if str(session_id).strip() else None,
                "orchestration_plan": orchestration_plan,
            },
            "acquisition": {
                "candidate_count": len(acquisition_state.get("candidates") or {}),
                "candidate_ids": tuple(sorted((acquisition_state.get("candidates") or {}).keys())),
                "pipeline_candidate_count": len(self.acquisition_pipeline.ledger.snapshot()),
                "durable_pipeline": True,
                "lifecycle": ["discover", "authorize", "inspect", "materialize", "probe", "promote", "integrate"],
                "documentation_is_not_execution": True,
                "first_execution_isolated": True,
                "promotion_requires_observed_success": True,
            },
            "search": {
                "registered_scout_count": len(self.search._scouts),
                "observation_count": len(search_state.get("observations") or ()),
                "recursive_hunt_graph": True,
                "native_vernacular_query_compiler": True,
                "completion_requires_all_required_families": True,
                "sensor_program_compiler": True,
            },
            "workers": workers,
            "wild_cognition": wild_plan,
            "image_quality": ImageQualityGovernor.compile_contract(""),
            "durable_runs": {
                "run_count": len(runs),
                "runs": runs,
                "sequence_replay_supported": True,
                "mobile_resume_can_bind_run_cursor": True,
            },
            "snapshot_at": time.time(),
        }

    def _seed_constitution(self) -> None:
        paths = sorted(self.project_root.glob("PROJECT_CONSTITUTION*.json"))
        for path in paths:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            for text in data.get("requirements", []):
                self.intent.add(str(text), source="project_constitution", tags=("persistent", "constitution"), metadata={"source_file": path.name})

    def _bind_continuity_run(self, task, *, delta_id: str, user_command: str) -> tuple[str, int]:
        run_id = "run_cont_" + hashlib.sha256(str(task.task_id).encode("utf-8")).hexdigest()[:20]
        run = self.runs.create_run(
            run_id=run_id,
            objective=str(task.objective),
            worker_ref=f"continuity:{task.task_id}",
            metadata={"continuity_task_id": task.task_id, "workstream_key": str(task.state.get("workstream_key", ""))},
        )
        event = self.runs.append_event(
            run.run_id,
            kind="turn_bound",
            payload={
                "continuity_task_id": task.task_id,
                "attempt": int(task.attempts),
                "phase": str(task.phase),
                "user_command_sha256": hashlib.sha256(str(user_command).encode("utf-8")).hexdigest(),
            },
            evidence_refs=(f"intent_delta:{delta_id}",),
            idempotency_key=f"turn-bound:{task.task_id}:{task.attempts}:{delta_id}",
        )
        return run.run_id, event.sequence

    def bind_turn(
        self,
        user_command: str,
        *,
        artifact_sha256: str = "",
        workstream_key: str | None = None,
    ) -> FoundationSnapshot:
        """Bind every chat delta without repeated full host preparation.

        Cumulative intent is global, while execution continuity is workstream-scoped.
        An unrelated message therefore cannot silently hijack the most recent unfinished
        task; semantic follow-ups can resume by supplying a stable workstream_key.
        """
        command = str(user_command).strip()
        if not command:
            raise ValueError("user command must be non-empty")
        wild_plan = self.wild_cognition.plan(command)
        self.jir.compile(command, obligations=("preserve_current_user_directive", "no_silent_downgrade"), effects=("execute_or_keep_open_with_failure_truth",), continuation="unfinished_work_remains_live")
        deltas = self.intent.add_message(command, source="user_turn", tags=("persistent", "turn_delta"), metadata={"artifact_sha256": artifact_sha256})
        delta = deltas[0]
        context_obs = self.live_context.append(modality="text", source="user_command", payload_ref=command, summary=command, metadata={"artifact_sha256": artifact_sha256})
        task = self.continuity.start_or_resume(
            objective=command,
            prefer_unfinished=True,
            workstream_key=workstream_key,
            strict_workstream=True,
            state={"latest_delta_id": delta.requirement_id, "artifact_sha256": artifact_sha256},
        )
        durable_run_id, replay_cursor = self._bind_continuity_run(task, delta_id=delta.requirement_id, user_command=command)
        current = self.continuity.checkpoint(
            task.task_id,
            phase=task.phase if task.phase != "initialized" else "intent_bound",
            state={"latest_user_command": command, "durable_run_id": durable_run_id, "durable_run_cursor": replay_cursor},
        )
        return FoundationSnapshot(
            runtime_root=str(self.root),
            cumulative_requirement_count=len(self.intent.active()),
            current_delta_id=delta.requirement_id,
            continuity_task_id=current.task_id,
            continuity_status=current.status,
            continuity_phase=current.phase,
            computer_fabric={},
            open_world_need_id="",
            open_world_discovery_syscall_id="",
            search_expansion_syscall_id="",
            local_open_world_candidates=(),
            local_open_world_reservoir={},
            live_context_observation_id=context_obs.observation_id,
            resource_snapshot={},
            wild_cognitive_plan=dict(wild_plan),
            prepared_at=time.time(),
        )

    def ingest(
        self,
        user_command: str,
        *,
        artifact_sha256: str = "",
        prepare_computer: bool = True,
        workstream_key: str | None = None,
    ) -> FoundationSnapshot:
        command = str(user_command).strip()
        if not command:
            raise ValueError("user command must be non-empty")
        wild_plan = self.wild_cognition.plan(command)
        self.jir.compile(command, obligations=("preserve_current_user_directive", "no_silent_downgrade"), effects=("execute_or_keep_open_with_failure_truth",), continuation="unfinished_work_remains_live")
        deltas = self.intent.add_message(command, source="user_turn", tags=("persistent", "turn_delta"), metadata={"artifact_sha256": artifact_sha256})
        delta = deltas[0]
        context_obs = self.live_context.append(modality="text", source="user_command", payload_ref=command, summary=command, metadata={"artifact_sha256": artifact_sha256})
        resource_snapshot = asdict(self.resource_probe.snapshot())
        task = self.continuity.start_or_resume(
            objective=command,
            planned_steps=(
                {"kind": "foundation", "name": "intent_bound"},
                {"kind": "foundation", "name": "computer_ready"},
                {"kind": "foundation", "name": "open_world_ready"},
                {"kind": "foundation", "name": "response_release"},
            ),
            prefer_unfinished=True,
            workstream_key=workstream_key,
            strict_workstream=True,
            state={"latest_delta_id": delta.requirement_id, "artifact_sha256": artifact_sha256},
        )
        durable_run_id, replay_cursor = self._bind_continuity_run(task, delta_id=delta.requirement_id, user_command=command)
        self.continuity.checkpoint(
            task.task_id,
            phase="intent_bound",
            completed_step={"name": "intent_bound", "delta_id": delta.requirement_id},
            state={"durable_run_id": durable_run_id, "durable_run_cursor": replay_cursor},
        )
        computer = self.computer.ensure_prepared(max_age_s=6 * 60 * 60) if prepare_computer else self.computer.read_snapshot()
        self.continuity.checkpoint(task.task_id, phase="computer_ready", completed_step={"name": "computer_ready"}, state={"computer_snapshot_sha256": self._sha_json(computer)})
        need = self.open_world.declare_need(
            objective=command,
            desired_outcomes=("fulfill_cumulative_user_objective_without_silent_downgrade",),
            known_routes=(),
            explicit_exclusions=(),
            context={"cumulative_intent": self.intent.compose(command), "artifact_sha256": artifact_sha256},
        )
        syscall = self.open_world.request_discovery(need)
        search_syscall = self.search.request_open_world_expansion(command)
        local_page = self.local_resolver.discover_page(command, cursor=0, page_size=24, include_reserve=True)
        local_candidates = tuple(asdict(x) for x in local_page["candidates"])
        local_reservoir = {k: v for k, v in local_page.items() if k != "candidates"}
        self.continuity.checkpoint(
            task.task_id,
            phase="open_world_ready",
            completed_step={"name": "open_world_ready", "need_id": need.need_id, "syscall_id": syscall.syscall_id, "search_syscall_id": search_syscall.syscall_id},
            state={
                "local_open_world_candidates": list(local_candidates),
                "local_open_world_reservoir": local_reservoir,
            },
        )
        current = self.continuity.latest_unfinished() or task
        return FoundationSnapshot(
            runtime_root=str(self.root),
            cumulative_requirement_count=len(self.intent.active()),
            current_delta_id=delta.requirement_id,
            continuity_task_id=current.task_id,
            continuity_status=current.status,
            continuity_phase=current.phase,
            computer_fabric=dict(computer or {}),
            open_world_need_id=need.need_id,
            open_world_discovery_syscall_id=syscall.syscall_id,
            search_expansion_syscall_id=search_syscall.syscall_id,
            local_open_world_candidates=local_candidates,
            local_open_world_reservoir=local_reservoir,
            live_context_observation_id=context_obs.observation_id,
            resource_snapshot=resource_snapshot,
            wild_cognitive_plan=dict(wild_plan),
            prepared_at=time.time(),
        )


    def next_local_open_world_page(
        self, objective: str, *, cursor: int, page_size: int = 24
    ) -> dict[str, Any]:
        """Open the next execution slice without shrinking the capability universe.

        Exhaustion is true only after every observed reservoir entry has been exposed.
        """
        page = self.local_resolver.discover_page(
            str(objective), cursor=int(cursor), page_size=int(page_size), include_reserve=True
        )
        return {
            **{k: v for k, v in page.items() if k != "candidates"},
            "candidates": tuple(asdict(x) for x in page["candidates"]),
        }

    def register_prebuilt_components(self, bus: UniversalCapabilityBus) -> tuple[str, ...]:
        return self.component_bridge.register(bus)

    def mark_response_release(
        self,
        *,
        release_receipt: str,
        response_sha256: str,
        objective_completed: bool = False,
        task_id: str | None = None,
    ) -> None:
        task = None
        if task_id is not None:
            task = next((x for x in self.continuity.unfinished() if x.task_id == str(task_id)), None)
        if task is None:
            task = self.continuity.latest_unfinished()
        if task is None:
            return
        durable_run_id = str(task.state.get("durable_run_id") or ("run_cont_" + hashlib.sha256(str(task.task_id).encode("utf-8")).hexdigest()[:20]))
        try:
            release_event = self.runs.append_event(
                durable_run_id,
                kind="response_release",
                payload={"response_sha256": str(response_sha256), "objective_completed": bool(objective_completed)},
                evidence_refs=(str(release_receipt),),
                idempotency_key=f"response-release:{task.task_id}:{response_sha256}",
            )
            release_cursor = release_event.sequence
        except (KeyError, RuntimeError):
            release_cursor = int(task.state.get("durable_run_cursor") or 0)
        release_state = {"released_response_sha256": str(response_sha256), "last_response_released_at": time.time(), "durable_run_id": durable_run_id, "durable_run_cursor": release_cursor}
        # A caller-supplied ``objective_completed`` boolean is not completion evidence.
        # Response release is recorded, but the durable user objective stays open until
        # the canonical Work-level proof closes it.
        release_state["objective_completed_claim"] = bool(objective_completed)
        release_state["objective_completion_requires_work_evidence"] = True
        current = self.continuity.checkpoint(
            task.task_id,
            phase=task.phase,
            receipts=(str(release_receipt),),
            state=release_state,
        )
        if objective_completed:
            # Preserve the claim for diagnostics, but do not turn it into a terminal
            # succeeded event without Work-level completion evidence.
            release_state["terminal_success_deferred"] = True
        self.self_history.record_episode(
            objective=current.objective,
            action="response_release",
            outcome=f"released:{response_sha256}",
            success=True,
            evidence=(str(release_receipt),),
            capabilities=("cumulative_intent", "continuity", "response_sink"),
            lesson="Preserve cumulative objective and durable continuity across fresh extraction boundaries.",
            facets={"task_id": current.task_id, "attempts": current.attempts, "objective_completed": bool(objective_completed)},
        )

    @staticmethod
    def _sha_json(value: Any) -> str:
        return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")).hexdigest()
