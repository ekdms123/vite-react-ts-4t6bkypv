from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CNFProblem:
    clauses: tuple[tuple[int, ...], ...]
    assumptions: tuple[int, ...]
    atom_to_var: dict[str, int]
    var_count: int


class TseitinEncoder:
    """Deterministically encode the project's JSON boolean-expression format.

    Expressions are atoms (strings) or lists using ``not``, ``and``, ``or`` and
    ``implies``. Returned literals use ordinary DIMACS 1-based signed integers.
    Auxiliary variables are allocated after atoms in first-seen traversal order.
    """

    def __init__(self) -> None:
        self.atom_to_var: dict[str, int] = {}
        self.clauses: list[list[int]] = []
        self._next_var = 1

    def _fresh(self) -> int:
        value = self._next_var
        self._next_var += 1
        return value

    def _atom(self, name: str) -> int:
        if not name:
            raise ValueError("boolean atom names must be non-empty strings")
        if name not in self.atom_to_var:
            self.atom_to_var[name] = self._fresh()
        return self.atom_to_var[name]

    def encode(self, spec: Any) -> int:
        if isinstance(spec, str):
            return self._atom(spec)
        if not isinstance(spec, list) or not spec:
            raise ValueError(f"invalid boolean expression spec: {spec!r}")

        op = spec[0]
        args = spec[1:]
        if op == "not" and len(args) == 1:
            return -self.encode(args[0])
        if op == "implies" and len(args) == 2:
            left = self.encode(args[0])
            right = self.encode(args[1])
            return self._encode_or((-left, right))
        if op == "and" and len(args) >= 2:
            return self._encode_and(tuple(self.encode(x) for x in args))
        if op == "or" and len(args) >= 2:
            return self._encode_or(tuple(self.encode(x) for x in args))
        raise ValueError(f"unsupported boolean expression: {spec!r}")

    def _encode_and(self, literals: tuple[int, ...]) -> int:
        out = self._fresh()
        # out -> each input
        for lit in literals:
            self.clauses.append([-out, lit])
        # all inputs -> out
        self.clauses.append([out, *(-lit for lit in literals)])
        return out

    def _encode_or(self, literals: tuple[int, ...]) -> int:
        out = self._fresh()
        # each input -> out
        for lit in literals:
            self.clauses.append([out, -lit])
        # out -> at least one input
        self.clauses.append([-out, *literals])
        return out

    @property
    def var_count(self) -> int:
        return self._next_var - 1


def build_entailment_cnf(problem: dict[str, Any]) -> CNFProblem:
    """Encode ``givens |= conclusion`` as SAT of ``givens & ~conclusion``.

    Structural Tseitin clauses are returned separately from assertion literals so
    a solver supporting assumptions can return an UNSAT assumption core.
    """

    if "conclusion" not in problem:
        raise ValueError("formal_problem requires a conclusion")
    givens = problem.get("givens", [])
    if not isinstance(givens, list):
        raise ValueError("formal_problem.givens must be a list")

    enc = TseitinEncoder()
    assumptions = [enc.encode(item) for item in givens]
    assumptions.append(-enc.encode(problem["conclusion"]))
    return CNFProblem(
        clauses=tuple(tuple(c) for c in enc.clauses),
        assumptions=tuple(assumptions),
        atom_to_var=dict(enc.atom_to_var),
        var_count=enc.var_count,
    )


def dimacs_to_tinysat_literal(literal: int) -> int:
    """Map DIMACS signed literals to tiny-sat's exact internal representation."""
    if literal == 0:
        raise ValueError("DIMACS reserves literal value 0 as the clause terminator")
    return (literal - 1) * 2 if literal > 0 else (-literal - 1) * 2 + 1


def evaluate_clause(clause: tuple[int, ...] | list[int], assignment: list[bool]) -> bool:
    for literal in clause:
        idx = abs(literal) - 1
        if idx < 0 or idx >= len(assignment):
            raise ValueError(f"assignment missing DIMACS variable {abs(literal)}")
        value = bool(assignment[idx])
        if value if literal > 0 else not value:
            return True
    return False


def validate_model(
    clauses: tuple[tuple[int, ...], ...] | list[list[int]],
    assumptions: tuple[int, ...] | list[int],
    assignment: list[bool],
) -> bool:
    unit_clauses = [[lit] for lit in assumptions]
    return all(evaluate_clause(c, assignment) for c in [*clauses, *unit_clauses])
