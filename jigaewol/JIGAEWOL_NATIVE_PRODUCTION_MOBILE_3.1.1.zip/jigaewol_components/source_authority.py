from __future__ import annotations

"""Source-grounded authority predicates.

Destructive lifecycle operations are never inferred from model/semantic payloads.
They require explicit language in the exact user source text. Derived intent may add
routes and hypotheses, but it cannot acquire cancellation/replacement authority.
"""

from jigaewol_components.directive_semantics import affirmative_actionable_marker_present

_EXPLICIT_REPLACEMENT_MARKERS = (
    "이전 요청 취소", "앞 요청 취소", "기존 요청 취소", "전에 말한 건 취소",
    "이전 건 무시", "앞의 요청 무시", "기존 목표 폐기", "기존 목표 버려",
    "이전 대신", "앞의 것 대신", "이전 건 말고", "이전 요청 말고",
    "이전 작업 취소", "이전 건 취소", "아까 거 취소", "그 작업 취소",
    "이전 작업 중단", "그 작업 중단", "이전 건 버려",
    "cancel the previous", "cancel my previous", "cancel previous", "cancel that",
    "ignore the previous", "replace the previous", "discard the previous",
    "instead of the previous", "stop previous", "abort previous",
)


_EXPLICIT_NEW_TASK_MARKERS = (
    "새 작업으로", "새 작업 시작", "새로운 작업으로", "별도 작업으로",
    "별개의 작업", "별개 작업", "이건 별개", "이건 별도", "새 주제로",
    "new task", "separate task", "start a new task", "treat this as a separate task",
)

_EXACT_CANCEL_COMMANDS = {
    "취소", "그만", "중단", "멈춰", "cancel", "stop",
}


def explicit_replacement_requested(message: str) -> bool:
    """Whether exact user source explicitly authorizes destructive replacement.

    This deliberately does not accept a semantic model's interpretation as evidence.
    """
    return affirmative_actionable_marker_present(str(message or ""), _EXPLICIT_REPLACEMENT_MARKERS)


def explicit_cancel_current_task(message: str) -> bool:
    """Whether the exact user source is itself an unambiguous task cancel command."""
    normalized = " ".join(str(message or "").casefold().strip().split()).rstrip(".!?~…")
    return normalized in _EXACT_CANCEL_COMMANDS


def destructive_goal_change_authorized(message: str) -> bool:
    return explicit_replacement_requested(message) or explicit_cancel_current_task(message)


def explicit_new_task_requested(message: str) -> bool:
    """Whether exact user source explicitly requests a detached/new task scope.

    Internal callers may suggest a task split, but they cannot detach unfinished user
    obligations by setting ``new_task``/``continuation`` flags alone.
    """
    return affirmative_actionable_marker_present(str(message or ""), _EXPLICIT_NEW_TASK_MARKERS)
