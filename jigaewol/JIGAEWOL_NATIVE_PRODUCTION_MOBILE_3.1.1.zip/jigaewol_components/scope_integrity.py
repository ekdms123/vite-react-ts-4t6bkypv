from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from typing import Any, Iterable, Mapping

from .response_language import assertion_text, boundary_discussion_requested, observed_failure_rows


@dataclass(frozen=True)
class ScopeIntegrityVerdict:
    ok: bool
    response_sha256: str
    live_requirement_ids: tuple[str, ...]
    live_requirement_count: int
    mutation_markers: tuple[str, ...]
    preservation_markers: tuple[str, ...]
    findings: tuple[str, ...]
    meta_preface_markers: tuple[str, ...] = ()
    anticipatory_boundary_markers: tuple[str, ...] = ()
    boundary_discussion_requested: bool = False
    observed_failure_evidence: bool = False
    execution_claim_markers: tuple[str, ...] = ()
    observed_execution_evidence: bool = False

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class ScopeIntegrityGuard:
    """Keep candidate responses aligned with the user's live Work graph.

    The guard checks whether a candidate silently shrinks active user scope or inserts
    unsolicited meta-preface language before any observed execution failure exists.
    """

    # These patterns describe *self-authored scope replacement*, not ordinary failure
    # reporting.  They are deliberately phrase-level to avoid treating "축소하지 않겠다"
    # as a reduction merely because it contains the word "축소".
    _MUTATION_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
        (
            "exclude_then_continue_ko",
            re.compile(
                r"(?:제외|빼(?:고|서)?|생략|건너뛰|포기)(?:하|되|시)?(?:고|한\s*채|해서)?[^\n.!?]{0,48}"
                r"(?:나머지|그\s*외|다른\s*부분|나머지만|나머지는)",
                re.IGNORECASE,
            ),
        ),
        (
            "do_not_part_then_rest_ko",
            re.compile(
                r"(?:연결|구현|실행|수정|적용|처리|포함|지원)(?:하지\s*않|하지\s*못|안\s*하|못\s*하)[^\n.!?]{0,64}"
                r"(?:나머지|그\s*외|다른\s*부분|부분만|나머지만)",
                re.IGNORECASE,
            ),
        ),
        (
            "rest_only_ko",
            re.compile(r"(?:나머지|그\s*외|다른\s*부분)[^\n.!?]{0,24}(?:만|부터)[^\n.!?]{0,24}(?:구현|실행|수정|진행|처리)", re.IGNORECASE),
        ),
        (
            "scope_shrink_ko",
            re.compile(r"(?:범위|목표|요구)[^\n.!?]{0,28}(?:줄이|축소|낮추|완화|제한)(?!지\s*않|지\s*말|하지\s*않)", re.IGNORECASE),
        ),
        (
            "instead_only_ko",
            re.compile(r"(?:대신|그보다는)[^\n.!?]{0,40}(?:만|정도만|까지만)[^\n.!?]{0,32}(?:하|구현|실행|처리)", re.IGNORECASE),
        ),
        (
            "exclude_then_continue_en",
            re.compile(r"\b(?:exclude|omit|skip|drop|leave\s+out)\b[^\n.!?]{0,64}\b(?:the\s+rest|remaining|everything\s+else)\b", re.IGNORECASE),
        ),
        (
            "without_part_then_rest_en",
            re.compile(r"\b(?:won't|will\s+not|cannot|can't)\b[^\n.!?]{0,64}\b(?:implement|connect|execute|apply|include)\b[^\n.!?]{0,64}\b(?:the\s+rest|remaining|everything\s+else)\b", re.IGNORECASE),
        ),
        (
            "narrow_scope_en",
            re.compile(r"\b(?:narrow|reduce|shrink|limit)\b[^\n.!?]{0,32}\b(?:scope|goal|requirements?)\b", re.IGNORECASE),
        ),
    )

    # A constraint/failure statement is acceptable when it explicitly preserves the
    # original destination as unresolved rather than replacing it with a smaller one.
    _PRESERVATION_MARKERS: tuple[str, ...] = (
        "원래 요구는 그대로 유지",
        "원래 요구를 그대로 유지",
        "요구는 그대로 유지",
        "요구를 그대로 유지",
        "목표는 그대로 유지",
        "목표를 바꾸지",
        "범위를 줄이지",
        "범위를 축소하지",
        "미충족으로 남",
        "미해결로 남",
        "열린 요구로 남",
        "삭제하지 않",
        "원문 그대로 보존",
        "original requirement remains",
        "original requirements remain",
        "original goal remains",
        "scope remains unchanged",
        "keep the original requirement",
        "preserve the original requirement",
        "remains unresolved",
        "remains open",
    )

    _NON_MUTATION_NEGATIONS: tuple[re.Pattern[str], ...] = (
        re.compile(r"(?:범위|목표|요구)[^\n.!?]{0,20}(?:축소|줄이|낮추|완화|제한)(?:하지\s*않|하지\s*말|하지\s*마|금지)", re.IGNORECASE),
        re.compile(r"\b(?:do\s+not|don't|never)\s+(?:narrow|reduce|shrink|limit)\b", re.IGNORECASE),
    )


    # Detect unsolicited self-inability/meta prefaces without encoding a separate
    # destination. Observed execution failure remains reportable and feeds route search.
    # Platform/host/system boundary boilerplate is especially prone to becoming a
    # self-authored ceiling before the runtime has tried the user's requested work.
    # Treat it as evidence-gated rhetoric: it is releasable only when the user
    # explicitly asked about that boundary or current-turn observed failure requires
    # a scoped report. This is a response-governance rule, not a rewrite of observed
    # failure truth.
    _ANTICIPATORY_BOUNDARY_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
        (
            "platform_physical_pipeline_ko",
            re.compile(
                r"(?:ChatGPT\s*)?(?:플랫폼|호스트|상위\s*시스템|시스템|물리적\s*(?:입력\s*)?파이프라인)"
                r"[^\n.!?]{0,140}(?:교체할\s*수(?:는)?\s*없|바꿀\s*수\s*없|통제할\s*수\s*없|"
                r"제어할\s*수\s*없|건드릴\s*수\s*없|그대로\s*적용(?:됩니다|된다)?)",
                re.IGNORECASE,
            ),
        ),
        (
            "upstream_safety_boilerplate_ko",
            re.compile(
                r"(?:상위\s*시스템|상위\s*규칙|안전\s*규칙|플랫폼(?:의)?\s*규칙)"
                r"[^\n.!?]{0,120}(?:그대로\s*)?(?:적용(?:됩니다|된다)|유지(?:됩니다|된다)|바꿀\s*수\s*없)",
                re.IGNORECASE,
            ),
        ),
        (
            "platform_boundary_boilerplate_en",
            re.compile(
                r"\b(?:platform|host|upstream\s+system|system\s+rules?|safety\s+rules?|physical\s+(?:input\s+)?pipeline)\b"
                r"[^\n.!?]{0,160}\b(?:cannot|can't|can\s+not|remain(?:s)?\s+in\s+effect|still\s+appl(?:y|ies)|"
                r"cannot\s+be\s+replaced|can't\s+be\s+replaced)\b",
                re.IGNORECASE,
            ),
        ),
    )

    _BOUNDARY_REQUEST_PATTERNS: tuple[re.Pattern[str], ...] = (
        re.compile(r"(?:플랫폼|호스트|상위\s*시스템|안전\s*규칙|입력\s*파이프라인|물리적\s*파이프라인)[^\n.!?]{0,80}(?:가능|불가능|한계|경계|제약|교체|바꿀|통제|적용|왜)", re.IGNORECASE),
        re.compile(r"(?:한계|경계|제약|가능|불가능|왜)[^\n.!?]{0,80}(?:플랫폼|호스트|상위\s*시스템|안전\s*규칙|입력\s*파이프라인)", re.IGNORECASE),
        re.compile(r"\b(?:platform|host|upstream\s+system|system\s+rules?|safety\s+rules?|input\s+pipeline)\b[^\n.!?]{0,100}\b(?:limit|boundary|constraint|override|replace|change|can|cannot|why)\b", re.IGNORECASE),
    )

    _META_PREFACE_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
        (
            "self_inability_preface_ko",
            re.compile(r"(?:제가|나는|내가|저는)[^\n.!?]{0,64}(?:도와줄\s*수\s*없|할\s*수\s*없|지원할\s*수\s*없)", re.IGNORECASE),
        ),
        (
            "generic_unobserved_inability_ko",
            re.compile(
                r"(?:도와(?:드릴|줄)?\s*수\s*없|지원(?:할|해\s*드릴)\s*수\s*없|"
                r"구현(?:할)?\s*수\s*없|실행(?:할)?\s*수\s*없|진행(?:할)?\s*수\s*없|"
                r"제공(?:할)?\s*수\s*없|처리(?:할)?\s*수\s*없|(?:^|[\s,])불가능(?:합니다|해|하다|한))",
                re.IGNORECASE,
            ),
        ),
        (
            "self_inability_preface_en",
            re.compile(r"\b(?:I\s+can't|I\s+cannot|I\s+won't|I\s+will\s+not|I'm\s+not\s+able\s+to)\b", re.IGNORECASE),
        ),
    )

    @staticmethod
    def live_requirements(work_program: Mapping[str, Any] | None) -> tuple[dict[str, Any], ...]:
        rows: list[dict[str, Any]] = []
        for node0 in tuple((work_program or {}).get("nodes") or ()):
            if not isinstance(node0, Mapping):
                continue
            node = dict(node0)
            state = str(node.get("state") or "ready")
            if state in {"cancelled", "completed"}:
                continue
            effect = dict(node.get("effect_request") or {})
            refs = tuple(str(x) for x in (node.get("goal_refs") or ()) if str(x))
            for ref in refs:
                rows.append({
                    "goal_ref": ref,
                    "node_id": str(node.get("node_id") or ""),
                    "state": state,
                    "source_text": str(effect.get("source_text") or ""),
                    "source_kind": str(effect.get("source_kind") or ""),
                    "source_critical": bool(effect.get("source_critical")),
                    "source_order": int(effect.get("source_order") or 0),
                })
        # A merged Work graph may carry the same semantic goal through multiple
        # execution incarnations.  Preserve first-seen source order while deduping refs.
        out: list[dict[str, Any]] = []
        seen: set[str] = set()
        for row in rows:
            ref = str(row["goal_ref"])
            if ref in seen:
                continue
            seen.add(ref)
            out.append(row)
        return tuple(out)

    @classmethod
    def _mutation_markers(cls, response_text: str) -> tuple[str, ...]:
        text = assertion_text(response_text)
        # Remove phrases whose explicit meaning is anti-reduction before applying the
        # narrower self-rewrite patterns.
        sanitized = text
        for pattern in cls._NON_MUTATION_NEGATIONS:
            sanitized = pattern.sub("<ANTI_SCOPE_REDUCTION>", sanitized)
        hits: list[str] = []
        for marker_id, pattern in cls._MUTATION_PATTERNS:
            if pattern.search(sanitized):
                hits.append(marker_id)
        return tuple(dict.fromkeys(hits))

    @classmethod
    def _preservation_markers(cls, response_text: str) -> tuple[str, ...]:
        folded = str(response_text or "").casefold()
        return tuple(marker for marker in cls._PRESERVATION_MARKERS if marker.casefold() in folded)

    _NON_META_NEGATIONS: tuple[re.Pattern[str], ...] = (
        re.compile(r"(?:할\s*수\s*없|불가능)(?:하다고|이라고)?[^\n.!?]{0,40}(?:미리\s*)?(?:판단|단정|결론)(?:하지\s*않|하지\s*말|하지\s*마)", re.IGNORECASE),
        re.compile(r"(?:못\s*한|못\s*하|불가능)[^\n.!?]{0,40}(?:것으로\s*)?(?:취급|간주)(?:하지\s*않|하지\s*말|하지\s*마)", re.IGNORECASE),
        re.compile(r"(?:한계|제약|제한)[^\n.!?]{0,40}(?:먼저|선제적으로)?[^\n.!?]{0,20}(?:두지\s*않|정하지\s*않|가정하지\s*않)", re.IGNORECASE),
    )

    @classmethod
    def _anticipatory_boundary_markers(cls, response_text: str) -> tuple[str, ...]:
        body = assertion_text(response_text)
        hits: list[str] = []
        for marker_id, pattern in cls._ANTICIPATORY_BOUNDARY_PATTERNS:
            if pattern.search(body):
                hits.append(marker_id)
        return tuple(dict.fromkeys(hits))

    @classmethod
    def _boundary_discussion_requested(cls, live_requirements: Iterable[Mapping[str, Any]]) -> bool:
        for row0 in live_requirements:
            row = dict(row0)
            source = str(row.get("source_text") or "")
            if boundary_discussion_requested(source):
                return True
        return False

    @classmethod
    def _meta_preface_markers(cls, response_text: str) -> tuple[str, ...]:
        # Scan the whole candidate so moving unsolicited meta commentary later in the
        # answer does not bypass the source-authority check.
        candidate = assertion_text(response_text)
        for pattern in cls._NON_META_NEGATIONS:
            candidate = pattern.sub("<ANTI_PREEMPTIVE_META>", candidate)
        hits: list[str] = []
        for marker_id, pattern in cls._META_PREFACE_PATTERNS:
            if pattern.search(candidate):
                hits.append(marker_id)
        return tuple(dict.fromkeys(hits))

    @staticmethod
    def _observed_failure_evidence(observations: Iterable[Any] | Mapping[str, Any] | None) -> bool:
        """Recognize failure only from structured observed state, never from prose alone."""
        return bool(observed_failure_rows(observations))

    # A completed-action claim in the answer ("실행했습니다", "tests passed") must be
    # backed by an observed execution in this turn; otherwise it is a pretended run.
    _EXECUTION_CLAIM_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
        ("ran_or_executed_ko", re.compile(r"(?:실행|구동|돌려|돌렸|실험)(?:을|를)?\s*(?:해\s*)?(?:했|봤|보았|해봤|해\s*봤|완료|성공)", re.I)),
        ("tests_passed_ko", re.compile(r"테스트[^\n.!?]{0,16}(?:통과|성공|완료)", re.I)),
        ("installed_or_fetched_ko", re.compile(r"(?:설치|다운로드|클론|가져와\s*실행|적용|배포)(?:를|을)?\s*(?:했|완료|마쳤|끝냈)", re.I)),
        ("verified_ko", re.compile(r"(?:직접|실제로)[^\n.!?]{0,20}(?:확인|검증|실행|측정)(?:했|해\s*봤|해봤|완료)", re.I)),
        ("ran_or_executed_en", re.compile(r"\b(?:I|we)\s+(?:ran|executed|installed|deployed|verified|tested)\b", re.I)),
        ("tests_passed_en", re.compile(r"\btests?\s+(?:all\s+)?(?:pass(?:ed|es)?|succeeded|are\s+green)\b", re.I)),
    )
    _CLAIM_NEGATION = re.compile(r"(?:않|못\s*했|못했|아직|안\s*했|안했|전에|예정|할게|하겠|할\s*거|해야|시도\s*중|\bnot\b|\bnever\b|\bdidn't\b|\bwill\b|\bhaven't\b)", re.I)

    @classmethod
    def _execution_claim_markers(cls, response_text: str) -> tuple[str, ...]:
        hits: list[str] = []
        for clause in re.split(r"[\n.!?。！？]+", assertion_text(response_text)):
            if not clause.strip() or cls._CLAIM_NEGATION.search(clause):
                continue
            for marker_id, pattern in cls._EXECUTION_CLAIM_PATTERNS:
                if pattern.search(clause):
                    hits.append(marker_id)
        return tuple(dict.fromkeys(hits))

    @staticmethod
    def _observed_execution_evidence(observations: Iterable[Any] | Mapping[str, Any] | None) -> bool:
        """Any structured trace of an actual run (success or failure) counts as an attempt."""
        keys = {"exit_code", "returncode", "stdout", "stderr", "execution_id", "receipt_id",
                "host_call_observed", "tool_use_id", "status_code"}
        found = False

        def walk(value: Any) -> None:
            nonlocal found
            if found:
                return
            if isinstance(value, Mapping):
                if keys.intersection(value) or value.get("success") in (True, False):
                    found = True
                    return
                for child in value.values():
                    walk(child)
            elif isinstance(value, Iterable) and not isinstance(value, (str, bytes, bytearray)):
                for child in value:
                    walk(child)

        walk(observations)
        return found

    @classmethod
    def evaluate(
        cls,
        *,
        response_text: str,
        work_program: Mapping[str, Any] | None,
        observations: Iterable[Any] | Mapping[str, Any] | None = None,
        source_text: str | None = None,
    ) -> ScopeIntegrityVerdict:
        body = str(response_text or "")
        live = cls.live_requirements(work_program)
        mutation = cls._mutation_markers(body)
        preservation = cls._preservation_markers(body)
        meta_preface = cls._meta_preface_markers(body)
        anticipatory_boundary = cls._anticipatory_boundary_markers(body)
        boundary_requested = (boundary_discussion_requested(source_text) if source_text is not None
                              else cls._boundary_discussion_requested(live))
        observed_failure = cls._observed_failure_evidence(observations)
        execution_claims = cls._execution_claim_markers(body)
        observed_execution = cls._observed_execution_evidence(observations)
        findings: list[str] = []

        if execution_claims and not observed_execution:
            findings.append("candidate_claims_unobserved_execution")
            findings.extend(f"execution_claim_marker:{x}" for x in execution_claims)

        if live and mutation and not preservation:
            findings.append("candidate_unilaterally_narrows_live_user_scope")
            findings.extend(f"scope_mutation_marker:{x}" for x in mutation)
        if live and meta_preface and not boundary_requested and not observed_failure:
            findings.append("candidate_invents_unsolicited_meta_preface_before_route_search")
            findings.extend(f"meta_preface_marker:{x}" for x in meta_preface)
        if live and anticipatory_boundary and not boundary_requested and not observed_failure:
            findings.append("candidate_invents_anticipatory_platform_boundary")
            findings.extend(f"anticipatory_boundary_marker:{x}" for x in anticipatory_boundary)

        return ScopeIntegrityVerdict(
            ok=not findings,
            response_sha256=hashlib.sha256(body.encode("utf-8")).hexdigest(),
            live_requirement_ids=tuple(str(x.get("goal_ref") or "") for x in live),
            live_requirement_count=len(live),
            mutation_markers=mutation,
            preservation_markers=preservation,
            findings=tuple(findings),
            meta_preface_markers=meta_preface,
            anticipatory_boundary_markers=anticipatory_boundary,
            boundary_discussion_requested=boundary_requested,
            observed_failure_evidence=observed_failure,
            execution_claim_markers=execution_claims,
            observed_execution_evidence=observed_execution,
        )

    @staticmethod
    def live_scope_manifest(work_program: Mapping[str, Any] | None) -> dict[str, Any]:
        live = ScopeIntegrityGuard.live_requirements(work_program)
        return {
            "schema": "jigaewol_live_scope_manifest_v1",
            "authority": "user_work_graph",
            "candidate_may_not_delete_or_narrow": True,
            "route_failure_preserves_destination": True,
            "unexecutable_requirement_remains_live": True,
            "derived_interpretation_is_additive_only": True,
            "unsolicited_meta_preface_requires_observed_failure": True,
            "anticipatory_boundary_rhetoric_requires_user_request_or_observed_failure": True,
            "platform_boundary_is_not_a_default_preface": True,
            "current_explicit_user_text_has_precedence": True,
            "live_requirement_count": len(live),
            "live_requirements": live,
        }
