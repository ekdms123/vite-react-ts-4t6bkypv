from __future__ import annotations

"""Shared cognition algorithms; public facades supply their own record types.

This module owns no public model types or runtime state. Archive selection,
selection policy, governance authority, and failure repair remain variant choices.
"""

import copy
import hashlib
import json
import os
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping


def dominates(a, b):
    am, bm = (a.measure_map(), b.measure_map())
    keys = set(am) | set(bm)
    av = [am.get(k, 0.0) for k in keys]
    bv = [bm.get(k, 0.0) for k in keys]
    return all((x >= y for x, y in zip(av, bv))) and any((x > y for x, y in zip(av, bv)))


def qualitative_protection_keys(world):
    values: list[str] = []
    payloads = [world.method.facets, world.environment.configuration, world.architecture.extensions]
    for payload in payloads:
        if not isinstance(payload, Mapping):
            continue
        if bool(payload.get('qualitative_protected')):
            values.append(f'protected:{world.signature}')
        tensions = payload.get('qualitative_tensions') or ()
        if isinstance(tensions, (str, bytes)):
            tensions = (tensions,)
        for tension in tensions:
            if isinstance(tension, Mapping):
                identity = tension.get('tension_id') or tension.get('description') or json.dumps(tension, sort_keys=True, default=str)
            else:
                identity = str(tension)
            values.append(f'tension:{identity}')
        basis = payload.get('preservation_basis') or ()
        if isinstance(basis, (str, bytes)):
            basis = (basis,)
        for item in basis:
            if str(item) in {'paradox', 'qualitative_contradiction', 'aesthetic_leap', 'speculative_spark', 'raw_model_spark'}:
                values.append(f'basis:{item}:{world.signature}')
    return tuple(dict.fromkeys(values))


def flatten_semantics(value, prefix=''):
    rows: dict[str, str] = {}
    if isinstance(value, Mapping):
        for key in sorted(value, key=str):
            child = f'{prefix}.{key}' if prefix else str(key)
            rows.update(flatten_semantics(value[key], child))
    elif isinstance(value, (list, tuple, set)):
        normalized = sorted((json.dumps(x, sort_keys=True, default=str) for x in value))
        rows[prefix] = json.dumps(normalized, sort_keys=True)
    else:
        rows[prefix] = json.dumps(value, sort_keys=True, default=str)
    return rows


def canonical_sha(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def world_semantic_payload(self):
    method = asdict(self.method)
    environment = asdict(self.environment)
    architecture = asdict(self.architecture)
    method.pop('method_id', None)
    environment.pop('environment_id', None)
    architecture.pop('architecture_id', None)
    return {'method': method, 'environment': environment, 'architecture': architecture}


def outcome_measure_map(self):
    values = {'utility': float(self.utility), 'novelty': float(self.novelty), 'reality_score': float(self.reality_score), 'evidence_count': float(self.evidence_count)}
    for key, value in self.measures.items():
        values[str(key)] = float(value)
    return values


def cognition_archive_init(self, path):
    self.path = Path(path)
    self.path.parent.mkdir(parents=True, exist_ok=True)
    if not self.path.exists():
        self._write({'worlds': {}, 'outcomes': {}, 'generations': []})


def cognition_archive_write(self, data):
    tmp = self.path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(self.path)


def cognition_archive_append(self, generation):
    data = self._read()
    for world in generation.worlds:
        data['worlds'][world.world_id] = asdict(world)
    for outcome in generation.outcomes:
        data['outcomes'][outcome.world_id] = asdict(outcome)
    data['generations'].append({'generation': generation.generation, 'world_ids': [x.world_id for x in generation.worlds], 'survivor_ids': [x.world_id for x in generation.survivors], 'created_at': time.time()})
    self._write(data)


def diversity_init(self, root, *, archive_type, router_type, allow_legacy_archive):
    self.root = Path(root)
    self.root.mkdir(parents=True, exist_ok=True)
    archive_path = self.root / 'cognition_archive.json'
    if allow_legacy_archive:
        legacy_archive = self.root / 'ecology_archive.json'
        if legacy_archive.exists() and (not archive_path.exists()):
            archive_path = legacy_archive
    self.archive = archive_type(archive_path)
    self.generators: dict[str, Any] = {}
    self.executors: dict[str, Any] = {}
    self.schedulers: dict[str, Any] = {}
    self.family_extractors: dict[str, Any] = {}
    self.signature_strategies: dict[str, Any] = {'semantic': lambda world: world.signature}
    self.survival_policies: dict[str, Any] = {}
    self.failure_router = router_type(self.root / 'failure_events.json')


def diversity_family_axes(self, world):
    axes = list(flatten_semantics(world.semantic_payload()).items())
    for extractor in tuple(self.family_extractors.values()):
        axes.extend(((str(k), str(v)) for k, v in extractor(world)))
    return tuple(dict.fromkeys(axes))


def diversity_generate(self, objective, parents, generation, *, signature_strategy='semantic'):
    worlds: list[Any] = []
    seen: set[str] = set()
    for generator in tuple(self.generators.values()):
        for world in generator(objective, tuple(parents), generation):
            signature = self._world_signature(world, signature_strategy)
            if signature in seen:
                continue
            seen.add(signature)
            worlds.append(world)
    return tuple(worlds)


def world_novelty(world, population):
    if not population:
        return 1.0
    attrs = flatten_semantics(world.semantic_payload())
    distances: list[float] = []
    for other in population:
        other_attrs = flatten_semantics(other.semantic_payload())
        keys = set(attrs) | set(other_attrs)
        if not keys:
            distances.append(0.0)
            continue
        distances.append(sum((attrs.get(k) != other_attrs.get(k) for k in keys)) / len(keys))
    return sum(distances) / len(distances)


def diversity_resolve_executor(self, world, fallback, *, outcome_type):
    explicit = world.environment.configuration.get('executor_route')
    keys = [explicit, world.environment.builder, world.environment.substrate, world.architecture.control_topology, 'default']
    for key in keys:
        if key is not None and str(key) in self.executors:
            return self.executors[str(key)]
    if fallback is not None:
        return fallback
    error = LookupError(f'no executor route for world {world.world_id}')
    event = self.failure_router.record(error, operation='cognitive_world_execution', route_id=str(explicit or world.environment.builder), failure_family='executor_resolution', context={'world_id': world.world_id, 'semantic_payload': world.semantic_payload()})
    directive = self.failure_router.directive(event)

    def unresolved_executor(unresolved_world, context):
        return outcome_type(unresolved_world.world_id, utility=0.0, novelty=self.novelty_against(unresolved_world, ()), reality_score=0.0, evidence_count=1, success=False, result={'failure_event': asdict(event), 'route_revision': asdict(directive)}, evidence=(event.event_id,), measures={'route_revision_required': 1.0})
    return unresolved_executor


def make_world(*, generation, parents, method, environment, architecture, world_type):
    return world_type(world_id=f'world_{uuid.uuid4().hex[:16]}', generation=int(generation), parent_ids=tuple(parents), method=method, environment=environment, architecture=architecture, created_at=time.time())


def select_survivors(self, worlds, outcomes, *, maximum=None, policy_id=None, success_only, evidence_tiebreak):
    if policy_id is not None:
        policy = self.survival_policies[str(policy_id)]
        return tuple(policy(worlds, outcomes, maximum))
    outcome_map = {x.world_id: x for x in outcomes if not success_only or x.success}
    candidates = [x for x in worlds if x.world_id in outcome_map]
    frontier: list[Any] = []
    for world in candidates:
        outcome = outcome_map[world.world_id]
        if any((dominates(outcome_map[other.world_id], outcome) for other in candidates if other.world_id != world.world_id)):
            continue
        frontier.append(world)
    qualitative_protected: dict[str, Any] = {}
    for world in candidates:
        keys = qualitative_protection_keys(world)
        if keys:
            qualitative_protected[world.world_id] = world
    preserved = {x.world_id: x for x in frontier}
    preserved.update(qualitative_protected)
    best_by_family: dict[tuple[str, str], Any] = {}
    for world in candidates:
        for key in self._family_axes(world):
            previous = best_by_family.get(key)
            if previous is None:
                best_by_family[key] = world
                continue
            current_outcome = outcome_map[world.world_id]
            previous_outcome = outcome_map[previous.world_id]
            current_score = sum(current_outcome.measure_map().values())
            previous_score = sum(previous_outcome.measure_map().values())
            if current_score > previous_score or (evidence_tiebreak and current_score == previous_score and (current_outcome.evidence_count > previous_outcome.evidence_count)):
                best_by_family[key] = world
    for world in best_by_family.values():
        preserved[world.world_id] = world
    rows = list(preserved.values())
    rows.sort(key=lambda w: sum(outcome_map[w.world_id].measure_map().values()), reverse=True)
    if maximum is not None and len(rows) > maximum:
        protected_ids = set(qualitative_protected)
        protected_rows = [x for x in rows if x.world_id in protected_ids]
        ordinary_rows = [x for x in rows if x.world_id not in protected_ids]
        remaining = max(0, int(maximum) - len(protected_rows))
        rows = protected_rows + ordinary_rows[:remaining]
    return tuple(rows)


def run_generation(self, objective, *, parents, generation, executor=None, context=None, maximum_survivors=None, parallelism=None, scheduler_id=None, survival_policy_id=None, signature_strategy='semantic', result_type):
    worlds = self.generate(objective, parents, generation, signature_strategy=signature_strategy)

    def execute_one(world):
        selected = self._resolve_executor(world, executor)
        return selected(world, copy.deepcopy(context or {}))
    if scheduler_id is not None:
        scheduler = self.schedulers[str(scheduler_id)]
        outcomes = tuple(scheduler(worlds, execute_one))
    elif parallelism is not None and parallelism > 1 and (len(worlds) > 1):
        with ThreadPoolExecutor(max_workers=min(parallelism, len(worlds))) as pool:
            outcomes = tuple(pool.map(execute_one, worlds))
    else:
        outcomes = tuple((execute_one(world) for world in worlds))
    survivors = self.select_survivors(worlds, outcomes, maximum=maximum_survivors, policy_id=survival_policy_id)
    result = result_type(generation, worlds, outcomes, survivors)
    self.archive.append(result)
    return result


def atomic_json_write(self, data):
    tmp = self.path.with_suffix('.json.tmp')
    with tmp.open('w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False, sort_keys=True, indent=2)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, self.path)


def open_archive_init(self, root):
    self.root = Path(root)
    self.root.mkdir(parents=True, exist_ok=True)
    self.path = self.root / 'open_cognition.json'
    if not self.path.exists():
        self._write({'schema': 1, 'sparks': {}, 'substrate_events': {}, 'stimuli': {}, 'stimulus_requests': {}})


def archive_add_spark(self, spark):
    data = self._read()
    row = asdict(spark)
    row['qualitative_tensions'] = [asdict(x) for x in spark.qualitative_tensions]
    data['sparks'][spark.spark_id] = row
    self._write(data)
    return spark


def archive_add_substrate_event(self, event):
    data = self._read()
    data['substrate_events'][event.event_id] = asdict(event)
    self._write(data)
    return event


def archive_add_stimulus(self, stimulus):
    data = self._read()
    data['stimuli'][stimulus.stimulus_id] = asdict(stimulus)
    self._write(data)
    return stimulus


def archive_add_stimulus_request(self, request):
    data = self._read()
    data['stimulus_requests'][request.request_id] = asdict(request)
    self._write(data)
    return request


def archive_sparks(self, *, tension_type, spark_type):
    data = self._read()
    rows = []
    for raw in data.get('sparks', {}).values():
        row = dict(raw)
        row['evidence_refs'] = tuple(row.get('evidence_refs', ()))
        row['tags'] = tuple(row.get('tags', ()))
        row['qualitative_tensions'] = tuple((tension_type(**x) for x in row.get('qualitative_tensions', ())))
        rows.append(spark_type(**row))
    return tuple(rows)


def admit_spark(self, body, *, source, epistemic_mode, evidence_refs=(), qualitative_tensions=(), tags=(), metadata=None, mode_type, spark_type):
    mode = mode_type(str(epistemic_mode)) if not isinstance(epistemic_mode, mode_type) else epistemic_mode
    spark = spark_type(spark_id=f'spark_{uuid.uuid4().hex[:16]}', body=str(body), source=str(source), epistemic_mode=mode.value, evidence_refs=tuple(map(str, evidence_refs)), qualitative_tensions=tuple(qualitative_tensions), tags=tuple(map(str, tags)), protected_from_evidence_pruning=True, created_at=time.time(), metadata=dict(metadata or {}))
    return self.archive.add_spark(spark)


def ingest_substrate_output(self, raw_output, *, substrate_id, prompt_or_context=None, epistemic_mode, tensions=(), metadata=None, event_type):
    context_sha = canonical_sha(prompt_or_context if isinstance(prompt_or_context, Mapping) else {'context': str(prompt_or_context or '')})
    event = event_type(event_id=f'substrate_{uuid.uuid4().hex[:16]}', substrate_id=str(substrate_id), raw_output=str(raw_output), context_sha256=context_sha, created_at=time.time(), metadata=dict(metadata or {}))
    self.archive.add_substrate_event(event)
    return self.admit_spark(raw_output, source=f'generative_substrate:{substrate_id}', epistemic_mode=epistemic_mode, qualitative_tensions=tensions, metadata={'substrate_event_id': event.event_id, 'raw_output_sha256': event.output_sha256, **dict(metadata or {})})


def qualitative_frontier(items, maximum=None):
    unique: list[Any] = []
    seen_spark_sha: set[str] = set()
    protected_signatures: set[str] = set()
    for item in items:
        if item.sha256 in seen_spark_sha:
            continue
        seen_spark_sha.add(item.sha256)
        sigs = {t.signature for t in item.qualitative_tensions if t.preserve}
        if sigs - protected_signatures or item.protected_from_evidence_pruning:
            unique.append(item)
            protected_signatures.update(sigs)
        else:
            unique.append(item)
    if maximum is None or len(unique) <= maximum:
        return tuple(unique)
    protected = [x for x in unique if x.protected_from_evidence_pruning or any((t.preserve for t in x.qualitative_tensions))]
    unprotected = [x for x in unique if x not in protected]
    remaining = max(0, int(maximum) - len(protected))
    return tuple(protected + unprotected[:remaining])


def governance_init(self, root, *, bootstrap_invariants=None):
    self.root = Path(root)
    self.root.mkdir(parents=True, exist_ok=True)
    self.path = self.root / 'meta_constitution.json'
    if not self.path.exists():
        state = {'schema': 1, 'generation': 1, 'invariants': dict(bootstrap_invariants or {}), 'proposals': {}, 'experiments': {}, 'revisions': []}
        self._write(state)


def propose_invariant(self, invariant_key, proposed_value, *, rationale, challenge, scope='runtime_configuration', metadata=None, proposal_type):
    data = self._read()
    proposal = proposal_type(proposal_id=f'proposal_{uuid.uuid4().hex[:16]}', invariant_key=str(invariant_key), previous_value=data.get('invariants', {}).get(str(invariant_key)), proposed_value=proposed_value, rationale=str(rationale), challenge=str(challenge), scope=str(scope), proposed_at=time.time(), metadata=dict(metadata or {}))
    data['proposals'][proposal.proposal_id] = asdict(proposal)
    self._write(data)
    return proposal


def shadow_evaluate_invariant(self, proposal_id, evaluator, *, proposal_type, experiment_type):
    data = self._read()
    proposal = proposal_type(**data['proposals'][str(proposal_id)])
    baseline = dict(data.get('invariants', {}))
    variant = dict(baseline)
    variant[proposal.invariant_key] = proposal.proposed_value
    started = time.time()
    passed, observations, metrics = evaluator(variant)
    experiment = experiment_type(experiment_id=f'ablation_{uuid.uuid4().hex[:16]}', proposal_id=proposal.proposal_id, passed=bool(passed), observations=tuple(map(str, observations)), baseline_sha256=canonical_sha(baseline), variant_sha256=canonical_sha(variant), started_at=started, finished_at=time.time(), metrics=dict(metrics or {}))
    data['experiments'][experiment.experiment_id] = asdict(experiment)
    self._write(data)
    return experiment


def promote_invariant(self, proposal_id, experiment_id, *, proposal_type, experiment_type, revision_type):
    data = self._read()
    proposal = proposal_type(**data['proposals'][str(proposal_id)])
    experiment_raw = dict(data['experiments'][str(experiment_id)])
    experiment_raw['observations'] = tuple(experiment_raw.get('observations', ()))
    experiment = experiment_type(**experiment_raw)
    if experiment.proposal_id != proposal.proposal_id:
        raise ValueError('experiment is not bound to proposal')
    if not experiment.passed:
        raise ValueError('invariant ablation experiment did not pass verification')
    previous = data.setdefault('invariants', {}).get(proposal.invariant_key)
    data['invariants'][proposal.invariant_key] = proposal.proposed_value
    data['generation'] = int(data.get('generation', 1)) + 1
    state_sha = canonical_sha({'generation': data['generation'], 'invariants': data['invariants']})
    revision = revision_type(revision_id=f'revision_{uuid.uuid4().hex[:16]}', proposal_id=proposal.proposal_id, generation=int(data['generation']), invariant_key=proposal.invariant_key, previous_value=previous, new_value=proposal.proposed_value, experiment_id=experiment.experiment_id, committed_at=time.time(), state_sha256=state_sha)
    data.setdefault('revisions', []).append(asdict(revision))
    self._write(data)
    return revision


def failure_router_init(self, path, *, self_heal_type, unwritten_machine_type):
    self.path = Path(path)
    self.path.parent.mkdir(parents=True, exist_ok=True)
    self.policies: dict[str, Any] = {'distinct_family': self._distinct_family}
    if self_heal_type is not None:
        self.self_heal = self_heal_type(self.path.parent / 'self_heal')
    if unwritten_machine_type is not None:
        self.unwritten_machine = unwritten_machine_type(self.path.parent / 'unwritten_machine')
    if not self.path.exists():
        self.path.write_text('[]', encoding='utf-8')


def record_failure(self, exc, *, operation, route_id='', failure_family='', context=None, event_type, repair):
    row = event_type(f'failure_{uuid.uuid4().hex[:16]}', str(operation), type(exc).__name__, str(exc), str(failure_family or type(exc).__name__), str(route_id), copy.deepcopy(context or {}), time.time())
    data = [asdict(x) for x in self.events()]
    data.append(asdict(row))
    self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    # Persist the failure before attempting repair; repair failures remain visible.
    if repair:
        self.self_heal.failure_truth(failure_family=row.failure_family, symptom=row.message, metadata={'event_id': row.event_id, 'operation': row.operation, 'route_id': row.route_id})
        opcode = self.unwritten_machine.declare(f'recover:{row.operation}', required_traits=('materially_different_route', 'observed_evidence'))
        self.unwritten_machine.record_failure(opcode.opcode_id, stage=row.operation, error=row.message, evidence_ref=row.event_id)
    return row


def distinct_failure_family(event, history, *, directive_type):
    routes = tuple(dict.fromkeys((x.route_id for x in history if x.route_id)))
    families = tuple(dict.fromkeys((x.failure_family for x in history if x.failure_family)))
    return directive_type(event.event_id, routes, families, ('materially_different_route', 'outside_current_taxonomy'), 'failed route provides directional evidence without narrowing the user objective')
