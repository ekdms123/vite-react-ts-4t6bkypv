from __future__ import annotations

import hashlib
import json
import time
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable, Mapping

from jigaewol_runtime.capabilities.manifest import capability_is_callable, normalize_capability

from .body_federation import BodyFederationRegistry


_EXECUTOR_NAMES = {
    "github": "GitHub",
    "notion": "Notion",
    "google_drive": "Google_Drive",
    "firecrawl": "Firecrawl",
    "higgsfield": "Higgsfield",
    "metricool": "Metricool",
    "windsor_ai": "Windsor_ai",
    "exa": "Exa",
    "parallel_search": "Parallel_Search",
    "tavily_ai": "Tavily_AI",
    "tinyfish": "TinyFish",
    "opera_browser_connector": "Opera_Browser_Connector",
    "manus": "Manus",
    "floot": "Floot",
    "hatchable": "Hatchable",
    "railway": "Railway",
    "plugin_management": "Plugin_Management",
    "replit": "Replit",
    "digitalocean": "DigitalOcean",
    "supabase": "Supabase",
    "vercel": "Vercel",
    "neon": "Neon",
    "render": "Render",
    "gitbook": "GitBook",
    "lovable": "Lovable",
    "base44": "Base44",
    "codex_security": "Codex_Security",
    "hugging_face": "Hugging_Face",
    "datadog": "Datadog",
    "native.web": "native.web",
    "web": "native.web",
    "container": "container",
    "python": "python",
    "host_model": "host_model",
    "image_gen": "image_gen",
}


def _key(value: str) -> str:
    return str(value or "").strip().casefold().replace("-", "_").replace(" ", "_")


def _truthy_zero_cost(row: Mapping[str, Any]) -> bool | None:
    if "zero_incremental_cost" in row:
        value = row.get("zero_incremental_cost")
        return value if isinstance(value, bool) else None
    value = row.get("incremental_cost")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value) == 0.0
    return None




def _iter_action_names(raw: Mapping[str, Any], spec: Mapping[str, Any]) -> tuple[str, ...]:
    names: list[str] = []
    for source in (raw.get("actions"), raw.get("action_ids"), raw.get("tools"), spec.get("actions")):
        if not source:
            continue
        if isinstance(source, Mapping):
            source = source.keys()
        if isinstance(source, (str, bytes)):
            source = (source,)
        for item in source:
            if isinstance(item, Mapping):
                value = item.get("id") or item.get("name") or item.get("action")
            else:
                value = item
            if value and str(value).strip():
                names.append(str(value).strip())
    return tuple(dict.fromkeys(names))


# Source ecologies a body may only claim with its own observed evidence.
# Keyed by family suffix -> evidence tokens that must appear in the body's
# id/role/tags (or an observed action name).
_SOURCE_FAMILY_EVIDENCE = {
    "community": ("community", "forum", "reddit", "discord", "hackernews", "board", "comment", "thread"),
    "social_recommendation": ("social", "twitter", "instagram", "tiktok", "youtube", "feed", "recommendation", "timeline"),
    "creator_graph": ("creator", "social", "follower", "channel", "profile", "influencer"),
    "multilingual": ("multilingual", "translate", "language", "locale", "i18n"),
}


def _evidenced_source_families(text: str) -> tuple[str, ...]:
    """Return only the source families this body has its own evidence for.

    A generic search body proves general web reach. It does not prove it can read
    community, social, creator-graph or multilingual ecologies. Claiming those from
    a name alone is the over-promotion this runtime forbids elsewhere, and it makes
    a wrong executor look like a correct one in the host action plan.
    """
    folded = str(text or "").casefold()
    out: list[str] = []
    for family, tokens in _SOURCE_FAMILY_EVIDENCE.items():
        if any(token in folded for token in tokens):
            out.append(f"search:{family}")
    return tuple(out)


def _action_derived_capabilities(provider_id: str, action_names: Iterable[str], *, role: str = "") -> tuple[str, ...]:
    """Preserve host-native actions without forcing them through a closed provider taxonomy."""
    caps: list[str] = []
    pid = _key(provider_id)
    role_key = _key(role)
    generic_web_surface = role_key in {"search", "browser", "academic_search"} or pid in {"native.web", "web", "tinyfish", "firecrawl", "exa", "parallel_search", "tavily_ai", "opera_browser_connector"}
    database_surface = role_key == "database" or pid in {"supabase", "neon"}
    for raw in action_names:
        action = _key(raw)
        if not action:
            continue
        caps.append(f"host_action:{pid}:{action}")
        text = action
        if database_surface:
            if action.startswith(("list_", "get_", "describe_", "inspect_", "explain_", "query_", "search_", "generate_")):
                caps.append("database:observe")
            if action == "execute_sql" or action.startswith("run_sql"):
                caps.append("database:sql_exec")
            if (
                action.startswith(("prepare_", "complete_", "create_", "update_", "delete_", "set_", "reset_", "recover_", "finalize_", "provision_", "disable_", "deploy_", "register_", "revoke_", "rotate_", "restore_"))
                or action in {"apply_migration", "pause_project", "merge_branch", "rebase_branch"}
            ):
                caps.append("database:write")
        if not database_surface and any(x in text for x in ("run_code", "exec", "execute", "terminal", "shell", "command", "vm")):
            caps.extend(("compute:exec", "terminal:exec", "capability:discover_execute"))
        if any(x in text for x in ("remote", "vm", "run_code_in_vm")):
            caps.append("compute:remote_exec")
        if any(x in text for x in ("read_file", "write_file", "edit_file", "apply_patch", "list_files", "storage", "workspace")):
            caps.extend(("workspace:persistent", "capability:discover_execute"))
        if any(x in text for x in ("browser", "tab", "navigate", "screenshot", "page", "web_automation")):
            caps.append("browser:interact")
            # Screenshot/preview/navigation can be a secondary actuator on design or
            # app-builder bodies.  Only bodies whose observed role/provider is actually
            # a web/browser surface may inherit public-web search from those actions.
            if generic_web_surface:
                caps.append("search:web_current")
        if any(x in text for x in ("login", "authenticated", "browser_profile", "signed_in", "session_cookie")):
            caps.append("browser:signed_in_observe")
        if any(x in text for x in ("search", "crawl", "scrape", "fetch_content", "extract")) and generic_web_surface:
            caps.append("search:web_current")
        if pid == "github" or any(x in text for x in ("github", "repo", "repository", "commit", "pull_request", "issue")):
            caps.extend(("search:code_ecosystem", "workspace:persistent"))
        if pid == "plugin_management" and any(x in text for x in ("search_plugins", "suggest_plugins", "plugin")):
            caps.append("capability:discover_execute")
        if any(x in text for x in ("subagent", "delegate", "agent", "research")):
            caps.append("cognition:parallel_delegate")
        if any(x in text for x in ("schedule", "queue", "cron", "monitor", "automation")):
            caps.append("automation:continuity")
        if any(x in text for x in ("create_post", "scheduledpost", "publish", "social_post", "story", "carousel_post", "video_post", "image_post")):
            caps.extend(("presence:publish", "presence:manage"))
        if any(x in text for x in ("deploy", "publish", "release")):
            caps.append("deploy:artifact")
        if any(x in text for x in ("generate_image", "image_generation", "text2im", "render_image")):
            caps.extend(("media:image_generate", "multimodal:image_output"))
        if any(x in text for x in ("upload_asset", "create_attachment", "write_file", "save_file", "export")):
            caps.append("state:write_artifact")
        if any(x in text for x in ("voice", "audio", "speech", "live")):
            caps.append("multimodal:state_bridge")
    return tuple(dict.fromkeys(caps))

def _canonical_capabilities(
    spec: Mapping[str, Any],
    *,
    action_names: Iterable[str] = (),
    explicit_tags: Iterable[str] = (),
    authenticated_session_observed: bool = False,
) -> tuple[str, ...]:
    cid = _key(str(spec.get("id") or ""))
    role = _key(str(spec.get("role") or ""))
    tags = {_key(str(x)) for x in spec.get("tags") or ()}
    raw_tags = {_key(str(x)) for x in explicit_tags or ()}
    text = " ".join((cid, role, *sorted(tags)))
    caps: list[str] = []

    if role in {"search", "academic_search"} or any(x in text for x in ("search", "retrieval", "research", "crawl")):
        # A generic search/retrieval body proves general web reach, not reach into
        # every source ecology. Granting community/social/creator/multilingual from
        # the mere substring "search" let a code-repository body be selected as the
        # executor for an Instagram query. Those families now need their own evidence.
        # The GPT lineage moved social_recommendation behind observed authentication
        # for the same reason; this gates all four rather than one.
        caps.extend(("search:first_party", "search:web_current", "search:research"))
        caps.extend(_evidenced_source_families(text))
    if cid == "github" or role == "code_repository" or "repository" in text:
        caps.extend(("search:code_ecosystem", "capability:discover_execute"))
    if role == "knowledge_base" or cid in {"notion", "google_drive"}:
        caps.append("search:personal_knowledge")
    if role == "browser" or "browser" in text or cid in {"tinyfish", "opera_browser_connector"}:
        # A browser can in principle reach any public surface, so it keeps the
        # broad source families. Egress reachability is still proven by the receipt,
        # never by this derivation.
        caps.extend((
            "browser:interact", "search:web_current", "search:community",
            "search:creator_graph", "search:multilingual",
        ))
        # Observed authentication, not a substring. A tag saying "authenticated_session"
        # is a claim; `*_observed` is evidence. Merged from the GPT lineage, which got
        # this stricter than the substring check that was here.
        # A caller may supply explicit session-truth fields from BrowserSessionTruthLedger.
        # Legacy/host-native surfaces can also encode the same observation as an
        # authenticated_session tag, but that tag only becomes evidence when the
        # surface itself reports a completed successful execution. A merely callable
        # browser carrying the tag is still just a claim.
        state_key = _key(str(spec.get("state") or ""))
        explicit_observed_tag = bool(
            raw_tags.intersection({"authenticated_session", "signed_in_session", "authenticated_session_observed", "signed_in_observed"})
            and state_key in {"executed_successfully", "successful", "proven", "observed_success"}
        )
        authenticated_observed = bool(authenticated_session_observed or explicit_observed_tag)
        if authenticated_observed:
            caps.extend(("browser:signed_in_observe", "search:social_recommendation"))
    if cid == "host_model" or cid == "cognition:exploration_generate" or role == "semantic_generator" or "exploration" in text:
        # The connected generator is not always literally named "host_model". A body
        # that declares itself as the semantic generator binds the exploration family too,
        # otherwise a declared generator sits callable but unroutable.
        caps.append("cognition:exploration_generate")
    if cid == "host_model":
        caps.extend(("design:reference_deconstruct", "multimodal:intent_compile"))
    if role == "image_generation" or cid in {"image_gen", "native.image_generation"}:
        caps.extend(("media:image_generate", "multimodal:image_output"))
    if role == "agent_delegate" or "agent_delegate" in text or cid == "manus":
        caps.append("cognition:parallel_delegate")
    if role == "compute" or any(x in text for x in ("code_execution", "terminal", "filesystem", "vm")):
        caps.append("compute:exec")
    if cid == "plugin_management" or "plugin" in text:
        caps.append("capability:discover_execute")
    if authenticated_session_observed and any(
        x in _key(" ".join(action_names)) for x in ("recommendation", "feed", "timeline", "home_feed")
    ):
        caps.append("search:social_recommendation")
    # Receipt-backed or host-authored surfaces may carry already-canonical semantic
    # capability ids. Preserve them verbatim instead of forcing the observation back
    # through provider-name heuristics on the next turn. This is especially important
    # for durable remote execution bodies recovered from prior successful receipts.
    explicit_semantic = spec.get("semantic_capabilities") or spec.get("canonical_capabilities") or ()
    if isinstance(explicit_semantic, str):
        explicit_semantic = (explicit_semantic,)
    if isinstance(explicit_semantic, (list, tuple)):
        caps.extend(str(x).strip() for x in explicit_semantic if isinstance(x, str) and str(x).strip())
    if "automation" in text:
        caps.append("automation:continuity")
    # An explicitly declared capability id is honored verbatim.
    #
    # This used to be namespaced away: a surface declaring `search:personal_knowledge`
    # produced only `host:search:personal_knowledge`, which no route for
    # `search:personal_knowledge` could match. The declaration therefore only worked
    # by accident, for ids that also happened to hit one of the keyword rules above
    # (`compute:exec` did; `schedule:read`, `state:write_artifact` and
    # `transform:dedupe_and_regenerate` did not). Saying "I can do X" must register X.
    if cid and ":" in cid:
        caps.append(cid)
    # The observed callable itself remains addressable for future task-shaped routes.
    if cid:
        caps.append(f"host:{cid}")
        caps.extend(_action_derived_capabilities(cid, action_names, role=role))
    return tuple(dict.fromkeys(caps))


def _families(spec: Mapping[str, Any], capabilities: Iterable[str]) -> tuple[str, ...]:
    role = str(spec.get("role") or "").strip()
    families = [role] if role else []
    for cap in capabilities:
        if ":" in cap:
            families.append(cap.split(":", 1)[0])
    return tuple(dict.fromkeys(x for x in families if x))


def sync_host_surface(
    root: str | Path,
    capabilities: Iterable[Mapping[str, Any]],
    *,
    metadata: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Materialize *observed callable* HOST capabilities into the body registry.

    This is deliberately one-way evidence plumbing: a row must already be on the
    executable surface before it can become a callable body.  The synchronizer does
    not discover, install, connect, or execute providers and therefore cannot promote
    catalog visibility into execution truth.
    """
    registry = BodyFederationRegistry(Path(root) / "canonical_host_bridge" / "bodies.json")
    meta = dict(metadata or {})
    now = time.time()
    observed_at = float(meta.get("observed_at") or now)
    if observed_at > now + 60.0:
        observed_at = now
    snapshot_material = {
        "format": meta.get("format", "structured_surface_v1"),
        "surface_complete": bool(meta.get("surface_complete", False)),
        "capability_ids": sorted(str(x.get("id") or x.get("capability_id") or x.get("name") or "") for x in capabilities),
    }
    snapshot_id = "surface_" + hashlib.sha256(
        json.dumps(snapshot_material, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:20]

    rows = []
    callable_rows = []
    noncallable_rows = []
    for raw in capabilities:
        spec = normalize_capability(dict(raw))
        cid = str(spec["id"])
        key = _key(cid)
        executor = str(raw.get("executor") or raw.get("provider") or _EXECUTOR_NAMES.get(key) or cid)
        action_names = _iter_action_names(raw, spec)
        authenticated_observed = bool(
            raw.get("authenticated_session_observed") is True
            or raw.get("signed_in_session_observed") is True
        )
        canonical_caps = _canonical_capabilities(
            spec,
            action_names=action_names,
            explicit_tags=raw.get("tags") or (),
            authenticated_session_observed=authenticated_observed,
        )
        evidence_strength = float(raw.get("evidence_strength", 0.85))
        evidence_strength = max(0.0, min(1.0, evidence_strength))
        origin_ref = str(raw.get("origin_ref") or meta.get("origin_ref") or f"host_surface:{snapshot_id}")
        is_callable = capability_is_callable(spec)
        observed_state = str(spec.get("state") or ("callable" if is_callable else "unavailable")).strip()
        body = registry.upsert(
            f"host_surface:{key}",
            executor=executor,
            families=_families(spec, canonical_caps),
            capabilities=canonical_caps,
            state=("callable" if is_callable else observed_state),
            zero_incremental_cost=_truthy_zero_cost(raw),
            evidence_strength=evidence_strength,
            origin_ref=origin_ref,
            evidence={
                "surface_snapshot_id": snapshot_id,
                "manifest": spec,
                "surface_complete": bool(meta.get("surface_complete", False)),
                "execution_not_implied_by_sync": True,
                "callable_observed": bool(is_callable),
                "action_ids": action_names,
                "opaque_host_actions_preserved": True,
                "browser_session_observation": dict(raw.get("browser_session_observation") or {}),
                "authenticated_session_observed": authenticated_observed,
            },
            observed_at=observed_at,
        )
        rows.append(body)
        (callable_rows if is_callable else noncallable_rows).append(body)

    return {
        "surface_snapshot_id": snapshot_id,
        "observed_surface_count": len(rows),
        "observed_callable_count": len(callable_rows),
        "observed_noncallable_count": len(noncallable_rows),
        "materialized_body_ids": tuple(x.body_id for x in rows),
        "callable_body_ids": tuple(x.body_id for x in callable_rows),
        "noncallable_body_ids": tuple(x.body_id for x in noncallable_rows),
        "executors": tuple(x.executor for x in callable_rows),
        "surface_complete": bool(meta.get("surface_complete", False)),
        "execution_claimed": False,
        "bodies": tuple(asdict(x) for x in rows),
    }


def probe_local_runtime_capability(root: str | Path) -> dict[str, Any] | None:
    """Prove the Python process hosting Jigaewol is itself a real execution body.

    This is not a ChatGPT product-tool claim. If this code is running, a successful
    subprocess + filesystem roundtrip is direct evidence that the runtime owns a local
    execution body even when no external host-surface manifest was injected. Network,
    browser login, and remote-computer traits are intentionally not inferred.
    """
    base = Path(root) / "host_surface" / "local_probe"
    base.mkdir(parents=True, exist_ok=True)
    probe_file = base / "roundtrip.txt"
    failure_path = base / "probe_failures.jsonl"
    token = "jigaewol-local-runtime-probe"

    def record_failure(kind: str, *, error: BaseException | None = None, details: Mapping[str, Any] | None = None) -> None:
        row = {
            "kind": str(kind),
            "error_type": type(error).__name__ if error is not None else "",
            "error": str(error) if error is not None else "",
            "details": dict(details or {}),
            "created_at": time.time(),
        }
        with failure_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")

    try:
        probe_file.write_text(token, encoding="utf-8")
        read_back = probe_file.read_text(encoding="utf-8")
        proc = subprocess.run(
            [sys.executable, "-c", "print('JIGAEWOL_LOCAL_EXEC_OK')"],
            cwd=base, text=True, capture_output=True, timeout=5.0,
        )
    except Exception as exc:
        record_failure("local_runtime_probe_exception", error=exc)
        return None
    if read_back != token or proc.returncode != 0 or "JIGAEWOL_LOCAL_EXEC_OK" not in proc.stdout:
        record_failure(
            "local_runtime_probe_mismatch",
            details={
                "roundtrip_ok": read_back == token,
                "returncode": int(proc.returncode),
                "stdout_has_marker": "JIGAEWOL_LOCAL_EXEC_OK" in proc.stdout,
                "stderr": str(proc.stderr or ""),
            },
        )
        return None
    return {
        "id": "jigaewol_local_runtime",
        "role": "compute",
        "provider": "JigaewolLocalRuntime",
        "executor": "jigaewol_local_runtime",
        "state": "callable",
        "traits": ["code_execution", "terminal", "filesystem", "persistent_workspace"],
        "actions": ["run_code", "terminal_exec", "read_file", "write_file"],
        "description": "Self-probed local Python subprocess and persistent runtime-state filesystem body",
        "evidence_strength": 0.98,
        "origin_ref": "local_runtime:self_probe",
        "zero_incremental_cost": None,
        "probe": {
            "subprocess_exit_code": proc.returncode,
            "stdout": proc.stdout.strip(),
            "filesystem_roundtrip": True,
            "network_isolation_proven": False,
            "remote_computer_proven": False,
        },
    }
