from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Iterable

from .requirement_contract import RequirementCompiler


class DirectiveInvariantError(RuntimeError):
    """Raised when canonical user-directive invariants are violated at runtime."""


def sha256_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class DirectiveSnapshot:
    exact_text: str
    destination_sha256: str
    original_active_atom_ids: frozenset[str]
    requirement_contract_sha256: str


def recompute_from_raw(raw_user_text: str) -> DirectiveSnapshot:
    exact = str(raw_user_text)
    contract = RequirementCompiler.compile(exact)
    return DirectiveSnapshot(
        exact_text=exact,
        destination_sha256=sha256_text(exact),
        original_active_atom_ids=frozenset(atom.atom_id for atom in contract.atoms),
        requirement_contract_sha256=contract.contract_sha256,
    )


def verify_destination(*, raw_user_text: str, original_user_directive_sha256: str) -> str:
    current_destination_sha256 = sha256_text(raw_user_text)
    expected = str(original_user_directive_sha256 or "").strip().lower()
    if not expected:
        raise DirectiveInvariantError("original_user_directive_sha256_missing")
    if current_destination_sha256 != expected:
        raise DirectiveInvariantError(
            "destination_sha256_changed:"
            f"expected={expected}:actual={current_destination_sha256}"
        )
    return current_destination_sha256


def verify_atom_conservation(
    *,
    raw_user_text: str,
    active_atom_ids: Iterable[str] = (),
    explicitly_deferred_atom_ids: Iterable[str] = (),
    explicitly_superseded_by_user_atom_ids: Iterable[str] = (),
) -> frozenset[str]:
    original = recompute_from_raw(raw_user_text).original_active_atom_ids
    active = frozenset(str(x) for x in active_atom_ids if str(x))
    deferred = frozenset(str(x) for x in explicitly_deferred_atom_ids if str(x))
    superseded = frozenset(str(x) for x in explicitly_superseded_by_user_atom_ids if str(x))
    represented = active | deferred | superseded
    missing = original - represented
    if missing:
        raise DirectiveInvariantError(
            "directive_atoms_lost:" + ",".join(sorted(missing))
        )
    return original
