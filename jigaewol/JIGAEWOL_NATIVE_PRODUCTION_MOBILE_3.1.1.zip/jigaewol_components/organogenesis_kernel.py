from __future__ import annotations

"""Astra organogenesis kernel: co-birth of the full Ω invention bundle."""

from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Any, Mapping
import json, time, hashlib

from .blueprint_fidelity import BlueprintFidelityLedger
from .literal_blueprint import load_literal_blueprint, default_blueprint_path
from .capsule_runtime import CapsuleRuntime
from .contradiction_cells import ContradictionCell
from .cyclic_synthesizer import CyclicSynthesizer
from .experience_factory import ExperienceFactory, HiddenWorld
from .generator_evolution import GeneratorEvolution, GeneratorGenome
from .mandate_anchor import UserMandate, competing_goal_views, outcome_contract, ResearchFrontier
from .organ_extractor import OrganExtractor
from .receiver_synthesizer import ReceiverSynthesizer
from .translation_residuals import TranslationResidualMiner
from .representation_execution_arena import RepresentationExecutionArena
from .history_reconstructor import HistoryReconstructor
from .organ_body_builder import OrganBodyBuilder
from .organ_ir import ProblemType, TranslatorDef, ReceiverDef, IntentSensorDef, GeneratorDef, OrganGenome


@dataclass(frozen=True, slots=True)
class OrganExperiment:
    world_rule: str
    synthesis: dict[str, Any]
    holdout_accuracy: float
    generated_operation_names: tuple[str, ...]
    generated_observation_channels: tuple[str, ...]
    portable_interpreter_sha256: str
    capsule_sha256: str
    capsule_path: str
    receiver: dict[str, Any]
    contradiction_probe: dict[str, Any]
    translation_residual_probe: dict[str, Any]


@dataclass(frozen=True, slots=True)
class BootstrapExperiment:
    world_id: str
    oracle_manifest: dict[str, Any]
    oracle_withheld_from_synthesizer: bool
    synthesis: dict[str, Any]
    holdout_accuracy: float
    omega_bundle: dict[str, Any]
    capsule_sha256: str
    capsule_path: str
    receiver: dict[str, Any]
    contradiction_probe: dict[str, Any]
    translation_residual_probe: dict[str, Any]


@dataclass(frozen=True, slots=True)
class OrganogenesisRun:
    schema: str
    run_id: str
    mandate: dict[str, Any]
    root_blueprint: dict[str, Any]
    goal_views: tuple[dict[str, Any], ...]
    outcome_contract: dict[str, Any]
    semantic_context: dict[str, Any]
    omega_bundle: dict[str, Any]
    bootstrap_experiment: dict[str, Any]
    experiments: tuple[dict[str, Any], ...]  # regression fixtures; not the definition of the architecture
    holdout_accuracy: float
    generated_operation_names: tuple[str, ...]
    generated_observation_channels: tuple[str, ...]
    extracted_meta_organ: dict[str, Any] | None
    generator_before: dict[str, Any]
    generator_after: dict[str, Any]
    capsule_sha256: str
    capsule_path: str
    omega_capsule_sha256: str
    omega_capsule_path: str
    materialized_body: dict[str, Any]
    history_reconstruction: dict[str, Any]
    literal_blueprint: dict[str, Any]
    fidelity_ledger: dict[str, Any]
    unresolved_frontier: tuple[str, ...]
    created_at: float

    @property
    def goal_view(self) -> dict[str, Any]:
        return self.goal_views[0] if self.goal_views else {}

    def as_mapping(self) -> dict[str, Any]:
        row = asdict(self); row["goal_view"] = self.goal_view; return row


class OrganogenesisKernel:
    SCHEMA = "jigaewol_organogenesis_run_v4"

    # These clause sets come from the fidelity ledger so this kernel does not
    # silently reclassify implementation requirements as research frontier.
    IMPLEMENTATION_REQUIREMENT_IDS = (
        "04_extended_world_operations",
        "08_experience_control_paths",
        "07_host_nonstandard_connections",
        "09_enhanced_receiver",
        "10_enhanced_capsule",
        "11_generator_evolution_candidates",
    )
    TRUE_FRONTIER_IDS = (
        "frontier_reverse_causation",
        "frontier_stateless_memory",
        "frontier_literal_physical_contradiction",
        "frontier_new_sense",
        "frontier_local_physical_law",
    )

    @staticmethod
    def _ledger_effects(clause_ids: tuple[str, ...]) -> tuple[str, ...]:
        by_id = {cid: effect for cid, effect, _anchors in BlueprintFidelityLedger.CLAUSES}
        missing = tuple(cid for cid in clause_ids if cid not in by_id)
        if missing:
            raise RuntimeError(f"blueprint fidelity clause missing: {missing!r}")
        return tuple(by_id[cid] for cid in clause_ids)

    def __init__(self, state_root: str | Path) -> None:
        self.state_root = Path(state_root); self.state_root.mkdir(parents=True, exist_ok=True)

    @property
    def _generator_state_path(self) -> Path:
        return self.state_root / "generator_state.json"

    def _load_generator(self) -> GeneratorGenome:
        if not self._generator_state_path.is_file():
            return GeneratorGenome()
        try:
            row = json.loads(self._generator_state_path.read_text(encoding="utf-8"))
            fields = GeneratorGenome.__dataclass_fields__
            return GeneratorGenome(**{k: row[k] for k in fields if k in row})
        except Exception:
            return GeneratorGenome()

    def _save_generator(self, genome: GeneratorGenome) -> None:
        self._generator_state_path.write_text(json.dumps(genome.as_mapping(), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")

    @classmethod
    def _contract(cls, mandate: UserMandate):
        # The software/execution requirements from the original design remain
        # required effects. They are not silently demoted into ResearchFrontier.
        implementation_requirements = cls._ledger_effects(cls.IMPLEMENTATION_REQUIREMENT_IDS)
        return outcome_contract(mandate, (
            "preserve the exact user mandate bytes and message sequence as source truth",
            "co-synthesize the full Ω bundle: problem datatype, language, interpreter, program, translator, receiver, generator, and intent sensor",
            "let a representational collision birth a new distinction or datatype rather than merely reject a candidate",
            "let missing syntax or operation semantics flow backward into language/interpreter birth",
            "retain contradictory evidence and use it as material for new observations",
            "treat translation loss as evidence for a new mediator organ",
            "generate executable experiences around obstruction and extract reusable organs",
            "co-synthesize a receiver when an ordinary surface flattens required distinctions",
            "carry language, semantics, interpreter, program, translation, receiver, continuity, and generator state inside the capsule",
            "let repeated failure alter how the next generator invents candidates",
            *implementation_requirements,
            "preserve unresolved original requirements instead of silently rewriting them as smaller software analogues",
        ), forbidden_substitutions=(
            "rename a fixed answer template as invention",
            "replace the Ω bundle with a wrapper around a preselected external solver",
            "claim execution when only metadata/prose exists",
            "claim an unresolved physical/causal requirement was achieved by a software simulation",
            "reclassify an implementation requirement from the original blueprint as a research frontier merely because it is difficult, unavailable, or not yet materialized",
        ))

    @classmethod
    def _frontier(cls) -> ResearchFrontier:
        # Only the five capabilities that the original design itself leaves as
        # genuinely unrealized physical/causal frontiers belong here.
        return ResearchFrontier(list(cls._ledger_effects(cls.TRUE_FRONTIER_IDS)))

    @staticmethod
    def _contradiction_from_cases(cases: tuple[Mapping[str, Any], ...]) -> ContradictionCell:
        cell = ContradictionCell("native visible representation uniquely determines required action")
        by_visible: dict[str, list[Any]] = {}
        for case in cases:
            by_visible.setdefault(repr(case.get("visible_representation")), []).append(case.get("required_action", case.get("required")))
        for visible, actions in by_visible.items():
            uniq = tuple(dict.fromkeys(actions))
            if len(uniq) > 1:
                cell.add(True, condition=f"visible={visible}; branch-A evidence", evidence=uniq[0])
                for action in uniq[1:]: cell.add(False, condition=f"visible={visible}; incompatible branch evidence", evidence=action)
                break
        return cell

    @staticmethod
    def _residual_and_receiver(materialized: Mapping[str, Any], channels: tuple[str, ...]):
        residual_miner = TranslationResidualMiner(); born = tuple(x for x in channels if x != "value")
        rows = tuple(row["representation"] for row in materialized.get("rows", ()))
        residuals = (); mediator = None
        if born:
            probes = tuple((lambda key: (lambda x: x.get(key)))(key) for key in born)
            residuals = residual_miner.inspect(rows, encode=lambda x: x.get("value"), decode=lambda x: {"value": x, **{key: None for key in born}}, probes=probes)
            mediator = residual_miner.propose_mediator(residuals)
        receiver_rows = tuple({**row["representation"], "required": row["required"], "output": row["output"]} for row in materialized.get("rows", ()))
        receiver = ReceiverSynthesizer().synthesize(receiver_rows, required_distinctions=tuple((*channels, "required", "output")))
        return residuals, mediator, receiver

    @staticmethod
    def _decorate_omega(genome: OrganGenome, *, receiver, mediator, goal_views, generator: GeneratorGenome) -> OrganGenome:
        channels = tuple(genome.observer.channels)
        problem_type = ProblemType(
            name="born_problem_type_" + genome.genome_id[-10:], fields=channels,
            invariants=({"kind": "preserve_action_relevant_distinctions"}, {"kind": "collision_must_not_be_silently_flattened"}),
            born_from="representation_collision_and_user_mandate",
        )
        translator = TranslatorDef(
            input_encoder={"kind": "lift", "source": "host_state_and_observation_path", "target": problem_type.name},
            output_decoder={"kind": "project", "source": problem_type.name, "target": "requested_effect_surface"},
            residual_probe={"kind": "roundtrip_behavioral_probe", "compare": "action_relevant_distinctions"},
            mediator=(asdict(mediator) if mediator is not None else {"kind": "birth_request", "reason": "no residual mediator was required by this witness set"}),
        )
        receiver_def = ReceiverDef(tuple(receiver.channels), tuple(receiver.manipulators), receiver.interaction_model, receiver.executable_spec)
        sensor = IntentSensorDef(
            channels=tuple({"source_kind": v.source_kind, "priority": v.priority, "interpretation_id": v.interpretation_id} for v in goal_views),
            competing_views=tuple(asdict(v) for v in goal_views),
            selection_rule="preserve source bytes; allow competing semantic views to drive invention without deleting the literal view",
        )
        generator_def = GeneratorDef(generator.as_mapping())
        return genome.evolve(problem_type=problem_type, translator=translator, receiver=receiver_def, intent_sensor=sensor, generator=generator_def)

    def _bootstrap(self, mandate: UserMandate, goal_views, generator: GeneratorGenome, frontier: ResearchFrontier, fidelity_seed: Mapping[str, Any]) -> tuple[BootstrapExperiment, OrganGenome, list[dict[str, Any]]]:
        factory = ExperienceFactory(); hidden: HiddenWorld = factory.birth_hidden_world(mandate.raw_bytes)
        train_rows = tuple(x.as_mapping() for x in hidden.train); holdout_rows = tuple(x.as_mapping() for x in hidden.holdout)
        synth = CyclicSynthesizer(generator).synthesize(train_rows, max_rounds=max(14, generator.expression_depth * 4))
        materialized = RepresentationExecutionArena.run_materialized_representation(synth.genome, holdout_rows)
        holdout_accuracy = materialized["success_count"] / max(1, materialized["case_count"])
        channels = tuple(ch.name for ch in synth.genome.observer.channels)
        residuals, mediator, receiver = self._residual_and_receiver(materialized, channels)
        cell = self._contradiction_from_cases(train_rows)
        omega_genome = self._decorate_omega(synth.genome, receiver=receiver, mediator=mediator, goal_views=goal_views, generator=generator)

        capsule_runtime = CapsuleRuntime()
        capsule = capsule_runtime.build(
            omega_genome, user_goal_reference=mandate.sha256,
            unresolved_dependencies=frontier.unresolved,
            previous_capability_routes=("canonical ingress", "EphemeralUniverseEngine", "RepresentationExecutionArena", "CanonicalHostBridge"),
            fidelity_ledger=fidelity_seed,
        )
        capsule_path = capsule_runtime.write(capsule, self.state_root / "capsules" / f"bootstrap_{mandate.sha256[:12]}.json")
        portable_ok = sum(int(capsule_runtime.execute(capsule, state=case.state, history=list(case.history)).get("output") == case.required_action) for case in hidden.holdout)
        portable_accuracy = portable_ok / max(1, len(hidden.holdout))
        if portable_accuracy != holdout_accuracy:
            raise RuntimeError(f"portable interpreter drift: arena={holdout_accuracy} portable={portable_accuracy}")
        experiment = BootstrapExperiment(
            hidden.world_id, hidden.oracle_manifest, True, synth.as_mapping(), holdout_accuracy,
            capsule.manifest["omega_bundle"], capsule.sha256, str(capsule_path), receiver.as_mapping(), cell.as_mapping(),
            {"residual_count": len(residuals), "mediator": (asdict(mediator) if mediator else None)},
        )
        failures = [{"kind": r.failure_kind, "mutation": r.mutation, "world_rule": hidden.world_id} for r in synth.rounds if r.failure_kind != "none"]
        return experiment, omega_genome, failures

    def _regression_experiment(self, rule: str, mandate: UserMandate, frontier: ResearchFrontier, generator: GeneratorGenome) -> tuple[OrganExperiment, tuple[dict[str, Any], ...]]:
        factory = ExperienceFactory(); train, holdout = factory.split(rule)
        synth = CyclicSynthesizer(generator).synthesize([x.as_mapping() for x in train])
        materialized = RepresentationExecutionArena.run_materialized_representation(synth.genome, [x.as_mapping() for x in holdout])
        holdout_accuracy = materialized["success_count"] / max(1, materialized["case_count"]); channels = tuple(ch.name for ch in synth.genome.observer.channels)
        cell = self._contradiction_from_cases(tuple(x.as_mapping() for x in train))
        residuals, mediator, receiver = self._residual_and_receiver(materialized, channels)
        cap_rt = CapsuleRuntime(); capsule = cap_rt.build(synth.genome, user_goal_reference=mandate.sha256, unresolved_dependencies=frontier.unresolved, previous_capability_routes=("R19 regression route",))
        capsule_path = cap_rt.write(capsule, self.state_root / "regression_capsules" / f"{rule}_{mandate.sha256[:12]}.json")
        portable_ok = sum(int(cap_rt.execute(capsule, state=case.state, history=list(case.history)).get("output") == case.required_action) for case in holdout)
        portable_accuracy = portable_ok / max(1, len(holdout))
        if portable_accuracy != holdout_accuracy: raise RuntimeError(f"portable interpreter drift for {rule}: arena={holdout_accuracy} portable={portable_accuracy}")
        experiment = OrganExperiment(rule, synth.as_mapping(), holdout_accuracy, tuple(op.name for op in synth.genome.operations), channels, str(capsule.manifest["execution"]["materialized_interpreter"]["sha256"]), capsule.sha256, str(capsule_path), receiver.as_mapping(), cell.as_mapping(), {"residual_count": len(residuals), "mediator": (asdict(mediator) if mediator else None)})
        failures = tuple({"kind": r.failure_kind, "mutation": r.mutation, "world_rule": rule} for r in synth.rounds if r.failure_kind != "none")
        return experiment, failures

    def run(self, directive: str | bytes, *, sequence: int = 0, semantic_objective: str | None = None, lineage: tuple[str, ...] = (), root_mandate: str | bytes | None = None, root_mandate_ref: str = "") -> OrganogenesisRun:
        raw = directive if isinstance(directive, bytes) else str(directive).encode("utf-8")
        literal_blueprint = load_literal_blueprint(default_blueprint_path())
        mandate = UserMandate(raw, sequence); goal_views = competing_goal_views(mandate, semantic_objective); contract = self._contract(mandate); frontier = self._frontier()
        root_raw = (root_mandate if isinstance(root_mandate, bytes) else (str(root_mandate).encode("utf-8") if root_mandate is not None else b""))
        root_sha = hashlib.sha256(root_raw).hexdigest() if root_raw else ""
        root_blueprint = {"present": bool(root_raw), "sha256": root_sha, "byte_count": len(root_raw), "reference": str(root_mandate_ref or ""), "is_separate_from_current_turn_mandate": True, "matches_packaged_literal_blueprint": bool(root_raw) and root_sha == literal_blueprint.sha256, "literal_blueprint_sha256": literal_blueprint.sha256, "source_bytes_are_authority": True}
        # A derived semantic objective is context only. It may widen search but cannot
        # become the operative destination of the organogenesis run.
        effective_objective = mandate.text
        semantic_context = {
            "effective_objective": effective_objective,
            "effective_objective_sha256": hashlib.sha256(effective_objective.encode("utf-8")).hexdigest(),
            "literal_message_is_effective_objective": True,
            "derived_semantic_objective": str(semantic_objective or ""),
            "derived_semantic_objective_is_advisory": True,
            "lineage": tuple(str(x) for x in lineage if str(x)),
            "goal_view_count": len(goal_views),
            "root_mandate_sha256": root_blueprint["sha256"],
            "root_mandate_byte_count": root_blueprint["byte_count"],
            "root_mandate_ref": root_blueprint["reference"],
        }

        gen0 = self._load_generator()
        pre_ledger = BlueprintFidelityLedger().build({"omega_bundle": ("organ_ir.InventionBundle",), "01_cyclic_cobirth": ("CyclicSynthesizer",)})
        bootstrap, omega_genome, failures = self._bootstrap(mandate, goal_views, gen0, frontier, pre_ledger)

        regression: list[OrganExperiment] = []; traces: list[tuple[str, ...]] = []
        for rule in ExperienceFactory().suite():
            experiment, failure_rows = self._regression_experiment(rule, mandate, frontier, gen0)
            regression.append(experiment); failures.extend(failure_rows)
            traces.append(tuple(str(r["mutation"]) for r in experiment.synthesis.get("rounds", ())))
        traces.append(tuple(str(r["mutation"]) for r in bootstrap.synthesis.get("rounds", ())) )

        gen1 = GeneratorEvolution().evolve(gen0, failures)
        self._save_generator(gen1)
        # Generator self-change is part of Ω: rebind the bundle to the evolved generator, not just the report.
        omega_genome = omega_genome.evolve(generator=GeneratorDef(gen1.as_mapping()))
        extracted = OrganExtractor().extract(traces, min_support=2, width=2)
        extracted_mapping = None
        if extracted is not None:
            extracted_mapping = {"operation": {"name": extracted.operation.name, "params": extracted.operation.params, "body": extracted.operation.body, "provenance": extracted.operation.provenance}, "support": extracted.support, "pattern": extracted.pattern}

        evidence = {
            "omega_bundle": (omega_genome.genome_id, bootstrap.capsule_sha256),
            "01_cyclic_cobirth": tuple(str(r["mutation"]) for r in bootstrap.synthesis.get("rounds", ())),
            "02_distinction_birth": tuple(bootstrap.omega_bundle.get("observer", {}).get("channels", ())),
            "03_contradiction_material": (bootstrap.contradiction_probe.get("value", ""),),
            "04_lift_world_project": ("translation.input_encoder=lift", "translation.output_decoder=project"),
            "05_translation_residual_organ": (str(bootstrap.translation_residual_probe.get("mediator")),),
            "06_reverse_history": ("HistoryReconstructor",),
            "07_body_on_demand": ("OrganBodyBuilder", "CanonicalHostBridge.route_organ_effect"),
            "08_experience_birth": (bootstrap.world_id, "OrganExtractor"),
            "09_receiver_cobirth": (bootstrap.receiver.get("receiver_id", "receiver"),),
            "10_law_capsule": (bootstrap.capsule_sha256,),
            "11_generator_self_change": (f"generation:{gen0.generation}->{gen1.generation}", gen1.candidate_scheduler),
            "12_r19_integration": ("runtime_ingress", "EphemeralUniverseEngine", "RepresentationExecutionArena", "CanonicalHostBridge"),
        }
        fidelity = BlueprintFidelityLedger().build(evidence)

        # Rebuild the primary capsule with the final evolved generator and final fidelity ledger.
        cap_rt = CapsuleRuntime(); final_capsule = cap_rt.build(omega_genome, user_goal_reference=mandate.sha256, unresolved_dependencies=frontier.unresolved, previous_capability_routes=("canonical ingress", "EphemeralUniverseEngine", "RepresentationExecutionArena", "CanonicalHostBridge"), fidelity_ledger=fidelity)
        final_capsule_path = cap_rt.write(final_capsule, self.state_root / "capsules" / f"omega_{mandate.sha256[:12]}.json")
        materialized_body = OrganBodyBuilder().materialize(capsule_path=final_capsule_path, output_path=self.state_root / "bodies" / f"omega_{mandate.sha256[:12]}.py").as_mapping()
        history_reconstruction = HistoryReconstructor().reconstruct({"value": 0}, alphabet=("observe", "touch", "listen", "rotate"), max_depth=2).as_mapping()

        holdout_min = min([x.holdout_accuracy for x in regression] or [bootstrap.holdout_accuracy])
        all_ops = tuple(dict.fromkeys([*(op.name for op in omega_genome.operations), *(name for x in regression for name in x.generated_operation_names)]))
        all_channels = tuple(dict.fromkeys([*(ch.name for ch in omega_genome.observer.channels), *(name for x in regression for name in x.generated_observation_channels)]))
        run_id = "organogenesis_" + mandate.sha256[:20]
        legacy_primary = next((x for x in regression if x.world_rule == "touch_residue_3"), regression[0] if regression else None)
        legacy_sha = legacy_primary.capsule_sha256 if legacy_primary is not None else final_capsule.sha256
        legacy_path = legacy_primary.capsule_path if legacy_primary is not None else str(final_capsule_path)
        run = OrganogenesisRun(
            self.SCHEMA, run_id, mandate.as_mapping(), root_blueprint, tuple(asdict(x) for x in goal_views), asdict(contract), semantic_context,
            final_capsule.manifest["omega_bundle"], asdict(bootstrap), tuple(asdict(x) for x in regression), holdout_min,
            all_ops, all_channels, extracted_mapping, gen0.as_mapping(), gen1.as_mapping(), legacy_sha, legacy_path,
            final_capsule.sha256, str(final_capsule_path), materialized_body, history_reconstruction, literal_blueprint.as_mapping(), fidelity, tuple(frontier.unresolved), time.time(),
        )
        report_path = self.state_root / f"{run_id}.json"; report_path.write_text(json.dumps(run.as_mapping(), ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        return run
