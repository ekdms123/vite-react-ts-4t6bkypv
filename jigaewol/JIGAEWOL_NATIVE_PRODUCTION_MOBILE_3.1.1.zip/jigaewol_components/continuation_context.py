from __future__ import annotations

"""Cross-turn continuity resolved from clause graphs.

Compatibility helpers in this module no longer maintain an independent phrase/regex
classifier.  SourceDirectiveCompiler is the single source of continuity interpretation;
ContinuityLinker turns that interpretation into explicit cross-turn graph edges.
"""

import hashlib
import json
import re
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .continuity_linker import ContinuityLinker
from .source_directive_compiler import SourceDirectiveCompiler, continuity_signal


def continuation_mode(message: str) -> str:
    return continuity_signal(str(message or "")).mode


def persistence_continuation_present(message: str) -> bool:
    return continuation_mode(message) == "referential_extension"


def is_bare_continuation(message: str) -> bool:
    return continuation_mode(message) == "bare"


def compose_authoritative_continuation_objective(prior_objective: str, current_message: str, *, mode: str) -> str:
    """Resolve current semantic objective while keeping prior work out-of-band.

    A truly bare continuation carries no standalone objective and therefore resolves to
    the active prior objective.  A substantive follow-up remains the exact current
    source; its relationship to prior work lives in graph edges, never string prefixing.
    """
    prior = str(prior_objective or "").strip()
    current = str(current_message or "").strip()
    if str(mode) == "bare":
        return prior
    if current:
        return current
    return prior


def _tokens(text: str) -> set[str]:
    return {
        token.casefold()
        for token in re.findall(r"[0-9A-Za-z가-힣_]{2,}", str(text))
        if len(token) >= 2
    }


def _candidate_score(*, current_text: str, prior_text: str, active: bool, updated_at: float, bare: bool) -> tuple[float, ...]:
    if bare:
        return (1.0 if active else 0.0, float(updated_at))
    current = _tokens(current_text)
    prior = _tokens(prior_text)
    overlap = len(current & prior) / max(1, len(current | prior)) if current and prior else 0.0
    # Explicit semantic overlap outranks recency; active-task status breaks ties.
    return (overlap, 1.0 if active else 0.0, float(updated_at))


def resolve_continuation_context(root: str | Path, message: str) -> dict[str, Any]:
    """Resolve a current clause graph against durable unfinished task graphs.

    The result keeps the old mapping API for callers, but continuity truth now includes
    the clause graph and authority graph that justify the restoration.  No second
    continuity classifier exists here.
    """
    text = str(message or "")
    signal = continuity_signal(text)
    if signal.mode == "none":
        return {
            "restored": False,
            "reason": "no_continuation_reference",
            "mode": "none",
            "continuity_source_evidence": (),
        }

    path = Path(root) / "continuity" / "turn_continuity.json"
    if not path.is_file():
        return {
            "restored": False,
            "reason": "no_turn_continuity_state",
            "mode": signal.mode,
            "continuity_source_evidence": signal.evidence,
        }
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {
            "restored": False,
            "reason": "invalid_turn_continuity_state",
            "mode": signal.mode,
            "continuity_source_evidence": signal.evidence,
        }

    tasks = data.get("tasks") or {}
    active_id = str(data.get("active_task_id") or "")
    compiler = SourceDirectiveCompiler()
    linker = ContinuityLinker()
    current_graph = compiler.compile(text, turn_id="current")

    ranked: list[tuple[tuple[float, ...], dict[str, Any], Any]] = []
    for tid, raw in tasks.items():
        if not isinstance(raw, dict) or raw.get("status") in {"completed", "abandoned"}:
            continue
        objective = str(raw.get("objective") or "").strip()
        if not objective:
            continue
        prior_graph = compiler.compile(objective, turn_id=str(raw.get("task_id") or tid))
        authority_graph = linker.link(previous=prior_graph, current=current_graph)
        score = _candidate_score(
            current_text=text,
            prior_text=objective,
            active=(str(tid) == active_id or str(raw.get("task_id") or "") == active_id),
            updated_at=float(raw.get("updated_at") or 0.0),
            bare=(signal.mode == "bare"),
        )
        ranked.append((score, raw, authority_graph))

    if not ranked:
        return {
            "restored": False,
            "reason": "no_unfinished_task",
            "mode": signal.mode,
            "continuity_source_evidence": signal.evidence,
            "source_clause_graph": asdict(current_graph),
        }

    ranked.sort(key=lambda row: row[0], reverse=True)
    _, row, authority_graph = ranked[0]
    prior_objective = str(row.get("objective") or "").strip()
    semantic_objective = compose_authoritative_continuation_objective(
        prior_objective, text, mode=signal.mode,
    )
    correction_rebind = any("correction" in str(item) for item in signal.evidence)
    restore_prior = signal.mode == "bare" or correction_rebind
    # A correction reconnects the unfinished work graph but never demotes the exact
    # current correction.  Only a truly bare "continue" borrows the prior objective
    # as the semantic command.
    current_explicit_dominates = signal.mode != "bare"
    return {
        "restored": restore_prior,
        "context_attached": True,
        "current_directive_is_highest_explicit_authority": current_explicit_dominates,
        "prior_unfinished_objective_preserved_as_context_only": not restore_prior,
        "reason": (
            "active_unfinished_task" if signal.mode == "bare"
            else "current_correction_rebinds_unfinished_work" if correction_rebind
            else "referential_prior_context_only"
        ),
        "mode": signal.mode,
        "task_id": str(row.get("task_id") or active_id),
        "objective": semantic_objective,
        "prior_objective": prior_objective,
        "objective_sha256": hashlib.sha256(semantic_objective.encode("utf-8")).hexdigest(),
        "phase": str(row.get("phase") or ""),
        "status": str(row.get("status") or ""),
        "continuity_source_evidence": signal.evidence,
        "source_clause_graph": asdict(current_graph),
        "authority_graph": asdict(authority_graph),
        "continuity_edges": tuple(asdict(edge) for edge in authority_graph.edges),
        "continuity_model": "clause_graph_edges_v1",
    }
