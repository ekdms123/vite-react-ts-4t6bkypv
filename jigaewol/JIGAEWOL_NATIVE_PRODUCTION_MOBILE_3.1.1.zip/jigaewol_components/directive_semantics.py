from __future__ import annotations

import re
from dataclasses import dataclass


_QUOTE_PAIRS = {
    '"': '"', "'": "'", '`': '`', '“': '”', '‘': '’', '「': '」', '『': '』', '《': '》', '〈': '〉',
}
_META_NOUNS = (
    '문구', '문자열', '표현', '단어', '텍스트', '패턴', '키워드', '로직', '코드', '규칙', '트리거', '오탐',
    'phrase', 'string', 'word', 'text', 'pattern', 'keyword', 'logic', 'code', 'rule', 'trigger', 'regex',
)
_META_VERBS = (
    '찾아', '찾기', '분석', '검사', '테스트', '검증', '설명', '뜻', '의미', '감지', '재현', '검색', '확인', '포렌식',
    'find', 'analy', 'inspect', 'test', 'check', 'explain', 'meaning', 'detect', 'repro', 'search', 'forensic',
)
_DIRECTIVE_FORCE = (
    '하지 마', '하지마', '하지 말', '그만해', '중단해', '취소해', '취소해라', '멈춰', '쓰지 마', '사용하지 마',
    'don\'t', 'do not', 'stop ', 'cancel ', 'abort ', 'never ',
)


def _quoted_spans(text: str) -> tuple[tuple[int, int], ...]:
    spans: list[tuple[int, int]] = []
    stack: list[tuple[str, int]] = []
    for i, ch in enumerate(text):
        if stack:
            opener, start = stack[-1]
            if ch == _QUOTE_PAIRS[opener]:
                spans.append((start, i + 1))
                stack.pop()
            continue
        if ch in _QUOTE_PAIRS:
            stack.append((ch, i))
    return tuple(spans)


def _inside(index: int, spans: tuple[tuple[int, int], ...]) -> bool:
    return any(start <= index < end for start, end in spans)


def _clause(text: str, start: int, end: int) -> str:
    left = max(text.rfind('\n', 0, start), text.rfind('.', 0, start), text.rfind('?', 0, start), text.rfind('!', 0, start), text.rfind('。', 0, start), text.rfind('？', 0, start), text.rfind('！', 0, start))
    right_candidates = [x for x in (text.find('\n', end), text.find('.', end), text.find('?', end), text.find('!', end), text.find('。', end), text.find('？', end), text.find('！', end)) if x >= 0]
    right = min(right_candidates) if right_candidates else len(text)
    return text[left + 1:right].strip()


def is_meta_mention(text: str, marker: str, *, index: int | None = None) -> bool:
    """Return True when a marker is being discussed, quoted, tested, or inspected.

    This is intentionally conservative: it suppresses state mutation only when the
    same clause contains both a meta-object noun (word/string/pattern/code/...) and a
    meta inspection verb (find/analyze/test/check/...). A direct imperative in the
    clause overrides the meta classification.
    """
    raw = str(text or '')
    folded = raw.casefold()
    needle = str(marker or '').casefold()
    if not needle:
        return False
    pos = folded.find(needle) if index is None else int(index)
    if pos < 0:
        return False
    if _inside(pos, _quoted_spans(raw)):
        return True
    clause = _clause(raw, pos, pos + len(marker)).casefold()
    has_meta_noun = any(x.casefold() in clause for x in _META_NOUNS)
    has_meta_verb = any(x.casefold() in clause for x in _META_VERBS)
    has_force = any(x.casefold() in clause for x in _DIRECTIVE_FORCE)
    if has_force:
        return False
    return bool(has_meta_noun and has_meta_verb)


def is_reported_or_negated_marker_reference(text: str, marker: str, *, index: int) -> bool:
    """Reject a destructive-looking phrase when the user is only discussing it.

    A literal phrase such as ``이전 요청 취소`` can appear inside a complaint like
    ``이전 요청 취소 같은 문구를 자동으로 적용하지 마``.  Earlier revisions
    treated the embedded phrase as an active cancellation because the surrounding
    imperative (``하지 마``) defeated the meta-mention heuristic.  That inverted
    source authority: a prohibition against inference became the very destructive
    action it prohibited.

    This predicate is deliberately local to the clause containing the marker.  It
    recognizes reported-speech / example / denial constructions only; a standalone
    cancellation clause such as ``이전 요청 취소. 이제 C로 바꿔`` remains active.
    """
    raw = str(text or '')
    clause = _clause(raw, index, index + len(marker)).casefold()
    needle = str(marker or '').casefold()
    rel = clause.find(needle)
    if rel < 0:
        return False
    after = clause[rel + len(needle):]
    before = clause[:rel]

    # Explicit quotation/reporting that is denied, described as an example, or
    # mentioned as a string/phrase never grants lifecycle authority.
    report_markers = ('라고', '라는', '이라는', '같은 문구', '같은 표현', '같은 단어',
                      '문구', '표현', '단어', '문자열', '키워드', '예시', '인용')
    denial_markers = ('적 없', '한 적 없', '말한 적 없', '쓴 적 없', '요청한 적 없',
                      '아니', '아닌', '아니다', '않았', '안 했', 'never said', 'did not say',
                      "didn't say", 'not asking', 'not a request')
    interpretation_verbs = ('해석', '추론', '감지', '오인', '판단', '분류', '적용', '간주',
                            'interpret', 'infer', 'detect', 'classif', 'treat as', 'apply')
    prohibition = ('하지 마', '하지마', '하지 말', '하지말', '말아', '금지', '않도록',
                   'do not', "don't", 'never ')

    if any(x in clause for x in ('예시', '인용')) and any(x in clause for x in report_markers):
        return True
    if any(x in clause for x in denial_markers) and any(x in after or x in before for x in report_markers):
        return True
    if any(x in after for x in report_markers) and any(v in clause for v in interpretation_verbs) and any(n in clause for n in prohibition):
        return True
    # Common compact form: ``<marker> 같은 ... 하지 마``.
    if ('같은' in after or '처럼' in after) and any(v in after for v in interpretation_verbs) and any(n in after for n in prohibition):
        return True
    return False


def actionable_marker_present(text: str, markers: tuple[str, ...] | list[str]) -> bool:
    """True only for an unquoted, source-actionable occurrence of one of *markers*.

    Marker presence is evidence, not authority.  Quoted, metalinguistic, reported,
    denied, or explicitly anti-inference occurrences are ignored so a model/runtime
    cannot turn discussion of a destructive instruction into that instruction.
    """
    raw = str(text or '')
    folded = raw.casefold()
    spans = _quoted_spans(raw)
    for marker in markers:
        needle = str(marker).casefold()
        if not needle:
            continue
        start = 0
        while True:
            pos = folded.find(needle, start)
            if pos < 0:
                break
            if (
                not _inside(pos, spans)
                and not is_meta_mention(raw, str(marker), index=pos)
                and not is_reported_or_negated_marker_reference(raw, str(marker), index=pos)
            ):
                return True
            start = pos + max(1, len(needle))
    return False


def _directly_negated_occurrence(text: str, marker: str, *, index: int) -> bool:
    """Whether this occurrence explicitly forbids/negates the marker action."""
    raw = str(text or '')
    folded = raw.casefold()
    needle = str(marker or '').casefold()
    pos = int(index)
    before = folded[max(0, pos - 48):pos]
    after = folded[pos + len(needle): min(len(folded), pos + len(needle) + 48)]
    if re.match(
        r"\s*(?:은|는|을|를|이|가|도|만|조차)?\s*"
        r"(?:하지\s*마|하지마|하지\s*말|하지말|하지\s*않|하지않|하면\s*안|"
        r"해선\s*안|해서는\s*안|금지|말아|말자|말고|마라|하지\s*마라)",
        after,
    ):
        return True
    if re.search(r"(?:\bdon['’]?t|\bdo\s+not|\bnever|\bnot\s+to|\bwithout)\s*$", before):
        return True
    if re.match(r"\s*(?:is|are|be)?\s*(?:not|forbidden|prohibited)\b", after):
        return True
    return False


def affirmative_actionable_marker_present(text: str, markers: tuple[str, ...] | list[str]) -> bool:
    """Actionable marker detector for destructive source authority.

    Unlike the generic detector used by friction/diagnostic classifiers, this one
    requires the destructive action to be affirmative. Explicitly negated phrases
    therefore remain useful diagnostic signals without becoming deletion authority.
    """
    raw = str(text or '')
    folded = raw.casefold()
    spans = _quoted_spans(raw)
    for marker in markers:
        needle = str(marker).casefold()
        if not needle:
            continue
        start = 0
        while True:
            pos = folded.find(needle, start)
            if pos < 0:
                break
            if (
                not _inside(pos, spans)
                and not is_meta_mention(raw, str(marker), index=pos)
                and not is_reported_or_negated_marker_reference(raw, str(marker), index=pos)
                and not _directly_negated_occurrence(raw, str(marker), index=pos)
            ):
                return True
            start = pos + max(1, len(needle))
    return False
