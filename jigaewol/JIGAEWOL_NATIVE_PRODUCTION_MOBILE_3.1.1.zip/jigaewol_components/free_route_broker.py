"""Durable zero-spending routes. Discovery never counts as execution.

Quota state belongs to a billing pool, so two aliases cannot evade one limit.
The exact goal and its hash survive route changes and process restarts.
"""
from __future__ import annotations
import hashlib,json,sqlite3,time
from pathlib import Path
from jigaewol_components.execution_cost_policy import assert_zero_spend

class FreeRouteBroker:
    def __init__(self, root):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'routes.sqlite3'
        with self.db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS routes(id TEXT, capability TEXT, pool TEXT, body TEXT, PRIMARY KEY(id,capability));
            CREATE TABLE IF NOT EXISTS quotas(pool TEXT PRIMARY KEY, until REAL, body TEXT);
            CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY, goal TEXT, goal_sha TEXT, body TEXT);
            ''')
    def db(self):
        db=sqlite3.connect(self.path,timeout=30);db.execute('PRAGMA journal_mode=WAL');return db
    def register(self, *, route_id, capability, pool, billing_mode, proof_ref, connected=False, quoted_usd=0, observation_ref=None):
        receipt=assert_zero_spend(provider=route_id,quoted_usd=quoted_usd,billing_mode=billing_mode,proof_ref=proof_ref)
        if not isinstance(connected,bool):raise ValueError('connection availability must be boolean')
        if not route_id or not capability or not pool:raise ValueError('route, capability and independent quota pool required')
        if connected and not observation_ref:raise ValueError('connected route needs actual host availability or execution observation')
        row={**receipt,'route_id':str(route_id),'capability':str(capability),'quota_pool':str(pool),
             'connected':bool(connected),'observation_ref':observation_ref,'registered_at':time.time()}
        with self.db() as db:
            prior=db.execute('SELECT pool FROM routes WHERE id=?',(str(route_id),)).fetchone()
            if prior and prior[0]!=str(pool):raise ValueError('all capabilities of one route share its quota pool')
            db.execute('INSERT OR REPLACE INTO routes VALUES (?,?,?,?)',(str(route_id),str(capability),str(pool),json.dumps(row)))
        return row
    def routes(self, capability=None, *, now=None):
        now=time.time() if now is None else float(now)
        with self.db() as db:
            rows=db.execute('SELECT body FROM routes'+(' WHERE capability=?' if capability else '')+' ORDER BY id', (str(capability),) if capability else ()).fetchall()
            quotas={p:until for p,until in db.execute('SELECT pool,until FROM quotas')}
        result=[]
        for (body,) in rows:
            row=json.loads(body);until=quotas.get(row['quota_pool'],0)
            row['cooldown_until']=until;row['available']=row['connected'] and until<=now
            result.append(row)
        return result
    def select(self, *, exact_goal, capability, exclude=(), now=None):
        if not isinstance(exact_goal,str) or not exact_goal:raise ValueError('exact user goal required')
        rows=self.routes(capability,now=now);eligible=[x for x in rows if x['available'] and x['route_id'] not in exclude]
        row={'exact_goal':exact_goal,'goal_sha256':hashlib.sha256(exact_goal.encode()).hexdigest(),
             'capability':capability,'route':eligible[0] if eligible else None,'additional_spend_usd':0,
             'continuation':'execute_observed_free_route' if eligible else 'checkpoint_and_continue_discovery',
             'preserve_goal':True,'paid_fallback':False}
        with self.db() as db:db.execute('INSERT INTO decisions(goal,goal_sha,body) VALUES (?,?,?)',(exact_goal,row['goal_sha256'],json.dumps(row,ensure_ascii=False)))
        return row

    def execute(self, *, exact_goal, capability, executors, arguments, workspace, exclude=()):
        """Choose and actually call connected zero-cost alternatives until one works."""
        attempted=set(exclude);observations=[]
        while True:
            choice=self.select(exact_goal=exact_goal,capability=capability,exclude=attempted)
            route=choice['route']
            if route is None:
                return {'success':False,'state':'awaiting_free_route_discovery',
                        'exact_goal':exact_goal,'goal_preserved':True,'attempts':observations,'additional_spend_usd':0}
            name=route['route_id'];attempted.add(name)
            callback=executors.get(name)
            if callback is None:continue
            try:
                result=callback(arguments,workspace)
                if not isinstance(result,dict):result={'value':result,'success':False}
                if 'success' not in result and 'returncode' in result:
                    result={**result,'success':result['returncode']==0}
            except Exception as exc:
                result={'success':False,'error_type':type(exc).__name__,'error':str(exc)}
            observation={'route_id':name,'result':result,'actual_adapter_call':True,
                         'goal_sha256':choice['goal_sha256'],'observed_at':time.time()}
            observations.append(observation)
            with self.db() as db:
                db.execute('INSERT INTO decisions(goal,goal_sha,body) VALUES (?,?,?)',
                           (exact_goal,choice['goal_sha256'],json.dumps(observation,ensure_ascii=False,default=str)))
            if result.get('success') is True:
                return {**result,'route_used':name,'attempts':observations,'goal_preserved':True,'additional_spend_usd':0}
    def observe_quota(self, *, route_id, status_code, reset_at=None, retry_after_seconds=None, observation_ref):
        if int(status_code) not in {429,402} or not observation_ref:raise ValueError('observed quota response required')
        now=time.time()
        if reset_at is not None:until=float(reset_at)
        elif retry_after_seconds is not None:until=now+float(retry_after_seconds)
        else:raise ValueError('observe the reset time before automatic retry')
        if not now<until<=now+31*86400:raise ValueError('finite future reset within 31 days required')
        with self.db() as db:
            row=db.execute('SELECT pool FROM routes WHERE id=?',(str(route_id),)).fetchone()
            if not row:raise KeyError('unknown free route')
            receipt={'route_id':route_id,'pool':row[0],'status_code':int(status_code),'reset_at':until,'observation_ref':str(observation_ref),'paid_upgrade':False}
            db.execute('INSERT INTO quotas VALUES (?,?,?) ON CONFLICT(pool) DO UPDATE SET until=MAX(until,excluded.until),body=excluded.body',(row[0],until,json.dumps(receipt)))
        return receipt
