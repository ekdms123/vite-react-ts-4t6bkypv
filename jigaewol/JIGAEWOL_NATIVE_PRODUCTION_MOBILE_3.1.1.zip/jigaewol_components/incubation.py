from __future__ import annotations

"""Pre-adversarial incubation for divergent ideas.

A useful idea can be fragile before it has a mechanism, assumptions, or causal links.
Sending every seed directly into adversarial refutation rewards safe, already-articulated
ideas and can erase promising novelty.  This module keeps incubation separate from
judgement: it records a seed, an elaboration, and the mechanism-level structure that
makes the idea mature enough to challenge later.

Incubation is not evidence, verification, or selection.  It is a protected growth
stage before a representation tournament or other adversarial comparison.
"""

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence


def _sha(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def _texts(values: Sequence[str] | str | None) -> tuple[str, ...]:
    if values is None:
        return ()
    if isinstance(values, str):
        values = (values,)
    return tuple(str(value).strip() for value in values if str(value).strip())


@dataclass(frozen=True)
class IncubatedIdea:
    idea_id: str
    frame_id: str
    seed: str
    elaboration: str
    mechanisms: tuple[str, ...]
    assumptions: tuple[str, ...]
    causal_links: tuple[str, ...]
    tensions: tuple[str, ...]
    ready_for_adversarial: bool
    maturity_findings: tuple[str, ...]

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class IncubationEngine:
    """Durable, score-free growth stage for candidate ideas."""

    def __init__(self, root: Path | str | None = None) -> None:
        self.root = Path(root) / "incubation" if root is not None else None
        self._ideas: dict[str, IncubatedIdea] = {}

    def incubate(
        self,
        frame_id: str,
        seed: str,
        elaboration: str,
        *,
        mechanisms: Sequence[str] | str | None = None,
        assumptions: Sequence[str] | str | None = None,
        causal_links: Sequence[str] | str | None = None,
        tensions: Sequence[str] | str | None = None,
    ) -> IncubatedIdea:
        frame = str(frame_id).strip()
        seed_text = str(seed).strip()
        elaborated = str(elaboration).strip()
        if not frame:
            raise ValueError("incubation needs a frame_id")
        if not seed_text:
            raise ValueError("incubation needs a non-empty seed")
        if not elaborated:
            raise ValueError("incubation needs a non-empty elaboration")

        mechanism_rows = _texts(mechanisms)
        assumption_rows = _texts(assumptions)
        causal_rows = _texts(causal_links)
        tension_rows = _texts(tensions)
        findings: list[str] = []
        if elaborated.casefold() == seed_text.casefold():
            findings.append("seed_not_elaborated")
        if not mechanism_rows and not causal_rows:
            findings.append("no_mechanism_or_causal_link")
        ready = not findings
        idea_id = "inc_" + _sha("\n".join((frame, seed_text, elaborated)))[:20]
        idea = IncubatedIdea(
            idea_id=idea_id,
            frame_id=frame,
            seed=seed_text,
            elaboration=elaborated,
            mechanisms=mechanism_rows,
            assumptions=assumption_rows,
            causal_links=causal_rows,
            tensions=tension_rows,
            ready_for_adversarial=ready,
            maturity_findings=tuple(findings),
        )
        self._ideas[idea_id] = idea
        self._persist(idea)
        return idea

    def get(self, idea_id: str) -> IncubatedIdea:
        try:
            return self._ideas[str(idea_id)]
        except KeyError:
            raise KeyError(f"unknown incubated idea: {idea_id}") from None

    def all(self) -> tuple[IncubatedIdea, ...]:
        return tuple(self._ideas.values())

    def _persist(self, idea: IncubatedIdea) -> None:
        if self.root is None:
            return
        self.root.mkdir(parents=True, exist_ok=True)
        target = self.root / f"{idea.idea_id}.json"
        tmp = target.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps(idea.as_mapping(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
        )
        tmp.replace(target)


def load_incubated(root: Path | str, idea_id: str) -> Mapping[str, Any]:
    path = Path(root) / "incubation" / f"{idea_id}.json"
    return json.loads(path.read_text(encoding="utf-8"))


__all__ = ["IncubatedIdea", "IncubationEngine", "load_incubated"]
