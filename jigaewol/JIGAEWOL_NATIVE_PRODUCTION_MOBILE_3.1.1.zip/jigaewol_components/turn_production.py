"""Actual candidate production and learning for each admitted natural-language turn.

The host supplies its existing generator and reviewed local/tool adapters. This
module creates programs, executes them, consumes their artifacts, chooses results,
and carries unresolved work and learned mechanisms into the next generation.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from collections import defaultdict
import sqlite3
import time
from pathlib import Path
from typing import Any

from .candidate_lab import CandidateLab
from .cognitive_os import CognitiveEvolutionMemory
from .observed_evidence import finite_scores
from .reasoning_portfolio import AdaptiveReasoningPortfolio, ExplorationStrategy
from .authority_guard import source_continuation_requested
from .free_route_broker import FreeRouteBroker


# Distant fields and odd askers used to pull the first idea away from the obvious one.
_FAR_FIELDS = ('면역계', '도시 교통', '요리 레시피', '게임 밸런싱', '군사 보급', '재즈 즉흥', '개미 군집',
               '우편 배송', '주식 시장', '연극 리허설', '응급실 분류', '법정 반대신문')
_ODD_ASKERS = ('다섯 살 아이', '외계인 엔지니어', '1950년대 프로그래머', '사기꾼', '게으른 천재', '결과만 보는 투자자')


def _has_final_consonant(word):
    """Korean particles follow the last syllable: 사기꾼이라면 / 천재라면, 요청을 / 메시지를."""
    hangul = [ch for ch in str(word) if '가' <= ch <= '힣']
    return bool(hangul) and (ord(hangul[-1]) - 0xAC00) % 28 != 0


def _divergent_angles(text, family):
    """Task-bound starting points that differ in mechanism, not wording."""
    first = re.split(r'(?<=[.!?。？！])\s+|\n', ' '.join(str(text).split()), maxsplit=1)[0]
    core = first if len(first) <= 40 else first[:40].rsplit(' ', 1)[0] + '…'
    seed = int(hashlib.sha256(str(text).encode('utf-8')).hexdigest(), 16)
    field = _FAR_FIELDS[seed % len(_FAR_FIELDS)]
    asker = _ODD_ASKERS[(seed // 7) % len(_ODD_ASKERS)]
    angles = [
        f"뒤집기: '{core}'{'을' if _has_final_consonant(core) else '를'} 정반대로 하면(안 하거나, 거꾸로 하면) 무엇이 드러나나?",
        f"먼 분야 빌려오기: 이 과제를 {field}의 방식으로 풀면 무엇이 달라지나?",
        f"실패 먼저: 이게 망하는 가장 그럴듯한 3가지를 먼저 적고, 그걸 막도록 거꾸로 설계하면?",
        f"현장 말투: 이걸 실제로 해본 사람들은 커뮤니티에서 뭐라고 욕하고 칭찬하나? (밈·은어로 찾기)",
        f"이상한 질문: {asker}{'이라면' if _has_final_consonant(asker) else '라면'} 이 과제에서 제일 먼저 뭘 물을까?",
    ]
    if family in {'development', 'design', 'general', 'search'}:
        angles.append(f"극단 규모: 10배 크게, 또는 10분의 1로 줄이면 무엇이 깨지고 무엇이 쉬워지나?")
    return angles


def _sha(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()


class TurnProduction:
    def __init__(self, root, *, adapters=None, memory_root=None):
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.memory_root=Path(memory_root or self.root/'memory').resolve()
        self.memory_root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'production.sqlite3'
        self.lab=CandidateLab(self.root/'candidates',adapters=adapters,experience_root=self.memory_root/'experiences')
        self.evolution=CognitiveEvolutionMemory(self.memory_root/'cognitive_evolution')
        self.portfolio=AdaptiveReasoningPortfolio(self.memory_root/'reasoning_portfolio.json')
        self.routes=FreeRouteBroker(self.memory_root/'free_routes')
        self.executors=dict(adapters or {})
        for name in self.executors:
            if name in {'file.read','file.write','process.run','artifact.revise','search:public_sources'}:
                self.routes.register(route_id=name,capability=name,pool='existing_local_sandbox',
                    billing_mode='local_included',proof_ref='bundled_local_adapter',connected=True,
                    observation_ref='supplied_existing_local_adapter')
        with self.db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, body TEXT);
            CREATE TABLE IF NOT EXISTS turns(id TEXT PRIMARY KEY, task_id TEXT, source TEXT);
            CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, task_id TEXT, kind TEXT, body TEXT);
            ''')

    def db(self):
        db=sqlite3.connect(self.path,timeout=30);db.execute('PRAGMA journal_mode=WAL');return db

    def _read(self, task_id):
        with self.db() as db:row=db.execute('SELECT body FROM tasks WHERE id=?',(str(task_id),)).fetchone()
        if not row:raise KeyError(task_id)
        return json.loads(row[0])

    def _save(self, task, event):
        task['updated_at']=time.time()
        with self.db() as db:
            db.execute('INSERT OR REPLACE INTO tasks VALUES (?,?)',(task['task_id'],json.dumps(task,ensure_ascii=False,default=str)))
            db.execute('INSERT INTO events(task_id,kind,body) VALUES (?,?,?)',
                       (task['task_id'],event,json.dumps(task,ensure_ascii=False,default=str)))

    def open_tasks(self):
        with self.db() as db:rows=[json.loads(x[0]) for x in db.execute('SELECT body FROM tasks ORDER BY rowid DESC')]
        return [x for x in rows if x['state']!='completed']

    @staticmethod
    def _family(text):
        # A routing hint only: the exact source remains present in every packet.
        folded=text.casefold()
        for family, terms in (
            ('search',('검색','조사','찾아','research','search')),
            ('development',('코드','구현','개발','고쳐','수정','code','implement','debug')),
            ('design',('디자인','시안','화면','design','layout')),
            ('writing',('소설','글','창작','대사','write','story'))):
            if any(x in folded for x in terms):return family
        return 'general'

    def begin(self, exact_text, turn_id, *, family=None):
        if not isinstance(exact_text,str) or not exact_text:raise ValueError('exact source required')
        with self.db() as db:prior=db.execute('SELECT task_id,source FROM turns WHERE id=?',(str(turn_id),)).fetchone()
        if prior:
            if prior[1]!=exact_text:raise ValueError('turn reused with a different user message')
            return self.packet(prior[0])
        opened=self.open_tasks()
        if source_continuation_requested(exact_text) and opened:
            task=opened[0]
            task['source_history'].append({'turn_id':str(turn_id),'exact_text':exact_text})
            task['current_source']=exact_text
        else:
            task={'task_id':'task_'+_sha([str(turn_id),exact_text])[:24],
                  'original_objective':exact_text,'current_source':exact_text,
                  'family':family or self._family(exact_text),'state':'needs_generation',
                  'source_history':[{'turn_id':str(turn_id),'exact_text':exact_text}],
                  'candidate_ids':[],'assessments':{},'selection':[],
                  'remaining_work':[],'failures':[],'deliveries':[],
                  'created_at':time.time()}
        self._save(task,'user_turn')
        with self.db() as db:db.execute('INSERT INTO turns VALUES (?,?,?)',(str(turn_id),task['task_id'],exact_text))
        return self.packet(task['task_id'])

    def packet(self, task_id):
        task=self._read(task_id)
        observed=self.lab.candidates(task_id)
        proposed=set(task['candidate_ids'])-{x['candidate_id'] for x in observed}
        if task['state']=='open' and task['deliveries']:next_operation='generate_next_probe_or_revision_for_open_task'
        elif proposed:next_operation='execute_candidate_programs'
        elif observed and not task['selection']:next_operation='compare_observed_artifacts'
        elif task['selection']:next_operation='deliver_selected_artifacts_and_continue_open_work'
        else:next_operation='generate_executable_candidates'
        experiences=self.lab.recall(task['family'])
        content_groups=defaultdict(list)
        for candidate in observed:
            content=[]
            for effect in candidate['observed_effects']:
                filename=effect.get('result',{}).get('artifact')
                if filename and Path(filename).is_file():content.append(hashlib.sha256(Path(filename).read_bytes()).hexdigest())
            if content:content_groups[_sha(content)].append(candidate['candidate_id'])
        from .production_sources import select_sources
        return {'schema':'jigaewol_turn_production_v1','task':task,
                'authority':['USER','JIGAEWOL','MODEL'],
                'source_authority':task['current_source'],
                'original_objective':task['original_objective'],
                'next_operation':next_operation,'observed_candidates':observed,
                'candidate_experiences':experiences,
                'relevant_mechanisms':self.evolution.relevant_recipes(task['current_source']),
                'reasoning_portfolio':self.portfolio.prompt_bundle(task['current_source']),
                'divergent_angles':_divergent_angles(task['current_source'],task['family']),
                'source_recommendations':select_sources(task['current_source'],task['family']),
                'actual_artifact_content_groups':dict(content_groups),
                'convergent_output_candidate_ids':[ids for ids in content_groups.values() if len(ids)>1],
                'generation_request':{
                    'use_current_host_model':True,'model_api_required':False,
                    'produce_actual_operator_programs':True,
                    'creative_mechanisms':['change_representation','remove_assumptions','minimal_surprise','cross_domain_transfer'],
                    'invented_mechanisms_allowed':True,
                    'result_target':'goal-faithful useful artifacts with substantively different mechanisms',
                    'candidate_count_policy':'select for this task; useful results can be used immediately',
                    'revision_target':'improve the artifact using the observed comparison, then execute the revision'},
                'additional_spend_usd':0}

    def submit(self, task_id, candidates):
        task=self._read(task_id)
        for source in candidates:
            row=dict(source)
            material=self.lab.propose(goal_ref=task_id,
                lane_id=row.get('mechanism_id') or row.get('lane_id') or 'invented',
                representation=row['representation'],operator_program=row['operator_program'],
                assumptions=row.get('assumptions',()),ancestry=row.get('ancestry',()),
                reusable_conditions=row.get('reusable_conditions',()))
            # Behavior is explicitly described independently of code/string hashes.
            material['behavior_descriptor']=row.get('behavior_descriptor',{})
            material['mechanism_instruction']=row.get('mechanism_instruction') or row['representation']
            with self.lab.db() as db:
                previous=db.execute('SELECT state,body FROM candidates WHERE id=?',(material['candidate_id'],)).fetchone()
                if previous[0]=='proposed':
                    db.execute('UPDATE candidates SET body=? WHERE id=?',(json.dumps(material,ensure_ascii=False),material['candidate_id']))
            if material['candidate_id'] not in task['candidate_ids']:task['candidate_ids'].append(material['candidate_id'])
        task['state']='producing'
        self._save(task,'programs_submitted')
        return self.packet(task_id)

    def execute(self, task_id):
        task=self._read(task_id);results=[]
        available={row['capability'] for row in self.routes.routes() if row['available']}
        self.lab.adapters={capability:(lambda args,workspace,capability=capability:
            self.routes.execute(exact_goal=task['original_objective'],capability=capability,
                                executors=self.executors,arguments=args,workspace=workspace)) for capability in available}
        for cid in task['candidate_ids']:
            self.lab.require_goal(cid,task_id)
            try:
                row=self.lab.run(cid,observer='actual_registered_adapter',score_result=lambda values:{
                    'execution_effect':float(bool(values) and all(isinstance(x['result'],dict) and x['result'].get('success') is True for x in values))})
                results.append(row)
            except Exception as exc:
                failure={'candidate_id':cid,'error_type':type(exc).__name__,'error':str(exc),'goal_preserved':True}
                task['failures'].append(failure);results.append(failure)
        self._save(task,'programs_executed')
        return {'task_id':task_id,'results':results,**self.packet(task_id)}

    def assess(self, task_id, candidate_id, *, metrics, observer, rationale='', user_feedback=''):
        self.lab.require_goal(candidate_id,task_id)
        task=self._read(task_id)
        row=next((x for x in self.lab.candidates(task_id) if x['candidate_id']==candidate_id),None)
        if not row:raise ValueError('assess an actually executed candidate')
        if not observer:raise ValueError('quality observation source required')
        values=finite_scores(metrics)
        if set(values)=={'execution_effect'}:raise ValueError('artifact quality needs a task outcome beyond execution success')
        review={'metrics':values,'observer':str(observer),'rationale':str(rationale),
                'user_feedback':str(user_feedback),'artifact_refs':row['artifact_refs'],
                'execution_evidence_refs':row['evidence_refs'],'observed_at':time.time()}
        if task['family']=='writing':
            from .author_prose_auditor import audit_prose
            review['structural_prose_observations']=[audit_prose(Path(effect['result']['artifact']).read_text())
                for effect in row['observed_effects'] if effect.get('result',{}).get('artifact')]
        review_file=self.lab.root/'workspaces'/candidate_id/'quality_observation.json'
        review_file.write_text(json.dumps(review,ensure_ascii=False,indent=2))
        quality_ref=self.lab.evidence.record(case_id=task_id,subject_ref=candidate_id,
            scores=values,artifacts=[review_file,*row['artifact_refs']],observer=observer)
        row['evidence_refs']=list(dict.fromkeys([*row['evidence_refs'],quality_ref]))
        task['assessments'][candidate_id]=review
        # Preserve execution truth and quality as separate observations, and make
        # task quality available to actual synthesis and later experience recall.
        row['quality_observation']=review;row['scores']={**row['scores'],**values}
        row['score']=sum(values.values())/len(values)
        with self.lab.db() as db:db.execute('UPDATE candidates SET body=? WHERE id=?',(json.dumps(row,ensure_ascii=False,default=str),candidate_id))
        self._save(task,'artifact_quality_observed')
        return review

    def revise(self,task_id,candidate_id,*,artifact_path,edits,mechanism_id='source_preserving_revision'):
        self.lab.require_goal(candidate_id,task_id)
        row=next(x for x in self.lab.candidates(task_id) if x['candidate_id']==candidate_id)
        allowed={str(Path(x['result']['artifact']).resolve()) for x in row['observed_effects'] if x.get('result',{}).get('artifact')}
        path=Path(artifact_path).resolve()
        if str(path) not in allowed:raise ValueError('revision must consume this candidate actual artifact')
        self.submit(task_id,[{'mechanism_id':mechanism_id,'representation':row['representation']+'; revise actual source anchors',
            'operator_program':[{'capability':'artifact.revise','arguments':{'path':path.name,'source_text':path.read_text(),'edits':edits}}],
            'ancestry':[candidate_id],'behavior_descriptor':row.get('behavior_descriptor',{}),
            'mechanism_instruction':'Retain the actual artifact and improve only the reviewed source spans.'}])
        return self.execute(task_id)

    def select(self, task_id, candidate_ids=None):
        task=self._read(task_id)
        observed={x['candidate_id']:x for x in self.lab.candidates(task_id)}
        if candidate_ids is None:
            assessed=[(cid,review) for cid,review in task['assessments'].items() if cid in observed]
            if assessed:
                # Comparable numeric outcome metrics guide choice. Qualitative
                # differences and other candidates remain stored for further work.
                groups=defaultdict(list)
                for cid,review in assessed:groups[tuple(sorted(review['metrics']))].append((cid,review))
                candidate_ids=[max(group,key=lambda x:sum(x[1]['metrics'].values())/len(x[1]['metrics']))[0] for group in groups.values()]
            else:
                candidate_ids=[cid for cid,row in observed.items() if row['scores'].get('execution_effect')==1]
        if any(cid not in observed for cid in candidate_ids):raise ValueError('selection needs observed artifacts')
        task['selection']=list(dict.fromkeys(candidate_ids))
        task['state']='result_ready' if task['selection'] else 'needs_generation'
        learned=set(task.get('learned_candidate_ids',[]))
        for cid in task['selection']:
            row=observed[cid];review=task['assessments'].get(cid)
            if not review or cid in learned:continue
            strategy=row['lane_id']
            self.portfolio.register(ExplorationStrategy(strategy,row.get('mechanism_instruction') or row['representation'],task['family']),
                                    parents=row.get('ancestry',()),note='observed task artifact')
            reward=sum(review['metrics'].values())/len(review['metrics'])
            self.portfolio.record(strategy,reward,note=review['rationale'])
            self.evolution.record_route_result(objective=task['original_objective'],route_id=strategy,
                mechanism=row['representation'],success=row['scores'].get('execution_effect')==1,
                bindings=[x['capability'] for x in row['operator_program']],evidence_refs=row['evidence_refs'],
                learned_recipe=row.get('mechanism_instruction') or row['representation'])
            self.lab.remember(cid,family=task['family'],user_feedback=review['user_feedback'])
            learned.add(cid)
        task['learned_candidate_ids']=sorted(learned)
        self._save(task,'artifact_selection')
        return self.packet(task_id)

    def note_response(self, task_id, response_text, *, goal_completed=False, remaining_work=()):
        task=self._read(task_id)
        task['deliveries'].append({'response_text':response_text,'sha256':hashlib.sha256(response_text.encode()).hexdigest(),
                                  'goal_completed':bool(goal_completed),'at':time.time()})
        task['remaining_work']=list(remaining_work)
        task['state']='completed' if goal_completed else 'open'
        self._save(task,'response_delivered_task_state_retained')
        return self.packet(task_id)

    def produce(self, exact_text, turn_id, *, generator, judge=None, family=None):
        """Synchronous host path: real generation -> execution -> comparison -> learning."""
        request=self.begin(exact_text,turn_id,family=family)
        task_id=request['task']['task_id']
        generated=generator(exact_text,request)
        candidates=generated.get('candidates',[]) if isinstance(generated,dict) else generated
        self.submit(task_id,candidates)
        self.execute(task_id)
        if judge:
            for row in self.lab.candidates(task_id):
                review=judge(exact_text,row)
                revision=review.pop('revision',None)
                self.assess(task_id,row['candidate_id'],**review)
                if revision:
                    self.revise(task_id,row['candidate_id'],**revision)
                    revised=[x for x in self.lab.candidates(task_id) if row['candidate_id'] in x.get('ancestry',[])]
                    for updated in revised:
                        final_review=judge(exact_text,updated);final_review.pop('revision',None)
                        self.assess(task_id,updated['candidate_id'],**final_review)
        return self.select(task_id)
