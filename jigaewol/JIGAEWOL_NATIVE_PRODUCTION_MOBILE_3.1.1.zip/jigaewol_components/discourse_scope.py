from __future__ import annotations

"""Presentation/provenance observations for exact user discourse.

Authority rules do not live here.  In authority_ruleset_version=1, this analyzer is a
lossless observation layer: it records formatting/provenance markers and delegates all
binding/action decisions to :mod:`jigaewol_components.authority_consolidation`.
"""

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Any

from .requirement_contract import RequirementContract


_TRANSCRIPT_SPEAKER_MARKERS = (
    "나 >", "나>", "너 >", "너>", "내턴", "내 턴", "너턴", "너 턴",
    "user >", "assistant >", "user:", "assistant:",
)
_REFERENCE_BLOCK_START = (
    "전문을 줄게", "전문을 줄께", "대화 전문", "대화를 줄게", "대화를 붙여", "붙여줄게",
    "아래 대화", "다음 대화", "transcript", "conversation transcript",
)
_REFERENCE_BLOCK_END = (
    "라는 대화를 나눴는데", "이 대화를 나눴는데", "여기까지가", "여기까지는",
    "네 생각은", "어떻게 생각", "평가해", "보고 말해", "what do you think",
)
_REFERENCE_INTRO_MARKERS = (
    "아래는", "아래 걸", "아래의", "전문", "지피티가 준", "클로드가 준",
    "the following", "below is", "quoted material", "reference material",
)


def _sha(value: Any) -> str:
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class PresentationObservation:
    atom_id: str
    source_index: int
    atom_text: str
    presentation_metadata: tuple[str, ...]
    provenance_metadata: tuple[str, ...]

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class DiscourseScopeProjection:
    """Presentation-only projection.

    Compatibility views (`action_text`, `current_text`, etc.) deliberately delegate to
    AuthorityConsolidation.  They contain no local authority logic and may be removed once
    downstream consumers migrate to CanonicalDirectiveSet directly.
    """

    message_sha256: str
    raw_text: str
    contract: RequirementContract
    rows: tuple[PresentationObservation, ...]
    presentation_metadata: tuple[str, ...]
    provenance_metadata: tuple[str, ...]

    def _canonical(self):
        from .authority_consolidation import AuthorityConsolidation, ExactUserSource
        return AuthorityConsolidation.compile(
            ExactUserSource.from_text(self.raw_text),
            self.contract,
            presentation=self,
        )

    @property
    def semantic_text(self) -> str:
        return self._canonical().semantic_text

    @property
    def current_text(self) -> str:
        return self._canonical().current_text

    @property
    def action_text(self) -> str:
        return self._canonical().action_text

    @property
    def semantic_atom_ids(self) -> tuple[str, ...]:
        return self._canonical().semantic_atom_ids

    @property
    def current_source_indexes(self) -> tuple[int, ...]:
        return self._canonical().current_source_indexes

    @property
    def action_atom_ids(self) -> tuple[str, ...]:
        return self._canonical().action_atom_ids

    @property
    def action_source_indexes(self) -> tuple[int, ...]:
        return self._canonical().action_source_indexes

    @property
    def scope_counts(self) -> dict[str, int]:
        return dict(self._canonical().scope_counts)

    def summary(self, *, max_ids: int | None = None) -> dict[str, Any]:
        canonical = self._canonical()
        presentation_rows = [
            f"{row.atom_id}:{row.source_index}:{','.join(row.presentation_metadata)}:{','.join(row.provenance_metadata)}"
            for row in self.rows
        ]
        result = canonical.summary(max_ids=max_ids)
        result.update({
            "presentation_schema": "jigaewol_discourse_presentation_v2",
            "presentation_metadata": list(self.presentation_metadata),
            "provenance_metadata": list(self.provenance_metadata),
            "presentation_rows_sha256": _sha(presentation_rows),
            "authority_decision_local_to_discourse_scope": False,
            "authority_compiler": "AuthorityConsolidation",
        })
        return result


class DiscourseScopeAnalyzer:
    """Observe presentation/provenance without deciding authority or actuation."""

    @staticmethod
    def _metadata(text: str, *, transcript_mode: bool) -> tuple[tuple[str, ...], tuple[str, ...]]:
        raw = str(text or "")
        folded = raw.casefold()
        presentation: list[str] = []
        provenance: list[str] = []

        if raw.lstrip().startswith(">"):
            presentation.append("markdown_quote_marker")
        if "```" in raw:
            presentation.append("code_fence_marker")
        if "**" in raw or "__" in raw:
            presentation.append("emphasis_marker")
        if any(marker.casefold() in folded for marker in _TRANSCRIPT_SPEAKER_MARKERS):
            presentation.append("speaker_marker")
            provenance.append("transcript_speaker_marker")
        if any(marker.casefold() in folded for marker in _REFERENCE_BLOCK_START):
            provenance.append("reference_block_start_marker")
        if any(marker.casefold() in folded for marker in _REFERENCE_BLOCK_END):
            provenance.append("reference_block_end_marker")
        if any(marker.casefold() in folded for marker in _REFERENCE_INTRO_MARKERS):
            provenance.append("reference_intro_marker")
        if transcript_mode:
            provenance.append("transcript_mode_observed")

        return tuple(dict.fromkeys(presentation)), tuple(dict.fromkeys(provenance))

    @classmethod
    def compile(cls, text: str, contract: RequirementContract) -> DiscourseScopeProjection:
        exact = str(text)
        if contract.message_sha256 != hashlib.sha256(exact.encode("utf-8")).hexdigest():
            raise ValueError("discourse_presentation_contract_source_mismatch")
        transcript_marker_count = sum(exact.casefold().count(x.casefold()) for x in _TRANSCRIPT_SPEAKER_MARKERS)
        transcript_mode = transcript_marker_count >= 2
        rows: list[PresentationObservation] = []
        presentation_union: list[str] = []
        provenance_union: list[str] = []
        for atom in contract.atoms:
            presentation, provenance = cls._metadata(str(atom.text), transcript_mode=transcript_mode)
            presentation_union.extend(presentation)
            provenance_union.extend(provenance)
            rows.append(PresentationObservation(
                atom_id=str(atom.atom_id),
                source_index=int(atom.source_index),
                atom_text=str(atom.text),
                presentation_metadata=presentation,
                provenance_metadata=provenance,
            ))
        return DiscourseScopeProjection(
            message_sha256=contract.message_sha256,
            raw_text=exact,
            contract=contract,
            rows=tuple(rows),
            presentation_metadata=tuple(dict.fromkeys(presentation_union)),
            provenance_metadata=tuple(dict.fromkeys(provenance_union)),
        )
