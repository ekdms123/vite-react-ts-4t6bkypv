from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .requirement_contract import RequirementContract
from .strategy_topology import StrategyTopology
from .semantic_authority import bind_semantic_authority


@dataclass(frozen=True)
class RepresentationFrame:
    frame_id: str
    mode: str
    instruction: str
    purpose: str
    preserve_goal: bool = True


@dataclass(frozen=True)
class RepresentationTournamentPlan:
    active: bool
    frames: tuple[RepresentationFrame, ...]
    synthesis_rule: str
    rejection_rule: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class RepresentationTournament:
    """Compiles materially different problem representations before answer selection.

    The tournament does not claim that more branches are always better. It opens
    alternate representations when topology warrants them, then asks the connected
    generator/solver to compare them against the same immutable user goal.
    """

    @staticmethod
    def compile(
        message: str,
        contract: RequirementContract,
        topology: StrategyTopology,
        *,
        semantic_authority: Mapping[str, Any] | None = None,
    ) -> RepresentationTournamentPlan:
        authority = bind_semantic_authority(message, semantic_authority)
        active = "representation_tournament" in topology.selected or bool(authority.get("representation_search_required"))
        if not active:
            return RepresentationTournamentPlan(
                False,
                (RepresentationFrame("original", "original", "Solve the user's exact problem without rewriting the goal.", "baseline"),),
                "Use the direct representation.",
                "Do not introduce extra branching merely because reasoning depth is high.",
            )

        constraints = [a.text for a in contract.atoms if a.kind == "constraint"]
        actions = [a.text for a in contract.atoms if a.kind == "action"]
        frames = [
            RepresentationFrame(
                "original", "original",
                "Solve the exact user objective as stated; preserve every atomic requirement.",
                "baseline against which alternatives are compared",
            ),
            RepresentationFrame(
                "constraint_inversion", "assumption_inversion",
                "Identify the strongest hidden assumption or inherited architecture choice. Temporarily invert it and ask whether a stronger route appears without changing the user's goal.",
                "escape premature closure",
            ),
            RepresentationFrame(
                "minimal_instance", "reduction",
                "Reduce the problem to the smallest instance that still contains the hard part. Solve or experimentally probe that instance, then lift the result back to the full goal.",
                "expose the true bottleneck",
            ),
            RepresentationFrame(
                "extreme_case", "stress_test",
                "Push scale, latency, uncertainty, or constraint tension to an extreme and inspect which assumptions break first.",
                "surface nonlinear failure modes",
            ),
            RepresentationFrame(
                "counterexample", "adversarial",
                "Actively construct the best counterexample to the leading approach and search for a route that survives it.",
                "avoid comfortable first-answer lock-in",
            ),
            RepresentationFrame(
                "execution_experiment", "experiment",
                "Convert uncertain claims into the cheapest real experiment, code probe, browser action, or measurable comparison available; prefer observation over speculation when executable.",
                "turn reasoning into evidence-producing action",
            ),
            RepresentationFrame(
                "structural_analogy", "cross_domain",
                "Look for a structurally similar problem in a different domain and transfer mechanism, not vocabulary; reject the analogy if the causal structure does not map.",
                "discover non-obvious mechanisms",
            ),
            RepresentationFrame(
                "information_gain", "research",
                "Ask which unknown, if resolved next, would most change the solution. Search or test that unknown before spending effort on low-value verification.",
                "maximize information gain per action",
            ),
        ]
        low=str(message).casefold()
        wanted={"original"}
        if authority and authority.get("frontier_exploration_required"):
            # Frontier mode keeps the whole seed ecology live. Seeds are still not a
            # closed ontology; task-local invented frames are requested downstream.
            wanted.update(frame.frame_id for frame in frames)
        elif authority:
            wanted.update(str(x) for x in authority.get("representation_frame_hints", ()) if str(x))
        else:
            if any(x in low for x in ("가정","전제","뒤집","assumption","premise")): wanted.add("constraint_inversion")
            if any(x in low for x in ("반례","반증","허점","counterexample","falsif")): wanted.add("counterexample")
            if any(x in low for x in ("실행","구현","테스트","run","execute","build")): wanted.add("execution_experiment")
            if any(x in low for x in ("비유","다른 분야","analogy","cross-domain")): wanted.add("structural_analogy")
            if any(x in low for x in ("정보","조사","검색","unknown","search","research")): wanted.add("information_gain")
            if any(x in low for x in ("극단", "한계", "벽", "stress", "scale", "latency")): wanted.add("extreme_case")
            if len(contract.atoms) >= 2: wanted.add("minimal_instance")
        # An active tournament with only the baseline is a contradiction.  If the
        # canonical semantic authority asked for representation search but no seed name
        # happened to match, reserve genuinely different fallback probes.  Seeds are
        # non-exhaustive; the generator may still invent a task-local frame.
        if active and wanted == {"original"}:
            wanted.update(("constraint_inversion", "extreme_case"))
        elif active and len(wanted - {"original"}) == 1:
            wanted.add("extreme_case" if "extreme_case" not in wanted else "counterexample")
        frames=[frame for frame in frames if frame.frame_id in wanted]
        if constraints:
            frames.append(RepresentationFrame(
                "constraint_tension", "multi_constraint",
                "Treat the following constraints as simultaneous, not optional: " + " | ".join(constraints),
                "prevent requirement compression",
            ))
        if len(actions) >= 2:
            frames.append(RepresentationFrame(
                "composition", "systems",
                "Treat the requested actions as a composed system. Search for shared infrastructure, state, or interfaces that make the whole cheaper and stronger than separate patches.",
                "find architecture-level leverage",
            ))
        # Preserve first occurrence and enforce the semantic contract: active means at
        # least one material alternative is actually reachable downstream.
        frames = list({frame.frame_id: frame for frame in frames}.values())
        if active and len(frames) < 2:
            raise AssertionError("active representation tournament must materialize a non-original frame")
        return RepresentationTournamentPlan(
            True,
            tuple(frames),
            "Preserve multiple live mechanisms long enough to expose real differences. Synthesize only when useful; evidence may narrow the set, but persistence, familiarity, or registry membership may not. Do not collapse genuinely distinct representations merely for consistency.",
            "Do not discard an unconventional frame merely because it lacks evidence at admission time; label it speculative, incubate it, then test it. Do discard frames that rewrite the user goal or contradict observed constraints after those constraints are actually re-applied.",
        )
