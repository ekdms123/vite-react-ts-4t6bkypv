from __future__ import annotations

"""Source-coverage policy for trend/current intelligence requests.

It widens sensor coverage; it never grants authority.  Authority still comes from the
exact current user directive compiled by SemanticAuthorityCompiler.
"""

import re
from typing import Any, Iterable, Mapping


class SearchSwarmPolicy:
    TREND_RE = re.compile(r"(?:요즘|유행|뜨는|핫한|트렌드|최신|trend(?:ing)?|what.?s hot|viral)", re.I)
    CODE_RE = re.compile(r"(?:github|gitlab|repo(?:sitory)?|깃허브|오픈소스|open\s*source)", re.I)
    COMMUNITY_RE = re.compile(r"(?:reddit|레딧|커뮤니티|forum|포럼|dcinside|디시|클리앙|루리웹|blind|블라인드)", re.I)
    MULTILINGUAL_RE = re.compile(r"(?:한국|한국어|korean|일본|일본어|japanese|중국|중국어|chinese|다국어|multilingual)", re.I)
    SOCIAL_RE = re.compile(r"(?:인스타|instagram|트위터|twitter|x(?:\.com)?|틱톡|tiktok|밈|meme|추천\s*피드)", re.I)

    @classmethod
    def expand(cls, text: str, families: Iterable[str], *, search_requested: bool) -> tuple[str, ...]:
        current = list(dict.fromkeys(str(x) for x in families if str(x)))
        if not search_requested:
            return tuple(current)
        for family in ("first_party", "web_current"):
            if family not in current:
                current.append(family)
        if cls.TREND_RE.search(str(text or "")):
            for family in ("community", "code_ecosystem", "social_recommendation", "creator_graph", "multilingual"):
                if family not in current:
                    current.append(family)
        source_text=str(text or "")
        if cls.SOCIAL_RE.search(source_text):
            for family in ("social_recommendation", "creator_graph", "community"):
                if family not in current:
                    current.append(family)
        if cls.CODE_RE.search(source_text) and "code_ecosystem" not in current:
            current.append("code_ecosystem")
        if cls.COMMUNITY_RE.search(source_text) and "community" not in current:
            current.append("community")
        if cls.MULTILINGUAL_RE.search(source_text) and "multilingual" not in current:
            current.append("multilingual")
        return tuple(current)

    @classmethod
    def compile_sensor_program(
        cls, text: str, families: Iterable[str], *, search_requested: bool
    ) -> dict[str, Any]:
        """Compile a source-coverage program from the exact search request.

        This is a completion contract, not an execution claim: every required family
        remains open until an observed success for that family is recorded.
        """
        required = cls.expand(text, families, search_requested=search_requested)
        from .search_portfolio_engine import SearchPortfolioEngine
        sensors = []
        for family in required:
            sensors.append({
                "source_family": family,
                "capability": f"search:{family}",
                "query_program": SearchPortfolioEngine.compile_query_program(str(text), family),
                "required": True,
                "completion_state": "open",
            })
        return {
            "schema": "jigaewol_search_swarm_program_v1",
            "objective": str(text),
            "required_families": list(required),
            "sensors": sensors,
            "completion_requires_all_required_families": True,
            "single_sensor_success_may_not_close_search": True,
            "blocked_lane_remains_explicit": True,
        }

    @staticmethod
    def coverage(program: Mapping[str, Any], observations: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
        required = [str(x) for x in (program.get("required_families") or ()) if str(x)]
        satisfied: list[str] = []
        blocked: list[str] = []
        evidence: dict[str, list[str]] = {fam: [] for fam in required}
        for raw in observations:
            row = dict(raw or {})
            family = str(row.get("source_family") or "")
            if family not in required:
                continue
            ref = str(row.get("evidence_ref") or row.get("observation_sha256") or "")
            if ref:
                evidence.setdefault(family, []).append(ref)
            if row.get("success") is True:
                if family not in satisfied:
                    satisfied.append(family)
            elif row.get("blocked") is True or row.get("terminal_failure") is True:
                if family not in blocked:
                    blocked.append(family)
        open_families = [fam for fam in required if fam not in satisfied]
        return {
            "required_families": required,
            "satisfied_families": satisfied,
            "blocked_families": blocked,
            "open_families": open_families,
            "evidence_by_family": evidence,
            "complete": bool(required) and not open_families,
            "partial_success_is_not_completion": bool(open_families and satisfied),
        }
