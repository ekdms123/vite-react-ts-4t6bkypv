from __future__ import annotations

import hashlib
import os
import platform
import sys
from pathlib import Path


def current_host_fingerprint() -> str:
    """Return a non-secret hash identifying the current execution host environment."""
    machine_id = ""
    for candidate in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        try:
            if candidate.exists():
                machine_id = candidate.read_text(encoding="utf-8").strip()
                break
        except OSError:
            pass
    payload = "|".join(
        [
            platform.system(),
            platform.release(),
            platform.machine(),
            platform.node(),
            machine_id,
            os.path.realpath(sys.executable),
        ]
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:24]
