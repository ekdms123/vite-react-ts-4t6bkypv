from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable


@dataclass(frozen=True)
class ObjectiveDimension:
    dimension_id: str
    description: str
    weight: float = 1.0


@dataclass(frozen=True)
class PlanCoverage:
    plan_id: str
    covered_dimensions: tuple[str, ...]
    notes: str = ""


@dataclass(frozen=True)
class FidelityReport:
    plan_id: str
    score: float
    covered: tuple[str, ...]
    missing: tuple[str, ...]


@dataclass(frozen=True)
class ObjectiveInterpretation:
    interpretation_id: str
    dimensions: tuple[ObjectiveDimension, ...]
    rationale: str = ""


ObjectiveMutator = Callable[[str, tuple[ObjectiveInterpretation, ...]], Iterable[ObjectiveInterpretation]]


class ObjectiveSpace:
    """Preserves user objective anchors while allowing flexible multi-dimensional interpretation."""

    def __init__(self, anchor: str, interpretations: Iterable[ObjectiveInterpretation]) -> None:
        self.anchor = anchor
        self.interpretations = {x.interpretation_id: x for x in interpretations}

    def expand(self, mutator: ObjectiveMutator) -> tuple[ObjectiveInterpretation, ...]:
        generated = tuple(mutator(self.anchor, tuple(self.interpretations.values())))
        for item in generated:
            self.interpretations[item.interpretation_id] = item
        return generated

    def fidelity_models(self) -> tuple["ObjectiveFidelity", ...]:
        return tuple(ObjectiveFidelity(x.dimensions) for x in self.interpretations.values())


class ObjectiveFidelity:
    """Measures whether candidate plans fulfill required objective dimensions."""

    def __init__(self, dimensions: Iterable[ObjectiveDimension]) -> None:
        dims = tuple(dimensions)
        if not dims:
            raise ValueError("at least one objective dimension is required")
        self.dimensions = {d.dimension_id: d for d in dims}

    def assess(self, plan: PlanCoverage) -> FidelityReport:
        covered = tuple(sorted(set(plan.covered_dimensions) & set(self.dimensions)))
        missing = tuple(sorted(set(self.dimensions) - set(covered)))
        total = sum(max(0.0, d.weight) for d in self.dimensions.values())
        hit = sum(max(0.0, self.dimensions[d].weight) for d in covered)
        score = hit / total if total else 1.0
        return FidelityReport(plan.plan_id, score, covered, missing)
