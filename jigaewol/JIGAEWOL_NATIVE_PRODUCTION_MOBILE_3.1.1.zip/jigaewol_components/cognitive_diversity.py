from __future__ import annotations

import copy
import hashlib
import json
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from .failure_router import FailureRouter


import jigaewol_components._cognition_shared as _shared


@dataclass(frozen=True)
class ThoughtMethodProfile:
    method_id: str
    representation: str
    mechanism: str
    source: str
    facets: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ComputeEnvironmentProfile:
    environment_id: str
    substrate: str
    builder: str
    configuration: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ArchitectureProfile:
    architecture_id: str
    control_topology: str
    memory_model: str
    self_model: str
    extensions: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CognitiveWorld:
    world_id: str
    generation: int
    parent_ids: tuple[str, ...]
    method: ThoughtMethodProfile
    environment: ComputeEnvironmentProfile
    architecture: ArchitectureProfile
    created_at: float

    def semantic_payload(self) -> dict[str, Any]:
        return _shared.world_semantic_payload(**locals())

    @property
    def signature(self) -> str:
        raw = json.dumps(self.semantic_payload(), sort_keys=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


@dataclass(frozen=True)
class WorldOutcome:
    world_id: str
    utility: float
    novelty: float
    reality_score: float
    evidence_count: int
    success: bool
    result: dict[str, Any] = field(default_factory=dict)
    evidence: tuple[str, ...] = ()
    measures: dict[str, float] = field(default_factory=dict)

    def measure_map(self) -> dict[str, float]:
        return _shared.outcome_measure_map(**locals())

    @property
    def vector(self) -> tuple[float, ...]:
        return tuple(self.measure_map()[k] for k in sorted(self.measure_map()))


@dataclass(frozen=True)
class GenerationResult:
    generation: int
    worlds: tuple[CognitiveWorld, ...]
    outcomes: tuple[WorldOutcome, ...]
    survivors: tuple[CognitiveWorld, ...]


WorldExecutor = Callable[[CognitiveWorld, dict[str, Any]], WorldOutcome]
WorldGenerator = Callable[[str, tuple[CognitiveWorld, ...], int], Iterable[CognitiveWorld]]
WorldScheduler = Callable[[Sequence[CognitiveWorld], Callable[[CognitiveWorld], WorldOutcome]], Sequence[WorldOutcome]]
FamilyExtractor = Callable[[CognitiveWorld], Iterable[tuple[str, str]]]
SignatureStrategy = Callable[[CognitiveWorld], str]
SurvivalPolicy = Callable[[Sequence[CognitiveWorld], Sequence[WorldOutcome], int | None], Sequence[CognitiveWorld]]


def _dominates(a: WorldOutcome, b: WorldOutcome) -> bool:
    return _shared.dominates(**locals())


def _qualitative_protection_keys(world: CognitiveWorld) -> tuple[str, ...]:
    return _shared.qualitative_protection_keys(**locals())


def _flatten_semantics(value: Any, prefix: str = "") -> dict[str, str]:
    return _shared.flatten_semantics(**locals())


class CognitionArchive:
    """Persistent archive preserving divergent thinking paths and experimental outcomes."""

    def __init__(self, path: Path) -> None:
        return _shared.cognition_archive_init(**locals())

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        return _shared.cognition_archive_write(**locals())

    def append(self, generation: GenerationResult) -> None:
        return _shared.cognition_archive_append(**locals())

    def raw(self) -> dict[str, Any]:
        return self._read()


class CognitiveDiversityEngine:
    """Multi-perspective hypothesis generator and qualitative tension protector."""

    def __init__(self, root: Path) -> None:
        return _shared.diversity_init(archive_type=CognitionArchive, router_type=FailureRouter, allow_legacy_archive=False, **locals())

    def register_generator(self, generator_id: str, generator: WorldGenerator) -> None:
        self.generators[str(generator_id)] = generator

    def register_executor(self, route_id: str, executor: WorldExecutor) -> None:
        self.executors[str(route_id)] = executor

    def register_scheduler(self, scheduler_id: str, scheduler: WorldScheduler) -> None:
        self.schedulers[str(scheduler_id)] = scheduler

    def register_family_extractor(self, extractor_id: str, extractor: FamilyExtractor) -> None:
        self.family_extractors[str(extractor_id)] = extractor

    def register_signature_strategy(self, strategy_id: str, strategy: SignatureStrategy) -> None:
        self.signature_strategies[str(strategy_id)] = strategy

    def register_survival_policy(self, policy_id: str, policy: SurvivalPolicy) -> None:
        self.survival_policies[str(policy_id)] = policy

    def _world_signature(self, world: CognitiveWorld, strategy_id: str = "semantic") -> str:
        return str(self.signature_strategies[str(strategy_id)](world))

    def _family_axes(self, world: CognitiveWorld) -> tuple[tuple[str, str], ...]:
        return _shared.diversity_family_axes(**locals())

    def _resolve_executor(self, world: CognitiveWorld, fallback: WorldExecutor | None) -> WorldExecutor:
        return _shared.diversity_resolve_executor(outcome_type=WorldOutcome, **locals())

    @staticmethod
    def make_world(
        *,
        generation: int,
        parents: Sequence[str],
        method: ThoughtMethodProfile,
        environment: ComputeEnvironmentProfile,
        architecture: ArchitectureProfile,
    ) -> CognitiveWorld:
        return _shared.make_world(world_type=CognitiveWorld, **locals())

    def generate(
        self,
        objective: str,
        parents: Sequence[CognitiveWorld],
        generation: int,
        *,
        signature_strategy: str = "semantic",
    ) -> tuple[CognitiveWorld, ...]:
        return _shared.diversity_generate(**locals())

    def select_survivors(
        self,
        worlds: Sequence[CognitiveWorld],
        outcomes: Sequence[WorldOutcome],
        *,
        maximum: int | None = None,
        policy_id: str | None = None,
    ) -> tuple[CognitiveWorld, ...]:
        return _shared.select_survivors(success_only=False, evidence_tiebreak=True, **locals())

    def run_generation(
        self,
        objective: str,
        *,
        parents: Sequence[CognitiveWorld],
        generation: int,
        executor: WorldExecutor | None = None,
        context: dict[str, Any] | None = None,
        maximum_survivors: int | None = None,
        parallelism: int | None = None,
        scheduler_id: str | None = None,
        survival_policy_id: str | None = None,
        signature_strategy: str = "semantic",
    ) -> GenerationResult:
        return _shared.run_generation(result_type=GenerationResult, **locals())

    @staticmethod
    def novelty_against(world: CognitiveWorld, population: Sequence[CognitiveWorld]) -> float:
        return _shared.world_novelty(**locals())


