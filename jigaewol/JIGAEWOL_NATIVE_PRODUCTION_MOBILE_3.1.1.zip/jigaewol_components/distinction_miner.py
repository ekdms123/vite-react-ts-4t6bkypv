from __future__ import annotations

"""Generate missing distinctions from collision witnesses rather than a fixed ontology."""

from dataclasses import dataclass
from itertools import combinations
from typing import Any, Iterable, Mapping
import hashlib, json, re

from .organ_ir import TypeField


@dataclass(frozen=True, slots=True)
class DistinctionWitness:
    left: Mapping[str, Any]
    right: Mapping[str, Any]
    represented_as: Any
    left_required: Any
    right_required: Any


@dataclass(frozen=True, slots=True)
class DistinctionProposal:
    field: TypeField
    separates: int
    witness_count: int
    novelty: float
    generated_from: tuple[str, ...]
    witnesses: tuple[DistinctionWitness, ...]


def _stable(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()


def _slug(value: Any) -> str:
    text = re.sub(r"[^0-9A-Za-z_]+", "_", str(value)).strip("_")
    return text[:36] or _stable(value)[:10]


def _path_get(obj: Any, path: str, default: Any = None) -> Any:
    cur = obj
    for part in str(path).split("."):
        if not part:
            continue
        if isinstance(cur, Mapping) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur


class DistinctionMiner:
    """Invent observation channels directly from representational collisions.

    There is deliberately no registry of task concepts such as ``history_parity``.
    Candidate expressions are synthesized from the raw structure actually present in
    the collision witnesses: state paths, event identities, path lengths, residues,
    and small tuples of those expressions.  A later round can combine multiple born
    channels if no single expression separates every witness.
    """

    def __init__(
        self, *, residue_basis: Iterable[int] = (2, 3, 4, 5), expression_depth: int = 2,
        combination_arity: int = 2, expression_forms: Iterable[str] = ("eq", "tuple", "add", "sub", "mul", "mod"),
        productions: Iterable[Mapping[str, Any]] = (), search_budget: int = 256,
    ) -> None:
        self.residue_basis = tuple(dict.fromkeys(max(2, int(x)) for x in residue_basis)) or (2, 3, 4, 5)
        self.expression_depth = max(1, int(expression_depth))
        self.combination_arity = max(1, int(combination_arity))
        self.expression_forms = tuple(dict.fromkeys(str(x) for x in expression_forms if str(x)))
        self.productions = tuple(dict(x) for x in productions if isinstance(x, Mapping))
        self.search_budget = max(32, int(search_budget))

    def collisions(self, cases: Iterable[Mapping[str, Any]], *, representation_key: str = "representation", target_key: str = "required") -> tuple[DistinctionWitness, ...]:
        rows = tuple(cases)
        out: list[DistinctionWitness] = []
        for a, b in combinations(rows, 2):
            if a.get(representation_key) == b.get(representation_key) and a.get(target_key) != b.get(target_key):
                out.append(DistinctionWitness(a, b, a.get(representation_key), a.get(target_key), b.get(target_key)))
        return tuple(out)

    @staticmethod
    def _flatten_state(state: Mapping[str, Any], prefix: str = "state", *, budget: int = 512) -> list[tuple[str, Any]]:
        """Flatten observed structure without imposing a semantic nesting ceiling.

        ``budget`` bounds work, not the kinds of structures that may exist. Deep mappings
        remain traversable until the resource horizon is consumed.
        """
        out: list[tuple[str, Any]] = []
        stack: list[tuple[str, Any]] = [(prefix, state)]
        seen: set[int] = set()
        while stack and len(out) < max(1, int(budget)):
            base, value = stack.pop()
            if isinstance(value, Mapping):
                oid = id(value)
                if oid in seen:
                    continue
                seen.add(oid)
                for key, child in reversed(tuple(value.items())):
                    stack.append((f"{base}.{key}", child))
            else:
                out.append((base, value))
        return out

    @staticmethod
    def _eval(expr: Mapping[str, Any], case: Mapping[str, Any]) -> Any:
        kind = str(expr.get("kind") or "literal")
        history = tuple(case.get("history") or ())
        if kind == "literal":
            return expr.get("value")
        if kind == "source":
            return _path_get({"state": case.get("state") or {}, "history": history}, str(expr.get("path") or ""), expr.get("default"))
        if kind == "history_len":
            return len(history)
        if kind == "history_tail":
            n = max(0, int(expr.get("count", 1)))
            return tuple(history[-n:])
        if kind == "history_count":
            target = expr.get("event")
            return sum(1 for event in history if event == target)
        if kind == "transition_count":
            left, right = expr.get("left"), expr.get("right")
            return sum(1 for a, b in zip(history, history[1:]) if a == left and b == right)
        if kind in {"add", "sub", "mul"}:
            a = DistinctionMiner._eval(expr.get("a") or {}, case)
            b = DistinctionMiner._eval(expr.get("b") or {}, case)
            if kind == "add": return a + b
            if kind == "sub": return a - b
            return a * b
        if kind == "mod":
            a = int(DistinctionMiner._eval(expr.get("a") or {}, case) or 0)
            b = max(1, int(DistinctionMiner._eval(expr.get("b") or {}, case) or 1))
            return a % b
        if kind == "eq":
            return DistinctionMiner._eval(expr.get("a") or {}, case) == DistinctionMiner._eval(expr.get("b") or {}, case)
        if kind == "if":
            branch = expr.get("then") if DistinctionMiner._eval(expr.get("cond") or {}, case) else expr.get("else")
            return DistinctionMiner._eval(branch or {}, case)
        if kind == "tuple":
            return tuple(DistinctionMiner._eval(x, case) for x in expr.get("items", ()))
        return None

    def _generated_candidates(self, witnesses: tuple[DistinctionWitness, ...], *, compose: bool = True) -> tuple[TypeField, ...]:
        expressions: list[tuple[str, Mapping[str, Any], str]] = []
        rows = tuple(x for w in witnesses for x in (w.left, w.right))

        state_paths: dict[str, list[Any]] = {}
        events: set[Any] = set()
        transitions: set[tuple[Any, Any]] = set()
        for row in rows:
            for path, value in self._flatten_state(row.get("state") or {}, budget=self.search_budget):
                state_paths.setdefault(path, []).append(value)
            hist = tuple(row.get("history") or ())
            events.update(hist)
            transitions.update(zip(hist, hist[1:]))

        for path, values in sorted(state_paths.items()):
            base_name = _slug(path.replace("state.", ""))
            base = {"kind": "source", "path": path}
            expressions.append((f"state_{base_name}", base, "state_distinction"))
            if all(isinstance(v, (int, bool)) for v in values if v is not None):
                for modulus in self.residue_basis:
                    expressions.append((f"state_{base_name}_mod_{modulus}", {"kind": "mod", "a": base, "b": {"kind": "literal", "value": modulus}}, "state_residue"))

        hlen = {"kind": "history_len"}
        expressions.append(("path_length", hlen, "path_measure"))
        for modulus in self.residue_basis:
            expressions.append((f"path_length_mod_{modulus}", {"kind": "mod", "a": hlen, "b": {"kind": "literal", "value": modulus}}, "path_residue"))
        for count in range(1, min(8, self.expression_depth + 2) + 1):
            expressions.append((f"path_tail_{count}", {"kind": "history_tail", "count": count}, "path_suffix"))

        for event in sorted(events, key=repr):
            ev_name = _slug(event)
            count_expr = {"kind": "history_count", "event": event}
            expressions.append((f"count_{ev_name}", count_expr, "event_multiplicity"))
            for modulus in self.residue_basis:
                expressions.append((f"count_{ev_name}_mod_{modulus}", {"kind": "mod", "a": count_expr, "b": {"kind": "literal", "value": modulus}}, "event_residue"))
        for left, right in sorted(transitions, key=repr):
            expressions.append((f"transition_{_slug(left)}_to_{_slug(right)}", {"kind": "transition_count", "left": left, "right": right}, "path_transition"))

        # The primitive observations are only atoms.  The generator-provided expression
        # forms define a *current* meta-grammar that may itself change next generation.
        # ``search_budget`` is a work horizon, not a whitelist of concept kinds.
        primitive = list(expressions)
        frontier = list(primitive)
        seen_expr = {_stable(expr) for _name, expr, _role in expressions}
        forms = set(self.expression_forms)
        # Depth here is a compute horizon derived from the current budget, not a
        # whitelist of semantic forms. Later generations can raise the budget.
        compose_depth = min(max(0, self.expression_depth - 1), max(1, int(self.search_budget ** 0.5) // 8)) if compose else 0
        for depth in range(compose_depth):
            born: list[tuple[str, Mapping[str, Any], str]] = []
            # Work horizon only: keep each generation broad enough to discover new
            # combinations without quadratic explosion over the full accumulated pool.
            pool_limit = max(12, int(self.search_budget ** 0.5) * 2)
            pool = (frontier + primitive)[:pool_limit]
            for i, (lname, lexpr, _lrole) in enumerate(pool):
                if len(expressions) + len(born) >= self.search_budget:
                    break
                if "mod" in forms:
                    for modulus in self.residue_basis:
                        expr = {"kind": "mod", "a": lexpr, "b": {"kind": "literal", "value": modulus}}
                        try:
                            tuple(self._eval(expr, row) for row in rows)
                        except Exception:
                            continue
                        if _stable(expr) not in seen_expr:
                            born.append((f"g{depth}_mod_{modulus}_{lname}"[:72], expr, "generated_composition")); seen_expr.add(_stable(expr))
                for rname, rexpr, _rrole in pool[i + 1 :]:
                    for form in ("tuple", "add", "sub", "mul", "eq"):
                        if form not in forms or len(expressions) + len(born) >= self.search_budget:
                            continue
                        if form == "tuple": expr = {"kind": "tuple", "items": (lexpr, rexpr)}
                        elif form == "eq": expr = {"kind": "eq", "a": lexpr, "b": rexpr}
                        else: expr = {"kind": form, "a": lexpr, "b": rexpr}
                        try:
                            tuple(self._eval(expr, row) for row in rows)
                        except Exception:
                            continue
                        sig = _stable(expr)
                        if sig in seen_expr:
                            continue
                        seen_expr.add(sig)
                        born.append((f"g{depth}_{form}_{lname}_{rname}"[:72], expr, "generated_composition"))
            if not born:
                break
            expressions.extend(born)
            frontier = born
            if len(expressions) >= self.search_budget:
                break

        # Deduplicate structurally. Names are descriptive consequences, not a concept registry.
        seen: set[str] = set()
        out: list[TypeField] = []
        for name, expr, role in expressions:
            sig = _stable(expr)
            if sig in seen:
                continue
            seen.add(sig)
            out.append(TypeField(name, expr, role))
        return tuple(out)

    @staticmethod
    def _residue_classifier_accuracy(residues: tuple[int, ...], labels: tuple[Any, ...]) -> tuple[float, dict[int, Any]]:
        buckets: dict[int, dict[str, tuple[Any, int]]] = {}
        for residue, label in zip(residues, labels):
            key = repr(label)
            bucket = buckets.setdefault(int(residue), {})
            prior = bucket.get(key)
            bucket[key] = (label, (prior[1] if prior else 0) + 1)
        mapping: dict[int, Any] = {}
        correct = 0
        for residue, counts in buckets.items():
            label, count = max(counts.values(), key=lambda row: row[1])
            mapping[residue] = label; correct += count
        return (correct / max(1, len(labels))), mapping

    def propose_program_residual(
        self, cases: Iterable[Mapping[str, Any]], *, existing_names: Iterable[str] = (),
        moduli: Iterable[int] | None = None, beam_width: int = 72, max_terms: int | None = None,
    ) -> DistinctionProposal | None:
        """Birth a new sensor when the *program* cannot express a general rule.

        This is deliberately not collision-only.  A representation can uniquely name
        every training row and still be useless for extrapolation.  We therefore search
        for a low-arity modular signature over raw observation primitives and add the
        resulting expression as a new first-class channel.  No hidden-world oracle is
        read; only states, histories and required effects in the training witnesses are
        available to this search.
        """
        rows = tuple(dict(x) for x in cases)
        if len(rows) < 2:
            return None
        labels = tuple(row.get("required") for row in rows)
        if len({repr(x) for x in labels}) < 2:
            return None

        # Reuse the same raw structural candidate generator by creating witness pairs
        # from differing outputs.  Limit pair count so the search geometry stays local.
        witness_rows: list[DistinctionWitness] = []
        for i, left in enumerate(rows):
            for right in rows[i + 1:]:
                if left.get("required") == right.get("required"):
                    continue
                witness_rows.append(DistinctionWitness(left, right, left.get("representation"), left.get("required"), right.get("required")))
                if len(witness_rows) >= 96:
                    break
            if len(witness_rows) >= 96:
                break
        if not witness_rows:
            return None
        fields = list(self._generated_candidates(tuple(witness_rows), compose=False))

        # Tail equality is a generic observation primitive, not knowledge of which
        # tail matters.  Every observed terminal event is offered symmetrically.
        terminal_events = tuple(dict.fromkeys(
            (tuple(row.get("history") or ())[-1] if tuple(row.get("history") or ()) else None)
            for row in rows
        ))
        for event in terminal_events:
            if event is None:
                continue
            fields.append(TypeField(
                f"tail_is_{_slug(event)}",
                {"kind": "eq", "a": {"kind": "history_tail", "count": 1}, "b": {"kind": "literal", "value": (event,)}},
                "terminal_event_indicator",
            ))

        terms: list[tuple[TypeField, tuple[int, ...]]] = []
        seen_expr: set[str] = set()
        for field in fields:
            if field.semantic_role == "composed_distinction":
                continue
            sig = _stable(field.extractor)
            if sig in seen_expr:
                continue
            seen_expr.add(sig)
            values = tuple(self._eval(field.extractor, row) for row in rows)
            if not values or not all(isinstance(v, (int, bool)) for v in values):
                continue
            ints = tuple(int(v) for v in values)
            if len(set(ints)) <= 1:
                continue
            terms.append((field, ints))

        if not terms:
            return None
        search_moduli = tuple(dict.fromkeys(int(x) for x in (moduli or self.residue_basis) if int(x) >= 2))
        requested_terms = max(1, int(max_terms or max(3, self.combination_arity + self.expression_depth)))
        # Beam search work horizon scales with evidence volume and can grow in later
        # generations; it does not define which expression families are admissible.
        evidence_horizon = max(3, int((len(rows) + 1).bit_length()) + 2)
        max_terms = min(requested_terms, evidence_horizon, max(1, len(terms)))

        for modulus in search_moduli:
            if len({repr(x) for x in labels}) > modulus:
                continue
            # beam item: (accuracy, selected[(idx,coeff)], residue-vector, mapping)
            beam: list[tuple[float, tuple[tuple[int, int], ...], tuple[int, ...], dict[int, Any]]] = []
            for intercept in range(modulus):
                residues = tuple(intercept for _ in rows)
                acc, mapping = self._residue_classifier_accuracy(residues, labels)
                beam.append((acc, (), residues, mapping))
            for _depth in range(max_terms):
                expanded: dict[tuple[int, ...], tuple[float, tuple[tuple[int, int], ...], tuple[int, ...], dict[int, Any]]] = {}
                for _acc, selected, residues, _mapping in beam:
                    used = {idx for idx, _ in selected}
                    for idx, (_field, values) in enumerate(terms):
                        if idx in used:
                            continue
                        for coeff in range(1, modulus):
                            next_residues = tuple((r + coeff * v) % modulus for r, v in zip(residues, values))
                            acc, mapping = self._residue_classifier_accuracy(next_residues, labels)
                            candidate = (acc, (*selected, (idx, coeff)), next_residues, mapping)
                            prior = expanded.get(next_residues)
                            if prior is None or (candidate[0], -len(candidate[1])) > (prior[0], -len(prior[1])):
                                expanded[next_residues] = candidate
                if not expanded:
                    break
                beam = sorted(expanded.values(), key=lambda row: (row[0], -len(row[1])), reverse=True)[:max(8, int(beam_width))]
                best = beam[0]
                if best[0] >= 1.0 and best[1]:
                    pieces = []
                    generated_from = []
                    for idx, coeff in best[1]:
                        field, _values = terms[idx]
                        generated_from.append(field.name)
                        term_expr: Mapping[str, Any] = dict(field.extractor)
                        if coeff != 1:
                            term_expr = {"kind": "mul", "a": {"kind": "literal", "value": coeff}, "b": term_expr}
                        pieces.append(term_expr)
                    expr: Mapping[str, Any] = pieces[0]
                    for piece in pieces[1:]:
                        expr = {"kind": "add", "a": expr, "b": piece}
                    expr = {"kind": "mod", "a": expr, "b": {"kind": "literal", "value": modulus}}
                    name = "residual_signature_" + _stable({"modulus": modulus, "terms": best[1], "expr": expr})[:14]
                    field = TypeField(name, expr, "program_residual_signature")
                    # This proposal is born from program failure, not pair collisions;
                    # report its coverage against all differently-labelled pairs.
                    return DistinctionProposal(field, len(witness_rows), len(witness_rows), 1.0, tuple(generated_from), tuple(witness_rows))
        return None


    def condition_candidates(self, rows: Iterable[Mapping[str, Any]], features: Iterable[str]) -> tuple[tuple[str, Mapping[str, Any]], ...]:
        """Generate predicates from the current meta-grammar over born observation fields."""
        rows = tuple(rows); features = tuple(dict.fromkeys(map(str, features)))
        out: list[tuple[str, Mapping[str, Any]]] = []
        forms = set(self.expression_forms)
        for feature in features:
            values = [dict(row.get("representation") or {}).get(feature) for row in rows]
            uniq: list[Any] = []
            for value in values:
                if repr(value) not in {repr(x) for x in uniq}: uniq.append(value)
            if "eq" in forms:
                for value in uniq:
                    out.append((f"{feature}=={value!r}", {"kind": "eq", "a": {"kind": "get", "root": "env", "path": feature}, "b": {"kind": "literal", "value": value}}))
            if "mod" in forms and values and all(isinstance(v, (int, bool)) for v in values):
                for modulus in self.residue_basis:
                    for residue in range(modulus):
                        out.append((f"{feature}%{modulus}=={residue}", {"kind": "eq", "a": {"kind": "mod", "a": {"kind": "get", "root": "env", "path": feature}, "b": {"kind": "literal", "value": modulus}}, "b": {"kind": "literal", "value": residue}}))
        numeric = tuple(f for f in features if rows and all(isinstance(dict(r.get("representation") or {}).get(f), (int, bool)) for r in rows))
        for i, left in enumerate(numeric):
            for right in numeric[i + 1:]:
                for form in ("add", "sub", "mul"):
                    if form not in forms:
                        continue
                    expr = {"kind": form, "a": {"kind": "get", "root": "env", "path": left}, "b": {"kind": "get", "root": "env", "path": right}}
                    if "mod" in forms:
                        for modulus in self.residue_basis:
                            for residue in range(modulus):
                                out.append((f"({left}{form}{right})%{modulus}=={residue}", {"kind": "eq", "a": {"kind": "mod", "a": expr, "b": {"kind": "literal", "value": modulus}}, "b": {"kind": "literal", "value": residue}}))
        seen: set[str] = set(); deduped = []
        for label, expr in out:
            sig = _stable(expr)
            if sig in seen: continue
            seen.add(sig); deduped.append((label, expr))
            if len(deduped) >= self.search_budget: break
        return tuple(deduped)

    def propose(self, cases: Iterable[Mapping[str, Any]], *, existing_names: Iterable[str] = ()) -> DistinctionProposal | None:
        witnesses = self.collisions(cases)
        if not witnesses:
            return None
        existing = set(map(str, existing_names))
        ranked: list[tuple[float, int, int, str, TypeField, tuple[str, ...]]] = []
        for field in self._generated_candidates(witnesses):
            if field.name in existing:
                continue
            separating = []
            values = set()
            for idx, witness in enumerate(witnesses):
                lv = self._eval(field.extractor, witness.left)
                rv = self._eval(field.extractor, witness.right)
                values.add(repr(lv)); values.add(repr(rv))
                if lv != rv:
                    separating.append(idx)
            if not separating:
                continue
            coverage = len(separating) / len(witnesses)
            complexity = len(json.dumps(field.extractor, sort_keys=True, default=str))
            novelty = coverage + min(0.25, len(values) / max(4.0, len(witnesses) * 2.0))
            ranked.append((novelty, len(separating), -complexity, field.name, field, tuple(map(str, separating))))
        if not ranked:
            return None
        # Do not let a high-cardinality composite win merely because it memorizes
        # witness pairs.  Primitive distinctions are allowed to accumulate across
        # rounds; only when no primitive can separate any remaining collision does
        # the generator escalate to a composed observation.
        primitive_ranked = [row for row in ranked if row[4].semantic_role not in {"composed_distinction", "generated_composition"}]
        pool = primitive_ranked or ranked
        _, score, _, _, field, generated_from = max(pool)
        return DistinctionProposal(field, score, len(witnesses), score / len(witnesses), generated_from, witnesses)
