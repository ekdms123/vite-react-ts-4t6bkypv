"""Advisory file locking with observable unavailability.

The previous inline pattern was `except ImportError: pass`, which silently
reopened the very TOCTOU window the call site's own comment described. A lock
that is not held is an execution fact, so it is recorded rather than swallowed.
"""
from __future__ import annotations

import os
import sys
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

try:  # POSIX in the current runtime; guarded for portability.
    import fcntl  # type: ignore
except Exception:  # pragma: no cover - non-POSIX fallback
    fcntl = None  # type: ignore

_private_worker = sys.platform == 'emscripten' and os.environ.get('JIGAEWOL_PRIVATE_MEMFS') == '1'
_worker_locks = {}
LOCK_BACKEND = "fcntl.flock" if fcntl is not None else "private_memfs.threading.RLock" if _private_worker else "none"
LOCK_AVAILABLE = fcntl is not None or _private_worker


def lock_status() -> dict[str, object]:
    """Observable lock capability, for receipts and diagnostics."""
    return {
        "lock_backend": LOCK_BACKEND,
        "lock_available": LOCK_AVAILABLE,
        "lock_unavailable": not LOCK_AVAILABLE,
        "mutual_exclusion_proven": LOCK_AVAILABLE,
        "lock_scope": "native_processes" if fcntl is not None else "one_worker_private_memfs" if _private_worker else "unavailable",
    }


@contextmanager
def exclusive_lock(path: str | Path) -> Iterator[dict[str, object]]:
    """Hold an exclusive advisory lock on ``path`` for the duration of the block.

    Yields the lock status so a caller can bind it into its own receipt instead of
    assuming mutual exclusion it may not have.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    status = lock_status()
    if fcntl is None and _private_worker:
        with _worker_locks.setdefault(str(target.resolve()), threading.RLock()):
            yield status
        return
    if fcntl is None:
        marker = target.with_suffix(target.suffix + ".lock_unavailable")
        try:
            marker.write_text(LOCK_BACKEND + "\n", encoding="utf-8")
        except OSError:
            pass
        yield status
        return
    fh = target.open("a+")
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try:
            yield status
        finally:
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
    finally:
        fh.close()
