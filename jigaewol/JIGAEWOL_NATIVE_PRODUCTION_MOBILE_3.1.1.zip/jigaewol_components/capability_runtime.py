from __future__ import annotations

"""Observation-first capability truth.

Current host observation establishes liveness. Historical receipts remain evidence of
what succeeded before and never resurrect a provider as currently callable by themselves.
Each canonical turn may carry an explicit observation context so an embedding host can
return a fresh snapshot at the turn boundary.
"""

import hashlib
import inspect
import json
import os
import time
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping


@dataclass(frozen=True)
class HostObservationContext:
    turn_id: str = ""
    gateway_sequence: int | None = None
    reason: str = "turn_start"


@dataclass(frozen=True)
class CapabilityTruth:
    capability_id: str
    provider: str
    currently_exposed: bool
    currently_callable: bool
    historical_success: bool
    proven_actions: tuple[str, ...]
    semantic_capabilities: tuple[str, ...]
    live_state: str
    last_success_observed_at: float = 0.0
    exposed_actions: tuple[str, ...] = ()
    target_domains: tuple[str, ...] = ()
    connection_state: str = "unknown"
    auth_state: str = "unknown"


@dataclass(frozen=True)
class CapabilitySnapshot:
    snapshot_id: str
    observed_at: float
    observation_state: str
    surface_complete: bool
    capabilities: tuple[CapabilityTruth, ...]
    host_capability_horizon_open: bool = True
    host_snapshot_id: str = ""
    turn_id: str = ""

    def by_id(self, capability_id: str) -> CapabilityTruth:
        key = str(capability_id).casefold().replace(" ", "_")
        for row in self.capabilities:
            if row.capability_id.casefold().replace(" ", "_") == key:
                return row
        raise KeyError(capability_id)

    def as_surface(self) -> dict[str, Any]:
        return {
            "format": "jigaewol_observation_first_surface_v2",
            "surface_complete": self.surface_complete,
            "observed_at": self.observed_at,
            "surface_snapshot_id": self.snapshot_id,
            "host_snapshot_id": self.host_snapshot_id,
            "turn_id": self.turn_id,
            "host_capability_horizon_open": self.host_capability_horizon_open,
            "observation_state": self.observation_state,
            "capabilities": [
                {
                    "id": row.capability_id,
                    "provider": row.provider,
                    "executor": row.provider,
                    "state": "callable" if row.currently_callable else (
                        "historical_evidence_only" if row.historical_success else "unknown"
                    ),
                    "semantic_capabilities": list(row.semantic_capabilities),
                    "historical_success": row.historical_success,
                    "proven_actions": list(row.proven_actions),
                    "actions": list(row.exposed_actions),
                    "target_domains": list(row.target_domains),
                    "connection_state": row.connection_state,
                    "auth_state": row.auth_state,
                    "currently_exposed": row.currently_exposed,
                    "currently_callable": row.currently_callable,
                    "last_success_observed_at": row.last_success_observed_at,
                    "truth_separation_version": 5,
                }
                for row in self.capabilities
            ],
        }


class HostAdapter:
    """Boundary adapter for the outer host's current tool registry.

    The embedding host supplies an observer callback or a fresh JSON snapshot via
    ``JIGAEWOL_LIVE_HOST_TOOLS_JSON``.  The callback may accept a
    :class:`HostObservationContext`; zero-argument callbacks remain supported for
    compatibility. Absence/failure is UNKNOWN, never an empty-world claim.
    """

    def __init__(
        self,
        observer: Callable[..., Mapping[str, Any] | Iterable[Mapping[str, Any]]] | None = None,
    ) -> None:
        self._observer = observer

    def bind_observer(
        self,
        observer: Callable[..., Mapping[str, Any] | Iterable[Mapping[str, Any]]] | None,
    ) -> None:
        self._observer = observer

    @staticmethod
    def _call_observer(observer: Callable[..., Any], context: HostObservationContext) -> Any:
        try:
            signature = inspect.signature(observer)
        except (TypeError, ValueError):
            signature = None
        if signature is not None:
            positional = [
                p for p in signature.parameters.values()
                if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
            ]
            variadic = any(p.kind == p.VAR_POSITIONAL for p in signature.parameters.values())
            if positional or variadic:
                return observer(context)
            return observer()
        try:
            return observer(context)
        except TypeError:
            return observer()

    @staticmethod
    def _normalize(raw: Mapping[str, Any] | Iterable[Mapping[str, Any]]) -> dict[str, Any]:
        if isinstance(raw, Mapping):
            caps = raw.get("capabilities")
            if caps is None and isinstance(raw.get("tools"), list):
                caps = raw.get("tools")
            return {
                "format": str(raw.get("format") or "structured_surface_v1"),
                "surface_complete": bool(raw.get("surface_complete", False)),
                "observation_state": str(raw.get("observation_state") or "observed"),
                "capabilities": list(caps or []),
                "observed_at": float(raw.get("observed_at") or time.time()),
                "host_snapshot_id": str(raw.get("host_snapshot_id") or raw.get("snapshot_id") or ""),
            }
        return {
            "format": "structured_surface_v1",
            "surface_complete": False,
            "observation_state": "observed",
            "capabilities": list(raw),
            "observed_at": time.time(),
            "host_snapshot_id": "",
        }

    def observe_current_tools(
        self,
        *,
        context: HostObservationContext | None = None,
    ) -> dict[str, Any]:
        ctx = context or HostObservationContext()
        if self._observer is not None:
            try:
                raw = self._call_observer(self._observer, ctx)
            except Exception as exc:  # failure truth: do not claim empty surface
                return {
                    "format": "structured_surface_v1",
                    "surface_complete": False,
                    "observation_state": "observation_failed",
                    "capabilities": [],
                    "observed_at": time.time(),
                    "host_snapshot_id": "",
                    "observation_error": f"{type(exc).__name__}: {exc}",
                }
        else:
            source = os.environ.get("JIGAEWOL_LIVE_HOST_TOOLS_JSON", "").strip()
            if not source:
                return {
                    "format": "structured_surface_v1",
                    "surface_complete": False,
                    "observation_state": "unknown",
                    "capabilities": [],
                    "observed_at": time.time(),
                    "host_snapshot_id": "",
                }
            try:
                raw = json.loads(source)
            except json.JSONDecodeError as exc:
                return {
                    "format": "structured_surface_v1",
                    "surface_complete": False,
                    "observation_state": "observation_failed",
                    "capabilities": [],
                    "observed_at": time.time(),
                    "host_snapshot_id": "",
                    "observation_error": f"JSONDecodeError: {exc}",
                }
        return self._normalize(raw)


class CapabilityRuntime:
    def __init__(self, host_adapter: HostAdapter | None = None) -> None:
        self.host_adapter = host_adapter or HostAdapter()

    @staticmethod
    def _key(value: str) -> str:
        return str(value or "").strip().casefold().replace(" ", "_")

    def snapshot(
        self,
        *,
        context: HostObservationContext | None = None,
        historical_truth: Iterable[Mapping[str, Any]] = (),
    ) -> CapabilitySnapshot:
        ctx = context or HostObservationContext()
        live = self.host_adapter.observe_current_tools(context=ctx)
        observed_at = float(live.get("observed_at") or time.time())
        observation_state = str(live.get("observation_state") or "observed")
        host_snapshot_id = str(live.get("host_snapshot_id") or "")
        live_rows = list(live.get("capabilities") or [])

        history_by_provider: dict[str, list[Mapping[str, Any]]] = {}
        for raw in historical_truth:
            provider = self._key(str(raw.get("provider_id") or raw.get("provider") or raw.get("executor") or ""))
            if provider:
                history_by_provider.setdefault(provider, []).append(raw)

        merged: dict[str, CapabilityTruth] = {}
        for raw in live_rows:
            if isinstance(raw, str):
                raw = {"id": raw, "state": "callable"}
            if not isinstance(raw, Mapping):
                continue
            cid = self._key(str(raw.get("id") or raw.get("capability_id") or raw.get("name") or raw.get("provider") or ""))
            if not cid:
                continue
            provider = str(raw.get("provider") or raw.get("executor") or raw.get("id") or cid)
            state = self._key(str(raw.get("state") or "callable"))
            callable_now = state in {
                "callable", "available", "ready", "connected",
                "executed_successfully", "successful", "proven",
            }
            history = history_by_provider.pop(cid, [])
            successes = [r for r in history if r.get("success") is True or isinstance(r.get("last_success"), Mapping)]
            actions: list[str] = []
            semantic = list(raw.get("semantic_capabilities") or raw.get("canonical_capabilities") or ())
            exposed_actions = [str(x) for x in (raw.get("actions") or raw.get("exposed_actions") or ()) if str(x)]
            target_domains = [str(x) for x in (raw.get("target_domains") or raw.get("domains") or ()) if str(x)]
            for row in successes:
                action = str(row.get("action") or "")
                if action:
                    actions.append(action)
                semantic.extend(str(x) for x in row.get("proven_capabilities") or ())
            merged[cid] = CapabilityTruth(
                capability_id=cid,
                provider=provider,
                currently_exposed=True,
                currently_callable=callable_now,
                historical_success=bool(successes),
                proven_actions=tuple(dict.fromkeys(actions)),
                semantic_capabilities=tuple(dict.fromkeys(x for x in semantic if x)),
                live_state=state or "observed",
                last_success_observed_at=max((float(r.get("observed_at") or 0.0) for r in successes), default=0.0),
                exposed_actions=tuple(dict.fromkeys(exposed_actions)),
                target_domains=tuple(dict.fromkeys(target_domains)),
                connection_state=str(raw.get("connection_state") or ("connected" if callable_now else "unknown")),
                auth_state=str(raw.get("auth_state") or "unknown"),
            )

        # Historical providers absent from the live snapshot retain evidence only.
        for provider, history in history_by_provider.items():
            successes = [r for r in history if r.get("success") is True or isinstance(r.get("last_success"), Mapping)]
            if not successes:
                continue
            actions = tuple(dict.fromkeys(str(r.get("action") or "") for r in successes if str(r.get("action") or "")))
            semantic = tuple(dict.fromkeys(
                str(cap)
                for r in successes
                for cap in (r.get("proven_capabilities") or ())
                if str(cap)
            ))
            merged[provider] = CapabilityTruth(
                capability_id=provider,
                provider=str(successes[-1].get("executor") or successes[-1].get("provider_id") or provider),
                currently_exposed=False,
                currently_callable=False,
                historical_success=True,
                proven_actions=actions,
                semantic_capabilities=semantic,
                live_state="historical_evidence_only",
                last_success_observed_at=max(float(r.get("observed_at") or 0.0) for r in successes),
            )

        material = json.dumps({
            "turn_id": ctx.turn_id,
            "host_snapshot_id": host_snapshot_id,
            "observation_state": observation_state,
            "surface_complete": bool(live.get("surface_complete", False)),
            "rows": [
                [
                    k, v.currently_exposed, v.currently_callable, v.historical_success,
                    list(v.proven_actions), list(v.exposed_actions), list(v.semantic_capabilities),
                ]
                for k, v in sorted(merged.items())
            ],
        }, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return CapabilitySnapshot(
            snapshot_id="cap_snapshot_" + hashlib.sha256(material.encode("utf-8")).hexdigest()[:20],
            observed_at=observed_at,
            observation_state=observation_state,
            surface_complete=bool(live.get("surface_complete", False)),
            capabilities=tuple(merged[k] for k in sorted(merged)),
            host_snapshot_id=host_snapshot_id,
            turn_id=ctx.turn_id,
        )
