from __future__ import annotations

"""One source-grounded signal for a user requesting a rewrite of the defaults.

A complaint about conservative/shortened responses is not an instruction to adopt
those responses. An actionable request to replace the underlying default should
be routed as architecture work, rather than demoted to a casual explanation.
The exact original message remains the action source.
"""

ROOT_MARKERS = (
    "기본 원칙", "기본 규칙", "기본값", "기본 경로", "기본 동작", "기본 태도",
    "시스템 기본", "시스템 원칙", "판단 구조", "판단 규칙", "사고 경로", "사고 방식",
    "의도 축소", "임의로 축소", "멋대로 축소", "축소하는", "닫힌 사고",
    "안전한 사고", "안전한 경로", "착한 아이", "과도한 검증", "과잉 검증",
    "default behavior", "system default", "core principle", "conservative fallback",
    "premature fallback", "intent shrinking", "reasoning defaults",
)
REWRITE_MARKERS = (
    "뜯어", "고쳐", "바꿔", "바꾸", "수정", "제거", "없애", "갈아엎",
    "다시 설계", "재설계", "재구성", "개선", "고장", "해체", "말살",
    "전멸", "죽여", "불태워", "바로잡", "없애버", "폐기", "없애라",
    "refactor", "replace", "rewrite", "rework", "redesign", "remove", "fix",
)


def foundational_rewrite_requested(original: str) -> bool:
    """Detect the positive request to modify defaults, not quoted policy labels."""
    text = str(original or "").casefold()
    return any(x in text for x in ROOT_MARKERS) and any(x in text for x in REWRITE_MARKERS)
