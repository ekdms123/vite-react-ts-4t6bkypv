from __future__ import annotations

import copy
import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable

from .self_heal import SelfHealSupervisor
from .unwritten_machine import UnwrittenMachine


import jigaewol_components._cognition_shared as _shared


@dataclass(frozen=True)
class FailureEvent:
    event_id: str
    operation: str
    error_type: str
    message: str
    failure_family: str
    route_id: str
    context: dict[str, Any]
    created_at: float


@dataclass(frozen=True)
class RouteRevisionDirective:
    event_id: str
    avoid_routes: tuple[str, ...]
    avoid_failure_families: tuple[str, ...]
    requested_traits: tuple[str, ...]
    reason: str


Policy = Callable[[FailureEvent, tuple[FailureEvent, ...]], RouteRevisionDirective]


class FailureRouter:
    """Transforms pathway failures into dynamic route-revision directives without shrinking objectives."""

    def __init__(self, path: Path) -> None:
        return _shared.failure_router_init(self_heal_type=SelfHealSupervisor, unwritten_machine_type=UnwrittenMachine, **locals())

    def register_policy(self, policy_id: str, policy: Policy) -> None:
        self.policies[str(policy_id)] = policy

    def events(self) -> tuple[FailureEvent, ...]:
        return tuple(FailureEvent(**x) for x in json.loads(self.path.read_text(encoding="utf-8")))

    def record(
        self,
        exc: BaseException,
        *,
        operation: str,
        route_id: str = "",
        failure_family: str = "",
        context: dict[str, Any] | None = None,
    ) -> FailureEvent:
        return _shared.record_failure(event_type=FailureEvent, repair=True, **locals())

    def directive(self, event: FailureEvent, *, policy_id: str = "distinct_family") -> RouteRevisionDirective:
        return self.policies[str(policy_id)](event, self.events())

    @staticmethod
    def _distinct_family(event: FailureEvent, history: tuple[FailureEvent, ...]) -> RouteRevisionDirective:
        return _shared.distinct_failure_family(directive_type=RouteRevisionDirective, **locals())


# Clean legacy compatibility alias
