from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from types import ModuleType
from typing import Any, Iterator

from .runtime_state import RuntimeSnapshot, StateConflict, VersionedStateStore


@dataclass(frozen=True)
class LoadedGeneration:
    generation: int
    parent_generation: int | None
    source_path: str
    source_sha256: str
    module_name: str
    state_schema: int
    created_at: float
    instance: Any


@dataclass(frozen=True)
class MutationRecord:
    generation: int
    parent_generation: int | None
    source_sha256: str
    trigger: str
    expected_gain: str
    created_at: float
    status: str


class DynamicPythonLoader:
    """Loads a fresh Python module dynamically under a generation-specific namespace."""

    def load(self, path: Path, *, generation: int, class_name: str) -> LoadedGeneration:
        raw = path.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        module_name = f"jigaewol_dynamic_{path.stem}_g{generation}_{sha[:10]}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"unable to build module spec for {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        cls = getattr(module, class_name)
        instance = cls()
        return LoadedGeneration(
            generation=generation,
            parent_generation=None,
            source_path=str(path),
            source_sha256=sha,
            module_name=module_name,
            state_schema=int(getattr(module, "STATE_SCHEMA", 1)),
            created_at=time.time(),
            instance=instance,
        )

    def load_module(self, generation: LoadedGeneration) -> ModuleType:
        return sys.modules[generation.module_name]


class VersionedHotSwapSlot:
    """Generation slot coordinating concurrent active and retired executions safely."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._current: LoadedGeneration | None = None
        self._leases: dict[int, int] = {}
        self._retired: dict[int, LoadedGeneration] = {}

    @property
    def current(self) -> LoadedGeneration | None:
        with self._lock:
            return self._current

    def activate(self, generation: LoadedGeneration) -> None:
        with self._lock:
            if self._current is not None:
                self._retired[self._current.generation] = self._current
            self._current = generation
            self._leases.setdefault(generation.generation, 0)
            self._collect()

    @contextmanager
    def lease(self) -> Iterator[LoadedGeneration]:
        with self._lock:
            if self._current is None:
                raise RuntimeError("no active generation")
            generation = self._current
            self._leases[generation.generation] = self._leases.get(generation.generation, 0) + 1
        try:
            yield generation
        finally:
            with self._lock:
                self._leases[generation.generation] -= 1
                self._collect()

    def _collect(self) -> None:
        for gid in tuple(self._retired):
            if self._leases.get(gid, 0) <= 0:
                self._retired.pop(gid, None)
                self._leases.pop(gid, None)

    def live_generations(self) -> tuple[int, ...]:
        with self._lock:
            ids = set(self._retired)
            if self._current is not None:
                ids.add(self._current.generation)
            return tuple(sorted(ids))


class MutationLineage:
    """Persistent generation lineage and revision history."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"records": []})

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def append(self, record: MutationRecord) -> None:
        data = self._read()
        data.setdefault("records", []).append(asdict(record))
        self._write(data)

    def records(self) -> tuple[MutationRecord, ...]:
        return tuple(MutationRecord(**row) for row in self._read().get("records", []))

    def recent_hashes(self, count: int | None = None) -> tuple[str, ...]:
        rows = self.records()
        if count is None:
            return tuple(x.source_sha256 for x in rows)
        return tuple(x.source_sha256 for x in rows[-max(1, int(count)):])

    def oscillation_signal(self) -> bool:
        hashes = self.recent_hashes(4)
        return len(hashes) == 4 and hashes[0] == hashes[2] and hashes[1] == hashes[3] and hashes[0] != hashes[1]


class SelfModifyingRuntime:
    """Hot-swappable modular runtime with state continuity and recoverable revisions."""

    def __init__(self, root: Path, *, class_name: str = "ReasoningCore") -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.generations_dir = self.root / "generations"
        self.generations_dir.mkdir(parents=True, exist_ok=True)
        self.transactions_dir = self.root / "transactions"
        self.transactions_dir.mkdir(parents=True, exist_ok=True)
        self.class_name = class_name
        self.loader = DynamicPythonLoader()
        self.slot = VersionedHotSwapSlot()
        self.state = VersionedStateStore(self.root / "runtime_state.json")
        self.lineage = MutationLineage(self.root / "lineage.json")
        self._rewrite_lock = threading.RLock()

    def _next_generation(self) -> int:
        records = self.lineage.records()
        return (max((x.generation for x in records), default=0) + 1)

    def _write_source(self, generation: int, source: str) -> Path:
        path = self.generations_dir / f"generation_{generation}.py"
        path.write_text(source, encoding="utf-8")
        return path

    def _module_for(self, loaded: LoadedGeneration) -> ModuleType:
        return self.loader.load_module(loaded)

    def bootstrap(self, source: str, *, initial_state: dict[str, Any]) -> LoadedGeneration:
        with self._rewrite_lock:
            if self.slot.current is not None:
                return self.slot.current
            gid = self._next_generation()
            path = self._write_source(gid, source)
            loaded = self.loader.load(path, generation=gid, class_name=self.class_name)
            loaded = replace(loaded, parent_generation=None)
            snap = self.state.snapshot()
            self.state.commit(
                expected_version=snap.version,
                payload=copy.deepcopy(initial_state),
                generation=gid,
                event={"kind": "bootstrap", "source_sha256": loaded.source_sha256},
            )
            self.slot.activate(loaded)
            self.lineage.append(
                MutationRecord(gid, None, loaded.source_sha256, "bootstrap", "initial runtime", time.time(), "active")
            )
            return loaded

    def step(self, payload: dict[str, Any] | None = None) -> RuntimeSnapshot:
        with self.slot.lease() as generation:
            snapshot = self.state.snapshot()
            if snapshot.generation != generation.generation:
                raise StateConflict(
                    f"generation/state mismatch: slot={generation.generation} state={snapshot.generation}"
                )
            next_payload = generation.instance.step(copy.deepcopy(snapshot.payload), copy.deepcopy(payload or {}))
            if not isinstance(next_payload, dict):
                raise TypeError("ReasoningCore.step must return a dict state")
            return self.state.commit(
                expected_version=snapshot.version,
                payload=next_payload,
                generation=generation.generation,
                event={"kind": "step", "module": generation.module_name},
            )

    def rewrite(
        self,
        source: str,
        *,
        trigger: str,
        expected_gain: str,
        shadow_payload: dict[str, Any] | None = None,
    ) -> LoadedGeneration:
        with self._rewrite_lock:
            current = self.slot.current
            if current is None:
                raise RuntimeError("bootstrap the runtime before rewrite")
            gid = self._next_generation()
            path = self._write_source(gid, source)
            candidate = self.loader.load(path, generation=gid, class_name=self.class_name)
            candidate = replace(candidate, parent_generation=current.generation)
            module = self._module_for(candidate)
            snapshot = self.state.snapshot()
            migrated = copy.deepcopy(snapshot.payload)
            migrate = getattr(module, "migrate_state", None)
            if migrate is not None:
                migrated = migrate(migrated, current.state_schema, candidate.state_schema)
            if not isinstance(migrated, dict):
                raise TypeError("migrate_state must return a dict")

            shadow = candidate.instance.step(copy.deepcopy(migrated), copy.deepcopy(shadow_payload or {}))
            if not isinstance(shadow, dict):
                raise TypeError("candidate ReasoningCore.step must return a dict")

            transaction = self.transactions_dir / f"rewrite_g{gid}.json"
            transaction.write_text(
                json.dumps(
                    {
                        "status": "prepared",
                        "from_generation": current.generation,
                        "to_generation": gid,
                        "expected_state_version": snapshot.version,
                        "source_sha256": candidate.source_sha256,
                        "trigger": trigger,
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )

            self.state.commit(
                expected_version=snapshot.version,
                payload=migrated,
                generation=gid,
                event={"kind": "rewrite", "from_generation": current.generation, "source_sha256": candidate.source_sha256},
            )
            self.slot.activate(candidate)
            self.lineage.append(
                MutationRecord(gid, current.generation, candidate.source_sha256, trigger, expected_gain, time.time(), "active")
            )
            transaction.write_text(
                json.dumps(
                    {
                        "status": "committed",
                        "from_generation": current.generation,
                        "to_generation": gid,
                        "source_sha256": candidate.source_sha256,
                        "trigger": trigger,
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            return candidate

    def recover(self) -> LoadedGeneration:
        snapshot = self.state.snapshot()
        gid = snapshot.generation
        if gid <= 0:
            raise RuntimeError("no persisted generation to recover")
        path = self.generations_dir / f"generation_{gid}.py"
        loaded = self.loader.load(path, generation=gid, class_name=self.class_name)
        parent = None
        for record in self.lineage.records():
            if record.generation == gid:
                parent = record.parent_generation
                break
        loaded = replace(loaded, parent_generation=parent)
        self.slot.activate(loaded)
        return loaded
