from __future__ import annotations

import json
import os
import signal
import subprocess
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Sequence

from .execution_plane import ExecutionPlane, ExecutionReceipt, ExecutionRequest


@dataclass(frozen=True)
class ServiceLease:
    service_id: str
    pid: int
    argv: tuple[str, ...]
    cwd: str
    stdout_path: str
    stderr_path: str
    started_at: float


class SyntheticWorkstation:
    """Persistent task computer built from ordinary host primitives.

    It owns files, cwd/env state through ExecutionPlane, plus long-lived services.
    It is intentionally model-independent and can be used from a mobile chat host.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.plane = ExecutionPlane(self.root / "workspace")
        self.services_dir = self.root / "services"
        self.services_dir.mkdir(exist_ok=True)
        self.state_path = self.root / "services.json"
        if not self.state_path.exists():
            self._write_state({"services": {}})

    def _read_state(self) -> dict[str, Any]:
        return json.loads(self.state_path.read_text(encoding="utf-8"))

    def _write_state(self, data: dict[str, Any]) -> None:
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.state_path)

    def run(self, argv: Sequence[str], *, cwd: str | None = None, timeout_s: float = 60.0, env: dict[str, str] | None = None) -> ExecutionReceipt:
        return self.plane.run_resilient(ExecutionRequest(tuple(argv), cwd=cwd, env=env, timeout_s=timeout_s))

    def write_text(self, relative_path: str, content: str) -> Path:
        path = (self.plane.root / relative_path).resolve()
        if self.plane.root not in path.parents and path != self.plane.root:
            raise ValueError("path escapes workstation")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def read_text(self, relative_path: str) -> str:
        path = (self.plane.root / relative_path).resolve()
        if self.plane.root not in path.parents and path != self.plane.root:
            raise ValueError("path escapes workstation")
        return path.read_text(encoding="utf-8")

    def launch_service(self, argv: Sequence[str], *, cwd: str | None = None, env: dict[str, str] | None = None) -> ServiceLease:
        if not argv:
            raise ValueError("service argv cannot be empty")
        service_id = f"service_{uuid.uuid4().hex[:16]}"
        service_root = self.services_dir / service_id
        service_root.mkdir(parents=True)
        stdout_path = service_root / "stdout.log"
        stderr_path = service_root / "stderr.log"
        target_cwd = self.plane._resolve_cwd(cwd)
        process_env = os.environ.copy()
        process_env.update(self.plane._read_state().get("env", {}))
        process_env.update({str(k): str(v) for k, v in (env or {}).items()})
        out = stdout_path.open("ab")
        err = stderr_path.open("ab")
        proc = subprocess.Popen(
            list(argv),
            cwd=target_cwd,
            env=process_env,
            stdout=out,
            stderr=err,
            start_new_session=True,
        )
        out.close(); err.close()
        lease = ServiceLease(service_id, proc.pid, tuple(argv), str(target_cwd), str(stdout_path), str(stderr_path), time.time())
        state = self._read_state()
        state.setdefault("services", {})[service_id] = asdict(lease)
        self._write_state(state)
        return lease

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        """Return process liveness without mistaking a zombie for a worker.

        ``kill(pid, 0)`` succeeds for zombie children on POSIX.  A worker supervisor
        must treat that state as dead or it will never recover crashed sessions.
        ``/proc`` is used when available; other platforms retain the portable probe.
        """
        try:
            os.kill(int(pid), 0)
        except OSError:
            return False
        stat = Path(f"/proc/{int(pid)}/stat")
        if stat.exists():
            try:
                parts = stat.read_text(encoding="utf-8", errors="replace").split()
                if len(parts) > 2 and parts[2] == "Z":
                    return False
            except OSError:
                pass
        return True

    def service_status(self, service_id: str) -> dict[str, Any]:
        row = self._read_state().get("services", {}).get(service_id)
        if row is None:
            raise KeyError(service_id)
        pid = int(row["pid"])
        alive = self._pid_alive(pid)
        return {
            **row,
            "alive": alive,
            "stdout": Path(row["stdout_path"]).read_text(encoding="utf-8", errors="replace") if Path(row["stdout_path"]).exists() else "",
            "stderr": Path(row["stderr_path"]).read_text(encoding="utf-8", errors="replace") if Path(row["stderr_path"]).exists() else "",
        }

    def stop_service(self, service_id: str, *, grace_s: float = 2.0) -> dict[str, Any]:
        row = self._read_state().get("services", {}).get(service_id)
        if row is None:
            raise KeyError(service_id)
        pid = int(row["pid"])
        try:
            os.killpg(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        deadline = time.time() + grace_s
        while time.time() < deadline:
            try:
                os.kill(pid, 0)
            except OSError:
                break
            time.sleep(0.05)
        try:
            os.killpg(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        return self.service_status(service_id)
