from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class ContinuityTask:
    task_id: str
    objective: str
    objective_sha256: str
    status: str
    phase: str
    next_cycle: int
    completed_steps: tuple[dict[str, Any], ...]
    remaining_steps: tuple[dict[str, Any], ...]
    artifacts: dict[str, str]
    receipts: tuple[str, ...]
    state: dict[str, Any]
    attempts: int
    created_at: float
    updated_at: float
    last_error: str | None = None


class TurnContinuityController:
    """Durable write-ahead continuity controller preserving state across boundaries."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"schema": 1, "tasks": {}, "active_task_id": None})
        self._recover_running_tasks()

    @staticmethod
    def _objective_sha(objective: str) -> str:
        return hashlib.sha256(str(objective).encode("utf-8")).hexdigest()

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)

    def _recover_running_tasks(self) -> None:
        data = self._read()
        changed = False
        now = time.time()
        for raw in data.get("tasks", {}).values():
            if raw.get("status") in {"running", "resumed"}:
                raw["status"] = "interrupted"
                raw["phase"] = raw.get("phase") or "unknown"
                raw["updated_at"] = now
                raw.setdefault("state", {})["interruption_detected_at"] = now
                changed = True
        if changed:
            self._write(data)

    @staticmethod
    def _inflate(raw: dict[str, Any]) -> ContinuityTask:
        row = dict(raw)
        row["completed_steps"] = tuple(row.get("completed_steps", ()))
        row["remaining_steps"] = tuple(row.get("remaining_steps", ()))
        row["receipts"] = tuple(row.get("receipts", ()))
        return ContinuityTask(**row)

    def unfinished(self) -> tuple[ContinuityTask, ...]:
        data = self._read()
        rows = [r for r in data.get("tasks", {}).values() if r.get("status") not in ("completed", "abandoned")]
        rows.sort(key=lambda r: float(r.get("updated_at", 0.0)))
        return tuple(self._inflate(x) for x in rows)

    def latest_unfinished(self, *, workstream_key: str | None = None) -> ContinuityTask | None:
        rows = list(self.unfinished())
        if workstream_key:
            rows = [x for x in rows if str(x.state.get("workstream_key", "")) == str(workstream_key)]
        return rows[-1] if rows else None

    def start_or_resume(
        self,
        *,
        objective: str,
        planned_steps: Iterable[dict[str, Any]] = (),
        prefer_unfinished: bool = True,
        state: dict[str, Any] | None = None,
        workstream_key: str | None = None,
        strict_workstream: bool = False,
    ) -> ContinuityTask:
        data = self._read()
        now = time.time()
        objective_sha = self._objective_sha(objective)
        unfinished = None
        if prefer_unfinished:
            candidates = list(self.unfinished())
            if workstream_key:
                candidates = [x for x in candidates if str(x.state.get("workstream_key", "")) == str(workstream_key)]
            elif strict_workstream:
                candidates = [x for x in candidates if x.objective_sha256 == objective_sha]
            unfinished = candidates[-1] if candidates else None
        if unfinished is not None:
            raw = data["tasks"][unfinished.task_id]
            raw["status"] = "resumed"
            raw["attempts"] = int(raw.get("attempts", 1)) + 1
            raw["updated_at"] = now
            raw.setdefault("state", {})["resume_objective_delta"] = str(objective)
            if workstream_key:
                raw["state"]["workstream_key"] = str(workstream_key)
            raw["state"].update(dict(state or {}))
            data["active_task_id"] = unfinished.task_id
            self._write(data)
            return self._inflate(raw)

        task_id = f"task_{uuid.uuid4().hex[:16]}"
        raw = asdict(ContinuityTask(
            task_id=task_id,
            objective=str(objective),
            objective_sha256=self._objective_sha(objective),
            status="running",
            phase="initialized",
            next_cycle=0,
            completed_steps=(),
            remaining_steps=tuple(dict(x) for x in planned_steps),
            artifacts={},
            receipts=(),
            state={**dict(state or {}), **({"workstream_key": str(workstream_key)} if workstream_key else {})},
            attempts=1,
            created_at=now,
            updated_at=now,
            last_error=None,
        ))
        data.setdefault("tasks", {})[task_id] = raw
        data["active_task_id"] = task_id
        self._write(data)
        return self._inflate(raw)

    def checkpoint(
        self,
        task_id: str,
        *,
        phase: str,
        next_cycle: int | None = None,
        completed_step: dict[str, Any] | None = None,
        remaining_steps: Iterable[dict[str, Any]] | None = None,
        artifacts: dict[str, str] | None = None,
        receipts: Iterable[str] = (),
        state: dict[str, Any] | None = None,
    ) -> ContinuityTask:
        data = self._read()
        raw = data["tasks"][str(task_id)]
        if raw.get("status") in ("completed", "abandoned"):
            raise RuntimeError(f"cannot checkpoint terminal task: {task_id}")
        raw["status"] = "running"
        raw["phase"] = str(phase)
        if next_cycle is not None:
            raw["next_cycle"] = int(next_cycle)
        if completed_step is not None:
            raw.setdefault("completed_steps", []).append(dict(completed_step))
        if remaining_steps is not None:
            raw["remaining_steps"] = [dict(x) for x in remaining_steps]
        raw.setdefault("artifacts", {}).update(dict(artifacts or {}))
        known_receipts = list(raw.get("receipts", []))
        for receipt in map(str, receipts):
            if receipt not in known_receipts:
                known_receipts.append(receipt)
        raw["receipts"] = known_receipts
        raw.setdefault("state", {}).update(dict(state or {}))
        raw["updated_at"] = time.time()
        raw["last_error"] = None
        data["active_task_id"] = str(task_id)
        self._write(data)
        return self._inflate(raw)

    def fail(self, task_id: str, *, phase: str, error: str, state: dict[str, Any] | None = None) -> ContinuityTask:
        data = self._read()
        raw = data["tasks"][str(task_id)]
        raw["status"] = "interrupted"
        raw["phase"] = str(phase)
        raw["last_error"] = str(error)
        raw.setdefault("state", {}).update(dict(state or {}))
        raw["updated_at"] = time.time()
        self._write(data)
        return self._inflate(raw)

    def complete(
        self, task_id: str, *, receipts: Iterable[str] = (), state: dict[str, Any] | None = None,
        completion_proof: dict[str, Any] | None = None,
    ) -> ContinuityTask:
        """Terminally close a user objective only with separate completion evidence.

        Route success, candidate generation, response release, or planner confidence are
        deliberately insufficient.  Callers must provide an observed Work-level proof
        so no internal component can turn its own notion of ``done`` into user-goal
        deletion.
        """
        proof = dict(completion_proof or {})
        evidence_refs = tuple(str(x) for x in (proof.get("evidence_refs") or ()) if str(x))
        if proof.get("proven") is not True or not evidence_refs:
            raise PermissionError("objective completion requires observed Work-level completion proof")
        data = self._read()
        raw = data["tasks"][str(task_id)]
        raw["status"] = "completed"
        raw["phase"] = "completed"
        raw.setdefault("state", {}).update(dict(state or {}))
        raw["state"]["objective_completion_proof"] = {**proof, "evidence_refs": evidence_refs}
        known_receipts = list(raw.get("receipts", []))
        for receipt in tuple(map(str, receipts)) + evidence_refs:
            if receipt not in known_receipts:
                known_receipts.append(receipt)
        raw["receipts"] = known_receipts
        raw["remaining_steps"] = []
        raw["updated_at"] = time.time()
        data["active_task_id"] = None
        self._write(data)
        return self._inflate(raw)
