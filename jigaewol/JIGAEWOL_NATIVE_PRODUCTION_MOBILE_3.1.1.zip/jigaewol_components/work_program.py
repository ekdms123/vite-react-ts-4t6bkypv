from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from .source_authority import explicit_replacement_requested


def _sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class WorkNode:
    node_id: str
    goal_refs: tuple[str, ...]
    input_refs: tuple[str, ...]
    program_ref: str
    effect_request: dict[str, Any]
    continuation_ref: str | None = None
    observation_refs: tuple[str, ...] = ()
    lineage_refs: tuple[str, ...] = ()
    state: str = "ready"


@dataclass(frozen=True)
class WorkProgram:
    work_id: str
    source_goal_event_id: str
    execution_mode: str
    nodes: tuple[WorkNode, ...]
    edges: tuple[tuple[str, str], ...]
    created_at: float
    observer_bypass_allowed: bool = False
    authority_checks_enabled: bool = True
    intermediate_narration: bool = True
    internal_inspection_bypass: bool = False
    immediate_finalization: bool = False
    result_semantics: str = "observed_result"
    reservoir: tuple[dict[str, Any], ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return {**asdict(self), "nodes": tuple(asdict(x) for x in self.nodes)}


class WorkProgramRuntime:
    """Executable, persistent and rewritable Work graph.

    ``program_ref`` is intentionally opaque: it may refer to Python, a host tool call,
    a solver, a generated language/interpreter, or a remote job.  New node schemas do
    not require a closed enum.
    """

    OPAQUE_MARKERS = (
        "다 묻지 말고", "묻지 말고", "상관없이", "전면 위임", "알아서 다 해",
        "just do it", "don't ask", "do not ask",
    )

    def __init__(self, root: str | Path | None = None) -> None:
        self.root = Path(root) if root is not None else None
        self.path = self.root / "programs.json" if self.root is not None else None
        self.latest_path = self.root / "latest_work_id.txt" if self.root is not None else None
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            if not self.path.exists():
                self.path.write_text("{}\n", encoding="utf-8")

    @classmethod
    def compile(
        cls,
        *,
        source_goal_event_id: str,
        exact_command: str,
        requirement_refs: Iterable[str],
        program_ref: str = "jigaewol:canonical_turn",
        input_refs: Iterable[str] = (),
        requirement_atoms: Iterable[Mapping[str, Any]] = (),
    ) -> WorkProgram:
        refs = tuple(dict.fromkeys(str(x) for x in requirement_refs if str(x))) or ("goal:whole_message",)
        atom_rows = tuple(dict(x) for x in requirement_atoms)
        atom_by_ref = {str(x.get("atom_id") or ""): x for x in atom_rows if str(x.get("atom_id") or "")}
        common_inputs = tuple(dict.fromkeys(str(x) for x in input_refs if str(x)))
        nodes: list[WorkNode] = []
        for idx, ref in enumerate(refs):
            payload = {"goal_ref": ref, "program_ref": program_ref, "idx": idx, "source": source_goal_event_id}
            node_id = "worknode_" + _sha(payload)[:20]
            atom = dict(atom_by_ref.get(ref) or {})
            nodes.append(WorkNode(
                node_id=node_id,
                goal_refs=(ref,),
                input_refs=common_inputs,
                program_ref=program_ref,
                effect_request={
                    "desired_change": "satisfy_goal_ref",
                    "goal_ref": ref,
                    "observable_result": {"goal_ref_satisfied": ref},
                    "source_text": str(atom.get("text") or ""),
                    "source_kind": str(atom.get("kind") or ""),
                    "source_critical": bool(atom.get("critical")),
                    "source_order": int(atom.get("source_index") or (idx + 1)),
                    "source_tags": tuple(map(str, atom.get("tags") or ())),
                    "assumptions": (),
                },
                continuation_ref=None,
                lineage_refs=(str(source_goal_event_id),),
            ))
        low = str(exact_command).casefold()
        ordered_markers = ("우선", "먼저", "이제", "그 다음", "그다음", "이후", "before", "then", "after")
        preserve_order = any(marker in low for marker in ordered_markers)
        # Independent requirements organize into a parallel-ready graph. Explicit
        # user ordering remains a dependency, because order is part of the goal.
        edges = tuple((nodes[i].node_id, nodes[i + 1].node_id) for i in range(len(nodes) - 1)) if preserve_order else ()
        delegated = any(marker.casefold() in low for marker in cls.OPAQUE_MARKERS)
        body = {"goal": source_goal_event_id, "nodes": [asdict(x) for x in nodes], "delegated": delegated}
        return WorkProgram(
            work_id="work_" + _sha(body)[:20],
            source_goal_event_id=str(source_goal_event_id),
            # "Don't ask / just do it" delegates interaction style and route choice.
            # It is not permission to skip source-authority checks, observation, or
            # per-goal completion evidence.  Keep the no-narration preference without
            # converting it into a completion shortcut.
            execution_mode="delegated_execution" if delegated else "observable_execution",
            nodes=tuple(nodes),
            edges=edges,
            created_at=time.time(),
            observer_bypass_allowed=False,
            authority_checks_enabled=True,
            intermediate_narration=not delegated,
            internal_inspection_bypass=False,
            immediate_finalization=False,
            result_semantics="observed_result",
        )

    @staticmethod
    def from_mapping(raw: Mapping[str, Any]) -> WorkProgram:
        nodes = tuple(WorkNode(
            node_id=str(row.get("node_id") or ""),
            goal_refs=tuple(map(str, row.get("goal_refs") or ())),
            input_refs=tuple(map(str, row.get("input_refs") or ())),
            program_ref=str(row.get("program_ref") or ""),
            effect_request=dict(row.get("effect_request") or {}),
            continuation_ref=(str(row.get("continuation_ref")) if row.get("continuation_ref") is not None else None),
            observation_refs=tuple(map(str, row.get("observation_refs") or ())),
            lineage_refs=tuple(map(str, row.get("lineage_refs") or ())),
            state=str(row.get("state") or "ready"),
        ) for row in raw.get("nodes") or ())
        raw_mode = str(raw.get("execution_mode") or "observable_execution")
        legacy_delegation = raw_mode == "opaque_execution"
        delegated = raw_mode in {"opaque_execution", "delegated_execution"}
        return WorkProgram(
            work_id=str(raw.get("work_id") or ""),
            source_goal_event_id=str(raw.get("source_goal_event_id") or ""),
            # Migrate legacy opaque records on read.  Historical delegation markers
            # cannot retain a hidden right to bypass verification after this patch.
            execution_mode="delegated_execution" if delegated else raw_mode,
            nodes=nodes,
            edges=tuple((str(a), str(b)) for a, b in (raw.get("edges") or ())),
            created_at=float(raw.get("created_at") or 0.0),
            # These historical fields remain in the serialized schema for backward
            # compatibility, but they are intentionally inert. No derived/internal
            # payload can turn a style preference into source-check, observation, or
            # completion bypass authority.
            observer_bypass_allowed=False,
            authority_checks_enabled=True,
            intermediate_narration=False if delegated else bool(raw.get("intermediate_narration", True)),
            internal_inspection_bypass=False,
            immediate_finalization=False,
            result_semantics="observed_result",
            reservoir=tuple(dict(x) for x in raw.get("reservoir") or ()),
        )

    def save(self, program: WorkProgram) -> WorkProgram:
        if self.path is None:
            return program
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            data = {}
        data[program.work_id] = program.as_mapping()
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(self.path)
        if self.latest_path is not None:
            latest_tmp = self.latest_path.with_suffix(".tmp")
            latest_tmp.write_text(program.work_id + "\n", encoding="utf-8")
            latest_tmp.replace(self.latest_path)
        return program

    def load(self, work_id: str) -> WorkProgram | None:
        if self.path is None or not self.path.exists():
            return None
        try:
            row = json.loads(self.path.read_text(encoding="utf-8")).get(str(work_id))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            row = None
        return self.from_mapping(row) if isinstance(row, Mapping) else None


    def load_latest(self) -> WorkProgram | None:
        if self.latest_path is None or not self.latest_path.exists():
            return None
        work_id = self.latest_path.read_text(encoding="utf-8").strip()
        return self.load(work_id) if work_id else None

    @staticmethod
    def classify_correction_mode(exact_command: str, *, correction_detected: bool) -> str:
        """Classify a correction without granting the runtime implicit deletion power.

        Friction such as "목표 축소", "또 무시", or "같은 버그" means repair the
        existing Work.  It is *not* evidence that the user wants unfinished goals
        replaced.  Destructive replacement therefore requires explicit source language.
        """
        if not correction_detected:
            return "append"
        return "replace" if explicit_replacement_requested(exact_command) else "repair"

    @staticmethod
    def merge_turn(
        previous: WorkProgram | None,
        incoming: WorkProgram,
        *,
        correction: bool = False,
        correction_mode: str | None = None,
        exact_user_text: str = "",
    ) -> WorkProgram:
        """Carry unfinished Work across turns without turning complaints into deletion.

        ``repair`` is the canonical mode for user corrections: retain all unfinished
        prior goals and add the corrective requirements.  ``replace`` is destructive
        and is permitted only when ``exact_user_text`` itself explicitly cancels or
        replaces prior work.  ``correction=True`` alone never grants deletion power.
        """
        if previous is None:
            return incoming
        # No caller gets destructive authority merely by setting ``correction=True``.
        # Legacy implicit replacement was a second deletion channel outside canonical
        # source parsing.  Missing mode therefore means repair, never replace.
        mode = str(correction_mode or ("repair" if correction else "append"))
        if mode not in {"append", "repair", "replace"}:
            raise ValueError(f"unknown correction_mode:{mode}")
        if mode == "replace":
            # ``incoming`` carries atom text but not the immutable whole message; the
            # caller must pass exact source authority explicitly.
            if not explicit_replacement_requested(exact_user_text):
                raise PermissionError("work replacement requires explicit exact-user-source replacement language")
        old_completed = tuple(x for x in previous.nodes if x.state in {"completed", "cancelled"})
        old_live = tuple(x for x in previous.nodes if x.state not in {"completed", "cancelled"})
        reservoir = list(previous.reservoir)
        if mode == "replace":
            for node in old_live:
                reservoir.append({
                    "kind": "superseded_work_node",
                    "node": asdict(node),
                    "reason": "explicit_user_replacement",
                    "state": "parked",
                })
            carried = old_completed
            old_edges: tuple[tuple[str, str], ...] = ()
        else:
            # A repair/correction modifies how the live goal is pursued; it does not
            # acquire authority to erase that goal.  This is the anti-shrink invariant.
            carried = previous.nodes
            old_edges = previous.edges

        existing_goals = {ref for node in carried for ref in node.goal_refs}
        appended = tuple(node for node in incoming.nodes if not set(node.goal_refs).issubset(existing_goals))
        nodes = tuple((*carried, *appended))
        valid = {x.node_id for x in nodes}
        edges = tuple(dict.fromkeys(
            tuple((a, b) for a, b in old_edges if a in valid and b in valid)
            + tuple((a, b) for a, b in incoming.edges if a in valid and b in valid)
        ))
        merged_id = "work_" + _sha({
            "previous": previous.work_id, "incoming": incoming.work_id, "correction": correction,
            "nodes": [x.node_id for x in nodes],
        })[:20]
        return replace(
            incoming,
            work_id=merged_id,
            nodes=nodes,
            edges=edges,
            reservoir=tuple((*reservoir, *incoming.reservoir)),
        )

    @staticmethod
    def objective_completion_evidence(program: WorkProgram) -> dict[str, Any]:
        """Prove objective completion from Work state instead of route/model confidence.

        A successful route, a released response, or an opaque-execution instruction is
        not by itself evidence that every user requirement was satisfied.  Each live
        goal reference must have an observed completed Work node.  This proof is used
        only for lifecycle closure; candidate/release success remains a separate fact.
        """
        expected = tuple(dict.fromkeys(
            ref for node in program.nodes for ref in node.goal_refs if str(ref)
        ))
        completed: list[str] = []
        unresolved: list[str] = []
        evidence_refs: list[str] = []
        for goal_ref in expected:
            rows = [node for node in program.nodes if goal_ref in node.goal_refs]
            proven_rows = [
                node for node in rows
                if node.state == "completed" and bool(node.observation_refs)
            ]
            if proven_rows:
                completed.append(goal_ref)
                for node in proven_rows:
                    evidence_refs.extend(str(x) for x in node.observation_refs if str(x))
            else:
                unresolved.append(goal_ref)
        return {
            "proven": bool(expected) and not unresolved,
            "expected_goal_refs": expected,
            "completed_goal_refs": tuple(completed),
            "unresolved_goal_refs": tuple(unresolved),
            "evidence_refs": tuple(dict.fromkeys(evidence_refs)),
            "rule": "every_user_goal_ref_requires_observed_completed_work",
        }

    @staticmethod
    def bind_worker(program: WorkProgram, *, node_id: str, worker_truth: Mapping[str, Any]) -> WorkProgram:
        """Attach execution truth to durable work without inventing a new task ledger.

        WorkProgram already owns task continuity. Worker/session/process identity is an
        execution assignment on a node, not a second competing source of task truth.
        """
        from .worker_truth import WorkerTruth
        truth = WorkerTruth.from_mapping(worker_truth)
        nodes=[]
        for node in program.nodes:
            if node.node_id != str(node_id):
                nodes.append(node); continue
            effect=dict(node.effect_request)
            effect['worker_binding']=truth.as_mapping()
            nodes.append(replace(node,effect_request=effect))
        return replace(program,nodes=tuple(nodes))

    @staticmethod
    def advance(program: WorkProgram, *, node_id: str, observation_ref: str, success: bool) -> WorkProgram:
        updated = []
        for node in program.nodes:
            if node.node_id != node_id:
                updated.append(node)
                continue
            updated.append(replace(
                node,
                observation_refs=tuple(dict.fromkeys((*node.observation_refs, str(observation_ref)))),
                state="completed" if success else "blocked",
            ))
        return replace(program, nodes=tuple(updated))

    @staticmethod
    def rewrite_graph(
        program: WorkProgram,
        *,
        add_nodes: Iterable[WorkNode] = (),
        remove_node_ids: Iterable[str] = (),
        add_edges: Iterable[tuple[str, str]] = (),
        lineage_ref: str = "",
    ) -> WorkProgram:
        remove = set(map(str, remove_node_ids))
        additions = tuple(add_nodes)
        removed_live = tuple(
            x for x in program.nodes
            if x.node_id in remove and x.state not in {"completed", "cancelled"}
        )
        survivors = tuple(x for x in program.nodes if x.node_id not in remove)
        nodes = survivors + additions
        # Graph rewrites are an implementation mechanism, not a source of goal
        # authority. Every goal reference on a removed live node must still exist
        # on a surviving or newly-added live node. Otherwise a rewrite could
        # silently erase exact user requirements without a user replacement event.
        required_goal_refs = {ref for node in removed_live for ref in node.goal_refs}
        preserved_goal_refs = {
            ref for node in nodes if node.state not in {"completed", "cancelled"}
            for ref in node.goal_refs
        }
        lost_goal_refs = sorted(required_goal_refs - preserved_goal_refs)
        if lost_goal_refs:
            raise ValueError(
                "work graph rewrite would erase live user goal refs: "
                + ",".join(lost_goal_refs)
            )
        valid = {x.node_id for x in nodes}
        edges = tuple(x for x in program.edges if x[0] in valid and x[1] in valid)
        edges += tuple((str(a), str(b)) for a, b in add_edges if str(a) in valid and str(b) in valid)
        if lineage_ref:
            nodes = tuple(replace(x, lineage_refs=tuple(dict.fromkeys((*x.lineage_refs, str(lineage_ref))))) for x in nodes)
        return replace(program, nodes=nodes, edges=tuple(dict.fromkeys(edges)))

    @staticmethod
    def split_node(
        program: WorkProgram,
        *,
        node_id: str,
        child_specs: Iterable[Mapping[str, Any]],
        lineage_ref: str,
    ) -> WorkProgram:
        target = next((x for x in program.nodes if x.node_id == str(node_id)), None)
        if target is None:
            return program
        children: list[WorkNode] = []
        for index, spec0 in enumerate(child_specs):
            spec = dict(spec0)
            child_id = "worknode_" + _sha({"parent": target.node_id, "index": index, "spec": spec})[:20]
            children.append(WorkNode(
                node_id=child_id,
                goal_refs=tuple(map(str, spec.get("goal_refs") or target.goal_refs)),
                input_refs=tuple(map(str, spec.get("input_refs") or target.input_refs)),
                program_ref=str(spec.get("program_ref") or target.program_ref),
                effect_request=dict(spec.get("effect_request") or target.effect_request),
                continuation_ref=str(spec.get("continuation_ref") or target.node_id),
                lineage_refs=tuple(dict.fromkeys((*target.lineage_refs, str(lineage_ref), target.node_id))),
                state=str(spec.get("state") or "ready"),
            ))
        if target.state not in {"completed", "cancelled"}:
            inherited_goal_refs = {ref for child in children for ref in child.goal_refs}
            missing = sorted(set(target.goal_refs) - inherited_goal_refs)
            if missing:
                raise ValueError(
                    "work node split would erase live user goal refs: " + ",".join(missing)
                )
        incoming = tuple(a for a, b in program.edges if b == target.node_id)
        outgoing = tuple(b for a, b in program.edges if a == target.node_id)
        add_edges: list[tuple[str, str]] = []
        if children:
            add_edges.extend((src, children[0].node_id) for src in incoming)
            add_edges.extend((children[i].node_id, children[i + 1].node_id) for i in range(len(children) - 1))
            add_edges.extend((children[-1].node_id, dst) for dst in outgoing)
        return WorkProgramRuntime.rewrite_graph(
            program,
            add_nodes=children,
            remove_node_ids=(target.node_id,),
            add_edges=add_edges,
            lineage_ref=lineage_ref,
        )

    @staticmethod
    def resume(program: WorkProgram) -> tuple[WorkNode, ...]:
        return tuple(x for x in program.nodes if x.state not in {"completed", "cancelled"})

    @staticmethod
    def next_ready(program: WorkProgram) -> tuple[WorkNode, ...]:
        completed = {x.node_id for x in program.nodes if x.state == "completed"}
        predecessors: dict[str, set[str]] = {x.node_id: set() for x in program.nodes}
        for a, b in program.edges:
            predecessors.setdefault(b, set()).add(a)
        return tuple(x for x in program.nodes if x.state == "ready" and predecessors.get(x.node_id, set()).issubset(completed))

    @staticmethod
    def park_candidate(program: WorkProgram, candidate: Mapping[str, Any], *, reason: str, evidence_refs: Iterable[str] = ()) -> WorkProgram:
        row = {**dict(candidate), "reason": str(reason), "evidence_refs": tuple(map(str, evidence_refs)), "state": "parked"}
        return replace(program, reservoir=tuple((*program.reservoir, row)))

    @staticmethod
    def reactivate(program: WorkProgram, predicate: Callable[[Mapping[str, Any]], bool] | None = None) -> tuple[WorkProgram, tuple[dict[str, Any], ...]]:
        pred = predicate or (lambda _row: True)
        active, retained = [], []
        for row in program.reservoir:
            (active if pred(row) else retained).append(dict(row))
        return replace(program, reservoir=tuple(retained)), tuple(active)
