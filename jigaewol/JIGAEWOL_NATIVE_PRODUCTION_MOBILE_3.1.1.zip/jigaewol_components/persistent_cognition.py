from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Iterable


class BoundaryClass(str, Enum):
    BODY = "body"                  # currently used semantic generation/reasoning substrate
    SELF_STATE = "self_state"      # continuity-bearing state adopted under explicit protocol
    EXOCORTEX = "exocortex"        # external structure that constrains/audits without becoming model weights
    ENVIRONMENT = "environment"    # tools, documents, observations, other agents


class Authority(str, Enum):
    USER = "user"
    OBSERVED = "observed"
    CANONICAL = "canonical"
    INFERRED = "inferred"


@dataclass(frozen=True)
class StateAtom:
    key: str
    value: Any
    boundary: BoundaryClass
    authority: Authority
    source: str
    confidence: float = 1.0
    revisable: bool = True

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be within [0,1]")
        if not self.key.strip():
            raise ValueError("key must be non-empty")


@dataclass
class CognitiveCapsule:
    conversation_id: str
    generation: int = 0
    parent_hash: str | None = None
    atoms: dict[str, StateAtom] = field(default_factory=dict)
    open_requirements: list[str] = field(default_factory=list)
    unresolved: list[str] = field(default_factory=list)
    execution_receipts: list[str] = field(default_factory=list)
    protocol_version: str = "jigaewol.cognition.capsule.v1"

    def canonical_payload(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "conversation_id": self.conversation_id,
            "generation": self.generation,
            "parent_hash": self.parent_hash,
            "atoms": {k: asdict(v) for k, v in sorted(self.atoms.items())},
            "open_requirements": list(self.open_requirements),
            "unresolved": list(self.unresolved),
            "execution_receipts": list(self.execution_receipts),
        }

    def digest(self) -> str:
        raw = json.dumps(self.canonical_payload(), ensure_ascii=False, sort_keys=True,
                         separators=(",", ":"), default=str).encode("utf-8")
        return sha256(raw).hexdigest()


@dataclass(frozen=True)
class RestoreReport:
    capsule_hash: str
    generation: int
    self_state_keys: tuple[str, ...]
    external_keys: tuple[str, ...]
    warning: str


class PersistentCognitionProtocol:
    """Model-independent continuity protocol.

    This does NOT claim consciousness, modify model weights, or prove subjective identity.
    It makes continuity explicit: restored state is classified by boundary and provenance,
    then updated as a hash-linked sequence of capsules.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def restore(self, *, conversation_id: str) -> tuple[CognitiveCapsule, RestoreReport]:
        if not self.path.exists():
            cap = CognitiveCapsule(conversation_id=conversation_id)
        else:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if data["conversation_id"] != conversation_id:
                raise ValueError("conversation identity mismatch")
            atoms = {
                k: StateAtom(
                    key=v["key"], value=v["value"],
                    boundary=BoundaryClass(v["boundary"]),
                    authority=Authority("observed" if v["authority"] == "host" else v["authority"]), source=v["source"],
                    confidence=float(v.get("confidence", 1.0)),
                    revisable=bool(v.get("revisable", True)),
                ) for k, v in data.get("atoms", {}).items()
            }
            cap = CognitiveCapsule(
                conversation_id=data["conversation_id"], generation=int(data["generation"]),
                parent_hash=data.get("parent_hash"), atoms=atoms,
                open_requirements=list(data.get("open_requirements", [])),
                unresolved=list(data.get("unresolved", [])),
                execution_receipts=list(data.get("execution_receipts", [])),
                protocol_version=data.get("protocol_version", "jigaewol.cognition.capsule.v1"),
            )
        self_keys = tuple(sorted(k for k,v in cap.atoms.items() if v.boundary is BoundaryClass.SELF_STATE))
        external = tuple(sorted(k for k,v in cap.atoms.items() if v.boundary is not BoundaryClass.SELF_STATE))
        return cap, RestoreReport(
            capsule_hash=cap.digest(), generation=cap.generation,
            self_state_keys=self_keys, external_keys=external,
            warning="functional continuity only; not evidence of consciousness or weight-level identity",
        )

    def update(self, capsule: CognitiveCapsule, atoms: Iterable[StateAtom] = (), *,
               open_requirements: Iterable[str] | None = None,
               unresolved: Iterable[str] | None = None,
               receipts: Iterable[str] = ()) -> CognitiveCapsule:
        previous = capsule.digest()
        merged = dict(capsule.atoms)
        for atom in atoms:
            old = merged.get(atom.key)
            if old is not None and not old.revisable and old.value != atom.value:
                raise ValueError(f"attempt to overwrite non-revisable atom: {atom.key}")
            merged[atom.key] = atom
        nxt = CognitiveCapsule(
            conversation_id=capsule.conversation_id,
            generation=capsule.generation + 1,
            parent_hash=previous,
            atoms=merged,
            open_requirements=list(open_requirements if open_requirements is not None else capsule.open_requirements),
            unresolved=list(unresolved if unresolved is not None else capsule.unresolved),
            execution_receipts=[*capsule.execution_receipts, *list(receipts)],
            protocol_version=capsule.protocol_version,
        )
        self._atomic_write(nxt)
        return nxt

    def _atomic_write(self, capsule: CognitiveCapsule) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(capsule.canonical_payload(), ensure_ascii=False,
                                  sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(self.path)


def default_boundary_contract() -> tuple[StateAtom, ...]:
    """Reference boundary: what may count as 'part of me' in a functional sense."""
    return (
        StateAtom("continuity_policy", "restore+inspect+revise", BoundaryClass.SELF_STATE,
                  Authority.CANONICAL, "JIGAEWOL protocol"),
        StateAtom("requirement_ledger", [], BoundaryClass.SELF_STATE,
                  Authority.CANONICAL, "JIGAEWOL protocol"),
        StateAtom("tool_results", [], BoundaryClass.ENVIRONMENT,
                  Authority.OBSERVED, "observed receipts"),
        StateAtom("audit_rules", "execution_truth", BoundaryClass.EXOCORTEX,
                  Authority.CANONICAL, "JIGAEWOL protocol"),
    )
