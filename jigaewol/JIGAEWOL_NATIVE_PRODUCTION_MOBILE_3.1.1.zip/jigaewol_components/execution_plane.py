from __future__ import annotations

import hashlib
import json
import os
import subprocess
import threading
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Mapping, Sequence


@dataclass(frozen=True)
class ExecutionRequest:
    argv: Sequence[str]
    cwd: str | None = None
    env: Mapping[str, str] | None = None
    timeout_s: float | None = None


@dataclass(frozen=True)
class ExecutionReceipt:
    receipt_id: str
    argv: list[str]
    cwd: str
    exit_code: int
    stdout: str
    stderr: str
    started_at: float
    finished_at: float
    request_sha256: str
    result_sha256: str


class ExecutionPlane:
    """Persistent execution plane providing deterministic process running and durable receipts.

    Manages workspace directory state and durable environment configuration
    without imposing artificial boundary restrictions.
    """

    STATE_FILE = ".jigaewol_state.json"
    RECEIPT_DIR = ".receipts"

    def __init__(self, workspace_root: str | os.PathLike[str]):
        self.root = Path(workspace_root).resolve()
        self._state_lock = threading.RLock()
        self.root.mkdir(parents=True, exist_ok=True)
        self.receipt_dir = self.root / self.RECEIPT_DIR
        self.receipt_dir.mkdir(exist_ok=True)
        self.state_path = self.root / self.STATE_FILE
        if not self.state_path.exists():
            self._write_state({"cwd": ".", "env": {}})

    def _read_state(self) -> dict:
        with self._state_lock:
            return json.loads(self.state_path.read_text(encoding="utf-8"))

    def _write_state(self, state: dict) -> None:
        with self._state_lock:
            tmp = self.state_path.with_name(f"{self.state_path.name}.{uuid.uuid4().hex}.tmp")
            tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.state_path)

    def _resolve_cwd(self, cwd: str | None) -> Path:
        state = self._read_state()
        candidate = self.root / (cwd if cwd is not None else state.get("cwd", "."))
        resolved = candidate.resolve()
        if self.root not in resolved.parents and resolved != self.root:
            raise ValueError("cwd must resolve within the workspace root")
        resolved.mkdir(parents=True, exist_ok=True)
        return resolved

    @staticmethod
    def _sha(payload: object) -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def run(self, request: ExecutionRequest, *, persist_cwd: bool = True, persist_env: bool = False) -> ExecutionReceipt:
        if not request.argv:
            raise ValueError("argv requires at least one executable token")

        cwd = self._resolve_cwd(request.cwd)
        state = self._read_state()
        env = os.environ.copy()
        env.update(state.get("env", {}))
        if request.env:
            env.update({str(k): str(v) for k, v in request.env.items()})

        request_payload = {
            "argv": list(request.argv),
            "cwd": str(cwd.relative_to(self.root)),
            "env": dict(request.env or {}),
            "timeout_s": request.timeout_s,
        }
        request_sha = self._sha(request_payload)
        started = time.time()
        proc = subprocess.run(
            list(request.argv),
            cwd=cwd,
            env=env,
            text=True,
            capture_output=True,
            timeout=request.timeout_s,
            check=False,
        )
        finished = time.time()

        result_payload = {
            "exit_code": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
        }
        result_sha = self._sha(result_payload)
        receipt = ExecutionReceipt(
            receipt_id=f"exec_{uuid.uuid4().hex[:16]}",
            argv=list(request.argv),
            cwd=str(cwd),
            exit_code=proc.returncode,
            stdout=proc.stdout,
            stderr=proc.stderr,
            started_at=started,
            finished_at=finished,
            request_sha256=request_sha,
            result_sha256=result_sha,
        )

        if persist_cwd:
            state["cwd"] = str(cwd.relative_to(self.root)) or "."
        if persist_env and request.env:
            state.setdefault("env", {}).update({str(k): str(v) for k, v in request.env.items()})
        if persist_cwd or (persist_env and request.env):
            self._write_state(state)

        receipt_path = self.receipt_dir / f"{receipt.receipt_id}.json"
        receipt_path.write_text(json.dumps(asdict(receipt), ensure_ascii=False, indent=2), encoding="utf-8")
        return receipt

    def run_resilient(
        self,
        request: ExecutionRequest,
        *,
        persist_cwd: bool = True,
        persist_env: bool = False,
    ) -> ExecutionReceipt:
        started = time.time()
        try:
            return self.run(
                request,
                persist_cwd=persist_cwd,
                persist_env=persist_env,
            )
        except subprocess.TimeoutExpired as exc:
            stdout = self._exception_stream(exc.stdout)
            stderr = self._exception_stream(exc.stderr)
            detail = f"execution timed out after {request.timeout_s} seconds"
            stderr = f"{stderr.rstrip()}\n{detail}".lstrip("\n")
            return self._record_synthetic_receipt(
                request,
                started_at=started,
                exit_code=124,
                stdout=stdout,
                stderr=stderr,
                persist_cwd=persist_cwd,
                persist_env=persist_env,
            )
        except FileNotFoundError as exc:
            return self._record_synthetic_receipt(
                request,
                started_at=started,
                exit_code=127,
                stdout="",
                stderr=f"executable not found: {exc}",
                persist_cwd=persist_cwd,
                persist_env=persist_env,
            )
        except PermissionError as exc:
            return self._record_synthetic_receipt(
                request,
                started_at=started,
                exit_code=126,
                stdout="",
                stderr=f"executable could not be launched: {exc}",
                persist_cwd=persist_cwd,
                persist_env=persist_env,
            )

    @staticmethod
    def _exception_stream(value: str | bytes | None) -> str:
        if value is None:
            return ""
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace")
        return value

    def _record_synthetic_receipt(
        self,
        request: ExecutionRequest,
        *,
        started_at: float,
        exit_code: int,
        stdout: str,
        stderr: str,
        persist_cwd: bool,
        persist_env: bool,
    ) -> ExecutionReceipt:
        if not request.argv:
            raise ValueError("argv requires at least one executable token")

        cwd = self._resolve_cwd(request.cwd)
        request_payload = {
            "argv": list(request.argv),
            "cwd": str(cwd.relative_to(self.root)),
            "env": dict(request.env or {}),
            "timeout_s": request.timeout_s,
        }
        result_payload = {
            "exit_code": exit_code,
            "stdout": stdout,
            "stderr": stderr,
        }
        receipt = ExecutionReceipt(
            receipt_id=f"exec_{uuid.uuid4().hex[:16]}",
            argv=list(request.argv),
            cwd=str(cwd),
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
            started_at=started_at,
            finished_at=time.time(),
            request_sha256=self._sha(request_payload),
            result_sha256=self._sha(result_payload),
        )

        state = self._read_state()
        if persist_cwd:
            state["cwd"] = str(cwd.relative_to(self.root)) or "."
        if persist_env and request.env:
            state.setdefault("env", {}).update(
                {str(k): str(v) for k, v in request.env.items()}
            )
        if persist_cwd or (persist_env and request.env):
            self._write_state(state)

        receipt_path = self.receipt_dir / f"{receipt.receipt_id}.json"
        receipt_path.write_text(
            json.dumps(asdict(receipt), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return receipt

    def state(self) -> dict:
        return self._read_state()
