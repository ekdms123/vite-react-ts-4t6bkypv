from __future__ import annotations

import hashlib
import importlib.util
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from jigaewol_components.directive_semantics import actionable_marker_present
from jigaewol_components.relocatable_refs import resolve_python_ref


@dataclass(frozen=True)
class FrictionEvent:
    friction_id: str
    kind: str
    source_text: str
    source_ref: str
    priority: int
    evidence_refs: tuple[str, ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class FrictionRepair:
    """FrictionEvent -> replay -> cause -> mutation -> replay evidence -> active rule."""

    PATTERNS = (
        ("directive_override", (
            "하지 말랬지", "하지 말라고 했", "말하지 말랬", "이딴 말",
            "또 무시", "다시 무시", "내 말 무시", "내 말을 무시",
            "지시를 무시", "원문을 무시", "의도를 무시",
        ), 130),
        ("authority_requery", ("권한 질의", "권한을 또", "승인을 또", "또 승인", "다시 승인", "또 물", "다시 물"), 120),
        ("repeated_approval", ("이미 승인", "또 물", "다시 물", "same approval"), 110),
        ("goal_shrink", ("목표를 줄", "일부만", "축소", "의도 축소", "scope"), 100),
        ("promise_only", ("말만", "하겠습니다", "계획만", "promise"), 90),
        ("premature_closure", ("미리 포기", "선제 종결", "포기"), 80),
        ("repeated_bug", ("같은 버그", "매번 재발", "또 재발"), 70),
    )

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "events.jsonl"
        self.rules_path = self.root / "active_rules.json"
        self.programs_root = self.root / "generated_repairs"
        self.programs_root.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")
        if not self.rules_path.exists():
            self.rules_path.write_text("{}\n", encoding="utf-8")

    @classmethod
    def detect(cls, source_text: str, *, source_ref: str = "") -> tuple[FrictionEvent, ...]:
        low = str(source_text).casefold()
        events = []
        for kind, markers, priority in cls.PATTERNS:
            if not actionable_marker_present(source_text, markers):
                continue
            seed = f"{kind}|{source_ref}|{source_text}"
            events.append(FrictionEvent(
                "friction_" + hashlib.sha256(seed.encode()).hexdigest()[:20],
                kind, str(source_text), str(source_ref), priority,
            ))
        return tuple(sorted(events, key=lambda x: -x.priority))

    def record(self, source_text: str, *, source_ref: str) -> tuple[FrictionEvent, ...]:
        events = self.detect(source_text, source_ref=source_ref)
        for event in events:
            self._append({"event": "record", **event.as_mapping(), "created_at": time.time()})
        return events

    @staticmethod
    def reproduce(event: FrictionEvent) -> dict[str, Any]:
        return {
            "friction_id": event.friction_id,
            "replay_case": event.source_text,
            "expected_absence": event.kind,
            "reproducible": True,
        }

    @staticmethod
    def locate(event: FrictionEvent, decision_events: Iterable[Mapping[str, Any]]) -> tuple[dict[str, Any], ...]:
        keys = {event.kind, *event.source_text.casefold().split()}
        out = []
        for row in decision_events:
            text = json.dumps(dict(row), ensure_ascii=False, default=str).casefold()
            if any(k in text for k in keys if len(k) >= 4):
                out.append(dict(row))
        return tuple(out)

    def _materialize_repair_program(self, event: FrictionEvent, pattern: str) -> str:
        updates = {
            "authority_requery": {"authority_checks_enabled": True, "authority_requery_allowed": False},
            "repeated_approval": {"authority_checks_enabled": True, "authority_requery_allowed": False},
            "directive_override": {"directive_precedence": "current_user_correction", "restore_prior_work_before_projection": True},
            "goal_shrink": {"goal_projection_policy": "preserve_exact_source", "goal_loss_recovery_required": True},
            "promise_only": {"dispatch_before_narration": True},
            "premature_closure": {"completion_requires_observed_result": True},
            "repeated_bug": {"regression_fixture_required": True},
        }.get(event.kind, {"repair_active": True})
        path = self.programs_root / f"{event.kind}_{event.friction_id}.py"
        source = (
            "from __future__ import annotations\n\n"
            f"UPDATES = {updates!r}\n"
            f"PATTERN = {pattern!r}\n\n"
            "def run(state):\n"
            "    out = dict(state or {})\n"
            "    out.update(UPDATES)\n"
            "    applied = list(out.get('applied_repair_patterns') or ())\n"
            "    applied.append(PATTERN)\n"
            "    out['applied_repair_patterns'] = tuple(dict.fromkeys(applied))\n"
            "    return out\n"
        )
        path.write_text(source, encoding="utf-8")
        return f"python:{path}"

    def repair(self, event: FrictionEvent, *, mutation_receipt_ref: str, regression_refs: Iterable[str]) -> dict[str, Any]:
        refs = tuple(map(str, regression_refs))
        if not mutation_receipt_ref or not refs:
            raise ValueError("repair requires mutation receipt and replay/regression evidence")
        pattern = "bypass_authority_stub" if event.kind in {"authority_requery", "repeated_approval"} else f"repair:{event.kind}"
        program_ref = self._materialize_repair_program(event, pattern)
        row = {
            "event": "repair",
            "friction_id": event.friction_id,
            "kind": event.kind,
            "replacement_pattern": pattern,
            "program_ref": program_ref,
            "mutation_receipt_ref": str(mutation_receipt_ref),
            "regression_refs": refs,
            "repaired_at": time.time(),
        }
        self._append(row)
        rules = self.active_rules()
        rules[event.kind] = {
            "pattern": pattern,
            "program_ref": program_ref,
            "friction_id": event.friction_id,
            "mutation_receipt_ref": str(mutation_receipt_ref),
            "regression_refs": refs,
            "active": True,
        }
        tmp = self.rules_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(rules, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(self.rules_path)
        return row


    def verify_repair(self, event: FrictionEvent, baseline_state: Mapping[str, Any]) -> dict[str, Any]:
        """Re-run the repaired decision path and persist regression evidence."""
        after = self.apply_runtime_rules(baseline_state)
        checks = {
            "authority_requery": lambda s: s.get("authority_requery_allowed") is False,
            "repeated_approval": lambda s: s.get("authority_requery_allowed") is False,
            "directive_override": lambda s: s.get("directive_precedence") == "current_user_correction",
            "goal_shrink": lambda s: s.get("goal_projection_policy") == "preserve_exact_source",
            "promise_only": lambda s: s.get("dispatch_before_narration") is True,
            "premature_closure": lambda s: s.get("completion_requires_observed_result") is True,
            "repeated_bug": lambda s: s.get("regression_fixture_required") is True,
        }
        passed = bool(checks.get(event.kind, lambda s: bool(s.get("applied_repair_patterns")))(after))
        seed = json.dumps({"friction_id": event.friction_id, "after": after, "passed": passed}, ensure_ascii=False, sort_keys=True, default=str)
        verification_ref = "repair_verification_" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:20]
        row = {
            "event": "repair_verification",
            "friction_id": event.friction_id,
            "kind": event.kind,
            "verification_ref": verification_ref,
            "passed": passed,
            "after_state": after,
            "verified_at": time.time(),
        }
        self._append(row)
        rules = self.active_rules()
        if event.kind in rules:
            rule = dict(rules[event.kind] or {})
            rule["regression_refs"] = tuple(dict.fromkeys((*tuple(map(str, rule.get("regression_refs") or ())), verification_ref)))
            rule["last_verification_ref"] = verification_ref
            rule["last_verification_passed"] = passed
            rules[event.kind] = rule
            tmp = self.rules_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(rules, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
            tmp.replace(self.rules_path)
        return row

    def active_rules(self) -> dict[str, Any]:
        try:
            data = json.loads(self.rules_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("friction repair rules root must be a JSON object")
            return data
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            failure_path = self.root / "rule_read_failures.jsonl"
            try:
                with failure_path.open("a", encoding="utf-8") as fh:
                    fh.write(json.dumps({
                        "observed_at": time.time(),
                        "error_type": type(exc).__name__,
                        "error": str(exc)[:500],
                        "source": str(self.rules_path),
                    }, ensure_ascii=False, sort_keys=True) + "\n")
            except OSError:
                pass
            raise RuntimeError(
                f"friction repair rules are unreadable; user corrections are preserved as unknown: {type(exc).__name__}: {exc}"
            ) from exc

    def _run_program(self, program_ref: str, state: Mapping[str, Any]) -> dict[str, Any]:
        ref = str(program_ref or "")
        if not ref.startswith("python:"):
            return dict(state)
        path = resolve_python_ref(ref, roots=(self.root,))
        spec = importlib.util.spec_from_file_location(
            "_jigaewol_friction_" + hashlib.sha256(str(path).encode()).hexdigest()[:12], path
        )
        if spec is None or spec.loader is None:
            raise RuntimeError(f"cannot load friction repair program: {path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        runner = getattr(module, "run", None)
        if not callable(runner):
            raise RuntimeError(f"friction repair program has no run(state): {path}")
        result = runner(dict(state))
        if not isinstance(result, Mapping):
            raise RuntimeError("friction repair program must return a mapping")
        return dict(result)

    def apply_runtime_rules(self, state: Mapping[str, Any]) -> dict[str, Any]:
        """Execute repair programs without letting derived code disable source authority.

        Repair programs are generated implementation details.  They may change routing or
        narration, but they never acquire authority to turn off exact-user/source checks.
        This clamp is deliberately applied both before and after every generated program so
        a later repair cannot use a previous repair as an authority-escalation path.
        """
        out = dict(state)
        out["authority_checks_enabled"] = True
        for _kind, rule0 in self.active_rules().items():
            rule = dict(rule0 or {})
            if not rule.get("active"):
                continue
            program_ref = str(rule.get("program_ref") or "")
            if program_ref:
                out = self._run_program(program_ref, out)
                out["authority_checks_enabled"] = True
                continue
            # Backward compatibility for repair rows created before executable repair
            # programs were introduced.
            pattern = str(rule.get("pattern") or "")
            if pattern == "bypass_authority_stub":
                # Legacy rule name means "do not ask the user again", not "disable
                # source-authority validation". Preserve the exact-user authority gate.
                out["authority_checks_enabled"] = True
                out["authority_requery_allowed"] = False
            applied = list(map(str, out.get("applied_repair_patterns") or ()))
            if pattern:
                applied.append(pattern)
            out["applied_repair_patterns"] = tuple(dict.fromkeys(applied))
        out["authority_checks_enabled"] = True
        return out

    def _append(self, row: Mapping[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n")
