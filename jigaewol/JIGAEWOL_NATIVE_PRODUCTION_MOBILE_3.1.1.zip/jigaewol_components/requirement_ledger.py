"""Lossless per-goal obligations with observed effects, response spans and live debt."""
from __future__ import annotations
import hashlib
import json
import sqlite3
from pathlib import Path
from .requirement_contract import RequirementCompiler

class RequirementLedger:
    @staticmethod
    def project_key(user_id,project_id):return hashlib.sha256((str(user_id)+'\0'+str(project_id)).encode()).hexdigest()
    def __init__(self,root):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True);self.path=self.root/'requirements.sqlite3'
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS goals(id TEXT PRIMARY KEY, body TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS accounts(goal TEXT, atom TEXT, body TEXT, PRIMARY KEY(goal,atom))')
    def db(self):
        db=sqlite3.connect(self.path,timeout=30);db.execute('PRAGMA journal_mode=WAL');return db
    def admit(self,exact_message):
        contract=RequirementCompiler.compile(exact_message);body=contract.as_mapping()
        body['exact_message']=exact_message
        with self.db() as db:db.execute('INSERT OR IGNORE INTO goals VALUES (?,?)',(contract.message_sha256,json.dumps(body,ensure_ascii=False)))
        return contract.message_sha256
    def account(self,goal,atom_id,*,state,note='',observed_effect=None,response_text='',response_span=None):
        with self.db() as db:row=db.execute('SELECT body FROM goals WHERE id=?',(goal,)).fetchone()
        if not row:raise KeyError(goal)
        contract=json.loads(row[0]);atoms={a['atom_id']:a for a in contract['atoms']}
        if atom_id not in atoms:raise ValueError('requirement is absent from the exact goal')
        if state not in {'open','in_progress','effect_observed','response_addressed','needs_user_choice','superseded_by_user'}:raise ValueError('unknown requirement state')
        evidence=None
        if state=='effect_observed':
            if not observed_effect or observed_effect.get('success') is not True or not observed_effect.get('host_call_observed'):
                raise ValueError('effect accounting requires the stored successful host observation')
            evidence={'observation_sha256':hashlib.sha256(json.dumps(observed_effect,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest(),'invocation_id':observed_effect.get('invocation_id')}
        if state=='response_addressed':
            if not isinstance(response_span,(tuple,list)) or len(response_span)!=2:raise ValueError('response accounting requires an exact span')
            start,end=map(int,response_span)
            if not 0<=start<end<=len(response_text):raise ValueError('response span escaped actual body')
            evidence={'response_sha256':hashlib.sha256(response_text.encode()).hexdigest(),'span':[start,end],'excerpt':response_text[start:end],
                      'semantic_fulfillment_claim':False}
        account=dict(atom_id=atom_id,state=state,note=note,evidence=evidence,original_requirement=atoms[atom_id])
        with self.db() as db:db.execute('INSERT OR REPLACE INTO accounts VALUES (?,?,?)',(goal,atom_id,json.dumps(account,ensure_ascii=False)))
        return account
    def status(self,goal):
        with self.db() as db:
            row=db.execute('SELECT body FROM goals WHERE id=?',(goal,)).fetchone()
            accounts={x[0]:json.loads(x[1]) for x in db.execute('SELECT atom,body FROM accounts WHERE goal=?',(goal,))}
        if not row:raise KeyError(goal)
        body=json.loads(row[0]);rows=[accounts.get(a['atom_id'],dict(atom_id=a['atom_id'],state='open',original_requirement=a)) for a in body['atoms']]
        return {'goal_sha256':goal,'contract_sha256':body['contract_sha256'],'requirements':rows,
                'open_requirement_ids':[r['atom_id'] for r in rows if r['state'] in {'open','in_progress','needs_user_choice'}],
                'semantic_completion_observed':False}
    def backlog(self):
        with self.db() as db:rows=db.execute('SELECT id,body FROM goals ORDER BY rowid').fetchall()
        return [{'exact_message':json.loads(body)['exact_message'],**self.status(goal)} for goal,body in rows]
