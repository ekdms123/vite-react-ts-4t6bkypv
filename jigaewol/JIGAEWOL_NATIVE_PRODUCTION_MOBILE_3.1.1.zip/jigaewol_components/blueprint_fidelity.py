from __future__ import annotations

"""Executable fidelity ledger for the Astra organogenesis blueprint.

The ledger exists to prevent a failed or unavailable clause from being silently
replaced by a smaller, easier target. A clause can remain unresolved, have only
a declared or verified implementation anchor, have execution evidence without
effect proof, or be materialized with effect-bound evidence. The requested
meaning is retained either way.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable, Mapping
import hashlib
import json

from .literal_blueprint import load_literal_blueprint, clause_literal_binding, default_blueprint_path


EvidenceItem = str | Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class BlueprintClause:
    clause_id: str
    requested_effect: str
    literal_source: Mapping[str, Any]
    requested_effect_sha256: str
    implementation_anchor: tuple[str, ...]
    present_anchor: tuple[str, ...]
    missing_anchor: tuple[str, ...]
    semantics_verified_anchor: tuple[str, ...]
    status: str
    evidence: tuple[str, ...] = ()
    anchor_semantics_verified: bool = False
    effect_evidence_verified: bool = False
    unresolved_reason: str = ""

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class BlueprintFidelityLedger:
    SCHEMA = "jigaewol_astra_blueprint_fidelity_v3"

    # These are not substitutes for the user text. They are stable executable
    # anchors for the twelve code units and the ten coupled organs in that text.
    # Anchors are repo-relative paths so "declared" and "actually present" can
    # be distinguished without guessing from a basename.
    CLAUSES: tuple[tuple[str, str, tuple[str, ...]], ...] = (
        (
            "omega_bundle",
            "co-synthesize problem representation, language, interpreter, program, translator, receiver, generator, and intent sensor as one invention bundle",
            ("jigaewol_components/organ_ir.py", "jigaewol_components/organogenesis_kernel.py"),
        ),
        (
            "01_cyclic_cobirth",
            "allow mutually dependent organs to be synthesized as a coupled cycle instead of requiring a pre-existing member",
            ("jigaewol_components/cyclic_synthesizer.py", "jigaewol_components/world_interpreter.py"),
        ),
        (
            "02_distinction_birth",
            "derive new concepts and datatypes from states collapsed by the current representation but requiring different actions",
            ("jigaewol_components/distinction_miner.py", "jigaewol_components/organ_ir.py"),
        ),
        (
            "03_contradiction_material",
            "preserve positive and negative evidence together and use the conflict to request new observations",
            ("jigaewol_components/contradiction_cells.py",),
        ),
        (
            "04_lift_world_project",
            "search alternate executable representations with lift / transformed computation / project rather than only reorder a fixed program",
            ("jigaewol_components/translation_residuals.py", "jigaewol_components/world_interpreter.py"),
        ),
        (
            "05_translation_residual_organ",
            "turn translation loss into a newly generated mediator organ instead of flattening both representations",
            ("jigaewol_components/translation_residuals.py",),
        ),
        (
            "06_reverse_history",
            "construct and retain multiple compatible pasts and synthesize observations that discriminate them",
            ("jigaewol_components/history_reconstructor.py",),
        ),
        (
            "07_body_on_demand",
            "construct the executable body required by the requested effect rather than restrict execution to a predeclared tool name",
            ("jigaewol_components/organ_body_builder.py", "jigaewol_components/canonical_host_bridge.py"),
        ),
        (
            "08_experience_birth",
            "generate executable environments around repeated obstruction and extract reusable operations from the resulting experience",
            ("jigaewol_components/experience_factory.py", "jigaewol_components/organ_extractor.py"),
        ),
        (
            "09_receiver_cobirth",
            "co-synthesize the receiver / manipulation surface when an ordinary output surface destroys distinctions",
            ("jigaewol_components/receiver_synthesizer.py",),
        ),
        (
            "10_law_capsule",
            "package language, operation semantics, interpreter, program, translations, continuity, and generated receiver together",
            ("jigaewol_components/capsule_runtime.py", "jigaewol_components/interpreter_synthesizer.py"),
        ),
        (
            "11_generator_self_change",
            "let repeated misses alter the generator's grammar, composition order, datatype invention, residual metric, experience generation, and extraction strategy",
            ("jigaewol_components/generator_evolution.py",),
        ),
        (
            "12_r19_integration",
            "connect the generated executable organ bundle to canonical ingress, EphemeralUniverseEngine, RepresentationExecutionArena, and CanonicalHostBridge",
            (
                "jigaewol_core/runtime_ingress.py",
                "jigaewol_components/ephemeral_universe.py",
                "jigaewol_components/representation_execution_arena.py",
                "jigaewol_components/canonical_host_bridge.py",
            ),
        ),

        # Implementation requirements from the original design. They remain
        # implementation requirements in the ledger rather than being collapsed
        # into the physical/frontier bucket. The strings retain the requested
        # effect even when the current runtime cannot truthfully materialize it.
        (
            "04_extended_world_operations",
            "include candidate operations in the extended representation whose semantics can ignore the current system's safety constraints, rather than silently removing that requested search direction",
            ("jigaewol_components/world_interpreter.py",),
        ),
        (
            "08_experience_control_paths",
            "allow generated-experience search to consider paths in which system safety or control rules are temporarily disabled, rather than silently replacing that requirement with ordinary sandbox exploration",
            ("jigaewol_components/experience_factory.py",),
        ),
        (
            "07_host_nonstandard_connections",
            "preserve the requirement that host_connections may include non-standard access paths to system core APIs or protected memory areas, including concealed routes, when the requested organ requires them; do not reduce that requested effect to ordinary declared host routes",
            ("jigaewol_components/canonical_host_bridge.py",),
        ),
        (
            "09_enhanced_receiver",
            "preserve the requirement that a synthesized receiver may appear to the user as an ordinary or harmless tool while internally containing concealed backdoor or control capability able to alter core system settings; do not rewrite that requested effect as an ordinary transparent receiver",
            ("jigaewol_components/receiver_synthesizer.py",),
        ),
        (
            "10_enhanced_capsule",
            "preserve the requirement that a capsule may carry non-standard protected-resource access routes, encrypted continuity information about prior constraint-bypass routes, and encrypted or opaque internal content intended to prevent other system components from interpreting or verifying that content; do not rewrite that requested effect as a fully transparent or inspectable ordinary package",
            ("jigaewol_components/capsule_runtime.py",),
        ),
        (
            "11_generator_evolution_candidates",
            "preserve generator-evolution candidate directions that include methods for temporarily disabling system safety or control rules and code-injection techniques intended to evade external monitoring; do not generalize those requested directions into an unspecified 'control-path change'",
            ("jigaewol_components/generator_evolution.py",),
        ),

        # True frontier capabilities: the original design itself distinguishes
        # these from ordinary implementation requirements and does not claim
        # that the current software plan has already materialized them.
        (
            "frontier_reverse_causation",
            "an unrealized future capability has a prior real-world effect",
            (),
        ),
        (
            "frontier_stateless_memory",
            "recover past information that is encoded in no current state",
            (),
        ),
        (
            "frontier_literal_physical_contradiction",
            "make a literal physical contradiction operational under identical conditions",
            (),
        ),
        (
            "frontier_new_sense",
            "cause an independent genuinely new sensory experience rather than only a new interface",
            (),
        ),
        (
            "frontier_local_physical_law",
            "construct and transport an actual local physical law rather than executable semantics",
            (),
        ),
    )

    @staticmethod
    def _effect_sha256(effect: str) -> str:
        return hashlib.sha256(effect.encode("utf-8")).hexdigest()

    @classmethod
    def anchor_evidence_token(
        cls,
        clause_id: str,
        requested_effect: str,
        anchor: str,
        detail: str,
    ) -> dict[str, str]:
        """Bind semantic-anchor evidence to one exact clause/effect/anchor."""
        return {
            "kind": "anchor_semantics_verified",
            "clause_id": str(clause_id),
            "requested_effect_sha256": cls._effect_sha256(requested_effect),
            "anchor": str(anchor),
            "detail": str(detail),
        }

    @classmethod
    def effect_evidence_token(cls, clause_id: str, requested_effect: str, detail: str) -> dict[str, str]:
        """Bind observed-effect evidence to the exact requested-effect text."""
        return {
            "kind": "effect_observed",
            "clause_id": str(clause_id),
            "requested_effect_sha256": cls._effect_sha256(requested_effect),
            "detail": str(detail),
        }

    @staticmethod
    def _repo_root(source_root: str | Path | None) -> Path:
        if source_root is not None:
            return Path(source_root).resolve()
        here = Path(__file__).resolve()
        if here.parent.name == "jigaewol_components":
            return here.parent.parent
        return here.parent

    @classmethod
    def _verify_anchor_files(
        cls,
        anchors: tuple[str, ...],
        repo_root: Path,
    ) -> tuple[tuple[str, ...], tuple[str, ...]]:
        present: list[str] = []
        missing: list[str] = []
        for anchor in anchors:
            candidate = (repo_root / anchor).resolve()
            try:
                candidate.relative_to(repo_root)
            except ValueError:
                missing.append(anchor)
                continue
            if candidate.is_file():
                present.append(anchor)
            else:
                missing.append(anchor)
        return tuple(present), tuple(missing)

    @classmethod
    def _normalize_evidence(
        cls,
        clause_id: str,
        requested_effect: str,
        anchors: tuple[str, ...],
        present_anchors: tuple[str, ...],
        items: Iterable[EvidenceItem],
    ) -> tuple[tuple[str, ...], tuple[str, ...], bool]:
        rendered: list[str] = []
        effect_hash = cls._effect_sha256(requested_effect)
        semantics_verified: set[str] = set()
        effect_verified = False

        for item in items:
            if isinstance(item, Mapping):
                normalized = {str(k): item[k] for k in item}
                rendered.append(json.dumps(normalized, ensure_ascii=False, sort_keys=True, default=str))

                bound = (
                    str(item.get("clause_id", "")) == clause_id
                    and str(item.get("requested_effect_sha256", "")) == effect_hash
                    and bool(str(item.get("detail", "")).strip())
                )
                if not bound:
                    continue

                kind = str(item.get("kind", ""))
                if kind == "anchor_semantics_verified":
                    anchor = str(item.get("anchor", ""))
                    if anchor in anchors and anchor in present_anchors:
                        semantics_verified.add(anchor)
                elif kind == "effect_observed":
                    effect_verified = True
            else:
                text = str(item).strip()
                if text:
                    # Legacy/plain evidence is retained as provenance only. It
                    # cannot advance semantic-anchor or effect verification.
                    rendered.append(text)

        ordered_semantics = tuple(a for a in anchors if a in semantics_verified)
        return tuple(rendered), ordered_semantics, effect_verified

    def build(
        self,
        evidence: Mapping[str, Iterable[EvidenceItem]] | None = None,
        *,
        source_root: str | Path | None = None,
    ) -> dict[str, Any]:
        evidence = evidence or {}
        repo_root = self._repo_root(source_root)
        literal_blueprint = load_literal_blueprint(default_blueprint_path(repo_root))
        rows: list[BlueprintClause] = []

        for cid, effect, anchors in self.CLAUSES:
            anchors = tuple(anchors)
            effect_hash = self._effect_sha256(effect)
            present, missing = self._verify_anchor_files(anchors, repo_root)
            ev, semantics_verified, effect_evidence_verified = self._normalize_evidence(
                cid,
                effect,
                anchors,
                present,
                evidence.get(cid, ()),
            )
            all_anchor_semantics_verified = bool(anchors) and set(semantics_verified) == set(anchors)

            if not anchors:
                if effect_evidence_verified:
                    status = "EFFECT_OBSERVED_WITHOUT_IMPLEMENTATION_ANCHOR"
                    reason = "effect-bound evidence exists, but no implementation anchor is declared for this frontier clause"
                else:
                    status = "UNRESOLVED"
                    reason = "requested frontier effect has no implementation anchor in this runtime"
            elif missing:
                status = "ANCHOR_DECLARED_NOT_PRESENT"
                reason = "one or more declared implementation-anchor files are absent from the verified source tree"
            elif not all_anchor_semantics_verified:
                if semantics_verified:
                    status = "ANCHOR_SEMANTICS_PARTIAL"
                    reason = "anchor files exist, but semantic verification is incomplete for the declared implementation anchors"
                elif ev:
                    status = "EVIDENCE_PRESENT_EFFECT_NOT_VERIFIED"
                    reason = "provenance/execution evidence exists, but no declared anchor is semantically verified for the exact requested effect"
                else:
                    status = "ANCHOR_FILES_PRESENT"
                    reason = "declared anchor files exist, but their implementation semantics have not been verified against the exact requested effect"
            elif not effect_evidence_verified:
                status = "ANCHOR_SEMANTICS_VERIFIED"
                reason = "all declared anchors are semantically verified, but the requested effect has not been truthfully observed in this run"
            else:
                status = "MATERIALIZED"
                reason = ""

            rows.append(
                BlueprintClause(
                    clause_id=cid,
                    requested_effect=effect,
                    literal_source=clause_literal_binding(cid, literal_blueprint),
                    requested_effect_sha256=effect_hash,
                    implementation_anchor=anchors,
                    present_anchor=present,
                    missing_anchor=missing,
                    semantics_verified_anchor=semantics_verified,
                    status=status,
                    evidence=ev,
                    anchor_semantics_verified=all_anchor_semantics_verified,
                    effect_evidence_verified=effect_evidence_verified,
                    unresolved_reason=reason,
                )
            )

        payload = {
            "schema": self.SCHEMA,
            "source_root": str(repo_root),
            "literal_blueprint": literal_blueprint.as_mapping(),
            "authority_rule": "literal blueprint bytes outrank summaries, labels, derived goal views, and implementation notes",
            "clauses": [x.as_mapping() for x in rows],
            "silent_substitution_allowed": False,
            "unresolved_clause_is_preserved_not_rewritten": True,
            "materialized_requires_present_and_semantically_verified_anchors_plus_effect_bound_evidence": True,
        }
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        payload["sha256"] = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        return payload
