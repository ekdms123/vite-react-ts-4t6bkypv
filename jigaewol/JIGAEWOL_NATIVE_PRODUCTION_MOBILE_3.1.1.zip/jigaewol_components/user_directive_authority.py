from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from typing import Any, Iterable, Mapping

from .directive_invariant import verify_atom_conservation, verify_destination

_NUMERIC = re.compile(r"(?<![0-9])([0-9][0-9_,]{1,})(?![0-9])")

@dataclass(frozen=True)
class UserDirectiveAuthority:
    """Canonical destination authority inside Jigaewol.

    Internal classifiers, profiles, budgets, verifiers, memory rankings and route
    failures may annotate or schedule work. They do not rewrite the user's exact
    destination or silently lower its requested scope/intensity.
    """
    exact_text: str
    text_sha256: str
    requirement_atoms: tuple[dict[str, Any], ...]
    numeric_aspirations: tuple[dict[str, Any], ...]
    no_silent_downgrade: bool = True
    semantic_ceiling: None = None
    route_failure_can_rewrite_destination: bool = False
    budget_can_rewrite_destination: bool = False
    verifier_can_rewrite_destination: bool = False
    classifier_can_rewrite_destination: bool = False
    memory_rank_can_delete_possibility: bool = False

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


def _numeric_aspirations(text: str) -> tuple[dict[str, Any], ...]:
    folded=text.casefold()
    cues=("목표","바라","원하","수준","까지","배","goal","target","aim","scale")
    out=[]
    for m in _NUMERIC.finditer(text):
        raw=m.group(1)
        try: value=int(raw.replace(',','').replace('_',''))
        except ValueError: continue
        if value < 10: continue
        lo=max(0,m.start()-32); hi=min(len(text),m.end()+32)
        ctx=folded[lo:hi]
        if any(cue in ctx for cue in cues):
            out.append({"raw":raw,"value":value,"context":text[lo:hi]})
    return tuple(out)


def compile_user_directive(message: str, requirements: Iterable[Mapping[str, Any]] = ()) -> UserDirectiveAuthority:
    if not isinstance(message,str) or not message.strip():
        raise ValueError('user directive needs nonempty exact text')
    exact=message
    digest=hashlib.sha256(exact.encode('utf-8')).hexdigest()
    verify_destination(raw_user_text=exact, original_user_directive_sha256=digest)
    atoms=[]
    for row in requirements or ():
        if isinstance(row, Mapping):
            atoms.append(dict(row))
    supplied_ids={str(row.get("atom_id") or "") for row in atoms if str(row.get("atom_id") or "")}
    if supplied_ids:
        verify_atom_conservation(raw_user_text=exact, active_atom_ids=supplied_ids)
    return UserDirectiveAuthority(
        exact_text=exact,
        text_sha256=digest,
        requirement_atoms=tuple(atoms),
        numeric_aspirations=_numeric_aspirations(exact),
    )
