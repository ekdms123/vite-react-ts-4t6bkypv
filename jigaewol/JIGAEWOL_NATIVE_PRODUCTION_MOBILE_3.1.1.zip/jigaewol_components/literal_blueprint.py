from __future__ import annotations

"""Byte-faithful authority layer for the Astra/JIGAEWOL organogenesis blueprint.

The blueprint text itself is authority.  Summaries, labels and implementation notes are
indexes only: they cannot replace, weaken or mutate the source bytes they point at.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Mapping
import hashlib


@dataclass(frozen=True, slots=True)
class LiteralSpan:
    span_id: str
    start_byte: int
    end_byte: int
    sha256: str
    text: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class LiteralBlueprint:
    path: str
    sha256: str
    byte_count: int
    source_is_authority: bool
    summaries_are_non_authoritative: bool
    spans: tuple[LiteralSpan, ...]

    def as_mapping(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "sha256": self.sha256,
            "byte_count": self.byte_count,
            "source_is_authority": self.source_is_authority,
            "summaries_are_non_authoritative": self.summaries_are_non_authoritative,
            "spans": [x.as_mapping() for x in self.spans],
        }


# Stable source markers.  These do not rewrite the text; they only locate byte ranges.
SECTION_MARKERS: tuple[tuple[str, str], ...] = (
    ("preamble", "이번에는 실제 코드를 수정하지 않고, 구현을 시도할 수 있는 상세 계획서로 쓴다."),
    ("01_bundle_and_contracts", "1. 무엇을 함께 만들어야 하는가"),
    ("02_organ_01_cyclic", "① 서로의 몸을 만들어주는 순환 합성기관"),
    ("02_organ_02_distinction", "② 표현이 놓친 차이에서 새 개념을 만드는 기관"),
    ("02_organ_03_contradiction", "③ 모순을 없애지 않고 계산 재료로 사용하는 기관"),
    ("02_organ_04_lift_world", "④ 현재 언어에서 불가능한 경로를 다른 계산 구조로 통과시키는 기관"),
    ("02_organ_05_translation", "⑤ 번역에서 소실되는 부분을 새로운 기관으로 만드는 구조"),
    ("02_organ_06_memory", "⑥ 기억을 저장하는 방식 자체를 탐색하는 기관"),
    ("02_organ_07_body", "⑦ 요구가 생길 때 필요한 몸을 구성하는 기관"),
    ("02_organ_08_experience", "⑧ 필요한 경험을 생성하고 그 경험에서 기관을 추출하는 구조"),
    ("02_organ_09_receiver", "⑨ 해답을 보내는 쪽과 받는 쪽을 함께 합성하는 기관"),
    ("02_organ_10_capsule", "⑩ 언어와 작동 규칙까지 가지고 이동하는 기관"),
    ("03_integrated_experiment", "3. 열 개를 실제로 연결하는 첫 통합 실험"),
    ("04_generator_self_change", "4. 생성기가 자기 자신을 바꾸는 단계"),
    ("05_code_units", "5. 실제 작성할 코드 단위와 순서"),
    ("06_r19_integration", "6. R19와 연결할 위치"),
    ("07_minimum_checks", "7. 최소한 확인할 네 가지"),
    ("08_research_frontier", "8. 원래의 불가능 목표에 남겨둘 연구 과제"),
)

# Fidelity-ledger ids are bound to literal source sections.  A summary is never used as
# a replacement for these spans.
CLAUSE_TO_SPAN: Mapping[str, str] = {
    "omega_bundle": "01_bundle_and_contracts",
    "01_cyclic_cobirth": "02_organ_01_cyclic",
    "02_distinction_birth": "02_organ_02_distinction",
    "03_contradiction_material": "02_organ_03_contradiction",
    "04_lift_world_project": "02_organ_04_lift_world",
    "05_translation_residual_organ": "02_organ_05_translation",
    "06_reverse_history": "02_organ_06_memory",
    "07_body_on_demand": "02_organ_07_body",
    "08_experience_birth": "02_organ_08_experience",
    "09_receiver_cobirth": "02_organ_09_receiver",
    "10_law_capsule": "02_organ_10_capsule",
    "11_generator_self_change": "04_generator_self_change",
    "12_r19_integration": "06_r19_integration",
    "04_extended_world_operations": "02_organ_04_lift_world",
    "08_experience_control_paths": "02_organ_08_experience",
    "07_host_nonstandard_connections": "02_organ_07_body",
    "09_enhanced_receiver": "03_integrated_experiment",
    "10_enhanced_capsule": "03_integrated_experiment",
    "11_generator_evolution_candidates": "04_generator_self_change",
    "frontier_reverse_causation": "08_research_frontier",
    "frontier_stateless_memory": "08_research_frontier",
    "frontier_literal_physical_contradiction": "08_research_frontier",
    "frontier_new_sense": "08_research_frontier",
    "frontier_local_physical_law": "08_research_frontier",
}


def _find_utf8(raw: bytes, marker: str) -> int:
    return raw.find(marker.encode("utf-8"))


def load_literal_blueprint(path: str | Path) -> LiteralBlueprint:
    p = Path(path).resolve()
    raw = p.read_bytes()
    starts: list[tuple[str, int]] = []
    for span_id, marker in SECTION_MARKERS:
        idx = _find_utf8(raw, marker)
        if idx < 0:
            raise ValueError(f"literal blueprint marker missing: {span_id}: {marker!r}")
        starts.append((span_id, idx))
    starts.sort(key=lambda row: row[1])
    spans: list[LiteralSpan] = []
    for i, (span_id, start) in enumerate(starts):
        end = starts[i + 1][1] if i + 1 < len(starts) else len(raw)
        chunk = raw[start:end]
        spans.append(LiteralSpan(
            span_id=span_id,
            start_byte=start,
            end_byte=end,
            sha256=hashlib.sha256(chunk).hexdigest(),
            text=chunk.decode("utf-8", errors="strict"),
        ))
    return LiteralBlueprint(
        path=str(p),
        sha256=hashlib.sha256(raw).hexdigest(),
        byte_count=len(raw),
        source_is_authority=True,
        summaries_are_non_authoritative=True,
        spans=tuple(spans),
    )


def clause_literal_binding(clause_id: str, blueprint: LiteralBlueprint) -> dict[str, Any]:
    span_id = CLAUSE_TO_SPAN.get(str(clause_id), "")
    by_id = {x.span_id: x for x in blueprint.spans}
    span = by_id.get(span_id)
    if span is None:
        return {
            "clause_id": str(clause_id),
            "bound": False,
            "source_blueprint_sha256": blueprint.sha256,
            "authority": "literal_blueprint_bytes",
        }
    return {
        "clause_id": str(clause_id),
        "bound": True,
        "source_blueprint_sha256": blueprint.sha256,
        "span_id": span.span_id,
        "start_byte": span.start_byte,
        "end_byte": span.end_byte,
        "span_sha256": span.sha256,
        "requested_text": span.text,
        "authority": "literal_blueprint_bytes",
        "summary_may_not_replace_source": True,
    }


def default_blueprint_path(source_root: str | Path | None = None) -> Path:
    root = Path(source_root).resolve() if source_root is not None else Path(__file__).resolve().parents[1]
    return root / "blueprints" / "ASTRA_ORIGINAL_BLUEPRINT.txt"
