from __future__ import annotations

import hashlib
import json
import os
import sys
try:
    import resource
except ImportError:
    if sys.platform != 'emscripten':raise
    resource = None
import shutil
import stat
import subprocess
import time
import uuid
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class IsolationPreflight:
    archive_sha256: str
    file_count: int
    total_uncompressed_bytes: int
    path_escape_detected: bool
    symlink_count: int
    executable_entry_count: int
    suspicious_names: tuple[str, ...]
    accepted: bool


@dataclass(frozen=True)
class IsolationCapability:
    filesystem_isolation: bool
    secret_env_stripping: bool
    resource_limits: bool
    network_namespace_proven: bool
    kernel_boundary_proven: bool
    suitable_for_untrusted_network_capable_code: bool
    required_upgrade_class: str


class IsolatedExecutor:
    """Zero-dependency disposable executor for untrusted source archives.

    It separates workspace/home/environment and applies resource/time limits.
    Filesystem and network boundaries are reported from actual provider probes.  It
    does *not* claim perfect malware detection or a kernel network namespace when
    the host does not provide one; those limitations remain explicit evidence.
    """

    SECRET_MARKERS = ("KEY", "TOKEN", "SECRET", "PASSWORD", "COOKIE", "AUTH", "CREDENTIAL")

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def isolation_capability() -> IsolationCapability:
        # CWD/workspace separation does not isolate filesystem reads.
        # Do not convert `unshare` being installed into a namespace claim: many hosted
        # sandboxes deny the required kernel capability at runtime.
        return IsolationCapability(
            filesystem_isolation=False,
            secret_env_stripping=True,
            resource_limits=resource is not None,
            network_namespace_proven=False,
            kernel_boundary_proven=False,
            suitable_for_untrusted_network_capable_code=False,
            required_upgrade_class="kernel_or_vm_isolated_executor",
        )

    def execution_admission(self, *, trust_level: str, network_needed: bool = False) -> dict[str, Any]:
        iso = self.isolation_capability()
        trust = str(trust_level or "reviewed").casefold()
        untrusted = trust in {"untrusted", "unknown", "third_party_unreviewed"}
        local_allowed = not untrusted
        if untrusted and not iso.suitable_for_untrusted_network_capable_code:
            local_allowed = False
        return {
            "trust_level": trust,
            "network_needed": bool(network_needed),
            "local_execution_allowed": local_allowed,
            "isolation": asdict(iso),
            "next_route": "local_isolated_execution" if local_allowed else iso.required_upgrade_class,
            "possibility_rejected": False,
            "effect_deferred_until_stronger_body": not local_allowed,
        }

    @staticmethod
    def _sha(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def preflight(self, archive: str | Path, *, max_files: int = 10000, max_uncompressed_bytes: int = 512 * 1024 * 1024) -> IsolationPreflight:
        path = Path(archive)
        suspicious = []
        escapes = False
        symlinks = 0
        executables = 0
        total = 0
        count = 0
        with zipfile.ZipFile(path) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                count += 1; total += int(info.file_size)
                name = info.filename.replace("\\", "/")
                parts = Path(name).parts
                if name.startswith("/") or ".." in parts:
                    escapes = True
                mode = (info.external_attr >> 16) & 0xFFFF
                if stat.S_ISLNK(mode):
                    symlinks += 1
                if mode & 0o111:
                    executables += 1
                low = name.casefold()
                if any(x in low for x in ("id_rsa", ".env", "credentials", "keychain", "wallet.dat")):
                    suspicious.append(name)
        accepted = not escapes and symlinks == 0 and count <= max_files and total <= max_uncompressed_bytes
        return IsolationPreflight(self._sha(path), count, total, escapes, symlinks, executables,
                                   tuple(suspicious), accepted)

    def materialize(self, archive: str | Path) -> tuple[Path, IsolationPreflight]:
        report = self.preflight(archive)
        if not report.accepted:
            raise PermissionError(f"archive rejected by isolation preflight: {asdict(report)}")
        workspace = self.root / ("q_" + uuid.uuid4().hex[:16])
        workspace.mkdir(parents=True, exist_ok=False)
        with zipfile.ZipFile(archive) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                target = (workspace / info.filename).resolve()
                if workspace.resolve() not in target.parents:
                    raise PermissionError("archive path escaped isolated workspace")
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, target.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
        (workspace / "QUARANTINE_PREFLIGHT.json").write_text(json.dumps(asdict(report), indent=2) + "\n", encoding="utf-8")
        return workspace, report

    @classmethod
    def _clean_env(cls, workspace: Path) -> dict[str, str]:
        keep = {"PATH", "LANG", "LC_ALL", "TZ", "PYTHONPATH", "VIRTUAL_ENV"}
        env = {k: v for k, v in os.environ.items() if k in keep and not any(m in k.upper() for m in cls.SECRET_MARKERS)}
        home = workspace / ".home"; home.mkdir(exist_ok=True)
        env.update({"HOME": str(home), "TMPDIR": str(workspace / ".tmp"), "JIGAEWOL_ISOLATED_EXECUTION": "1",
                    "PYTHONDONTWRITEBYTECODE": "1", "GIT_CONFIG_NOSYSTEM": "1"})
        Path(env["TMPDIR"]).mkdir(exist_ok=True)
        return env

    @staticmethod
    def _limits() -> None:
        if resource is None:raise RuntimeError('native resource limits require an observed native executor')
        resource.setrlimit(resource.RLIMIT_CPU, (15, 15))
        resource.setrlimit(resource.RLIMIT_FSIZE, (64 * 1024 * 1024, 64 * 1024 * 1024))
        try:
            resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
        except (ValueError, OSError):
            pass

    def run(
        self, workspace: str | Path, argv: Iterable[str], *, cwd: str = "", timeout: float = 20.0,
        trust_level: str = "reviewed", allow_weak_isolation: bool = False, network_needed: bool = False,
    ) -> dict[str, Any]:
        admission = self.execution_admission(trust_level=trust_level, network_needed=network_needed)
        if not admission["local_execution_allowed"] and not allow_weak_isolation:
            raise PermissionError(
                "untrusted code preserved as a candidate but external effect deferred: "
                "kernel/VM-isolated executor required"
            )
        ws = Path(workspace).resolve()
        run_cwd = (ws / cwd).resolve() if cwd else ws
        if ws not in run_cwd.parents and run_cwd != ws:
            raise PermissionError("run cwd must stay inside isolated workspace")
        started = time.time()
        proc = subprocess.run(list(argv), cwd=run_cwd, env=self._clean_env(ws), text=True, capture_output=True,
                              timeout=float(timeout), preexec_fn=self._limits)
        return {"executed": True, "argv": list(argv), "cwd": str(run_cwd), "exit_code": proc.returncode,
                "stdout": proc.stdout, "stderr": proc.stderr, "duration_seconds": time.time()-started,
                "network_namespace_proven": False, "kernel_boundary_proven": False,
                "secret_environment_stripped": True, "isolation_admission": admission,
                "weak_isolation_override": bool(allow_weak_isolation and not admission["local_execution_allowed"]),
                "success": proc.returncode == 0}
