from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class JIRNode:
    node_id: str
    kind: str
    label: str
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class JIREdge:
    source: str
    relation: str
    target: str


@dataclass(frozen=True)
class JIRGraph:
    graph_id: str
    objective_sha256: str
    nodes: tuple[JIRNode, ...]
    edges: tuple[JIREdge, ...]
    created_at: float
    schema: str = "jigaewol_ir_v1"

    def as_mapping(self) -> dict[str, Any]:
        return {
            "schema": self.schema,
            "graph_id": self.graph_id,
            "objective_sha256": self.objective_sha256,
            "nodes": [asdict(x) for x in self.nodes],
            "edges": [asdict(x) for x in self.edges],
            "created_at": self.created_at,
        }


class JIGAEWOLIR:
    """Tiny typed effect IR.

    The IR is deliberately small: obligation -> effect -> capability -> evidence -> truth,
    with continuation nodes for unfinished work.  It is an executable coordination format,
    not a prompt dump.  Provider-specific details are late-bound in node payloads.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.ledger = self.root / "graphs.jsonl"

    @staticmethod
    def _node(kind: str, label: str, payload: dict[str, Any] | None = None) -> JIRNode:
        basis = json.dumps([kind, label, payload or {}, uuid.uuid4().hex], ensure_ascii=False, sort_keys=True).encode()
        return JIRNode("jir_" + hashlib.sha256(basis).hexdigest()[:20], kind, label, dict(payload or {}))

    def compile(
        self,
        objective: str,
        *,
        obligations: Iterable[str] = (),
        effects: Iterable[str] = (),
        capabilities: Iterable[str] = (),
        continuation: str = "",
    ) -> JIRGraph:
        text = str(objective)
        root = self._node("objective", "user_objective", {"sha256": hashlib.sha256(text.encode()).hexdigest()})
        nodes: list[JIRNode] = [root]
        edges: list[JIREdge] = []

        obs = list(dict.fromkeys(str(x) for x in obligations if str(x))) or ["preserve_objective_fidelity"]
        effs = list(dict.fromkeys(str(x) for x in effects if str(x))) or ["produce_observed_effect"]
        caps = list(dict.fromkeys(str(x) for x in capabilities if str(x)))

        obligation_nodes = [self._node("obligation", x) for x in obs]
        effect_nodes = [self._node("effect", x) for x in effs]
        capability_nodes = [self._node("capability", x, {"binding": "late"}) for x in caps]
        nodes.extend(obligation_nodes + effect_nodes + capability_nodes)
        for n in obligation_nodes:
            edges.append(JIREdge(root.node_id, "requires", n.node_id))
        for n in obligation_nodes:
            for e in effect_nodes:
                edges.append(JIREdge(n.node_id, "satisfied_by", e.node_id))
        for e in effect_nodes:
            for c in capability_nodes:
                edges.append(JIREdge(e.node_id, "may_bind_to", c.node_id))

        evidence = self._node("evidence", "observed_execution_receipt", {"required": True})
        truth = self._node("truth", "promotion_gate", {"rule": "no_success_without_observed_evidence"})
        nodes.extend([evidence, truth])
        for e in effect_nodes:
            edges.append(JIREdge(e.node_id, "requires_evidence", evidence.node_id))
        edges.append(JIREdge(evidence.node_id, "promotes", truth.node_id))

        if continuation:
            cont = self._node("continuation", continuation, {"state": "open"})
            nodes.append(cont)
            edges.append(JIREdge(root.node_id, "continues_as", cont.node_id))

        canonical = json.dumps({
            "objective": hashlib.sha256(text.encode()).hexdigest(),
            "nodes": [asdict(x) for x in nodes],
            "edges": [asdict(x) for x in edges],
        }, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
        graph = JIRGraph(
            graph_id="jirgraph_" + hashlib.sha256(canonical).hexdigest()[:20],
            objective_sha256=hashlib.sha256(text.encode()).hexdigest(),
            nodes=tuple(nodes),
            edges=tuple(edges),
            created_at=time.time(),
        )
        with self.ledger.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(graph.as_mapping(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return graph
