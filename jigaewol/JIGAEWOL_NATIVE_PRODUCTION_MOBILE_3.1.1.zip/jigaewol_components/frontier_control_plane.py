from __future__ import annotations

import hashlib
import os
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .code_doctor import RuntimeCodeDoctor
from .free_provider_catalog import FreeProviderCatalog
from .hunt_graph import HuntGraph
from .jir import JIGAEWOLIR
from .probe_scheduler import InformationGainScheduler
from .quarantine_materializer import QuarantineMaterializer
from .self_heal import SelfHealSupervisor
from .unwritten_machine import UnwrittenMachine
from .authority_guard import source_effect_authorized


@dataclass(frozen=True)
class FrontierTurnState:
    state_id: str
    message_sha256: str
    jir_graph_id: str
    open_opcode_ids: tuple[str, ...]
    requirement_count: int
    semantic_ceiling: None
    no_silent_downgrade: bool
    hard_spend_cap_usd: float
    code_doctor_report_id: str
    code_doctor_high_findings: int
    quarantine_materializer_ready: bool
    quarantine_network_namespace_proven: bool
    created_at: float

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class FrontierControlPlane:
    """Open-ended self-improvement control plane on the canonical turn path.

    It does not claim a capability merely because a target is ambitious. It keeps the
    semantic ceiling unset, converts live requirements into typed effects/opcodes, and
    makes structural defects durable repair work. This is the bridge between the R3
    modules and the actual canonical runtime rather than a sidecar demo.
    """

    def __init__(self, state_root: Path, *, source_root: Path) -> None:
        self.root = Path(state_root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.source_root = Path(source_root).resolve()
        self.jir = JIGAEWOLIR(self.root / "jir")
        self.unwritten = UnwrittenMachine(self.root / "unwritten_machine")
        self.self_heal = SelfHealSupervisor(self.root / "self_heal")
        self.hunt = HuntGraph(self.root / "hunt")
        self.free_catalog = FreeProviderCatalog(evidence_root=self.root / "free_provider_evidence")
        self.probes = InformationGainScheduler()
        self.code_doctor = RuntimeCodeDoctor(self.source_root, self.root / "code_doctor")
        self.quarantine = QuarantineMaterializer(self.root / "quarantine_materializer")
        self.turns_path = self.root / "frontier_turns.jsonl"
        self.frontier_requirements_path = self.source_root / "USER_FRONTIER_REQUIREMENTS_2026-09-26.json"


    def _seed_project_frontier(self) -> tuple[str, ...]:
        if not self.frontier_requirements_path.is_file():
            return ()
        try:
            data = json.loads(self.frontier_requirements_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("frontier requirements must be a JSON object")
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            failure_path = self.root / "frontier_requirement_failures.jsonl"
            row = {
                "kind": "frontier_requirements_corrupt",
                "source": str(self.frontier_requirements_path),
                "error_type": type(exc).__name__,
                "error": str(exc),
                "created_at": time.time(),
            }
            with failure_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")
            raise RuntimeError(f"frontier requirements unreadable or corrupt: {exc}") from exc
        open_ids: list[str] = []
        for requirement in data.get("requirements") or ():
            text = str(requirement).strip()
            if not text:
                continue
            rid = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
            op = self.unwritten.declare(
                f"frontier_requirement:{rid}",
                required_traits=("user_outcome_evidence", "no_silent_downgrade", "keep_open_until_delivered_or_changed"),
                materializers=({"kind": "project_frontier_requirement", "text": text},),
            )
            if op.state != "materialized":
                open_ids.append(op.opcode_id)
        return tuple(open_ids)

    @staticmethod
    def _atom_rows(requirement_contract: Any) -> tuple[dict[str, Any], ...]:
        rows = []
        for atom in getattr(requirement_contract, "atoms", ()) or ():
            rows.append({
                "atom_id": str(getattr(atom, "atom_id", "")),
                "text": str(getattr(atom, "text", "")),
                "kind": str(getattr(atom, "kind", "preference")),
                "critical": bool(getattr(atom, "critical", False)),
                "tags": tuple(getattr(atom, "tags", ()) or ()),
            })
        return tuple(rows)

    def prepare_turn(
        self,
        command: str,
        *,
        requirement_contract: Any,
        semantic_authority: Mapping[str, Any] | None = None,
        observed_capabilities: Iterable[str] = (),
    ) -> FrontierTurnState:
        atoms = self._atom_rows(requirement_contract)
        obligations = [f"{x['atom_id']}:{x['text']}" for x in atoms]
        effects = [f"fulfill:{x['atom_id']}" for x in atoms if x["kind"] == "action" or x["critical"]]
        if not effects:
            effects = ["preserve_requirement_fidelity"]
        capabilities = list(dict.fromkeys(str(x) for x in observed_capabilities if str(x)))
        authority = dict(semantic_authority or {})
        trait_hints = tuple(str(x) for x in authority.get("required_capability_traits") or () if str(x))
        if source_effect_authorized(authority):
            for trait in trait_hints:
                if trait not in capabilities:
                    capabilities.append(trait)
        graph = self.jir.compile(
            command,
            obligations=obligations,
            effects=effects,
            capabilities=capabilities,
            continuation="keep_unfinished_requirements_live",
        )

        open_ids: list[str] = list(self._seed_project_frontier())
        for atom in atoms:
            if atom["kind"] != "action" and not atom["critical"]:
                continue
            op = self.unwritten.declare(
                f"fulfill_requirement:{atom['atom_id']}",
                required_traits=("observed_evidence", "no_silent_downgrade", "objective_fidelity"),
                materializers=(
                    {"kind": "quarantine_source_materializer", "requirement_text": atom["text"], "promotion_requires": ["source_identity", "license", "static_scan", "bounded_probe"]},
                    {"kind": "late_bound_host_or_generated_body", "requirement_text": atom["text"]},
                ),
            )
            if op.state != "materialized":
                open_ids.append(op.opcode_id)

        # Self-modification source scans run during explicit maintenance, not on every
        # user message.  They are orthogonal to executing the current user task.
        doctor_id = ""
        high = 0
        maintenance_requested = os.environ.get("JIGAEWOL_MAINTENANCE_SCAN", "").lower() in {"1", "true", "yes"}
        if maintenance_requested:
            doctor = self.code_doctor.scan(force=False)
            doctor_id = doctor.report_id
            high = sum(1 for x in doctor.findings if x.severity in {"critical", "high"})
            for finding in doctor.findings:
                if finding.severity not in {"critical", "high"}:
                    continue
                op = self.unwritten.declare(
                    f"repair_code_finding:{finding.finding_id}",
                    required_traits=("targeted_patch", "regression_evidence", "no_capability_regression"),
                    materializers=({"kind": "source_patch", "path": finding.path, "line": finding.line, "category": finding.category},),
                )
                if op.state != "materialized":
                    open_ids.append(op.opcode_id)
        elif self.code_doctor.latest_path.is_file():
            try:
                last = json.loads(self.code_doctor.latest_path.read_text(encoding="utf-8"))
                doctor_id = str(last.get("report_id") or "")
                high = sum(1 for x in last.get("findings", ()) if x.get("severity") in {"critical", "high"})
            except (ValueError, TypeError, OSError):
                pass

        now = time.time()
        message_sha = hashlib.sha256(str(command).encode("utf-8")).hexdigest()
        state = FrontierTurnState(
            state_id="frontier_" + hashlib.sha256(
                json.dumps([message_sha, graph.graph_id, sorted(set(open_ids)), doctor_id], sort_keys=True).encode("utf-8")
            ).hexdigest()[:20],
            message_sha256=message_sha,
            jir_graph_id=graph.graph_id,
            open_opcode_ids=tuple(dict.fromkeys(open_ids)),
            requirement_count=len(atoms),
            semantic_ceiling=None,
            no_silent_downgrade=True,
            hard_spend_cap_usd=self.free_catalog.hard_spend_cap_usd,
            code_doctor_report_id=doctor_id,
            code_doctor_high_findings=high,
            quarantine_materializer_ready=True,
            quarantine_network_namespace_proven=self.quarantine.executor.isolation_capability().network_namespace_proven,
            created_at=now,
        )
        with self.turns_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(state.as_mapping(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return state
