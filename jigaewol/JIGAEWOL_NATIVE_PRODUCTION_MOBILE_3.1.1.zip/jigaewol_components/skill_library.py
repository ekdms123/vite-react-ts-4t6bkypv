from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence


def _tokens(text: str) -> set[str]:
    return {x for x in re.findall(r"[\w가-힣]+", str(text).lower()) if len(x) > 1}


def _fingerprint(objective: str, action: str, capabilities: Sequence[str], facets: dict[str, Any]) -> str:
    raw = json.dumps(
        {
            "objective_tokens": sorted(_tokens(objective)),
            "action": str(action),
            "capabilities": sorted(map(str, capabilities)),
            "facets": facets,
        },
        ensure_ascii=False,
        sort_keys=True,
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class SkillRecord:
    skill_id: str
    fingerprint: str
    title: str
    objective_pattern: str
    action: str
    steps: tuple[dict[str, Any], ...]
    capabilities: tuple[str, ...]
    evidence: tuple[str, ...]
    success_count: int
    failure_count: int
    source_episode_ids: tuple[str, ...]
    created_at: float
    updated_at: float
    facets: dict[str, Any] = field(default_factory=dict)

    @property
    def reliability(self) -> float:
        total = self.success_count + self.failure_count
        return self.success_count / total if total else 0.0


class SkillLibrary:
    """Crystallizes reality-backed successful execution paths into reusable skills.

    A skill cannot be forged from prose alone: verified execution evidence is required.
    Empirical reuse updates reliability dynamically over time.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"skills": {}})

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def crystallize(
        self,
        *,
        objective: str,
        action: str,
        steps: Iterable[dict[str, Any]],
        capabilities: Iterable[str],
        evidence: Iterable[str],
        success: bool,
        source_episode_id: str = "",
        title: str | None = None,
        facets: dict[str, Any] | None = None,
    ) -> SkillRecord:
        evidence_t = tuple(str(x) for x in evidence if str(x))
        if not evidence_t:
            raise ValueError("observed evidence is required to crystallize an experience recipe")
        capabilities_t = tuple(dict.fromkeys(str(x) for x in capabilities if str(x)))
        facets_d = dict(facets or {})
        fp = _fingerprint(objective, action, capabilities_t, facets_d)
        data = self._read()
        skills = data.setdefault("skills", {})
        now = time.time()
        existing = next((row for row in skills.values() if row.get("fingerprint") == fp), None)
        if existing:
            source_ids = tuple(
                dict.fromkeys(
                    [*existing.get("source_episode_ids", []), source_episode_id]
                    if source_episode_id
                    else existing.get("source_episode_ids", [])
                )
            )
            merged_evidence = tuple(dict.fromkeys([*existing.get("evidence", []), *evidence_t]))
            updated = {
                **existing,
                "steps": list(steps) or existing.get("steps", []),
                "evidence": list(merged_evidence),
                "success_count": int(existing.get("success_count", 0)) + (1 if success else 0),
                "failure_count": int(existing.get("failure_count", 0)) + (0 if success else 1),
                "source_episode_ids": list(source_ids),
                "updated_at": now,
            }
            skills[existing["skill_id"]] = updated
            self._write(data)
            return SkillRecord(
                **{
                    **updated,
                    "steps": tuple(updated["steps"]),
                    "capabilities": tuple(updated["capabilities"]),
                    "evidence": tuple(updated["evidence"]),
                    "source_episode_ids": tuple(updated["source_episode_ids"]),
                }
            )

        skill_id = f"skill_{fp[:16]}"
        row = SkillRecord(
            skill_id=skill_id,
            fingerprint=fp,
            title=str(title or action or objective),
            objective_pattern=str(objective),
            action=str(action),
            steps=tuple(dict(x) for x in steps),
            capabilities=capabilities_t,
            evidence=evidence_t,
            success_count=(1 if success else 0),
            failure_count=(0 if success else 1),
            source_episode_ids=(source_episode_id,) if source_episode_id else (),
            created_at=now,
            updated_at=now,
            facets=facets_d,
        )
        skills[skill_id] = asdict(row)
        self._write(data)
        return row

    def record_reuse(self, skill_id: str, *, success: bool, evidence: Iterable[str] = ()) -> SkillRecord:
        data = self._read()
        row = data.get("skills", {}).get(skill_id)
        if row is None:
            raise KeyError(skill_id)
        row["success_count" if success else "failure_count"] = (
            int(row.get("success_count" if success else "failure_count", 0)) + 1
        )
        row["evidence"] = list(dict.fromkeys([*row.get("evidence", []), *(str(x) for x in evidence if str(x))]))
        row["updated_at"] = time.time()
        data["skills"][skill_id] = row
        self._write(data)
        return SkillRecord(
            **{
                **row,
                "steps": tuple(row["steps"]),
                "capabilities": tuple(row["capabilities"]),
                "evidence": tuple(row["evidence"]),
                "source_episode_ids": tuple(row["source_episode_ids"]),
            }
        )

    def retrieve(self, objective: str, *, capabilities: Iterable[str] = (), limit: int | None = None) -> tuple[SkillRecord, ...]:
        q = _tokens(objective)
        need = set(map(str, capabilities))
        scored: list[tuple[float, SkillRecord]] = []
        for raw in self._read().get("skills", {}).values():
            row = SkillRecord(
                **{
                    **raw,
                    "steps": tuple(raw["steps"]),
                    "capabilities": tuple(raw["capabilities"]),
                    "evidence": tuple(raw["evidence"]),
                    "source_episode_ids": tuple(raw["source_episode_ids"]),
                }
            )
            rt = _tokens(row.objective_pattern)
            lexical = len(q & rt) / max(1, len(q | rt))
            cap = len(need & set(row.capabilities)) / max(1, len(need)) if need else 0.0
            # Direct relevance, capability fit, and empirical history remain separate
            # dimensions; no arbitrary weighted sum gets to define meaning.
            relevance = max(lexical, cap)
            scored.append((relevance, row))
        scored.sort(key=lambda x: (x[0], bool(x[1].evidence), x[1].updated_at), reverse=True)
        visible = scored if limit is None else scored[: max(0, int(limit))]
        return tuple(row for score, row in visible if score > 0)

    def all(self) -> tuple[SkillRecord, ...]:
        rows=[]
        for raw in self._read().get("skills", {}).values():
            rows.append(SkillRecord(**{**raw, "steps": tuple(raw["steps"]), "capabilities": tuple(raw["capabilities"]), "evidence": tuple(raw["evidence"]), "source_episode_ids": tuple(raw["source_episode_ids"])}))
        return tuple(rows)
