from __future__ import annotations

import json
import os
import uuid
from contextlib import contextmanager

from .file_lock import exclusive_lock
from dataclasses import asdict, replace
from pathlib import Path

from .response_protocol import (
    CandidateResponse, CandidateBundle, ReleasedResponse, ReleasedHypothesis, ReleasedResponseGroup, sha256_text
)


class ResponseCAS:
    """Durable content-addressed storage for released response bodies."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _fsync_dir(path: Path) -> None:
        try:
            fd = os.open(str(path), os.O_DIRECTORY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        except (AttributeError, OSError):
            pass

    def _blob_path(self, sha256: str) -> Path:
        return self.root / "sha256" / sha256[:2] / sha256

    def put_text(self, body: str, *, expected_sha256: str | None = None) -> tuple[str, int, Path]:
        data = body.encode("utf-8")
        sha = str(expected_sha256 or sha256_text(body))
        final_path = self._blob_path(sha)
        final_path.parent.mkdir(parents=True, exist_ok=True)

        if not final_path.exists():
            tmp = final_path.with_name(final_path.name + f".{uuid.uuid4().hex}.tmp")
            with tmp.open("xb") as fh:
                fh.write(data)
                fh.flush()
                os.fsync(fh.fileno())
            # CAS publication is atomic. Existing identical content wins harmlessly.
            try:
                if hasattr(os,'link'):
                    os.link(tmp, final_path)
                else:
                    # Private WASM MEMFS supports atomic rename but no hard links.
                    # The caller holds the per-sink transaction lock throughout.
                    import sys
                    from .file_lock import lock_status
                    if sys.platform!='emscripten' or lock_status()['lock_scope']!='one_worker_private_memfs':raise RuntimeError('CAS needs an observed atomic filesystem primitive')
                    os.rename(tmp,final_path)
            except FileExistsError:
                pass
            finally:
                tmp.unlink(missing_ok=True)
            self._fsync_dir(final_path.parent)

        read_back = final_path.read_bytes()
        if len(read_back) != len(data):
            raise PermissionError("release integrity: CAS blob size mismatch")
        import hashlib
        actual = hashlib.sha256(read_back).hexdigest()
        if actual != sha or read_back != data:
            raise PermissionError("release integrity: CAS blob read-back mismatch")
        return actual, len(read_back), final_path


class ResponseSink:
    """Durable content-addressed storage for user-facing response bodies.

    The canonical hot path treats this component as an integrity sink only.
    """

    def __init__(self, root: Path, *, require_finalization_permit: bool = True) -> None:
        """Publish only with a verified finalizer permit; raw storage uses ResponseCAS."""
        self.root = Path(root)
        self.require_finalization_permit = True
        self.root.mkdir(parents=True, exist_ok=True)
        self.release_dir = self.root / "releases"
        self.release_dir.mkdir(exist_ok=True)
        self.staging_dir = self.root / "staging"
        self.staging_dir.mkdir(exist_ok=True)
        self.cas = ResponseCAS(self.root / "cas")
        self.release_lock_path = self.root / ".release.lock"
        self.release_lock_path.touch(exist_ok=True)

    @contextmanager
    def _release_lock(self):
        """Serialize CAS publication across sink instances/processes."""
        # Lock unavailability is recorded, not swallowed: see jigaewol_components.file_lock.
        with exclusive_lock(self.release_lock_path) as status:
            self.lock_status = status
            yield

    @staticmethod
    def _atomic_stage(path: Path, payload: dict) -> Path:
        # Projection files are rebuildable from durable CAS content.  Do not pay
        # an fsync on this non-authoritative convenience copy.
        tmp = path.with_name(path.name + f".{uuid.uuid4().hex}.tmp")
        with tmp.open("w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
            fh.flush()
        return tmp

    @staticmethod
    def _fsync_dir(path: Path) -> None:
        try:
            fd = os.open(str(path), os.O_DIRECTORY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        except (AttributeError, OSError):
            pass

    @classmethod
    def _promote_projection(cls, staged: Path, final_path: Path) -> None:
        os.replace(staged, final_path)

    def recover(self, turn_id: str) -> ReleasedResponse:
        """Recover a released response from the CAS-backed projection."""
        return self._recover_integrity_only(turn_id)

    def _recover_integrity_only(self, turn_id: str) -> ReleasedResponse:
        path = self.release_dir / f"{turn_id}.json"
        if not path.is_file():
            raise PermissionError("no integrity release projection for this turn")
        row = json.loads(path.read_text(encoding="utf-8"))
        released = ReleasedResponse(**row)
        body = self.cas._blob_path(released.blob_sha256).read_text(encoding="utf-8")
        if sha256_text(body) != released.body_sha256:
            raise PermissionError("release integrity: CAS body digest mismatch on recovery")
        return replace(released, body=body)

    def _release_integrity_only(self, *, candidate: CandidateResponse, actual_sha: str) -> ReleasedResponse:
        """Persist and verify the body in CAS with no permit and no permission check."""
        blob_sha256, blob_size_bytes, _blob_path = self.cas.put_text(
            candidate.body, expected_sha256=actual_sha
        )
        if blob_sha256 != actual_sha:
            raise PermissionError("release integrity: CAS/body digest mismatch")
        released = ReleasedResponse(
            turn_id=candidate.turn_id,
            body=candidate.body,
            body_sha256=actual_sha,
            blob_sha256=blob_sha256,
            blob_size_bytes=blob_size_bytes,
            integrity_receipt_id="integrity_" + blob_sha256[:24],
            integrity_sha256=blob_sha256,
            release_format="direct-cas-v1",
        )
        final_path = self.release_dir / f"{candidate.turn_id}.json"
        if final_path.exists():
            raise PermissionError("release integrity: turn already has a released response")
        staged = self._atomic_stage(self.staging_dir / f"{candidate.turn_id}.json", asdict(released))
        try:
            self._promote_projection(staged, final_path)
            return released
        finally:
            if staged.exists():
                staged.unlink(missing_ok=True)

    def _release_unlocked(self, *, candidate: CandidateResponse, user_command: str) -> ReleasedResponse:
        return self._release_integrity_only(candidate=candidate, actual_sha=candidate.response_sha256)


    def recover_group(self, turn_id: str) -> ReleasedResponseGroup:
        path = self.release_dir / f"{turn_id}.json"
        if not path.is_file():
            raise PermissionError("no integrity release projection for this turn")
        row = json.loads(path.read_text(encoding="utf-8"))
        hypotheses = []
        for item in row.get("hypotheses", ()):
            item = dict(item)
            body = self.cas._blob_path(str(item["blob_sha256"])).read_text(encoding="utf-8")
            if sha256_text(body) != str(item["body_sha256"]):
                raise PermissionError("release integrity: response-group CAS/body digest mismatch")
            hypotheses.append(ReleasedHypothesis(**{**item, "body": body}))
        return ReleasedResponseGroup(
            turn_id=str(row["turn_id"]),
            release_group_id=str(row["release_group_id"]),
            bundle_sha256=str(row["bundle_sha256"]),
            hypotheses=tuple(hypotheses),
            integrity_receipt_id="integrity_group_" + str(row["bundle_sha256"])[:24],
            release_format="direct-cas-group-v1",
        )

    def _release_group_unlocked(self, *, bundle: CandidateBundle, user_command: str) -> ReleasedResponseGroup:
        released_children = []
        for candidate in bundle.candidates:
            blob_sha, blob_size, _blob_path = self.cas.put_text(candidate.body, expected_sha256=candidate.response_sha256)
            if blob_sha != candidate.response_sha256:
                raise PermissionError("release integrity: response-group CAS/body digest mismatch")
            released_children.append(
                ReleasedHypothesis(
                    candidate_id=candidate.candidate_id,
                    body=candidate.body,
                    body_sha256=candidate.response_sha256,
                    blob_sha256=blob_sha,
                    blob_size_bytes=blob_size,
                    integrity_receipt_id="integrity_" + blob_sha[:24],
                )
            )
        released = ReleasedResponseGroup(
            turn_id=bundle.turn_id,
            release_group_id=bundle.release_group_id,
            bundle_sha256=bundle.bundle_sha256,
            hypotheses=tuple(released_children),
            integrity_receipt_id="integrity_group_" + bundle.bundle_sha256[:24],
            release_format="direct-cas-group-v1",
        )
        final_path = self.release_dir / f"{bundle.turn_id}.json"
        if final_path.exists():
            raise PermissionError("release integrity: turn already has a released response")
        staged = self._atomic_stage(self.staging_dir / f"{bundle.turn_id}.json", asdict(released))
        try:
            self._promote_projection(staged, final_path)
            return released
        finally:
            staged.unlink(missing_ok=True)

    def release_group(self, *, bundle: CandidateBundle, user_command: str) -> ReleasedResponseGroup:
        """Atomically release multiple hash-bound hypotheses as one integrity group."""
        if self.require_finalization_permit:
            raise PermissionError("release integrity: canonical response-group publication requires FinalizationPermit")
        with self._release_lock():
            return self._release_group_unlocked(bundle=bundle, user_command=user_command)

    def commit_group(self, *, bundle: CandidateBundle, permit, user_command: str, permit_verifier=None) -> ReleasedResponseGroup:
        """Publish a response group only when its exact bundle hash has finality proof."""
        if permit_verifier is not None and permit_verifier(permit) is not True:
            raise PermissionError("release integrity: invalid finalization permit")
        if str(getattr(permit, "turn_id", "")) != str(bundle.turn_id):
            raise PermissionError("release integrity: finalization permit turn mismatch")
        if str(getattr(permit, "response_sha256", "")).lower() != str(bundle.bundle_sha256).lower():
            raise PermissionError("release integrity: finalization permit bundle hash mismatch")
        if not str(getattr(permit, "permit_sha256", "")).strip():
            raise PermissionError("release integrity: missing finalization permit digest")
        with self._release_lock():
            return self._release_group_unlocked(bundle=bundle, user_command=user_command)


    def commit(self, *, candidate: CandidateResponse, permit, user_command: str, permit_verifier=None) -> ReleasedResponse:
        """Two-phase canonical publication.

        The sink never decides whether a turn is solved. It only publishes a candidate
        whose hash is named by an authenticated FinalizationPermit verified by the
        caller/finalizer.
        """
        if permit_verifier is not None and permit_verifier(permit) is not True:
            raise PermissionError("release integrity: invalid finalization permit")
        if str(getattr(permit, "turn_id", "")) != str(candidate.turn_id):
            raise PermissionError("release integrity: finalization permit turn mismatch")
        if str(getattr(permit, "response_sha256", "")).lower() != candidate.response_sha256.lower():
            raise PermissionError("release integrity: finalization permit response hash mismatch")
        if not str(getattr(permit, "permit_sha256", "")).strip():
            raise PermissionError("release integrity: missing finalization permit digest")
        with self._release_lock():
            return self._release_unlocked(candidate=candidate, user_command=user_command)

    def release(self, *, candidate: CandidateResponse, user_command: str) -> ReleasedResponse:
        if self.require_finalization_permit:
            raise PermissionError("release integrity: canonical response publication requires FinalizationPermit")
        with self._release_lock():
            return self._release_unlocked(candidate=candidate, user_command=user_command)
