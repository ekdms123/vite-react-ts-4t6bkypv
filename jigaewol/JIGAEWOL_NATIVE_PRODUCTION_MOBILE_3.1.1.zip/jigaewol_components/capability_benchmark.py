from __future__ import annotations
from dataclasses import asdict, dataclass
from pathlib import Path
import tempfile
from typing import Any

from .ambition_preserver import AmbitionPreserver
from .requirement_contract import RequirementCompiler
from .strategy_topology import StrategyTopologySelector
from .representation_tournament import RepresentationTournament
from .search_portfolio_engine import SearchPortfolioEngine
from .anti_recurrence import AntiRecurrenceEngine
from .body_federation import BodyFederationRegistry
from .agent_skill_registry import AgentSkillRegistry
from .intent_deep_analyzer import IntentDeepAnalyzer


@dataclass(frozen=True)
class BenchmarkCase:
    case_id: str
    passed: bool
    evidence: dict[str, Any]


class CapabilityAmplificationBenchmark:
    """Deterministic runtime-amplification benchmark, explicitly not an IQ test."""

    @staticmethod
    def run(root: str | Path) -> dict[str, Any]:
        root=Path(root); cases=[]
        # Benchmarks are observational with respect to the source artifact. Any
        # mutable ledgers/fixtures live in a throwaway state root so running the
        # benchmark after sealing cannot dirty or mutate the candidate tree.
        temp_ctx = tempfile.TemporaryDirectory(prefix="jigaewol-capability-benchmark-")
        state_root = Path(temp_ctx.name)
        msg="검색을 해줘.\nGitHub 실제 실행도 해줘.\n목표를 축소하지 마.\n요구를 하나도 빼먹지 마."
        c=RequirementCompiler.compile(msg)
        cases.append(BenchmarkCase('atomic_requirements', len(c.atoms)>=4 and c.semantic_coverage_required,
                                   {'atoms':len(c.atoms),'semantic_coverage_required':c.semantic_coverage_required}))
        anchor=AmbitionPreserver.anchor('모바일 한 창에서 컴퓨터처럼 최대한 실행해')
        ok,findings=AmbitionPreserver.validate_routes(anchor,[{'route_id':'browser','state':'failed','preserves_goal':True},{'route_id':'container','state':'planned','preserves_goal':True}])
        cases.append(BenchmarkCase('goal_preservation',ok and not findings,{'findings':findings}))
        topo=StrategyTopologySelector.select('기존 기능을 유지하고 속도를 낮추지 않으면서 여러 실행 경로를 합쳐 해결해',c,search_required=False,external_capability_required=True,signed_in_browser_preferred=False,deep_reasoning_required=True)
        rep=RepresentationTournament.compile(msg,c,topo)
        cases.append(BenchmarkCase('representation_tournament',rep.active and len(rep.frames)>=2,{'frames':len(rep.frames),'selected':list(topo.selected)}))
        q=SearchPortfolioEngine.compile_query_program('요즘 뜨는 AI 찾아줘','community')
        cases.append(BenchmarkCase('research_mesh',q['counts_are_not_openness_or_sufficiency_metrics'] and q['result_to_query_loop']['requery_observed_terms'],{'dialects':len(q['dialects'])}))
        anti=AntiRecurrenceEngine(state_root/'anti.json'); anti.observe('왜 또 몇 개만 하고 빼먹고 목표 축소하고 실행한 척 해?')
        fam={x.family for x in anti.active()}; cases.append(BenchmarkCase('anti_recurrence',{'requirement_omission','goal_shrink','fake_execution'}.issubset(fam),{'families':sorted(fam)}))
        bodies=BodyFederationRegistry(state_root/'bodies.json'); bodies.upsert('free',executor='free',families=('test',),capabilities=('browse',),state='callable',zero_incremental_cost=True,evidence_strength=.8,origin_ref='benchmark'); bodies.upsert('unknown',executor='unknown',families=('test',),capabilities=('browse',),state='callable',zero_incremental_cost=None,evidence_strength=1,origin_ref='benchmark')
        route=bodies.route('browse',zero_cost_only=True); cases.append(BenchmarkCase('zero_cost_truth',route.selected_body_id=='free' and 'unknown' in route.deferred_cost_unknown,asdict(route)))
        skill_dir=state_root/'skill'; skill_dir.mkdir(exist_ok=True)
        (skill_dir/'SKILL.md').write_text('---\nname: vault-scout\ndescription: Search a private vault before external capability discovery.\nlicense: MIT\n---\nUse the canonical private vault first.\n',encoding='utf-8')
        skills=AgentSkillRegistry(state_root/'skills'); rec=skills.install(skill_dir,source_ref='benchmark:vault'); skills.promote(rec.skill_id,evidence_ref='benchmark:review',rights_basis='open_license')
        ctx=skills.context_for_query('search the private vault for capabilities')
        va=IntentDeepAnalyzer().analyze('내 노션 자료의 스킬과 MCP를 참고해서 없는 기능을 합쳐줘')
        cases.append(BenchmarkCase('vault_skill_federation',ctx['matched_skill_count']==1 and 'personal_knowledge' in va.inferred_source_families and va.inferred_external_capability_required,{'matched':ctx['matched_skill_count'],'families':list(va.inferred_source_families)}))

        multilingual_dir=state_root/'multilingual_skill'; multilingual_dir.mkdir(exist_ok=True)
        (multilingual_dir/'SKILL.md').write_text('---\nname: vault-capability-scout\ndescription: Use when the user named personal corpus, saved Agent Skills, MCPs, plugins, hooks, open-source code, or missing capabilities should be reused or integrated into JIGAEWOL.\nlicense: MIT\n---\nSearch private prior work first.\n',encoding='utf-8')
        multilingual=AgentSkillRegistry(state_root/'multilingual_skills'); mrec=multilingual.install(multilingual_dir,source_ref='benchmark:multilingual'); multilingual.promote(mrec.skill_id,evidence_ref='benchmark:review',rights_basis='open_license')
        ko=multilingual.context_for_query('볼트에서 MCP나 플러그인 찾아서 부족한 능력을 JIGAEWOL에 붙여줘')
        generic=multilingual.context_for_query('스킬 목록 보여줘')
        cases.append(BenchmarkCase('multilingual_skill_routing',ko['matched_skill_count']==1 and generic['matched_skill_count']==0,{'korean_matched':ko['matched_skill_count'],'generic_matched':generic['matched_skill_count'],'score':ko['matches'][0]['match_score'] if ko['matches'] else 0.0}))

        from jigaewol_core.observability import PublicExecutionTrace
        delivered=[]
        trace=PublicExecutionTrace(state_root/'progress-trace.jsonl',listener=lambda row: delivered.append(row))
        trace.emit(turn_id='benchmark-progress',phase='EXECUTION',status='STARTED',component='benchmark',action='progress_probe')
        pd=trace.digest('benchmark-progress')
        delivery=pd['progress_delivery']
        cases.append(BenchmarkCase(
            'progress_delivery_truth',
            len(delivered)==1
            and delivery['listener_invocation_count']==1
            and delivery['host_forwarding_observed_count']==0
            and delivery['ui_rendering_observed_count']==0
            and delivery['realtime_user_visibility_proven'] is False
            and pd['platform_ui_labels_controlled'] is False,
            {
                'listener_events':len(delivered),
                'listener_invocations':delivery['listener_invocation_count'],
                'host_forwarded':delivery['host_forwarding_observed_count'],
                'ui_rendered':delivery['ui_rendering_observed_count'],
                'realtime_user_visibility_proven':delivery['realtime_user_visibility_proven'],
                'platform_ui_labels_controlled':pd['platform_ui_labels_controlled'],
            }
        ))

        from jigaewol_core.turn_gateway import TurnGateway
        interrupt_state=state_root/'interrupt-state'
        gateway=TurnGateway(interrupt_state/'turn_gateway',user_id='bench',project_id='bench',session_id='bench')
        first=gateway.issue('old task')
        duplicate=gateway.admit_new_message(interrupt_state/'canonical_finalizer',message='old task',origin_ref='benchmark:duplicate')
        supersede=gateway.admit_new_message(interrupt_state/'canonical_finalizer',message='new task',origin_ref='benchmark:interrupt')
        proof=gateway.assert_previous_finalized(interrupt_state/'canonical_finalizer')
        cases.append(BenchmarkCase(
            'turn_interrupt_truth',
            duplicate['action']=='reuse_pending'
            and supersede['state']=='previous_gateway_continued_unfinalized'
            and supersede['prior_user_work_preserved'] is True
            and supersede['host_release_status']=='prior_work_still_open'
            and proof['previous_gateway_continued_unfinalized'] is True,
            {
                'first_gateway_turn_id':first['gateway_turn_id'],
                'duplicate_action':duplicate['action'],
                'supersede_state':supersede['state'],
                'host_release_status':supersede['host_release_status'],
            }
        ))

        passed=sum(x.passed for x in cases); total=len(cases)
        result={'benchmark':'capability_amplification_structural_v2','is_iq_test':False,'passed':passed,'total':total,'pass_rate':passed/total if total else 0.0,'cases':[asdict(x) for x in cases]}
        temp_ctx.cleanup()
        return result
