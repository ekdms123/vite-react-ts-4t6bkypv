from __future__ import annotations

"""IR for Astra organogenesis: representation, execution, interpretation, and intent can co-evolve."""

from dataclasses import dataclass, field, asdict, replace
import hashlib, json
from typing import Any, Mapping


def _sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode()).hexdigest()


@dataclass(frozen=True, slots=True)
class TypeField:
    name: str
    extractor: Mapping[str, Any]
    semantic_role: str = "distinction"


@dataclass(frozen=True, slots=True)
class ProblemType:
    name: str
    fields: tuple[TypeField, ...]
    invariants: tuple[Mapping[str, Any], ...] = ()
    born_from: str = "mandate"


@dataclass(frozen=True, slots=True)
class OperationDef:
    name: str
    params: tuple[str, ...] = ()
    body: Mapping[str, Any] = field(default_factory=dict)
    provenance: str = "generated"


@dataclass(frozen=True, slots=True)
class ObserverDef:
    name: str
    channels: tuple[TypeField, ...]
    disturbance: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class GrammarDef:
    tokens: tuple[str, ...]
    forms: tuple[str, ...] = ("call", "if", "seq", "emit")
    productions: tuple[Mapping[str, Any], ...] = ()


@dataclass(frozen=True, slots=True)
class ProgramDef:
    tree: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class TranslatorDef:
    input_encoder: Mapping[str, Any] = field(default_factory=lambda: {"kind": "identity"})
    output_decoder: Mapping[str, Any] = field(default_factory=lambda: {"kind": "identity"})
    residual_probe: Mapping[str, Any] = field(default_factory=dict)
    mediator: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ReceiverDef:
    channels: tuple[str, ...] = ()
    manipulators: tuple[str, ...] = ()
    interaction_model: str = ""
    executable_spec: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class IntentSensorDef:
    channels: tuple[Mapping[str, Any], ...] = ()
    competing_views: tuple[Mapping[str, Any], ...] = ()
    selection_rule: str = (
        "preserve immutable mandate provenance and explicit-clause precedence; latent views may "
        "add distinctions, probes, and route hypotheses but may not replace or weaken the literal user view"
    )
    latent_view_may_outrank_literal: bool = False
    literal_view_is_semantic_ceiling: bool = True


@dataclass(frozen=True, slots=True)
class CapabilityContractDef:
    """Existing capability continuity plus explicit permission to redefine foundational assumptions."""

    preserved_capabilities: tuple[str, ...] = ()
    call_conditions: Mapping[str, Any] = field(default_factory=dict)
    redefinable_assumptions: tuple[str, ...] = (
        "representation",
        "problem_definition",
        "language",
        "interpreter",
        "observer",
        "execution_structure",
    )
    expansion_routes: tuple[str, ...] = (
        "invent_new_operation",
        "invent_new_datatype",
        "invent_new_language",
        "invent_new_interpreter",
        "invent_new_observer",
        "redefine_foundational_assumption",
    )
    rule: str = (
        "preserve prior callable effects that remain required, but do not preserve the assumptions "
        "behind them when redefining those assumptions is necessary to satisfy the user outcome"
    )


@dataclass(frozen=True, slots=True)
class GeneratorDef:
    genome: Mapping[str, Any] = field(default_factory=dict)
    self_change_dimensions: tuple[str, ...] = (
        "program_grammar",
        "candidate_composition_order",
        "datatype_invention",
        "translation_loss_measure",
        "experience_generation",
        "organ_extraction",
    )


@dataclass(frozen=True, slots=True)
class InterpreterGenome:
    equality_mode: str = "structural"
    history_mode: str = "visible"
    composition_mode: str = "sequential"
    contradiction_mode: str = "paraconsistent"
    unknown_operation_mode: str = "birth_request"
    unknown_syntax_mode: str = "birth_request"


@dataclass(frozen=True, slots=True)
class OrganGenome:
    grammar: GrammarDef
    operations: tuple[OperationDef, ...]
    observer: ObserverDef
    program: ProgramDef
    interpreter: InterpreterGenome = InterpreterGenome()
    problem_type: ProblemType = ProblemType("uncommitted_problem", ())
    translator: TranslatorDef = TranslatorDef()
    receiver: ReceiverDef = ReceiverDef()
    intent_sensor: IntentSensorDef = IntentSensorDef()
    generator: GeneratorDef = GeneratorDef()
    capability_contract: CapabilityContractDef = CapabilityContractDef()
    lineage: tuple[str, ...] = ()
    generation: int = 0

    @property
    def genome_id(self) -> str:
        return "organ_" + _sha(asdict(self))[:24]

    def op_map(self) -> dict[str, OperationDef]:
        return {x.name: x for x in self.operations}

    def evolve(self, **changes: Any) -> "OrganGenome":
        nxt = replace(self, **changes)
        return replace(nxt, generation=self.generation + 1, lineage=self.lineage + (self.genome_id,))

    def as_mapping(self) -> dict[str, Any]:
        row = asdict(self)
        row["genome_id"] = self.genome_id
        return row


@dataclass(frozen=True, slots=True)
class InventionBundle:
    """The Ω bundle from the blueprint. No member is assumed to pre-exist."""

    problem_type: ProblemType
    language: GrammarDef
    interpreter: InterpreterGenome
    program: ProgramDef
    translator: TranslatorDef
    receiver: ReceiverDef
    generator: GeneratorDef
    intent_sensor: IntentSensorDef
    observer: ObserverDef
    operations: tuple[OperationDef, ...]
    unresolved_dependencies: tuple[str, ...] = ()
    capability_contract: CapabilityContractDef = CapabilityContractDef()

    @property
    def bundle_id(self) -> str:
        return "omega_" + _sha(asdict(self))[:24]

    def as_mapping(self) -> dict[str, Any]:
        row = asdict(self)
        row["bundle_id"] = self.bundle_id
        return row


@dataclass(frozen=True, slots=True)
class BirthRequest:
    kind: str
    reason: str
    witness: Mapping[str, Any]
    suggested_shape: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ExecutionTrace:
    success: bool
    output: Any
    events: tuple[Mapping[str, Any], ...]
    birth_requests: tuple[BirthRequest, ...]
    genome_id: str
