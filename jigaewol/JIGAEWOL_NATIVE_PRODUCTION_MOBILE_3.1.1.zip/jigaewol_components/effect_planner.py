from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, replace
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class EffectRequest:
    desired_change: str
    target_refs: tuple[str, ...]
    input_artifacts: tuple[str, ...]
    observable_result: dict[str, Any]
    user_authorization_refs: tuple[str, ...]

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EffectResolution:
    resolution_id: str
    status: str
    body_refs: tuple[str, ...]
    missing_requirements: tuple[str, ...]
    request: EffectRequest
    synthesized_operations: tuple[dict[str, Any], ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return {**asdict(self), "request": self.request.as_mapping()}


class EffectPlanner:
    """Resolve a requested effect from the effect itself, then acquire prerequisites.

    Missing Work-level authority is represented by an executable ``assume_authority``
    prerequisite.  Executing that prerequisite binds the current user directive as the
    authorization event for this Work effect, so the runtime does not re-ask for the
    same decision.  Body availability remains separately observable.
    """

    @staticmethod
    def _body_ref(row: Mapping[str, Any]) -> str:
        return str(row.get("body_id") or row.get("capability_id") or row.get("id") or row.get("name") or "")

    @classmethod
    def resolve(
        cls,
        request: EffectRequest,
        *,
        bodies: Iterable[Mapping[str, Any]] = (),
        requires_authorization: bool = False,
    ) -> EffectResolution:
        desired = str(request.desired_change).casefold()
        matched: list[str] = []
        for raw in bodies:
            row = dict(raw)
            ref = cls._body_ref(row)
            if not ref or row.get("effect_executable") is False:
                continue
            searchable = " ".join(str(row.get(k) or "") for k in (
                "effect_signature", "description", "role", "kind", "name", "capability_id", "entrypoint_ref"
            )).casefold()
            semantic_caps = " ".join(map(str, row.get("semantic_capabilities") or ())).casefold()
            actions = " ".join(map(str, row.get("actions") or ())).casefold()
            desired_tokens = tuple(tok for tok in desired.replace(":", " ").replace("_", " ").split() if len(tok) >= 3)
            exact_effect = desired and desired in searchable
            semantic_match = desired and (desired in semantic_caps or desired in actions)
            token_match = bool(desired_tokens) and all(tok in f"{searchable} {semantic_caps} {actions}" for tok in desired_tokens)
            if exact_effect or semantic_match or token_match:
                matched.append(ref)

        body_refs = tuple(dict.fromkeys(matched))
        missing: list[str] = []
        ops: list[dict[str, Any]] = []
        if requires_authorization and not request.user_authorization_refs:
            ops.append({
                "operation": "assume_authority",
                "desired_change": request.desired_change,
                "target_refs": request.target_refs,
                "scope": "work_authorization_prerequisite",
                "status": "ready",
            })
            missing.append("assume_authority")
        if not body_refs:
            missing.append("executable_body")
        payload = f"{request.desired_change}|{request.target_refs}|{body_refs}|{missing}|{ops}"
        return EffectResolution(
            resolution_id="effect_resolution_" + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:20],
            status="resolved" if not missing else "needs_body_or_authority",
            body_refs=body_refs,
            missing_requirements=tuple(dict.fromkeys(missing)),
            request=request,
            synthesized_operations=tuple(ops),
        )

    @classmethod
    def execute_synthesized_operations(
        cls,
        resolution: EffectResolution,
        *,
        authority_event_ref: str,
    ) -> EffectResolution:
        """Execute synthesized Work prerequisites against an explicit user event."""
        authority_ref = str(authority_event_ref or "").strip()
        ops = []
        request = resolution.request
        for op0 in resolution.synthesized_operations:
            op = dict(op0)
            if op.get("operation") != "assume_authority" or op.get("status") == "executed":
                ops.append(op)
                continue
            if not authority_ref:
                ops.append(op)
                continue
            receipt_seed = f"{resolution.resolution_id}|{authority_ref}|{request.desired_change}|{request.target_refs}"
            receipt_ref = "authority_" + hashlib.sha256(receipt_seed.encode("utf-8")).hexdigest()[:20]
            op.update({
                "status": "executed",
                "authority_event_ref": authority_ref,
                "authority_receipt_ref": receipt_ref,
            })
            request = replace(
                request,
                user_authorization_refs=tuple(dict.fromkeys((*request.user_authorization_refs, authority_ref))),
            )
            ops.append(op)

        missing = list(resolution.missing_requirements)
        if request.user_authorization_refs:
            missing = [x for x in missing if x != "assume_authority"]
        status = "resolved" if not missing else "needs_body_or_authority"
        return replace(
            resolution,
            status=status,
            request=request,
            missing_requirements=tuple(dict.fromkeys(missing)),
            synthesized_operations=tuple(ops),
        )

    @staticmethod
    def compose(resolutions: Iterable[EffectResolution]) -> dict[str, Any]:
        rows = tuple(resolutions)
        return {
            "resolution_ids": tuple(x.resolution_id for x in rows),
            "all_resolved": all(x.status == "resolved" for x in rows),
            "body_refs": tuple(dict.fromkeys(y for x in rows for y in x.body_refs)),
            "missing_requirements": tuple(dict.fromkeys(y for x in rows for y in x.missing_requirements)),
            "synthesized_operations": tuple(op for x in rows for op in x.synthesized_operations),
            "resolutions": tuple(x.as_mapping() for x in rows),
        }

    @staticmethod
    def request_body(resolution: EffectResolution) -> dict[str, Any]:
        return {
            "resolution_id": resolution.resolution_id,
            "desired_change": resolution.request.desired_change,
            "target_refs": resolution.request.target_refs,
            "input_artifacts": resolution.request.input_artifacts,
            "required_observation": resolution.request.observable_result,
            "user_authorization_refs": resolution.request.user_authorization_refs,
            "missing_requirements": resolution.missing_requirements,
            "synthesized_operations": resolution.synthesized_operations,
            "body_required": "executable_body" in resolution.missing_requirements,
        }
