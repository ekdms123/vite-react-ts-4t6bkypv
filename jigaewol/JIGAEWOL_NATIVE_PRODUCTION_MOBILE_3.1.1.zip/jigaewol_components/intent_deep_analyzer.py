from __future__ import annotations

import math
import re
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable, Sequence

from jigaewol_runtime.capabilities.search_intent import explicit_public_search_requested


@dataclass(frozen=True)
class IntentDeepAnalysis:
    """Auditable hypothesis regarding user intent depth and required search surfaces.

    Separates explicit surface requests from latent behavioural cues without overriding
    the user's direct instruction.
    """

    inferred_depth: str = "unspecified"  # deep | shallow | unspecified
    confidence: float = 0.0
    evidence_weight: float = 0.0
    override_explicit_request: bool = False
    inferred_search_required: bool = False
    inferred_external_capability_required: bool = False
    inferred_signed_in_browser_preferred: bool = False
    inferred_source_families: tuple[str, ...] = ()
    current_explicit_depth: str = "unspecified"
    delay_since_last_user_s: float | None = None
    repeated_topic_strength: float = 0.0
    feature_scores: dict[str, float] = field(default_factory=dict)
    reasons: tuple[str, ...] = ()

    def as_facet(self) -> dict[str, Any]:
        return asdict(self)


class IntentDeepAnalyzer:
    """Infers intent depth dynamically from observable interaction patterns.

    Operates adaptively without rigid lexical traps or fixed ceilings.
    Explicit user commands always maintain primary authority over depth.
    """

    DEEP_MARKERS = (
        "깊게", "더 깊", "깊이 생각", "깊이 분석", "심층", "자세히", "철저",
        "끝까지", "최대한", "여러 갈래", "창의", "도약", "한계 없이", "완전 자세",
        "열린 사고", "열린 탐색", "개방적 사고", "가능성 탐색", "폭넓게 탐색",
        "대안 탐색", "최고 성능", "고성능",
        "수단과 방법", "가리지 말고", "계속 확장", "계속 넓", "범위를 넓", "최대한 넓게", "쭉 찾아", "모조리",
        "미치게", "뼛속", "끝장", "바닥까지", "뜯어", "해커처럼", "해커 수준", "제대로 파",
        "평소엔 절대 못 보던", "평소에는 절대 못 보던", "극단적으로", "집요하게",
        "deep", "exhaustive", "frontier", "thorough", "comprehensive",
    )
    SHALLOW_MARKERS = (
        "간단히", "간단하게", "짧게", "한 줄", "요약만", "핵심만",
        "brief", "concise", "short answer",
    )
    SEARCH_MARKERS = (
        "검색", "찾아", "조사", "최신", "요즘", "유행", "자료", "출처",
        "search", "latest", "research", "trend",
    )
    # Lexical terms are hints. Only explicit action language can promote a
    # search/capability hint into an immediate actuator requirement.
    # Immediate public-web actuation is intentionally narrower than generic discovery.
    # "찾아/조사/research" remain semantic hints but do not force web search by themselves.
    SEARCH_ACTION_MARKERS = ("검색", "search")
    CAPABILITY_MARKERS = (
        "github", "깃허브", "plugin", "플러그인", "오픈소스", "open source",
        "도구", "설치", "실행", "코드 실행", "connector", "커넥터",
        "skill", "스킬", "mcp", "hook", "훅", "기능 확장", "없는 기능", "기능 합",
    )
    CAPABILITY_ACTION_MARKERS = (
        "설치", "실행", "연결", "사용", "써", "이용", "호출", "합쳐", "합치", "통합",
        "찾아", "검색", "조사",
        "install", "run", "execute", "connect", "use", "invoke", "combine", "integrate", "search", "research",
    )
    PERSONAL_KNOWLEDGE_MARKERS = (
        "노션", "notion", "vault", "개인 지식", "개인 자료", "private corpus", "personal knowledge",
    )
    BROWSER_MARKERS = (
        "추천 피드", "내 피드", "내 계정", "로그인", "signed-in", "브라우저 세션",
        "내 dm", "내 메시지", "authenticated session", "account feed",
    )
    COMMUNITY_MARKERS = (
        "커뮤니티", "reddit", "레딧", "디시", "갤러리", "포럼", "카페",
        "밈", "댓글", "반응", "community", "forum",
    )
    SOCIAL_MARKERS = (
        "인스타", "instagram", "트위터", "twitter", "x.com", "틱톡", "tiktok",
        "추천 피드", "알티", "리트윗", "dm", "밈",
    )

    def __init__(
        self,
        *,
        history_limit: int | None = None,
        override_confidence: float = 0.68,
        override_evidence_weight: float = 2.4,
        override_margin: float = 1.15,
    ) -> None:
        self.history_limit = None if history_limit is None else int(history_limit)
        self.override_confidence = float(override_confidence)
        self.override_evidence_weight = float(override_evidence_weight)
        self.override_margin = float(override_margin)

    _NEGATION_RE = re.compile(r"(?:하지\s*마|하지말|하지\s*말|말고|말아|않고|않아|금지|제외|빼고|\bdo\s+not\b|\bdon['’]?t\b|\bnot\b|\bwithout\b)", re.IGNORECASE)
    _MENTION_SUFFIX_RE = re.compile(r"^(?:이라는|라는|이란|란|의(?:\s|$)|이라는\s*단어|라는\s*단어|경로|개념|의미|여부|문구|표현|코드)")
    _COMPLETED_SUFFIX_RE = re.compile(r"^(?:낸|놓은|둔|본|했던|한\s+것|해둔)")

    @staticmethod
    def _mask_quoted(text: str) -> str:
        # Quoted/pasted names are context by default, not an action request. Keep
        # the same length so local polarity windows still line up.
        patterns = (r"```.*?```", r"`[^`]*`", r'"[^"\n]*"', r"“[^”\n]*”", r"‘[^’\n]*’", r"'[^'\n]*'")
        out = str(text)
        for pattern in patterns:
            out = re.sub(pattern, lambda m: " " * len(m.group(0)), out, flags=re.DOTALL)
        return out

    @classmethod
    def _count_markers(cls, text: str, markers: Sequence[str], *, action_semantics: bool = False) -> int:
        lowered = cls._mask_quoted(str(text)).casefold() if action_semantics else str(text).casefold()
        if not action_semantics:
            return sum(lowered.count(marker.casefold()) for marker in markers)
        count = 0
        for marker in markers:
            mlow = marker.casefold()
            start = 0
            while True:
                idx = lowered.find(mlow, start)
                if idx < 0:
                    break
                end = idx + len(mlow)
                before = lowered[max(0, idx - 18):idx]
                after = lowered[end:min(len(lowered), end + 22)]
                window = lowered[max(0, idx - 10):min(len(lowered), end + 14)]
                negated = bool(cls._NEGATION_RE.search(window))
                descriptive = bool(cls._MENTION_SUFFIX_RE.search(after))
                completed = bool(cls._COMPLETED_SUFFIX_RE.search(after))
                if not negated and not descriptive and not completed:
                    count += 1
                start = end
        return count

    @classmethod
    def _explicit_depth(cls, text: str) -> str:
        deep = cls._count_markers(text, cls.DEEP_MARKERS)
        shallow = cls._count_markers(text, cls.SHALLOW_MARKERS)
        if deep > shallow and deep > 0:
            return "deep"
        if shallow > deep and shallow > 0:
            return "shallow"
        return "unspecified"

    @staticmethod
    def _tokens(text: str) -> set[str]:
        stop = {
            "그냥", "정말", "이거", "저거", "그리고", "근데", "그러면", "나는", "내가",
            "너는", "네가", "해줘", "해주세요", "하는", "있는", "없는", "what", "that",
            "this", "with", "from", "please", "about",
        }
        raw = re.findall(r"[가-힣A-Za-z0-9_]{2,}", str(text).casefold())
        return {tok for tok in raw if tok not in stop}

    @staticmethod
    def _structure_score(text: str) -> float:
        text = str(text)
        length = len(text)
        numbered = len(re.findall(r"(?:^|\\n)\\s*\\d+[\\.)]\\s*", text))
        bullets = len(re.findall(r"(?:^|\\n)\\s*[-*>]\\s+", text))
        questions = text.count("?")
        emphatic = len(re.findall(r"(?:더){2,}|(?:진짜){2,}|(?:정말){2,}|[!?]{3,}", text))
        return min(
            3.0,
            (0.55 if length >= 350 else 0.0)
            + (0.65 if length >= 900 else 0.0)
            + min(0.8, numbered * 0.16 + bullets * 0.10)
            + min(0.55, questions * 0.08)
            + min(0.45, emphatic * 0.15),
        )

    @staticmethod
    def _observation_text(obs: Any) -> str:
        return str(getattr(obs, "payload_ref", "") or getattr(obs, "summary", "") or "")

    @staticmethod
    def _observed_at(obs: Any) -> float:
        try:
            return float(getattr(obs, "observed_at"))
        except (TypeError, ValueError, AttributeError):
            return 0.0

    def analyze(
        self,
        current_command: str,
        *,
        observations: Iterable[Any] = (),
        active_requirements: Iterable[Any] = (),
        now: float | None = None,
    ) -> IntentDeepAnalysis:
        current=str(current_command)
        obs=[x for x in observations if str(getattr(x,"source",""))=="user_command"]
        if self.history_limit is not None:
            obs = obs[-self.history_limit:]
        prior=[self._observation_text(x) for x in obs if self._observation_text(x).strip()]
        # Active requirements are continuity-bearing semantic evidence. They may widen
        # or preserve a route, but never override an explicit current shallow/deep ask.
        for req in active_requirements:
            text = str(getattr(req, "text", "") or (req.get("text") if isinstance(req, dict) else req) or "").strip()
            if text:
                prior.append(text)
        current_tokens=self._tokens(current)
        repeated=0.0
        for text in prior:
            toks=self._tokens(text)
            if current_tokens and toks:
                repeated=max(repeated, len(current_tokens & toks)/max(1,len(current_tokens | toks)))
        explicit=self._explicit_depth(current)
        # Generic causal interrogatives ("왜/어떻게") are not themselves a deepness
        # signal. Treating them as one made ordinary status/debug questions pay the full
        # DEEP/Open Exploration/tournament tax. Deepness comes from explicit depth language or from
        # structural/fundamental subject matter.
        structural_cues=(
            "근본","구조","메타","원리","설계","충돌","모순","해체","공격","절대선","벽","한계",
            "전제","가정","선택압","닫히","존재","의식","자아","정체성","지능","인과","ontology","taxonomy",
            "representation","architecture","mechanism",
        )
        structurally_deep=any(x in current.casefold() for x in structural_cues)
        continuation_cues=("이어가", "계속", "아까", "저거", "그거", "그대로", "더 파", "계속해", "go on", "continue")
        continuation=any(x in current.casefold() for x in continuation_cues)
        prior_deep=any(self._explicit_depth(x)=="deep" or any(c in x.casefold() for c in structural_cues) for x in prior)
        inferred=explicit if explicit in {"deep", "shallow"} else ("deep" if structurally_deep or (continuation and prior_deep) else "unspecified")
        search_hint_n=self._count_markers(current,self.SEARCH_MARKERS, action_semantics=False)
        # Deterministic actuator rule: generic discovery language is not public-web search.
        # A public search becomes required only when the user explicitly says search or
        # names a public/external source together with a discovery verb.
        public_search_requested = explicit_public_search_requested(current)
        search_n = 1 if public_search_requested else 0
        capability_hint_n=self._count_markers(current,self.CAPABILITY_MARKERS, action_semantics=False)
        capability_action_n=self._count_markers(current,self.CAPABILITY_ACTION_MARKERS, action_semantics=True)
        capability_n = capability_hint_n if capability_action_n else 0
        browser_n=self._count_markers(current,self.BROWSER_MARKERS)
        community_n=self._count_markers(current,self.COMMUNITY_MARKERS)
        social_n=self._count_markers(current,self.SOCIAL_MARKERS)
        personal_n=self._count_markers(current,self.PERSONAL_KNOWLEDGE_MARKERS)
        inferred_search=bool(public_search_requested)
        inferred_capability=bool(capability_n)
        inferred_browser=bool(browser_n)
        families=[]
        if personal_n:
            families.append("personal_knowledge")
        # A generic discovery verb inside an explicitly named private corpus is not
        # automatically a request to leave that corpus for the public web.  Public
        # search remains available as a later unlocked route, but becomes immediately
        # required only when the current objective names a public/fresh/external scope
        # or no personal corpus was specified.
        public_scope_markers = (
            "웹", "인터넷", "외부", "공개", "최신", "요즘", "유행", "출처",
            "web", "internet", "public", "external", "latest", "trend",
        )
        public_scope = any(x in current.casefold() for x in public_scope_markers)
        if search_n and (not personal_n or public_scope):
            families.extend(("first_party","web_current"))
        if community_n: families.append("community")
        if social_n or inferred_browser: families.append("social_recommendation")
        if inferred_capability: families.append("code_ecosystem")
        reasons=[]
        if personal_n: reasons.append("current_explicit_message_requests_personal_knowledge_corpus")
        if public_search_requested: reasons.append("current_explicit_message_requests_public_search")
        if inferred_capability: reasons.append("current_explicit_message_requests_external_capability")
        if inferred_browser: reasons.append("current_explicit_message_requests_authenticated_surface")
        if community_n: reasons.append("current_explicit_message_requests_community_sources")
        if social_n: reasons.append("current_explicit_message_requests_social_sources")
        if repeated: reasons.append("prior_topic_continuity_observed_not_authoritative")
        return IntentDeepAnalysis(
            inferred_depth=inferred, confidence=(1.0 if explicit in {"deep", "shallow"} else 0.5 if inferred!="unspecified" else 0.0), evidence_weight=float(bool(inferred!="unspecified")),
            override_explicit_request=False, inferred_search_required=inferred_search, inferred_external_capability_required=inferred_capability,
            inferred_signed_in_browser_preferred=inferred_browser, inferred_source_families=tuple(dict.fromkeys(families)),
            current_explicit_depth=explicit, delay_since_last_user_s=None, repeated_topic_strength=round(repeated,6),
            feature_scores={
                "search":float(search_n),
                "search_lexical_hint":float(search_hint_n),
                "capability":float(capability_n),
                "capability_lexical_hint":float(capability_hint_n),
                "browser":float(browser_n),
                "community":float(community_n),
                "social":float(social_n),
                "personal_knowledge":float(personal_n),
            },
            reasons=tuple(reasons),
        )

    def enrich_plan_mapping(
        self,
        current_command: str,
        raw_plan: dict[str, Any] | None,
        *,
        observations: Iterable[Any] = (),
        active_requirements: Iterable[Any] = (),
        now: float | None = None,
    ) -> tuple[dict[str, Any], IntentDeepAnalysis]:
        analysis = self.analyze(
            current_command,
            observations=observations,
            active_requirements=active_requirements,
            now=now,
        )
        plan = dict(raw_plan or {})
        plan.setdefault("mode", "adaptive")
        plan.setdefault("command_sha256", "")
        facets = dict(plan.get("facets") or {})
        facets["intent_deep_analysis"] = analysis.as_facet()
        facets["intent_deep_analyzer_enabled"] = True
        facets["latent_intent_may_override_surface_request"] = False
        facets["current_explicit_command_has_depth_authority"] = True
        plan["facets"] = facets

        if analysis.inferred_search_required:
            plan["search_required"] = True
        if analysis.inferred_external_capability_required:
            plan["external_capability_required"] = True
        if analysis.inferred_signed_in_browser_preferred:
            plan["signed_in_browser_preferred"] = True
        if analysis.inferred_source_families:
            existing = list(plan.get("required_source_families") or ())
            plan["required_source_families"] = list(dict.fromkeys(existing + list(analysis.inferred_source_families)))
        return plan, analysis
