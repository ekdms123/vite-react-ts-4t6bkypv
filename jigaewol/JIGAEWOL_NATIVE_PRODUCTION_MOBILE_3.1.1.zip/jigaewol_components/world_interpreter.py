from __future__ import annotations

"""Executable substrate whose task language, observations, and syntax can mutate."""

from dataclasses import dataclass
from typing import Any, Mapping
import hashlib, json

from .organ_ir import BirthRequest, ExecutionTrace, OrganGenome


@dataclass(slots=True)
class EvalContext:
    state: dict[str, Any]
    history: list[Any]
    observation: dict[str, Any]
    events: list[dict[str, Any]]
    births: list[BirthRequest]


def _stable(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()


def _path_get(obj: Any, path: str, default: Any = None) -> Any:
    cur = obj
    for part in str(path).split("."):
        if not part:
            continue
        if isinstance(cur, Mapping) and part in cur:
            cur = cur[part]
        elif isinstance(cur, (list, tuple)) and part.isdigit() and int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return default
    return cur


class WorldInterpreter:
    """Mechanics kernel that lets the genome extend syntax instead of making syntax the ceiling."""

    def observe(self, genome: OrganGenome, state: Mapping[str, Any], history: list[Any]) -> dict[str, Any]:
        source = {"state": dict(state), "history": list(history), "history_len": len(history)}
        return {channel.name: self._eval_expr(channel.extractor, source) for channel in genome.observer.channels}

    def _observe_with_births(self, genome: OrganGenome, ctx: EvalContext) -> dict[str, Any]:
        source = {"state": dict(ctx.state), "history": list(ctx.history), "history_len": len(ctx.history)}
        out: dict[str, Any] = {}
        for channel in genome.observer.channels:
            try:
                out[channel.name] = self._eval_expr(channel.extractor, source)
            except ValueError as exc:
                req = BirthRequest(
                    "observer_operation",
                    "observer extractor requires semantics not present in the current interpreter",
                    {"channel": channel.name, "extractor": dict(channel.extractor), "error": str(exc)},
                    {"preserve_channel_name": channel.name, "invent_extractor_semantics": True},
                )
                ctx.births.append(req)
                ctx.events.append({"kind": "birth_request", "target": "observer_operation", "channel": channel.name})
                out[channel.name] = None
        return out

    def execute(self, genome: OrganGenome, *, state: Mapping[str, Any], history: list[Any] | None = None) -> ExecutionTrace:
        h = list(history or [])
        ctx = EvalContext(dict(state), h, {}, [], [])
        ctx.observation = self._observe_with_births(genome, ctx)
        try:
            output = self._eval_node(genome.program.tree, genome, ctx, {})
            ok = not any(x.get("kind") == "runtime_error" for x in ctx.events)
        except Exception as exc:
            ctx.events.append({"kind": "runtime_error", "error": f"{type(exc).__name__}:{exc}"})
            output = None
            ok = False
        return ExecutionTrace(ok, output, tuple(ctx.events), tuple(ctx.births), genome.genome_id)

    def _equal(self, a: Any, b: Any, genome: OrganGenome) -> bool:
        mode = genome.interpreter.equality_mode
        if mode == "stable_json":
            return _stable(a) == _stable(b)
        if mode == "type_and_value":
            return type(a) is type(b) and a == b
        return a == b

    @staticmethod
    def _production_map(genome: OrganGenome) -> dict[str, Mapping[str, Any]]:
        out: dict[str, Mapping[str, Any]] = {}
        for row in genome.grammar.productions:
            if isinstance(row, Mapping) and str(row.get("name") or row.get("kind") or ""):
                out[str(row.get("name") or row.get("kind"))] = row
        return out

    def _expand_generated_form(self, node: Mapping[str, Any], production: Mapping[str, Any]) -> Any:
        template = production.get("expansion") or production.get("template")
        if template is None:
            return None
        bindings = dict(node)

        def subst(value: Any) -> Any:
            if isinstance(value, str) and value.startswith("$"):
                return bindings.get(value[1:])
            if isinstance(value, Mapping):
                return {k: subst(v) for k, v in value.items()}
            if isinstance(value, (list, tuple)):
                return tuple(subst(v) for v in value)
            return value
        return subst(template)

    def _eval_node(self, node: Any, genome: OrganGenome, ctx: EvalContext, env: Mapping[str, Any]) -> Any:
        if not isinstance(node, Mapping):
            return node
        kind = node.get("kind", "literal")
        if kind == "literal": return node.get("value")
        if kind == "get":
            root = node.get("root", "observation")
            base = {"state": ctx.state, "history": ctx.history, "observation": ctx.observation, "env": env}.get(root, ctx.observation)
            return _path_get(base, str(node.get("path", "")), node.get("default"))
        if kind == "seq":
            value = None
            for child in node.get("items", ()): value = self._eval_node(child, genome, ctx, env)
            return value
        if kind == "if":
            return self._eval_node(node.get("then") if self._eval_node(node.get("cond"), genome, ctx, env) else node.get("else"), genome, ctx, env)
        if kind == "eq": return self._equal(self._eval_node(node.get("a"), genome, ctx, env), self._eval_node(node.get("b"), genome, ctx, env), genome)
        if kind == "not": return not bool(self._eval_node(node.get("value"), genome, ctx, env))
        if kind == "and": return all(bool(self._eval_node(x, genome, ctx, env)) for x in node.get("items", ()))
        if kind == "or": return any(bool(self._eval_node(x, genome, ctx, env)) for x in node.get("items", ()))
        if kind == "tuple": return tuple(self._eval_node(x, genome, ctx, env) for x in node.get("items", ()))
        if kind == "hash": return _stable(self._eval_node(node.get("value"), genome, ctx, env))
        if kind in {"add", "sub", "mul"}:
            a = self._eval_node(node.get("a"), genome, ctx, env); b = self._eval_node(node.get("b"), genome, ctx, env)
            return a + b if kind == "add" else (a - b if kind == "sub" else a * b)
        if kind == "mod":
            a = int(self._eval_node(node.get("a"), genome, ctx, env) or 0); b = max(1, int(self._eval_node(node.get("b"), genome, ctx, env) or 1)); return a % b
        if kind == "lt": return self._eval_node(node.get("a"), genome, ctx, env) < self._eval_node(node.get("b"), genome, ctx, env)
        if kind == "emit":
            value = self._eval_node(node.get("value"), genome, ctx, env); ctx.events.append({"kind": "emit", "value": value}); return value
        if kind == "call": return self._call(str(node.get("op", "")), tuple(node.get("args", ())), genome, ctx, env)
        if kind == "parallel_worlds":
            worlds = []
            for branch in node.get("branches", ()):
                worlds.append({"assumption": branch.get("assumption"), "output": self._eval_node(branch.get("body"), genome, ctx, env)})
            ctx.events.append({"kind": "parallel_worlds", "world_count": len(worlds)})
            return tuple(worlds)
        if kind == "birth_observer":
            req = BirthRequest("observer", str(node.get("reason") or "program requested a new observation dimension"), {"state": ctx.state, "observation": ctx.observation}, dict(node.get("suggested_shape") or {}))
            ctx.births.append(req); ctx.events.append({"kind": "birth_request", "target": "observer"}); return None
        if kind == "learned_macro":
            effects = []
            for step in tuple(map(str, node.get("steps", ()))):
                if step in genome.op_map():
                    effects.append(self._call(step, (), genome, ctx, env))
                else:
                    effects.append({"symbolic_step": step})
                    ctx.events.append({"kind": "implicit_macro_step", "step": step})
            return effects[-1] if node.get("return") == "last_effect_or_symbolic_trace" and effects else tuple(effects)
        if kind == "case_policy":
            observation = self._eval_node(node.get("observation", {"kind": "get", "root": "observation", "path": ""}), genome, ctx, env)
            if not isinstance(observation, Mapping):
                observation = ctx.observation
            discriminators = tuple(node.get("discriminators", ()))
            for case in node.get("cases", ()):
                when = dict(case.get("when") or {})
                keys = discriminators or tuple(when)
                if all(observation.get(k) == when.get(k) for k in keys):
                    return case.get("action")
            return node.get("fallback")
        if kind == "residual_mediator":
            value = self._eval_node(node.get("value", {"kind": "get", "root": "observation", "path": ""}), genome, ctx, env)
            return {"translated": value, str(node.get("residual_channel") or "semantic_residue"): tuple(node.get("retained_dimensions", ())) }

        production = self._production_map(genome).get(str(kind))
        if production is not None:
            expanded = self._expand_generated_form(node, production)
            if expanded is not None:
                ctx.events.append({"kind": "generated_syntax_expansion", "form": kind})
                return self._eval_node(expanded, genome, ctx, env)

        if genome.interpreter.unknown_syntax_mode == "birth_request":
            req = BirthRequest(
                "syntax",
                f"program invoked syntax form absent from current interpreter: {kind}",
                {"node": dict(node), "grammar_tokens": genome.grammar.tokens, "grammar_forms": genome.grammar.forms},
                {"name": str(kind), "invent_semantics": True},
            )
            ctx.births.append(req); ctx.events.append({"kind": "birth_request", "target": "syntax", "form": kind}); return None
        raise ValueError(f"unknown expression kind {kind!r}")

    def _eval_expr(self, expr: Any, source: Mapping[str, Any]) -> Any:
        if not isinstance(expr, Mapping): return expr
        kind = expr.get("kind", "literal")
        if kind == "literal": return expr.get("value")
        if kind == "source": return _path_get(source, str(expr.get("path", "")), expr.get("default"))
        if kind == "history_len": return int(source.get("history_len", 0))
        if kind == "history_tail":
            h = list(source.get("history") or ()); n = max(0, int(expr.get("count", 1))); return tuple(h[-n:])
        if kind == "history_count": return sum(1 for x in source.get("history") or () if x == expr.get("event"))
        if kind == "transition_count":
            h = tuple(source.get("history") or ()); left, right = expr.get("left"), expr.get("right"); return sum(1 for a, b in zip(h, h[1:]) if a == left and b == right)
        if kind == "history_digest": return _stable(source.get("history") or ())
        if kind in {"add", "sub", "mul"}:
            a = self._eval_expr(expr.get("a"), source); b = self._eval_expr(expr.get("b"), source); return a + b if kind == "add" else (a - b if kind == "sub" else a * b)
        if kind == "mod": return int(self._eval_expr(expr.get("a"), source) or 0) % max(1, int(self._eval_expr(expr.get("b"), source) or 1))
        if kind == "eq": return self._eval_expr(expr.get("a"), source) == self._eval_expr(expr.get("b"), source)
        if kind == "if": return self._eval_expr(expr.get("then") if self._eval_expr(expr.get("cond"), source) else expr.get("else"), source)
        if kind == "tuple": return tuple(self._eval_expr(x, source) for x in expr.get("items", ()))
        raise ValueError(f"unknown extractor kind {kind!r}")

    def _call(self, name: str, args: tuple[Any, ...], genome: OrganGenome, ctx: EvalContext, env: Mapping[str, Any]) -> Any:
        op = genome.op_map().get(name)
        if op is None:
            req = BirthRequest("operation", f"program invoked absent operation {name}", {"operation": name, "args": args}, {"name": name})
            ctx.births.append(req); ctx.events.append({"kind": "birth_request", "operation": name}); return None
        values = [self._eval_node(x, genome, ctx, env) for x in args]
        local = dict(env); local.update(zip(op.params, values))
        ctx.events.append({"kind": "operation_call", "operation": name, "arguments": tuple(values)})
        result = self._eval_node(dict(op.body), genome, ctx, local)
        ctx.events.append({"kind": "operation_result", "operation": name, "result": result})
        return result
