from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping

from .worker_truth import WorkerTruth


@dataclass(frozen=True)
class DelegateTask:
    task_id: str
    role: str
    objective: str
    context: dict[str, Any]


@dataclass(frozen=True)
class DelegateResult:
    task_id: str
    role: str
    result: Any
    execution_kind: str = "thread"
    independent_worker: bool = False
    independent_cognitive_worker: bool = False
    closed_loop_agent_worker: bool = False
    worker_truth: dict[str, Any] | None = None


Delegate = Callable[[DelegateTask], Any]
DelegateResolver = Callable[[str, tuple[DelegateTask, ...]], Delegate | None]


class DelegateMesh:
    """Parallel delegate fabric with runtime role acquisition."""

    def __init__(
        self,
        delegates: dict[str, Delegate],
        max_workers: int | None = None,
        *,
        resolver: DelegateResolver | None = None,
    ) -> None:
        self.delegates = dict(delegates)
        self.worker_truth: dict[str, WorkerTruth] = {
            str(role): WorkerTruth(execution_kind="thread", provider_ref="DelegateMesh.ThreadPoolExecutor")
            for role in self.delegates
        }
        self.max_workers = None if max_workers is None else max(1, int(max_workers))
        self.resolver = resolver

    def register(self, role: str, delegate: Delegate, *, worker_truth: WorkerTruth | Mapping[str, Any] | None = None) -> None:
        key=str(role)
        self.delegates[key] = delegate
        self.worker_truth[key] = (
            worker_truth if isinstance(worker_truth, WorkerTruth)
            else WorkerTruth.from_mapping(worker_truth) if worker_truth is not None
            else WorkerTruth(execution_kind="thread", provider_ref="DelegateMesh.ThreadPoolExecutor")
        )

    def register_worker(self, role: str, delegate: Delegate, *, execution_kind: str, context_ref: str,
                        provider_ref: str, execution_receipt_ref: str = "",
                        agent_backed: bool = False, result_return_path_observed: bool = False) -> None:
        self.register(role, delegate, worker_truth=WorkerTruth(
            execution_kind=str(execution_kind), context_ref=str(context_ref),
            provider_ref=str(provider_ref), execution_receipt_ref=str(execution_receipt_ref),
            agent_backed=bool(agent_backed), result_return_path_observed=bool(result_return_path_observed),
        ))

    def _resolve_missing(self, work: tuple[DelegateTask, ...]) -> None:
        missing = sorted({task.role for task in work if task.role not in self.delegates})
        if not missing:
            return
        if self.resolver is not None:
            for role in missing:
                delegate = self.resolver(role, tuple(t for t in work if t.role == role))
                if delegate is not None:
                    # A resolver returning a Python callable has not by itself proven a
                    # separate process/model/session. It enters as thread-callable truth
                    # until the resolver explicitly registers a stronger worker binding.
                    self.register(role, delegate)
        remaining = sorted({task.role for task in work if task.role not in self.delegates})
        if remaining:
            raise KeyError(f"delegate roles unavailable: {', '.join(remaining)}")

    def run(self, tasks: Iterable[DelegateTask]) -> tuple[DelegateResult, ...]:
        work = tuple(tasks)
        if not work:
            return ()
        self._resolve_missing(work)

        results: dict[str, DelegateResult] = {}
        worker_count = len(work) if self.max_workers is None else min(self.max_workers, len(work))
        with ThreadPoolExecutor(max_workers=max(1, worker_count)) as pool:
            futures = {pool.submit(self.delegates[task.role], task): task for task in work}
            for future in as_completed(futures):
                task = futures[future]
                truth=self.worker_truth.get(task.role, WorkerTruth(execution_kind="thread", provider_ref="DelegateMesh.ThreadPoolExecutor"))
                results[task.task_id] = DelegateResult(
                    task_id=task.task_id,
                    role=task.role,
                    result=future.result(),
                    execution_kind=truth.execution_kind,
                    independent_worker=truth.independent_worker,
                    independent_cognitive_worker=truth.independent_cognitive_worker,
                    closed_loop_agent_worker=truth.closed_loop_agent_worker,
                    worker_truth=truth.as_mapping(),
                )
        return tuple(results[task.task_id] for task in work)
