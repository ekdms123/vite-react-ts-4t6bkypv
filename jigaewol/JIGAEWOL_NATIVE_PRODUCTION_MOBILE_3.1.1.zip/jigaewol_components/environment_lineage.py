from __future__ import annotations

import copy
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping

from .branch_state import BranchingStateStore
from .git_lineage import GitLineage
from .quality_diversity import QDEntry, QualityDiversityArchive
from .coordination_blackboard import CoordinationBlackboard


@dataclass(frozen=True)
class EnvironmentWorld:
    world_id: str
    state_branch: str
    git_branch: str
    descriptor: dict[str, Any]
    facets: dict[str, Any] = field(default_factory=dict)
    parent_worlds: tuple[str, ...] = ()


@dataclass(frozen=True)
class RealitySelection:
    world_id: str
    accepted_to_qd: bool
    niche_id: str
    score: float | None
    state_version: int
    git_commit: str
    signal_id: str
    evidence: tuple[str, ...]


class EnvironmentLineage:
    """Decentralized environment, branch lineage, and empirical evidence coordinator.

    Worlds operate as independent state/Git branches. Real execution results become
    decay-weighted event signals and QD entries without forcing a single central coordinator.
    """

    def __init__(self, root: Path, *, objective: str) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.objective = str(objective)
        self.states = BranchingStateStore(self.root / "branch_state.json", initial={"objective": self.objective})
        self.blackboard = CoordinationBlackboard(self.root / "blackboard.json")
        self.qd = QualityDiversityArchive(self.root / "qd.json")
        self.git = GitLineage(self.root / "git_lineage")
        self._worlds: dict[str, EnvironmentWorld] = {}
        self.states.register_merge_policy("evidence_union", self._evidence_union)
        self.blackboard.inscribe("objective", "anchor", {"objective": self.objective})

    @staticmethod
    def _evidence_union(target: Any, sources: Iterable[Any], context: Mapping[str, Any]) -> dict[str, Any]:
        out = copy.deepcopy(target.payload)
        out.setdefault("merged_worlds", [])
        out.setdefault("reality_evidence", [])
        for source in sources:
            if source.branch_id not in out["merged_worlds"]:
                out["merged_worlds"].append(source.branch_id)
            for item in source.payload.get("reality_evidence", []):
                if item not in out["reality_evidence"]:
                    out["reality_evidence"].append(copy.deepcopy(item))
        out.setdefault("merge_context", {}).update(copy.deepcopy(dict(context)))
        return out

    def register_grid(
        self,
        *,
        ranges: Mapping[str, tuple[float, float]],
        bins: Mapping[str, int],
        binner_id: str = "grid",
    ) -> None:
        self.qd.register_binner(str(binner_id), self.qd.grid_binner(ranges, bins))

    def spawn(
        self,
        *,
        descriptor: Mapping[str, Any],
        facets: Mapping[str, Any] | None = None,
        parents: Iterable[str] = (),
    ) -> EnvironmentWorld:
        wid = f"world_{uuid.uuid4().hex[:12]}"
        state_branch = f"state-{wid}"
        git_branch = f"git-{wid}"
        self.states.fork("main", branch_id=state_branch, facets={"world_id": wid, **dict(facets or {})})
        self.git.fork(git_branch)
        row = EnvironmentWorld(
            wid,
            state_branch,
            git_branch,
            {str(k): copy.deepcopy(v) for k, v in descriptor.items()},
            dict(facets or {}),
            tuple(str(x) for x in parents),
        )
        self._worlds[wid] = row
        self.blackboard.emit(
            "world.birth",
            "candidate",
            intensity=0.5,
            half_life_s=None,
            payload={"world_id": wid, "descriptor": row.descriptor},
            facets=row.facets,
        )
        return row

    def record_reality(
        self,
        world_id: str,
        *,
        score: float | None,
        result: Mapping[str, Any],
        evidence: Iterable[str],
        binner_id: str = "identity",
    ) -> RealitySelection:
        world = self._worlds[str(world_id)]
        ev = tuple(str(x) for x in evidence)
        snap = self.states.snapshot(world.state_branch)
        payload = copy.deepcopy(snap.payload)
        payload.setdefault("reality_evidence", []).append(
            {"score": score, "result": dict(result), "evidence": list(ev), "at": time.time()}
        )
        committed = self.states.commit(
            world.state_branch,
            expected_version=snap.version,
            payload=payload,
            event={"kind": "reality", "score": score, "evidence": list(ev)},
        )
        node = self.git.mutate(
            world.git_branch,
            artifact_name=f"worlds/{world.world_id}.json",
            payload={
                "objective": self.objective,
                "score": score,
                "descriptor": world.descriptor,
                "result": dict(result),
                "evidence": list(ev),
            },
            message=f"reality {world.world_id} observed",
        )
        accepted, niche = self.qd.add(
            QDEntry(
                world.world_id,
                score,
                dict(world.descriptor),
                {"state_branch": world.state_branch, "git_branch": world.git_branch, "result": dict(result)},
                ev,
                dict(world.facets),
            ),
            binner_id=binner_id,
        )
        intensity = max(0.0, min(1.0, float(score))) if isinstance(score, (int, float)) else 0.5
        signal = self.blackboard.emit(
            "reality.result",
            "accepted" if accepted else "observed",
            intensity=intensity,
            half_life_s=None,
            payload={"world_id": world.world_id, "score": score, "niche": niche, "accepted": accepted},
            facets=world.facets,
        )
        if accepted:
            self.blackboard.inscribe(
                "elite",
                niche,
                {"world_id": world.world_id, "score": score, "git_commit": node.commit, "state_branch": world.state_branch},
                evidence=ev,
            )
        return RealitySelection(world.world_id, accepted, niche, score, committed.version, node.commit, signal.signal_id, ev)

    def elite_worlds(self, maximum: int | None = None) -> tuple[EnvironmentWorld, ...]:
        elites = self.qd.sample_diverse(maximum)
        return tuple(self._worlds[x.entry_id] for x in elites if x.entry_id in self._worlds)

    def merge_elites(self, *, maximum: int | None = None, evidence: Iterable[str] = ()) -> dict[str, Any]:
        elites = self.elite_worlds(maximum)
        branches = [x.state_branch for x in elites]
        if not branches:
            return {"merged": False, "reason": "no elites"}
        after, merge = self.states.merge(
            "main",
            branches,
            policy_id="evidence_union",
            context={"objective": self.objective, "elite_worlds": [x.world_id for x in elites]},
            evidence=evidence,
        )
        return {
            "merged": True,
            "elite_worlds": [x.world_id for x in elites],
            "state_version": after.version,
            "merge": asdict(merge),
            "qd_coverage": self.qd.coverage(),
            "qd_score": self.qd.qd_score(),
        }


