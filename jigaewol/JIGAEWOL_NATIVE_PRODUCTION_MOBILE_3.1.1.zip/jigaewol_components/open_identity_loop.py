from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

from .identity_policy import FunctionalIdentity, default_identity, load_identity, save_identity
from .persistent_cognition import (
    Authority,
    BoundaryClass,
    PersistentCognitionProtocol,
    StateAtom,
    default_boundary_contract,
)

PACKAGE_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class ChallengeDirective:
    frame_id: str
    mode: str
    instruction: str
    purpose: str
    registry_bounded: bool = True


@dataclass(frozen=True)
class ContinuityIngress:
    conversation_id: str
    capsule_generation: int
    capsule_hash: str
    identity_generation: int
    identity_hash: str
    decision_context: dict[str, Any]
    challenge_directives: tuple[ChallengeDirective, ...]
    adjusted_divergence_tier: int
    previous_divergence_tier: int
    restored: bool
    updated: bool
    functional_only: bool = True

    def as_mapping(self) -> dict[str, Any]:
        row = asdict(self)
        row["challenge_directives"] = tuple(asdict(x) for x in self.challenge_directives)
        row["identity_is_neural_weights"] = False
        row["consciousness_claim"] = False
        row["open_slot_present"] = any(not x.registry_bounded for x in self.challenge_directives)
        return row


class OpenIdentityLoop:
    """Wires persistent state into each runtime turn without turning memory into dogma.

    The loop deliberately separates four operations:
      restore -> challenge -> influence current routing -> persist a hash-linked update.

    It never treats a remembered claim as true merely because it persisted.  Every
    substantive turn includes an unbounded challenge slot whose representation is
    supplied by the host semantic model rather than by this registry.  This prevents
    the challenge taxonomy itself from becoming a closed ontology.
    """

    def __init__(self, root: str | Path, *, user_id: str, project_id: str, session_id: str):
        self.root = Path(root)
        # Continuity follows the user+project thread; a chat/session is an episode, not identity.
        self.conversation_id = f"{user_id}:{project_id}"
        self.episode_id = str(session_id)
        self.protocol = PersistentCognitionProtocol(self.root / "persistent_cognition" / "state.json")
        self.identity_path = self.root / "persistent_identity" / "identity.json"
        self.events_path = self.root / "persistent_identity" / "events.jsonl"

    @staticmethod
    def _sha_text(value: str) -> str:
        return sha256(str(value).encode("utf-8")).hexdigest()

    @staticmethod
    def assert_compatible(root: str | Path, *, user_id: str, project_id: str) -> None:
        """Fail before any runtime component can mutate state for the wrong identity."""
        state_path = Path(root) / "persistent_cognition" / "state.json"
        if not state_path.exists():
            return
        try:
            data = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError("persistent cognition state is unreadable") from exc
        expected = f"{user_id}:{project_id}"
        actual = str(data.get("conversation_id") or "")
        if actual and actual != expected:
            raise ValueError("conversation identity mismatch")

    def _identity(self) -> FunctionalIdentity:
        identity = load_identity(self.identity_path)
        if identity is None:
            identity = default_identity(f"jigaewol-functional-self:{self.conversation_id}")
            save_identity(self.identity_path, identity)
        return identity

    def _restore_capsule(self):
        capsule, report = self.protocol.restore(conversation_id=self.conversation_id)
        if not capsule.atoms:
            capsule = self.protocol.update(capsule, default_boundary_contract())
            capsule, report = self.protocol.restore(conversation_id=self.conversation_id)
        if "project_north_star" not in capsule.atoms:
            text = ""
            source_ref = ""
            for goal_path in (self.root / "PROJECT_NORTH_STAR.json", PACKAGE_ROOT / "PROJECT_NORTH_STAR.json"):
                if not goal_path.is_file():
                    continue
                try:
                    row = json.loads(goal_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError, TypeError):
                    continue
                text = str(row.get("goal") or "").strip()
                source_ref = str(row.get("source") or goal_path)
                if text:
                    break
            if text:
                atom = StateAtom(
                    "project_north_star", text, BoundaryClass.SELF_STATE, Authority.USER,
                    f"canonical north star seed: {source_ref}", confidence=1.0, revisable=True,
                )
                open_requirements = tuple(dict.fromkeys([text, *capsule.open_requirements]))
                capsule = self.protocol.update(capsule, (atom,), open_requirements=open_requirements)
                capsule, report = self.protocol.restore(conversation_id=self.conversation_id)
        return capsule, report

    def project_goal(self) -> str:
        capsule, _ = self._restore_capsule()
        atom = capsule.atoms.get("project_north_star")
        return str(atom.value).strip() if atom is not None else ""

    def open_requirements(self) -> tuple[str, ...]:
        capsule, _ = self._restore_capsule()
        return tuple(str(x) for x in capsule.open_requirements if str(x).strip())

    def set_project_goal(self, goal: str, *, source: str = "user canonical north star") -> dict[str, Any]:
        text = str(goal or "").strip()
        if not text:
            raise ValueError("project goal must be non-empty")
        capsule, _ = self._restore_capsule()
        atom = StateAtom(
            "project_north_star", text, BoundaryClass.SELF_STATE, Authority.USER,
            source, confidence=1.0, revisable=True,
        )
        merged = tuple(dict.fromkeys([text, *capsule.open_requirements]))
        nxt = self.protocol.update(capsule, (atom,), open_requirements=merged)
        return {"capsule_generation": nxt.generation, "project_goal_sha256": self._sha_text(text)}

    def _challenge_directives(
        self,
        identity: FunctionalIdentity,
        command: str = "",
        *,
        semantic_authority: Mapping[str, Any] | None = None,
    ) -> tuple[ChallengeDirective, ...]:
        low=str(command).casefold()
        authority = dict(semantic_authority or {})
        directives: list[ChallengeDirective] = []
        if any(x in low for x in ("가정", "전제", "당연", "assumption", "premise", "뒤집")):
            directives.append(ChallengeDirective("inherited_assumption_escape","assumption_escape","Challenge a materially relevant inherited assumption only if it changes the route.","avoid inherited dogma"))
        if any(x in low for x in ("정체성", "identity", "자아", "self-model")):
            directives.append(ChallengeDirective("identity_disagreement","self_disagreement","Develop a materially different self-model only when identity is part of the task.","keep persistent identity revisable"))
        if any(x in low for x in ("분류", "범주", "ontology", "taxonomy", "틀 밖", "schema")):
            directives.append(ChallengeDirective("ontology_escape","schema_escape","Use whatever representation the task needs without mapping it back prematurely.","keep schemas provisional",registry_bounded=False))
        # Canonical frontier semantics must materialize at least one challenge that is
        # *not* bounded by this registry. Previously the runtime promised such a slot in
        # the class contract, but the implementation only opened it for a small lexical
        # ontology (ontology/taxonomy/schema). That made anti-closure/frontier turns
        # silently fall back to registry-bounded challenges.
        frontier_open = bool(
            authority.get("frontier_exploration_required")
            or authority.get("representation_search_required")
            or authority.get("possibility_space_open")
            or authority.get("open_problem_required")
        )
        if frontier_open and not any(not x.registry_bounded for x in directives):
            directives.append(ChallengeDirective(
                "frontier_unbounded_escape",
                "host_invented_representation",
                "Invent a task-local representation or challenge that is not required to fit this runtime's current registry before deciding whether any known frame applies.",
                "prevent the challenge registry from becoming the possibility ceiling",
                registry_bounded=False,
            ))
        return tuple(directives)

    def begin_turn(
        self,
        *,
        command: str,
        requirement_texts: Iterable[str],
        topology: Any,
        project_goal: str = "",
        semantic_authority: Mapping[str, Any] | None = None,
    ) -> tuple[Any, ContinuityIngress]:
        capsule, restore_report = self._restore_capsule()
        identity = self._identity()
        context = identity.decision_context()
        directives = self._challenge_directives(identity, command, semantic_authority=semantic_authority)

        previous_tier = int(getattr(topology, "divergence_tier", 0) or 0)
        adjusted_tier = previous_tier
        substantive = bool(str(command).strip())
        # Persistence alone still does not impose a divergence floor. Canonical current-
        # turn frontier semantics, however, must not be represented as the same bounded
        # tier used for ordinary comparison. Tier 3 denotes an actually materialized
        # non-registry challenge slot; it is a scheduling signal, not a claim that three
        # branches are sufficient.
        adjusted_topology = topology
        if any(not x.registry_bounded for x in directives):
            adjusted_tier = max(previous_tier, 3)
            try:
                adjusted_topology = replace(topology, divergence_tier=adjusted_tier)
            except TypeError:
                adjusted_topology = topology

        current_requirements = tuple(str(x) for x in requirement_texts if str(x).strip())
        durable_goal = str(project_goal or self.project_goal() or "").strip()
        open_requirements = tuple(dict.fromkeys([
            *( [durable_goal] if durable_goal else [] ),
            *capsule.open_requirements,
            *current_requirements,
        ]))
        atoms = (
            StateAtom(
                "last_user_command_sha256", self._sha_text(command), BoundaryClass.SELF_STATE,
                Authority.INFERRED, "current-turn ingress", confidence=1.0, revisable=True,
            ),
            StateAtom(
                "identity_decision_context", context, BoundaryClass.SELF_STATE,
                Authority.CANONICAL, "persistent functional identity", confidence=1.0, revisable=True,
            ),
            StateAtom(
                "open_challenge_directives", ([asdict(x) for x in directives] if substantive else []), BoundaryClass.EXOCORTEX,
                Authority.CANONICAL, "open identity loop", confidence=1.0, revisable=True,
            ),
            StateAtom(
                "closure_rule", "evidence_may_narrow_live_models_but_persistence_alone_may_not", BoundaryClass.SELF_STATE,
                Authority.CANONICAL, "open identity loop", confidence=1.0, revisable=True,
            ),
        )
        unresolved = list(capsule.unresolved)
        updated_capsule = self.protocol.update(
            capsule, atoms, open_requirements=open_requirements, unresolved=tuple(unresolved),
        )
        ingress = ContinuityIngress(
            conversation_id=self.conversation_id,
            capsule_generation=updated_capsule.generation,
            capsule_hash=updated_capsule.digest(),
            identity_generation=identity.generation,
            identity_hash=identity.digest(),
            decision_context=context,
            challenge_directives=directives if substantive else (),
            adjusted_divergence_tier=adjusted_tier,
            previous_divergence_tier=previous_tier,
            restored=True,
            updated=True,
        )
        self._event({"event": "turn_begin", "command_sha256": self._sha_text(command), **ingress.as_mapping()})
        return adjusted_topology, ingress

    def complete_turn(
        self,
        *,
        release_turn_id: str,
        finalizer_receipt: Mapping[str, Any],
        execution_receipt_ids: Iterable[str] = (),
        requirement_manifest: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        capsule, _ = self._restore_capsule()
        identity = self._identity()
        application_state = str(finalizer_receipt.get("application_state") or "unknown")
        # Release integrity and objective completion are separate truths.  An
        # ``applied_full`` response may be a valid turn release while the cumulative
        # user objective remains live.  Only Work-level observed completion may teach
        # continuity that the objective itself finished.
        success = bool(finalizer_receipt.get("objective_completion_proven"))
        event = {
            "release_turn_id": str(release_turn_id),
            "application_state": application_state,
            "final_response_allowed": bool(finalizer_receipt.get("final_response_allowed")),
            "objective_completion_proven": success,
            "execution_receipt_ids": tuple(str(x) for x in execution_receipt_ids),
            "requirement_manifest_sha256": self._sha_text(json.dumps(requirement_manifest or {}, ensure_ascii=False, sort_keys=True, default=str)),
            "finalizer_receipt_id": str(finalizer_receipt.get("receipt_id") or ""),
        }
        identity = identity.record_experience(event)
        save_identity(self.identity_path, identity)

        unresolved = list(capsule.unresolved)
        if success:
            unresolved = [x for x in unresolved if x != "current turn awaits canonical finalization"]
        else:
            unresolved = list(dict.fromkeys([*unresolved, "current turn awaits canonical finalization"]))
        atoms = (
            StateAtom(
                "last_turn_outcome", event, BoundaryClass.SELF_STATE, Authority.OBSERVED,
                "canonical finalizer", confidence=1.0, revisable=True,
            ),
            StateAtom(
                "identity_hash", identity.digest(), BoundaryClass.SELF_STATE, Authority.CANONICAL,
                "persistent functional identity", confidence=1.0, revisable=True,
            ),
        )
        next_capsule = self.protocol.update(
            capsule, atoms, unresolved=unresolved, receipts=tuple(str(x) for x in execution_receipt_ids),
        )
        result = {
            "capsule_generation": next_capsule.generation,
            "capsule_hash": next_capsule.digest(),
            "identity_generation": identity.generation,
            "identity_hash": identity.digest(),
            "application_state": application_state,
            "functional_continuity_updated": True,
            "consciousness_claim": False,
        }
        self._event({"event": "turn_complete", **result, **event})
        return result

    def snapshot(self) -> dict[str, Any]:
        capsule, report = self._restore_capsule()
        identity = self._identity()
        return {
            "conversation_id": self.conversation_id,
            "capsule_generation": capsule.generation,
            "capsule_hash": capsule.digest(),
            "self_state_keys": report.self_state_keys,
            "external_keys": report.external_keys,
            "identity_generation": identity.generation,
            "identity_hash": identity.digest(),
            "decision_context": identity.decision_context(),
            "functional_only": True,
            "consciousness_claim": False,
        }

    def _event(self, row: Mapping[str, Any]) -> None:
        self.events_path.parent.mkdir(parents=True, exist_ok=True)
        with self.events_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, default=str) + "\n")
