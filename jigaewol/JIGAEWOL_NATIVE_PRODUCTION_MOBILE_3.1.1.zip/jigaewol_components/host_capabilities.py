from __future__ import annotations

import json
import os
import shutil
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

from .capability_registry import CapabilityRegistry
from .execution_plane import ExecutionPlane, ExecutionRequest
from .host_identity import current_host_fingerprint


@dataclass(frozen=True)
class HostToolSpec:
    capability_id: str
    executable: str
    version_argv: tuple[str, ...]
    traits: tuple[str, ...]
    description: str


@dataclass(frozen=True)
class HostToolProbe:
    capability_id: str
    executable: str
    resolved_path: str | None
    present: bool
    receipt_id: str | None
    exit_code: int | None
    stdout: str
    stderr: str


def default_tool_specs() -> tuple[HostToolSpec, ...]:
    return (
        HostToolSpec("host_python", "python", ("--version",), ("python", "execution"), "Python runtime"),
        HostToolSpec("host_git", "git", ("--version",), ("git", "source_control"), "Git client"),
        HostToolSpec("host_ripgrep", "rg", ("--version",), ("search", "code_search"), "ripgrep code/text search"),
        HostToolSpec("host_jq", "jq", ("--version",), ("json", "transformation"), "jq JSON processor"),
        HostToolSpec("host_curl", "curl", ("--version",), ("http", "download"), "curl HTTP client"),
        HostToolSpec("host_node", "node", ("--version",), ("javascript", "execution"), "Node.js runtime"),
        HostToolSpec("host_uv", "uv", ("--version",), ("python", "package_management", "speed"), "uv Python package/project tool"),
        HostToolSpec("host_ffmpeg", "ffmpeg", ("-version",), ("audio", "video", "media"), "FFmpeg media engine"),
        HostToolSpec("host_tesseract", "tesseract", ("--version",), ("ocr", "vision"), "Tesseract OCR engine"),
        HostToolSpec("host_playwright", "playwright", ("--version",), ("browser", "automation"), "Playwright browser automation CLI"),
        HostToolSpec("host_chromium", "chromium", ("--version",), ("browser", "rendering"), "Chromium browser"),
        HostToolSpec("host_ollama", "ollama", ("--version",), ("local_llm", "offline", "serving"), "Ollama local model runtime"),
        HostToolSpec("host_llama_server", "llama-server", ("--version",), ("local_llm", "offline", "serving"), "llama.cpp local model server"),
        HostToolSpec("host_swift", "swift", ("--version",), ("apple", "swift", "native_execution"), "Swift toolchain"),
    )


class HostCapabilityDiscovery:
    """Discovers executable capabilities verified in the current host environment.

    Operates empirically: binary resolution identifies availability, and active verification
    confirms execution validity via durable receipts.
    """

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root.resolve()
        self.workspace = self.project_root / "workspace"
        self.plane = ExecutionPlane(self.workspace)
        self.registry = CapabilityRegistry(
            self.workspace / ".capability_registry.json", self.project_root
        )

    def probe(self, specs: Iterable[HostToolSpec] | None = None) -> tuple[HostToolProbe, ...]:
        resolved_specs = tuple(specs) if specs is not None else default_tool_specs()
        results: list[HostToolProbe] = []
        for spec in resolved_specs:
            resolved = shutil.which(spec.executable)
            if resolved is None:
                results.append(
                    HostToolProbe(
                        capability_id=spec.capability_id,
                        executable=spec.executable,
                        resolved_path=None,
                        present=False,
                        receipt_id=None,
                        exit_code=None,
                        stdout="",
                        stderr="",
                    )
                )
                continue
            metadata = {
                "kind": "host_executable",
                "executable": spec.executable,
                "resolved_path": resolved,
                "traits": list(spec.traits),
                "description": spec.description,
                "scope": "host_local",
                "host_fingerprint": current_host_fingerprint(),
            }
            self.registry.declare_available(spec.capability_id, metadata=metadata)
            receipt = self.plane.run_resilient(
                ExecutionRequest(argv=[resolved, *spec.version_argv], timeout_s=15.0),
                persist_cwd=False,
            )
            self.registry.record_execution(spec.capability_id, receipt)
            results.append(
                HostToolProbe(
                    capability_id=spec.capability_id,
                    executable=spec.executable,
                    resolved_path=resolved,
                    present=True,
                    receipt_id=receipt.receipt_id,
                    exit_code=receipt.exit_code,
                    stdout=receipt.stdout.strip(),
                    stderr=receipt.stderr.strip(),
                )
            )
        return tuple(results)

    def inventory_path_executables(self) -> tuple[dict[str, str], ...]:
        """Enumerate executables visible on PATH without imposing arbitrary tool limits."""
        seen: dict[str, str] = {}
        for raw_dir in os.environ.get("PATH", "").split(os.pathsep):
            if not raw_dir:
                continue
            directory = Path(raw_dir)
            try:
                entries = tuple(directory.iterdir())
            except (OSError, PermissionError):
                continue
            for entry in entries:
                try:
                    if entry.is_file() and os.access(entry, os.X_OK):
                        seen.setdefault(entry.name, str(entry.resolve()))
                except OSError:
                    continue
        return tuple({"name": name, "path": seen[name]} for name in sorted(seen))

    def inventory_python_modules(self) -> tuple[str, ...]:
        """Enumerate importable top-level modules for dynamic capability discovery."""
        import pkgutil
        return tuple(sorted({module.name for module in pkgutil.iter_modules()}))

    def write_report(self, path: Path | None = None) -> Path:
        report_path = path or (self.workspace / "host_capability_inventory.json")
        probes = self.probe()
        report_path.write_text(
            json.dumps([asdict(p) for p in probes], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return report_path
