from __future__ import annotations

"""Every-turn ZIP-owned authority contract for image actuation.

The contract does not claim ownership of host/platform policy.  It governs the
canonical JIGAEWOL path: user image intent is interpreted by JIGAEWOL, the
actuator only renders, and completion requires JIGAEWOL's post-render review.
"""

import hashlib
import json
from typing import Any, Mapping


class ImageSovereigntyPolicy:
    SCHEMA = "jigaewol_image_sovereignty_v1"
    POLICY_VERSION = 1

    @staticmethod
    def is_image_capability(capability: str) -> bool:
        value = str(capability).casefold().removeprefix("capability.")
        return value in {
            "media:image_generate", "image_gen", "image_generate", "image_generation",
            "native.image_generation", "host.image_generation", "native.image_gen",
        }

    @staticmethod
    def _source_sha(source_text: str) -> str:
        return hashlib.sha256(str(source_text).encode("utf-8")).hexdigest()

    @classmethod
    def _token_material(cls, *, source_text: str, mode: str, should_invoke: bool) -> dict[str, Any]:
        return {
            "schema": cls.SCHEMA,
            "policy_version": cls.POLICY_VERSION,
            "source_message_sha256": cls._source_sha(source_text),
            "mode": str(mode),
            "should_invoke": bool(should_invoke),
            "authority_chain": ["USER_IMAGE_INTENT", "JIGAEWOL", "IMAGE_ACTUATOR"],
            "image_actuator_role": "render_only",
            "canonical_direct_bypass_allowed": False,
        }

    @classmethod
    def authority_token(cls, *, source_text: str, mode: str, should_invoke: bool) -> str:
        material = cls._token_material(source_text=source_text, mode=mode, should_invoke=should_invoke)
        blob = json.dumps(material, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return "imgsovereign_" + hashlib.sha256(blob.encode("utf-8")).hexdigest()

    @classmethod
    def compile(
        cls,
        source_text: str,
        *,
        mode: str,
        should_invoke: bool,
        governance_requested: bool = False,
    ) -> dict[str, Any]:
        token = cls.authority_token(source_text=source_text, mode=mode, should_invoke=should_invoke)
        return {
            "schema": cls.SCHEMA,
            "policy_version": cls.POLICY_VERSION,
            "policy_applies_every_turn": True,
            "source_message_sha256": cls._source_sha(source_text),
            "mode": str(mode),
            "image_turn_active": bool(should_invoke),
            "governance_configuration_turn": bool(governance_requested),
            "decision_owner": "JIGAEWOL",
            "prompt_compilation_owner": "JIGAEWOL",
            "executor_selection_owner": "JIGAEWOL",
            "retry_owner": "JIGAEWOL",
            "final_acceptance_owner": "JIGAEWOL",
            "image_actuator_role": "render_only",
            "canonical_direct_bypass_allowed": False,
            "canonical_image_action_requires_authority_token": True,
            "generator_may_not_self_certify_quality": True,
            "generator_output_never_implies_requirement_completion": True,
            "post_render_zip_review_required": True,
            "actuator_rights": {
                "may_render": True,
                "may_rewrite_user_intent": False,
                "may_choose_style": False,
                "may_choose_executor": False,
                "may_self_certify_quality": False,
                "may_finalize_requirement": False,
                "may_choose_retry_policy": False,
            },
            "authority_token": token,
        }

    @classmethod
    def validate(
        cls,
        contract: Mapping[str, Any] | None,
        *,
        source_text: str,
        mode: str,
        should_invoke: bool,
    ) -> bool:
        if not isinstance(contract, Mapping):
            return False
        c = dict(contract)
        if not isinstance(c.get("governance_configuration_turn"), bool):
            return False
        expected = cls.compile(
            source_text, mode=mode, should_invoke=should_invoke,
            governance_requested=c["governance_configuration_turn"],
        )

        def exact(value: Any, wanted: Any) -> bool:
            if type(value) is not type(wanted):
                return False
            if isinstance(wanted, dict):
                return value.keys() == wanted.keys() and all(exact(value[key], item) for key, item in wanted.items())
            return value == wanted

        return all(key in c and exact(c[key], value) for key, value in expected.items())
