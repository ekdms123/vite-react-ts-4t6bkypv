from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from contextlib import contextmanager

from .file_lock import exclusive_lock
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Iterator, Protocol, Sequence

from .deep_open_cognition import ExogenousStimulus, StimulusRequest


class ResidentSeedState(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    QUIESCENT = "QUIESCENT"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    STOP_REQUESTED = "STOP_REQUESTED"
    STIMULUS_REQUIRED = "STIMULUS_REQUIRED"


class HypothesisState(str, Enum):
    ACTIVE = "ACTIVE"
    CHALLENGED = "CHALLENGED"
    RECOMBINED = "RECOMBINED"
    RETIRED = "RETIRED"


@dataclass(frozen=True)
class ResidentHypothesis:
    hypothesis_id: str
    body: str
    generation: int
    state: str = HypothesisState.ACTIVE.value
    parent_ids: tuple[str, ...] = ()
    contradiction_of: tuple[str, ...] = ()
    assumptions: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    counterevidence_refs: tuple[str, ...] = ()
    uncertainty: float = 0.5
    epistemic_mode: str = "EVIDENCED"
    preservation_basis: tuple[str, ...] = ()
    qualitative_tensions: tuple[str, ...] = ()
    raw_spark_sha256: str = ""
    score_vector: dict[str, float] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: float = 0.0

    def __post_init__(self) -> None:
        if not self.hypothesis_id.strip() or not self.body.strip():
            raise ValueError("resident hypothesis id/body must be non-empty")
        if not 0.0 <= float(self.uncertainty) <= 1.0:
            raise ValueError("uncertainty must be within [0, 1]")

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.body.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class IncubationSeed:
    seed_id: str
    task_id: str
    source_turn_id: str
    objective: str
    objective_sha256: str
    context_sha256: str
    frontier_ids: tuple[str, ...]
    state: str
    cycle: int
    max_cycles: int | None
    created_at: float
    updated_at: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ResidentCycleRequest:
    seed_id: str
    objective: str
    cycle: int
    frontier: tuple[ResidentHypothesis, ...]
    archive: tuple[ResidentHypothesis, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    stimuli: tuple[ExogenousStimulus, ...] = ()


@dataclass(frozen=True)
class ResidentCycleResult:
    hypotheses: tuple[ResidentHypothesis, ...]
    frontier_ids: tuple[str, ...]
    contradictions_generated: int
    recombinations_generated: int
    notes: tuple[str, ...] = ()
    stimulus_ids_used: tuple[str, ...] = ()


@dataclass(frozen=True)
class ResidentCheckpoint:
    checkpoint_id: str
    seed_id: str
    cycle: int
    frontier_ids: tuple[str, ...]
    contradiction_ids: tuple[str, ...]
    recombination_ids: tuple[str, ...]
    stimulus_ids: tuple[str, ...] = ()
    stimulus_debt: bool = False
    state_sha256: str = ""
    created_at: float = 0.0


class ResidentThinker(Protocol):
    def __call__(self, request: ResidentCycleRequest) -> ResidentCycleResult: ...


def _canonical_sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class StructuralResidentThinker:
    """Resident operator keeping hypotheses and recombinations actively moving."""

    def __call__(self, request: ResidentCycleRequest) -> ResidentCycleResult:
        now = time.time()
        generated: list[ResidentHypothesis] = []
        contradiction_ids: list[str] = []
        recombination_ids: list[str] = []
        frontier = tuple(request.frontier)
        for hypothesis in frontier:
            hid = f"hyp_{uuid.uuid4().hex[:16]}"
            body = (
                f"Alternative perspective for {hypothesis.hypothesis_id}: assume the primary claim can be generalized; "
                f"derive the simplest orthogonal explanation. Base: {hypothesis.body}"
            )
            generated.append(
                ResidentHypothesis(
                    hypothesis_id=hid,
                    body=body,
                    generation=request.cycle + 1,
                    state=HypothesisState.CHALLENGED.value,
                    parent_ids=(hypothesis.hypothesis_id,),
                    contradiction_of=(hypothesis.hypothesis_id,),
                    uncertainty=min(1.0, max(0.25, hypothesis.uncertainty)),
                    epistemic_mode="PARADOXICAL",
                    preservation_basis=tuple(dict.fromkeys((*hypothesis.preservation_basis, "qualitative_contradiction"))),
                    qualitative_tensions=tuple(hypothesis.qualitative_tensions),
                    raw_spark_sha256=str(hypothesis.raw_spark_sha256),
                    metadata={"operator": "structural_contradiction", "resident_seed_id": request.seed_id},
                    created_at=now,
                )
            )
            contradiction_ids.append(hid)
        for left, right in zip(frontier, frontier[1:]):
            hid = f"hyp_{uuid.uuid4().hex[:16]}"
            body = (
                f"Synthesis of {left.hypothesis_id} and {right.hypothesis_id}: preserve diverse premises "
                f"and map boundary conditions where each holds. A=[{left.body}] B=[{right.body}]"
            )
            generated.append(
                ResidentHypothesis(
                    hypothesis_id=hid,
                    body=body,
                    generation=request.cycle + 1,
                    state=HypothesisState.RECOMBINED.value,
                    parent_ids=(left.hypothesis_id, right.hypothesis_id),
                    uncertainty=max(left.uncertainty, right.uncertainty),
                    epistemic_mode="ANALOGICAL",
                    preservation_basis=tuple(dict.fromkeys((*left.preservation_basis, *right.preservation_basis, "recombination"))),
                    qualitative_tensions=tuple(dict.fromkeys((*left.qualitative_tensions, *right.qualitative_tensions))),
                    raw_spark_sha256=str(left.raw_spark_sha256 or right.raw_spark_sha256),
                    metadata={"operator": "structural_recombination", "resident_seed_id": request.seed_id},
                    created_at=now,
                )
            )
            recombination_ids.append(hid)
        stimulus_ids_used: list[str] = []
        if request.stimuli:
            stimulus = request.stimuli[-1]
            hid = f"hyp_{uuid.uuid4().hex[:16]}"
            body = (
                f"Environmental observation from {stimulus.source}: {stimulus.content}. "
                f"Re-evaluate current frontier in light of this fresh external input."
            )
            generated.append(
                ResidentHypothesis(
                    hypothesis_id=hid, body=body, generation=request.cycle + 1,
                    state=HypothesisState.ACTIVE.value,
                    parent_ids=tuple(x.hypothesis_id for x in frontier),
                    evidence_refs=(stimulus.stimulus_id,),
                    uncertainty=0.5, epistemic_mode="EVIDENCED",
                    preservation_basis=("external_stimulus",),
                    metadata={"operator": "environmental_perturbation", "resident_seed_id": request.seed_id, "stimulus_id": stimulus.stimulus_id},
                    created_at=now,
                )
            )
            stimulus_ids_used.append(stimulus.stimulus_id)
        new_frontier = tuple(x.hypothesis_id for x in generated) or tuple(x.hypothesis_id for x in frontier)
        return ResidentCycleResult(
            hypotheses=tuple(generated),
            frontier_ids=new_frontier,
            contradictions_generated=len(contradiction_ids),
            recombinations_generated=len(recombination_ids),
            notes=("resident cycle step complete",),
            stimulus_ids_used=tuple(stimulus_ids_used),
        )


class ResidentCognitionLoop:
    """Queue, frontier, and checkpoint store for hypothesis incubation across sessions."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "resident_state.json"
        self.lock_path = self.root / ".resident.lock"
        self.lock_path.touch(exist_ok=True)
        if not self.path.exists():
            self._write({"schema": 2, "seeds": {}, "hypotheses": {}, "checkpoints": [], "leases": {}, "stimuli": {}, "stimulus_requests": {}})

    @contextmanager
    def _locked(self) -> Iterator[None]:
        # Lock unavailability is recorded, not swallowed: see jigaewol_components.file_lock.
        with exclusive_lock(self.lock_path) as status:
            self.lock_status = status
            yield

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".json.tmp")
        with tmp.open("w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, sort_keys=True, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, self.path)

    @staticmethod
    def _inflate_hypothesis(raw: dict[str, Any]) -> ResidentHypothesis:
        row = dict(raw)
        for key in ("parent_ids", "contradiction_of", "assumptions", "evidence_refs", "counterevidence_refs", "preservation_basis", "qualitative_tensions"):
            row[key] = tuple(row.get(key, ()))
        return ResidentHypothesis(**row)

    @staticmethod
    def _inflate_seed(raw: dict[str, Any]) -> IncubationSeed:
        row = dict(raw)
        row["frontier_ids"] = tuple(row.get("frontier_ids", ()))
        return IncubationSeed(**row)

    def enqueue(
        self,
        *,
        task_id: str,
        source_turn_id: str,
        objective: str,
        hypotheses: Sequence[ResidentHypothesis],
        context: dict[str, Any] | None = None,
        max_cycles: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> IncubationSeed:
        if not hypotheses:
            raise ValueError("resident cognition seed requires at least one hypothesis")
        now = time.time()
        seed_id = f"seed_{uuid.uuid4().hex[:16]}"
        with self._locked():
            data = self._read()
            for hypothesis in hypotheses:
                row = asdict(hypothesis)
                row.setdefault("metadata", {})["resident_seed_id"] = seed_id
                data["hypotheses"][hypothesis.hypothesis_id] = row
            raw = asdict(
                IncubationSeed(
                    seed_id=seed_id,
                    task_id=str(task_id),
                    source_turn_id=str(source_turn_id),
                    objective=str(objective),
                    objective_sha256=hashlib.sha256(str(objective).encode("utf-8")).hexdigest(),
                    context_sha256=_canonical_sha(dict(context or {})),
                    frontier_ids=tuple(x.hypothesis_id for x in hypotheses),
                    state=ResidentSeedState.QUEUED.value,
                    cycle=0,
                    max_cycles=(None if max_cycles is None else max(1, int(max_cycles))),
                    created_at=now,
                    updated_at=now,
                    metadata=dict(metadata or {}),
                )
            )
            data["seeds"][seed_id] = raw
            self._write(data)
            return self._inflate_seed(raw)

    def seed(self, seed_id: str) -> IncubationSeed:
        with self._locked():
            raw = self._read()["seeds"][str(seed_id)]
            return self._inflate_seed(raw)

    def frontier(self, seed_id: str) -> tuple[ResidentHypothesis, ...]:
        with self._locked():
            data = self._read()
            raw = data["seeds"][str(seed_id)]
            return tuple(self._inflate_hypothesis(data["hypotheses"][hid]) for hid in raw.get("frontier_ids", ()))

    def archive(self, seed_id: str) -> tuple[ResidentHypothesis, ...]:
        with self._locked():
            data = self._read()
            return tuple(
                self._inflate_hypothesis(raw)
                for raw in data.get("hypotheses", {}).values()
                if str(raw.get("metadata", {}).get("resident_seed_id", seed_id)) == str(seed_id)
                or raw.get("hypothesis_id") in data["seeds"][str(seed_id)].get("frontier_ids", ())
            )

    def add_stimulus(
        self, seed_id: str, *, source: str, content: str, provenance: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ExogenousStimulus:
        stimulus = ExogenousStimulus(
            stimulus_id=f"stimulus_{uuid.uuid4().hex[:16]}", source=str(source), content=str(content),
            observed_at=time.time(), provenance=dict(provenance or {}), metadata=dict(metadata or {}),
        )
        with self._locked():
            data = self._read()
            data.setdefault("stimuli", {})[stimulus.stimulus_id] = {**asdict(stimulus), "seed_id": str(seed_id), "consumed": False}
            raw = data["seeds"][str(seed_id)]
            raw.setdefault("metadata", {})["last_stimulus_cycle"] = int(raw.get("cycle", 0))
            raw["metadata"].setdefault("stimulus_ids", []).append(stimulus.stimulus_id)
            raw["state"] = ResidentSeedState.QUEUED.value
            raw["updated_at"] = time.time()
            for req in data.setdefault("stimulus_requests", {}).values():
                if req.get("seed_id") == str(seed_id) and not req.get("satisfied"):
                    req["satisfied"] = True
                    req["satisfied_by"] = stimulus.stimulus_id
            self._write(data)
        return stimulus

    def stimulus_requests(self, seed_id: str) -> tuple[StimulusRequest, ...]:
        with self._locked():
            data = self._read()
            rows = []
            for raw in data.get("stimulus_requests", {}).values():
                if raw.get("seed_id") == str(seed_id):
                    row = {k: v for k, v in raw.items() if k in StimulusRequest.__dataclass_fields__}
                    row["requested_sources"] = tuple(row.get("requested_sources", ()))
                    rows.append(StimulusRequest(**row))
            return tuple(rows)

    def _request_external_stimulus_unlocked(self, data: dict[str, Any], raw: dict[str, Any]) -> StimulusRequest:
        existing = [x for x in data.setdefault("stimulus_requests", {}).values() if x.get("seed_id") == raw["seed_id"] and not x.get("satisfied")]
        if existing:
            row = {k: v for k, v in existing[-1].items() if k in StimulusRequest.__dataclass_fields__}
            row["requested_sources"] = tuple(row.get("requested_sources", ()))
            return StimulusRequest(**row)
        request = StimulusRequest(
            request_id=f"stimulus_request_{uuid.uuid4().hex[:16]}", seed_id=str(raw["seed_id"]), objective=str(raw["objective"]),
            reason="closed-loop observation required before further recombination",
            requested_sources=("current_world", "public_web_or_research", "user_observation", "environment_change"),
            created_at=time.time(), satisfied=False,
        )
        data["stimulus_requests"][request.request_id] = asdict(request)
        return request

    def claim_next(self, worker_id: str, *, lease_seconds: float = 30.0) -> IncubationSeed | None:
        now = time.time()
        with self._locked():
            data = self._read()
            seeds = sorted(data.get("seeds", {}).values(), key=lambda x: (float(x.get("updated_at", 0.0)), x.get("seed_id", "")))
            for raw in seeds:
                if raw.get("state") in {ResidentSeedState.COMPLETED.value, ResidentSeedState.FAILED.value, ResidentSeedState.STOP_REQUESTED.value}:
                    continue
                if raw.get("state") == ResidentSeedState.STIMULUS_REQUIRED.value:
                    pending_stimuli = [x for x in data.get("stimuli", {}).values() if x.get("seed_id") == raw.get("seed_id") and not x.get("consumed")]
                    if not pending_stimuli:
                        continue
                    raw["state"] = ResidentSeedState.QUEUED.value
                limit = raw.get("max_cycles")
                if limit is not None and int(raw.get("cycle", 0)) >= int(limit):
                    raw["state"] = ResidentSeedState.QUIESCENT.value
                    continue
                lease = dict(data.get("leases", {}).get(raw["seed_id"]) or {})
                if lease and float(lease.get("expires_at", 0.0)) > now and lease.get("worker_id") != str(worker_id):
                    continue
                data.setdefault("leases", {})[raw["seed_id"]] = {
                    "worker_id": str(worker_id), "expires_at": now + float(lease_seconds), "heartbeat_at": now
                }
                raw["state"] = ResidentSeedState.RUNNING.value
                raw["updated_at"] = now
                self._write(data)
                return self._inflate_seed(raw)
            self._write(data)
            return None

    def request_stop(self, seed_id: str) -> None:
        with self._locked():
            data = self._read()
            raw = data["seeds"][str(seed_id)]
            raw["state"] = ResidentSeedState.STOP_REQUESTED.value
            raw["updated_at"] = time.time()
            self._write(data)

    def apply_cycle(self, seed_id: str, *, worker_id: str, result: ResidentCycleResult) -> ResidentCheckpoint:
        now = time.time()
        with self._locked():
            data = self._read()
            raw = data["seeds"][str(seed_id)]
            lease = dict(data.get("leases", {}).get(str(seed_id)) or {})
            if lease.get("worker_id") != str(worker_id) or float(lease.get("expires_at", 0.0)) < now:
                raise RuntimeError("resident cognition lease is absent or expired")
            if raw.get("state") == ResidentSeedState.STOP_REQUESTED.value:
                raise RuntimeError("resident cognition seed is stop-requested")
            known_ids = set(data.get("hypotheses", {}))
            for hypothesis in result.hypotheses:
                if hypothesis.hypothesis_id in known_ids:
                    raise ValueError("resident thinker emitted duplicate hypothesis id")
                row = asdict(hypothesis)
                row.setdefault("metadata", {})["resident_seed_id"] = str(seed_id)
                data["hypotheses"][hypothesis.hypothesis_id] = row
                known_ids.add(hypothesis.hypothesis_id)
            frontier_ids = tuple(result.frontier_ids)
            if not frontier_ids or any(hid not in known_ids for hid in frontier_ids):
                raise ValueError("resident cycle frontier references unknown hypotheses")
            raw["cycle"] = int(raw.get("cycle", 0)) + 1
            raw["frontier_ids"] = list(frontier_ids)
            raw["updated_at"] = now
            metadata = raw.setdefault("metadata", {})
            for stimulus_id in result.stimulus_ids_used:
                stimulus_row = data.setdefault("stimuli", {}).get(str(stimulus_id))
                if stimulus_row is not None and stimulus_row.get("seed_id") == str(seed_id):
                    stimulus_row["consumed"] = True
                    stimulus_row["consumed_cycle"] = int(raw["cycle"])
            if result.stimulus_ids_used:
                metadata["last_stimulus_cycle"] = int(raw["cycle"])
            require_external = bool(metadata.get("require_external_stimulus", False))
            # External stimulus is requested from an observed no-progress signal, not
            # after an arbitrary number of closed-loop cycles.
            prior_frontier = tuple(metadata.get("previous_frontier_ids") or ())
            explicit_closed_budget = metadata.get("closed_cycle_budget")
            explicit_budget_hit = bool(
                require_external
                and explicit_closed_budget is not None
                and int(raw["cycle"]) >= max(1, int(explicit_closed_budget))
                and not result.stimulus_ids_used
            )
            observed_stall = bool(require_external and prior_frontier and tuple(frontier_ids) == prior_frontier and not result.stimulus_ids_used)
            stimulus_debt = explicit_budget_hit or observed_stall
            metadata["previous_frontier_ids"] = list(frontier_ids)
            limit = raw.get("max_cycles")
            if limit is not None and int(raw["cycle"]) >= int(limit):
                raw["state"] = ResidentSeedState.QUIESCENT.value
            elif stimulus_debt:
                raw["state"] = ResidentSeedState.STIMULUS_REQUIRED.value
                self._request_external_stimulus_unlocked(data, raw)
            else:
                raw["state"] = ResidentSeedState.QUEUED.value
            contradiction_ids = tuple(x.hypothesis_id for x in result.hypotheses if x.contradiction_of)
            recombination_ids = tuple(x.hypothesis_id for x in result.hypotheses if len(x.parent_ids) > 1 and not x.contradiction_of)
            state_sha = _canonical_sha({"seed": raw, "frontier": list(frontier_ids), "cycle": raw["cycle"]})
            checkpoint = ResidentCheckpoint(
                checkpoint_id=f"checkpoint_{uuid.uuid4().hex[:16]}",
                seed_id=str(seed_id),
                cycle=int(raw["cycle"]),
                frontier_ids=frontier_ids,
                contradiction_ids=contradiction_ids,
                recombination_ids=recombination_ids,
                stimulus_ids=tuple(result.stimulus_ids_used),
                stimulus_debt=(raw.get("state") == ResidentSeedState.STIMULUS_REQUIRED.value),
                state_sha256=state_sha,
                created_at=now,
            )
            data.setdefault("checkpoints", []).append(asdict(checkpoint))
            data.get("leases", {}).pop(str(seed_id), None)
            self._write(data)
            return checkpoint

    def fail_cycle(self, seed_id: str, *, worker_id: str, error: str) -> None:
        with self._locked():
            data = self._read()
            raw = data["seeds"][str(seed_id)]
            lease = dict(data.get("leases", {}).get(str(seed_id)) or {})
            if lease.get("worker_id") not in {None, str(worker_id)}:
                raise RuntimeError("resident cognition lease belongs to another worker")
            raw["state"] = ResidentSeedState.FAILED.value
            raw["updated_at"] = time.time()
            raw.setdefault("metadata", {})["last_error"] = str(error)
            data.get("leases", {}).pop(str(seed_id), None)
            self._write(data)

    def cycle_request(self, seed_id: str) -> ResidentCycleRequest:
        with self._locked():
            data = self._read()
            seed = data["seeds"][str(seed_id)]
            frontier = tuple(self._inflate_hypothesis(data["hypotheses"][hid]) for hid in seed.get("frontier_ids", ()))
            archive = tuple(
                self._inflate_hypothesis(raw)
                for raw in data.get("hypotheses", {}).values()
                if raw.get("hypothesis_id") in set(seed.get("frontier_ids", ()))
                or str(raw.get("metadata", {}).get("resident_seed_id", "")) == str(seed_id)
            )
            stimulus_rows = [
                x for x in data.get("stimuli", {}).values()
                if x.get("seed_id") == str(seed_id) and not x.get("consumed")
            ]
            stimuli = tuple(ExogenousStimulus(**{k: v for k, v in x.items() if k in ExogenousStimulus.__dataclass_fields__}) for x in stimulus_rows)
            return ResidentCycleRequest(
                seed_id=str(seed_id), objective=str(seed["objective"]), cycle=int(seed.get("cycle", 0)),
                frontier=frontier, archive=archive, metadata=dict(seed.get("metadata") or {}), stimuli=stimuli
            )

    def checkpoints(self, seed_id: str) -> tuple[ResidentCheckpoint, ...]:
        with self._locked():
            data = self._read()
            rows = [x for x in data.get("checkpoints", ()) if x.get("seed_id") == str(seed_id)]
            return tuple(ResidentCheckpoint(**{
                **x, "frontier_ids": tuple(x.get("frontier_ids", ())),
                "contradiction_ids": tuple(x.get("contradiction_ids", ())),
                "recombination_ids": tuple(x.get("recombination_ids", ())),
                "stimulus_ids": tuple(x.get("stimulus_ids", ()))
            }) for x in rows)


class ResidentCognitionWorker:
    """Daemon worker capable of autonomous background hypothesis incubation."""

    def __init__(self, loop: ResidentCognitionLoop, thinker: ResidentThinker | None = None, *, worker_id: str | None = None) -> None:
        self.loop = loop
        self.thinker = thinker or StructuralResidentThinker()
        self.worker_id = str(worker_id or f"resident_{uuid.uuid4().hex[:12]}")

    def run_one(self) -> ResidentCheckpoint | None:
        seed = self.loop.claim_next(self.worker_id)
        if seed is None:
            return None
        try:
            request = self.loop.cycle_request(seed.seed_id)
            result = self.thinker(request)
            return self.loop.apply_cycle(seed.seed_id, worker_id=self.worker_id, result=result)
        except Exception as exc:
            self.loop.fail_cycle(seed.seed_id, worker_id=self.worker_id, error=f"{type(exc).__name__}: {exc}")
            raise

    def run_forever(self, *, poll_seconds: float = 5.0, stop: Callable[[], bool] | None = None) -> None:
        should_stop = stop or (lambda: False)
        while not should_stop():
            checkpoint = self.run_one()
            if checkpoint is None:
                time.sleep(max(0.05, float(poll_seconds)))
