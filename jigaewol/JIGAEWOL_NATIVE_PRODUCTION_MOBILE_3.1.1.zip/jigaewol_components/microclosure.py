from __future__ import annotations

import hashlib, json, re
from dataclasses import dataclass, asdict
from typing import Any, Iterable, Mapping


def _sha(x: Any) -> str:
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()

@dataclass(frozen=True)
class Assumption:
    assumption_id: str
    category: str
    statement: str
    inherited_from: str
    status: str = "challengeable"

@dataclass(frozen=True)
class IntentRelation:
    relation_id: str
    left: str
    relation: str
    right: str
    evidence: str

@dataclass(frozen=True)
class OpenRepresentation:
    exact_message: str
    intent_anchor: str
    atoms: tuple[dict[str, Any], ...]
    relations: tuple[IntentRelation, ...]
    assumptions: tuple[Assumption, ...]
    units_are_provisional: bool = True
    representation_is_revisable: bool = True
    plan_shape_is_revisable: bool = True
    # Whether this message deserves thought at all. Computed once here and carried,
    # so downstream cannot re-derive it from a lossy proxy such as bool(assumptions):
    # a substantive message that misses the assumption keyword taxonomy produced zero
    # assumptions and was then treated as not worth thinking about.
    substantive: bool = True

    def as_mapping(self):
        return {**asdict(self), "relations": [asdict(x) for x in self.relations], "assumptions": [asdict(x) for x in self.assumptions]}

class MicroClosureAuditor:
    """Challenges silent defaults without turning challenge itself into a mandatory ritual."""

    RELATIONS = (
        (r"하지만|그런데|하되|\bbut\b", "contrast"),
        (r"\b대신\b|\binstead\b", "substitution"),
        (r"\b때문\b|\bbecause\b|\bso that\b", "causal_or_reason"),
        (r"\b절대\b|\b무조건\b|\b반드시\b|\bnever\b|\bmust\b", "priority_or_non_downgrade"),
        (r"\b그리고\b|\band\b", "conjunction"),
    )

    DEFAULT_ASSUMPTIONS = (
        ("unit", "one chat turn is the natural unit of cognition"),
        ("goal", "the latest sentence is identical to the user's underlying goal"),
        ("atom", "intent is fully represented by a bag of requirement atoms"),
        ("tool", "named tools are the natural units of action"),
        ("route", "a solution should be represented as a route through predefined phases"),
        ("search", "information discovery is naturally query-centric"),
        ("agent", "parallel cognition is naturally a fixed number of agents/cells"),
        ("success", "successful outcomes are more reusable than informative failures"),
        ("memory", "lexical similarity is a good default for retrieving prior experience"),
        ("artifact", "one monolithic versioned artifact is the natural unit of evolution"),
        ("progress", "more tool calls or more branches imply more progress or openness"),
        ("closure", "the system should converge within the current response if it can"),
    )

    @staticmethod
    def _relevant_assumption_categories(message: str, atoms: tuple[dict[str, Any], ...]) -> set[str]:
        low = str(message).casefold()
        cats: set[str] = set()
        if len(atoms) > 1 or any(x in low for x in ("하지만", "하되", "대신", "그리고", "but", "instead", "while")):
            cats.update({"atom", "goal"})
        if any(x in low for x in ("검색", "찾아", "research", "search", "x.com", "트위터", "instagram", "인스타")):
            cats.add("search")
        if any(x in low for x in ("도구", "tool", "plugin", "플러그인", "github", "브라우저", "browser")):
            cats.update({"tool", "route"})
        if any(x in low for x in ("구조", "방식", "발명", "architecture", "reframe", "reinvent")):
            cats.update({"route", "progress"})
        if any(x in low for x in ("agent", "에이전트", "병렬", "parallel", "subagent")):
            cats.add("agent")
        if any(x in low for x in ("기억", "memory", "과거", "이전", "계속")):
            cats.add("memory")
        if any(x in low for x in ("zip", "파일", "artifact", "버전", "version")):
            cats.add("artifact")
        if any(x in low for x in ("끝", "최종", "완료", "closure", "final")):
            cats.add("closure")
        if any(x in low for x in ("성공", "실패", "success", "failure", "검증")):
            cats.add("success")
        return cats

    @staticmethod
    def _substantive(message: str, atoms: Iterable[Mapping[str, Any]]) -> bool:
        # No topology/divergence heuristic gets veto power over whether the message deserves thought.
        text = str(message).strip()
        if not text:
            return False
        if len(text) <= 12 and not tuple(atoms):
            return False
        return True

    def represent(self, *, message: str, atoms: Iterable[Mapping[str, Any]], prior_goal: str = "") -> OpenRepresentation:
        atom_rows = tuple(dict(x) for x in atoms)
        relations = []
        for pattern, kind in self.RELATIONS:
            for m in re.finditer(pattern, message, re.I):
                left = message[:m.start()].splitlines()[-1].strip()
                right = message[m.end():].splitlines()[0].strip()
                relations.append(IntentRelation("rel_"+_sha((kind,m.start(),left,right))[:14], left, kind, right, m.group(0)))
        assumptions = []
        substantive = self._substantive(message, atom_rows)
        if substantive:
            relevant = self._relevant_assumption_categories(message, atom_rows)
            for category, statement in self.DEFAULT_ASSUMPTIONS:
                if category in relevant:
                    assumptions.append(Assumption("assumption_"+_sha((category,statement))[:14], category, statement, "observed_task_shape"))
        anchor = prior_goal.strip() or message.strip()
        return OpenRepresentation(
            message, anchor, atom_rows, tuple(relations), tuple(assumptions),
            substantive=substantive,
        )

    @staticmethod
    def challenge_prompt(rep: OpenRepresentation) -> str:
        if not rep.assumptions:
            return ""
        return "What would change if the conventional workflow, named tools, phase order, and current representation were never assumed in the first place?"
