from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Iterable, Mapping

from .runtime_home import resolve_runtime_home


class ArtifactIntegrityError(RuntimeError):
    """Raised when the sealed runtime source no longer matches its canonical manifest."""


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _stable_rows_sha(rows: Iterable[Mapping[str, Any]]) -> str:
    payload = json.dumps(
        list(rows), ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _load_manifest(root: Path) -> tuple[dict[str, Any], list[dict[str, Any]], str]:
    path = root / "CANONICAL_ARTIFACT.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ArtifactIntegrityError("canonical artifact manifest is missing or unreadable") from exc
    rows = data.get("active_files")
    if not isinstance(rows, list) or not all(isinstance(x, dict) for x in rows):
        raise ArtifactIntegrityError("canonical artifact active_files must be a list of objects")
    paths = [str(x.get("path") or "") for x in rows]
    if any(not x for x in paths) or len(paths) != len(set(paths)):
        raise ArtifactIntegrityError("canonical artifact active_files contains empty or duplicate paths")
    declared_count = int(data.get("active_file_count") or -1)
    if declared_count != len(rows):
        raise ArtifactIntegrityError(
            f"canonical artifact active_file_count mismatch: declared={declared_count} actual={len(rows)}"
        )
    rows_sha = _stable_rows_sha(rows)
    declared_sha = str(data.get("active_content_set_sha256") or "").strip()
    if not declared_sha or rows_sha != declared_sha:
        raise ArtifactIntegrityError("canonical artifact active content-set digest mismatch")
    content_sha = str(data.get("content_set_sha256") or "").strip()
    if content_sha and content_sha != rows_sha:
        raise ArtifactIntegrityError("canonical artifact content_set_sha256 disagrees with active set")
    return data, rows, rows_sha


def _current_stats(root: Path, rows: list[dict[str, Any]]) -> tuple[dict[str, dict[str, int]], list[str]]:
    stats: dict[str, dict[str, int]] = {}
    missing: list[str] = []
    for row in rows:
        rel = str(row["path"])
        path = root / rel
        try:
            st = path.stat()
        except OSError:
            missing.append(rel)
            continue
        if not path.is_file():
            missing.append(rel)
            continue
        stats[rel] = {"size": int(st.st_size), "mtime_ns": int(st.st_mtime_ns)}
    return stats, missing


def verify_active_artifact(
    root: str | Path,
    *,
    check_membership: bool = True,
    use_cache: bool = True,
) -> dict[str, Any]:
    """Verify immutable shipped files while allowing mutable runtime state.

    The canonical manifest intentionally seals only package/source membership. Runtime
    receipts, sqlite state, traces, caches, generated evidence, and other mutable files
    may appear beside the source and are *not* treated as corruption merely because the
    active directory contains more files than the release ZIP.

    A stat-bound cache makes the normal per-turn check cheap. Any sealed file whose size
    or mtime changed is re-hashed before the turn is admitted.
    """

    root = Path(root).expanduser().resolve()
    _manifest, rows, rows_sha = _load_manifest(root)
    root_key = hashlib.sha256(str(root).encode("utf-8")).hexdigest()[:20]
    cache_path = resolve_runtime_home(runtime_identity="JIGAEWOL") / "artifact_integrity" / f"{root_key}.json"
    stats, missing = _current_stats(root, rows)
    if missing:
        raise ArtifactIntegrityError(
            "sealed runtime files are missing: " + ", ".join(missing[:12])
        )

    prior: dict[str, Any] = {}
    if use_cache and cache_path.is_file():
        try:
            prior = json.loads(cache_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            prior = {}

    membership_ok = True
    membership_count = len(rows)
    if check_membership:
        # Import lazily: the integrity primitive stays reusable without making package
        # construction part of module import time.
        from tools.build_zip import CANONICAL_NONRECURSIVE_METADATA, personal_files

        expected = sorted(
            name
            for name in personal_files(root)
            if name not in CANONICAL_NONRECURSIVE_METADATA
        )
        actual = sorted(str(x["path"]) for x in rows)
        membership_ok = expected == actual
        membership_count = len(expected)
        if not membership_ok:
            extra = sorted(set(expected) - set(actual))
            stale = sorted(set(actual) - set(expected))
            raise ArtifactIntegrityError(
                "canonical package membership drift: "
                f"unsealed_package_files={extra[:12]} stale_manifest_files={stale[:12]}"
            )

    cached_stats = prior.get("file_stats") if isinstance(prior.get("file_stats"), dict) else {}
    cache_hit = bool(
        use_cache
        and prior.get("verified") is True
        and prior.get("active_content_set_sha256") == rows_sha
        and cached_stats == stats
        and (not check_membership or prior.get("membership_ok") is True)
    )

    checked_files = 0
    if not cache_hit:
        bad_size: list[str] = []
        bad_hash: list[str] = []
        for row in rows:
            rel = str(row["path"])
            path = root / rel
            expected_size = int(row.get("size") or 0)
            if path.stat().st_size != expected_size:
                bad_size.append(rel)
                continue
            checked_files += 1
            if _sha256_file(path) != str(row.get("sha256") or ""):
                bad_hash.append(rel)
        if bad_size or bad_hash:
            raise ArtifactIntegrityError(
                "sealed runtime bytes changed: "
                f"size_mismatch={bad_size[:12]} sha256_mismatch={bad_hash[:12]}"
            )

    row = {
        "format": "jigaewol_active_artifact_integrity_v1",
        "verified": True,
        "active_content_set_sha256": rows_sha,
        "sealed_file_count": len(rows),
        "package_membership_count": membership_count,
        "membership_ok": membership_ok,
        "cache_hit": cache_hit,
        "hashed_file_count": checked_files,
        "mutable_runtime_files_allowed": True,
        "verified_at": time.time(),
        "file_stats": stats,
    }
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = cache_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(row, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    tmp.replace(cache_path)
    return row


def assert_active_artifact_integrity(root: str | Path) -> dict[str, Any]:
    return verify_active_artifact(root, check_membership=False, use_cache=True)
