from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class ObjectiveAnchor:
    command_sha256: str
    exact_objective: str
    requirement_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        self.validate()

    def validate(self) -> None:
        recomputed = hashlib.sha256(self.exact_objective.encode("utf-8")).hexdigest()
        if recomputed != str(self.command_sha256 or "").strip().lower():
            raise ValueError("objective_anchor_sha256_mismatch")

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ExplorationCandidate:
    result_id: str
    run_id: str
    operator_id: str
    requirement_bindings: tuple[str, ...]
    payload: str
    causal_delta: Mapping[str, Any]
    causal_proof: Mapping[str, Any] = field(default_factory=dict)
    evidence_state: str = "speculative"
    evidence_refs: tuple[str, ...] = ()
    self_promoting: bool = False

    @classmethod
    def build(
        cls,
        *,
        run_id: str,
        operator_id: str,
        requirement_bindings: Iterable[str],
        payload: str,
        causal_delta: Mapping[str, Any],
        causal_proof: Mapping[str, Any] | None = None,
        evidence_state: str = "speculative",
        evidence_refs: Iterable[str] = (),
    ) -> "ExplorationCandidate":
        base = {
            "run_id": str(run_id),
            "operator_id": str(operator_id),
            "requirement_bindings": tuple(str(x) for x in requirement_bindings if str(x)),
            "payload": str(payload),
            "causal_delta": dict(causal_delta),
            "causal_proof": dict(causal_proof or {}),
            "evidence_state": str(evidence_state),
            "evidence_refs": tuple(str(x) for x in evidence_refs if str(x)),
        }
        raw = json.dumps(base, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
        return cls(
            "result_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20],
            self_promoting=False,
            **base,
        )

    def as_mapping(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "causal_delta": dict(self.causal_delta),
            "causal_proof": dict(self.causal_proof),
        }


@dataclass(frozen=True)
class ExplorationSelection:
    accepted: tuple[ExplorationCandidate, ...]
    speculative_live: tuple[ExplorationCandidate, ...]
    discarded_ids: tuple[str, ...]
    reasons: tuple[str, ...]

    def as_mapping(self) -> dict[str, Any]:
        return {
            "accepted": tuple(x.as_mapping() for x in self.accepted),
            "speculative_live": tuple(x.as_mapping() for x in self.speculative_live),
            "discarded_ids": self.discarded_ids,
            "reasons": self.reasons,
        }


class ExplorationResultFilter:
    """Keep exploration permissive while keeping truth claims separate.

    Nonempty unproven ideas remain available as speculative material.  A result is
    promoted to ``accepted`` only when an independently recorded causal probe shows
    that the intervention changed a downstream decision-relevant state.  This filter
    does not decide what the user is allowed to ask for and never narrows the goal.
    """

    CAUSAL_KEYS = {
        "next_action",
        "question_destroyed",
        "route_unlocked",
        "assumption_changed",
        "probe_created",
        "representation_changed",
    }

    @classmethod
    def adjudicate(
        cls,
        *,
        anchor: ObjectiveAnchor,
        candidates: Iterable[ExplorationCandidate],
    ) -> ExplorationSelection:
        anchor.validate()
        valid_ids = set(anchor.requirement_ids)
        accepted: list[ExplorationCandidate] = []
        speculative_live: list[ExplorationCandidate] = []
        discarded_ids: list[str] = []
        reasons: list[str] = []
        seen_delta: set[str] = set()

        for candidate in candidates:
            if not candidate.payload.strip():
                discarded_ids.append(candidate.result_id)
                reasons.append(f"{candidate.result_id}:empty_payload")
                continue
            if candidate.self_promoting:
                speculative_live.append(candidate)
                reasons.append(f"{candidate.result_id}:self_promotion_is_not_proof")
                continue
            if valid_ids and not (set(candidate.requirement_bindings) & valid_ids):
                speculative_live.append(candidate)
                reasons.append(f"{candidate.result_id}:not_bound_to_current_requirement")
                continue

            delta = dict(candidate.causal_delta or {})
            keys = tuple(sorted(k for k in delta if k in cls.CAUSAL_KEYS and delta.get(k)))
            proof = dict(candidate.causal_proof or {})
            if not keys or proof.get("material_change") is not True or not str(proof.get("method") or "").strip():
                speculative_live.append(candidate)
                reasons.append(f"{candidate.result_id}:causal_effect_not_proven")
                continue

            method = str(proof.get("method") or "").strip()
            if method.startswith("matched_ab"):
                before = str(proof.get("before_sha256") or "")
                after = str(proof.get("after_sha256") or "")
                if not before or not after or before == after:
                    speculative_live.append(candidate)
                    reasons.append(f"{candidate.result_id}:matched_ab_without_observed_change")
                    continue

            signature = json.dumps(
                {
                    "delta": {k: delta.get(k) for k in keys},
                    "proof_after": proof.get("after_sha256") or proof.get("observed_ref") or proof.get("probe_id"),
                },
                ensure_ascii=False,
                sort_keys=True,
                default=str,
            )
            if signature in seen_delta:
                speculative_live.append(candidate)
                reasons.append(f"{candidate.result_id}:duplicate_effect_evidence")
                continue
            seen_delta.add(signature)
            accepted.append(candidate)

        return ExplorationSelection(
            tuple(accepted),
            tuple(speculative_live),
            tuple(discarded_ids),
            tuple(reasons),
        )
