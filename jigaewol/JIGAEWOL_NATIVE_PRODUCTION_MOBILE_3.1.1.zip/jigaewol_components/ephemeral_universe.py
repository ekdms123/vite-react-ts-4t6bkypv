from __future__ import annotations

"""Task-local axiom-breaking cognition worlds.

This is deliberately not a claim of new physics, hidden model powers, or formal
correctness.  It is a *representation generator*: when a turn is deep/open enough,
the runtime exposes radically different computational assumptions to the same final
candidate generator while the canonical user destination remains immutable.
"""

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Any, Mapping


def _sha(value: Any) -> str:
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class AxiomBreaker:
    breaker_id: str
    destroyed_assumption: str
    replacement_rule: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class EphemeralUniverseEngine:
    """Compile a bounded superposition of radical task-local representations."""

    AXIOM_BREAKERS: tuple[AxiomBreaker, ...] = (
        AxiomBreaker("no_choice_function", "a useful option can always be selected", "permit families with no global selector; reason locally and preserve unresolved choice"),
        AxiomBreaker("nonmeasurable_state", "every uncertainty admits one global probability measure", "allow incompatible local measures and qualitative possibility without forced probability"),
        AxiomBreaker("identity_partial", "object identity is globally decidable", "treat identity as probe-relative/partial; preserve multiple identity witnesses"),
        AxiomBreaker("partial_composition", "all useful transformations compose associatively", "allow non-composable transformations and invent mediators only where needed"),
        AxiomBreaker("causation_observation_fused", "observation is external to causation", "treat some observations as interventions and track the disturbance as first-class evidence"),
        AxiomBreaker("no_global_totality", "the whole task can always be represented as one global object", "work with compatible local patches; obstruction to gluing is itself output"),
        AxiomBreaker("forcing_generic_capability", "only currently definable capabilities may be considered", "adjoin a generic capability consistent with known constraints, then derive the interface it would require"),
        AxiomBreaker("yoneda_interaction_signature", "an object must be represented by an internal body", "represent it by how every relevant probe/other object can interact with it"),
        AxiomBreaker("opaque_functional_cognition", "internal cognition must be plaintext-readable to be useful", "permit opaque state accessed only through task-relevant functions/queries"),
        AxiomBreaker("local_mathematical_worlds", "one mathematical language must govern the whole task", "solve local aspects in different mathematical worlds and preserve translation debt"),
        AxiomBreaker("institution_logic_plurality", "one logic must adjudicate every subsystem", "let each subsystem use its own logic while translations preserve satisfaction where defined"),
        AxiomBreaker("realizability_body_relative_truth", "truth is independent of executable embodiment", "separate abstract claims from what is realizable by each available body"),
        AxiomBreaker("spectral_sequence_selection", "candidate survival is decided in one verification pass", "let candidates survive through staged differentials; higher-order residues can re-enter later pages"),
        AxiomBreaker("strong_weak_duality", "a hard representation must be attacked in the same coordinates", "seek a dual representation where the strongest interaction becomes weak/easy"),
        AxiomBreaker("tilted_world", "the native arithmetic/characteristic is sacred", "translate to a structurally preserving tilted world, compute there, then map invariants back"),
        AxiomBreaker("tropical_skeleton", "full nonlinear structure is required from the start", "collapse to a piecewise-linear/min-plus skeleton, solve the skeleton, then lift candidates"),
        AxiomBreaker("coinductive_prefix", "a useful computation must terminate before any result is released", "allow indefinitely refinable objects whose every finite prefix satisfies the contract"),
        AxiomBreaker("collapse_universe", "the runtime ontology must persist between tasks", "discard task-local axioms/worlds after emitting lineage, invariants, and useful artifacts"),
    )

    ACTIVATION_MARKERS = (
        "기괴", "이상한", "미친", "틀을 깨", "전제", "공리", "우주", "forcing", "yoneda",
        "spectral", "tropical", "tilt", "coinductive", "한계 없이", "끝까지", "괴물", "초지능",
        "axiom", "ontology", "존재론", "상상은", "누구도 생각", "미치게",
        "평범하게 가지", "미친 결과물", "언어와 해석기", "설계도 기준",
    )

    MATERIALIZATION_MARKERS = (
        "organogenesis", "organogenesis kernel", "기관 생성", "새 기관",
        "기관을 만들어", "기관을 실제", "materialize", "materialization",
        "언어와 해석기", "새 해석기",
    )

    @classmethod
    def compile(cls, command: str, semantic_authority: Mapping[str, Any]) -> dict[str, Any]:
        folded = str(command or "").casefold()
        deep = str(semantic_authority.get("effective_depth") or "") == "deep"
        open_problem = bool(semantic_authority.get("open_problem_required"))
        frontier = bool(semantic_authority.get("frontier_exploration_required"))
        rep = bool(semantic_authority.get("representation_search_required"))
        explicit = any(x.casefold() in folded for x in cls.ACTIVATION_MARKERS)
        materialization_requested = any(x.casefold() in folded for x in cls.MATERIALIZATION_MARKERS)
        # An explicit user request to enter the axiom-breaking/organogenesis mode is itself
        # sufficient activation evidence; semantic classifiers may otherwise incorrectly
        # close the turn before the requested representation search can begin.
        active = bool(explicit or (open_problem and (frontier or (deep and rep))))
        breakers = tuple(x.as_mapping() for x in cls.AXIOM_BREAKERS)
        breaker_ids = [x["breaker_id"] for x in breakers]
        pipeline = (
            "canonical_destination -> organogenesis_kernel -> forcing_generic_capability -> yoneda_interaction_signature -> "
            "opaque_functional_cognition -> local_mathematical_worlds -> institution/realizability -> "
            "spectral_sequence_selection -> dual/tilted/tropical_transforms -> coinductive_prefix -> "
            "collapse_task_local_universe"
        )
        organogenesis_handoff = {
            "module": "jigaewol_components.organogenesis_kernel",
            "entrypoint": "OrganogenesisKernel.run",
            "co_synthesized_dimensions": ("representation", "language", "operation_semantics", "interpreter", "observer", "program"),
            "failure_can_birth_structure": True,
            "fixed_external_solver_is_not_the_search_ontology": True,
        }
        if not active:
            return {
                "schema": "jigaewol_ephemeral_universe_v1", "active": False,
                "breaker_count": len(breakers), "breaker_ids_sha256": _sha(breaker_ids),
                "activation_is_task_local_not_global_ritual": True,
                "materialization_requested": materialization_requested,
                "organogenesis_handoff": organogenesis_handoff,
            }

        # Two worlds carry all eighteen breakers without multiplying model calls by 18.
        # World 1 changes the ontology; World 2 attacks the remaining meta-assumptions.
        worlds = (
            {
                "world_id": "ephemeral_universe_pipeline",
                "mode": "axiom_breaking_superposition",
                "instruction": (
                    "Preserve the exact user destination. Temporarily treat the following 18 assumptions as revisable. "
                    "Do not turn them into factual claims; use them to invent a representation or route unavailable in the default ontology. "
                    + " | ".join(f"{x.breaker_id}: {x.replacement_rule}" for x in cls.AXIOM_BREAKERS)
                ),
                "purpose": "make the task-local universe itself a revisable working representation",
                "preserve_goal": True,
                "epistemic_state": "speculative_influence_allowed",
            },
            {
                "world_id": "below_choice_identity_totality",
                "mode": "meta_axiom_attack",
                "instruction": (
                    "Go one layer below the named mechanisms. Ask whether this solution still assumes a global choice function, "
                    "a probability measure, a decidable identity relation, total function composition, a clean causation/observation split, "
                    "or a constructible global whole. If one assumption silently closes the space, formulate a local/partial alternative and "
                    "carry its unresolved obstruction forward instead of normalizing it away."
                ),
                "purpose": "attack assumptions shared even by unusual architectures",
                "preserve_goal": True,
                "epistemic_state": "speculative_influence_allowed",
            },
        )
        return {
            "schema": "jigaewol_ephemeral_universe_v1",
            "active": True,
            "pipeline": pipeline,
            "breaker_count": len(breakers),
            "axiom_breakers": breakers,
            "breaker_ids_sha256": _sha(breaker_ids),
            "worlds": worlds,
            "world_count": len(worlds),
            "canonical_destination_may_be_represented_but_not_rewritten": True,
            "worlds_are_speculative_not_truth_claims": True,
            "worlds_collapse_after_turn_but_lineage_may_persist": True,
            "bounded_materialization_preserves_latency": True,
            "materialization_requested": materialization_requested,
            "organogenesis_handoff": organogenesis_handoff,
        }
