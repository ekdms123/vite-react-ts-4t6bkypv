from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from jigaewol_components.directive_semantics import actionable_marker_present


@dataclass(frozen=True)
class RecurrenceInvariant:
    invariant_id: str
    family: str
    statement: str
    trigger_excerpt: str
    created_at: float


class AntiRecurrenceEngine:
    """Turns repeated user complaints into durable behavioral invariants/golden cases."""

    PATTERNS = {
        "requirement_omission": ("빼먹", "몇개만", "몇 개만", "개무시", "누락"),
        "goal_shrink": ("의도 축소", "목표 축소", "축소하", "다운그레이드"),
        "fake_execution": ("실행한 척", "읽고 실행", "해본 척"),
        "verification_drift": ("검증 측", "검증으로", "검증 도구", "검증에 치우"),
        "shallow_search": ("겉핥기", "검색어 띨롱", "평범하게 검색", "커뮤니티"),
        "closed_strategy": ("닫힌 사고", "한계를 정", "처음부터 제외"),
        "promised_fix_carryover": ("위에서 고친다고", "전에 고친다고", "같이 고치", "같이 고쳐", "이전에 말했던 것도"),
        "generic_answer_drift": ("뻔한 대답", "뻔하게", "상투적", "generic answer", "generic response"),
        "runtime_bypass": ("zip을 거쳐", "zip 거쳐", "zip을 통과", "zip 통과", "zip을 고쳐", "zip 고쳐"),
        "runtime_install_drift": ("zip이 풀리고", "zip 풀리고", "왜 자꾸 zip", "매턴 zip", "zip 매턴"),
        "host_body_disconnect_recurrence": ("바디가 안 붙", "연결이 안 됐", "연결 부위", "또 연결", "body가 안", "도구가 없"),
        "model_ceiling_drift": ("모델 성능", "모델 능력", "모델 한계", "모델로 한계", "현재 모델", "성능으로 한계"),
        "multimodal_disconnect": ("이미지랑 연결", "이미지 도구", "음성 도구", "라이브에도", "live에도", "그림체", "스타일 상태"),
        "external_prefilter_drift": ("처음부터 제외", "외부는", "바이러스", "오픈소스", "플러그인", "깃허브 같은"),
        "caution_chatter_drift": ("경계는 알아서", "굳이 말", "안 궁금", "기분을 잡치", "쿨하게 다 말하지"),
        "reference_implementation_drift": (
            "레퍼런스랑", "안 닮", "1도 안 닮", "흔한 노션", "밤티",
            "자료만 가지고", "자료만 가져", "플러그인도 제대로", "깃허브도 안 써",
            "달력도 크게 안 보", "generic notion", "reference mismatch",
        ),
    }
    STATEMENTS = {
        "requirement_omission": "Atomic user requirements must be accounted for before release; no silent compression.",
        "goal_shrink": "Route failure must not rewrite or shrink the user's goal.",
        "fake_execution": "Documentation/static inspection must never be labeled as execution.",
        "verification_drift": "Verification is a bounded truth floor, not the primary optimization objective unless explicitly requested.",
        "shallow_search": "Open-ended research must diversify source families, vernacular, graph follow-ups, and observed-term requery when relevant.",
        "closed_strategy": "Unknown routes remain discoverable; inability of one route is not a global impossibility claim.",
        "promised_fix_carryover": "Previously identified or promised fixes must be explicitly carried into the next implementation pass, tested, or truthfully marked blocked; they may not silently disappear behind the newest request.",
        "generic_answer_drift": "When the user rejects generic output and asks for research/learning, fresh domain evidence must be gathered before release and the answer must surface concrete deltas rather than restating priors.",
        "runtime_bypass": "Every substantive user turn must enter through the current ZIP canonical ingress before downstream reasoning or external work; bypass is a release-blocking recurrence.",
        "runtime_install_drift": "Applying the current ZIP means verifying and reusing one stable canonical code root; extraction happens only when the artifact hash changes, and mutable state must remain in a separate stable state root.",
        "host_body_disconnect_recurrence": "Previously observed successful bodies remain durable revalidation candidates; a stale or partial host surface may not be rewritten as global body absence.",
        "model_ceiling_drift": "Current model identity, familiar prompting style, or current capability inventory may not be used as the ontology ceiling for problem solving.",
        "multimodal_disconnect": "Image, voice, live, browser, file and text actuators must receive the same objective/style/unfinished-state contract before dispatch when the modality supports it.",
        "external_prefilter_drift": "Benign external candidates remain discoverable by default; uncertainty changes the isolation/approval route, not the goal or candidate ontology.",
        "caution_chatter_drift": "Task work comes first; unsolicited meta commentary must not replace or delay it.",
        "reference_implementation_drift": "Reference-backed implementation must convert concrete reference geometry, hierarchy, typography, calendar prominence, imagery, and interaction into verified design/code/Notion actions. Collecting references alone is not implementation, and generic card-grid/AI-template defaults must not replace the observed reference language.",
    }

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(json.dumps({"version": 1, "invariants": []}, indent=2), encoding="utf-8")

    def observe(self, message: str) -> tuple[RecurrenceInvariant, ...]:
        text = str(message)
        low = text.casefold()
        data = json.loads(self.path.read_text(encoding="utf-8"))
        existing = {row["invariant_id"] for row in data.get("invariants", [])}
        added: list[RecurrenceInvariant] = []
        for family, markers in self.PATTERNS.items():
            if not actionable_marker_present(text, markers):
                continue
            statement = self.STATEMENTS[family]
            invariant_id = "inv_" + hashlib.sha256(f"{family}:{statement}".encode("utf-8")).hexdigest()[:16]
            if invariant_id in existing:
                continue
            row = RecurrenceInvariant(invariant_id, family, statement, text[:500], time.time())
            data.setdefault("invariants", []).append(asdict(row))
            existing.add(invariant_id)
            added.append(row)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)
        return tuple(added)

    def active(self) -> tuple[RecurrenceInvariant, ...]:
        data = json.loads(self.path.read_text(encoding="utf-8"))
        return tuple(RecurrenceInvariant(**row) for row in data.get("invariants", []))
