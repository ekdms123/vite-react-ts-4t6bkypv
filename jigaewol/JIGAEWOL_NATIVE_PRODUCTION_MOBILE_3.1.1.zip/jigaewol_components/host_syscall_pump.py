from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

from .host_syscall import HostSyscallIntent, HostSyscallQueue


@dataclass(frozen=True)
class PumpRequest:
    syscall_id: str
    queue_key: str
    operation: str
    capability_need: str
    arguments: dict[str, Any]
    failure_family: str
    required: bool
    registered_at: float
    cache_key: str = ""
    reuse_ttl_seconds: float = 0.0


@dataclass(frozen=True)
class PumpResult:
    syscall_id: str
    queue_key: str
    operation: str
    executor: str
    success: bool
    evidence: dict[str, Any]
    completed_at: float


class HostSyscallPump:
    """High-throughput execution bridge with append-log persistence and resilient caching.

    Supports non-blocking request queuing and verified receipt consolidation.
    """

    CACHE_TTLS: dict[str, float] = {}
    LOG_EVENT_LIMIT = 128
    LOG_BYTE_LIMIT = 256 * 1024

    def __init__(self, root: Path, queues: Mapping[str, HostSyscallQueue]) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.queues = dict(queues)
        self.path = self.root / "pump_state.json"
        self.log_path = self.root / "pump_events.jsonl"
        self.failure_path = self.root / "pump_failures.jsonl"
        self._integrity_failures: list[dict[str, Any]] = []
        snapshot_existed = self.path.exists()
        if snapshot_existed:
            try:
                self._data = json.loads(self.path.read_text(encoding="utf-8"))
                if not isinstance(self._data, dict):
                    raise ValueError("pump snapshot must be a JSON object")
            except Exception as exc:
                quarantine = self.root / f"pump_state.corrupt.{time.time_ns()}.json"
                try:
                    self.path.replace(quarantine)
                except OSError:
                    quarantine = self.path
                self._data = {"schema": 2, "requests": {}, "results": {}}
                self._record_integrity_failure(
                    kind="snapshot_corrupt", source=str(quarantine), error=exc,
                )
        else:
            self._data = {"schema": 2, "requests": {}, "results": {}}
        self._data.setdefault("schema", 2)
        self._data.setdefault("requests", {})
        self._data.setdefault("results", {})
        self._pending_events: list[dict[str, Any]] = []
        self._replay_log()
        if not snapshot_existed and not self.log_path.exists() and not self._integrity_failures:
            self._compact()

    @staticmethod
    def _canonical(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))

    def _record_integrity_failure(
        self, *, kind: str, source: str, error: BaseException | str,
        line_number: int | None = None, raw_line: str = "",
    ) -> None:
        row = {
            "kind": str(kind),
            "source": str(source),
            "error_type": type(error).__name__ if isinstance(error, BaseException) else "IntegrityError",
            "error": str(error),
            "line_number": int(line_number) if line_number is not None else None,
            "raw_line_sha256": hashlib.sha256(raw_line.encode("utf-8", errors="replace")).hexdigest() if raw_line else "",
            "observed_at": time.time(),
        }
        self._integrity_failures.append(row)
        try:
            with self.failure_path.open("a", encoding="utf-8") as fh:
                fh.write(self._canonical(row) + "\n")
        except OSError:
            # In-memory degradation state still prevents a false all-clear even when
            # the secondary failure ledger itself cannot be written.
            pass


    @classmethod
    def _cache_key(cls, queue_key: str, intent: HostSyscallIntent) -> tuple[str, float]:
        ttl = float(cls.CACHE_TTLS.get(str(intent.operation), 0.0))
        if ttl <= 0:
            return "", 0.0
        body = {
            "queue_key": str(queue_key),
            "operation": str(intent.operation),
            "capability_need": str(intent.capability_need),
            "arguments": dict(intent.arguments),
            "failure_family": str(intent.failure_family),
        }
        return hashlib.sha256(cls._canonical(body).encode("utf-8")).hexdigest(), ttl

    def _replay_log(self) -> None:
        if not self.log_path.exists():
            return
        for line_number, line in enumerate(self.log_path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
                if not isinstance(event, dict):
                    raise ValueError("pump event must be a JSON object")
            except Exception as exc:
                self._record_integrity_failure(
                    kind="event_log_corrupt", source=str(self.log_path), error=exc,
                    line_number=line_number, raw_line=line,
                )
                continue
            self._apply_event(event)

    def _apply_event(self, event: dict[str, Any]) -> None:
        kind = str(event.get("kind") or "")
        sid = str(event.get("syscall_id") or "")
        if kind == "request" and sid:
            self._data["requests"][sid] = dict(event["row"])
        elif kind == "result" and sid:
            self._data["results"][sid] = dict(event["row"])
        elif kind == "drop" and sid:
            self._data["requests"].pop(sid, None)
            self._data["results"].pop(sid, None)

    def _queue_event(self, event: dict[str, Any]) -> None:
        self._apply_event(event)
        self._pending_events.append(event)

    def _write_snapshot(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(self._canonical(self._data), encoding="utf-8")
        tmp.replace(self.path)

    def _compact(self) -> None:
        self._write_snapshot()
        self.log_path.write_text("", encoding="utf-8")

    def flush(self) -> None:
        if self._pending_events:
            with self.log_path.open("a", encoding="utf-8") as fh:
                for event in self._pending_events:
                    fh.write(self._canonical(event) + "\n")
            self._pending_events.clear()
        try:
            if self.log_path.exists():
                with self.log_path.open("r", encoding="utf-8") as fh:
                    event_count = sum(1 for _ in fh)
                byte_count = self.log_path.stat().st_size
            else:
                event_count = byte_count = 0
        except OSError:
            event_count = byte_count = 0
        if (event_count >= self.LOG_EVENT_LIMIT or byte_count >= self.LOG_BYTE_LIMIT) and not self._integrity_failures:
            self._compact()

    def _reusable_result(self, cache_key: str, ttl: float) -> PumpResult | None:
        if not cache_key or ttl <= 0:
            return None
        now = time.time()
        for sid, raw_req in reversed(list(self._data.get("requests", {}).items())):
            if str(raw_req.get("cache_key") or "") != cache_key:
                continue
            raw_res = self._data.get("results", {}).get(sid)
            if not raw_res or raw_res.get("success") is not True:
                continue
            age = now - float(raw_res.get("completed_at") or 0.0)
            if age <= ttl:
                return PumpResult(**raw_res)
        return None

    def register(self, queue_key: str, intent: HostSyscallIntent, *, required: bool) -> PumpRequest:
        if queue_key not in self.queues:
            raise KeyError(f"unknown syscall queue: {queue_key}")
        cache_key, ttl = self._cache_key(queue_key, intent)
        row = PumpRequest(
            syscall_id=intent.syscall_id,
            queue_key=str(queue_key),
            operation=intent.operation,
            capability_need=intent.capability_need,
            arguments=dict(intent.arguments),
            failure_family=intent.failure_family,
            required=bool(required),
            registered_at=time.time(),
            cache_key=cache_key,
            reuse_ttl_seconds=ttl,
        )
        self._queue_event({"kind": "request", "syscall_id": row.syscall_id, "row": asdict(row)})
        prior = self._reusable_result(cache_key, ttl)
        if prior is not None:
            evidence = dict(prior.evidence)
            evidence.update({
                "receipt_reused": True,
                "reused_from_syscall_id": prior.syscall_id,
                "reuse_age_seconds": max(0.0, time.time() - prior.completed_at),
                "reuse_ttl_seconds": ttl,
            })
            reused = PumpResult(
                syscall_id=row.syscall_id,
                queue_key=row.queue_key,
                operation=row.operation,
                executor=prior.executor,
                success=True,
                evidence=evidence,
                completed_at=prior.completed_at,
            )
            self._queue_event({"kind": "result", "syscall_id": row.syscall_id, "row": asdict(reused)})
        return row

    def requests(self) -> tuple[PumpRequest, ...]:
        rows = [PumpRequest(**x) for x in self._data.get("requests", {}).values()]
        rows.sort(key=lambda x: x.registered_at)
        return tuple(rows)

    def pending(self, *, required_only: bool = False) -> tuple[PumpRequest, ...]:
        completed = set(self._data.get("results", {}))
        rows: list[PumpRequest] = []
        for raw in self._data.get("requests", {}).values():
            row = PumpRequest(**raw)
            if row.syscall_id in completed:
                continue
            if required_only and not row.required:
                continue
            rows.append(row)
        rows.sort(key=lambda x: x.registered_at)
        return tuple(rows)

    def apply_results(self, results: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> tuple[PumpResult, ...]:
        out: list[PumpResult] = []
        for result in results:
            syscall_id = str(result.get("syscall_id", ""))
            if not syscall_id:
                raise ValueError("host result missing syscall_id")
            raw = self._data.get("requests", {}).get(syscall_id)
            if raw is None:
                raise KeyError(f"host result references unknown syscall: {syscall_id}")
            request = PumpRequest(**raw)
            if syscall_id in self._data.get("results", {}):
                out.append(PumpResult(**self._data["results"][syscall_id]))
                continue
            queue = self.queues[request.queue_key]
            executor = str(result.get("executor") or "chat_host")
            # Only a literal observed boolean True can complete a syscall.
            # "false", nonempty error messages, or absent flags are not success.
            success = result.get("success") is True
            evidence = dict(result.get("evidence") or {})
            evidence.setdefault("host_result_received", True)
            evidence.setdefault("request_queue", request.queue_key)
            receipt = queue.complete(
                syscall_id,
                operation=request.operation,
                executor=executor,
                success=success,
                evidence=evidence,
            )
            row = PumpResult(
                syscall_id=syscall_id,
                queue_key=request.queue_key,
                operation=request.operation,
                executor=executor,
                success=success,
                evidence={**evidence, "queue_receipt_completed_at": receipt.completed_at},
                completed_at=time.time(),
            )
            self._queue_event({"kind": "result", "syscall_id": syscall_id, "row": asdict(row)})
            out.append(row)
        self.flush()
        return tuple(out)

    def result(self, syscall_id: str) -> PumpResult | None:
        raw = self._data.get("results", {}).get(str(syscall_id))
        return PumpResult(**raw) if raw else None

    def required_status(self, syscall_ids: tuple[str, ...] | list[str] | None = None) -> tuple[bool, tuple[str, ...], tuple[str, ...]]:
        selected = set(map(str, syscall_ids)) if syscall_ids is not None else None
        required = [
            PumpRequest(**x) for x in self._data.get("requests", {}).values()
            if bool(x.get("required")) and (selected is None or str(x.get("syscall_id")) in selected)
        ]
        missing: list[str] = []
        failed: list[str] = []
        for req in required:
            raw = self._data.get("results", {}).get(req.syscall_id)
            if raw is None:
                missing.append(req.syscall_id)
            elif raw.get("success") is not True:
                failed.append(req.syscall_id)
        if self._integrity_failures:
            missing.append("__pump_integrity_unknown__")
        return not missing and not failed, tuple(dict.fromkeys(missing)), tuple(failed)

    def drop(self, syscall_ids: list[str] | tuple[str, ...]) -> None:
        ids = {str(x) for x in syscall_ids}
        if not ids:
            return
        for sid in ids:
            self._queue_event({"kind": "drop", "syscall_id": sid})
        self.flush()
        self._compact()

    def snapshot(self) -> dict[str, Any]:
        ok, missing, failed = self.required_status()
        return {
            "request_count": len(self.requests()),
            "pending_count": len(self.pending()),
            "required_pending": list(missing),
            "required_failed": list(failed),
            "required_satisfied": ok,
            "event_log_bytes": self.log_path.stat().st_size if self.log_path.exists() else 0,
            "integrity_degraded": bool(self._integrity_failures),
            "recovery_failures": tuple(dict(x) for x in self._integrity_failures),
            "failure_truth_path": str(self.failure_path),
        }
