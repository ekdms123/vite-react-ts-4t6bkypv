from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Mapping


def _sha(value: Any) -> str:
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),default=str)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


ARTIFACT_KINDS={
    'document':('state:write_artifact',),
    'spreadsheet':('state:write_artifact',),
    'slides':('state:write_artifact',),
    'pdf':('state:write_artifact',),
    'image':('state:write_artifact',),
    'design':('design:artifact_generate','state:write_artifact'),
    'diagram':('design:reference_deconstruct','state:write_artifact'),
    'app':('compute:exec','state:write_artifact'),
    'deployed_app':('compute:exec','state:write_artifact','deploy:artifact'),
    'code_patch':('compute:exec','state:write_artifact'),
}


@dataclass(frozen=True)
class ArtifactPlan:
    kind: str
    required_capabilities: tuple[str,...]
    proof_rule: str


@dataclass(frozen=True)
class ArtifactReceipt:
    artifact_id: str
    kind: str
    producer_id: str
    operation: str
    state: str
    artifact_refs: tuple[str,...]
    editable: bool
    deployed: bool
    evidence_refs: tuple[str,...]
    metadata: dict[str,Any]
    created_at: float
    updated_at: float


class ArtifactExecutionRegistry:
    """Common truth contract for files, designs, apps, and deployed artifacts."""

    FORMAT='jigaewol_artifact_execution_v1'
    STATES=('created','verified','deployed','published')

    def __init__(self, root: str | Path) -> None:
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'artifacts.json'
        if not self.path.exists(): self._write({'format':self.FORMAT,'artifacts':{}})

    def _read(self):
        data=json.loads(self.path.read_text(encoding='utf-8'))
        if data.get('format')!=self.FORMAT: raise ValueError('artifact registry format mismatch')
        data.setdefault('artifacts',{}); return data

    def _write(self,data):
        tmp=self.path.with_suffix('.tmp'); tmp.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8'); tmp.replace(self.path)

    @staticmethod
    def plan(kind: str) -> ArtifactPlan:
        kind=str(kind).strip().casefold()
        if kind not in ARTIFACT_KINDS: raise KeyError(kind)
        return ArtifactPlan(kind,ARTIFACT_KINDS[kind],'created needs a concrete artifact ref; verified/deployed/published additionally need observed evidence refs')

    def record_created(self, *, kind: str, producer_id: str, operation: str, artifact_refs: Iterable[str], evidence_refs: Iterable[str], editable: bool=False, metadata: Mapping[str,Any] | None=None) -> ArtifactReceipt:
        self.plan(kind)
        refs=tuple(dict.fromkeys(str(x) for x in artifact_refs if str(x).strip()))
        evidence=tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x).strip()))
        if not refs: raise ValueError('artifact creation requires at least one concrete artifact ref')
        if not evidence: raise ValueError('artifact creation requires observed execution evidence')
        seed={'kind':kind,'producer_id':producer_id,'operation':operation,'refs':refs}
        aid='artifact_'+_sha(seed)[:20]; now=time.time()
        row=ArtifactReceipt(aid,str(kind),str(producer_id),str(operation),'created',refs,bool(editable),False,evidence,dict(metadata or {}),now,now)
        data=self._read(); old=data['artifacts'].get(aid)
        if old: row=replace(row,created_at=float(old.get('created_at') or now))
        data['artifacts'][aid]=asdict(row); self._write(data); return row

    def get(self, artifact_id: str) -> ArtifactReceipt:
        raw=self._read()['artifacts'].get(str(artifact_id))
        if raw is None: raise KeyError(artifact_id)
        row=dict(raw)
        row['artifact_refs']=tuple(row.get('artifact_refs') or ())
        row['evidence_refs']=tuple(row.get('evidence_refs') or ())
        row['metadata']=dict(row.get('metadata') or {})
        return ArtifactReceipt(**row)

    def promote(self, artifact_id: str, *, state: str, evidence_refs: Iterable[str], metadata: Mapping[str,Any] | None=None) -> ArtifactReceipt:
        state=str(state)
        if state not in {'verified','deployed','published'}: raise ValueError('promotion state must be verified/deployed/published')
        current=self.get(artifact_id)
        refs=tuple(dict.fromkeys((*current.evidence_refs,*(str(x) for x in evidence_refs if str(x).strip()))))
        if len(refs)<=len(current.evidence_refs): raise ValueError('artifact promotion requires new observed evidence')
        row=replace(current,state=state,deployed=current.deployed or state in {'deployed','published'},evidence_refs=refs,metadata={**current.metadata,**dict(metadata or {})},updated_at=time.time())
        data=self._read(); data['artifacts'][artifact_id]=asdict(row); self._write(data); return row

    def ingest_host_result(self, *, kind: str, producer_id: str, operation: str, success: bool, artifact_refs: Iterable[str], evidence_refs: Iterable[str], editable: bool=False, metadata: Mapping[str,Any] | None=None) -> ArtifactReceipt | None:
        if success is not True: return None
        return self.record_created(kind=kind,producer_id=producer_id,operation=operation,artifact_refs=artifact_refs,evidence_refs=evidence_refs,editable=editable,metadata=metadata)
