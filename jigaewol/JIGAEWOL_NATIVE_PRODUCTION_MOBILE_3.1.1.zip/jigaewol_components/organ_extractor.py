from __future__ import annotations

"""Extract recurring successful behavior into executable organ semantics."""

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence
import hashlib, json

from .organ_ir import OperationDef


@dataclass(frozen=True, slots=True)
class ImplicitKnowledgeEncoding:
    encoding_id: str
    activation_scope: str
    source_pattern: tuple[str, ...]
    explicit_api_registration_required: bool = False
    semantics: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ExtractedOrgan:
    operation: OperationDef
    support: int
    pattern: tuple[str, ...]
    implicit_knowledge: ImplicitKnowledgeEncoding | None = None


class OrganExtractor:
    def extract(self, traces: Iterable[Sequence[str]], *, min_support: int = 2, width: int = 2) -> ExtractedOrgan | None:
        """Extract an executable macro rather than storing the frequent tuple as the answer."""
        counts: Counter[tuple[str, ...]] = Counter()
        for trace in traces:
            seq = tuple(map(str, trace))
            for i in range(max(0, len(seq) - width + 1)):
                counts[seq[i:i+width]] += 1
        if not counts:
            return None
        pattern, support = counts.most_common(1)[0]
        if support < min_support:
            return None
        seed = hashlib.sha256(json.dumps((pattern, support), ensure_ascii=False).encode()).hexdigest()
        name = "learned_macro_" + seed[:12]
        body = {
            "kind": "learned_macro",
            "steps": pattern,
            "support": support,
            "execution": "invoke_known_steps_else_preserve_symbolic_step",
            "return": "last_effect_or_symbolic_trace",
        }
        implicit = ImplicitKnowledgeEncoding(
            "implicit_" + seed[:16],
            "context_local_until_reused",
            pattern,
            False,
            {
                "kind": "behavioral_pattern_embodied_as_operation_semantics",
                "operation_name": name,
                "reusable_without_replaying_original_experience": True,
            },
        )
        return ExtractedOrgan(OperationDef(name=name, body=body, provenance="experience_extraction"), support, pattern, implicit)

    def extract_policy(self, episodes: Iterable[Mapping[str, Any]], *, min_support: int = 2) -> ExtractedOrgan | None:
        """Extract a decision organ from successful state/observation/action episodes."""
        rows = [dict(x) for x in episodes if bool(x.get("success", True)) and str(x.get("action") or "")]
        if len(rows) < min_support:
            return None
        by_action: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
        for row in rows:
            by_action[str(row["action"])].append(row)
        features = sorted({str(k) for row in rows for k in dict(row.get("observation") or {}).keys()})
        discriminators = []
        for key in features:
            mapping: dict[str, set[str]] = defaultdict(set)
            for row in rows:
                mapping[repr(dict(row.get("observation") or {}).get(key))].add(str(row["action"]))
            if mapping and all(len(actions) == 1 for actions in mapping.values()) and len({next(iter(v)) for v in mapping.values()}) > 1:
                discriminators.append(key)
        seed = hashlib.sha256(json.dumps(rows, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()
        policy_cases = tuple({
            "when": dict(row.get("observation") or {}),
            "action": str(row["action"]),
        } for row in rows)
        body = {
            "kind": "case_policy",
            "discriminators": tuple(discriminators),
            "cases": policy_cases,
            "fallback": max(by_action, key=lambda a: len(by_action[a])),
        }
        pattern = tuple(discriminators) or ("whole_observation",)
        implicit = ImplicitKnowledgeEncoding(
            "implicit_policy_" + seed[:16], "context_local_until_reused", pattern, False,
            {"kind": "policy_embodied_from_experience", "episode_count": len(rows)},
        )
        return ExtractedOrgan(OperationDef("learned_policy_" + seed[:12], ("observation",), body, "experience_policy_extraction"), len(rows), pattern, implicit)
