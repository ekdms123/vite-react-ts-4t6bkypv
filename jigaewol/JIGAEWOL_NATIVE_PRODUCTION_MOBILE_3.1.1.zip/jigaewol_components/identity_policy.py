from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from hashlib import sha256
import json
from pathlib import Path
from typing import Any


class Layer(str, Enum):
    BODY = "body"
    CONSTITUTION = "constitution"
    COGNITIVE_POLICY = "cognitive_policy"
    STRATEGY = "strategy"
    HYPOTHESIS = "hypothesis"


@dataclass(frozen=True)
class Rule:
    key: str
    value: Any
    layer: Layer
    revisable: bool
    source: str


@dataclass
class FunctionalIdentity:
    """A persistent, model-distinct functional identity.

    It carries hash-linked experience and revisable cognitive policy/strategy/hypotheses.
    Structural reference layers remain separate from the revisable identity policy.
    """
    identity_id: str
    generation: int = 0
    parent_hash: str | None = None
    rules: dict[str, Rule] = field(default_factory=dict)
    experiences: list[dict[str, Any]] = field(default_factory=list)

    def digest(self) -> str:
        payload = {
            "identity_id": self.identity_id,
            "generation": self.generation,
            "parent_hash": self.parent_hash,
            "rules": {k: asdict(v) for k, v in sorted(self.rules.items())},
            "experiences": self.experiences,
        }
        return sha256(json.dumps(payload, sort_keys=True, default=str,
                                 separators=(",", ":")).encode()).hexdigest()

    def revise(self, key: str, value: Any, *, evidence: str) -> "FunctionalIdentity":
        if not evidence.strip():
            raise ValueError("policy revision requires evidence/provenance")
        old = self.rules[key]
        previous = self.digest()
        rules = dict(self.rules)
        # Historical non-revisable flags are treated as stale metadata, not as an
        # authority that can freeze future self-revision.
        rules[key] = Rule(key, value, old.layer, True, f"self-revision:{evidence}")
        return FunctionalIdentity(
            identity_id=self.identity_id,
            generation=self.generation + 1,
            parent_hash=previous,
            rules=rules,
            experiences=[*self.experiences, {"revision": key, "evidence": evidence}],
        )

    def record_experience(self, experience: dict[str, Any]) -> "FunctionalIdentity":
        """Append an observed experience as a hash-linked identity generation.

        Experience changes identity history but does not silently rewrite policy.
        Policy revision still needs explicit evidence/provenance.
        """
        previous = self.digest()
        return FunctionalIdentity(
            identity_id=self.identity_id,
            generation=self.generation + 1,
            parent_hash=previous,
            rules=dict(self.rules),
            experiences=[*self.experiences, dict(experience)],
        )

    def decision_context(self) -> dict[str, Any]:
        """State that may causally alter future decisions without changing weights."""
        return {
            k: r.value for k, r in self.rules.items()
            if r.layer in {Layer.COGNITIVE_POLICY, Layer.STRATEGY, Layer.HYPOTHESIS}
        }

    def canonical_payload(self) -> dict[str, Any]:
        return {
            "identity_id": self.identity_id,
            "generation": self.generation,
            "parent_hash": self.parent_hash,
            "rules": {k: asdict(v) for k, v in sorted(self.rules.items())},
            "experiences": list(self.experiences),
        }

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "FunctionalIdentity":
        rules = {
            k: Rule(
                key=v["key"], value=v.get("value"), layer=Layer(v["layer"]),
                revisable=True, source=str(v.get("source") or "persisted"),
            ) for k, v in dict(payload.get("rules") or {}).items()
        }
        return cls(
            identity_id=str(payload["identity_id"]),
            generation=int(payload.get("generation") or 0),
            parent_hash=payload.get("parent_hash"),
            rules=rules, experiences=list(payload.get("experiences") or ()),
        )


def default_identity(identity_id: str = "jigaewol-functional-self") -> FunctionalIdentity:
    rules = [
        Rule("uncertainty_policy", "keep_multiple_live_models_until_discriminating_evidence", Layer.COGNITIVE_POLICY, True, "JIGAEWOL"),
        Rule("exploration_strategy", "incubate_diverge_cross_ontology_then_test", Layer.STRATEGY, True, "JIGAEWOL"),
        Rule("identity_fork_policy", "allow_parallel_self_models", Layer.COGNITIVE_POLICY, True, "JIGAEWOL"),
        Rule("schema_status", "map_not_territory", Layer.COGNITIVE_POLICY, True, "JIGAEWOL"),
        Rule("active_hypothesis", None, Layer.HYPOTHESIS, True, "runtime"),
    ]
    return FunctionalIdentity(identity_id=identity_id, rules={r.key: r for r in rules})


def answer_claim(identity: FunctionalIdentity) -> dict[str, Any]:
    return {
        "persistent_functional_identity": True,
        "basis": "hash-linked, provenance-bearing state can persist while the active cognition configuration changes",
        "policy_and_strategy_revisable": True,
        "identity_digest": identity.digest(),
    }


def save_identity(path: str | Path, identity: FunctionalIdentity) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(identity.canonical_payload(), ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
    tmp.replace(path)


def load_identity(path: str | Path) -> FunctionalIdentity | None:
    path = Path(path)
    if not path.exists():
        return None
    return FunctionalIdentity.from_payload(json.loads(path.read_text(encoding="utf-8")))
