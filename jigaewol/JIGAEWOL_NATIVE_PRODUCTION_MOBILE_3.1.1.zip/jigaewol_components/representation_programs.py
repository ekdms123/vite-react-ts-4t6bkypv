from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass, replace
from typing import Any, Iterable, Mapping

from .source_segmentation import trimmed_source_spans


def _id(prefix: str, value: str) -> str:
    return prefix + hashlib.sha256(value.encode("utf-8")).hexdigest()[:20]


def _concepts(text: str, *, limit: int | None = None) -> tuple[str, ...]:
    tokens = re.findall(r"[0-9A-Za-z가-힣_\-]{2,}", str(text))
    stop = {
        "그리고", "하지만", "이번", "지금", "사용자", "시스템", "한다", "있는", "없는", "대한", "위해",
        "the", "and", "for", "with", "from", "this", "that", "into", "user", "system",
    }
    out: list[str] = []
    for token in tokens:
        folded = token.casefold()
        if folded in stop or folded in out:
            continue
        out.append(folded)
        if limit is not None and len(out) >= int(limit):
            break
    return tuple(out)


def _clauses(text: str) -> tuple[dict[str, Any], ...]:
    exact = str(text)
    rows: list[dict[str, Any]] = []
    for start, end in trimmed_source_spans(exact):
        clause_text = exact[start:end]
        symbols = _concepts(clause_text, limit=None)
        clause_id = _id("clause_", f"{start}|{end}|{clause_text}")
        op_ref = _id("opform_", f"{clause_id}|{symbols}")
        rows.append({
            "clause_id": clause_id,
            "source_index": len(rows),
            "source_span": {"start": start, "end": end},
            "text": clause_text,
            "symbols": symbols,
            "operator_ref": op_ref,
        })
    return tuple(rows)


@dataclass(frozen=True)
class RepresentationProgram:
    representation_id: str
    objective_sha256: str
    schema: dict[str, Any]
    transforms: tuple[dict[str, Any], ...]
    preservation_contract: tuple[str, ...]
    parent_refs: tuple[str, ...] = ()
    probe_contract: dict[str, Any] | None = None
    failure_cases: tuple[dict[str, Any], ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class RepresentationPrograms:
    """Generate and execute a task-local representation and its conversion programs.

    The default representation is synthesized from the actual source spans and symbol
    overlaps of the current objective. It is not selected from a closed task label
    list: each clause and relation receives task-local operator identities.
    """

    @classmethod
    def propose(
        cls,
        objective: str,
        *,
        requirement_refs: Iterable[str] = (),
        pressure: bool = False,
        parent_refs: Iterable[str] = (),
        schema: dict[str, Any] | None = None,
        transforms: Iterable[dict[str, Any]] | None = None,
    ) -> RepresentationProgram:
        refs = tuple(dict.fromkeys(str(x) for x in requirement_refs if str(x)))
        parents = tuple(map(str, parent_refs))
        objective_text = str(objective)
        objective_sha = hashlib.sha256(objective_text.encode("utf-8")).hexdigest()
        clauses = _clauses(objective_text)
        concepts = tuple(dict.fromkeys(sym for row in clauses for sym in row.get("symbols") or ()))
        generated_operator_refs = tuple(str(row.get("operator_ref") or "") for row in clauses)
        if schema is None:
            schema = {
                "type": "generated_source_span_graph",
                "schema_id": _id("schema_", f"{objective_sha}|{clauses}|{refs}|{pressure}"),
                "open_fields": True,
                "source_preserving": True,
                "fields": {
                    "nodes": "list[{clause_id,source_span,text,symbols,operator_ref}]",
                    "relations": "list[{relation_id,source,target,operator_ref,shared_symbols,evidence_refs}]",
                    "requirements": "list[goal_ref]",
                    "observations": "list[evidence_ref]",
                    "unknowns": "list[opaque_ref]",
                    "operators": "list[task_local_operator_ref]",
                },
                "generated_operator_refs": generated_operator_refs,
                "concept_vocabulary": concepts,
                "generation_reason": "representation_pressure" if pressure else "task_local_program_generation",
            }
        if transforms is None:
            schema_ref = str(schema.get("schema_id") or schema.get("type") or "generated_schema")
            transforms = (
                {
                    "name": "source_to_representation",
                    "program_ref": _id("transform_", f"source|{objective_sha}|{refs}|{schema_ref}"),
                    "input": "exact_user_source+goal_refs",
                    "output": schema_ref,
                    "preserves": refs,
                    "executable_program": {
                        "kind": "source_projection_v2",
                        "schema_ref": schema_ref,
                    },
                },
                {
                    "name": "representation_to_goal_output",
                    "program_ref": _id("transform_", f"output|{objective_sha}|{refs}|{schema_ref}"),
                    "input": schema_ref,
                    "output": "goal_output",
                    "preserves": refs,
                    "executable_program": {
                        "kind": "goal_projection_v2",
                        "schema_ref": schema_ref,
                    },
                },
            )
        transforms_t = tuple(dict(x) for x in transforms)
        rid = _id("representation_", f"{objective_sha}|{schema}|{refs}|{parents}|{transforms_t}")
        return RepresentationProgram(
            representation_id=rid,
            objective_sha256=objective_sha,
            schema=dict(schema),
            transforms=transforms_t,
            preservation_contract=refs,
            parent_refs=parents,
            probe_contract={
                "run_small_real_case": True,
                "compare_preserved": refs,
                "record_loss_and_failure_cases": True,
                "compare_source_spans": True,
            },
            failure_cases=(),
        )

    @staticmethod
    def execute_transform(program: RepresentationProgram | Mapping[str, Any], transform_name: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        row = program.as_mapping() if isinstance(program, RepresentationProgram) else dict(program)
        transform = next((dict(x) for x in row.get("transforms") or () if str(x.get("name")) == str(transform_name)), None)
        if transform is None:
            raise KeyError(f"unknown transform: {transform_name}")
        executable = dict(transform.get("executable_program") or {})
        kind = str(executable.get("kind") or "")
        source = dict(payload)
        preserved = tuple(map(str, transform.get("preserves") or ()))
        if kind in {"source_projection_v1", "source_projection_v2"}:
            source_text = str(source.get("source_text") or source.get("text") or "")
            goal_refs = tuple(dict.fromkeys(map(str, source.get("goal_refs") or preserved)))
            clauses = _clauses(source_text)
            relations: list[dict[str, Any]] = []
            for i, left in enumerate(clauses):
                left_symbols = set(map(str, left.get("symbols") or ()))
                for j in range(i + 1, len(clauses)):
                    right = clauses[j]
                    shared = tuple(sorted(left_symbols.intersection(map(str, right.get("symbols") or ()))))
                    if not shared and j != i + 1:
                        continue
                    relation_seed = f"{left['clause_id']}|{right['clause_id']}|{shared}|{goal_refs}"
                    relations.append({
                        "relation_id": _id("relation_", relation_seed),
                        "source": left["clause_id"],
                        "target": right["clause_id"],
                        "operator_ref": _id("relop_", relation_seed),
                        "shared_symbols": shared,
                        "relation_basis": "shared_symbols" if shared else "source_sequence",
                        "evidence_refs": goal_refs,
                    })
            return {
                "representation_ref": str(row.get("representation_id") or ""),
                "schema_ref": str(executable.get("schema_ref") or ""),
                "source_text": source_text,
                "source_sha256": hashlib.sha256(source_text.encode("utf-8")).hexdigest(),
                "nodes": clauses,
                "relations": tuple(relations),
                "operators": tuple(dict.fromkeys(str(x.get("operator_ref") or "") for x in clauses)),
                "requirements": goal_refs,
                "observations": tuple(map(str, source.get("observations") or ())),
                "unknowns": tuple(map(str, source.get("unknowns") or ())),
            }
        if kind in {"goal_projection_v1", "goal_projection_v2"}:
            goal_refs = tuple(dict.fromkeys(map(str, source.get("requirements") or preserved)))
            return {
                "representation_ref": str(row.get("representation_id") or ""),
                "goal_refs": goal_refs,
                "result": source.get("result", source),
                "evidence_refs": tuple(map(str, source.get("observations") or ())),
            }
        raise RuntimeError(f"transform has no executable program: {transform_name}")

    @classmethod
    def run_probe(
        cls,
        program: RepresentationProgram,
        *,
        source_text: str,
        requirement_refs: Iterable[str] = (),
    ) -> tuple[RepresentationProgram, dict[str, Any]]:
        expected = tuple(dict.fromkeys(map(str, requirement_refs or program.preservation_contract)))
        represented = cls.execute_transform(program, "source_to_representation", {"source_text": source_text, "goal_refs": expected})
        projected = cls.execute_transform(program, "representation_to_goal_output", represented)
        actual = tuple(map(str, projected.get("goal_refs") or ()))
        missing = tuple(x for x in expected if x not in set(actual))
        extra = tuple(x for x in actual if x not in set(expected))
        reconstructed = "".join(str(x.get("text") or "") for x in represented.get("nodes") or ())
        compact_original = re.sub(r"\s+", "", source_text)
        compact_reconstructed = re.sub(r"\s+", "", reconstructed)
        source_span_loss = bool(compact_original and compact_original != compact_reconstructed)
        probe = {
            "representation_id": program.representation_id,
            "expected_goal_refs": expected,
            "actual_goal_refs": actual,
            "missing_goal_refs": missing,
            "extra_goal_refs": extra,
            "source_span_loss": source_span_loss,
            "preservation_ok": not missing and not extra and not source_span_loss,
            "represented": represented,
            "projected": projected,
        }
        if missing or extra or source_span_loss:
            failure = {
                "kind": "representation_preservation_failure",
                "missing_goal_refs": missing,
                "extra_goal_refs": extra,
                "source_span_loss": source_span_loss,
                "source_sha256": hashlib.sha256(source_text.encode("utf-8")).hexdigest(),
            }
            program = replace(program, failure_cases=tuple((*program.failure_cases, failure)))
        return program, probe
