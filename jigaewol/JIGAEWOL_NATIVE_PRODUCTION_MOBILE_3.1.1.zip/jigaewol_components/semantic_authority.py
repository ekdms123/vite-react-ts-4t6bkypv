from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .directive_invariant import DirectiveInvariantError, verify_atom_conservation, verify_destination
from .intent_deep_analyzer import IntentDeepAnalysis, IntentDeepAnalyzer
from .microclosure import MicroClosureAuditor
from .requirement_contract import RequirementContract, RequirementCompiler
from .proof_carrying_improvement import ProofCarryingImprovementProtocol
from .discourse_scope import DiscourseScopeAnalyzer
from .authority_consolidation import AuthorityConsolidation, ExactUserSource, requested_mode, capability_prohibited
from .privacy_minimization import PrivacyMinimizationPolicy
from .source_directive_compiler import ClauseGraph, SourceDirectiveCompiler, explicit_request_present, quote_adoption_requested
from .search_swarm_policy import SearchSwarmPolicy
from jigaewol_runtime.capabilities.execution_routes import infer_required_traits


_ARITH = re.compile(r"^\s*-?\d+(?:\.\d+)?\s*[+\-*/]\s*-?\d+(?:\.\d+)?\s*(?:=|\?|？|은|는)?\s*$")

# Compatibility-only outcome projection.  These regexes do not participate in source
# authority.  The authoritative representation is the clause graph; this adapter only
# preserves legacy downstream labels until those consumers migrate to open effects.
_BUILD_EFFECT_RE = re.compile(r"(?:만들|제작|구축|구현|build|create|scaffold|implement)", re.IGNORECASE)
_SCHEDULE_EFFECT_RE = re.compile(r"(?:일정|스케줄|캘린더|리마인|schedule|calendar|remind)", re.IGNORECASE)
_PRESENCE_EFFECT_RE = re.compile(r"(?:팔로워|구독자|조회수|도달|인게이지|audience|followers|subscribers|engagement)", re.IGNORECASE)
_COLLECTION_EFFECT_RE = re.compile(r"(?:수집|스크랩|크롤|말뭉치|데이터셋|collect|scrape|crawl|corpus|dataset)", re.IGNORECASE)


def _explicit_execution_permission(text: str) -> bool:
    """Require an affirmative execution speech act, not mere execution-related prose."""
    raw = str(text or "")
    # Implementation, repair and testing include their necessary local execution.
    # This is source intent, not a requirement to recite one magic execution verb.
    # Explicit prohibitions remain capability-specific authority at dispatch.
    if explicit_request_present(raw) and not capability_prohibited(raw, ("실행", "구동", "run", "execute")):
        if re.search(r"(?:구현|개발|고쳐|수정|디버그|테스트|시험|돌려|계속|이어서|이어\s*해|implement|develop|fix|debug|test|continue)",raw,re.I):
            return True
    if explicit_request_present(raw) and re.search(
        r"(?:실행|구동)(?:을|를)?\s*(?:원해|원한다|원하는|해\s*줄래|해\s*줄\s*수)|"
        r"\b(?:want|need)\b[^.!?\n]{0,48}\b(?:run|execute)\b", raw, re.I
    ):
        return True
    return bool(re.search(
        r"(?:"
        r"(?:코드(?:를|를\s+직접)?\s*)?(?:실행|구동)(?:해|해줘|해주세요|하라|하자|하고|해서|시켜|해\s*봐)"
        r"|(?:직접|실제로)\s*(?:돌려|실행해|실행하고|실행해서)"
        r"|(?:돌려\s*줘|돌려줘|돌려\s*봐|돌려봐)"
        r"|\b(?:run|execute)\b(?:\s+the)?\s+(?:code|script|command)\b"
        r")",
        raw,
        re.IGNORECASE,
    ))


def classify_outcome_shape(text: str) -> str:
    """Project canonical binding directives into legacy scheduling labels.

    Binding authority is compiled once by AuthorityConsolidation.  The legacy outcome
    labeler only inspects those already-binding current-user rows and therefore cannot
    promote a SourceDirectiveCompiler hint into effect authority.
    """
    exact = str(text or "")
    contract = RequirementCompiler.compile(exact)
    presentation = DiscourseScopeAnalyzer.compile(exact, contract)
    canonical = AuthorityConsolidation.compile(
        ExactUserSource.from_text(exact), contract, presentation=presentation
    )
    for row in reversed(canonical.directives):
        if not (
            row.binding
            and row.authority_scope == "current_user"
            and row.directive_kind in {"directive", "standing_policy"}
        ):
            continue
        probe = row.raw_text
        if requested_mode(probe) == "research":
            continue
        if _BUILD_EFFECT_RE.search(probe):
            return "build_artifact"
        if _SCHEDULE_EFFECT_RE.search(probe):
            return "schedule_manage"
        if _PRESENCE_EFFECT_RE.search(probe):
            return "grow_presence"
        if _COLLECTION_EFFECT_RE.search(probe):
            return "collect_and_transform"
    return ""


@dataclass(frozen=True)
class TurnSemanticAuthority:
    """Single typed semantic decision record for one immutable user message.

    The exact user text is retained alongside its hash so downstream code never needs
    to reconstruct or paraphrase the directive before acting on it.
    """

    message_sha256: str
    semantic_text: str
    substantive: bool
    effective_depth: str
    task_shape: str
    outcome_shape: str
    effective_objective: str
    continuation_restored: bool
    continuation_task_id: str
    continuation_objective_sha256: str
    search_required: bool
    external_capability_required: bool
    signed_in_browser_preferred: bool
    public_browser_interaction_required: bool
    source_families: tuple[str, ...]
    open_problem_required: bool
    representation_search_required: bool
    execution_experiment_required: bool
    required_capability_traits: tuple[str, ...]
    capability_need_descriptions: tuple[str, ...]
    unclassified_capability_requests: tuple[str, ...]
    urgency_requested: bool
    representation_frame_hints: tuple[str, ...]
    frontier_exploration_required: bool
    possibility_space_open: bool
    claim_verification_separate: bool
    effect_gate_at_materialization: bool
    # Executable authority split: these are the only fields downstream code may
    # use to grant current-turn effect authority.  task_shape/outcome_shape/traits
    # remain hypotheses and scheduling metadata.
    source_effect_authorized: bool
    denied_capabilities: tuple[str, ...]
    explicit_permissions: tuple[str, ...]
    authorizing_source_span: str
    derived_fields_are_advisory: bool
    operative_destination_source: str
    evidence: tuple[str, ...]
    proof_carrying_improvement: dict[str, Any]
    privacy_minimization: dict[str, Any]
    discourse_scope: dict[str, Any]
    source_clause_graph: dict[str, Any]
    monotonic_openness: bool = True
    raw_reparse_may_narrow: bool = False
    explicit_source_precedence: bool = True
    derived_interpretation_may_override_explicit: bool = False
    internal_boundary_may_rewrite_destination: bool = False
    current_directive_must_remain_visible_to_generation: bool = True
    # task_shape schedules work; it is not permission to narrow the user's goal.
    task_shape_role: str = "scheduling_hint"

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


def bind_semantic_authority(message: str, semantic_authority: Mapping[str, Any] | None) -> dict[str, Any]:
    """Return a provenance-checked authority mapping for this exact message.

    Canonical authority is message-hash bound.  Partial authority dictionaries remain supported for narrow standalone probes, but a full authority carrying a
    message hash may never be replayed onto a different command.  Openness contracts are message-bound: callers cannot opt a canonical authority into raw reparsing
    that narrows previously established semantics.
    """
    authority = dict(semantic_authority or {})
    if not authority:
        return authority
    actual_sha256 = hashlib.sha256(str(message).encode("utf-8")).hexdigest()
    accepted_hashes: set[str] = set()
    bound = str(authority.get("message_sha256") or "").strip().lower()
    if bound:
        accepted_hashes.add(bound)
    communication = authority.get("semantic_communication")
    if isinstance(communication, Mapping):
        source_hash = str(communication.get("source_sha256") or "").strip().lower()
        canonical_hash = str(communication.get("canonical_sha256") or "").strip().lower()
        if source_hash:
            accepted_hashes.add(source_hash)
        if canonical_hash:
            accepted_hashes.add(canonical_hash)
        if bound and (source_hash or canonical_hash) and bound not in {source_hash, canonical_hash}:
            raise DirectiveInvariantError(
                "semantic_authority_hash_mismatch:"
                f"message_sha256={bound}:source_sha256={source_hash}:canonical_sha256={canonical_hash}"
            )
    semantic_text = authority.get("semantic_text")
    if isinstance(semantic_text, str) and semantic_text:
        accepted_hashes.add(hashlib.sha256(semantic_text.encode("utf-8")).hexdigest())
    if accepted_hashes and actual_sha256 not in accepted_hashes:
        raise DirectiveInvariantError(
            "destination_sha256_changed:"
            f"expected_one_of={','.join(sorted(accepted_hashes))}:actual={actual_sha256}"
        )
    if authority.get("monotonic_openness") is False:
        raise DirectiveInvariantError("semantic_authority_monotonicity_disabled")
    if authority.get("raw_reparse_may_narrow") is True:
        raise DirectiveInvariantError("semantic_authority_raw_reparse_narrowing_forbidden")
    return authority


class SemanticAuthorityCompiler:
    """Compile the one semantic control-plane record used by downstream runtime gates."""

    @classmethod
    def _task_shape(
        cls, command: str, canonical_directives: Any, contract: RequirementContract,
        analysis: IntentDeepAnalysis, effective_depth: str,
    ) -> str:
        text = str(command or "").strip()
        if _ARITH.match(text):
            return "closed_deterministic"
        positives = tuple(
            row for row in canonical_directives.directives
            if row.binding and row.authority_scope == "current_user"
            and row.directive_kind in {"directive", "standing_policy"}
        )
        questions = tuple(
            row for row in canonical_directives.directives
            if row.binding and row.authority_scope == "current_user"
            and row.directive_kind == "question"
        )
        if str(effective_depth).casefold() == "deep":
            return "open_problem"
        if analysis.inferred_search_required or analysis.inferred_external_capability_required:
            return "open_problem"
        if positives and (len(positives) > 1 or classify_outcome_shape(text)):
            return "open_problem"
        if questions and not positives:
            return "closed_knowledge"
        return "ambiguous_general"

    @classmethod
    def compile(
        cls,
        command: str,
        contract: RequirementContract,
        analysis: IntentDeepAnalysis,
        *,
        effective_depth: str,
        semantic_objective: str | None = None,
        continuation_context: Mapping[str, Any] | None = None,
        semantic_contract: RequirementContract | None = None,
        discourse_scope: Any | None = None,
    ) -> TurnSemanticAuthority:
        # The literal message and the semantic objective are two different authorities
        # on a continuation turn.  The raw contract is the immutable destination hash;
        # the restored semantic contract describes the unfinished workstream.  Never
        # verify one against the other's bytes.
        verify_destination(
            raw_user_text=str(command),
            original_user_directive_sha256=contract.message_sha256,
        )
        verify_atom_conservation(
            raw_user_text=str(command),
            active_atom_ids=(a.atom_id for a in contract.atoms),
        )
        semantic_text = str(semantic_objective or command)
        semantic_contract = semantic_contract or contract
        if semantic_text != str(command):
            verify_destination(
                raw_user_text=semantic_text,
                original_user_directive_sha256=semantic_contract.message_sha256,
            )
            verify_atom_conservation(
                raw_user_text=semantic_text,
                active_atom_ids=(a.atom_id for a in semantic_contract.atoms),
            )
        elif semantic_contract.contract_sha256 != contract.contract_sha256:
            raise DirectiveInvariantError("semantic_contract_mismatch_without_projection")

        continuation = dict(continuation_context or {})
        semantic_presentation = discourse_scope or DiscourseScopeAnalyzer.compile(semantic_text, semantic_contract)
        semantic_directives = AuthorityConsolidation.compile(
            ExactUserSource.from_text(semantic_text), semantic_contract, presentation=semantic_presentation
        )
        if semantic_text == str(command) and semantic_contract.contract_sha256 == contract.contract_sha256:
            source_directives = semantic_directives
        else:
            source_presentation = DiscourseScopeAnalyzer.compile(str(command), contract)
            source_directives = AuthorityConsolidation.compile(
                ExactUserSource.from_text(str(command)), contract, presentation=source_presentation
            )
        scope = semantic_directives
        atom_rows = tuple(asdict(a) for a in semantic_contract.atoms)
        substantive = MicroClosureAuditor._substantive(semantic_text, atom_rows)

        # AuthorityConsolidation is the only discourse binding compiler.  Presentation
        # analyzers and downstream semantic classifiers may add hints, but they cannot
        # resurrect reference/history text as current effect authority.
        current_atoms = tuple(semantic_contract.atoms)
        current_text = semantic_directives.current_text or semantic_directives.semantic_text
        action_text = source_directives.action_text
        current_analysis = analysis
        action_analysis = IntentDeepAnalyzer().analyze(action_text) if action_text else IntentDeepAnalyzer().analyze("")
        current_depth = effective_depth

        # Compile source structure before deriving any routing hypotheses.  Exact source
        # clauses own effect authority; the semantic-objective graph is used only to
        # understand the active problem on restored continuation turns.
        source_graph = SourceDirectiveCompiler().compile(str(command))
        semantic_graph = SourceDirectiveCompiler().compile(current_text or semantic_text)
        # Clause graphs remain advisory structure only. Final binding/effect authority
        # comes from the versioned CanonicalDirectiveSet.
        effect_directives = tuple(
            row for row in source_directives.directives
            if row.binding
            and row.authority_scope == "current_user"
            and row.directive_kind in {"directive", "standing_policy", "prohibition"}
        )
        positive_effect_directives = tuple(
            row for row in effect_directives
            if row.directive_kind in {"directive", "standing_policy"}
        )
        prohibition_directives = tuple(
            row for row in effect_directives
            if row.directive_kind == "prohibition"
        )
        question_directives = tuple(
            row for row in source_directives.directives
            if row.binding and row.authority_scope == "current_user" and row.directive_kind == "question"
        )

        task_shape = cls._task_shape(
            current_text, semantic_directives, semantic_contract, current_analysis, current_depth
        )
        privacy_policy_text = action_text or str(command)
        privacy_decision = PrivacyMinimizationPolicy.evaluate(privacy_policy_text)
        outcome_shape = classify_outcome_shape(action_text) if action_text else ""
        if privacy_decision.active and outcome_shape == "grow_presence" and not privacy_decision.presence_growth_explicit:
            outcome_shape = ""
        open_problem = task_shape == "open_problem"
        execution_requested = False

        # Capability routing consumes only source-grounded live clauses.  A quoted or
        # negated mention can still be present in current_text, but cannot contribute
        # current actuator traits.  Questions can request information/capability
        # discovery without granting actuation.
        action_traits_set: set[str] = set()
        question_traits_set: set[str] = set()
        denied_capabilities: set[str] = set(source_directives.denied_capabilities)
        explicit_permissions: set[str] = set(source_directives.allowed_capabilities)
        authorizing_source_spans: list[str] = []
        source_families: list[str] = []
        signed_in_browser_preferred = False
        explicit_search_requested = False
        for directive in positive_effect_directives:
            directive_traits = set() if directive.requested_mode == "research" else set(infer_required_traits(directive.raw_text))
            if directive.requested_mode != "research" and _explicit_execution_permission(directive.raw_text):
                directive_traits.add("code_execution")
            if quote_adoption_requested(directive.raw_text):
                # Explicitly adopted quoted targets retain their capability hints.
                for clause in source_graph.clauses:
                    if clause.quoted and clause.authoritative:
                        directive_traits.update(infer_required_traits(clause.source_text))
            permission_traits = set(directive_traits)
            if "code_execution" in permission_traits and not _explicit_execution_permission(directive.raw_text):
                permission_traits.remove("code_execution")
            action_traits_set.update(permission_traits)
            explicit_permissions.update(permission_traits)
            # The exact directive is authority even when no finite capability
            # vocabulary recognizes its target. Unknown work stays executable.
            explicit_permissions.add("source_effect")
            authorizing_source_spans.append(directive.raw_text)
            directive_analysis = IntentDeepAnalyzer().analyze(directive.raw_text)
            explicit_search_requested = bool(explicit_search_requested or directive_analysis.inferred_search_required)
            source_families.extend(directive_analysis.inferred_source_families)
            signed_in_browser_preferred = bool(
                signed_in_browser_preferred or directive_analysis.inferred_signed_in_browser_preferred
            )
        # Prohibitions are negative authority evidence, never positive actuator traits.
        # infer_required_traits intentionally suppresses negated mentions, so execution
        # denial must be recovered from the already-authoritative prohibition span.
        for directive in prohibition_directives:
            folded = directive.raw_text.casefold()
            if capability_prohibited(directive.raw_text, (
                "run code", "execute code", "terminal", "shell", "vm",
                "실행", "코드 실행", "테스트",
            )):
                denied_capabilities.add("code_execution")

        for directive in question_directives:
            question_traits_set.update(infer_required_traits(directive.raw_text))
            directive_analysis = IntentDeepAnalyzer().analyze(directive.raw_text)
            explicit_search_requested = bool(explicit_search_requested or directive_analysis.inferred_search_required)
            source_families.extend(directive_analysis.inferred_source_families)

        source_families = list(SearchSwarmPolicy.expand(
            current_text or str(command), source_families, search_requested=explicit_search_requested
        ))
        required_capability_traits = tuple(sorted(action_traits_set | question_traits_set))
        trait_set = set(required_capability_traits)
        search_required = bool(explicit_search_requested or "web_search" in action_traits_set)
        material_outcome = outcome_shape in {
            "schedule_manage", "grow_presence", "collect_and_transform", "build_artifact"
        }
        if material_outcome and positive_effect_directives:
            explicit_permissions.add("material_outcome")
            if not authorizing_source_spans:
                authorizing_source_spans.append(positive_effect_directives[-1].raw_text)
        execution_requested = bool(positive_effect_directives)
        external_capability_required = bool(action_traits_set or question_traits_set or material_outcome)

        if privacy_decision.external_tools_disallowed:
            search_required = False
            external_capability_required = False
            signed_in_browser_preferred = False
            required_capability_traits = tuple(
                x for x in required_capability_traits
                if x not in {"browser", "interaction", "authenticated_session", "web_search"}
            )
            trait_set = set(required_capability_traits)

        # Explicit prohibitions apply to their capability, never to every other
        # request in the same turn. Keep source binding while filtering the route.
        denied_traits = set(denied_capabilities)
        if "code_modification" in denied_capabilities:
            denied_traits.add("write")
        if "external_tools" in denied_capabilities or privacy_decision.external_tools_disallowed:
            denied_traits.update({"browser", "interaction", "authenticated_session", "web_search", "web_write", "remote_compute", "remote_computer"})
        required_capability_traits = tuple(x for x in required_capability_traits if x not in denied_traits)
        explicit_permissions.difference_update(denied_traits)
        trait_set = set(required_capability_traits)
        if "web_search" in denied_traits:
            search_required = False

        # Preserve each exact live directive as an open capability description instead
        # of deciding whether it belongs to a fixed capability vocabulary. Known traits
        # are optional routing hints; unknown effects remain representable.
        capability_need_descriptions = tuple(
            dict.fromkeys(row.raw_text for row in positive_effect_directives if row.raw_text.strip())
        )
        unclassified_capability_requests = tuple(
            row.raw_text for row in positive_effect_directives
            if not infer_required_traits(row.raw_text) and row.raw_text.strip()
        )
        public_browser_interaction_required = bool(
            "browser" in trait_set and "interaction" in trait_set
            and not privacy_decision.external_tools_disallowed
        )

        # Exact-source host/material authority is now clause-grounded.  Derived task
        # shape, depth, and search classifiers cannot manufacture permission.  They may
        # only route an already-positive source effect.
        authorizing_source_span = "\n".join(dict.fromkeys(authorizing_source_spans)).strip()
        effective_permissions = explicit_permissions - denied_capabilities
        source_effect_authorized = bool(
            positive_effect_directives
            and effective_permissions
            and authorizing_source_span
        )
        urgency_requested = any(bool(atom.critical) for atom in semantic_contract.atoms)

        # Representation/frontier scheduling is derived from graph structure and depth,
        # not a finite list of semantic trigger words.
        rep_hints: list[str] = []
        if question_directives:
            rep_hints.append("information_gain")
        if len(semantic_graph.clauses) >= 2:
            rep_hints.append("multi_clause_alternative")
        if execution_requested:
            rep_hints.append("execution_experiment")
        if current_depth == "deep":
            rep_hints.append("open_representation")
        representation_search = bool(
            open_problem and (current_depth == "deep" or len(semantic_graph.clauses) >= 2)
        )
        frontier_exploration = bool(open_problem and current_depth == "deep")
        if representation_search and not rep_hints:
            rep_hints.append("open_representation")

        proof_carrying_improvement = (
            ProofCarryingImprovementProtocol.optimizer_context(semantic_text, semantic_contract)
            if ProofCarryingImprovementProtocol.should_activate(current_text)
            else {
                "schema": "proof_carrying_improvement_v1",
                "active": False,
                "optimizer_role": "runtime_optimizer",
            }
        )

        evidence = [
            f"depth:{current_depth}",
            f"task_shape:{task_shape}",
            f"search:{int(bool(search_required))}",
            f"external_capability:{int(bool(external_capability_required))}",
            f"privacy_minimization:{int(bool(privacy_decision.active))}",
            f"external_tools_disallowed:{int(bool(privacy_decision.external_tools_disallowed))}",
            f"execution_experiment:{int(bool(execution_requested))}",
            f"required_capability_traits:{','.join(required_capability_traits)}",
            f"urgency:{int(bool(urgency_requested))}",
            f"representation_search:{int(bool(representation_search))}",
            f"frontier_exploration:{int(bool(frontier_exploration))}",
            f"source_clause_count:{len(source_graph.clauses)}",
            f"unclassified_capability_requests:{len(unclassified_capability_requests)}",
            f"outcome_shape:{outcome_shape or 'none'}",
            f"continuation_restored:{int(bool(continuation.get('restored')))}",
            f"current_task_atoms:{len(current_atoms)}",
            f"action_scope_atoms:{len(source_directives.action_atom_ids)}",
            f"historical_scope_atoms:{source_directives.scope_counts.get('historical_reference', 0)}",
            f"quoted_scope_atoms:{source_directives.scope_counts.get('quoted_reference', 0)}",
            f"hypothetical_scope_atoms:{source_directives.scope_counts.get('hypothetical_reference', 0)}",
        ]
        return TurnSemanticAuthority(
            message_sha256=hashlib.sha256(str(command).encode("utf-8")).hexdigest(),
            semantic_text=semantic_text,
            substantive=substantive,
            effective_depth=str(current_depth or "unspecified"),
            task_shape=task_shape,
            outcome_shape=outcome_shape,
            # Keep the exact current source as the operative destination.  A restored
            # continuation objective remains available as semantic_text and may only be
            # resolved by the centralized source-bound continuation guard downstream.
            effective_objective=str(command),
            continuation_restored=bool(continuation.get("restored")),
            continuation_task_id=str(continuation.get("task_id") or ""),
            continuation_objective_sha256=str(continuation.get("objective_sha256") or ""),
            search_required=bool(search_required),
            external_capability_required=bool(external_capability_required),
            signed_in_browser_preferred=bool(signed_in_browser_preferred),
            public_browser_interaction_required=public_browser_interaction_required,
            source_families=tuple(dict.fromkeys(source_families)),
            open_problem_required=open_problem,
            representation_search_required=representation_search,
            execution_experiment_required=execution_requested,
            required_capability_traits=tuple(required_capability_traits),
            capability_need_descriptions=capability_need_descriptions,
            unclassified_capability_requests=unclassified_capability_requests,
            urgency_requested=urgency_requested,
            representation_frame_hints=tuple(dict.fromkeys(rep_hints)),
            frontier_exploration_required=frontier_exploration,
            possibility_space_open=bool(open_problem or representation_search or frontier_exploration),
            claim_verification_separate=True,
            effect_gate_at_materialization=True,
            source_effect_authorized=source_effect_authorized,
            denied_capabilities=tuple(sorted(denied_capabilities)),
            explicit_permissions=tuple(sorted(explicit_permissions - denied_capabilities)),
            authorizing_source_span=authorizing_source_span,
            derived_fields_are_advisory=True,
            operative_destination_source="exact_current_user_text",
            evidence=tuple(evidence),
            proof_carrying_improvement=proof_carrying_improvement,
            privacy_minimization=privacy_decision.as_mapping(),
            discourse_scope=scope.summary(),
            source_clause_graph=asdict(source_graph),
        )
