"""Executable candidate programs, independent artifacts, and reusable experience."""
from __future__ import annotations
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from .observed_evidence import ObservedEvidence, finite_scores

class CandidateLab:
    def __init__(self, root, adapters=None, experience_root=None):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True,exist_ok=True)
        self.adapters = dict(adapters or {})
        self.evidence = ObservedEvidence(self.root/'observations')
        self.path = self.root/'candidates.sqlite3'
        self.experience_root = Path(experience_root or self.root)
        self.experience_root.mkdir(parents=True,exist_ok=True)
        self.experience_path = self.experience_root/'experiences.sqlite3'
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS candidates(id TEXT PRIMARY KEY, goal TEXT, body TEXT, state TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS experiences(id TEXT PRIMARY KEY, family TEXT, body TEXT)')
        with sqlite3.connect(self.experience_path) as db:
            db.execute('CREATE TABLE IF NOT EXISTS experiences(id TEXT PRIMARY KEY, family TEXT, body TEXT)')

    def db(self):
        db = sqlite3.connect(self.path,timeout=30)
        db.execute('PRAGMA journal_mode=WAL')
        return db

    def propose(self, *, goal_ref, lane_id, representation, operator_program, assumptions=(), ancestry=(), reusable_conditions=()):
        if not goal_ref or not representation or not operator_program:
            raise ValueError('candidate needs exact goal reference, representation and executable operator program')
        for step in operator_program:
            if not isinstance(step,dict) or not step.get('capability') or not isinstance(step.get('arguments'),dict):
                raise ValueError('operator steps require capability and argument object')
        material = dict(goal_ref=str(goal_ref),lane_id=str(lane_id),representation=str(representation),
                        operator_program=list(operator_program),assumptions=list(assumptions),ancestry=list(ancestry),
                        reusable_conditions=list(reusable_conditions))
        signature = hashlib.sha256(json.dumps([representation,operator_program],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        cid = 'candidate_'+hashlib.sha256(json.dumps(material,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:24]
        material.update(candidate_id=cid,diversity_signature=signature,created_at=time.time())
        with self.db() as db:
            db.execute('INSERT OR IGNORE INTO candidates VALUES (?,?,?,?)',(cid,str(goal_ref),json.dumps(material,ensure_ascii=False),'proposed'))
        return material

    def run(self, candidate_id, *, observer, score_result):
        from .state_transaction import state_transaction
        with state_transaction(self.root/'locks'/candidate_id):
            return self._run(candidate_id,observer=observer,score_result=score_result)

    def require_goal(self, candidate_id, goal_ref):
        with self.db() as db:
            row = db.execute('SELECT goal FROM candidates WHERE id=?',(candidate_id,)).fetchone()
        if not row or row[0] != goal_ref:
            raise ValueError('candidate is not bound to this exact user goal')

    def run_batch(self, candidate_ids, *, max_workers=4, observer):
        from concurrent.futures import ThreadPoolExecutor
        score = lambda rows:{'execution_effect':float(bool(rows) and all(isinstance(x['result'],dict) and x['result'].get('success') is True for x in rows))}
        def run_one(cid):
            try: return {'candidate_id':cid,'result':self.run(cid,observer=observer,score_result=score)}
            except Exception as exc: return {'candidate_id':cid,'state':'route_failed','error':str(exc)}
        with ThreadPoolExecutor(max_workers=max(1,int(max_workers))) as pool:
            results = list(pool.map(run_one,dict.fromkeys(candidate_ids)))
        return {'workers_observed':len(results),'independent_workspaces':True,'results':results}

    def _run(self, candidate_id, *, observer, score_result):
        with self.db() as db:
            saved = db.execute('SELECT body,state FROM candidates WHERE id=?',(candidate_id,)).fetchone()
        if not saved:
            raise KeyError(candidate_id)
        row = json.loads(saved[0])
        if saved[1] == 'observed':
            for ref in row['evidence_refs']: self.evidence.resolve(ref)
            return row
        if saved[1] == 'running':
            raise ValueError('candidate has an interrupted execution requiring reconciliation')
        for step in row['operator_program']:
            if step['capability'] not in self.adapters:
                raise KeyError('candidate capability needs binding: '+step['capability'])
        with self.db() as db:
            db.execute("UPDATE candidates SET state='running' WHERE id=?",(candidate_id,))
        workspace = self.root/'workspaces'/candidate_id
        workspace.mkdir(parents=True,exist_ok=True)
        outputs = []
        for step in row['operator_program']:
            capability = step['capability']
            if capability not in self.adapters:
                raise KeyError('candidate capability needs binding: '+capability)
            result = self.adapters[capability](step['arguments'],workspace)
            outputs.append({'capability':capability,'result':result})
        artifact = workspace/'observed_program_results.json'
        artifact.write_text(json.dumps(outputs,ensure_ascii=False,sort_keys=True,default=str))
        scores = finite_scores(score_result(outputs))
        ref = self.evidence.record(case_id=row['goal_ref'],subject_ref=candidate_id,scores=scores,artifacts=[artifact],observer=observer)
        row.update(tested=True,observed_effects=outputs,evidence_refs=[ref],scores=scores,score=sum(scores.values())/len(scores),artifact_refs=[str(artifact)])
        with self.db() as db:
            db.execute("UPDATE candidates SET body=?,state='observed' WHERE id=?",(json.dumps(row,ensure_ascii=False,default=str),candidate_id))
        return row

    def candidates(self, goal_ref):
        with self.db() as db:
            rows=[json.loads(x[0]) for x in db.execute("SELECT body FROM candidates WHERE goal=? AND state='observed'",(str(goal_ref),))]
        # Artifact locations move with a state capsule; signed operator requests
        # and exact source bytes remain unchanged.
        bindings=next((p/'RESTORED_PATH_BINDINGS.json' for p in (self.root,*self.root.parents) if (p/'RESTORED_PATH_BINDINGS.json').is_file()),None)
        if bindings:
            mapping=json.loads(bindings.read_text());old=mapping['origin_root'];new=mapping['current_root']
            def address(value):return new+value[len(old):] if isinstance(value,str) and (value==old or value.startswith(old+'/')) else value
            for row in rows:
                row['artifact_refs']=[address(x) for x in row.get('artifact_refs',[])]
                for effect in row.get('observed_effects',[]):
                    if isinstance(effect.get('result'),dict) and effect['result'].get('artifact'):
                        effect['result']['artifact']=address(effect['result']['artifact'])
        return rows

    def synthesize(self, goal_ref):
        from .wild_cognitive_plane import WildCognitivePlane
        candidates = self.candidates(goal_ref)
        readiness = WildCognitivePlane.synthesis_readiness(candidates,evidence_resolver=self.evidence.resolve)
        return {**readiness,'goal_ref':goal_ref,'candidate_results':candidates if readiness['ready'] else [],
                'next_effect':'generate_synthesis_from_observed_artifacts' if readiness['ready'] else 'continue_independent_candidate_programs'}

    def remember(self, candidate_id, *, family, user_feedback):
        with self.db() as db:
            row = db.execute('SELECT body,state FROM candidates WHERE id=?',(candidate_id,)).fetchone()
            if not row or row[1] != 'observed':
                raise ValueError('experience must have actual candidate observations')
            body = json.loads(row[0]); body['user_feedback'] = str(user_feedback)
        with sqlite3.connect(self.experience_path) as db:
            db.execute('INSERT OR REPLACE INTO experiences VALUES (?,?,?)',(candidate_id,str(family),json.dumps(body,ensure_ascii=False,default=str)))

    def recall(self, family):
        with sqlite3.connect(self.experience_path) as db:
            return [json.loads(x[0]) for x in db.execute('SELECT body FROM experiences WHERE family=? ORDER BY rowid DESC',(str(family),))]
