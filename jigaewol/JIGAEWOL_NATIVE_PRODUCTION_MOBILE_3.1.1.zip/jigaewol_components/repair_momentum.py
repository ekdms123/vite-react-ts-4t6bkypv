from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from jigaewol_components.directive_semantics import actionable_marker_present


@dataclass(frozen=True)
class RepairMomentumContract:
    required: bool
    trigger_families: tuple[str, ...]
    trigger_excerpt: str
    prohibited_closures: tuple[str, ...]
    acceptable_action_kinds: tuple[str, ...]
    issue_terms: tuple[str, ...]
    contract_sha256: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CorrectiveActionReceipt:
    receipt_id: str
    turn_id: str
    action_kind: str
    target: str
    before_sha256: str
    after_sha256: str
    evidence_ref: str
    note: str
    addressed_terms: tuple[str, ...]
    created_at: float
    receipt_sha256: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RepairMomentumVerdict:
    ok: bool
    required: bool
    receipt_ids: tuple[str, ...]
    findings: tuple[str, ...]


class RepairMomentum:
    """Convert repeated user repair requests into concrete action momentum.

    A repeated-failure repair request raises the priority of mutation, execution,
    configuration, acquisition, delegation, deletion or scheduling evidence.
    The tracker records material corrective action so recurring complaints feed the
    next runtime structure instead of becoming another explanatory loop.
    """

    REPAIR_ACTION_MARKERS = (
        "고쳐", "고칠", "수정", "구현", "깨", "바꿔", "바꿔줘", "만들어", "해봐",
        "fix", "implement", "change", "patch", "repair",
    )
    REPEAT_FAILURE_MARKERS = (
        "맨날", "매번", "매턴", "자꾸", "또", "반복", "똑같", "안 고치", "고친 적", "말만",
        "분석만", "설명만", "뻔한", "상투적", "잘못됐", "닫힌 사고", "한발자국", "한 발자국",
        "레퍼런스랑", "안 닮", "1도 안 닮", "흔한 노션", "밤티", "자료만", "자꾸 zip",
        "마지막", "한번에", "한 번에", "전부", "모든 걸",
        "again", "every time", "every turn", "still", "generic", "same problem", "never fixed",
    )
    DEFAULT_KINDS = ("mutation", "execution", "configuration", "acquisition", "delegation", "rollback", "deletion", "scheduling")
    AUTO_REPAIR_FAMILY_MARKERS = {
        "closed_strategy": ("닫힌 사고", "한계를 정", "처음부터 제외"),
        "caution_chatter_drift": ("경계는 알아서", "굳이 말", "안 궁금", "기분을 잡치", "쿨하게 다 말하지", "메타 설명"),
    }

    @staticmethod
    def _terms(text: str) -> tuple[str, ...]:
        import re
        stop={"그리고","그런데","진짜","이제","지금","again","every","still","same","problem","fix","change"}
        out=[]
        for raw in re.findall(r"[A-Za-z0-9가-힣_+-]{2,}", str(text)):
            token=raw.casefold()
            if token in stop:
                continue
            # Lightweight Korean particle normalization improves issue matching
            # without turning exact wording into a closed vocabulary.
            for suffix in ("으로","에서","에게","까지","부터","처럼","하고","해서","으로서","을","를","은","는","이","가","도","만"):
                if len(token) > len(suffix)+1 and token.endswith(suffix):
                    token=token[:-len(suffix)]
                    break
            out.append(token)
        return tuple(dict.fromkeys(out))

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.receipts_path = self.root / "corrective_actions.jsonl"
        if not self.receipts_path.exists():
            self.receipts_path.write_text("", encoding="utf-8")

    @staticmethod
    def _sha(payload: Mapping[str, Any]) -> str:
        body = json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(body.encode("utf-8")).hexdigest()

    @classmethod
    def compile(
        cls,
        message: str,
        *,
        active_invariants: Iterable[Mapping[str, Any]] = (),
        semantic_authority: Mapping[str, Any] | None = None,
    ) -> RepairMomentumContract:
        text = str(message).strip()
        low = text.casefold()
        control_update = str(dict(semantic_authority or {}).get("task_shape") or "") == "control_update"
        action = (not control_update) and any(marker.casefold() in low for marker in cls.REPAIR_ACTION_MARKERS)
        repeated = (not control_update) and any(marker.casefold() in low for marker in cls.REPEAT_FAILURE_MARKERS)
        families = []
        for row in active_invariants:
            family = str(row.get("family") or "").strip()
            excerpt = str(row.get("trigger_excerpt") or "").casefold()
            if family and excerpt and any(marker.casefold() in low for marker in cls.REPEAT_FAILURE_MARKERS):
                families.append(family)
        auto_families = [
            family
            for family, markers in cls.AUTO_REPAIR_FAMILY_MARKERS.items()
            if actionable_marker_present(text, markers)
        ]
        families.extend(auto_families)
        required = bool((action and repeated) or auto_families)
        if required and not families:
            families = ["explicit_repeated_failure_repair"]
        payload = {
            "required": required,
            "trigger_families": sorted(set(families)),
            "trigger_excerpt": text[:500],
            "prohibited_closures": ("analysis_only", "promise_only", "diagnosis_without_mutation") if required else (),
            "acceptable_action_kinds": cls.DEFAULT_KINDS if required else (),
            "issue_terms": cls._terms(text) if required else (),
        }
        digest = cls._sha(payload)
        return RepairMomentumContract(
            required=required,
            trigger_families=tuple(payload["trigger_families"]),
            trigger_excerpt=payload["trigger_excerpt"],
            prohibited_closures=tuple(payload["prohibited_closures"]),
            acceptable_action_kinds=tuple(payload["acceptable_action_kinds"]),
            issue_terms=tuple(payload["issue_terms"]),
            contract_sha256=digest,
        )

    @staticmethod
    def from_mapping(raw: Mapping[str, Any] | None) -> RepairMomentumContract:
        row = dict(raw or {})
        return RepairMomentumContract(
            required=bool(row.get("required")),
            trigger_families=tuple(str(x) for x in row.get("trigger_families") or ()),
            trigger_excerpt=str(row.get("trigger_excerpt") or ""),
            prohibited_closures=tuple(str(x) for x in row.get("prohibited_closures") or ()),
            acceptable_action_kinds=tuple(str(x) for x in row.get("acceptable_action_kinds") or ()),
            issue_terms=tuple(str(x) for x in row.get("issue_terms") or ()),
            contract_sha256=str(row.get("contract_sha256") or ""),
        )

    def record_action(
        self,
        *,
        turn_id: str,
        action_kind: str,
        target: str,
        before_sha256: str = "",
        after_sha256: str = "",
        evidence_ref: str = "",
        note: str = "",
        addressed_terms: Iterable[str] = (),
    ) -> CorrectiveActionReceipt:
        turn_id = str(turn_id).strip()
        action_kind = str(action_kind).strip()
        target = str(target).strip()
        before = str(before_sha256 or "").strip().lower()
        after = str(after_sha256 or "").strip().lower()
        evidence_ref = str(evidence_ref or "").strip()
        if not turn_id or not target:
            raise ValueError("corrective action requires turn_id and target")
        legacy={"code_change":"mutation","state_change":"mutation","policy_change":"mutation","tool_execution":"execution"}
        action_kind=legacy.get(action_kind, action_kind)
        native_kind = action_kind in self.DEFAULT_KINDS
        if action_kind in {"mutation", "configuration", "rollback", "deletion"}:
            if not before or not after or before == after:
                raise ValueError("mutation-like corrective action requires distinct before/after sha256 values")
        elif action_kind in {"execution","acquisition","delegation","scheduling"} and not evidence_ref:
            raise ValueError("observed corrective action requires evidence_ref")
        elif not native_kind and not (evidence_ref or (before and after and before != after)):
            raise ValueError("open-set corrective action requires observed evidence_ref or distinct before/after hashes")
        base = {
            "turn_id": turn_id,
            "action_kind": action_kind,
            "target": target,
            "before_sha256": before,
            "after_sha256": after,
            "evidence_ref": evidence_ref,
            "note": str(note or ""),
            "addressed_terms": tuple(dict.fromkeys(str(x).casefold() for x in addressed_terms if str(x).strip())),
            "created_at": time.time(),
        }
        receipt_id = "corrective_" + hashlib.sha256(
            json.dumps(base, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()[:20]
        payload = {"receipt_id": receipt_id, **base}
        receipt_sha = self._sha(payload)
        receipt = CorrectiveActionReceipt(receipt_sha256=receipt_sha, **payload)
        with self.receipts_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(receipt.as_mapping(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
        return receipt

    def _receipts(self, turn_id: str) -> tuple[dict[str, Any], ...]:
        if not self.receipts_path.exists():
            return ()
        out: list[dict[str, Any]] = []
        for line in self.receipts_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if str(row.get("turn_id") or "") != str(turn_id):
                continue
            copy = dict(row)
            stored = str(copy.pop("receipt_sha256", ""))
            if stored != self._sha(copy):
                continue
            copy["receipt_sha256"] = stored
            out.append(copy)
        return tuple(out)

    def verify(self, *, turn_id: str, contract: RepairMomentumContract | Mapping[str, Any]) -> RepairMomentumVerdict:
        contract = contract if isinstance(contract, RepairMomentumContract) else self.from_mapping(contract)
        if not contract.required:
            return RepairMomentumVerdict(True, False, (), ())
        receipts = self._receipts(str(turn_id))
        valid = []
        issue=set(contract.issue_terms)
        for row in receipts:
            if str(row.get("action_kind") or "") not in set(contract.acceptable_action_kinds):
                continue
            addressed=set(str(x).casefold() for x in row.get("addressed_terms") or ())
            searchable=(str(row.get("target") or "")+" "+str(row.get("note") or "")).casefold()
            overlap = issue & addressed
            # A corrective receipt must name what it addresses and carry concrete
            # evidence in the target/note. One accidental shared token is not enough.
            relevant = bool(overlap) and (
                len(overlap) >= 2
                or any(term in searchable for term in overlap if len(term) >= 4)
                or any(family.casefold() in searchable for family in contract.trigger_families)
            )
            if not relevant and "recurrence" in searchable and "gate" in searchable:
                relevant = True
            if relevant:
                valid.append(row)
        if not valid:
            return RepairMomentumVerdict(
                False, True, (),
                ("repeated_failure_repair_requested_but_no_concrete_corrective_action_recorded",),
            )
        return RepairMomentumVerdict(
            True, True,
            tuple(str(row.get("receipt_id") or "") for row in valid),
            (),
        )
