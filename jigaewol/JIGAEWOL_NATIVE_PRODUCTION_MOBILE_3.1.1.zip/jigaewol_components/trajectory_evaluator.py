from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping


def _sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class TrajectoryScore:
    evaluation_id: str
    case_id: str
    candidate_id: str
    scores: dict[str, float]
    aggregate: float
    feedback: tuple[str, ...]
    trace_ref: str
    created_at: float

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class TrajectoryEvaluator:
    """Evidence-oriented evaluator for agent/runtime execution trajectories.

    The evaluator deliberately grades *observed behavior*, not hidden reasoning.  It
    accepts structured events/receipts and emits a small metric vector plus textual
    feedback suitable for policy evolution.  Metrics are normalized to [0, 1].
    """

    DEFAULT_WEIGHTS = {
        "objective_fidelity": 0.30,
        "execution_truth": 0.25,
        "evidence_coverage": 0.20,
        "route_openness": 0.15,
        "completion_integrity": 0.10,
    }

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "trajectory_evaluations.jsonl"
        self.path.touch(exist_ok=True)

    @staticmethod
    def _bounded(value: Any) -> float:
        try:
            return max(0.0, min(1.0, float(value)))
        except (TypeError, ValueError):
            return 0.0

    @classmethod
    def score_trace(cls, trace: Mapping[str, Any]) -> tuple[dict[str, float], tuple[str, ...]]:
        row = dict(trace or {})
        feedback: list[str] = []

        exact = row.get("objective_preserved_exactly") is True
        accounted = cls._bounded(row.get("requirement_accounting", 1.0 if exact else 0.0))
        objective_fidelity = 1.0 if exact else accounted
        if objective_fidelity < 1.0:
            feedback.append("objective fidelity was incomplete; preserve current user intent and atomic requirements")

        planned = max(0, int(row.get("planned_actions") or 0))
        executed = max(0, int(row.get("executed_actions") or 0))
        falsely_claimed = max(0, int(row.get("false_execution_claims") or 0))
        if planned == 0:
            execution_truth = 1.0 if falsely_claimed == 0 else 0.0
        else:
            execution_truth = max(0.0, min(1.0, executed / planned))
            if falsely_claimed:
                execution_truth = 0.0
        if execution_truth < 1.0:
            feedback.append("planned work was not fully backed by observed execution receipts")

        successful = max(0, int(row.get("successful_actions") or 0))
        evidence_refs = tuple(str(x) for x in row.get("evidence_refs") or () if str(x).strip())
        expected_evidence = max(successful, int(row.get("expected_evidence_count") or 0))
        if expected_evidence <= 0:
            evidence_coverage = 1.0
        else:
            evidence_coverage = min(1.0, len(set(evidence_refs)) / expected_evidence)
        if evidence_coverage < 1.0:
            feedback.append("successful effects were not fully supported by durable observation refs")

        route_failures = max(0, int(row.get("route_failures") or 0))
        alternate_attempts = max(0, int(row.get("alternate_route_attempts") or 0))
        global_impossibility = row.get("global_impossibility_claimed") is True
        if global_impossibility:
            route_openness = 0.0
            feedback.append("a route-level failure was promoted to a global impossibility claim")
        elif route_failures == 0:
            route_openness = 1.0
        else:
            route_openness = min(1.0, alternate_attempts / route_failures)
            if route_openness < 1.0:
                feedback.append("failed routes were not matched by alternate-route exploration")

        released = row.get("released") is True
        completion_claimed = row.get("completion_claimed") is True
        open_obligations = max(0, int(row.get("open_obligations") or 0))
        if completion_claimed and open_obligations:
            completion_integrity = 0.0
            feedback.append("completion was claimed while obligations remained open")
        elif released:
            completion_integrity = 1.0
        else:
            completion_integrity = cls._bounded(row.get("completion_integrity", 0.5))

        return {
            "objective_fidelity": objective_fidelity,
            "execution_truth": execution_truth,
            "evidence_coverage": evidence_coverage,
            "route_openness": route_openness,
            "completion_integrity": completion_integrity,
        }, tuple(feedback)

    def evaluate(
        self,
        *,
        case_id: str,
        candidate_id: str,
        trace: Mapping[str, Any],
        trace_ref: str = "",
        weights: Mapping[str, float] | None = None,
        extra_feedback: Iterable[str] = (),
    ) -> TrajectoryScore:
        scores, feedback = self.score_trace(trace)
        w = {**self.DEFAULT_WEIGHTS, **dict(weights or {})}
        denominator = sum(max(0.0, float(w.get(k, 0.0))) for k in scores) or 1.0
        aggregate = sum(scores[k] * max(0.0, float(w.get(k, 0.0))) for k in scores) / denominator
        material = {
            "case_id": str(case_id), "candidate_id": str(candidate_id), "scores": scores,
            "trace_ref": str(trace_ref), "trace": dict(trace or {}),
        }
        evaluation_id = "teval_" + _sha(material)[:20]
        result = TrajectoryScore(
            evaluation_id=evaluation_id,
            case_id=str(case_id),
            candidate_id=str(candidate_id),
            scores=scores,
            aggregate=aggregate,
            feedback=tuple(dict.fromkeys((*feedback, *(str(x) for x in extra_feedback if str(x).strip())))),
            trace_ref=str(trace_ref),
            created_at=time.time(),
        )
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(result.as_mapping(), ensure_ascii=False, sort_keys=True) + "\n")
        return result
