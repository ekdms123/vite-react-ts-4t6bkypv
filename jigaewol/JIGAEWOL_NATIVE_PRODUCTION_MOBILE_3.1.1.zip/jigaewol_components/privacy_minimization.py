from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from jigaewol_components.directive_semantics import affirmative_actionable_marker_present, actionable_marker_present, is_meta_mention, is_reported_or_negated_marker_reference


@dataclass(frozen=True, slots=True)
class PrivacyMinimizationDecision:
    """Minimize avoidable plaintext duplication by the ZIP runtime itself."""

    active: bool
    chat_only_requested: bool
    external_tools_disallowed: bool
    minimize_plaintext_persistence: bool
    minimize_host_payload_plaintext: bool
    presence_growth_explicit: bool
    boundary: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class PrivacyMinimizationPolicy:
    _PRIVACY_MARKERS = (
        "프라이버시", "privacy", "private", "개인정보", "민감정보", "민감한", "비공개",
        "노출을 줄", "노출 줄", "노출되지", "노출 안", "다른 사람", "아무도", "로그", "기록 최소",
        "감지하지 못", "감지 못", "인식하지 못", "인식 못", "숨기", "보이지 않", "안 보이",
    )
    _CHAT_ONLY_MARKERS = (
        "이 채팅에서만", "여기서만", "채팅 안이어야", "무조건 여기", "밖으로 보내지", "밖에 보내지",
        "no external api", "no external tool", "chat only", "in this chat only",
    )
    _NO_EXTERNAL_RE = re.compile(
        r"(?:외부\s*(?:api|도구|서비스|걸|것).{0,12}(?:못|안|금지|쓰지|사용하지))|"
        r"(?:(?:못|안)\s*.{0,12}외부\s*(?:api|도구|서비스))|"
        r"(?:no\s+external\s+(?:api|tool|service))",
        re.IGNORECASE,
    )
    _PRESENCE_GROWTH_MARKERS = (
        "계정 키우", "팔로워", "구독자", "조회수", "도달률", "인게이지", "떡상", "채널 키우",
        "바이럴", "알고리즘 타", "followers", "subscribers", "engagement", "audience growth", "go viral",
    )
    _PRIVACY_DISABLE_RE = re.compile(
        r"(?:프라이버시|privacy|private|로그|기록|노출|숨기|redact|minimi[sz]e)"
        r"[^\n]{0,24}(?:하지\s*마|하지마|하지\s*말|말고|숨기지\s*마|지우지\s*마|삭제하지\s*마|"
        r"보이지\s*않게\s*하지\s*마|do\s+not|don't|never)"
        r"|(?:do\s+not|don't|never)[^\n]{0,24}(?:hide|redact|minimi[sz]e|privacy|logs?)",
        re.IGNORECASE,
    )

    @classmethod
    def evaluate(cls, text: str) -> PrivacyMinimizationDecision:
        folded = str(text or "").casefold()
        raw = str(text or "")
        privacy = bool(
            affirmative_actionable_marker_present(raw, cls._PRIVACY_MARKERS)
            and not cls._PRIVACY_DISABLE_RE.search(folded)
        )
        chat_only = actionable_marker_present(raw, cls._CHAT_ONLY_MARKERS)
        no_external_match = cls._NO_EXTERNAL_RE.search(folded)
        no_external = bool(
            no_external_match
            and not is_meta_mention(str(text or ""), no_external_match.group(0), index=no_external_match.start())
            and not is_reported_or_negated_marker_reference(
                str(text or ""), no_external_match.group(0), index=no_external_match.start()
            )
        )
        presence = any(m.casefold() in folded for m in cls._PRESENCE_GROWTH_MARKERS)
        active = bool(privacy or chat_only or no_external)
        return PrivacyMinimizationDecision(
            active=active,
            chat_only_requested=bool(chat_only),
            external_tools_disallowed=bool(active and no_external),
            minimize_plaintext_persistence=bool(active),
            minimize_host_payload_plaintext=bool(active),
            presence_growth_explicit=bool(presence),
            boundary=(
                "runtime_minimization_active"
                if active else "default_runtime"
            ),
        )

    @staticmethod
    def objective_ref(text: str) -> str:
        digest = hashlib.sha256(str(text).encode("utf-8")).hexdigest()
        return f"[privacy-minimized objective sha256:{digest}]"

    @classmethod
    def minimize_payload_objective(cls, payload: Mapping[str, Any], *, decision: Mapping[str, Any]) -> dict[str, Any]:
        row = cls.minimize_payload_recursive(dict(payload), decision=decision)
        return dict(row)


    @classmethod
    def minimize_payload_recursive(cls, value: Any, *, decision: Mapping[str, Any]) -> Any:
        """Recursively redact avoidable plaintext in nested host payloads.

        The first privacy patch redacted only top-level ``objective``/``query`` keys.
        Search portfolios and nested query programs could therefore re-copy the same
        user text one level down.  This walk treats those semantic carrier keys the
        same at every nesting depth while leaving structural metadata intact.
        """
        if not bool(decision.get("minimize_host_payload_plaintext")):
            return value
        sensitive_keys = {
            "objective", "command", "query", "prompt", "semantic_text",
            "exact_text", "user_text", "raw_user_text", "original_text",
        }
        def walk(node: Any, key: str = "") -> Any:
            if isinstance(node, Mapping):
                out: dict[str, Any] = {}
                for k, v in node.items():
                    sk = str(k)
                    if sk.casefold() in sensitive_keys and isinstance(v, str) and v:
                        # Already-redacted refs are stable and need not be rehashed.
                        if v.startswith("[privacy-minimized objective sha256:"):
                            out[sk] = v
                        else:
                            out[sk] = cls.objective_ref(v)
                            out[f"{sk}_sha256"] = hashlib.sha256(v.encode("utf-8")).hexdigest()
                            out[f"{sk}_plaintext_redacted"] = True
                    else:
                        out[sk] = walk(v, sk)
                return out
            if isinstance(node, tuple):
                return tuple(walk(x, key) for x in node)
            if isinstance(node, list):
                return [walk(x, key) for x in node]
            return node
        redacted = walk(value)
        if isinstance(redacted, dict):
            redacted.setdefault("privacy_minimization", {
                "active": True,
                "boundary": str(decision.get("boundary") or "runtime_minimization_active"),
                "recursive_payload_redaction": True,
            })
        return redacted

    @classmethod
    def audit_preview(cls, text: str) -> str:
        decision = cls.evaluate(text)
        if not decision.minimize_plaintext_persistence:
            return str(text)[:240]
        digest = hashlib.sha256(str(text).encode("utf-8")).hexdigest()
        return f"[privacy-minimized sha256:{digest}]"
