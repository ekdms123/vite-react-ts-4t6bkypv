"""Immutable observation records with verified artifact bindings."""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path

def finite_scores(scores):
    result = {str(k): float(v) for k, v in dict(scores).items()}
    if not result or any(not math.isfinite(v) or not 0 <= v <= 1 for v in result.values()):
        raise ValueError('scores must be finite numbers in [0,1]')
    return result

class ObservedEvidence:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def record(self, *, case_id, subject_ref, scores, artifacts, observer):
        rows = []
        for filename in artifacts:
            path = Path(filename).resolve()
            data = path.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            target = self.root / (digest + '.artifact')
            if not target.exists():
                target.write_bytes(data)
            rows.append({'sha256': digest, 'size': len(data)})
        if not rows or not observer or not case_id or not subject_ref:
            raise ValueError('observation requires case, subject, observer and actual artifacts')
        row = dict(case_id=str(case_id), subject_ref=str(subject_ref), scores=finite_scores(scores),
                   artifacts=rows, observer=str(observer))
        data = json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
        digest = hashlib.sha256(data).hexdigest()
        (self.root/(digest+'.json')).write_bytes(data)
        return 'observation:sha256:'+digest

    def resolve(self, ref):
        prefix = 'observation:sha256:'
        if not str(ref).startswith(prefix):
            raise ValueError('unresolved observation reference')
        digest = str(ref)[len(prefix):]
        if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('invalid observation digest')
        data = (self.root/(digest+'.json')).read_bytes()
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError('observation digest mismatch')
        row = json.loads(data)
        for artifact in row['artifacts']:
            data = (self.root/(artifact['sha256']+'.artifact')).read_bytes()
            if len(data) != artifact['size'] or hashlib.sha256(data).hexdigest() != artifact['sha256']:
                raise ValueError('observation artifact mismatch')
        finite_scores(row['scores'])
        return row
