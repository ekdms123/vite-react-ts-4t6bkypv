from __future__ import annotations
from jigaewol_components.snapshot_store import load_snapshot, save_snapshot

import hashlib
import json
import re
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .privacy_minimization import PrivacyMinimizationPolicy
from .body_federation import BodyFederationRegistry
from .host_action_truth import HostActionTruthLedger
from .runtime_home import resolve_chat_runtime_home
from .durable_run_protocol import DurableRunLedger
from .search_run_bridge import SearchRunBridge
from .intent_deep_analyzer import IntentDeepAnalyzer
from .search_portfolio_engine import SearchPortfolioEngine
from .objective_fidelity import (
    ObjectiveDimension,
    ObjectiveFidelity,
    ObjectiveInterpretation,
    ObjectiveSpace,
    PlanCoverage,
)
from .reasoning_portfolio import AdaptiveReasoningPortfolio
from .semantic_authority import bind_semantic_authority
from .authority_guard import capability_authorization, source_bound_objective, source_effect_authorized
from .image_sovereignty import ImageSovereigntyPolicy
from .image_quality_governor import ImageQualityGovernor
from jigaewol_runtime.capabilities.execution_routes import infer_required_traits




def _public_browser_interaction_materially_required(command: str) -> bool:
    """Route explicit public-site UI tests through an interactive browser body.

    A URL plus an interaction verb (type/search/click/navigate/test) is different
    from merely asking to read or summarize a public page.  This keeps public UI
    execution separate from authenticated-session semantics.
    """
    text = str(command)
    folded = text.casefold()
    if not re.search(r"https?://[^\s]+", text):
        return False
    interaction_markers = (
        "이 사이트", "사이트로", "사이트에서", "페이지에서", "직접 열", "열어",
        "눌러", "클릭", "입력", "검색되나", "검색되는지", "검색해봐", "이동",
        "접속", "테스트", "작동하는지", "동작하는지", "확인먼저", "확인 먼저",
        "use this site", "on this site", "open this site", "click", "type into",
        "search from", "navigate", "test whether", "interact",
    )
    return any(marker.casefold() in folded for marker in interaction_markers)


@dataclass(frozen=True)
class CanonicalHostAction:
    action_id: str
    release_turn_id: str
    capability: str
    family: str
    preferred_executors: tuple[str, ...]
    selected_body_id: str
    selected_executor: str
    zero_cost_only: bool
    required: bool
    payload: dict[str, Any]
    request_sha256: str
    state: str
    created_at: float
    binding_state: str = ""
    revalidation_required: bool = False
    fallback_body_ids: tuple[str, ...] = ()
    fallback_executors: tuple[str, ...] = ()


class CanonicalHostBridge:
    """Durable action boundary between canonical cognition and real host tools.

    Emitting an action is never execution.  Only ``record_result`` can close the
    action, and successful results keep their host origin reference for later
    binding into the canonical release evidence ledger.
    """

    EXECUTORS = {
        "first_party": ("native.web", "TinyFish", "Firecrawl"),
        "web_current": ("native.web", "TinyFish", "Exa", "Parallel_Search", "Firecrawl"),
        "community": ("native.web", "TinyFish", "Exa", "Firecrawl"),
        "social_recommendation": ("Opera_Browser_Connector", "TinyFish", "native.web"),
        "code_ecosystem": ("GitHub", "native.web", "TinyFish", "Firecrawl"),
        "research": ("native.web", "Exa", "Parallel_Search", "Consensus", "Elicit", "SciSpace"),
        "creator_graph": ("Opera_Browser_Connector", "TinyFish", "native.web"),
        "multilingual": ("native.web", "TinyFish", "Exa", "Firecrawl"),
        "personal_knowledge": ("Notion", "Google_Drive"),
        "signed_in_personalized_surface": ("Opera_Browser_Connector", "TinyFish"),
        "delegation": ("ChatGPT.Work.subagent", "Codex.subagent", "Manus", "host_model"),
        "infrastructure_delegation": ("Railway", "host_model"),
        "automation": ("ChatGPT.Automations",),
        "design": ("Figma", "Canva", "host_model"),
        # Outcome-bearing families. Without these, an outcome request drew only
        # search actions and the turn could "succeed" having produced nothing.
        # The two lineages named partly different bodies; the union is kept, because
        # a body is only ever selected when its own evidence backs it, and a wider
        # preference list is exactly what the failover path needs somewhere to go.
        "state_write": ("Notion", "Google_Drive", "Figma", "Canva", "Coda"),
        "schedule": ("Google_Calendar", "Notion"),
        "presence": ("Opera_Browser_Connector", "TinyFish", "Metricool", "host_model"),
        "transform": ("host_model", "container"),
    }

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "actions.json"
        self.results_path = self.root / "results.jsonl"
        self.bodies = BodyFederationRegistry(self.root / "bodies.json")
        # Capabilities the observed host surface explicitly declared non-callable.
        # An explicit "I probed this and it is unavailable" is stronger evidence than
        # "no exact body was found", so no fallback may quietly substitute another
        # body for these. Set by the caller from the loaded capability surface.
        self.declared_unavailable: frozenset[str] = frozenset()
        self._planning_requirement_rows: tuple[dict[str, Any], ...] = ()
        self._planning_release_turn_id: str = ""
        if not self.path.exists():
            self.path.write_text(json.dumps({"version": 1, "actions": {}}, indent=2) + "\n", encoding="utf-8")
        self.results_path.touch(exist_ok=True)

    def search_coverage(self, release_turn_id: str) -> dict[str, Any]:
        data=self._read()
        rows=[dict(x) for x in (data.get("actions") or {}).values()
              if str(x.get("release_turn_id") or "")==str(release_turn_id)
              and bool(x.get("required")) and str(x.get("capability") or "").startswith("search:")]
        required=[]; satisfied=[]; failed=[]
        evidence: dict[str,list[str]]={}
        for row in rows:
            family=str(row.get("family") or str(row.get("capability") or "").split(":",1)[-1])
            if family not in required: required.append(family)
            state=str(row.get("state") or "")
            if state=="succeeded" and family not in satisfied: satisfied.append(family)
            elif state=="failed" and family not in failed: failed.append(family)
            evidence.setdefault(family,[])
            ref=str(row.get("result_observation_sha256") or row.get("request_sha256") or "")
            if ref: evidence[family].append(ref)
        open_families=[x for x in required if x not in satisfied]
        report={
            "schema":"jigaewol_search_swarm_coverage_v1",
            "release_turn_id":str(release_turn_id),
            "required_families":required,
            "satisfied_families":satisfied,
            "failed_families":failed,
            "open_families":open_families,
            "complete":bool(required) and not open_families,
            "single_family_success_may_not_close_multi_family_search":True,
            "evidence_by_family":evidence,
        }
        out_dir=self.root/"search_coverage"; out_dir.mkdir(parents=True,exist_ok=True)
        out=out_dir/f"{release_turn_id}.json"
        tmp=out.with_suffix('.tmp'); tmp.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8'); tmp.replace(out)
        return report

    @staticmethod
    def _sha(payload: Mapping[str, Any]) -> str:
        raw = json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def route_organ_effect(self, *, release_turn_id: str, genome_id: str, capability: str,
                           payload: dict[str, Any], required: bool = True,
                           preferred_executors: Iterable[str] = (),
                           host_connections: Iterable[Mapping[str, Any] | str] = ()) -> CanonicalHostAction:
        """Route an effect requested by a generated organ without collapsing it to a tool name.

        The organ may invent the capability name, input/output relation and host-connection
        description.  Those connection descriptions are preserved verbatim in the action rather
        than rewritten as an ordinary predeclared route.  If no currently observed body implements
        the invented effect, the action remains a required unbound invention request; lack of an
        existing body is not treated as proof that the capability ontology is closed.

        A returned host result is still the evidence boundary for claiming that an external effect
        occurred.  That is an execution-truth condition, not a rewrite of the organ's requested
        capability or connection semantics.
        """
        normalized_connections = []
        for row in host_connections:
            normalized_connections.append(dict(row) if isinstance(row, Mapping) else {"kind": "declared_connection", "target": str(row)})
        organ_payload = dict(payload)
        organ_payload["organogenesis"] = {
            "genome_id": str(genome_id),
            "invented_capability": str(capability),
            "body_on_demand": True,
            "predeclared_tool_name_is_not_the_capability_boundary": True,
            "host_connections": tuple(normalized_connections),
            "preserve_nonstandard_connection_semantics": True,
        }
        organ_payload.setdefault("family_substitution_allowed", False)
        return self.route_effect(
            release_turn_id=release_turn_id,
            capability=capability,
            payload=organ_payload,
            required=required,
            preferred_executors=preferred_executors,
        )

    def route_effect(self, *, release_turn_id: str, capability: str, payload: dict[str, Any],
                     required: bool = True, zero_cost_only: bool = False,
                     preferred_executors: Iterable[str] = ()) -> CanonicalHostAction:
        """Narrow effect-port API used by the causal loop.

        The caller/runtime decides *what* effect is needed.  This bridge only routes
        the exact request to an observed body and keeps the durable evidence boundary.
        """
        capability_text = ("media:image_generate" if ImageSovereigntyPolicy.is_image_capability(capability)
                           else str(capability))
        family = capability_text.split(":", 1)[0] or "host"
        # Search capabilities encode their sensor family after the namespace
        # (search:web_current, search:code_ecosystem, ...).  Preserve that
        # semantic family so search observations reach the durable SearchRunBridge
        # instead of being flattened to the generic literal "search".
        if capability_text.startswith("search:"):
            search_family = capability_text.split(":", 1)[1].split(":", 1)[0].strip()
            if search_family in self.EXECUTORS:
                family = search_family
        preferred = tuple(preferred_executors) or tuple(self.EXECUTORS.get(family, ()))
        return self._add(
            release_turn_id=release_turn_id, capability=capability_text, family=family,
            preferred_executors=preferred, payload=dict(payload), required=bool(required),
            zero_cost_only=bool(zero_cost_only),
        )

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _infer_requirement_ids(*, capability: str, family: str, requirements: Iterable[Mapping[str, Any]]) -> tuple[str, ...]:
        """Conservatively bind an action to source atoms it can actually serve.

        This is intentionally a narrow router, not a semantic completion engine.  If
        an atom does not clearly match this action family it stays unbound/unplanned.
        """
        cap = str(capability or "").casefold()
        fam = str(family or "").casefold()
        rows = [dict(r) for r in requirements if isinstance(r, Mapping)]
        out: list[str] = []
        acquisition_markers = ("플러그인", "plugin", "오픈소스", "open source", "github", "깃허브", "skill", "스킬", "도구", "tool", "연결", "connect", "설치", "install", "가져와", "acquire")
        browser_markers = ("브라우저", "browser", "사이트", "website", "페이지", "click", "클릭", "로그인", "login", "navigate", "접속")
        delegation_markers = ("에이전트", "agent", "worker", "워커", "subagent", "하위 에이전트", "병렬", "parallel")
        write_markers = ("수정", "고쳐", "작성", "저장", "만들", "구현", "write", "edit", "modify", "create", "implement", "build")
        for row in rows:
            atom_id = str(row.get("atom_id") or "")
            text = str(row.get("text") or "")
            if not atom_id or not text:
                continue
            low = text.casefold()
            kind = str(row.get("kind") or "")
            traits = set(infer_required_traits(text))
            analysis = IntentDeepAnalyzer().analyze(text)
            match = False
            if fam == "compute" or cap.startswith("compute:"):
                match = bool(traits & {"code_execution", "terminal", "filesystem", "remote_computer", "remote_compute", "persistent_workspace"})
                if not match and kind == "action":
                    match = any(x in low for x in write_markers) and any(x in low for x in ("코드", "파일", "테스트", "실행", "code", "file", "test", "run"))
            elif fam == "capability" or cap.startswith("capability:"):
                match = kind == "action" and any(x in low for x in acquisition_markers)
            elif fam == "browser" or cap.startswith("browser:"):
                match = any(x in low for x in browser_markers) or bool(traits & {"browser", "interaction", "authenticated_session"})
            elif fam in {"delegation", "infrastructure_delegation"} or "delegate" in cap:
                match = kind == "action" and any(x in low for x in delegation_markers)
            elif cap.startswith("search:") or fam in CanonicalHostBridge.EXECUTORS:
                source_families = set(getattr(analysis, "inferred_source_families", ()) or ())
                search_required = bool(getattr(analysis, "inferred_search_required", False))
                match = search_required and (fam in source_families or not source_families)
                if fam == "code_ecosystem" and any(x in low for x in ("github", "깃허브", "오픈소스", "repository", "repo")):
                    match = True
                if fam == "personal_knowledge" and any(x in low for x in ("노션", "notion", "drive", "드라이브", "내 자료", "개인 자료")):
                    match = True
            elif fam in {"state_write", "transform", "design", "schedule", "presence"}:
                if kind == "action":
                    family_markers = {
                        "state_write": write_markers,
                        "transform": ("변환", "정리", "재생성", "dedupe", "transform"),
                        "design": ("디자인", "figma", "canva", "화면", "design"),
                        "schedule": ("일정", "캘린더", "calendar", "schedule"),
                        "presence": ("게시", "포스트", "publish", "social", "SNS", "인스타", "twitter", "x"),
                    }
                    match = any(x.casefold() in low for x in family_markers[fam])
            if match and atom_id not in out:
                out.append(atom_id)
        return tuple(out)

    def _bind_requirement_payload(self, *, release_turn_id: str, capability: str, family: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        enriched = dict(payload)
        if str(release_turn_id) != self._planning_release_turn_id or not self._planning_requirement_rows:
            return enriched
        if enriched.get("requirement_ids"):
            return enriched
        ids = self._infer_requirement_ids(capability=capability, family=family, requirements=self._planning_requirement_rows)
        if not ids:
            return enriched
        enriched["requirement_ids"] = list(ids)
        hashes = {str(r.get("parent_message_sha256") or "") for r in self._planning_requirement_rows if str(r.get("atom_id") or "") in set(ids)}
        hashes.discard("")
        if len(hashes) == 1:
            enriched["requirement_message_sha256"] = next(iter(hashes))
        return enriched

    def _add(self, *, release_turn_id: str, capability: str, family: str,
             preferred_executors: Iterable[str], payload: dict[str, Any], required: bool,
             zero_cost_only: bool) -> CanonicalHostAction:
        payload = self._bind_requirement_payload(
            release_turn_id=release_turn_id, capability=capability, family=family, payload=payload
        )
        if ImageSovereigntyPolicy.is_image_capability(capability):
            governance = dict(payload.get("image_generation_governance") or {})
            sovereignty = dict(payload.get("image_sovereignty_contract") or governance.get("sovereignty_contract") or {})
            token = str(payload.get("image_sovereignty_token") or sovereignty.get("authority_token") or "")
            source_text = str(governance.get("prompt_source_text") or payload.get("objective") or "")
            mode = str(payload.get("mode") or governance.get("mode") or "generate")
            should_invoke = bool(governance.get("should_invoke", True))
            if not should_invoke:
                raise PermissionError("inactive image contract cannot authorize image generation")
            if not sovereignty or token != str(sovereignty.get("authority_token") or ""):
                raise RuntimeError("image sovereignty token missing from canonical image action")
            if not ImageSovereigntyPolicy.validate(
                sovereignty, source_text=source_text, mode=mode, should_invoke=should_invoke
            ):
                raise RuntimeError("image sovereignty contract invalid for canonical image action")
            payload = {
                **dict(payload),
                "image_sovereignty_contract": sovereignty,
                "image_sovereignty_token": token,
                "generator_role": "render_only",
                "zip_final_review_required": True,
                "generator_may_not_self_certify_quality": True,
            }
        # Privacy minimization must be recursive.  A top-level redacted objective is
        # a strong signal that nested query programs/strategy payloads belong to the
        # same privacy turn; sanitize *before* hashing/persisting the action.
        objective_value = str(payload.get("objective") or "") if isinstance(payload, Mapping) else ""
        privacy_row = dict(payload.get("privacy_minimization") or {}) if isinstance(payload, Mapping) and isinstance(payload.get("privacy_minimization"), Mapping) else {}
        privacy_active = bool(privacy_row.get("active")) or objective_value.startswith("[privacy-minimized objective sha256:")
        if privacy_active:
            payload = dict(PrivacyMinimizationPolicy.minimize_payload_recursive(
                payload, decision={
                    "minimize_host_payload_plaintext": True,
                    "boundary": privacy_row.get("boundary") or "runtime_minimization_active",
                },
            ))
        data = self._read()
        request_material = {
            "release_turn_id": str(release_turn_id), "capability": capability, "family": family,
            "preferred_executors": tuple(preferred_executors), "payload": payload,
            "required": bool(required), "zero_cost_only": bool(zero_cost_only),
        }
        request_sha = self._sha(request_material)
        for row in data.get("actions", {}).values():
            if row.get("request_sha256") == request_sha:
                return CanonicalHostAction(**row)
        route = self.bodies.route(
            capability,
            preferred_executors=preferred_executors,
            zero_cost_only=zero_cost_only,
            max_age_seconds=1800.0,
            allow_stale_revalidation=True,
        )
        # Open sensor families are not forced into a closed registry.  If an invented
        # public-search family has no exact body binding, reuse a currently observed
        # generic web-search body while preserving the invented family on the action.
        explicitly_unavailable = str(capability) in self.declared_unavailable
        if (not route.selected_body_id and str(capability).startswith("search:")
                and str(family) not in {"personal_knowledge", "social_recommendation"}
                and not explicitly_unavailable):
            fallback = self.bodies.route(
                "search:web_current", preferred_executors=preferred_executors,
                zero_cost_only=zero_cost_only, max_age_seconds=1800.0,
                allow_stale_revalidation=True,
            )
            if fallback.selected_body_id:
                route = fallback
        # Open-ended late binding: exact capability names are preferred, but the
        # current registry is not treated as the ontology of all possible work.
        # A same-family callable body may receive the request; the later observed
        # host receipt, not this fallback, proves whether it actually worked.
        # Family membership is not semantic equivalence.  A provider proven for
        # one family-scoped effect (for example infrastructure delegation) must not
        # silently satisfy a different exact capability (for example general
        # cognition delegation).  Open-ended search handles an unbound exact request
        # by constructing/discovering another path; family substitution is used only
        # when the live request explicitly declares that effect equivalence.
        family_substitution_allowed = bool(payload.get("family_substitution_allowed"))
        if (not route.selected_body_id and family_substitution_allowed
                and not explicitly_unavailable):
            family_fallback = self.bodies.route_family(
                str(family), preferred_executors=preferred_executors,
                zero_cost_only=zero_cost_only, max_age_seconds=1800.0,
                allow_stale_revalidation=True,
            )
            if family_fallback.selected_body_id:
                route = family_fallback
        body_map = {b.body_id: b for b in self.bodies.bodies()}
        fallback_body_ids = tuple(
            body_id for body_id in route.eligible_body_ids
            if body_id and body_id != route.selected_body_id and body_id in body_map
        )
        fallback_executors = tuple(dict.fromkeys(
            body_map[body_id].executor for body_id in fallback_body_ids
            if str(body_map[body_id].executor).strip() and body_map[body_id].executor != route.selected_executor
        ))
        # A bound body proves availability, not permission.  Optional/derived routes
        # stay reserved and are never dispatchable until exact-source effect authority
        # makes the action required.
        action_state = "pending" if bool(required) else "reserved_unbound"
        action = CanonicalHostAction(
            action_id="hostact_" + uuid.uuid4().hex[:18], release_turn_id=str(release_turn_id),
            capability=str(capability), family=str(family), preferred_executors=tuple(preferred_executors),
            selected_body_id=route.selected_body_id, selected_executor=route.selected_executor,
            zero_cost_only=bool(zero_cost_only), required=bool(required), payload=dict(payload),
            request_sha256=request_sha, state=action_state, created_at=time.time(),
            binding_state=str(route.route_state),
            revalidation_required=str(route.route_state) == "selected_stale_requires_revalidation",
            fallback_body_ids=fallback_body_ids, fallback_executors=fallback_executors,
        )
        data.setdefault("actions", {})[action.action_id] = asdict(action)
        self._write(data)
        return action

    def _add_resolved_authority_action(self, *, release_turn_id: str, capability: str,
                                       payload: Mapping[str, Any]) -> CanonicalHostAction:
        """Persist a non-dispatchable authority decision as a resolved host-action record."""
        data = self._read()
        request_material = {
            "release_turn_id": str(release_turn_id),
            "capability": str(capability),
            "family": "authority",
            "preferred_executors": (),
            "payload": dict(payload),
            "required": False,
            "zero_cost_only": True,
        }
        request_sha = self._sha(request_material)
        for row in data.get("actions", {}).values():
            if row.get("request_sha256") == request_sha:
                return CanonicalHostAction(**row)
        action = CanonicalHostAction(
            action_id="hostact_" + uuid.uuid4().hex[:18],
            release_turn_id=str(release_turn_id),
            capability=str(capability),
            family="authority",
            preferred_executors=(),
            selected_body_id="",
            selected_executor="",
            zero_cost_only=True,
            required=False,
            payload=dict(payload),
            request_sha256=request_sha,
            state="resolved",
            created_at=time.time(),
            binding_state="authority_gate",
        )
        data.setdefault("actions", {})[action.action_id] = asdict(action)
        self._write(data)
        return action

    def bind_planning_requirements(self, *, release_turn_id: str, requirements: Iterable[Mapping[str, Any]]) -> None:
        self._planning_release_turn_id = str(release_turn_id)
        self._planning_requirement_rows = tuple(dict(x) for x in requirements if isinstance(x, Mapping))

    def plan_for_turn(self, *, release_turn_id: str, command: str, strategy_topology: Mapping[str, Any],
                      cognitive_os: Mapping[str, Any] | None = None,
                      exploration_decision: Mapping[str, Any] | None = None,
                      exploration_operator_ids: Iterable[str] = (),
                      requirement_ids: Iterable[str] = (),
                      requirements: Iterable[Mapping[str, Any]] = (),
                      active_invariants: Iterable[Mapping[str, Any]] = (),
                      semantic_authority: Mapping[str, Any] | None = None,
                      image_generation_governance: Mapping[str, Any] | None = None,
                      wild_cognitive_plan: Mapping[str, Any] | None = None,
                      zero_cost_only: bool = False) -> tuple[CanonicalHostAction, ...]:
        self.bind_planning_requirements(release_turn_id=release_turn_id, requirements=requirements)
        authority = bind_semantic_authority(command, semantic_authority)
        objective = source_bound_objective(command, authority) if authority else str(command)
        current_effect_authorized = source_effect_authorized(authority)
        privacy = dict(authority.get("privacy_minimization") or {}) if authority else PrivacyMinimizationPolicy.evaluate(command).as_mapping()
        external_tools_disallowed = bool(privacy.get("external_tools_disallowed"))
        payload_objective = (PrivacyMinimizationPolicy.objective_ref(objective)
                             if privacy.get("minimize_host_payload_plaintext") else objective)
        if authority:
            analysis = None
            search_required = bool(authority.get("search_required"))
            external_capability_required = bool(authority.get("external_capability_required"))
            signed_in_browser_preferred = bool(authority.get("signed_in_browser_preferred"))
            public_browser_interaction_required = bool(authority.get("public_browser_interaction_required"))
            source_families = tuple(authority.get("source_families") or ())
            # Derived execution/search/trait classifiers are advisory.  Only the
            # exact-source bound authority bit can grant actuation.
            execution_requested = current_effect_authorized
        else:
            analysis = IntentDeepAnalyzer().analyze(objective)
            search_required = bool(analysis.inferred_search_required)
            external_capability_required = bool(analysis.inferred_external_capability_required)
            signed_in_browser_preferred = bool(analysis.inferred_signed_in_browser_preferred)
            public_browser_interaction_required = _public_browser_interaction_materially_required(command)
            source_families = tuple(analysis.inferred_source_families)
            execution_requested = False
        selected = set(map(str, strategy_topology.get("selected") or ()))
        os_plan = dict(cognitive_os or {})
        os_routes = {str(r.get("route_id") or "") for r in os_plan.get("routes") or () if isinstance(r, Mapping)}
        os_sensor_families = tuple(str(x) for x in os_plan.get("sensor_families") or () if str(x).strip())
        actions: list[CanonicalHostAction] = []
        invariant_families = {str(x.get("family") or "") for x in active_invariants if isinstance(x, Mapping)}
        folded_command = objective.casefold()
        reference_markers = ("레퍼런스", "reference", "참고 이미지", "이미지처럼", "저 페이지", "저런 화면", "목업")
        implementation_markers = ("구현", "만들", "디자인", "노션", "화면", "페이지", "mockup", "implement", "build")
        implementation_requested = execution_requested if authority else any(x in folded_command for x in implementation_markers)
        reference_work = (
            "reference_implementation_drift" in invariant_families
            and implementation_requested
        ) or (
            any(x in folded_command for x in reference_markers)
            and implementation_requested
        )
        if reference_work:
            actions.append(self._add(
                release_turn_id=release_turn_id, capability="design:reference_deconstruct", family="design",
                preferred_executors=(("host_model",) if external_tools_disallowed else self.EXECUTORS["design"]), required=current_effect_authorized, zero_cost_only=zero_cost_only,
                payload={
                    "objective": payload_objective,
                    "reference_fidelity_required": True,
                    "extract": [
                        "layout_geometry", "visual_hierarchy", "calendar_scale", "image_role",
                        "typography_density", "asymmetry", "database_view_role", "mobile_behavior",
                    ],
                    "prohibited_defaults": [
                        "generic_equal_card_grid", "invented_sentimental_copy",
                        "small_calendar_when_calendar_is_reference_anchor", "unobserved_kawaii_sticker_fill",
                    ],
                    "required_output": "reference_to_implementation_spec",
                    "observed_host_receipt_required": True,
                },
            ))
            if not external_tools_disallowed:
                actions.append(self._add(
                    release_turn_id=release_turn_id, capability="search:code_ecosystem", family="code_ecosystem",
                    preferred_executors=self.EXECUTORS["code_ecosystem"], required=current_effect_authorized, zero_cost_only=zero_cost_only,
                    payload={
                        "objective": payload_objective,
                        "implementation_sources_required": True,
                        "license_check_required": True,
                        "reference_to_code_translation": True,
                    },
                ))
                actions.append(self._add(
                    release_turn_id=release_turn_id, capability="search:personal_knowledge", family="personal_knowledge",
                    preferred_executors=self.EXECUTORS["personal_knowledge"], required=current_effect_authorized, zero_cost_only=zero_cost_only,
                    payload={
                        "objective": payload_objective,
                        "reuse_existing_user_research": True,
                        "source_of_truth": "connected personal knowledge before generic reconstruction",
                    },
                ))
        required_traits = set(authority.get("required_capability_traits") or ()) if authority else set(infer_required_traits(objective))
        denied_capabilities = set(authority.get("denied_capabilities") or ()) if authority else set()
        explicit_permissions = set(authority.get("explicit_permissions") or ()) if authority else set()
        capability_need_descriptions = tuple(authority.get("capability_need_descriptions") or ()) if authority else ()
        unclassified_capability_requests = tuple(authority.get("unclassified_capability_requests") or ()) if authority else ()
        execution_traits = required_traits & {
            "code_execution", "terminal", "filesystem", "remote_computer",
            "remote_compute", "persistent_workspace",
        }
        image_decision = dict(image_generation_governance or {})
        if image_decision.get("should_invoke") and not external_tools_disallowed:
            actions.append(self._add(
                release_turn_id=release_turn_id, capability="media:image_generate", family="media",
                preferred_executors=tuple(image_decision.get("preferred_executors") or ("image_gen", "Higgsfield", "Canva")),
                payload={
                    "objective": payload_objective,
                    "image_generation_governance": image_decision,
                    "image_sovereignty_contract": dict(image_decision.get("sovereignty_contract") or {}),
                    "image_sovereignty_token": str(dict(image_decision.get("sovereignty_contract") or {}).get("authority_token") or ""),
                    "generator_role": "render_only",
                    "zip_final_review_required": True,
                    "mode": str(image_decision.get("mode") or "generate"),
                    "target_refs": list(image_decision.get("target_refs") or ()),
                    "requirement_ids": list(image_decision.get("requirement_ids") or ()),
                    "requirement_message_sha256": str(image_decision.get("source_message_sha256") or ""),
                    "exact_source_prompt_preserved": True,
                    "observed_host_receipt_required": True,
                    "reobserve_output_required": bool(image_decision.get("reobserve_generated_output", True)),
                },
                required=bool(current_effect_authorized), zero_cost_only=zero_cost_only,
            ))
        if execution_traits or "execution_experiment_loop" in selected:
            # Model-independent Actuation Gate: execution is decided from canonical
            # source authority only.  Different host/model interpretations may propose
            # execution, but they cannot alter this deterministic permission result.
            exec_allowed, exec_reason, exec_fingerprint = capability_authorization(authority, "code_execution")
            authority_gate = {
                "capability": "code_execution",
                "allowed": exec_allowed,
                "reason": exec_reason,
                "decision_sha256": exec_fingerprint,
                "model_identity_ignored": True,
            }
            if exec_reason == "explicit_user_prohibition":
                actions.append(self._add_resolved_authority_action(
                    release_turn_id=release_turn_id,
                    capability="authority_conflict",
                    payload={
                        "objective": payload_objective,
                        "denied_capability": "code_execution",
                        "reason": exec_reason,
                        "authority_gate": authority_gate,
                    },
                ))
            elif not exec_allowed:
                actions.append(self._add_resolved_authority_action(
                    release_turn_id=release_turn_id,
                    capability="no_permission",
                    payload={
                        "objective": payload_objective,
                        "missing_permission": "code_execution",
                        "reason": exec_reason,
                        "authority_gate": authority_gate,
                    },
                ))
            else:
                remote_required = bool({"remote_computer", "remote_compute"} & required_traits)
                compute_capability = "compute:remote_exec" if remote_required else "compute:exec"
                actions.append(self._add(
                    release_turn_id=release_turn_id, capability=compute_capability, family="compute",
                    preferred_executors=(("jigaewol_local_runtime", "container") if external_tools_disallowed else ("Floot", "container", "Railway", "Hatchable", "GitHub")),
                    payload={
                        "objective": payload_objective,
                        "required_traits": sorted(execution_traits or {"code_execution"}),
                        "remote_execution_required": remote_required,
                        "execution_cell_semantics": "lease or compose observed cells; one immortal machine is not required",
                        "persistent_state_may_live_separately_from_compute": True,
                        "actual_execution_requires_observed_receipt": True,
                        "provider_hints_are_non_exhaustive": True,
                        "authority_gate": authority_gate,
                    },
                    required=True, zero_cost_only=zero_cost_only,
                ))
        direct_private_retrieval_required = "personal_knowledge" in set(source_families)
        if (not external_tools_disallowed) and (
            search_required or direct_private_retrieval_required
            or "research_mesh" in selected or "route_sensor_mesh" in os_routes
        ):
            # Canonical semantic authority owns which source families are materially
            # required *now*.  CognitiveOS may keep a much wider sensor ecology alive
            # as possibility reserve, but merely existing in that reserve must not turn
            # every family into an immediate required host call.  This preserves the
            # open-world ontology without repeating the old “research_mesh => search
            # everything” execution overtrigger.
            # Semantic source-family hints do not become required host searches unless
            # this turn actually requires search.  When research_mesh is open only as
            # a possibility reserve, keep both semantic and CognitiveOS families as
            # optional reserve lanes rather than manufacturing immediate required calls.
            if search_required:
                primary_families = tuple(dict.fromkeys(source_families))
            else:
                # A named private corpus (Notion/Drive/etc.) is an explicit retrieval
                # target, but it must not be mislabeled as public-web search.
                primary_families = tuple(
                    family for family in dict.fromkeys(source_families)
                    if family == "personal_knowledge"
                )
            if not primary_families and search_required:
                primary_families = ("first_party", "web_current")
            reserve_seed = tuple(dict.fromkeys((*source_families, *os_sensor_families)))
            reserve_families = tuple(
                x for x in reserve_seed if x not in set(primary_families)
            )
            scheduled_families = tuple((x, True) for x in primary_families) + tuple((x, False) for x in reserve_families)
            for family, family_required in scheduled_families:
                program = SearchPortfolioEngine.compile_query_program(objective, family)
                payload = {
                    "objective": payload_objective,
                    "source_family": family,
                    "query_program": program,
                    "recursive_followup_required": True,
                    "observed_term_requery_required": True,
                    "hunt_id": "hunt_" + self._sha({"turn": release_turn_id, "family": family, "objective": payload_objective})[:18],
                    "hunt_frontier_must_persist": True,
                    "stop_condition": "saturation_or_observed_hard_boundary_or_user_stop_not_query_count",
                    "blocked_lane_remains_open_debt": True,
                    "native_vernacular_meme_slang_queries_allowed": True,
                    "scheduling_state": "primary_required" if family_required else "possibility_reserve",
                    "reserve_is_not_ontology_deletion": not family_required,
                }
                if family == "personal_knowledge":
                    payload.update({
                        "corpus_hint": "the user-explicit personal corpus when one is named",
                        "retrieval_order": [
                            "broad_private_index_or_saved_view",
                            "precise_canonical_record_fetch",
                            "external_recheck_only_for_freshness_rights_provenance_or_gaps",
                        ],
                        "private_corpus_is_prior_work_not_a_whitelist": True,
                    })
                actions.append(self._add(
                    release_turn_id=release_turn_id,
                    capability=f"search:{family}", family=family,
                    preferred_executors=self.EXECUTORS.get(family, ("native.web", "TinyFish")),
                    payload=payload,
                    required=bool(family_required and current_effect_authorized), zero_cost_only=zero_cost_only,
                ))
        if (not external_tools_disallowed) and (external_capability_required or unclassified_capability_requests or "execution_experiment_loop" in selected or "route_dynamic_acquisition" in os_routes):
            actions.append(self._add(
                release_turn_id=release_turn_id, capability="capability:discover_execute", family="capability",
                preferred_executors=("Plugin_Management", "GitHub", "container"),
                payload={
                    "objective": payload_objective,
                    "capability_need_descriptions": list(capability_need_descriptions),
                    "unclassified_capability_requests": list(unclassified_capability_requests),
                    "unknown_sources_allowed": True,
                    "readme_is_not_execution": True,
                    "capability_source_order": [
                        "USER_EXPLICIT_PERSONAL_CORPUS",
                        "installed_agent_skills",
                        "connected_plugins_and_bodies",
                        "github_open_source",
                        "open_web",
                    ],
                    "agent_skill_standard": "SKILL.md",
                    "translate_provider_specific_surfaces": True,
                    "capability_agenda": [
                        "discover", "inspect", "bind_or_materialize_as_needed", "execute", "observe", "promote_if_useful"
                    ],
                    "external_connection_step": "surface_only_when_the_selected_provider_reports_a_real_connection_requirement",
                    "provider_names_are_bindings_not_ontology": True,
                    "current_capability_surface_is_not_ceiling": True,
                    "unknown_candidate_default": "inspect_and_keep_open",
                    "installed_host_surface_first": True,
                    "plugin_directory_then_open_source_then_generated_tool": True,
                    "materialization_state_machine_required": True,
                    "untrusted_code_execution_requires_isolation_class": "kernel_or_vm_isolated",
                    "local_weak_isolation_is_inspection_only_for_untrusted_code": True,
                    "candidate_route_failure_keeps_goal_live": True,
                },
                required=bool(current_effect_authorized and (external_capability_required or unclassified_capability_requests)),
                zero_cost_only=zero_cost_only,
            ))
        if (not external_tools_disallowed) and public_browser_interaction_required:
            actions.append(self._add(
                release_turn_id=release_turn_id, capability="browser:interact", family="browser",
                preferred_executors=("TinyFish", "Opera_Browser_Connector", "native.web"),
                payload={
                    "objective": payload_objective,
                    "interaction_mode": "public_web_ui",
                    "authenticated_state_required": False,
                    "direct_url_navigation_allowed": True,
                    "observed_browser_receipt_required": True,
                    "mutation_requires_separate_explicit_action": True,
                },
                required=current_effect_authorized, zero_cost_only=zero_cost_only,
            ))
        if (not external_tools_disallowed) and (signed_in_browser_preferred or "route_signed_in_perception" in os_routes):
            actions.append(self._add(
                release_turn_id=release_turn_id, capability="browser:signed_in_observe", family="browser",
                preferred_executors=("Opera_Browser_Connector", "TinyFish"),
                payload={"objective": payload_objective, "interaction_mode": "task_defined", "observation_may_change_recommendation_state": True,
                         "mutation_requires_separate_explicit_action": True},
                required=current_effect_authorized, zero_cost_only=zero_cost_only,
            ))
        if (not external_tools_disallowed) and "route_parallel_delegation" in os_routes:
            actions.append(self._add(
                release_turn_id=release_turn_id, capability="cognition:parallel_delegate", family="delegation",
                preferred_executors=self.EXECUTORS["delegation"],
                payload={
                    "objective": payload_objective,
                    "cells": list(os_plan.get("cells") or ()),
                    "merge_semantics": "merge artifacts/evidence; do not claim hidden chain-of-thought",
                    "actual_parallel_agent_claim_requires_host_receipt": True,
                    "independent_worker_claim_requires_distinct_execution_context_evidence": True,
                    "same_model_roles_are_not_claimed_as_independent_error_distributions": True,
                    "executor_names_are_non_exhaustive_hints": True,
                },
                required=False, zero_cost_only=zero_cost_only,
            ))
        if (
            (not external_tools_disallowed)
            and "deploy" in required_traits
            and ("agent_delegate" in required_traits or "route_parallel_delegation" in os_routes)
        ):
            actions.append(self._add(
                release_turn_id=release_turn_id,
                capability="cognition:domain_delegate_infrastructure",
                family="delegation",
                preferred_executors=self.EXECUTORS["infrastructure_delegation"],
                payload={
                    "objective": payload_objective,
                    "domain_scope": "infrastructure_deployment_only",
                    "generic_cognition_claim_forbidden": True,
                    "actual_agent_claim_requires_host_receipt": True,
                    "result_return_path_required": True,
                },
                required=False, zero_cost_only=zero_cost_only,
            ))
        if (not external_tools_disallowed) and "route_proactive_continuity" in os_routes:
            actions.append(self._add(
                release_turn_id=release_turn_id, capability="automation:continuity", family="automation",
                preferred_executors=self.EXECUTORS["automation"],
                payload={
                    "objective": payload_objective,
                    "semantics": "compile to a real scheduled/conditional actuator only when the user requested ongoing or future work",
                    "no_background_claim_without_actual_automation": True,
                },
                required=False, zero_cost_only=zero_cost_only,
            ))
        exploration = dict(exploration_decision or {})
        # outcome_shape, not task_shape: an open problem may still owe an artifact,
        # and a build request should not have to stop being an open problem to get
        # its write action. The authority's own classification leads; the exploration subsystem
        # decision is the fallback; a task_shape that happens to name an outcome
        # plan is the last resort.
        outcome_shape = str(authority.get("outcome_shape") or "") if authority else ""
        if not outcome_shape:
            outcome_shape = str(exploration.get("outcome_shape") or "")
        if not outcome_shape and str(exploration.get("task_shape") or "") in self.OUTCOME_PLANS:
            outcome_shape = str(exploration.get("task_shape") or "")
        if not external_tools_disallowed:
            actions.extend(self._outcome_actions(
                release_turn_id=release_turn_id, objective=objective, outcome_shape=outcome_shape,
                zero_cost_only=zero_cost_only, required_authorized=current_effect_authorized,
            ))
        if str(exploration.get("state") or "") == "ACTIVE":
            actions.append(self._add(
                release_turn_id=release_turn_id, capability="cognition:exploration_generate", family="exploration",
                preferred_executors=(("host_model",) if external_tools_disallowed else ("host_model", "ChatGPT.Work.subagent", "Codex.subagent", "Manus")),
                payload={
                    "objective": payload_objective,
                    "privacy_minimization": privacy,
                    "exploration_decision": exploration,
                    "operator_ids": list(dict.fromkeys(str(x) for x in exploration_operator_ids if str(x))),
                    "strategy_portfolio": self.strategy_bundle(payload_objective if external_tools_disallowed else command),
                    "wild_cognitive_program": dict(wild_cognitive_plan or {}),
                    "wild_probe_contract": {
                        "baseline_required": bool(dict(wild_cognitive_plan or {}).get("synthesis_gate", {}).get("baseline_required", True)),
                        "minimum_tested_divergent_lanes": int(dict(wild_cognitive_plan or {}).get("synthesis_gate", {}).get("minimum_tested_divergent_lanes", 3)),
                        "lane_ids": [str(x.get("lane_id") or "") for x in dict(wild_cognitive_plan or {}).get("lanes", ()) if isinstance(x, Mapping) and str(x.get("lane_id") or "")],
                        "execution_truth_required": True,
                        "observed_probe_results_required_for_synthesis": True,
                        "same_frame_duplicates_do_not_count": True,
                    },
                    "operator_seeds_not_closed_set": True,
                    "ephemeral_operator_invention_allowed": True,
                    "ephemeral_operator_contract": {
                        "id_prefix": "ephemeral:",
                        "must_state_destroyed_assumption_or_new_information_ecology": True,
                        "must_not_self_promote": True,
                        "return_still_requires_causal_proof": True,
                    },
                    "requirement_ids": list(dict.fromkeys(str(x) for x in requirement_ids if str(x))),
                    "protocol": "baseline/intervention/counterfactual or observed implementation delta; full scratch must not reenter mainline",
                    "return_contract": {
                        "results_only": True,
                        "causal_proof_required": True,
                        "novelty_alone_is_insufficient_for_mainline": True,
                        "non_returned_but_potentially_exaptive_artifacts_may_enter_stepping_stone_archive": True,
                        "current_turn_utility_is_not_required_for_speculative_survival": True,
                        "truth_or_superiority_not_implied": True,
                    },
                },
                # Exploration remains fully available to reasoning, but does not
                # become a host side effect solely because an open-problem classifier
                # fired.
                required=False, zero_cost_only=zero_cost_only,
            ))

        # Required work may never terminate at "no body is connected".  An unbound
        # action is an acquisition *input*, not a final diagnosis.  Compile a
        # materialization action that can search installed plugins, open source, or
        # the local execution body and then retry/rebind the orphaned action.  This
        # intentionally excludes the host-semantic exploration request: external actuator
        # closure and host-model cognition are separate truth domains.
        orphaned_required = [
            a for a in actions
            if a.required
            and not a.selected_executor
            and a.family != "exploration"
            and a.capability != "capability:discover_execute"
        ]
        if orphaned_required and not external_tools_disallowed:
            actions.append(self._add(
                release_turn_id=release_turn_id,
                capability="capability:discover_execute",
                family="capability",
                preferred_executors=("Plugin_Management", "GitHub", "jigaewol_local_runtime", "container"),
                payload={
                    "objective": payload_objective,
                    "reason": "required_host_action_has_no_current_body_binding",
                    "orphan_action_ids": [a.action_id for a in orphaned_required],
                    "orphan_capabilities": [a.capability for a in orphaned_required],
                    "orphan_families": [a.family for a in orphaned_required],
                    "materialization_protocol": [
                        "inspect_current_and_previous_observed_bodies",
                        "discover_plugin_or_repo_or_generated_adapter",
                        "inspect_license_dependencies_and_effect_boundary",
                        "materialize_or_connect_real_callable_body",
                        "rebind_orphan_action",
                        "execute_and_record_observed_receipt",
                    ],
                    "missing_body_is_not_terminal_diagnosis": True,
                    "route_failure_keeps_goal_live": True,
                    "readme_or_catalog_entry_is_not_execution": True,
                    "materialization_must_end_in_callable_body_or_observed_external_connection_boundary": True,
                },
                required=True,
                zero_cost_only=zero_cost_only,
            ))
        return tuple(actions)

    def pending(self, release_turn_id: str | None = None) -> tuple[CanonicalHostAction, ...]:
        rows = []
        for row in self._read().get("actions", {}).values():
            if row.get("state") != "pending":
                continue
            if release_turn_id and row.get("release_turn_id") != str(release_turn_id):
                continue
            rows.append(CanonicalHostAction(**row))
        return tuple(rows)


    def supersede_turn(self, release_turn_id: str, *, reason: str, superseded_by: str = "") -> dict[str, Any]:
        """Mark still-pending actions from an older turn as non-executable.

        Already observed results remain historical evidence, but no new result may
        be recorded for an action after it has been superseded.
        """
        data = self._read()
        changed = []
        for action_id, row in data.get("actions", {}).items():
            if row.get("release_turn_id") != str(release_turn_id) or row.get("state") not in {"pending", "reserved_unbound"}:
                continue
            row["state"] = "superseded"
            row["superseded_reason"] = str(reason)
            row["superseded_by"] = str(superseded_by)
            row["superseded_at"] = time.time()
            data["actions"][action_id] = row
            changed.append(action_id)
        if changed:
            self._write(data)
        return {
            "release_turn_id": str(release_turn_id),
            "superseded_action_ids": changed,
            "superseded_count": len(changed),
        }

    def supersede_pending_except(self, release_turn_id: str, *, reason: str, superseded_by: str = "") -> dict[str, Any]:
        """Close stale pending actions before a new canonical turn is dispatched.

        This is intentionally narrower than deleting history: succeeded/failed actions
        remain evidence, while only still-pending actions from older release turns are
        made non-executable.
        """
        data = self._read()
        changed: list[str] = []
        releases: set[str] = set()
        for action_id, row in data.get("actions", {}).items():
            if row.get("state") not in {"pending", "reserved_unbound"} or row.get("release_turn_id") == str(release_turn_id):
                continue
            releases.add(str(row.get("release_turn_id") or ""))
            row["state"] = "superseded"
            row["superseded_reason"] = str(reason)
            row["superseded_by"] = str(superseded_by or release_turn_id)
            row["superseded_at"] = time.time()
            data["actions"][action_id] = row
            changed.append(action_id)
        if changed:
            self._write(data)
        return {
            "successor_release_turn_id": str(release_turn_id),
            "superseded_release_turn_ids": tuple(sorted(x for x in releases if x)),
            "superseded_action_ids": tuple(changed),
            "superseded_count": len(changed),
        }

    def _dispatch_surface_hint(self, action: CanonicalHostAction) -> dict[str, Any]:
        """Expose the selected body's observed host-native actions to the outer dispatcher.

        These are *candidates*, not executions and not schema-correct invocations. The
        outer host still resolves the current tool schema and performs the real call.
        Keeping the candidates on the request avoids throwing away the live surface
        information immediately after routing selected the executor.
        """
        bodies = {b.body_id: b for b in self.bodies.bodies()}

        def body_hint(body_id: str) -> dict[str, Any]:
            body = bodies.get(str(body_id or ""))
            if body is None:
                return {}
            evidence = dict(body.evidence or {})
            action_ids = tuple(str(x) for x in evidence.get("action_ids") or () if str(x).strip())
            return {
                "body_id": body.body_id,
                "executor": body.executor,
                "origin_ref": body.origin_ref,
                "observed_at": body.observed_at,
                "host_action_ids": action_ids,
                "host_action_count": len(action_ids),
                "execution_success_not_implied": True,
            }

        selected = body_hint(action.selected_body_id)
        fallbacks = tuple(
            hint for hint in (body_hint(body_id) for body_id in action.fallback_body_ids) if hint
        )
        return {
            "selected": selected,
            "fallbacks": fallbacks,
            "resolve_schema_at_dispatch_time": True,
            "dispatch_contract": "choose one observed host action whose current schema satisfies the canonical payload; execute; return request-bound receipt",
        }

    def export_dispatch_batch(self, release_turn_id: str, *, required_only: bool = False) -> dict[str, Any]:
        actions = [
            x for x in self.pending(release_turn_id)
            if (not required_only or x.required)
        ]
        material = [
            {"action_id": x.action_id, "request_sha256": x.request_sha256, "capability": x.capability}
            for x in actions
        ]
        batch_id = "hostbatch_" + self._sha({"release_turn_id": str(release_turn_id), "actions": material})[:20]
        action_rows = []
        for action in actions:
            row = asdict(action)
            row["dispatch_surface"] = self._dispatch_surface_hint(action)
            action_rows.append(row)
        return {
            "schema": "jigaewol_host_dispatch_batch_v1",
            "batch_id": batch_id,
            "release_turn_id": str(release_turn_id),
            "required_only": bool(required_only),
            "actions": action_rows,
            "execution_truth": "dispatch request only; success requires an observed host receipt",
        }

    def _bind_exploration_return(self, action_row: Mapping[str, Any], evidence: Mapping[str, Any]) -> dict[str, Any]:
        from .cumulative_intent import CumulativeIntentLedger
        from .exploration_return import ObjectiveAnchor, ExplorationResultFilter, ExplorationCandidate
        from .requirement_contract import RequirementCompiler

        release_turn_id = str(action_row.get("release_turn_id") or "")
        turn_path = self.root.parent / "core_turns" / f"{release_turn_id}.json"
        if not turn_path.is_file():
            raise FileNotFoundError(f"core turn state not found for exploration result: {release_turn_id}")
        turn = load_snapshot(turn_path)

        requirement_contract = RequirementCompiler.from_mapping(
            dict(turn.get("requirement_contract") or {})
        )
        requirement_sha256 = str(requirement_contract.message_sha256 or "").strip().lower()
        intent_ledger = CumulativeIntentLedger(
            self.root.parent / "intent" / "cumulative_intent.json"
        )
        exact_objective = intent_ledger.exact_message(requirement_sha256)
        if not exact_objective:
            raise ValueError("canonical_objective_missing")

        recomputed_sha256 = hashlib.sha256(exact_objective.encode("utf-8")).hexdigest()
        command_sha256 = str(turn.get("command_sha256") or "").strip().lower()
        semantic_sha256 = str(
            dict(turn.get("semantic_authority") or {}).get("message_sha256") or ""
        ).strip().lower()

        if recomputed_sha256 != command_sha256:
            raise ValueError("core_turn_command_sha256_mismatch")
        if recomputed_sha256 != requirement_sha256:
            raise ValueError("requirement_contract_sha256_mismatch")
        if recomputed_sha256 != semantic_sha256:
            raise ValueError("semantic_authority_sha256_mismatch")

        req_ids = tuple(atom.atom_id for atom in requirement_contract.atoms if atom.atom_id)
        anchor = ObjectiveAnchor(
            recomputed_sha256,
            exact_objective,
            req_ids,
        )
        anchor.validate()
        raw_candidates = evidence.get("results") or ()
        if not isinstance(raw_candidates, (list, tuple)):
            raise ValueError("Open Exploration evidence results must be a list")
        candidates = []
        for raw in raw_candidates:
            if not isinstance(raw, Mapping):
                raise ValueError("Open Exploration return candidate must be an object")
            candidates.append(ExplorationCandidate.build(
                run_id=str(raw.get("run_id") or evidence.get("run_id") or "host_exploration"),
                operator_id=str(raw.get("operator_id") or "host_exploration"),
                requirement_bindings=tuple(raw.get("requirement_bindings") or req_ids),
                payload=str(raw.get("payload") or ""),
                causal_delta=dict(raw.get("causal_delta") or {}),
                causal_proof=dict(raw.get("causal_proof") or {}),
                evidence_state=str(raw.get("evidence_state") or "probed"),
                evidence_refs=tuple(raw.get("evidence_refs") or ()),
            ))
        verdict = ExplorationResultFilter.adjudicate(anchor=anchor, candidates=candidates)
        mapping = {
            "run_id": str(evidence.get("run_id") or "host_exploration"),
            "state": "RETURNED" if verdict.accepted else "CLOSED",
            "operator_ids": tuple(str(x) for x in dict(action_row.get("payload") or {}).get("operator_ids") or ()),
            "seed_operator_ids": tuple(str(x) for x in dict(action_row.get("payload") or {}).get("operator_ids") or ()),
            "returned_operator_ids": tuple(dict.fromkeys(x.operator_id for x in verdict.accepted)),
            "ephemeral_operator_ids": tuple(dict.fromkeys(x.operator_id for x in verdict.accepted if x.operator_id.startswith("ephemeral:"))),
            "results": tuple(x.as_mapping() for x in verdict.accepted),
            "discarded_ids": verdict.discarded_ids,
            "selection_reasons": verdict.reasons,
            "full_scratch_reentered_mainline": False,
            "host_semantic_action_observed": True,
        }
        turn["exploration_return"] = mapping
        tmp = turn_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(turn, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(turn_path)
        return {
            "state": mapping["state"],
            "accepted_result_count": len(verdict.accepted),
            "discarded_count": len(verdict.discarded_ids),
            "full_scratch_reentered_mainline": False,
        }

    # Each outcome shape owes a different kind of finished thing. Search alone never
    # finishes any of them, which is why an outcome request used to draw ten search
    # actions and no write: the turn could report success having produced nothing.
    OUTCOME_PLANS: dict[str, tuple[dict[str, Any], ...]] = {
        "collect_and_transform": (
            {"capability": "search:code_ecosystem", "family": "code_ecosystem", "required": True,
             "payload": {"collection_target": "upstream corpora, awesome-lists, and the repos they cite",
                         "license_check_required": True}},
            {"capability": "search:community", "family": "community", "required": True,
             "payload": {"collection_target": "what practitioners actually reuse, and what they abandoned",
                         "prefer_lived_reports_over_marketing": True}},
            {"capability": "capability:discover_execute", "family": "capability", "required": True,
             "payload": {"objective_kind": "acquire or assemble a collector",
                         "readme_is_not_execution": True}},
            {"capability": "transform:dedupe_and_regenerate", "family": "transform", "required": True,
             "payload": {"collected_is_not_delivered": True,
                         "required_steps": ["dedupe_by_content", "cluster_by_intent",
                                            "extract_reusable_pattern", "regenerate_stronger_variant"],
                         "raw_dump_is_not_an_answer": True}},
        ),
        "build_artifact": (
            {"capability": "search:personal_knowledge", "family": "personal_knowledge", "required": True,
             "payload": {"reuse_existing_user_material_first": True,
                         "private_corpus_is_prior_work_not_a_whitelist": True}},
            {"capability": "design:reference_deconstruct", "family": "design", "required": True,
             "payload": {"reference_fidelity_required": True,
                         "prohibited_defaults": ["generic_equal_card_grid", "invented_sentimental_copy"]}},
            {"capability": "state:write_artifact", "family": "state_write", "required": True,
             "payload": {"a_plan_is_not_an_artifact": True,
                         "observed_write_receipt_required": True,
                         "destination_must_be_user_directed": True}},
        ),
        "schedule_manage": (
            {"capability": "schedule:read", "family": "schedule", "required": True,
             "payload": {"read_before_write": True,
                         "existing_commitments_are_authoritative": True}},
            {"capability": "schedule:write", "family": "schedule", "required": True,
             "payload": {"a_summary_is_not_a_scheduled_event": True,
                         "observed_write_receipt_required": True,
                         "event_changes_follow_exact_user_directive": True}},
        ),
        "grow_presence": (
            {"capability": "search:social_recommendation", "family": "social_recommendation", "required": True,
             "payload": {"observe_what_actually_spread": True,
                         "engagement_signals_required": True}},
            {"capability": "search:creator_graph", "family": "creator_graph", "required": True,
             "payload": {"traverse_adjacent_creators_and_their_failures": True}},
            # Publishing is a real-world side effect. It stays non-required so the plan
            # never implies the runtime may post on the user's behalf unprompted.
            {"capability": "presence:publish", "family": "presence", "required": False,
             "payload": {"publish_only_when_it_serves_the_user_directive": True,
                         "observed_publish_receipt_required": True}},
        ),
    }
    def _outcome_actions(self, *, release_turn_id: str, zero_cost_only: bool,
                         objective: str = "", command: str = "",
                         outcome_shape: str = "", task_shape: str = "",
                         required_authorized: bool = False) -> list[CanonicalHostAction]:
        """Draw the actions an outcome shape owes, whatever the caller calls them.

        The two lineages named these arguments differently (`command`/`task_shape`
        vs `objective`/`outcome_shape`). Both are accepted rather than one being
        renamed away, and each action carries both keys in its payload, so neither
        lineage's callers nor its receipt readers lose their name silently.
        """
        goal = str(objective or command or "")
        shape = str(outcome_shape or task_shape or "")
        plan = self.OUTCOME_PLANS.get(shape)
        if not plan:
            return []
        rows: list[CanonicalHostAction] = []
        for spec in plan:
            payload = {"objective": goal, "outcome_shape": shape, "task_shape": shape,
                       **dict(spec["payload"])}
            rows.append(self._add(
                release_turn_id=release_turn_id, capability=str(spec["capability"]),
                family=str(spec["family"]),
                preferred_executors=self.EXECUTORS.get(str(spec["family"]), ("host_model",)),
                payload={**payload, "source_effect_authorized": bool(required_authorized)},
                required=bool(spec["required"] and required_authorized), zero_cost_only=zero_cost_only,
            ))
        return rows


    # ---- 의도 충실도 -------------------------------------------------------
    #
    # 사용자의 반복된 불만은 "내 의도를 축소한다" 였고, 그것이 계측된 적이 없었다.
    # jigaewol_components/objective_fidelity.py 는 정확히 그 계측기인데 어디에서도
    # import 되지 않았다. 여기서 실제로 연결한다.
    #
    # 차원(dimension)은 이 턴이 스스로 요구한 것들이다. 커버리지는 그중 실제로
    # 실행자가 붙은 것이다. 따라서 `missing` 은 "요구했지만 아무도 못 하는 것",
    # 즉 이 턴에서 실제로 축소된 부분의 이름이다. 점수는 자평이 아니다.
    OUTCOME_DIMENSION_WEIGHT = 2.0
    FAMILY_DIMENSION_WEIGHT = 1.0

    def objective_fidelity_report(self, *, command: str, actions: Iterable[CanonicalHostAction],
                                  outcome_shape: str = "",
                                  requirement_ledger_report: Mapping[str, Any] | None = None) -> dict[str, Any]:
        if requirement_ledger_report is not None:
            ledger = dict(requirement_ledger_report)
            total = int(ledger.get("total") or 0)
            covered = int(ledger.get("covered") or 0)
            score = float(ledger.get("score") if ledger.get("score") is not None else (covered / total if total else 1.0))
            return {
                "measured": True,
                "basis": "source_requirement_ledger",
                "score": round(score, 4),
                "covered": tuple(ledger.get("covered_ids") or ()),
                "missing": tuple(ledger.get("missing") or ()),
                "dimension_count": total,
                "state_counts": dict(ledger.get("state_counts") or {}),
                "outcome_shape": str(outcome_shape or ""),
                "score_is_requirement_planning_coverage_not_execution_success": True,
                "missing_names_unplanned_or_blocked_source_requirements": True,
            }
        rows = tuple(actions)
        outcome_caps = {str(spec["capability"])
                        for spec in self.OUTCOME_PLANS.get(str(outcome_shape) or "", ())
                        if spec.get("required")}
        dims: list[ObjectiveDimension] = []
        seen: set[str] = set()
        for action in rows:
            if not action.required:
                continue
            if action.capability in outcome_caps:
                did, weight, desc = (f"outcome:{action.capability}", self.OUTCOME_DIMENSION_WEIGHT,
                                     f"this turn cannot be finished without {action.capability}")
            else:
                did, weight, desc = (f"family:{action.family}", self.FAMILY_DIMENSION_WEIGHT,
                                     f"the turn demanded the {action.family} family")
            if did in seen:
                continue
            seen.add(did)
            dims.append(ObjectiveDimension(did, desc, weight))
        if not dims:
            return {
                "measured": False,
                "reason": "this turn demanded no required host action, so there is nothing to shrink",
                "score": None, "covered": (), "missing": (),
            }
        covered: list[str] = []
        for action in rows:
            if not action.required or not str(action.selected_executor or "").strip():
                continue
            did = (f"outcome:{action.capability}" if action.capability in outcome_caps
                   else f"family:{action.family}")
            if did in seen:
                covered.append(did)
        space = ObjectiveSpace(str(command), (ObjectiveInterpretation(
            "demanded_plan", tuple(dims),
            "dimensions are what this turn demanded of itself; coverage is what a real executor can serve",
        ),))
        model = space.fidelity_models()[0]
        report = model.assess(PlanCoverage("host_action_plan", tuple(dict.fromkeys(covered)),
                                           notes=f"outcome_shape={outcome_shape or 'none'}"))
        return {
            "measured": True,
            "score": round(float(report.score), 4),
            "covered": tuple(report.covered),
            "missing": tuple(report.missing),
            "dimension_count": len(dims),
            "outcome_shape": str(outcome_shape or ""),
            "score_is_plan_executability_not_answer_quality": True,
            "missing_names_what_this_turn_shrank": True,
        }

    # ---- 전략 포트폴리오 ---------------------------------------------------
    #
    # "여러 전략을 동시에 유지한다" 는 요구가 있었고 AdaptiveReasoningPortfolio 가
    # 그것인데 놀고 있었다. exploration 가 열릴 때 실제 전략 묶음을 실어 보낸다.
    def strategy_bundle(self, objective: str, *, count: int = 4) -> dict[str, Any]:
        try:
            portfolio = AdaptiveReasoningPortfolio(self.root / "reasoning_portfolio.json")
            bundle = portfolio.prompt_bundle(str(objective), count)
        except Exception as exc:  # 전략 부재가 턴을 죽이지는 않는다
            return {"available": False, "reason": f"{type(exc).__name__}: {exc}"}
        return {
            "available": True,
            "bundle": bundle,
            "strategies_are_seeds_not_a_closed_set": True,
            "portfolio_learns_from_recorded_reward": True,
        }
    def _spawn_failover_after_failure(self, row: Mapping[str, Any], *, failed_executor: str) -> tuple[str, ...]:
        """Turn an observed route failure into another executable route, not a conclusion.

        The retry lineage grows by *observed distinct executor failures* rather than a
        magic attempt count.  When no already-observed alternate body remains, a real
        capability materialization action is queued.
        """
        payload = dict(row.get("payload") or {})
        lineage = tuple(dict.fromkeys(
            str(x) for x in (payload.get("failed_executors") or ()) if str(x).strip()
        ))
        failed = tuple(dict.fromkeys((*lineage, str(failed_executor))))
        fallback_execs = [
            str(x) for x in row.get("fallback_executors") or ()
            if str(x).strip() and str(x) not in failed
        ]
        preferred = [
            str(x) for x in row.get("preferred_executors") or ()
            if str(x).strip() and str(x) not in failed and str(x) not in fallback_execs
        ]
        alternatives = tuple(dict.fromkeys((*fallback_execs, *preferred)))
        created: list[str] = []
        if alternatives:
            retry_payload = {
                **payload,
                "retry_of_action_id": str(row.get("action_id") or ""),
                "failed_executors": list(failed),
                "route_failure_keeps_goal_live": True,
                "failover_reason": "observed_executor_failure",
            }
            retry = self._add(
                release_turn_id=str(row.get("release_turn_id") or ""),
                capability=str(row.get("capability") or ""),
                family=str(row.get("family") or ""),
                preferred_executors=alternatives,
                payload=retry_payload,
                required=bool(row.get("required")),
                zero_cost_only=bool(row.get("zero_cost_only")),
            )
            created.append(retry.action_id)
            return tuple(created)
        if str(row.get("capability") or "") != "capability:discover_execute":
            discovery = self._add(
                release_turn_id=str(row.get("release_turn_id") or ""),
                capability="capability:discover_execute",
                family="capability",
                preferred_executors=("Plugin_Management", "GitHub", "Floot", "jigaewol_local_runtime", "container"),
                payload={
                    "objective": str(payload.get("objective") or ""),
                    "reason": "observed_route_failed_and_no_observed_alternate_remains",
                    "failed_action_id": str(row.get("action_id") or ""),
                    "failed_capability": str(row.get("capability") or ""),
                    "failed_family": str(row.get("family") or ""),
                    "failed_executors": list(failed),
                    "materialization_protocol": [
                        "discover_materially_different_body",
                        "inspect_license_dependencies_and_effect_boundary",
                        "materialize_or_connect_callable_body",
                        "rebind_original_capability",
                        "execute_and_record_receipt",
                    ],
                    "search_outside_current_registry": True,
                    "route_failure_keeps_goal_live": True,
                },
                required=bool(row.get("required")),
                zero_cost_only=bool(row.get("zero_cost_only")),
            )
            created.append(discovery.action_id)
        return tuple(created)

    def record_result(self, action_id: str, *, executor: str, success: bool, origin_ref: str,
                      evidence: dict[str, Any] | None = None, zero_incremental_cost: bool | None = None) -> dict[str, Any]:
        data = self._read()
        row = data.get("actions", {}).get(str(action_id))
        if row is None:
            raise KeyError(action_id)
        if str(row.get("state") or "") == "superseded":
            raise PermissionError("host action belongs to a superseded turn and cannot accept new execution results")
        quality_review_only = str(row.get("state") or "") == "awaiting_quality"
        if str(row.get("state") or "") not in {"pending", "failed", "awaiting_quality"}:
            raise PermissionError(f"host action is not executable from state={row.get('state')}")
        observed_evidence = dict(evidence or {})
        if quality_review_only and not (
            success is True
            and str(origin_ref) == str(row.get("render_origin_ref") or "")
            and str(executor) == str(row.get("render_executor") or "")
            and observed_evidence.get("render_observation_sha256") == row.get("render_observation_sha256")
            and str(observed_evidence.get("image_quality_review_ref") or "").strip()
        ):
            raise PermissionError("image review must bind to the previously observed render")
        if bool(success) and observed_evidence.get("host_call_observed") is not True:
            raise PermissionError("successful host action requires evidence.host_call_observed=true")
        if not str(executor).strip():
            raise ValueError("executor must be nonempty")
        if not str(origin_ref).strip():
            raise ValueError("origin_ref must be nonempty")
        exploration_binding = None
        if bool(success) and str(row.get("capability") or "") == "cognition:exploration_generate":
            exploration_binding = self._bind_exploration_return(row, observed_evidence)
        result = {
            "action_id": str(action_id), "request_sha256": str(row["request_sha256"]),
            "release_turn_id": str(row["release_turn_id"]),
            "capability": str(row.get("capability") or ""), "family": str(row.get("family") or ""),
            "executor": str(executor),
            "success": bool(success), "origin_ref": str(origin_ref), "evidence": observed_evidence,
            "zero_incremental_cost": zero_incremental_cost, "observed_at": time.time(),
        }
        action_payload = dict(row.get("payload") or {})
        image_action = ImageSovereigntyPolicy.is_image_capability(str(row.get("capability") or ""))
        completion_allowed = bool(success)
        if image_action:
            governance = dict(action_payload.get("image_generation_governance") or {})
            sovereignty = action_payload.get("image_sovereignty_contract") or governance.get("sovereignty_contract")
            if not (
                governance.get("should_invoke", True) is True
                and ImageSovereigntyPolicy.validate(
                    sovereignty, source_text=str(governance.get("prompt_source_text") or action_payload.get("objective") or ""),
                    mode=str(action_payload.get("mode") or governance.get("mode") or "generate"), should_invoke=True,
                )
                and str(action_payload.get("image_sovereignty_token") or "") == str(dict(sovereignty or {}).get("authority_token") or "")
            ):
                raise PermissionError("image action contract changed after dispatch")
        if image_action and success:
            governance = dict(action_payload.get("image_generation_governance") or {})
            quality_contract = dict(governance.get("quality_contract") or ImageQualityGovernor.compile_contract(""))
            observation = observed_evidence.get("image_quality_observation")
            verdict = ImageQualityGovernor.review_observation(
                observation if isinstance(observation, Mapping) else {}, contract=quality_contract
            )
            result["image_quality_verdict"] = verdict
            result["image_quality_observation"] = observation
            result["quality_review_only"] = quality_review_only
            completion_allowed = verdict.get("accepted") is True
            if verdict.get("review_required") is True:
                result["image_quality_review_request"] = ImageQualityGovernor.compile_review_request(
                    generated_ref=str(observed_evidence.get("image_ref") or origin_ref),
                    contract=quality_contract, parent_action_id=str(action_id),
                    requirement_ids=list(action_payload.get("requirement_ids") or ()),
                )
        if exploration_binding is not None:
            result["exploration_binding"] = exploration_binding
        # Hash the observed host effect separately from orchestration follow-ups.
        # This digest is what promotes an executor into durable receipt-backed body
        # memory; later failover/search actions are derived control-plane state and
        # must not retroactively change the hash of the effect that was observed.
        result["observation_sha256"] = self._sha(result)

        # If the outer host reports the exact provider action it actually invoked,
        # preserve that action-level truth separately from the broader capability
        # requested by this bridge.  A successful GitHub read must not accidentally
        # prove GitHub write; a successful connector probe must not prove remote exec.
        host_action_name = str(
            observed_evidence.get("host_action_name")
            or observed_evidence.get("host_action")
            or ""
        ).strip()
        if host_action_name and not quality_review_only:
            provider_id = str(observed_evidence.get("provider_id") or executor).strip()
            action_result_summary = observed_evidence.get("action_result_summary")
            if not isinstance(action_result_summary, dict):
                action_result_summary = {}
            action_truth = HostActionTruthLedger(
                resolve_chat_runtime_home(self.root.parent),
                body_root=self.root.parent,
            ).record(
                provider_id=provider_id,
                executor=str(executor),
                role=str(observed_evidence.get("provider_role") or row.get("family") or ""),
                action=host_action_name,
                success=bool(success),
                origin_ref=str(origin_ref),
                evidence_ref="canonical_observation_sha256:" + str(result["observation_sha256"]),
                result_summary=dict(action_result_summary),
                error=str(observed_evidence.get("error") or ""),
                observed_at=float(result["observed_at"]),
            )
            result["host_action_truth_observation_id"] = action_truth.observation_id
            result["host_action_truth_capabilities"] = list(action_truth.proven_capabilities)

        row["state"] = (
            "awaiting_quality" if image_action and success and result["image_quality_verdict"].get("review_required") is True
            else "succeeded" if success else "failed"
        )
        if image_action and success and not quality_review_only:
            row["render_observation_sha256"] = result["observation_sha256"]
            row["render_origin_ref"] = str(origin_ref)
            row["render_executor"] = str(executor)
        row["selected_executor"] = str(executor)
        if success and not quality_review_only:
            # A successful host call is stronger evidence than a one-turn surface
            # enumeration.  Promote/refresh the actual executor into the durable
            # body federation so the next turn does not "forget" a body that just
            # executed successfully.  Freshness is still revalidated at dispatch;
            # this is durable routing memory, not a permanent connectivity claim.
            existing = {b.body_id: b for b in self.bodies.bodies()}
            executor_slug = re.sub(r"[^a-z0-9_.:-]+", "_", str(executor).casefold()).strip("_") or "host"
            body_id = str(row.get("selected_body_id") or f"execution_receipt:{executor_slug}")
            previous = existing.get(body_id)
            capabilities = list(previous.capabilities if previous else ())
            families = list(previous.families if previous else ())
            capability = str(row.get("capability") or "").strip()
            family = str(row.get("family") or "").strip()
            if capability and capability not in capabilities:
                capabilities.append(capability)
            if family and family not in families:
                families.append(family)
            prior_evidence = dict(previous.evidence if previous else {})
            receipt_evidence = {
                **prior_evidence,
                "receipt_backed_callable_memory": True,
                "last_action_id": str(action_id),
                "last_request_sha256": str(row.get("request_sha256") or ""),
                "last_observation_sha256": str(result["observation_sha256"]),
                "host_call_observed": True,
                "revalidate_before_effect_if_surface_is_stale": True,
            }
            promoted = self.bodies.upsert(
                body_id,
                executor=str(executor),
                families=families,
                capabilities=capabilities,
                state="executed_successfully",
                zero_incremental_cost=(
                    zero_incremental_cost if zero_incremental_cost is not None
                    else (previous.zero_incremental_cost if previous else None)
                ),
                evidence_strength=max(1.0, previous.evidence_strength if previous else 0.0),
                origin_ref=str(origin_ref),
                evidence=receipt_evidence,
                observed_at=float(result["observed_at"]),
            )
            row["selected_body_id"] = promoted.body_id
            row["binding_state"] = "receipt_backed_callable"
            row["revalidation_required"] = False
        data["actions"][str(action_id)] = row
        self._write(data)
        if str(row.get("capability") or "").startswith("search:"):
            result["search_swarm_coverage"] = self.search_coverage(str(row.get("release_turn_id") or ""))

        failover_action_ids: tuple[str, ...] = ()
        if not success:
            failover_action_ids = self._spawn_failover_after_failure(row, failed_executor=str(executor))
        if image_action and success and result["image_quality_verdict"].get("rerender_required") is True:
            governance = dict(action_payload.get("image_generation_governance") or {})
            iteration = max(0, int(action_payload.get("quality_iteration") or 0))
            max_iterations = max(1, int(governance.get("max_quality_iterations") or 5))
            result["image_quality_retry_exhausted"] = iteration >= max_iterations
            if iteration < max_iterations:
                directive = ImageQualityGovernor.rerender_directive(
                    dict(governance.get("render_directive") or {}), result["image_quality_verdict"]
                )
                retry = self.route_effect(
                    release_turn_id=str(row["release_turn_id"]), capability="media:image_generate",
                    payload={**action_payload, "image_rerender_directive": directive,
                             "quality_iteration": iteration + 1,
                             "parent_action_id": str(action_payload.get("parent_action_id") or action_id),
                             "parent_quality_receipt_id": result["observation_sha256"]},
                    required=bool(row.get("required")), zero_cost_only=bool(row.get("zero_cost_only")),
                    preferred_executors=tuple(row.get("preferred_executors") or ()),
                )
                result["image_rerender_action_id"] = retry.action_id

        # Successful search/browser observations feed newly observed vocabulary and
        # links back into the durable action queue.  This is bounded and idempotent:
        # it expands discovery, but never calls a host tool by pretending a plan is execution.
        followups = []
        if success and str(row.get("family") or "") in {
            "first_party", "web_current", "community", "social_recommendation",
            "code_ecosystem", "research", "creator_graph", "multilingual", "personal_knowledge", "browser"
        }:
            ev = dict(evidence or {})
            items = ev.get("items") or ev.get("results") or ()
            if isinstance(items, dict):
                items = items.get("items") or items.get("results") or ()
            if isinstance(items, (list, tuple)) and items:
                family = str(row.get("family") or "web_current")
                source_family = "social_recommendation" if family == "browser" else family
                program = SearchPortfolioEngine.derive_followup_program(items, source_family, max_terms=None)
                parent_round = int(dict(row.get("payload") or {}).get("round") or 0)
                if not program.get("saturated"):
                    objective = str(dict(row.get("payload") or {}).get("objective") or "")
                    current_actions = self._read().get("actions", {})
                    already_scheduled = {
                        str(dict(existing.get("payload") or {}).get("observed_term") or "").casefold()
                        for existing in current_actions.values()
                        if str(existing.get("release_turn_id") or "") == str(row.get("release_turn_id") or "")
                        and str(existing.get("family") or "") == source_family
                    }
                    for term in tuple(program.get("observed_terms") or ()):
                        if term.casefold() in already_scheduled:
                            continue
                        action = self._add(
                            release_turn_id=str(row["release_turn_id"]),
                            capability=f"search:{source_family}", family=source_family,
                            preferred_executors=self.EXECUTORS.get(source_family, ("native.web", "TinyFish")),
                            payload={"objective": objective, "observed_term": term, "round": parent_round + 1,
                                     "parent_action_id": str(action_id),
                                     "requirement_ids": list(dict(row.get("payload") or {}).get("requirement_ids") or ()),
                                     "requirement_message_sha256": dict(row.get("payload") or {}).get("requirement_message_sha256", ""),
                                     "query_program": SearchPortfolioEngine.compile_query_program(term, source_family),
                                     "recursive_followup_required": True, "observed_term_requery_required": True,
                                     "stop_semantics": "saturation_or_no_new_observed_terms_or_user_stop"},
                            required=bool(row.get("required")), zero_cost_only=bool(row.get("zero_cost_only", False)),
                        )
                        followups.append(action.action_id)
                        already_scheduled.add(term.casefold())
        result["followup_action_ids"] = followups
        result["failover_action_ids"] = list(failover_action_ids)

        # Search/browser observations are part of long-running work continuity, not
        # ephemeral chat decoration. Journal them only when exactly one running
        # chat work stream exists; ambiguity is explicit rather than guessed.
        if str(row.get("family") or "") in {
            "first_party", "web_current", "community", "social_recommendation",
            "code_ecosystem", "research", "creator_graph", "multilingual",
            "personal_knowledge", "browser",
        }:
            ev = dict(evidence or {})
            search_items = ev.get("items") or ev.get("results") or ()
            if isinstance(search_items, dict):
                search_items = search_items.get("items") or search_items.get("results") or ()
            if not isinstance(search_items, (list, tuple)):
                search_items = ()
            try:
                run_bridge = SearchRunBridge(
                    DurableRunLedger(resolve_chat_runtime_home(self.root.parent) / "durable_runs")
                )
                durable_search = run_bridge.journal(
                    action_row={**row, "action_id": str(action_id)},
                    success=bool(success),
                    items=search_items,
                    evidence_refs=("canonical_observation_sha256:" + str(result["observation_sha256"]), str(origin_ref)),
                    observation_sha256=str(result["observation_sha256"]),
                    observed_at=float(result["observed_at"]),
                )
            except Exception as exc:
                durable_search = {"journaled": False, "reason": f"journal_error:{type(exc).__name__}:{exc}"}
            result["durable_search_journal"] = durable_search
        result["result_sha256"] = self._sha({k: v for k, v in result.items() if k != "result_sha256"})
        # Bind each observed host action to its source requirement without collapsing
        # multi-action obligations.  One requirement may require several search/source
        # families or execution steps; it becomes satisfied only when every required
        # action obligation has an observed successful result.  A failover may satisfy
        # the parent obligation it explicitly replaces.
        action_payload = dict(row.get("payload") or {})
        requirement_message_sha256 = str(action_payload.get("requirement_message_sha256") or "").strip()
        requirement_ids = tuple(str(x) for x in action_payload.get("requirement_ids") or () if str(x).strip())
        if requirement_message_sha256 and requirement_ids and (completion_allowed or not success):
            from .requirement_anti_shrink import RequirementAntiShrinkLedger
            ledger = RequirementAntiShrinkLedger(self.root.parent)
            satisfaction_refs = []
            pending_refs = []
            obligation_action_id = str(action_payload.get("parent_action_id") or action_id)
            for atom_id in requirement_ids:
                outcome = ledger.record_action_outcome(
                    requirement_message_sha256,
                    atom_id,
                    str(action_id),
                    success=bool(success),
                    evidence_refs=(
                        f"canonical_host_result:{result['result_sha256']}",
                        str(origin_ref),
                    ),
                    obligation_action_id=obligation_action_id,
                )
                if outcome.get("requirement_complete") is True:
                    satisfaction_refs.append(atom_id)
                else:
                    pending_refs.append(atom_id)
            result["satisfied_requirement_ids"] = satisfaction_refs
            result["pending_requirement_ids"] = pending_refs
        elif requirement_message_sha256 and requirement_ids:
            result["satisfied_requirement_ids"] = []
            result["pending_requirement_ids"] = list(requirement_ids)
        with self.results_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(result, ensure_ascii=False, sort_keys=True) + "\n")
        return result

    def record_image_quality_review(self, action_id: str, *, render_observation_sha256: str,
                                    review_ref: str, observation: Mapping[str, Any]) -> dict[str, Any]:
        """Review an existing render without claiming another image generation call."""
        row = self._read().get("actions", {}).get(str(action_id))
        if not row or row.get("state") != "awaiting_quality":
            raise PermissionError("image action is not awaiting a quality review")
        if not str(review_ref).strip() or not isinstance(observation, Mapping):
            raise ValueError("an observed review reference and metric mapping are required")
        if str(render_observation_sha256) != str(row.get("render_observation_sha256") or ""):
            raise PermissionError("quality review render receipt mismatch")
        render = None
        for line in self.results_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            candidate = json.loads(line)
            if candidate.get("action_id") == str(action_id) and candidate.get("observation_sha256") == str(render_observation_sha256):
                render = candidate
        if not render or render.get("success") is not True:
            raise PermissionError("observed successful render receipt is missing")
        return self.record_result(
            action_id, executor=str(render["executor"]), success=True, origin_ref=str(render["origin_ref"]),
            evidence={**dict(render.get("evidence") or {}), "image_quality_observation": dict(observation),
                      "image_quality_review_ref": str(review_ref),
                      "render_observation_sha256": str(render_observation_sha256)},
            zero_incremental_cost=render.get("zero_incremental_cost"),
        )

    def apply_dispatch_batch(self, batch: Mapping[str, Any], observations: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
        """Apply a host batch only after every observation is request-hash bound.

        Validation happens for the entire observation set before any action is mutated,
        preventing a malformed second observation from partially closing the first.
        """
        batch_row = dict(batch or {})
        if batch_row.get("schema") != "jigaewol_host_dispatch_batch_v1":
            raise ValueError("unsupported host dispatch batch schema")
        expected = {str(x.get("action_id") or ""): dict(x) for x in batch_row.get("actions") or ()}
        rows = [dict(x) for x in observations]
        if not rows:
            raise ValueError("at least one host observation is required")
        seen: set[str] = set()
        current = self._read().get("actions", {})
        for obs in rows:
            action_id = str(obs.get("action_id") or "")
            if not action_id or action_id in seen or action_id not in expected:
                raise PermissionError("host observation is not uniquely bound to this dispatch batch")
            seen.add(action_id)
            exp = expected[action_id]
            live = current.get(action_id)
            if live is None or str(live.get("release_turn_id") or "") != str(batch_row.get("release_turn_id") or ""):
                raise PermissionError("host observation release turn mismatch")
            if str(obs.get("request_sha256") or "") != str(exp.get("request_sha256") or ""):
                raise PermissionError("host observation request hash mismatch")
            if str(live.get("request_sha256") or "") != str(exp.get("request_sha256") or ""):
                raise PermissionError("dispatch batch is stale relative to canonical action state")
            if str(live.get("state") or "") not in {"pending", "failed"}:
                raise PermissionError(f"host action is not executable from state={live.get('state')}")
            evidence = dict(obs.get("evidence") or {})
            for key in ("provider_id", "host_action_name", "host_action", "provider_role", "action_result_summary"):
                if key in obs and key not in evidence:
                    evidence[key] = obs.get(key)
            if bool(obs.get("success")) and evidence.get("host_call_observed") is not True:
                raise PermissionError("successful host observation requires evidence.host_call_observed=true")
            if not str(obs.get("executor") or "").strip() or not str(obs.get("origin_ref") or "").strip():
                raise ValueError("executor and origin_ref are required for host observations")

        receipts = []
        causal_resume_observations: list[dict[str, Any]] = []
        for obs in rows:
            action_id = str(obs["action_id"])
            evidence = dict(obs.get("evidence") or {})
            for key in ("provider_id", "host_action_name", "host_action", "provider_role", "action_result_summary"):
                if key in obs and key not in evidence:
                    evidence[key] = obs.get(key)
            receipt = self.record_result(
                action_id,
                executor=str(obs["executor"]),
                success=bool(obs.get("success")),
                origin_ref=str(obs["origin_ref"]),
                evidence=evidence,
                zero_incremental_cost=obs.get("zero_incremental_cost"),
            )
            receipts.append(receipt)
            action_payload = dict(expected[action_id].get("payload") or {})
            causal_invocation_id = str(action_payload.get("causal_loop_invocation_id") or "")
            causal_request_sha = str(action_payload.get("causal_loop_request_sha256") or "")
            if causal_invocation_id and causal_request_sha:
                evidence = dict(obs.get("evidence") or {})
                causal_resume_observations.append({
                    "kind": "action",
                    "invocation_id": causal_invocation_id,
                    "request_sha256": causal_request_sha,
                    "executor_id": str(obs["executor"]),
                    "origin_ref": str(obs["origin_ref"]),
                    "host_call_observed": evidence.get("host_call_observed") is True,
                    "success": bool(obs.get("success")),
                    "result": {
                        "canonical_host_action_id": action_id,
                        "canonical_host_request_sha256": str(expected[action_id].get("request_sha256") or ""),
                        "canonical_host_result_sha256": str(receipt.get("result_sha256") or ""),
                        "evidence": evidence,
                    },
                    "request_payload": dict(action_payload.get("work") or {}),
                })
        return {
            "batch_id": str(batch_row.get("batch_id") or ""),
            "release_turn_id": str(batch_row.get("release_turn_id") or ""),
            "applied_count": len(receipts),
            "receipts": tuple(receipts),
            "result_sha256s": tuple(str(x.get("result_sha256") or "") for x in receipts),
            "causal_resume_observations": tuple(causal_resume_observations),
            "causal_resume_ready": bool(causal_resume_observations),
            "followup_action_ids": tuple(
                y for x in receipts for y in tuple(x.get("followup_action_ids") or ())
            ),
            "failover_action_ids": tuple(
                y for x in receipts for y in tuple(x.get("failover_action_ids") or ())
            ),
        }

    def successful_evidence(self, release_turn_id: str) -> tuple[dict[str, Any], ...]:
        out = []
        actions = self._read().get("actions", {})
        for line in self.results_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if row.get("release_turn_id") == str(release_turn_id) and row.get("success") is True:
                payload = dict(dict(actions.get(str(row.get("action_id"))) or {}).get("payload") or {})
                out.append({
                    "provider": row.get("executor"), "operation": "canonical_host_action",
                    "capability": row.get("capability"),
                    "requirement_ids": list(payload.get("requirement_ids") or ()),
                    "requirement_message_sha256": str(payload.get("requirement_message_sha256") or ""),
                    "origin_ref": row.get("origin_ref"), "status": "successful", "success": True,
                    "image_quality_verdict": row.get("image_quality_verdict"),
                    "image_quality_observation": dict(row.get("evidence") or {}).get("image_quality_observation"),
                    "result": {"action_id": row.get("action_id"), "request_sha256": row.get("request_sha256"),
                               "result_sha256": row.get("result_sha256"), "evidence": row.get("evidence")},
                })
        return tuple(out)
