"""JIGAEWOL's source-first cognitive frontier, donor-backed and host-neutral.

This is an *operational* frontier: exact-message keyed requests, divergent
representation probes, raw generative result retention, and executable optional
host-generator branch traversal. Neither a tool catalog nor a model name limits
which hypotheses may be proposed. A generated hypothesis is not a completed task.

Donor: user's USAGI_V4_0_OPEN_WORLD_COGNITIVE_OPERATING_SYSTEM.zip,
       overdrive/deep_open_cognition.py (preserved in upstream_cognition/).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import time
from pathlib import Path
from typing import Any, Callable, Mapping

from .upstream_cognition.deep_open_cognition import OpenCognitionEngine, EpistemicMode


def digest(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def _atomic_json(path: Path, obj: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '.', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(obj, handle, ensure_ascii=False, sort_keys=True, indent=2, default=str)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


class FrontierCognition:
    """Host-neutral cognition that begins with the *entire* exact user message.

    Branches express falsifiable requests to the host's cognitive generator,
    but avoid a fixed candidate ontology. A host can call generate() using its
    already-present model, rather than requiring an additional model endpoint.
    """

    def __init__(self, state_root: str | Path) -> None:
        self.root = Path(state_root).resolve() / 'cognitive_frontier'
        self.root.mkdir(parents=True, exist_ok=True)
        self.open_engine = OpenCognitionEngine(self.root / 'donor_open_cognition')

    @staticmethod
    def _requirements(exact: str) -> tuple[str, ...]:
        # These clauses remain additive pointers. The full exact source is kept.
        rows = (s.strip() for s in re.split(r'[\n]+|(?<=[.!?。])\s+', exact))
        return tuple(dict.fromkeys(s for s in rows if s))

    def prepare(self, exact_text: str, *, release_turn_id: str = '') -> dict[str, Any]:
        if not isinstance(exact_text, str) or not exact_text.strip():
            raise ValueError('exact user message required')
        sha = digest(exact_text)
        requirements = self._requirements(exact_text)
        # Conjecture diversity must be distinct in *causal mechanism*, not a pile
        # of synonyms. Each method addresses the user's whole source goal.
        methods = (
            ('native', 'Solve the exact original request directly, without replacing its objective.'),
            ('representation_escape', 'Invent a representation or primitive not present in the current vocabulary; derive a task-changing consequence.'),
            ('counterexample', 'Find the hidden assumption whose negation could unlock the goal; keep contradictory possibilities live.'),
            ('cross_domain', 'Transfer a mechanism from an unrelated domain, and show exactly what its transfer would change.'),
            ('first_principles', 'Remove inherited implementation choices; rebuild a causal solution from what the user actually needs.'),
            ('minimal_surprise', 'Find a deceptively small intervention with disproportionately large practical effects.'),
            ('adversarial_reframe', 'Propose a fundamentally different but goal-faithful route that could defeat the strongest incumbent approach.'),
        )
        branches = [
            {'branch_id': label,
             'epistemic_mode': ('EVIDENCED' if label == 'native' else 'SPECULATIVE'),
             'mechanism_request': question,
             'objective_sha256': sha,
             'state': 'candidate_not_yet_generated'}
            for label, question in methods
        ]
        # Host-discovered and user-defined methods can extend the seed family.
        # There is no fixed method vocabulary after the first seven probes.
        record_path = self.root / 'requests' / (sha + '.json')
        if record_path.is_file():
            prior = json.loads(record_path.read_text(encoding='utf-8'))
            if prior.get('exact_text_sha256') == sha and prior.get('exact_text') == exact_text:
                seen = {b['branch_id'] for b in branches}
                for extra in prior.get('branch_set', []):
                    if extra.get('branch_id') not in seen:
                        branches.append(extra)
                        seen.add(extra.get('branch_id'))
        record = {
            'schema': 'jigaewol_frontier_cognition_v1',
            'exact_text': exact_text,
            'exact_text_sha256': sha,
            'release_turn_id': release_turn_id,
            'requirement_clauses': requirements,
            'objective_policy': 'full_exact_source_only',
            'creative_target': 'causal_and_representational_novelty_not_surface_flair',
            'raw_generation_preservation': True,
            'branch_set': branches,
            'host_generation_binding': 'use_current_chat_model_when_host_supplies_callback',
            'branch_generation_is_optional_not_precondition_for_user_response': True,
            'created_at': time.time(),
        }
        _atomic_json(record_path, record)
        return {**record, 'record_path': str(record_path)}

    def register_method(self, exact_text: str, *, mechanism_request: str,
                        branch_id: str = '', epistemic_mode: str = 'SPECULATIVE') -> dict[str, Any]:
        """Attach a newly invented thinking operator to this exact-source frontier."""
        if not mechanism_request.strip():
            raise ValueError('mechanism_request required')
        if epistemic_mode not in {x.value for x in EpistemicMode}:
            raise ValueError('unsupported epistemic mode')
        plan = self.prepare(exact_text)
        existing = {row['branch_id'] for row in plan['branch_set']}
        branch_id = branch_id.strip() or ('invented_' + digest(mechanism_request)[:16])
        if branch_id in existing:
            match = next(x for x in plan['branch_set'] if x['branch_id'] == branch_id)
            if match['mechanism_request'] != mechanism_request:
                raise ValueError('branch_id already defined with different mechanism')
            return match
        new_branch = {
            'branch_id': branch_id, 'epistemic_mode': epistemic_mode,
            'mechanism_request': mechanism_request,
            'objective_sha256': plan['exact_text_sha256'],
            'state': 'candidate_not_yet_generated',
            'origin': 'dynamically_invented',
        }
        plan['branch_set'].append(new_branch)
        _atomic_json(Path(plan['record_path']), {k:v for k,v in plan.items() if k!='record_path'})
        return new_branch

    def record_feedback(self, exact_text: str, *, branch_id: str, outcome: str,
                        evidence_ref: str = '', next_mechanism: str = '') -> dict[str, Any]:
        """Preserve outcomes as empirical feedback without pruning other hypotheses.

        A new adaptation idea extends the method set, never replaces the objective.
        """
        plan = self.prepare(exact_text)
        if branch_id not in {r['branch_id'] for r in plan['branch_set']}:
            raise KeyError('unknown cognition branch')
        row = {'original_sha256':plan['exact_text_sha256'],
               'branch_id':branch_id, 'outcome':str(outcome),
               'evidence_ref':str(evidence_ref), 'observed_at':time.time()}
        ledger = self.root / 'cognitive_feedback.jsonl'
        with ledger.open('a', encoding='utf-8') as h:
            h.write(json.dumps(row, ensure_ascii=False) + '\n')
        if next_mechanism.strip():
            row['new_branch'] = self.register_method(exact_text, mechanism_request=next_mechanism)['branch_id']
        return row

    def observe(self, original_text: str, raw_result: str, *, branch_id: str = 'native',
                host_event_id: str = '', generation_source: str = 'host_observed_model') -> dict[str, str]:
        """Durably capture actually observed model output, without truncation/rewrites."""
        if not isinstance(raw_result, str):
            raise TypeError('raw model output must be text')
        source_sha = digest(original_text)
        spark = self.open_engine.ingest_substrate_output(
            raw_result, substrate_id=generation_source,
            prompt_or_context={'exact_user_message_sha256': source_sha, 'branch_id': branch_id},
            epistemic_mode=EpistemicMode.EVIDENCED if branch_id == 'native' else EpistemicMode.SPECULATIVE,
            metadata={'host_event_id': host_event_id, 'branch_id': branch_id, 'source_sha256': source_sha})
        return {'spark_id': spark.spark_id, 'raw_output_sha256': spark.sha256,
                'raw_archive': str(self.open_engine.archive.path)}

    def generate_with_host(self, exact_text: str,
                           generator: Callable[[str, Mapping[str, Any]], Any],
                           *, methods: tuple[str, ...] | None = None) -> dict[str, Any]:
        """Actually execute chosen divergent branches through a supplied host model.

        This method performs no network access itself and silently assumes no API key.
        Each generator invocation is genuine and its full output is persisted; a
        failed branch does not erase others or alter the user objective.
        """
        plan = self.prepare(exact_text)
        selected = set(methods) if methods is not None else {x['branch_id'] for x in plan['branch_set']}
        rows = []
        for branch in plan['branch_set']:
            if branch['branch_id'] not in selected:
                continue
            try:
                raw = generator(exact_text, branch)
                body = raw if isinstance(raw, str) else json.dumps(raw, ensure_ascii=False, default=str)
                receipt = self.observe(exact_text, body, branch_id=branch['branch_id'],
                                       generation_source='host_branch_generator')
                rows.append({'branch_id': branch['branch_id'], 'state': 'observed', **receipt})
            except Exception as exc:
                rows.append({'branch_id': branch['branch_id'], 'state': 'failed',
                             'error_type': type(exc).__name__, 'error': str(exc)})
        result = {'schema': 'jigaewol_frontier_generation_v1',
                  'exact_text_sha256': plan['exact_text_sha256'], 'branches': rows,
                  'actual_generations': sum(row['state']=='observed' for row in rows)}
        _atomic_json(self.root/'observed_runs'/(plan['exact_text_sha256']+'.json'), result)
        return result
