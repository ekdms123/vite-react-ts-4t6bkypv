from __future__ import annotations

import ast
import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class CodeFinding:
    finding_id: str
    category: str
    severity: str
    path: str
    line: int
    detail: str
    repair_hint: str


@dataclass(frozen=True)
class CodeDoctorReport:
    report_id: str
    source_fingerprint: str
    scanned_files: int
    findings: tuple[CodeFinding, ...]
    generated_at: float
    schema: str = "jigaewol_code_doctor_v1"

    def as_mapping(self) -> dict[str, Any]:
        return {
            "schema": self.schema,
            "report_id": self.report_id,
            "source_fingerprint": self.source_fingerprint,
            "scanned_files": self.scanned_files,
            "finding_count": len(self.findings),
            "findings": [asdict(x) for x in self.findings],
            "generated_at": self.generated_at,
        }


class RuntimeCodeDoctor:
    """Cheap structural doctor for the active source tree.

    This is not a linter replacement. It targets failure modes that matter to a
    self-modifying runtime: swallowed failures, giant orchestration hubs, runtime
    monkey-patching, dynamic code execution, and non-terminating control loops.
    Reports are artifact-fingerprinted so the scan can be reused until source changes.
    """

    SOURCE_DIRS = ("jigaewol_core", "jigaewol_components", "jigaewol_runtime", "model_host", "tools")
    GUARDED_DYNAMIC_EXEC_SINKS = {
        ("jigaewol_components/dynamic_execution_gate.py", "_execute_admitted"),
        ("jigaewol_runtime/methods/runner.py", "_child"),
    }

    def __init__(self, source_root: Path, state_root: Path) -> None:
        self.source_root = Path(source_root).resolve()
        self.state_root = Path(state_root).resolve()
        self.state_root.mkdir(parents=True, exist_ok=True)
        self.latest_path = self.state_root / "latest.json"
        self.history_path = self.state_root / "history.jsonl"

    def _python_files(self) -> tuple[Path, ...]:
        rows: list[Path] = []
        for dirname in self.SOURCE_DIRS:
            base = self.source_root / dirname
            if not base.exists():
                continue
            rows.extend(p for p in base.rglob("*.py") if "__pycache__" not in p.parts)
        return tuple(sorted(set(rows)))

    @staticmethod
    def _hash_snapshot(snapshot: Iterable[tuple[Path, bytes]], root: Path) -> str:
        h = hashlib.sha256()
        for p, payload in snapshot:
            rel = p.relative_to(root).as_posix().encode("utf-8")
            h.update(len(rel).to_bytes(4, "big")); h.update(rel)
            h.update(len(payload).to_bytes(8, "big")); h.update(hashlib.sha256(payload).digest())
        return h.hexdigest()

    def _stable_source_snapshot(self, *, attempts: int = 3) -> tuple[tuple[tuple[Path, bytes], ...], tuple[str, ...]]:
        """Read a bounded coherent-enough source snapshot during live self-modification.

        A source file may be atomically replaced between discovery and read. That is a
        mutation race, not permission to crash the canonical turn. Retry discovery a
        few times and, if churn persists, analyze the bytes that were actually observed
        while surfacing the vanished paths as explicit doctor findings.
        """
        last_rows: tuple[tuple[Path, bytes], ...] = ()
        last_missing: tuple[str, ...] = ()
        for _ in range(max(1, int(attempts))):
            rows: list[tuple[Path, bytes]] = []
            missing: list[str] = []
            for path in self._python_files():
                try:
                    rows.append((path, path.read_bytes()))
                except FileNotFoundError:
                    missing.append(path.relative_to(self.source_root).as_posix())
            last_rows, last_missing = tuple(rows), tuple(missing)
            if not missing:
                return last_rows, ()
        return last_rows, last_missing

    @staticmethod
    def _finding(category: str, severity: str, path: str, line: int, detail: str, repair_hint: str) -> CodeFinding:
        basis = json.dumps([category, path, line, detail], ensure_ascii=False, sort_keys=True).encode("utf-8")
        return CodeFinding(
            finding_id="doctor_" + hashlib.sha256(basis).hexdigest()[:20],
            category=category, severity=severity, path=path, line=int(line),
            detail=detail, repair_hint=repair_hint,
        )

    def scan(self, *, force: bool = False) -> CodeDoctorReport:
        snapshot, snapshot_races = self._stable_source_snapshot()
        fingerprint = self._hash_snapshot(snapshot, self.source_root)
        if not force and self.latest_path.exists():
            try:
                raw = json.loads(self.latest_path.read_text(encoding="utf-8"))
                if raw.get("source_fingerprint") == fingerprint:
                    return CodeDoctorReport(
                        report_id=str(raw["report_id"]), source_fingerprint=fingerprint,
                        scanned_files=int(raw["scanned_files"]),
                        findings=tuple(CodeFinding(**x) for x in raw.get("findings") or ()),
                        generated_at=float(raw["generated_at"]), schema=str(raw.get("schema") or "jigaewol_code_doctor_v1"),
                    )
            except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
                # Cache corruption is not a source finding; rebuild from source below.
                raw = {}

        findings: list[CodeFinding] = []
        for rel in snapshot_races:
            findings.append(self._finding(
                "source_snapshot_race", "medium", rel, 0,
                "source path changed while the self-modification doctor was taking a snapshot",
                "retry from a stable snapshot; keep the mutation event visible rather than crashing or erasing it",
            ))
        for p, payload in snapshot:
            rel = p.relative_to(self.source_root).as_posix()
            text = payload.decode("utf-8", errors="replace")
            line_count = text.count("\n") + 1
            if line_count >= 1800:
                findings.append(self._finding(
                    "orchestration_hub", "high", rel, 1,
                    f"module has {line_count} lines and is a high-risk change concentrator",
                    "split hot-path orchestration from side-lane diagnostics and provider adapters",
                ))
            elif line_count >= 1000:
                findings.append(self._finding(
                    "large_module", "medium", rel, 1,
                    f"module has {line_count} lines",
                    "extract cohesive state machines behind typed interfaces",
                ))
            try:
                tree = ast.parse(text)
            except SyntaxError as exc:
                findings.append(self._finding(
                    "syntax_error", "critical", rel, int(exc.lineno or 0), str(exc), "repair before promotion",
                ))
                continue

            parent_of = {child: parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)}

            def enclosing_function(node: ast.AST) -> str:
                cur = parent_of.get(node)
                while cur is not None:
                    if isinstance(cur, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        return cur.name
                    cur = parent_of.get(cur)
                return ""

            for node in ast.walk(tree):
                if isinstance(node, ast.ExceptHandler):
                    broad = node.type is None or (isinstance(node.type, ast.Name) and node.type.id == "Exception")
                    if broad and len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
                        findings.append(self._finding(
                            "silent_failure", "high", rel, getattr(node, "lineno", 0),
                            "broad exception is silently swallowed",
                            "record failure truth or narrow the exception; never erase the causal signal",
                        ))
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in {"eval", "exec"}:
                    owner = enclosing_function(node)
                    guarded = (rel, owner) in self.GUARDED_DYNAMIC_EXEC_SINKS
                    findings.append(self._finding(
                        "guarded_dynamic_execution" if guarded else "dynamic_code_execution",
                        "low" if guarded else "medium", rel, getattr(node, "lineno", 0),
                        (f"receipt/admission-bound {node.func.id}() sink in {owner}" if guarded else f"direct {node.func.id}() call"),
                        (
                            "keep hash/admission/isolated-child invariants regression-tested; do not widen this sink"
                            if guarded else
                            "bind executable mutations to an isolated body, explicit source hash, and receipt"
                        ),
                    ))
                if isinstance(node, ast.While) and isinstance(node.test, ast.Constant) and node.test.value is True:
                    findings.append(self._finding(
                        "unbounded_loop", "low", rel, getattr(node, "lineno", 0),
                        "while True loop requires an externally observable termination or heartbeat path",
                        "verify bounded exit/heartbeat semantics in tests",
                    ))
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name) and target.value.id[:1].isupper():
                            findings.append(self._finding(
                                "runtime_monkey_patch", "medium", rel, getattr(node, "lineno", 0),
                                f"class attribute patched at runtime: {target.value.id}.{target.attr}",
                                "move behavior into the class or an explicit adapter registry",
                            ))
            for line_no, line in enumerate(text.splitlines(), start=1):
                if re.search(r"\bTODO\b|\bFIXME\b|\bHACK\b", line):
                    findings.append(self._finding(
                        "unfinished_marker", "low", rel, line_no, line.strip()[:240],
                        "convert to a tracked opcode or close it with evidence",
                    ))

        generated_at = time.time()
        report_id = "code_doctor_" + hashlib.sha256(
            json.dumps([fingerprint, [asdict(x) for x in findings]], ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()[:20]
        report = CodeDoctorReport(report_id, fingerprint, len(snapshot), tuple(findings), generated_at)
        payload = report.as_mapping()
        tmp = self.latest_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.latest_path)
        with self.history_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return report
