from __future__ import annotations

"""Runs the representation tournament instead of describing it.

`representation_tournament` compiles frames; until now those frames were flattened
into instruction strings and appended to the turn's next-work list, so nothing ever
checked that materially different candidates were produced, attacked, or compared.
A plan that is only ever read is indistinguishable from no plan.

This engine holds the round: it records one candidate per frame, records the
refutations candidates raise against each other, and adjudicates deterministically.
The generator is still the host model — the runtime cannot write the candidates. What
it can do is refuse to call a round decided when the work the round is named after did
not happen, which is the same execution-truth boundary the rest of the runtime keeps.

Scoring is heuristic and says so. Its job is ordering plus a floor on process, not a
claim of measured quality: coverage and distinctness are computed from token overlap,
and survival counts refutations nobody answered.
"""

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Mapping

from .representation_tournament import RepresentationTournamentPlan
from .requirement_contract import RequirementContract

_IDENTICAL = 0.90
_SEVERITY = {"minor": 1.0, "major": 2.5, "fatal": 6.0}
# Measured on Korean and English pairs: candidates that addressed an atom overlapped it
# by 0.25 to 1.00, ones that did not scored a flat 0.00. The gap is wide, so this sits
# below the lowest positive rather than splitting the difference — a missed atom should
# cost coverage, but a candidate that phrases things its own way should not.
_ADDRESSED = 0.15
_WORD = re.compile(r"[^\W_]+", re.UNICODE)


def _tokens(text: str) -> set[str]:
    """Overlap features that work for particle-attaching languages too.

    Whitespace tokens alone score Korean at about zero: the particle attaches to the
    noun, so "구조" in a requirement and "구조를" in a candidate are different tokens and
    a candidate that plainly addresses the atom earns no coverage at all. Character
    bigrams survive the particle, so both kinds of feature are kept and compared
    together — words carry the Latin case, bigrams carry the Korean one.
    """
    body = str(text).casefold()
    features = {t for t in _WORD.findall(body) if len(t) > 1}
    squeezed = re.sub(r"\s+", "", body)
    features |= {squeezed[i:i + 2] for i in range(len(squeezed) - 1)}
    return features


def _sha(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class SemanticProfile:
    """Meaning-level structure supplied by the host model, kept separate from prose.

    This is deliberately not inferred from surface text by the runtime. The model that
    understands the candidate can expose the assumptions/causality/failure/evidence
    structure, and the runtime can then detect "different wording, same model" without
    pretending string distance is semantic judgement.
    """
    assumptions: tuple[str, ...] = ()
    causal_model: tuple[str, ...] = ()
    failure_modes: tuple[str, ...] = ()
    required_evidence: tuple[str, ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Candidate:
    frame_id: str
    text: str
    text_sha256: str
    semantic_profile: SemanticProfile | None = None

    def as_mapping(self) -> dict[str, Any]:
        row = {"frame_id": self.frame_id, "text": self.text, "text_sha256": self.text_sha256}
        row["semantic_profile"] = self.semantic_profile.as_mapping() if self.semantic_profile else None
        return row


@dataclass(frozen=True)
class Refutation:
    attacker_frame: str
    target_frame: str
    claim: str
    severity: str
    answered: bool = False

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ScoredCandidate:
    frame_id: str
    score: float
    coverage: float
    distinctness: float
    survival: float
    unanswered_refutations: int
    semantic_distinctness: float | None = None

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RoundVerdict:
    round_id: str
    decided: bool
    ranked: tuple[ScoredCandidate, ...]
    findings: tuple[str, ...]
    winner_frame: str | None
    merge_candidates: tuple[str, ...]
    synthesis_rule: str
    convergence_detected: bool = False
    selection_role: str = "heuristic ordering; not truth, quality measurement, or mandatory winner selection"

    def as_mapping(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "ranked": [row.as_mapping() for row in self.ranked],
        }


@dataclass
class TournamentRound:
    round_id: str
    message_sha256: str
    contract_sha256: str
    expected_frames: tuple[str, ...]
    min_candidates: int
    refutation_required: bool
    synthesis_rule: str
    candidates: dict[str, Candidate] = field(default_factory=dict)
    refutations: list[Refutation] = field(default_factory=list)

    def as_mapping(self) -> dict[str, Any]:
        return {
            "round_id": self.round_id,
            "message_sha256": self.message_sha256,
            "contract_sha256": self.contract_sha256,
            "expected_frames": list(self.expected_frames),
            "min_candidates": self.min_candidates,
            "refutation_required": self.refutation_required,
            "synthesis_rule": self.synthesis_rule,
            "candidates": {k: v.as_mapping() for k, v in self.candidates.items()},
            "refutations": [r.as_mapping() for r in self.refutations],
        }


class TournamentEngine:
    """Ledger and adjudicator for one representation tournament round."""

    def __init__(self, root: Path | str | None = None) -> None:
        self.root = Path(root) / "tournament" if root is not None else None
        self._rounds: dict[str, TournamentRound] = {}

    # ---- round lifecycle -------------------------------------------------

    def open_round(
        self,
        message: str,
        contract: RequirementContract,
        plan: RepresentationTournamentPlan,
        *,
        min_candidates: int | None = None,
    ) -> TournamentRound:
        frames = tuple(frame.frame_id for frame in plan.frames)
        if len(frames) < 2:
            raise ValueError("a tournament needs at least two frames; this plan is single-frame")
        round_id = "trn_" + _sha(contract.contract_sha256 + "\n" + "\n".join(frames))[:20]
        floor = min(len(frames), 3) if min_candidates is None else int(min_candidates)
        if floor < 2:
            raise ValueError("a tournament needs at least two candidates to compare")
        row = TournamentRound(
            round_id=round_id,
            message_sha256=_sha(message),
            contract_sha256=contract.contract_sha256,
            expected_frames=frames,
            min_candidates=floor,
            # Below three candidates there is no cross-examination to demand; from three
            # up, a round with no attack recorded is a parade, not a tournament.
            refutation_required=floor >= 3,
            synthesis_rule=plan.synthesis_rule,
        )
        self._rounds[round_id] = row
        self._persist(row)
        return row

    def directives(self, plan: RepresentationTournamentPlan) -> tuple[dict[str, str], ...]:
        return tuple(
            {"frame_id": frame.frame_id, "mode": frame.mode, "instruction": frame.instruction,
             "purpose": frame.purpose}
            for frame in plan.frames
        )

    def submit_candidate(
        self, round_id: str, frame_id: str, text: str,
        *, semantic_profile: Mapping[str, Any] | SemanticProfile | None = None,
    ) -> Candidate:
        row = self._require(round_id)
        if frame_id not in row.expected_frames:
            raise KeyError(f"frame {frame_id} is not part of round {round_id}")
        body = str(text).strip()
        if not body:
            raise ValueError("a candidate needs a body; an empty submission is not an answer")
        profile = self._coerce_semantic_profile(semantic_profile)
        candidate = Candidate(frame_id=frame_id, text=body, text_sha256=_sha(body), semantic_profile=profile)
        row.candidates[frame_id] = candidate
        self._persist(row)
        return candidate

    def submit_refutation(
        self, round_id: str, attacker_frame: str, target_frame: str, claim: str,
        *, severity: str = "major", answered: bool = False,
    ) -> Refutation:
        row = self._require(round_id)
        if severity not in _SEVERITY:
            raise ValueError(f"severity must be one of {sorted(_SEVERITY)}")
        if attacker_frame == target_frame:
            raise ValueError("a candidate cannot refute itself")
        for frame_id in (attacker_frame, target_frame):
            if frame_id not in row.expected_frames:
                raise KeyError(f"frame {frame_id} is not part of round {round_id}")
        if not str(claim).strip():
            raise ValueError("a refutation needs a stated claim")
        refutation = Refutation(attacker_frame, target_frame, str(claim).strip(), severity, bool(answered))
        row.refutations.append(refutation)
        self._persist(row)
        return refutation

    # ---- adjudication ----------------------------------------------------

    def adjudicate(self, round_id: str, contract: RequirementContract) -> RoundVerdict:
        row = self._require(round_id)
        findings: list[str] = []
        submitted = tuple(row.candidates)

        if len(submitted) < row.min_candidates:
            missing = [f for f in row.expected_frames if f not in row.candidates]
            findings.append(
                f"insufficient_candidates:{len(submitted)}/{row.min_candidates}"
                + (":missing=" + ",".join(missing[:6]) if missing else "")
            )

        similarity = self._max_similarity(row)
        if len(submitted) >= 2 and similarity >= _IDENTICAL:
            findings.append(f"candidates_are_not_materially_different:max_similarity={similarity:.2f}")
        semantic_convergence = self._semantic_convergence(row)
        if semantic_convergence is not None and semantic_convergence >= _IDENTICAL:
            findings.append(f"semantic_convergence_detected:max_similarity={semantic_convergence:.2f}")
        if row.refutation_required and not row.refutations:
            findings.append("no_refutation_recorded")

        ranked = self._score(row, contract)
        decided = not findings and bool(ranked)
        winner = ranked[0].frame_id if decided else None
        merge = tuple(
            item.frame_id for item in ranked[1:]
            if decided and item.unanswered_refutations == 0 and item.score >= ranked[0].score * 0.85
        )
        verdict = RoundVerdict(
            round_id=row.round_id,
            decided=decided,
            ranked=ranked,
            findings=tuple(findings),
            winner_frame=winner,
            merge_candidates=merge,
            synthesis_rule=row.synthesis_rule,
            convergence_detected=any("convergence" in finding or "not_materially_different" in finding for finding in findings),
        )
        self._persist(row, verdict)
        return verdict

    def _score(self, row: TournamentRound, contract: RequirementContract) -> tuple[ScoredCandidate, ...]:
        atoms = [(_tokens(atom.text), atom.critical) for atom in contract.atoms]
        atoms = [(toks, critical) for toks, critical in atoms if toks]
        scored: list[ScoredCandidate] = []
        for frame_id, candidate in row.candidates.items():
            body = _tokens(candidate.text)
            if atoms:
                weights = [2.0 if critical else 1.0 for _, critical in atoms]
                hits = [
                    weight for (toks, _), weight in zip(atoms, weights)
                    if len(toks & body) / len(toks) >= _ADDRESSED
                ]
                coverage = sum(hits) / sum(weights)
            else:
                coverage = 1.0
            others = [c.text for fid, c in row.candidates.items() if fid != frame_id]
            distinctness = 1.0 - max(
                (SequenceMatcher(None, candidate.text, other).ratio() for other in others), default=0.0
            )
            semantic_others = [
                c.semantic_profile for fid, c in row.candidates.items()
                if fid != frame_id and c.semantic_profile is not None
            ]
            semantic_distinctness = None
            if candidate.semantic_profile is not None and semantic_others:
                semantic_distinctness = 1.0 - max(
                    self._semantic_profile_similarity(candidate.semantic_profile, other)
                    for other in semantic_others
                )
            unanswered = [
                r for r in row.refutations if r.target_frame == frame_id and not r.answered
            ]
            penalty = sum(_SEVERITY[r.severity] for r in unanswered)
            survival = 1.0 / (1.0 + penalty)
            score = 0.40 * coverage + 0.35 * survival + 0.25 * distinctness
            scored.append(ScoredCandidate(
                frame_id=frame_id, score=round(score, 4), coverage=round(coverage, 4),
                distinctness=round(distinctness, 4), survival=round(survival, 4),
                unanswered_refutations=len(unanswered),
                semantic_distinctness=(round(semantic_distinctness, 4) if semantic_distinctness is not None else None),
            ))
        # Ties resolve by frame id so the same round always adjudicates the same way.
        scored.sort(key=lambda item: (-item.score, item.frame_id))
        return tuple(scored)

    @staticmethod
    def _coerce_semantic_profile(value: Mapping[str, Any] | SemanticProfile | None) -> SemanticProfile | None:
        if value is None:
            return None
        if isinstance(value, SemanticProfile):
            return value
        if not isinstance(value, Mapping):
            raise ValueError("semantic_profile must be a mapping or SemanticProfile")

        def rows(name: str) -> tuple[str, ...]:
            raw = value.get(name, ())
            if isinstance(raw, str):
                raw = (raw,)
            if not isinstance(raw, (list, tuple)):
                raise ValueError(f"semantic_profile.{name} must be text or a list of text")
            return tuple(str(item).strip() for item in raw if str(item).strip())

        return SemanticProfile(
            assumptions=rows("assumptions"),
            causal_model=rows("causal_model"),
            failure_modes=rows("failure_modes"),
            required_evidence=rows("required_evidence"),
        )

    @staticmethod
    def _semantic_profile_similarity(left: SemanticProfile, right: SemanticProfile) -> float:
        """Compare declared semantic axes without treating prose distance as meaning.

        Empty-on-both axes are ignored. A populated axis on only one side is maximally
        different. Populated pairs use token Jaccard over the axis contents. This is
        still a structural heuristic, not semantic truth; the important improvement is
        that the host explicitly supplies the meaning-level axes being compared.
        """
        scores: list[float] = []
        for name in ("assumptions", "causal_model", "failure_modes", "required_evidence"):
            lrows = getattr(left, name)
            rrows = getattr(right, name)
            if not lrows and not rrows:
                continue
            if not lrows or not rrows:
                scores.append(0.0)
                continue
            lt = _tokens(" ".join(lrows))
            rt = _tokens(" ".join(rrows))
            union = lt | rt
            scores.append((len(lt & rt) / len(union)) if union else 1.0)
        return sum(scores) / len(scores) if scores else 0.0

    @classmethod
    def _semantic_convergence(cls, row: TournamentRound) -> float | None:
        profiles = [candidate.semantic_profile for candidate in row.candidates.values() if candidate.semantic_profile]
        if len(profiles) < 2:
            return None
        best = 0.0
        pairs = 0
        for index, left in enumerate(profiles):
            for right in profiles[index + 1:]:
                best = max(best, cls._semantic_profile_similarity(left, right))
                pairs += 1
        return best if pairs else None

    @staticmethod
    def _max_similarity(row: TournamentRound) -> float:
        texts = [c.text for c in row.candidates.values()]
        best = 0.0
        for i, left in enumerate(texts):
            for right in texts[i + 1:]:
                best = max(best, SequenceMatcher(None, left, right).ratio())
        return best

    # ---- storage ---------------------------------------------------------

    def _require(self, round_id: str) -> TournamentRound:
        row = self._rounds.get(round_id)
        if row is None:
            raise KeyError(f"unknown tournament round: {round_id}")
        return row

    def _persist(self, row: TournamentRound, verdict: RoundVerdict | None = None) -> None:
        if self.root is None:
            return
        self.root.mkdir(parents=True, exist_ok=True)
        payload = row.as_mapping()
        if verdict is not None:
            payload["verdict"] = verdict.as_mapping()
        target = self.root / f"{row.round_id}.json"
        tmp = target.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(target)


def load_round(root: Path | str, round_id: str) -> Mapping[str, Any]:
    return json.loads((Path(root) / "tournament" / f"{round_id}.json").read_text(encoding="utf-8"))


__all__ = [
    "Candidate", "SemanticProfile", "Refutation", "RoundVerdict", "ScoredCandidate",
    "TournamentEngine", "TournamentRound", "load_round",
]
