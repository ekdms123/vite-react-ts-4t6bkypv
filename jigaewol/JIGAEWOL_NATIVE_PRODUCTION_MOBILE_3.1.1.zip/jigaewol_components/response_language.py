from __future__ import annotations

"""Shared interpretation of response assertions and observed failure records."""

import re
from collections.abc import Iterable, Mapping
from typing import Any


_REPORTING = re.compile(
    r"(?:문구|문자열|메시지|오류|예시|인용|테스트|뜻|의미|라는|이라고|"
    r"\b(?:message|string|error|example|quote|quoted|phrase|means|meaning|reads|test)\b)", re.I
)
_QUOTED = re.compile(r'“[^”\n]*”|「[^」\n]*」|『[^』\n]*』|"[^"\n]+"|(?<!\w)\x27[^\x27\n]+\x27(?!\w)')
_NEGATED_CEILINGS = (
    re.compile(r"(?:할\s*수(?:는)?\s*없|불가능)(?:하다고|이라고)?[^\n.!?;]{0,40}?(?:판단|단정|결론)(?:하지\s*않|하지\s*말|하지\s*마)", re.I),
    re.compile(r"(?:못\s*한|못\s*하|불가능)[^\n.!?;]{0,40}?(?:취급|간주)(?:하지\s*않|하지\s*말|하지\s*마)", re.I),
    re.compile(r"\b(?:do\s+not|don't|never|will\s+not|won't)\s+(?:assume|conclude|declare|treat)[^\n.!?;]{0,80}?\b(?:impossible|unsupported|cannot|can't)\b", re.I),
    re.compile(r"\b(?:not|isn't|is\s+not)\s+(?:necessarily\s+)?(?:impossible|unsupported)\b", re.I),
)
_BOUNDARY = re.compile(r"(?:플랫폼|호스트|상위\s*(?:시스템|규칙)|안전\s*규칙|(?:입력|물리적)\s*파이프라인|\b(?:platform|host|upstream\s+system|system\s+rules?|safety\s+rules?|(?:physical\s+)?input\s+pipeline)\b)", re.I)
_BOUNDARY_QUESTION = re.compile(r"(?:가능|불가능|한계|경계|제약|왜|설명|알려|여부|\?|\b(?:can|could|why|whether|explain|limits?|boundar(?:y|ies)|constraints?)\b)", re.I)


def assertion_text(text: str) -> str:
    """Exclude code, attributed quotations, and explicitly negated ceiling claims.

    Bare quoted refusals remain assertions. Reporting context must exist outside the
    quote, so wrapping an actual refusal in quotation marks does not exempt it.
    """
    body = str(text or "")
    body = re.sub(r"(?ms)^[ \t]*(?:```|~~~)[^\n]*\n.*?^[ \t]*(?:```|~~~)[ \t]*$", " ", body)
    body = re.sub(r"(`+)[^`\n]*\1", " ", body)
    body = re.sub(r"(?m)^\s*>[^\n]*$", " ", body)

    def quoted(match: re.Match[str]) -> str:
        left = body[max(0, match.start() - 80):match.start()]
        right = body[match.end():match.end() + 80]
        return " " if _REPORTING.search(left + right) else match.group(0)

    body = _QUOTED.sub(quoted, body)
    # Error explanations often reproduce an unquoted English message in Korean.
    body = re.sub(
        r"[A-Za-z][A-Za-z0-9_ :/\-]{0,100}\b(?:cannot|can't|unsupported|impossible)\b"
        r"[^\n.!?;]{0,80}?(?:라는|이라는|는)\s*[^\n.!?;]{0,30}?(?:오류\s*)?(?:메시지|문구|문자열)",
        " ", body, flags=re.I,
    )
    for pattern in _NEGATED_CEILINGS:
        body = pattern.sub(" ", body)
    return body


def boundary_discussion_requested(source_text: str) -> bool:
    source = str(source_text or "")
    # Keep the boundary and the question in the same source sentence. A previous
    # requirement about boundaries must not exempt an unrelated current request.
    return any(_BOUNDARY.search(part) and _BOUNDARY_QUESTION.search(part)
               for part in re.split(r"[\n.!;。！？]+", source))


def is_observed_failure(row: Mapping[str, Any]) -> bool:
    if row.get("success") is False or row.get("ok") is False:
        return True
    if row.get("success") is True or row.get("ok") is True:
        return False
    status = str(row.get("status") or row.get("state") or "").casefold()
    if status in {"failed", "failure", "error", "errored", "timeout", "timed_out", "blocked"}:
        return True
    for key in ("exit_code", "returncode"):
        try:
            if key in row and int(row[key]) != 0:
                return True
        except (TypeError, ValueError, OverflowError):
            pass
    try:
        return "status_code" in row and 400 <= int(row["status_code"]) <= 599
    except (TypeError, ValueError, OverflowError):
        return False


def observed_failure_rows(observations: Any) -> tuple[dict[str, Any], ...]:
    rows: list[dict[str, Any]] = []

    def walk(value: Any) -> None:
        if isinstance(value, Mapping):
            if is_observed_failure(value):
                rows.append(dict(value))
            elif value.get("success") is not True and value.get("ok") is not True:
                for child in value.values():
                    walk(child)
        elif isinstance(value, Iterable) and not isinstance(value, (str, bytes, bytearray)):
            for child in value:
                walk(child)

    walk(observations)
    return tuple(rows)
