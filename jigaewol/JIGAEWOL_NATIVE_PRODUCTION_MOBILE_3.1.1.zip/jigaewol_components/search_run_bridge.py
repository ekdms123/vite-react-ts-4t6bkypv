from __future__ import annotations

from dataclasses import asdict
from typing import Any, Iterable, Mapping

from .durable_run_protocol import DurableRunLedger
from .search_portfolio_engine import SearchPortfolioEngine


SEARCH_EVENT_KIND = "search_observation"


class SearchRunBridge:
    """Bind observed search/browser results to a durable long-running work stream.

    It never manufactures a run binding.  Automatic binding is allowed only when
    exactly one running chat work stream exists.  Ambiguity stays explicit so a
    search result cannot leak into the wrong user task.
    """

    def __init__(self, runs: DurableRunLedger) -> None:
        self.runs = runs

    def resolve_unique_live_chat_run(self) -> str:
        candidates = [
            run for run in self.runs.list_runs(status="running", limit=200)
            if str(run.worker_ref).startswith("chat:")
        ]
        if len(candidates) != 1:
            return ""
        return candidates[0].run_id

    def journal(
        self,
        *,
        action_row: Mapping[str, Any],
        success: bool,
        items: Iterable[Mapping[str, Any]] = (),
        evidence_refs: Iterable[str] = (),
        observation_sha256: str = "",
        observed_at: float | None = None,
        run_id: str = "",
    ) -> dict[str, Any]:
        rid = str(run_id).strip() or self.resolve_unique_live_chat_run()
        if not rid:
            return {
                "journaled": False,
                "reason": "no_unique_running_chat_run",
                "run_id": "",
            }
        family = str(action_row.get("family") or "web_current")
        rows = tuple(dict(x) for x in items)
        followup = SearchPortfolioEngine.derive_followup_program(rows, family)
        evidence = tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x).strip()))
        payload = {
            "action_id": str(action_row.get("action_id") or ""),
            "release_turn_id": str(action_row.get("release_turn_id") or ""),
            "source_family": family,
            "capability": str(action_row.get("capability") or ""),
            "executor": str(action_row.get("selected_executor") or ""),
            "success": bool(success),
            "item_count": len(rows),
            "items": rows,
            "followup_program": followup,
            "observation_sha256": str(observation_sha256),
        }
        action_id = payload["action_id"] or "unknown"
        idem = f"search-observation:{action_id}:{observation_sha256 or 'no-sha'}"
        try:
            event = self.runs.append_event(
                rid,
                kind=SEARCH_EVENT_KIND,
                payload=payload,
                evidence_refs=evidence,
                idempotency_key=idem,
                observed_at=observed_at,
            )
        except RuntimeError as exc:
            return {
                "journaled": False,
                "reason": str(exc),
                "run_id": rid,
            }
        return {
            "journaled": True,
            "run_id": rid,
            "sequence": event.sequence,
            "event_kind": event.kind,
            "payload_sha256": event.payload_sha256,
        }

    def replay_summary(self, run_id: str, *, cursor: int = 0, limit: int = 100) -> dict[str, Any]:
        page = self.runs.replay(str(run_id), cursor=int(cursor), limit=int(limit))
        coverage: dict[str, int] = {}
        terms: list[str] = []
        links: list[str] = []
        observations = []
        for event in page.events:
            if event.kind != SEARCH_EVENT_KIND or not isinstance(event.payload, dict):
                continue
            payload = dict(event.payload)
            family = str(payload.get("source_family") or "unknown")
            coverage[family] = coverage.get(family, 0) + int(payload.get("item_count") or 0)
            followup = dict(payload.get("followup_program") or {})
            for raw in followup.get("observed_terms") or ():
                term = str(raw).strip()
                if term and term.casefold() not in {x.casefold() for x in terms}:
                    terms.append(term)
            for raw in followup.get("observed_links") or ():
                link = str(raw).strip()
                if link and link not in links:
                    links.append(link)
            observations.append({
                "sequence": event.sequence,
                "source_family": family,
                "success": bool(payload.get("success")),
                "item_count": int(payload.get("item_count") or 0),
                "action_id": str(payload.get("action_id") or ""),
                "observation_sha256": str(payload.get("observation_sha256") or ""),
            })
        return {
            "run_id": page.run_id,
            "cursor": page.cursor,
            "next_cursor": page.next_cursor,
            "latest_sequence": page.latest_sequence,
            "has_more": page.has_more,
            "terminal": page.terminal,
            "terminal_kind": page.terminal_kind,
            "cursor_ahead": page.cursor_ahead,
            "gap_detected": page.gap_detected,
            "source_coverage": coverage,
            "observed_terms": terms,
            "observed_links": links,
            "search_observations": observations,
            "events_seen": len(page.events),
        }
