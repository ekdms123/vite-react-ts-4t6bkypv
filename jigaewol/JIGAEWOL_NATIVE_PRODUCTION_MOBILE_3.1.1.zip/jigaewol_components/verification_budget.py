from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class VerificationBudget:
    mode: str
    fraction: float | None
    reason: str


class VerificationBudgetPolicy:
    """Keeps verification as a bounded truth tax instead of the task objective."""

    @staticmethod
    def choose(*, required_count: int, facets: Mapping[str, Any] | None = None) -> VerificationBudget:
        facets = dict(facets or {})
        forced = str(facets.get("fidelity_mode") or "").casefold()
        if forced in {"none", "deterministic", "ghost"}:
            return VerificationBudget(forced, None, "explicit_runtime_override")
        if required_count <= 0:
            return VerificationBudget("none", None, "no_claim_requires_execution_proof")
        if bool(facets.get("force_ghost_verification")) or bool(facets.get("user_explicit_verification")):
            return VerificationBudget("ghost", None, "explicit_verification_request")
        return VerificationBudget("deterministic", None, "claim_appropriate_truth_check")
