from __future__ import annotations

import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .host_action_truth import worker_truth_from_host_action


def _key(value: str) -> str:
    return str(value or "").strip().casefold().replace("-", "_").replace(" ", "_")


@dataclass(frozen=True)
class HostProviderTruth:
    provider_id: str
    executor: str
    catalog_state: str
    callable_actions: tuple[str, ...]
    successful_actions: tuple[str, ...]
    failed_actions: tuple[str, ...]
    proven_capabilities: tuple[str, ...]
    unproven_callable_actions: tuple[str, ...]
    status: str
    last_failure_family: str
    independent_cognitive_worker_actions: tuple[str, ...]
    running_cognitive_worker_actions: tuple[str, ...]
    closed_loop_agent_worker_actions: tuple[str, ...]


class HostCapabilityMatrix:
    """Join catalog visibility with observed action receipts without conflating them."""

    def __init__(self, root: str | Path, *, action_state_root: str | Path | None = None) -> None:
        self.root = Path(root)
        self.action_state_root = Path(action_state_root) if action_state_root is not None else self.root

    def _record_failure(self, kind: str, source: Path, error: BaseException) -> None:
        failure_path = self.root / "host_surface" / "capability_matrix_failures.jsonl"
        failure_path.parent.mkdir(parents=True, exist_ok=True)
        row = {
            "kind": str(kind),
            "source": str(source),
            "error_type": type(error).__name__,
            "error": str(error),
            "created_at": time.time(),
        }
        with failure_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")

    def _catalog(self) -> dict[str, dict[str, Any]]:
        p = self.root / "host_surface" / "live_surface.json"
        if not p.is_file():
            return {}
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("host capability catalog must be a JSON object")
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            self._record_failure("host_capability_catalog_corrupt", p, exc)
            raise RuntimeError(f"host capability catalog unreadable or corrupt: {exc}") from exc
        out: dict[str, dict[str, Any]] = {}
        for row in data.get("capabilities") or ():
            if not isinstance(row, dict):
                continue
            pid = _key(str(row.get("id") or row.get("provider") or row.get("executor") or ""))
            if pid:
                out[pid] = row
        return out

    def _action_state(self) -> dict[str, Any]:
        p = self.action_state_root / "host_surface" / "action_truth_state.json"
        if not p.is_file():
            return {"actions": {}}
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("host action truth state must be a JSON object")
            actions = data.setdefault("actions", {})
            if not isinstance(actions, dict):
                raise TypeError("host action truth actions must be a JSON object")
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            self._record_failure("host_action_truth_corrupt", p, exc)
            raise RuntimeError(f"host action truth unreadable or corrupt: {exc}") from exc
        return data

    def snapshot(self) -> tuple[HostProviderTruth, ...]:
        catalog = self._catalog()
        action_state = self._action_state().get("actions") or {}
        providers = set(catalog)
        for key in action_state:
            providers.add(str(key).split(":", 1)[0])
        rows: list[HostProviderTruth] = []
        for pid in sorted(providers):
            cat = dict(catalog.get(pid) or {})
            callable_actions = tuple(dict.fromkeys(str(x) for x in cat.get("actions") or () if str(x).strip()))
            successes: list[str] = []
            failures: list[str] = []
            caps: list[str] = []
            failure_family = ""
            cognitive_actions: list[str] = []
            running_actions: list[str] = []
            closed_loop_actions: list[str] = []
            for key, raw in action_state.items():
                if not str(key).startswith(pid + ":") or not isinstance(raw, dict):
                    continue
                action = str(key).split(":", 1)[1]
                success = raw.get("last_success")
                failure = raw.get("last_failure")
                if isinstance(success, dict):
                    successes.append(action)
                    caps.extend(str(x) for x in success.get("proven_capabilities") or () if str(x).strip())
                    truth = worker_truth_from_host_action(pid, action, success)
                    if truth.independent_cognitive_worker:
                        cognitive_actions.append(action)
                        if truth.state == "running":
                            running_actions.append(action)
                    if truth.closed_loop_agent_worker:
                        closed_loop_actions.append(action)
                if isinstance(failure, dict):
                    failures.append(action)
                    err = str(failure.get("error") or "")
                    summary = failure.get("result_summary") if isinstance(failure.get("result_summary"), dict) else {}
                    failure_family = str(summary.get("failure_family") or err or failure_family)
            successful_actions = tuple(sorted(set(successes)))
            failed_actions = tuple(sorted(set(failures)))
            unproven = tuple(x for x in callable_actions if _key(x) not in {_key(a) for a in successful_actions})
            cat_state = str(cat.get("state") or ("not_catalogued" if not cat else "discovered"))
            if successful_actions:
                status = "observed_success"
            elif callable_actions or cat_state == "callable":
                status = "callable_unproven"
            elif failed_actions:
                status = "observed_failure_only"
            else:
                status = "discovered_only"
            rows.append(HostProviderTruth(
                provider_id=pid,
                executor=str(cat.get("executor") or pid),
                catalog_state=cat_state,
                callable_actions=callable_actions,
                successful_actions=successful_actions,
                failed_actions=failed_actions,
                proven_capabilities=tuple(sorted(set(caps))),
                unproven_callable_actions=unproven,
                status=status,
                last_failure_family=failure_family,
                independent_cognitive_worker_actions=tuple(sorted(set(cognitive_actions))),
                running_cognitive_worker_actions=tuple(sorted(set(running_actions))),
                closed_loop_agent_worker_actions=tuple(sorted(set(closed_loop_actions))),
            ))
        return tuple(rows)

    def as_mapping(self) -> dict[str, Any]:
        rows = self.snapshot()
        return {
            "format": "jigaewol_host_capability_matrix_v1",
            "provider_count": len(rows),
            "observed_success_provider_count": sum(x.status == "observed_success" for x in rows),
            "independent_cognitive_worker_provider_count": sum(bool(x.independent_cognitive_worker_actions) for x in rows),
            "running_cognitive_worker_provider_count": sum(bool(x.running_cognitive_worker_actions) for x in rows),
            "closed_loop_agent_worker_provider_count": sum(bool(x.closed_loop_agent_worker_actions) for x in rows),
            "providers": [asdict(x) for x in rows],
            "truth_rule": "catalog callable != action executed; only observed successful actions prove action-level capabilities",
        }
