from __future__ import annotations

"""Materialize a born organ as a callable body carrying its generated interpreter."""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import hashlib

from .capsule_runtime import CapsuleRuntime


@dataclass(frozen=True, slots=True)
class MaterializedOrganBody:
    body_id: str
    path: str
    capsule_path: str
    interpreter_sha256: str = ""
    self_contained_interpreter: bool = True

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class OrganBodyBuilder:
    def materialize(self, *, capsule_path: str | Path, output_path: str | Path) -> MaterializedOrganBody:
        """Birth a body from capsule semantics rather than a fixed CapsuleRuntime wrapper.

        The capsule is read once during materialization.  Its generated interpreter source
        and entrypoint are embedded into the body so the resulting callable body carries
        the semantics that were born with the organ.
        """
        capsule_path = Path(capsule_path).resolve()
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        capsule = CapsuleRuntime().read(capsule_path)
        spec = dict(capsule.manifest["execution"]["materialized_interpreter"])
        source_text = str(spec["source"])
        entrypoint = str(spec.get("entrypoint") or "run")
        interpreter_sha = hashlib.sha256(source_text.encode("utf-8")).hexdigest()
        declared = str(spec.get("sha256") or "")
        if declared and declared != interpreter_sha:
            raise ValueError("born interpreter source does not match capsule digest")
        body_id = "organ_body_" + hashlib.sha256((capsule.sha256 + interpreter_sha).encode()).hexdigest()[:20]
        source = f'''# Generated organ body: carries the interpreter born with its capsule.
import hashlib

BORN_INTERPRETER_SOURCE = {source_text!r}
BORN_INTERPRETER_SHA256 = {interpreter_sha!r}
BORN_ENTRYPOINT = {entrypoint!r}
CAPSULE_SHA256 = {capsule.sha256!r}


def _namespace():
    if hashlib.sha256(BORN_INTERPRETER_SOURCE.encode("utf-8")).hexdigest() != BORN_INTERPRETER_SHA256:
        raise ValueError("embedded born interpreter digest mismatch")
    ns = {{"__name__": "_jigaewol_born_organ_body_"}}
    exec(compile(BORN_INTERPRETER_SOURCE, "<born-organ-interpreter>", "exec"), ns, ns)
    return ns


def run(payload):
    payload = dict(payload or {{}})
    ns = _namespace()
    fn = ns[BORN_ENTRYPOINT]
    result = fn(dict(payload.get("state") or {{}}), list(payload.get("history") or ()))
    if isinstance(result, dict):
        return {{"success": True, **result, "capsule_sha256": CAPSULE_SHA256}}
    return {{"success": True, "output": result, "capsule_sha256": CAPSULE_SHA256}}
'''
        output_path.write_text(source, encoding="utf-8")
        return MaterializedOrganBody(body_id, str(output_path), str(capsule_path), interpreter_sha, True)
