from __future__ import annotations


import json
import sys
from dataclasses import dataclass
from pathlib import Path



@dataclass(frozen=True)
class DGMSourceEvidence:
    exact_source_executed: bool
    repository: str
    common_utils_blob: str
    evo_utils_blob: str
    last_generation: int
    archive_size: int


def execute_exact_source(source_root: Path, metadata_path: Path) -> DGMSourceEvidence:
    source_root = Path(source_root)
    sys.path.insert(0, str(source_root))
    try:
        from utils.evo_utils import load_dgm_metadata  # type: ignore
        last = load_dgm_metadata(str(metadata_path), last_only=True)
    finally:
        try:
            sys.path.remove(str(source_root))
        except ValueError:
            pass
    provenance = json.loads((source_root / "PROVENANCE.json").read_text(encoding="utf-8"))
    files = provenance["files"]
    return DGMSourceEvidence(
        exact_source_executed=True,
        repository=provenance["repository"],
        common_utils_blob=files["utils/common_utils.py"]["actual_git_blob_sha"],
        evo_utils_blob=files["utils/evo_utils.py"]["actual_git_blob_sha"],
        last_generation=int(last["generation"]),
        archive_size=len(last.get("archive", [])),
    )


