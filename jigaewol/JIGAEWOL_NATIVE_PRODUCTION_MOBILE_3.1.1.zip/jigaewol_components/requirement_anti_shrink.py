from __future__ import annotations

"""Durable requirement planning ledger that refuses silent compression.

The ledger is deliberately orthogonal to execution truth.  It records whether every
source requirement is explicitly satisfied, action-planned, research-planned, blocked,
or still unplanned.  A requirement can therefore never disappear merely because the
host planner emitted a smaller action set.
"""

import json
import time
from pathlib import Path
from typing import Any, Iterable, Mapping

from .requirement_contract import RequirementContract, response_deliverable
from .host_mirror import _atomic_json

PLANNED_STATES = frozenset({"satisfied", "action-planned", "research-planned"})
VALID_STATES = frozenset({*PLANNED_STATES, "unplanned", "blocked"})


class RequirementAntiShrinkLedger:
    SCHEMA = "jigaewol_requirement_anti_shrink_v1"

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.dir = self.root / "requirement_anti_shrink"
        self.dir.mkdir(parents=True, exist_ok=True)

    def _path(self, message_sha256: str) -> Path:
        return self.dir / f"{str(message_sha256)}.json"

    def _read(self, message_sha256: str) -> dict[str, Any]:
        path = self._path(message_sha256)
        if not path.is_file():
            return {}
        return json.loads(path.read_text(encoding="utf-8"))

    def ensure_contract(self, contract: RequirementContract) -> dict[str, Any]:
        current = self._read(contract.message_sha256)
        existing = {str(row.get("atom_id")): dict(row) for row in current.get("requirements", ()) if row.get("atom_id")}
        rows: list[dict[str, Any]] = []
        now = time.time()
        for atom in contract.atoms:
            row = existing.get(atom.atom_id, {})
            status = str(row.get("status") or "unplanned")
            if status not in VALID_STATES:
                status = "unplanned"
            rows.append({
                "atom_id": atom.atom_id,
                "source_index": atom.source_index,
                "kind": atom.kind,
                "critical": bool(atom.critical),
                "tags": list(atom.tags),
                "text": atom.text,
                "status": status,
                "evidence_refs": list(dict.fromkeys(str(x) for x in row.get("evidence_refs", ()) if str(x))),
                "required_action_ids": list(dict.fromkeys(str(x) for x in row.get("required_action_ids", ()) if str(x))),
                "completed_action_ids": list(dict.fromkeys(str(x) for x in row.get("completed_action_ids", ()) if str(x))),
                "failed_action_ids": list(dict.fromkeys(str(x) for x in row.get("failed_action_ids", ()) if str(x))),
                "note": str(row.get("note") or ""),
                "updated_at": float(row.get("updated_at") or now),
            })
        payload = {
            "schema": self.SCHEMA,
            "message_sha256": contract.message_sha256,
            "requirement_contract_sha256": contract.contract_sha256,
            "requirement_count": len(rows),
            "requirements": rows,
            "updated_at": now,
        }
        _atomic_json(self._path(contract.message_sha256), payload)
        return payload

    def mark(
        self,
        message_sha256: str,
        atom_id: str,
        status: str,
        *,
        evidence_refs: Iterable[str] = (),
        note: str = "",
    ) -> dict[str, Any]:
        status = str(status)
        if status not in VALID_STATES:
            raise ValueError(f"invalid requirement anti-shrink state: {status}")
        payload = self._read(message_sha256)
        if not payload:
            raise KeyError(f"unknown requirement ledger: {message_sha256}")
        found = False
        for row in payload.get("requirements", ()):
            if str(row.get("atom_id")) != str(atom_id):
                continue
            found = True
            row["status"] = status
            row["evidence_refs"] = list(dict.fromkeys([
                *[str(x) for x in row.get("evidence_refs", ()) if str(x)],
                *[str(x) for x in evidence_refs if str(x)],
            ]))
            if note:
                row["note"] = str(note)
            row["updated_at"] = time.time()
            break
        if not found:
            raise KeyError(f"unknown requirement atom: {atom_id}")
        payload["updated_at"] = time.time()
        _atomic_json(self._path(message_sha256), payload)
        return payload

    def plan_from_runtime(
        self,
        contract: RequirementContract,
        *,
        host_actions: Iterable[Any] = (),
        exploration_active: bool = False,
        satisfied_ids: Iterable[str] = (),
    ) -> dict[str, Any]:
        """Project planning state while preserving every required action obligation.

        A source requirement bound to multiple required host actions remains open until
        every required action has an observed successful outcome.  Planning therefore
        cannot collapse a multi-surface or multi-step requirement into the first
        successful receipt.
        """
        payload = self.ensure_contract(contract)
        required_actions = [a for a in host_actions if bool(getattr(a, "required", False))]
        action_bindings: dict[str, list[str]] = {}
        for action in required_actions:
            action_id = str(getattr(action, "action_id", "") or "")
            raw_payload = getattr(action, "payload", {})
            action_payload = dict(raw_payload) if isinstance(raw_payload, Mapping) else {}
            bound_ids = action_payload.get("requirement_ids") or action_payload.get("requirement_bindings") or ()
            for raw_id in bound_ids:
                atom_id = str(raw_id or "")
                if not atom_id:
                    continue
                action_bindings.setdefault(atom_id, [])
                if action_id and action_id not in action_bindings[atom_id]:
                    action_bindings[atom_id].append(action_id)
        satisfied = {str(x) for x in satisfied_ids if str(x)}
        now = time.time()
        for row in payload.get("requirements", ()):
            atom_id = str(row.get("atom_id") or "")
            if atom_id in satisfied:
                row["status"] = "satisfied"
                row["evidence_refs"] = list(dict.fromkeys([*row.get("evidence_refs", ()), "explicit_satisfaction"]))
            elif atom_id in action_bindings:
                required = list(dict.fromkeys([*row.get("required_action_ids", ()), *action_bindings[atom_id]]))
                completed = [x for x in row.get("completed_action_ids", ()) if x in required]
                row["required_action_ids"] = required
                row["completed_action_ids"] = list(dict.fromkeys(completed))
                row["failed_action_ids"] = list(dict.fromkeys(str(x) for x in row.get("failed_action_ids", ()) if str(x)))
                row["evidence_refs"] = list(dict.fromkeys([*row.get("evidence_refs", ()), *required]))
                row["status"] = "satisfied" if required and set(required).issubset(set(completed)) else "action-planned"
            elif str(row.get("kind")) in {"question", "preference"} and exploration_active:
                if str(row.get("status")) != "satisfied":
                    row["status"] = "research-planned"
                    row["evidence_refs"] = list(dict.fromkeys([*row.get("evidence_refs", ()), "cognition:exploration_generate"]))
            row["updated_at"] = now
        payload["updated_at"] = now
        _atomic_json(self._path(contract.message_sha256), payload)
        return payload

    def record_action_outcome(
        self,
        message_sha256: str,
        atom_id: str,
        action_id: str,
        *,
        success: bool,
        evidence_refs: Iterable[str] = (),
        obligation_action_id: str = "",
    ) -> dict[str, Any]:
        """Bind one observed host action result to one source requirement.

        ``obligation_action_id`` lets a successful failover satisfy the original
        required action it replaced without pretending the failed route itself
        succeeded.  When omitted, the observed action is its own obligation.
        """
        payload = self._read(message_sha256)
        if not payload:
            raise KeyError(f"unknown requirement ledger: {message_sha256}")
        observed = str(action_id or "").strip()
        obligation = str(obligation_action_id or observed).strip()
        if not observed or not obligation:
            raise ValueError("action_id must be non-empty")
        target = None
        for row in payload.get("requirements", ()):
            if str(row.get("atom_id")) == str(atom_id):
                target = row
                break
        if target is None:
            raise KeyError(f"unknown requirement atom: {atom_id}")
        required = list(dict.fromkeys(str(x) for x in target.get("required_action_ids", ()) if str(x)))
        if obligation not in required:
            required.append(obligation)
        completed = list(dict.fromkeys(str(x) for x in target.get("completed_action_ids", ()) if str(x)))
        failed = list(dict.fromkeys(str(x) for x in target.get("failed_action_ids", ()) if str(x)))
        if success:
            if obligation not in completed:
                completed.append(obligation)
            failed = [x for x in failed if x != obligation]
        else:
            if obligation not in failed:
                failed.append(obligation)
        refs = list(dict.fromkeys([
            *[str(x) for x in target.get("evidence_refs", ()) if str(x)],
            *[str(x) for x in evidence_refs if str(x)],
            f"observed_action:{observed}",
        ]))
        complete = bool(required and set(required).issubset(set(completed)))
        target["required_action_ids"] = required
        target["completed_action_ids"] = completed
        target["failed_action_ids"] = failed
        target["evidence_refs"] = refs
        target["status"] = "satisfied" if complete else "action-planned"
        target["updated_at"] = time.time()
        payload["updated_at"] = time.time()
        _atomic_json(self._path(message_sha256), payload)
        return {
            "atom_id": str(atom_id),
            "observed_action_id": observed,
            "obligation_action_id": obligation,
            "success": bool(success),
            "requirement_complete": complete,
            "required_action_ids": tuple(required),
            "completed_action_ids": tuple(completed),
            "failed_action_ids": tuple(failed),
        }

    def coverage(self, message_sha256: str) -> dict[str, Any]:
        payload = self._read(message_sha256)
        rows = list(payload.get("requirements", ()))
        covered = [str(row.get("atom_id")) for row in rows if str(row.get("status")) in PLANNED_STATES]
        missing = [str(row.get("atom_id")) for row in rows if str(row.get("status")) not in PLANNED_STATES]
        counts: dict[str, int] = {}
        for row in rows:
            state = str(row.get("status") or "unplanned")
            counts[state] = counts.get(state, 0) + 1
        total = len(rows)
        return {
            "schema": self.SCHEMA,
            "message_sha256": str(payload.get("message_sha256") or message_sha256),
            "requirement_contract_sha256": str(payload.get("requirement_contract_sha256") or ""),
            "total": total,
            "covered": len(covered),
            "score": (len(covered) / total if total else 1.0),
            "covered_ids": tuple(covered),
            "missing": tuple(missing),
            "state_counts": counts,
            "complete": not missing,
            "coverage_means_explicitly_tracked_not_executed": True,
        }

    def completion_evidence(self, message_sha256: str, *, proposed_response_ids: Iterable[str] = (), response_evidence_ref: str = "",
                            not_applicable_ids: Iterable[str] = ()) -> dict[str, Any]:
        """Return current-message completion proof without inheriting older open goals.

        The anti-shrink ledger is keyed to the exact current user message.  A prior
        unfinished WorkProgram remains durable, but it must not make a later fully
        satisfied user turn impossible to finalize.  Every current atom still needs
        explicit satisfaction evidence; action atoms additionally require an observed
        execution-style reference.
        """
        payload = self._read(message_sha256)
        rows = list(payload.get("requirements", ()))
        proposed = set(proposed_response_ids) if response_evidence_ref else set()
        not_applicable = set(not_applicable_ids) if response_evidence_ref else set()
        completed: list[str] = []
        unresolved: list[str] = []
        evidence_refs: list[str] = []
        for row in rows:
            atom_id = str(row.get("atom_id") or "")
            refs = tuple(str(x) for x in row.get("evidence_refs", ()) if str(x))
            satisfied = str(row.get("status") or "") == "satisfied"
            deliverable = response_deliverable(str(row.get("kind") or ""), row.get("tags"))
            if atom_id in not_applicable:
                completed.append(atom_id)
                evidence_refs.append(f"alternative_branch_not_taken:{atom_id}")
                continue
            if atom_id in proposed and deliverable:
                satisfied = True
                refs = (*refs, response_evidence_ref)
            action_evidence = any(
                ref.startswith(("execution_receipt:", "canonical_host_result:", "host_result:", "origin_ref:"))
                or "observed host success" in ref.casefold()
                or ref.startswith("evidence:")
                for ref in refs
            )
            if satisfied and refs and (deliverable or action_evidence):
                completed.append(atom_id)
                evidence_refs.extend(refs)
            else:
                unresolved.append(atom_id)
        return {
            "proven": bool(rows) and not unresolved,
            "expected_goal_refs": tuple(str(r.get("atom_id") or "") for r in rows),
            "completed_goal_refs": tuple(completed),
            "unresolved_goal_refs": tuple(unresolved),
            "evidence_refs": tuple(dict.fromkeys(evidence_refs)),
            "rule": "exact_current_message_requirements_require_satisfied_evidence",
        }

    def completion_coverage(self, message_sha256: str, *, proposed_response_ids: Iterable[str] = (),
                            not_applicable_ids: Iterable[str] = ()) -> dict[str, Any]:
        """Measure delivered completion, not planning coverage.

        `coverage()` answers whether every source atom is still explicitly represented
        in the plan.  This method answers the stricter question used for completion:
        only `satisfied` atoms count as delivered.  Planned/research states therefore
        can never make a turn look complete by themselves.
        """
        payload = self._read(message_sha256)
        rows = list(payload.get("requirements", ()))
        proposed = set(proposed_response_ids)
        not_applicable = set(not_applicable_ids)
        satisfied_ids = [
            str(row.get("atom_id")) for row in rows
            if str(row.get("status") or "") == "satisfied"
            or str(row.get("atom_id")) in not_applicable
            or (response_deliverable(str(row.get("kind") or ""), row.get("tags")) and str(row.get("atom_id")) in proposed)
        ]
        missing = [
            str(row.get("atom_id")) for row in rows
            if str(row.get("atom_id")) not in satisfied_ids
        ]
        total = len(rows)
        return {
            "schema": self.SCHEMA,
            "message_sha256": str(payload.get("message_sha256") or message_sha256),
            "requirement_contract_sha256": str(payload.get("requirement_contract_sha256") or ""),
            "total": total,
            "satisfied": len(satisfied_ids),
            "score": (len(satisfied_ids) / total if total else 1.0),
            "satisfied_ids": tuple(satisfied_ids),
            "missing": tuple(missing),
            "complete": not missing,
            "completion_requires_satisfied_not_merely_planned": True,
        }
