"""Lossless content-addressed turn storage; legacy JSON remains readable."""
from __future__ import annotations
import hashlib
import json
import os
import tempfile
from pathlib import Path

def _atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix='.'+path.name)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)

def save_snapshot(path, value):
    path = Path(path)
    objects = path.parent.parent/'snapshot_objects'
    memo = {}
    def encode(node, top=False):
        if isinstance(node, (dict, list)):
            ident = id(node)
            if ident in memo and not top:
                return memo[ident]
            packed = {k: encode(v) for k, v in node.items()} if isinstance(node, dict) else [encode(v) for v in node]
        else:
            packed = node
        data = json.dumps(packed, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str).encode()
        if not top and len(data) >= 2048:
            digest = hashlib.sha256(data).hexdigest()
            target = objects/(digest+'.json')
            if not target.exists():
                _atomic(target, data)
            packed = {'$jigaewol_object': digest}
        if isinstance(node, (dict, list)):
            memo[id(node)] = packed
        return packed
    _atomic(path, json.dumps({'schema':'jigaewol_cas_snapshot_v1', 'value':encode(value, True)}, ensure_ascii=False, separators=(',', ':')).encode())

def load_snapshot(path):
    path = Path(path)
    row = json.loads(path.read_text(encoding='utf-8'))
    if row.get('schema') != 'jigaewol_cas_snapshot_v1':
        return row
    objects = path.parent.parent/'snapshot_objects'
    cache = {}
    resolving = set()
    def decode(node):
        if isinstance(node, dict) and set(node) == {'$jigaewol_object'}:
            digest = node['$jigaewol_object']
            if not isinstance(digest, str) or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
                raise ValueError('invalid snapshot object reference')
            if digest in resolving:
                raise ValueError('cyclic snapshot object')
            if digest not in cache:
                data = (objects/(digest+'.json')).read_bytes()
                if hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError('snapshot object hash mismatch')
                resolving.add(digest)
                cache[digest] = decode(json.loads(data))
                resolving.remove(digest)
            # JSON preserves values, not mutable object identity. Restore separate
            # subtrees so changing an active projection cannot alter original source.
            import copy
            return copy.deepcopy(cache[digest])
        if isinstance(node, dict):
            return {k: decode(v) for k,v in node.items()}
        if isinstance(node, list):
            return [decode(v) for v in node]
        return node
    return decode(row['value'])
