from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class ExecutionBody:
    body_id: str
    kind: str
    state: str
    capabilities: tuple[str, ...]
    connector_ref: str
    zero_incremental_cost: bool | None
    evidence_strength: float
    evidence: dict[str, Any]


@dataclass(frozen=True)
class BodySelection:
    requested_capability: str
    selected_body_id: str
    eligible: tuple[str, ...]
    deferred_cost_unknown: tuple[str, ...]
    reason: str


class CapabilityFederation:
    """Treats many execution surfaces as one logical machine without conflating states/cost."""

    @staticmethod
    def from_host_surfaces(rows: Iterable[Mapping[str, Any]]) -> tuple[ExecutionBody, ...]:
        out: list[ExecutionBody] = []
        for row in rows:
            ev = dict(row.get("evidence") or {})
            zero: bool | None
            if "zero_incremental_cost" in ev:
                zero = bool(ev["zero_incremental_cost"])
            elif str(ev.get("incremental_cost") or "").casefold() in {"0", "0.0", "free", "included", "none"}:
                zero = True
            elif ev.get("paid") is True:
                zero = False
            else:
                zero = None
            out.append(ExecutionBody(
                body_id=str(row.get("surface_id") or row.get("body_id") or ""),
                kind=str(row.get("kind") or "unknown"), state=str(row.get("state") or "discovered"),
                capabilities=tuple(map(str, row.get("capabilities") or ())),
                connector_ref=str(row.get("connector_ref") or ""),
                zero_incremental_cost=zero,
                evidence_strength=float(row.get("evidence_strength") or 0.0),
                evidence=ev,
            ))
        return tuple(out)

    @staticmethod
    def select_zero_cost(capability: str, bodies: Iterable[ExecutionBody]) -> BodySelection:
        cap = str(capability)
        candidates = [b for b in bodies if cap in b.capabilities and b.state in {"callable", "executed_successfully", "proven"}]
        free = [b for b in candidates if b.zero_incremental_cost is True]
        free.sort(key=lambda b: (b.evidence_strength, b.state in {"proven", "executed_successfully"}), reverse=True)
        unknown = tuple(sorted(b.body_id for b in candidates if b.zero_incremental_cost is None))
        if free:
            return BodySelection(cap, free[0].body_id, tuple(b.body_id for b in free), unknown, "zero_incremental_cost_proven")
        return BodySelection(cap, "", (), unknown, "no_zero_cost_callable_body_proven")
