from __future__ import annotations

"""Settles claims by running their checks instead of asserting them.

The runtime already separates planning from execution for host actions. Claims made
inside an answer had no equivalent: nothing distinguished "I checked this" from "I
believe this", so a turn could report a verified result having run nothing.

This loop closes that gap for the claims that are mechanically decidable. A claim
carries a check, the check runs in the sandboxed computation worker
(`jigaewol_runtime.methods.runner`: subprocess, allowlisted builtins, size and time
limits), and only a completed run whose output matches the stated expectation moves a
claim to `verified`. A broken check leaves the claim unverified rather than quietly
passing it, and a mismatch reports `refuted` instead of being retried into agreement.

Verification stays a floor, not the task: claims are registered deliberately, and a
claim nobody could decide is recorded as `unverifiable` with its reason rather than
being dressed up as settled.
"""

import hashlib
from dataclasses import asdict, dataclass, field
from typing import Any, Mapping

from jigaewol_runtime.methods.runner import prepare_job, run_job

UNVERIFIED = "unverified"
CHECK_ATTACHED = "check_attached"
VERIFIED = "verified"
REFUTED = "refuted"
CHECK_FAILED = "check_failed"
UNVERIFIABLE = "unverifiable"

_SETTLED = {VERIFIED, REFUTED, UNVERIFIABLE}


def _sha(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class CheckRun:
    status: str
    output: Any
    elapsed_seconds: float
    error: str | None = None

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Claim:
    claim_id: str
    text: str
    critical: bool
    state: str = UNVERIFIED
    reason: str = ""
    expectation: Any = None
    method_hash: str = ""
    run: CheckRun | None = None
    _job: dict[str, Any] | None = field(default=None, repr=False)

    def as_mapping(self) -> dict[str, Any]:
        return {
            "claim_id": self.claim_id, "text": self.text, "critical": self.critical,
            "state": self.state, "reason": self.reason, "expectation": self.expectation,
            "method_hash": self.method_hash,
            "run": self.run.as_mapping() if self.run else None,
        }


@dataclass(frozen=True)
class VerificationReport:
    settled: bool
    rows: tuple[Mapping[str, Any], ...]
    open_critical: tuple[str, ...]
    findings: tuple[str, ...]

    def as_mapping(self) -> dict[str, Any]:
        return {
            "settled": self.settled, "rows": [dict(r) for r in self.rows],
            "open_critical": list(self.open_critical), "findings": list(self.findings),
        }


class VerificationLoop:
    """Registry of claims and the checks that decide them."""

    def __init__(self, *, max_runs: int | None = None) -> None:
        if max_runs is not None and max_runs < 1:
            raise ValueError("max_runs must be >= 1 when specified")
        self.max_runs = None if max_runs is None else int(max_runs)
        self.runs_spent = 0
        self._claims: dict[str, Claim] = {}

    def register(self, text: str, *, critical: bool = False) -> Claim:
        body = str(text).strip()
        if not body:
            raise ValueError("a claim needs a body")
        claim_id = "clm_" + _sha(body)[:16]
        existing = self._claims.get(claim_id)
        if existing is not None:
            # Re-registering the same sentence must not reopen a settled claim; the
            # strictest critical flag wins so a later critical mention is not softened.
            if critical and not existing.critical:
                existing.critical = True
            return existing
        claim = Claim(claim_id=claim_id, text=body, critical=bool(critical))
        self._claims[claim_id] = claim
        return claim

    def mark_unverifiable(self, claim_id: str, reason: str) -> Claim:
        claim = self._require(claim_id)
        if not str(reason).strip():
            raise ValueError("calling a claim unverifiable requires a stated reason")
        claim.state = UNVERIFIABLE
        claim.reason = str(reason).strip()
        return claim

    def attach_check(self, claim_id: str, *, method: Mapping[str, Any], input: Any, expect: Any) -> Claim:
        claim = self._require(claim_id)
        job = prepare_job(dict(method), input)
        claim._job = job
        claim.method_hash = job["method_hash"]
        claim.expectation = expect
        claim.state = CHECK_ATTACHED
        claim.reason = ""
        claim.run = None
        return claim

    def run(self, claim_id: str, *, timeout_seconds: float | None = None) -> Claim:
        claim = self._require(claim_id)
        if claim._job is None:
            raise ValueError(f"claim {claim_id} has no check to run")
        if self.max_runs is not None and self.runs_spent >= self.max_runs:
            raise RuntimeError("verification budget exhausted; raise max_runs deliberately")
        self.runs_spent += 1
        result = run_job(claim._job, timeout_seconds=timeout_seconds)
        status = str(result.get("status"))
        claim.run = CheckRun(
            status=status,
            output=result.get("output"),
            elapsed_seconds=float(result.get("elapsed_seconds") or 0.0),
            error=result.get("error"),
        )
        if status != "ok":
            # The check broke, which says nothing about the claim. Leaving it unverified
            # is the honest outcome; promoting it here is exactly the drift this guards.
            claim.state = CHECK_FAILED
            claim.reason = f"check did not complete: {status}"
        elif claim.run.output == claim.expectation:
            claim.state = VERIFIED
            claim.reason = ""
        else:
            claim.state = REFUTED
            claim.reason = f"check returned {claim.run.output!r}, expected {claim.expectation!r}"
        return claim

    def verify(self, text: str, *, method: Mapping[str, Any], input: Any, expect: Any,
               critical: bool = False, timeout_seconds: float | None = None) -> Claim:
        claim = self.register(text, critical=critical)
        self.attach_check(claim.claim_id, method=method, input=input, expect=expect)
        return self.run(claim.claim_id, timeout_seconds=timeout_seconds)

    def report(self) -> VerificationReport:
        rows = tuple(claim.as_mapping() for claim in self._claims.values())
        open_critical = tuple(
            claim.claim_id for claim in self._claims.values()
            if claim.critical and claim.state not in _SETTLED
        )
        findings: list[str] = []
        if open_critical:
            findings.append("critical_claims_not_settled:" + ",".join(open_critical))
        refuted = [c.claim_id for c in self._claims.values() if c.state == REFUTED]
        if refuted:
            findings.append("refuted_claims:" + ",".join(refuted))
        failed = [c.claim_id for c in self._claims.values() if c.state == CHECK_FAILED]
        if failed:
            findings.append("checks_did_not_complete:" + ",".join(failed))
        return VerificationReport(
            settled=not open_critical, rows=rows,
            open_critical=open_critical, findings=tuple(findings),
        )

    def _require(self, claim_id: str) -> Claim:
        claim = self._claims.get(claim_id)
        if claim is None:
            raise KeyError(f"unknown claim: {claim_id}")
        return claim


def numeric_check(check_id: str, purpose: str, source: str, entrypoint: str) -> dict[str, str]:
    """Shape a pure computation into the method record the sandboxed worker accepts."""
    return {
        "id": check_id, "purpose": purpose, "representation": "python_pure_function",
        "source": source, "entrypoint": entrypoint,
        "applicability": "deterministic check over JSON input",
    }


__all__ = [
    "CHECK_ATTACHED", "CHECK_FAILED", "Claim", "CheckRun", "REFUTED", "UNVERIFIABLE",
    "UNVERIFIED", "VERIFIED", "VerificationLoop", "VerificationReport", "numeric_check",
]
