"""Inspect, authorize, materialize and exercise executable capability packages."""
from __future__ import annotations
import ast
import hashlib
import json
import shutil
import sqlite3
import time
from pathlib import Path
from .isolated_executor import IsolatedExecutor
from .skill_acquisition_pipeline import SkillAcquisitionPipeline

class CapabilityWorkbench:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True,exist_ok=True)
        self.path = self.root/'capabilities.sqlite3'
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS candidates(id TEXT PRIMARY KEY, body TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS grants(scope TEXT PRIMARY KEY, body TEXT)')

    def db(self):
        db = sqlite3.connect(self.path,timeout=30); db.execute('PRAGMA journal_mode=WAL'); return db

    def inspect(self, source, *, need_ref, source_url, revision, license_scope, executable_entrypoint='', dependencies=(), credential_scopes=(), task_probe=None):
        source = Path(source).resolve()
        files = []
        syntax_failures = []
        observations = []
        for path in sorted(source.rglob('*')):
            if path.is_symlink() or (path.is_file() and not path.resolve().is_relative_to(source)):
                raise ValueError('package has a symbolic link or escaped source')
            if not path.is_file():
                continue
            data = path.read_bytes()
            name = path.relative_to(source).as_posix()
            files.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'size':len(data)})
            if path.suffix == '.py':
                try:
                    tree = ast.parse(data)
                    imports = [x.module for x in ast.walk(tree) if isinstance(x,ast.ImportFrom)]
                    imports += [a.name for x in ast.walk(tree) if isinstance(x,ast.Import) for a in x.names]
                    observations.append({'path':name,'imports':imports})
                except (SyntaxError,UnicodeError) as exc:
                    syntax_failures.append({'path':name,'error':str(exc)})
        if not files or not need_ref or not source_url or not revision or not license_scope:
            raise ValueError('candidate needs source/revision/license/task provenance and files')
        if executable_entrypoint and executable_entrypoint not in {x['path'] for x in files}:
            raise ValueError('entrypoint is absent from inspected package')
        row = dict(need_ref=need_ref,source_url=source_url,revision=revision,license_scope=license_scope,
                   artifact_type='executable' if executable_entrypoint else 'instruction_package',
                   executable_entrypoint=executable_entrypoint,runtime_dependencies=list(dependencies),
                   credential_scopes=list(credential_scopes),task_probe=task_probe,files=files,
                   source_path=str(source),syntax_failures=syntax_failures,static_observations=observations,
                   static_scan_scope='syntax/import inventory; execution requires reviewed or isolated admission',
                   state='source_inspected',rollback_plan='remove this candidate revision; keep prior active revision')
        cid = 'capability_'+hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:24]
        row['candidate_id'] = cid
        with self.db() as db:
            db.execute('INSERT OR IGNORE INTO candidates VALUES (?,?)',(cid,json.dumps(row,ensure_ascii=False)))
        return row

    def get(self, cid):
        with self.db() as db:
            row = db.execute('SELECT body FROM candidates WHERE id=?',(cid,)).fetchone()
        if not row: raise KeyError(cid)
        return json.loads(row[0])

    @staticmethod
    def discover(query='',*,limit=20):
        import csv
        catalog=Path(__file__).resolve().parents[1]/'blueprints'/'NOTION_TOOLKIT_120.csv'
        if not catalog.exists():return {'candidates':[],'catalog_present':False,'next_route':'inspect_personal_knowledge_and_code_sources'}
        with catalog.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
        terms=[x.casefold() for x in str(query).split() if len(x)>1]
        ranked=[]
        for row in rows:
            text=' '.join(row.get(k,'') for k in ('item','kind','why','runtime_form','integration_needed','url')).casefold()
            matches=sum(t in text for t in terms)
            if not terms or matches:ranked.append((matches,row))
        ranked.sort(key=lambda x:x[0],reverse=True)
        return {'candidates':[{**row,'source_match_count':score,'current_execution_state':'inventory_only'} for score,row in ranked[:max(1,min(int(limit),120))]],
                'catalog_size':len(rows),'installation_claim':False,'need_query':query}

    def fetch(self, url, *, need_ref, revision, license_scope, expected_sha256, executable_entrypoint='', dependencies=(), credential_scopes=()):
        """Download immutable bytes into quarantine before source inspection."""
        import urllib.request
        from urllib.parse import urlsplit
        if urlsplit(url).scheme!='https' or len(expected_sha256)!=64:
            raise ValueError('remote source needs HTTPS and a pinned archive SHA-256')
        target=self.root/'downloads'/(expected_sha256+'.zip');target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():
            chunks=[];size=0
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'JIGAEWOL/2.9.0'}),timeout=60) as response:
                if urlsplit(response.geturl()).scheme!='https':raise ValueError('source redirect changed HTTPS transport')
                while True:
                    chunk=response.read(65536)
                    if not chunk:break
                    size+=len(chunk)
                    if size>32*1024*1024:raise ValueError('source exceeds 32 MiB acquisition cell')
                    chunks.append(chunk)
            data=b''.join(chunks)
            if hashlib.sha256(data).hexdigest()!=expected_sha256:raise ValueError('download did not match pinned artifact')
            from .snapshot_store import _atomic
            _atomic(target,data)
        if hashlib.sha256(target.read_bytes()).hexdigest()!=expected_sha256:raise ValueError('quarantined download changed')
        source,preflight=IsolatedExecutor(self.root/'quarantine').materialize(target)
        children=[x for x in source.iterdir() if x.name!='QUARANTINE_PREFLIGHT.json']
        if len(children)==1 and children[0].is_dir():source=children[0]
        row=self.inspect(source,need_ref=need_ref,source_url=url,revision=revision,license_scope=license_scope,
            executable_entrypoint=executable_entrypoint,dependencies=dependencies,credential_scopes=credential_scopes)
        return {**row,'archive_sha256':expected_sha256,'quarantine_preflight':preflight.__dict__}

    def bind(self,candidate_id,*,capability_name,argv,expected_artifacts=()):
        """Exercise the package before creating a reusable executable adapter."""
        observed=self.probe(candidate_id,argv=argv,expected_artifacts=expected_artifacts)
        if not observed.get('task_effect_observed'):raise ValueError('adapter binding needs actual task effects')
        return self.make_adapter(candidate_id,argv=argv),{'capability':capability_name,'candidate_id':candidate_id,'task_effect_observed':True,
                        'adapter_contract':'JIGAEWOL_INPUT.json + actual argv, stdout/stderr/exit code'}

    def make_adapter(self,candidate_id,*,argv):
        observed=self.get(candidate_id)
        if not observed.get('task_effect_observed'):raise ValueError('adapter has no observed task effects')
        def adapter(request,workspace):
            from jigaewol_runtime.mobile_adapters import parameters
            args=parameters(request)
            source=Path(observed['installed_path']);workspace=Path(workspace);workspace.mkdir(parents=True,exist_ok=True)
            for item in observed['files']:
                data=(source/item['path']).read_bytes()
                if hashlib.sha256(data).hexdigest()!=item['sha256']:raise ValueError('installed adapter source changed')
                target=workspace/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            input_path=workspace/'JIGAEWOL_INPUT.json';input_path.write_text(json.dumps(args,ensure_ascii=False))
            return IsolatedExecutor(self.root/'executor').run(workspace,argv,trust_level='reviewed')
        return adapter

    def authorize(self, candidate_id, *, exact_user_directive, allow_install=True, reviewed_execution=False):
        row = self.get(candidate_id)
        if not exact_user_directive:
            raise ValueError('authorization must retain the actual user directive')
        grant = dict(candidate_id=candidate_id,user_directive=exact_user_directive,
                     user_directive_sha256=hashlib.sha256(exact_user_directive.encode()).hexdigest(),
                     allow_install=bool(allow_install),reviewed_execution=bool(reviewed_execution),
                     credential_scopes=row['credential_scopes'],created_at=time.time())
        with self.db() as db:
            db.execute('INSERT OR REPLACE INTO grants VALUES (?,?)',(candidate_id,json.dumps(grant,ensure_ascii=False)))
        return grant

    def materialize(self, candidate_id):
        row = self.get(candidate_id)
        with self.db() as db:
            grant = db.execute('SELECT body FROM grants WHERE scope=?',(candidate_id,)).fetchone()
        if not grant or not json.loads(grant[0])['allow_install']:
            return {**row,'state':'connection_approval_required','approval_request':{
                'candidate_id':candidate_id,'source_url':row['source_url'],'revision':row['revision'],
                'need_ref':row['need_ref'],'credential_scopes':row['credential_scopes'],'install_plan':row['runtime_dependencies']}}
        if row['syntax_failures']:
            raise ValueError('candidate has syntax failures')
        target = self.root/'installed'/candidate_id
        target.mkdir(parents=True,exist_ok=True)
        for item in row['files']:
            source = Path(row['source_path'])/item['path']
            data = source.read_bytes()
            if hashlib.sha256(data).hexdigest() != item['sha256']:
                raise ValueError('source changed since inspection')
            output = target/item['path']; output.parent.mkdir(parents=True,exist_ok=True); output.write_bytes(data)
        row.update(state='materialized',installed_path=str(target),instruction_loaded=(target/'SKILL.md').exists(),
                   execution_state='not_applicable' if not row['executable_entrypoint'] else 'not_yet_executed')
        with self.db() as db:
            db.execute('UPDATE candidates SET body=? WHERE id=?',(json.dumps(row,ensure_ascii=False),candidate_id))
        return row

    def probe(self, candidate_id, *, argv, expected_artifacts=()):
        row = self.materialize(candidate_id)
        if row['state'] != 'materialized' or not row['executable_entrypoint']:
            raise ValueError('candidate has no authorized executable package')
        with self.db() as db:
            grant = json.loads(db.execute('SELECT body FROM grants WHERE scope=?',(candidate_id,)).fetchone()[0])
        import uuid
        workspace = self.root/'probes'/(candidate_id+'_'+uuid.uuid4().hex)
        workspace.mkdir(parents=True)
        for item in row['files']:
            source=Path(row['installed_path'])/item['path'];data=source.read_bytes()
            if hashlib.sha256(data).hexdigest()!=item['sha256']:raise ValueError('installed source changed before probe')
            target=workspace/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        before={name:(workspace/name).stat().st_mtime_ns for name in expected_artifacts if (workspace/name).is_file()}
        result = IsolatedExecutor(self.root/'executor').run(workspace,argv,
                    trust_level='reviewed' if grant['reviewed_execution'] else 'untrusted')
        effects = []
        for name in expected_artifacts:
            path = (workspace/name).resolve()
            if not path.is_relative_to(workspace) or not path.is_file():
                raise ValueError('task probe did not produce required artifact: '+name)
            if name in before and path.stat().st_mtime_ns==before[name]:
                raise ValueError('task probe merely found an unchanged source artifact: '+name)
            effects.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        row.update(execution_state='execution_observed',last_execution=result,
                   task_effect_observed=bool(result['success'] and effects),task_effects=effects)
        with self.db() as db:
            db.execute('UPDATE candidates SET body=? WHERE id=?',(json.dumps(row,ensure_ascii=False),candidate_id))
        return row
