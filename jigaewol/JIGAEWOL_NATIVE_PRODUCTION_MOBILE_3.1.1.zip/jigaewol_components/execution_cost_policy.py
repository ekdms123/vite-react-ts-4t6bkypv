"""The user's zero-spending directive is checked before optional API calls."""
from __future__ import annotations
import json
from decimal import Decimal,InvalidOperation
from pathlib import Path

POLICY=Path(__file__).resolve().parents[1]/'FREE_EXECUTION_POLICY.json'

def execution_policy():
    row=json.loads(POLICY.read_text())
    if row.get('max_additional_spend_usd')!=0 or row.get('paid_api_calls') is not False or row.get('paid_hosting') is not False:
        raise ValueError('the active release requires the exact user zero-spending policy')
    return row

def assert_zero_spend(*,provider,quoted_usd,billing_mode,proof_ref):
    execution_policy()
    if isinstance(quoted_usd,bool):raise ValueError('boolean is not a price')
    try:price=Decimal(str(quoted_usd))
    except InvalidOperation:raise ValueError('price is not a finite zero') from None
    if not price.is_finite() or price!=0:raise PermissionError('retain candidate and select a verified zero-spending route')
    if billing_mode not in {'local_included','host_included','free_no_card','public_no_auth'} or not isinstance(proof_ref,str) or not proof_ref.strip():
        raise PermissionError('route needs an observed free basis before execution')
    return {'provider':str(provider),'additional_spend_usd':0,'billing_mode':billing_mode,'proof_ref':str(proof_ref)}

def optional_paid_api(provider):
    policy=execution_policy()
    if policy['paid_api_calls'] is False:
        raise PermissionError(str(provider)+': keep the task in the zero-spending chat or verified free provider route')
