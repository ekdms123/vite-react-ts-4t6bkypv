from __future__ import annotations

import copy
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable


@dataclass
class FunctionalSelfModel:
    """Operational self-representation and state tracking model."""

    identity_id: str
    generation: int = 0
    objective: str = ""
    active_paradigms: list[str] = field(default_factory=list)
    capabilities: list[str] = field(default_factory=list)
    recent_failures: list[str] = field(default_factory=list)
    uncertainties: dict[str, float] = field(default_factory=dict)
    body_locations: list[str] = field(default_factory=list)
    memory_lineage: list[str] = field(default_factory=list)
    observations: list[dict[str, Any]] = field(default_factory=list)
    updated_at: float = 0.0
    extensions: dict[str, Any] = field(default_factory=dict)


class SelfModelStore:
    def __init__(self, path: Path, identity_id: str) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.save(FunctionalSelfModel(identity_id=identity_id, updated_at=time.time()))

    def load(self) -> FunctionalSelfModel:
        return FunctionalSelfModel(**json.loads(self.path.read_text(encoding="utf-8")))

    def save(self, model: FunctionalSelfModel) -> None:
        model.updated_at = time.time()
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(asdict(model), ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def update(self, **facts: Any) -> FunctionalSelfModel:
        model = self.load()
        for key, value in facts.items():
            if hasattr(model, key):
                setattr(model, key, copy.deepcopy(value))
            else:
                model.extensions[str(key)] = copy.deepcopy(value)
        self.save(model)
        return model


SelfObserver = Callable[[], dict[str, Any]]
SelfPolicy = Callable[[FunctionalSelfModel, dict[str, Any]], list[dict[str, Any]]]


class CausalSelfLoop:
    """Observe state -> update model -> select subsequent verified actions."""

    def __init__(self, store: SelfModelStore, observer: SelfObserver, policy: SelfPolicy) -> None:
        self.store = store
        self.observer = observer
        self.policy = policy

    def cycle(self, context: dict[str, Any] | None = None) -> tuple[FunctionalSelfModel, list[dict[str, Any]]]:
        facts = self.observer()
        model = self.store.load()
        for key, value in facts.items():
            if hasattr(model, key):
                setattr(model, key, copy.deepcopy(value))
            else:
                model.extensions[str(key)] = copy.deepcopy(value)
                model.observations.append({"key": key, "value": copy.deepcopy(value)})
        self.store.save(model)
        actions = self.policy(model, copy.deepcopy(context or {}))
        return model, actions


@dataclass(frozen=True)
class SelfModelExperimentResult:
    experiment_id: str
    baseline: Any
    lesion: Any
    changed: bool


class FunctionalSelfLab:
    """Measures component efficacy via component isolation and baseline comparison."""

    def run_lesion(
        self,
        experiment_id: str,
        actor: Callable[[FunctionalSelfModel | None], Any],
        model: FunctionalSelfModel,
    ) -> SelfModelExperimentResult:
        baseline = actor(copy.deepcopy(model))
        lesion = actor(None)
        return SelfModelExperimentResult(
            experiment_id=experiment_id,
            baseline=baseline,
            lesion=lesion,
            changed=baseline != lesion,
        )

    def run_component_isolation(
        self,
        experiment_id: str,
        actor: Callable[[FunctionalSelfModel | None], Any],
        model: FunctionalSelfModel,
    ) -> SelfModelExperimentResult:
        """Stable named entrypoint; avoids mutating the class at import time."""
        return self.run_lesion(experiment_id, actor, model)
