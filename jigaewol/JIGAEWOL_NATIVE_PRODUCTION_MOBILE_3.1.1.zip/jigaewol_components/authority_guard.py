from __future__ import annotations

"""Executable authority guards for destination, continuation, effect and finality.

The runtime previously carried many authority statements as metadata while parallel
subsystems still acquired permission from derived classifications.  This module is a
small deterministic choke point: derived interpretations may propose work, but only
exact-source evidence may activate prior work or authorize an observed external effect.
"""

import hashlib
from typing import Any, Mapping

from .source_directive_compiler import continuity_signal


def _sha(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def source_continuation_evidence(message: str) -> tuple[str, ...]:
    """Return source-grounded cross-turn evidence from the clause compiler.

    Continuity is parsed once in SourceDirectiveCompiler.  This guard only consumes
    that result; it no longer maintains a parallel phrase/regex ontology.
    """
    return continuity_signal(str(message or "")).evidence


def source_continuation_requested(message: str) -> bool:
    return bool(source_continuation_evidence(message))


def source_bound_objective(message: str, authority: Mapping[str, Any] | None = None) -> str:
    """Return the only objective allowed to carry destination authority.

    The only executable destination is the exact current user message.
    Continuation is held separately as context and open work, never substituted for
    the user's live directive by a semantic projection.
    """
    exact = str(message)
    authority = dict(authority or {})
    bound = str(authority.get("message_sha256") or "").strip().lower()
    if bound and bound != _sha(exact):
        # semantic_text hashes are intentionally not accepted here: destination
        # authority belongs to the exact current source.
        raise ValueError("authority_guard_message_hash_mismatch")
    # This applies to every caller (routing, deliberation, tool selection, finality).
    # Prior work is preserved in its own ledger, not as a replacement destination.
    return exact


def capability_authorization(authority: Mapping[str, Any] | None, capability: str) -> tuple[bool, str, str]:
    """Return a deterministic, model-independent actuation decision for one capability.

    The decision consumes only source-grounded authority facts.  Model identity, model
    confidence, inferred intent scores, and upstream ``source_effect_authorized`` booleans
    are deliberately ignored.  This makes the final permission boundary stable across
    different model implementations given the same canonical authority record.
    """
    cap = str(capability or "").strip()
    if not authority or not cap:
        return False, "missing_authority", ""

    denied = {str(x).strip() for x in authority.get("denied_capabilities", ()) if str(x).strip()}
    explicit = {str(x).strip() for x in authority.get("explicit_permissions", ()) if str(x).strip()}
    source_span = str(authority.get("authorizing_source_span", "") or "").strip()

    if cap in denied:
        allowed, reason = False, "explicit_user_prohibition"
    elif cap not in explicit:
        allowed, reason = False, "explicit_user_permission_required"
    elif not source_span:
        allowed, reason = False, "authorizing_source_span_required"
    else:
        allowed, reason = True, "explicit_user_permission"

    fingerprint_payload = {
        "capability": cap,
        "denied": sorted(denied),
        "explicit": sorted(explicit),
        "authorizing_source_span_sha256": _sha(source_span) if source_span else "",
        "allowed": allowed,
        "reason": reason,
    }
    fingerprint = hashlib.sha256(
        __import__("json").dumps(
            fingerprint_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
    ).hexdigest()
    return allowed, reason, fingerprint


def source_effect_authorized(authority: Mapping[str, Any] | None) -> bool:
    """Return whether the current source grants at least one still-live effect permission.

    This generic predicate no longer lets an unrelated explicit denial cancel a distinct
    explicitly-authorized capability.  Capability-specific actuation must still call
    :func:`capability_authorization` immediately before dispatch.
    """
    if not authority:
        return False
    denied = {str(x).strip() for x in authority.get("denied_capabilities", ()) if str(x).strip()}
    explicit = {str(x).strip() for x in authority.get("explicit_permissions", ()) if str(x).strip()}
    source_span = str(authority.get("authorizing_source_span", "") or "").strip()
    return bool((explicit - denied) and source_span)


def require_exact_destination(message: str, objective: str, authority: Mapping[str, Any] | None = None) -> None:
    expected = source_bound_objective(message, authority)
    if str(objective) != expected:
        raise PermissionError("derived_destination_override_forbidden")


def finality_requires_objective_completion(*, host_execution_required: bool,
                                           unresolved_goal_refs: tuple[str, ...] | list[str] = ()) -> bool:
    """Material/effectful work cannot be labeled final without work-level proof."""
    return bool(host_execution_required or tuple(unresolved_goal_refs or ()))
