from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Iterable


class EvidenceType(str, Enum):
    OBSERVED = "observed"
    COMPUTED = "computed"
    USER_GIVEN = "user_given"
    ASSUMED = "assumed"
    INFERRED = "inferred"
    SELF_ATTESTED = "self_attested"


class SupportState(str, Enum):
    GROUNDED = "grounded"
    CONDITIONALLY_SUPPORTED = "conditionally_supported"
    SELF_SUPPORTED = "self_supported"
    CYCLIC = "cyclic"
    CONTESTED = "contested"
    UNRESOLVED = "unresolved"


@dataclass(frozen=True)
class ReasonNode:
    node_id: str
    label: str
    evidence_type: EvidenceType
    failure_family: str = "unknown"
    metadata: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class ReasonEdge:
    source: str
    target: str
    relation: str = "depends_on"


@dataclass(frozen=True)
class CycleFinding:
    node_ids: tuple[str, ...]
    labels: tuple[str, ...]
    external_anchors: tuple[str, ...]
    shared_failure_families: tuple[str, ...]
    state: SupportState
    reason: str


@dataclass(frozen=True)
class CapabilityExpansionTrigger:
    trigger_id: str
    signal: str
    reason: str
    cycle_node_ids: tuple[str, ...]
    origin_failure_families: tuple[str, ...]
    required_traits: tuple[str, ...]
    context: dict[str, object] = field(default_factory=dict)


@dataclass
class BreakReport:
    findings: list[CycleFinding]
    triggers: list[CapabilityExpansionTrigger]

    @property
    def closed_loop_detected(self) -> bool:
        return bool(self.triggers)

    def to_dict(self) -> dict:
        return {
            "closed_loop_detected": self.closed_loop_detected,
            "findings": [asdict(f) for f in self.findings],
            "triggers": [asdict(t) for t in self.triggers],
        }


class JustificationGraph:
    """Directed graph where edge (A -> B) denotes dependency: A depends on B."""

    def __init__(self, nodes: Iterable[ReasonNode], edges: Iterable[ReasonEdge]):
        self.nodes = {n.node_id: n for n in nodes}
        self.edges = list(edges)
        missing = {
            endpoint
            for e in self.edges
            for endpoint in (e.source, e.target)
            if endpoint not in self.nodes
        }
        if missing:
            raise ValueError(f"unknown graph nodes: {sorted(missing)}")
        self.adj: dict[str, list[str]] = {nid: [] for nid in self.nodes}
        for edge in self.edges:
            self.adj[edge.source].append(edge.target)

    def has_self_loop(self, node_id: str) -> bool:
        return node_id in self.adj[node_id]


class VerificationLoopBreaker:
    """Detects self-supporting verification loops and converts them into expansion signals.

    Reporting dependency cycles prevents circular reasoning traps without narrowing goals.
    """

    @staticmethod
    def _seed_grounding_types() -> set[EvidenceType]:
        return {EvidenceType.OBSERVED, EvidenceType.COMPUTED, EvidenceType.USER_GIVEN}

    def __init__(self, grounding_types: Iterable[EvidenceType] | None = None) -> None:
        self.grounding_types = set(grounding_types or self._seed_grounding_types())

    def register_grounding_type(self, evidence_type: EvidenceType) -> None:
        self.grounding_types.add(evidence_type)

    def analyze(self, graph: JustificationGraph) -> BreakReport:
        findings: list[CycleFinding] = []
        triggers: list[CapabilityExpansionTrigger] = []

        for component in self._tarjan_scc(graph):
            cyclic = len(component) > 1 or (
                len(component) == 1 and graph.has_self_loop(component[0])
            )
            if not cyclic:
                continue

            component_set = set(component)
            external_anchors: set[str] = set()
            for node_id in component:
                for dependency_id in graph.adj[node_id]:
                    if dependency_id in component_set:
                        continue
                    dependency = graph.nodes[dependency_id]
                    if dependency.evidence_type in self.grounding_types:
                        external_anchors.add(dependency_id)

            internal_grounding = {
                node_id
                for node_id in component
                if graph.nodes[node_id].evidence_type in self.grounding_types
            }
            all_anchors = tuple(sorted(external_anchors | internal_grounding))
            ordered_component = tuple(sorted(component))
            failure_families = tuple(
                sorted({graph.nodes[n].failure_family for n in component})
            )
            labels = tuple(graph.nodes[n].label for n in ordered_component)

            if all_anchors:
                state = SupportState.CONDITIONALLY_SUPPORTED
                reason = "cycle contains external or internal grounding anchors"
            else:
                state = SupportState.CYCLIC
                reason = "dependencies form a closed loop without grounding anchors"

            finding = CycleFinding(
                node_ids=ordered_component,
                labels=labels,
                external_anchors=all_anchors,
                shared_failure_families=failure_families,
                state=state,
                reason=reason,
            )
            findings.append(finding)

            if state is SupportState.CYCLIC:
                stable_key = "|".join(sorted(component))
                triggers.append(
                    CapabilityExpansionTrigger(
                        trigger_id=f"expand:{stable_key}",
                        signal="EPISTEMIC_CLOSED_LOOP",
                        reason=(
                            "Current reasoning closes over its own premises; "
                            "launch an independent computation or evidence pathway."
                        ),
                        cycle_node_ids=ordered_component,
                        origin_failure_families=failure_families,
                        required_traits=self._required_traits(graph, component),
                        context=self._trigger_context(graph, component),
                    )
                )

        return BreakReport(findings=findings, triggers=triggers)

    @staticmethod
    def _required_traits(
        graph: JustificationGraph, component: list[str]
    ) -> tuple[str, ...]:
        traits = {"independent_failure_family", "executable"}
        formal_hint = False
        formal_label_tokens = (
            "logic", "logical", "proof", "theorem", "sat", "satisfiable",
            "constraint", "formal", "axiom", "entail",
        )
        formal_kind_tokens = (
            "logic", "logical", "proof", "theorem", "sat", "satisf",
            "consisten", "constraint", "formal", "axiom", "entail",
        )

        for node_id in component:
            node = graph.nodes[node_id]
            explicit = node.metadata.get("missing_capability_traits", ())
            if isinstance(explicit, str):
                traits.add(explicit)
            elif isinstance(explicit, (list, tuple, set, frozenset)):
                traits.update(str(x) for x in explicit)

            if node.metadata.get("formalizable") is True:
                formal_hint = True
            kind = str(node.metadata.get("problem_kind", "")).lower()
            label = node.label.lower()
            if any(tok in kind for tok in formal_kind_tokens):
                formal_hint = True
            if any(tok in label for tok in formal_label_tokens):
                formal_hint = True

        language_loop = any(
            graph.nodes[n].failure_family
            in {"llm", "language_self_evaluation", "language_reasoning"}
            for n in component
        )
        if formal_hint and language_loop:
            traits.update({"formal_reasoning", "symbolic_logic"})

        return tuple(sorted(traits))

    @staticmethod
    def _trigger_context(
        graph: JustificationGraph, component: list[str]
    ) -> dict[str, object]:
        context: dict[str, object] = {
            "cycle_labels": [graph.nodes[n].label for n in sorted(component)],
        }
        formal_problem = None
        for node_id in component:
            node = graph.nodes[node_id]
            if "formal_problem" in node.metadata:
                formal_problem = node.metadata["formal_problem"]
                break
        if formal_problem is not None:
            context["formal_problem"] = formal_problem
        return context

    @staticmethod
    def _tarjan_scc(graph: JustificationGraph) -> list[list[str]]:
        index = 0
        indices: dict[str, int] = {}
        lowlink: dict[str, int] = {}
        stack: list[str] = []
        on_stack: set[str] = set()
        result: list[list[str]] = []

        def strongconnect(v: str) -> None:
            nonlocal index
            indices[v] = index
            lowlink[v] = index
            index += 1
            stack.append(v)
            on_stack.add(v)

            for w in graph.adj[v]:
                if w not in indices:
                    strongconnect(w)
                    lowlink[v] = min(lowlink[v], lowlink[w])
                elif w in on_stack:
                    lowlink[v] = min(lowlink[v], indices[w])

            if lowlink[v] == indices[v]:
                component: list[str] = []
                while True:
                    w = stack.pop()
                    on_stack.remove(w)
                    component.append(w)
                    if w == v:
                        break
                result.append(component)

        for node_id in graph.nodes:
            if node_id not in indices:
                strongconnect(node_id)
        return result


