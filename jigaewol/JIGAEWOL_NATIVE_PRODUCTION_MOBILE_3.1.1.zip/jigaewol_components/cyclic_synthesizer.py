from __future__ import annotations

"""Co-evolve observation, language, operation semantics, interpreter assumptions and program."""

from dataclasses import dataclass, asdict
from collections import Counter
from math import log2
from typing import Any, Iterable, Mapping
import hashlib, json

from .distinction_miner import DistinctionMiner
from .organ_ir import GrammarDef, InterpreterGenome, OperationDef, OrganGenome, ObserverDef, ProgramDef, TypeField
from .world_interpreter import WorldInterpreter
from .generator_evolution import GeneratorEvolution, GeneratorGenome


@dataclass(frozen=True, slots=True)
class SynthesisRound:
    round_index: int
    genome_id: str
    accuracy: float
    failure_kind: str
    mutation: str
    detail: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class CyclicSynthesisResult:
    genome: OrganGenome
    rounds: tuple[SynthesisRound, ...]
    train_accuracy: float
    solved: bool

    def as_mapping(self) -> dict[str, Any]:
        return {"genome": self.genome.as_mapping(), "rounds": [asdict(x) for x in self.rounds], "train_accuracy": self.train_accuracy, "solved": self.solved}


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


def _entropy(labels: Iterable[Any]) -> float:
    values = tuple(labels)
    if not values: return 0.0
    counts = Counter(map(repr, values)); n = len(values)
    return -sum((c / n) * log2(c / n) for c in counts.values())


class CyclicSynthesizer:
    """Failure-driven organogenesis without a registry of task-specific answers."""

    def __init__(self, generator_genome: GeneratorGenome | None = None) -> None:
        self.generator_genome = generator_genome or GeneratorGenome()
        self.interpreter = WorldInterpreter()
        self.distinctions = DistinctionMiner(
            residue_basis=self.generator_genome.residue_basis,
            expression_depth=self.generator_genome.expression_depth,
            combination_arity=self.generator_genome.combination_arity,
            expression_forms=self.generator_genome.expression_forms,
            productions=self.generator_genome.born_productions,
            search_budget=self.generator_genome.search_budget,
        )

    @staticmethod
    def seed(cases: Iterable[Mapping[str, Any]]) -> OrganGenome:
        rows = tuple(cases)
        first_state = dict((rows[0].get("state") or {}) if rows else {})
        # Native representation begins with only directly visible scalar state paths.
        channels = tuple(TypeField(str(k), {"kind": "source", "path": f"state.{k}"}, "native_visible_state") for k, v in first_state.items() if not isinstance(v, Mapping))
        if not channels:
            channels = (TypeField("visible_hash", {"kind": "history_digest"}, "fallback_visible_signature"),)
        grammar = GrammarDef(tokens=tuple(dict.fromkeys((*[c.name for c in channels], "literal", "if", "eq", "emit"))))
        # A deliberately structure-free seed. It will be replaced by a born operation once enough distinctions exist.
        default = rows[0].get("required_action", rows[0].get("required")) if rows else None
        return OrganGenome(grammar, (), ObserverDef("native_visible", channels), ProgramDef({"kind": "literal", "value": default}), InterpreterGenome(history_mode="uncommitted"))

    def _evaluate(self, genome: OrganGenome, cases: Iterable[Mapping[str, Any]]) -> tuple[float, list[dict[str, Any]]]:
        rows: list[dict[str, Any]] = []; correct = 0; total = 0
        for case in cases:
            history = list(case.get("history") or ())
            state = case.get("state") or {}
            trace = self.interpreter.execute(genome, state=state, history=history)
            required = case.get("required_action", case.get("required"))
            represented = self.interpreter.observe(genome, state, history)
            ok = trace.output == required
            correct += int(ok); total += 1
            rows.append({"state": state, "history": tuple(history), "representation": represented, "required": required, "output": trace.output, "correct": ok, "events": trace.events})
        return (correct / total if total else 0.0), rows

    @staticmethod
    def _field(path: str) -> dict[str, Any]:
        return {"kind": "get", "root": "env", "path": path}

    @staticmethod
    def _literal(value: Any) -> dict[str, Any]: return {"kind": "literal", "value": value}

    def _condition_candidates(self, rows: tuple[dict[str, Any], ...], features: tuple[str, ...]) -> tuple[tuple[str, dict[str, Any]], ...]:
        # Predicate birth is delegated to the current generator-shaped distinction
        # language. The seed operators are therefore not a permanent classifier DSL.
        return tuple((name, dict(expr)) for name, expr in self.distinctions.condition_candidates(rows, features))

    @staticmethod
    def _eval_condition(expr: Mapping[str, Any], observation: Mapping[str, Any]) -> bool:
        kind = expr.get("kind")
        if kind == "literal": return bool(expr.get("value"))
        if kind == "get": return observation.get(str(expr.get("path") or ""))
        if kind == "eq": return CyclicSynthesizer._eval_value(expr.get("a") or {}, observation) == CyclicSynthesizer._eval_value(expr.get("b") or {}, observation)
        return bool(CyclicSynthesizer._eval_value(expr, observation))

    @staticmethod
    def _eval_value(expr: Any, observation: Mapping[str, Any]) -> Any:
        if not isinstance(expr, Mapping): return expr
        kind = expr.get("kind")
        if kind == "literal": return expr.get("value")
        if kind == "get": return observation.get(str(expr.get("path") or ""))
        if kind in {"add", "sub", "mul"}:
            a = CyclicSynthesizer._eval_value(expr.get("a"), observation); b = CyclicSynthesizer._eval_value(expr.get("b"), observation)
            return a + b if kind == "add" else (a - b if kind == "sub" else a * b)
        if kind == "mod": return int(CyclicSynthesizer._eval_value(expr.get("a"), observation) or 0) % max(1, int(CyclicSynthesizer._eval_value(expr.get("b"), observation) or 1))
        if kind == "eq": return CyclicSynthesizer._eval_value(expr.get("a"), observation) == CyclicSynthesizer._eval_value(expr.get("b"), observation)
        if kind == "tuple": return tuple(CyclicSynthesizer._eval_value(x, observation) for x in expr.get("items", ()))
        return None

    def _learn_tree(self, rows: tuple[dict[str, Any], ...], features: tuple[str, ...], *, depth: int = 0, max_depth: int | None = None) -> tuple[dict[str, Any] | None, tuple[str, ...]]:
        if max_depth is None:
            max_depth = max(4, 2 + self.generator_genome.expression_depth * 2 + int(log2(len(rows) + 1)))
        labels = tuple(r["required"] for r in rows)
        if not rows: return None, ()
        if all(label == labels[0] for label in labels): return self._literal(labels[0]), ()
        if depth >= max_depth: return None, ()
        base = _entropy(labels)
        best: tuple[float, str, dict[str, Any], tuple[dict[str, Any], ...], tuple[dict[str, Any], ...]] | None = None
        for name, cond in self._condition_candidates(rows, features):
            yes = tuple(r for r in rows if self._eval_condition(cond, r["representation"]))
            no = tuple(r for r in rows if not self._eval_condition(cond, r["representation"]))
            if not yes or not no: continue
            gain = base - (len(yes)/len(rows))*_entropy(r["required"] for r in yes) - (len(no)/len(rows))*_entropy(r["required"] for r in no)
            balance = min(len(yes), len(no)) / len(rows)
            score = gain + 0.01 * balance - 0.00001 * len(json.dumps(cond, default=str))
            if best is None or score > best[0]: best = (score, name, cond, yes, no)
        if best is None or best[0] <= 1e-9: return None, ()
        _, name, cond, yes, no = best
        left, lused = self._learn_tree(yes, features, depth=depth + 1, max_depth=max_depth)
        right, rused = self._learn_tree(no, features, depth=depth + 1, max_depth=max_depth)
        if left is None or right is None: return None, ()
        return {"kind": "if", "cond": cond, "then": left, "else": right}, tuple(dict.fromkeys((name, *lused, *rused)))

    def _rebind_search_geometry(self, genome: OrganGenome) -> OrganGenome:
        self.distinctions = DistinctionMiner(
            residue_basis=self.generator_genome.residue_basis,
            expression_depth=self.generator_genome.expression_depth,
            combination_arity=self.generator_genome.combination_arity,
            expression_forms=self.generator_genome.expression_forms,
            productions=self.generator_genome.born_productions,
            search_budget=self.generator_genome.search_budget,
        )
        grammar = GrammarDef(
            tokens=genome.grammar.tokens,
            forms=tuple(dict.fromkeys((*genome.grammar.forms, *self.generator_genome.grammar_forms))),
            productions=tuple(dict(x) for x in self.generator_genome.born_productions),
        )
        from .organ_ir import GeneratorDef
        return genome.evolve(grammar=grammar, generator=GeneratorDef(self.generator_genome.as_mapping()))

    def _adapt_generator(self, genome: OrganGenome, failure: Mapping[str, Any]) -> OrganGenome:
        prior = self.generator_genome
        evolved = GeneratorEvolution().evolve(prior, (dict(failure),))
        if evolved.as_mapping() == prior.as_mapping():
            return genome
        self.generator_genome = evolved
        return self._rebind_search_geometry(genome)

    def _birth_operation(self, genome: OrganGenome, observed: tuple[dict[str, Any], ...]) -> tuple[OrganGenome | None, dict[str, Any]]:
        features = tuple(c.name for c in genome.observer.channels)
        body, used = self._learn_tree(observed, features)
        if body is None: return None, {"reason": "no_classifier_in_current_language", "feature_count": len(features)}
        name = "born_op_" + _sha({"features": features, "body": body})[:16]
        op = OperationDef(name=name, params=features, body=body, provenance="born_from_collision_resolved_language")
        program = ProgramDef({"kind": "call", "op": name, "args": tuple({"kind": "get", "root": "observation", "path": f} for f in features)})
        token_kinds: set[str] = set()
        def walk(x: Any) -> None:
            if isinstance(x, Mapping):
                if x.get("kind"): token_kinds.add(str(x["kind"]))
                for value in x.values(): walk(value)
            elif isinstance(x, (tuple, list)):
                for value in x: walk(value)
        walk(body)
        grammar = GrammarDef(tokens=tuple(dict.fromkeys((*genome.grammar.tokens, name, *features, *sorted(token_kinds), "call"))), forms=tuple(dict.fromkeys((*genome.grammar.forms, "generated_operation", *self.generator_genome.grammar_forms))), productions=tuple(dict(x) for x in self.generator_genome.born_productions))
        history_sensitive = any(c.semantic_role.startswith(("path", "event")) or "history" in c.name or "count" in c.name or "tail" in c.name for c in genome.observer.channels)
        interpreter = InterpreterGenome(equality_mode="type_and_value", history_mode=("generated_path_semantics" if history_sensitive else "state_semantics"), composition_mode="born_operation_dispatch", contradiction_mode=genome.interpreter.contradiction_mode, unknown_operation_mode="birth_request")
        return genome.evolve(operations=tuple((*genome.operations, op)), grammar=grammar, program=program, interpreter=interpreter), {"operation": name, "features": features, "predicates": used, "language_tokens_added": sorted(token_kinds)}

    def synthesize(self, cases: Iterable[Mapping[str, Any]], *, max_rounds: int = 14) -> CyclicSynthesisResult:
        cases = tuple(cases)
        genome = self.seed(cases)
        rounds: list[SynthesisRound] = []
        for idx in range(max_rounds):
            accuracy, observed_rows = self._evaluate(genome, cases)
            if accuracy >= 1.0:
                rounds.append(SynthesisRound(idx, genome.genome_id, accuracy, "none", "fixed_point", {"solved": True}))
                return CyclicSynthesisResult(genome, tuple(rounds), accuracy, True)
            proposal = self.distinctions.propose(observed_rows, existing_names=(c.name for c in genome.observer.channels))
            if proposal is not None:
                observer = ObserverDef(genome.observer.name + "+born", tuple((*genome.observer.channels, proposal.field)), genome.observer.disturbance)
                grammar = GrammarDef(tokens=tuple(dict.fromkeys((*genome.grammar.tokens, proposal.field.name))), forms=genome.grammar.forms)
                genome = genome.evolve(observer=observer, grammar=grammar,
                    interpreter=InterpreterGenome(equality_mode=genome.interpreter.equality_mode, history_mode="representation_expanding", composition_mode=genome.interpreter.composition_mode, contradiction_mode=genome.interpreter.contradiction_mode, unknown_operation_mode=genome.interpreter.unknown_operation_mode))
                detail_row = {"field": proposal.field.name, "extractor": dict(proposal.field.extractor), "separates": proposal.separates, "witness_count": proposal.witness_count, "semantic_role": proposal.field.semantic_role, "generator_generation": self.generator_genome.generation, "candidate_scheduler": self.generator_genome.candidate_scheduler}
                rounds.append(SynthesisRound(idx, genome.genome_id, accuracy, "representation_collision", "birth_observation_expression", detail_row))
                genome = self._adapt_generator(genome, {"kind": "representation_collision", "detail": detail_row, "search_dimensions": ("observer", "representation", "problem_type")})
                continue
            born, detail = self._birth_operation(genome, tuple(observed_rows))
            if born is not None:
                genome = born
                detail_row = {**detail, "generator_generation": self.generator_genome.generation, "generator_scheduler": self.generator_genome.candidate_scheduler}
                rounds.append(SynthesisRound(idx, genome.genome_id, accuracy, "program_miss", "birth_language_operation_interpreter_program", detail_row))
                genome = self._adapt_generator(genome, {"kind": "program_miss", "detail": detail_row, "search_dimensions": ("language", "operation", "interpreter", "program")})
                continue
            residual = self.distinctions.propose_program_residual(
                observed_rows,
                existing_names=(c.name for c in genome.observer.channels),
                moduli=self.generator_genome.residue_basis,
                max_terms=max(3, self.generator_genome.combination_arity + self.generator_genome.expression_depth),
            )
            if residual is not None:
                observer = ObserverDef(genome.observer.name + "+residual", tuple((*genome.observer.channels, residual.field)), genome.observer.disturbance)
                grammar = GrammarDef(tokens=tuple(dict.fromkeys((*genome.grammar.tokens, residual.field.name, "add", "sub", "mul", "mod", "eq", "if"))), forms=tuple(dict.fromkeys((*genome.grammar.forms, *self.generator_genome.grammar_forms))), productions=tuple(dict(x) for x in self.generator_genome.born_productions))
                genome = genome.evolve(
                    observer=observer,
                    grammar=grammar,
                    interpreter=InterpreterGenome(
                        equality_mode=genome.interpreter.equality_mode,
                        history_mode="program_residual_sensor",
                        composition_mode=genome.interpreter.composition_mode,
                        contradiction_mode=genome.interpreter.contradiction_mode,
                        unknown_operation_mode=genome.interpreter.unknown_operation_mode,
                    ),
                )
                detail_row = {
                    "field": residual.field.name,
                    "extractor": dict(residual.field.extractor),
                    "generated_from": residual.generated_from,
                    "generator_generation": self.generator_genome.generation,
                    "generator_scheduler": self.generator_genome.candidate_scheduler,
                }
                rounds.append(SynthesisRound(idx, genome.genome_id, accuracy, "program_miss", "birth_program_residual_sensor", detail_row))
                genome = self._adapt_generator(genome, {"kind": "program_miss", "detail": detail_row, "search_dimensions": ("observer", "language", "operation", "interpreter")})
                continue
            before_generation = self.generator_genome.generation
            failure = {"kind": "unresolved", "detail": detail, "search_dimensions": tuple(self.generator_genome.search_dimensions)}
            genome = self._adapt_generator(genome, failure)
            rounds.append(SynthesisRound(idx, genome.genome_id, accuracy, "unresolved", "mutate_generator_search_geometry", {**detail, "generator_generation_before": before_generation, "generator_generation_after": self.generator_genome.generation, "search_budget": self.generator_genome.search_budget, "expression_forms": self.generator_genome.expression_forms}))
            if self.generator_genome.generation == before_generation:
                break
            continue
        accuracy, _ = self._evaluate(genome, cases)
        return CyclicSynthesisResult(genome, tuple(rounds), accuracy, accuracy >= 1.0)
