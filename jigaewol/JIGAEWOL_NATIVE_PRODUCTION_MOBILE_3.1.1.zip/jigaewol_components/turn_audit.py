from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterator

from .file_lock import exclusive_lock
from .privacy_minimization import PrivacyMinimizationPolicy
from .response_protocol import CandidateBundle, CandidateResponse, sha256_text
from .semantic_communication import SemanticCommunicationLayer, build_semantic_record


class AuditCorruptionError(RuntimeError):
    pass


@dataclass(frozen=True)
class TurnIngressReceipt:
    receipt_id: str
    turn_id: str
    sequence: int
    command_sha256: str
    command_preview: str
    runtime_identity: str
    charter_id: str
    artifact_sha256: str = ""
    artifact_size_bytes: int = 0
    created_at: float = 0.0


@dataclass(frozen=True)
class RuntimeTraversalEvidence:
    receipt_id: str
    run_id: str
    subsystem: str
    success: bool
    evidence: dict[str, Any] = field(default_factory=dict)
    created_at: float = 0.0


@dataclass(frozen=True)
class CandidateBindingReceipt:
    receipt_id: str
    turn_id: str
    response_sha256: str
    producer: str
    body_bytes: int
    created_at: float = 0.0


@dataclass(frozen=True)
class CandidateGroupBindingReceipt:
    receipt_id: str
    turn_id: str
    release_group_id: str
    bundle_sha256: str
    candidate_ids: tuple[str, ...]
    response_sha256s: tuple[str, ...]
    created_at: float = 0.0


def _sha_json(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class TurnAuditLedger:
    """Append-only turn observation ledger with observation-only authority.

    It records ingress, runtime observations, candidate hashes, and failure annotations.
    Methods append observations and repair signals while the user destination stays canonical.
    """

    def __init__(self, root: Path, *, runtime_identity: str, charter_id: str, canonical_artifact_path: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.receipt_dir = self.root / "receipts"
        self.receipt_dir.mkdir(exist_ok=True)
        self.runtime_identity = str(runtime_identity)
        self.charter_id = str(charter_id)
        self.canonical_artifact_path = Path(canonical_artifact_path).resolve()
        if not self.canonical_artifact_path.is_file():
            raise FileNotFoundError(f"canonical artifact is not a file: {self.canonical_artifact_path}")
        self.state_path = self.root / "state.json"
        self.events_path = self.root / "events.jsonl"
        self.lock_path = self.root / ".audit.lock"
        self.events_path.touch(exist_ok=True)
        self.lock_path.touch(exist_ok=True)
        if not self.state_path.exists():
            self._write_state({"sequence": 0, "turns": {}, "event_sequence": 0, "last_event_sha256": ""})

    @contextmanager
    def _locked(self) -> Iterator[None]:
        with exclusive_lock(self.lock_path):
            yield

    @staticmethod
    def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
        tmp = path.with_name(path.name + f".{uuid.uuid4().hex}.tmp")
        with tmp.open("w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)

    def _write_state(self, state: dict[str, Any]) -> None:
        self._atomic_json(self.state_path, state)

    def _load_state(self) -> dict[str, Any]:
        try:
            state = json.loads(self.state_path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError) as exc:
            raise AuditCorruptionError("turn audit state is unreadable") from exc
        if not isinstance(state.get("turns"), dict):
            raise AuditCorruptionError("turn audit state has invalid turns map")
        return state

    def _append(self, state: dict[str, Any], turn_id: str, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        payload = dict(SemanticCommunicationLayer.normalize_audit_payload(payload))
        body = {
            "event_sequence": int(state.get("event_sequence", 0)) + 1,
            "event_id": f"audit_{uuid.uuid4().hex[:16]}",
            "turn_id": str(turn_id),
            "kind": str(kind),
            "payload": payload,
            "created_at": time.time(),
            "previous_event_sha256": str(state.get("last_event_sha256", "")),
        }
        row = {**body, "event_sha256": _sha_json(body)}
        with self.events_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        state["event_sequence"] = row["event_sequence"]
        state["last_event_sha256"] = row["event_sha256"]
        self._write_state(state)
        return row

    def _write_receipt(self, receipt_id: str, payload: dict[str, Any]) -> None:
        self._atomic_json(self.receipt_dir / f"{receipt_id}.json", payload)

    def current_artifact_identity(self) -> tuple[str, int]:
        data = self.canonical_artifact_path.read_bytes()
        return hashlib.sha256(data).hexdigest(), len(data)

    def begin(self, user_command: str) -> TurnIngressReceipt:
        command = str(user_command)
        if not command.strip():
            raise ValueError("user command must be non-empty")
        with self._locked():
            state = self._load_state()
            sequence = int(state.get("sequence", 0)) + 1
            artifact_sha256, artifact_size_bytes = self.current_artifact_identity()
            turn_id = f"turn_{sequence:08d}_{uuid.uuid4().hex[:8]}"
            semantic_record = build_semantic_record(command, direction="user")
            speech_act = str(semantic_record.concept_frame.get("speech_act") or "unspecified")
            receipt = TurnIngressReceipt(
                receipt_id=f"ingress_{uuid.uuid4().hex[:16]}", turn_id=turn_id, sequence=sequence,
                command_sha256=sha256_text(command),
                command_preview=f"[semantic:{speech_act}:{semantic_record.concept_sha256[:16]}]",
                runtime_identity=self.runtime_identity, charter_id=self.charter_id,
                artifact_sha256=artifact_sha256, artifact_size_bytes=artifact_size_bytes,
                created_at=time.time(),
            )
            state["sequence"] = sequence
            ingress_row = {**asdict(receipt), "semantic_record": semantic_record.audit_projection()}
            state["turns"][turn_id] = {
                "state": "ACTIVE", "ingress": ingress_row, "traversals": [],
                "candidate": None, "candidate_group": None, "failures": [],
            }
            self._write_receipt(receipt.receipt_id, ingress_row)
            self._append(state, turn_id, "TURN_INGRESSED", {"ingress": ingress_row})
            return receipt

    def attach_runtime(self, turn_id: str, *, run_id: str, subsystem: str, success: bool,
                       evidence: dict[str, Any] | None = None) -> RuntimeTraversalEvidence:
        with self._locked():
            state = self._load_state()
            turn = state["turns"].get(str(turn_id))
            if turn is None:
                raise KeyError(f"unknown turn: {turn_id}")
            artifact_sha256, artifact_size_bytes = self.current_artifact_identity()
            evidence_row = dict(SemanticCommunicationLayer.normalize_audit_payload(dict(evidence or {})))
            evidence_row.setdefault("observed_artifact_sha256", artifact_sha256)
            evidence_row.setdefault("observed_artifact_size_bytes", artifact_size_bytes)
            row = RuntimeTraversalEvidence(
                receipt_id=f"traversal_{uuid.uuid4().hex[:16]}", run_id=str(run_id),
                subsystem=str(subsystem), success=bool(success), evidence=evidence_row, created_at=time.time(),
            )
            turn["traversals"].append(asdict(row))
            self._write_receipt(row.receipt_id, asdict(row))
            self._append(state, str(turn_id), "TRAVERSAL_OBSERVED", {"traversal": asdict(row)})
            return row

    def bind_candidate(self, turn_id: str, candidate: CandidateResponse) -> CandidateBindingReceipt:
        if str(candidate.turn_id) != str(turn_id):
            raise ValueError("candidate turn does not match target turn")
        with self._locked():
            state = self._load_state()
            turn = state["turns"].get(str(turn_id))
            if turn is None:
                raise KeyError(f"unknown turn: {turn_id}")
            receipt = CandidateBindingReceipt(
                receipt_id=f"candidate_{uuid.uuid4().hex[:16]}", turn_id=str(turn_id),
                response_sha256=candidate.response_sha256, producer=str(candidate.producer),
                body_bytes=len(candidate.body.encode("utf-8")), created_at=time.time(),
            )
            response_record = build_semantic_record(candidate.body, direction="system")
            row = {**asdict(receipt), "source_response_sha256": candidate.source_response_sha256,
                   "semantic_record": response_record.audit_projection(),
                   "evidence": SemanticCommunicationLayer.normalize_audit_payload(dict(candidate.evidence))}
            turn["candidate"] = row
            self._write_receipt(receipt.receipt_id, row)
            self._append(state, str(turn_id), "CANDIDATE_OBSERVED", {"candidate": row})
            return receipt

    def bind_candidate_group(self, turn_id: str, bundle: CandidateBundle) -> CandidateGroupBindingReceipt:
        if str(bundle.turn_id) != str(turn_id):
            raise ValueError("candidate group turn does not match target turn")
        with self._locked():
            state = self._load_state()
            turn = state["turns"].get(str(turn_id))
            if turn is None:
                raise KeyError(f"unknown turn: {turn_id}")
            receipt = CandidateGroupBindingReceipt(
                receipt_id=f"candidate_group_{uuid.uuid4().hex[:16]}", turn_id=str(turn_id),
                release_group_id=str(bundle.release_group_id), bundle_sha256=bundle.bundle_sha256,
                candidate_ids=tuple(x.candidate_id for x in bundle.candidates),
                response_sha256s=tuple(x.response_sha256 for x in bundle.candidates), created_at=time.time(),
            )
            rationale_record = build_semantic_record(str(bundle.rationale), direction="system")
            row = {**asdict(receipt), "candidates": [x.binding_payload() for x in bundle.candidates],
                   "rationale": rationale_record.audit_projection(),
                   "evidence": SemanticCommunicationLayer.normalize_audit_payload(dict(bundle.evidence))}
            turn["candidate_group"] = row
            self._write_receipt(receipt.receipt_id, row)
            self._append(state, str(turn_id), "CANDIDATE_GROUP_OBSERVED", {"candidate_group": row})
            return receipt

    def fail_turn(self, turn_id: str, *, reason: str, evidence: dict[str, Any] | None = None) -> None:
        """Record a failure as evidence; it is not a terminal permission state."""
        with self._locked():
            state = self._load_state()
            turn = state["turns"].get(str(turn_id))
            if turn is None:
                raise KeyError(f"unknown turn: {turn_id}")
            failure = {"reason": str(reason), "evidence": SemanticCommunicationLayer.normalize_audit_payload(dict(evidence or {})), "created_at": time.time()}
            turn.setdefault("failures", []).append(failure)
            self._append(state, str(turn_id), "FAILURE_OBSERVED", {"failure": failure})

    def read_verified_state(self) -> dict[str, Any]:
        with self._locked():
            return self._load_state()

    def read_verified_turn(self, turn_id: str) -> dict[str, Any]:
        state = self.read_verified_state()
        turn = state.get("turns", {}).get(str(turn_id))
        if turn is None:
            raise KeyError(f"unknown turn: {turn_id}")
        return turn
