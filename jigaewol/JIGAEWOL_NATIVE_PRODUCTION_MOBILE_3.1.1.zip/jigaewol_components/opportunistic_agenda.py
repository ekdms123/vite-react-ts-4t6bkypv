from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Iterable

@dataclass(frozen=True)
class Move:
    move_id:str; kind:str; description:str; prerequisites:tuple[str,...]=(); evidence_refs:tuple[str,...]=(); state:str='available'
    def as_mapping(self): return asdict(self)

class OpportunisticAgenda:
    """Non-linear action graph: moves can be fused, split, skipped, revisited or invented at runtime."""
    def seed(self, *, objective:str, need_execution:bool=False, need_discovery:bool=False, need_continuity:bool=False):
        moves=[Move('move_represent','representation','re-represent the objective without assuming the conventional workflow')]
        if need_discovery: moves.append(Move('move_sense','perception','observe the relevant information ecology; query is only one possible sensor'))
        if need_execution: moves.append(Move('move_probe','experiment','construct the cheapest discriminating probe or executable artifact'))
        if need_continuity: moves.append(Move('move_continue','continuity','externalize a future observation or persistent state transition'))
        moves.append(Move('move_invent','invention','invent, fuse, split, or discard moves after observing what the task actually becomes'))
        return tuple(moves)
