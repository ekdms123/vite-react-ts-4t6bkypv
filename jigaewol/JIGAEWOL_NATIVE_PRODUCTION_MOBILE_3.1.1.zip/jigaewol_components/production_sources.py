"""Select available source references for actual generation and tool construction."""
from __future__ import annotations
import json,re
from pathlib import Path

# Korean request words mapped to the English vocabulary the attributed skills are written in.
KO_TERMS={'코드':('code',),'코딩':('code','coding'),'리뷰':('review',),'검토':('review',),'보안':('security','vulnerability'),
          '취약':('vulnerability','security'),'테스트':('test','testing','tdd'),'디버그':('debug','debugging'),'버그':('bug','debug'),
          '오류':('error','debug'),'에러':('error','debug'),'리팩터':('refactor',),'리팩토링':('refactor',),'설계':('design','architecture'),
          '구조':('architecture',),'아키텍처':('architecture',),'디자인':('design','frontend'),'화면':('ui','frontend'),'프론트':('frontend',),
          '백엔드':('backend','api'),'api':('api',),'데이터베이스':('database','sql'),'성능':('performance','benchmark'),'속도':('performance',),
          '배포':('deploy','release','deployment'),'출시':('release','shipping'),'문서':('documentation','docs'),'검색':('search','research'),
          '조사':('research',),'리서치':('research',),'계획':('plan','planning'),'기획':('plan','spec'),'명세':('spec',),'스펙':('spec',),
          '브라우저':('browser','playwright'),'자동화':('automation','ci'),'깃':('git',),'깃허브':('github','git'),'커밋':('git','commit'),
          'pr':('pr','pull'),'코멘트':('comments','comment'),'댓글':('comments',),'스킬':('skill',),'플러그인':('plugin','mcp'),'mcp':('mcp',),'프롬프트':('prompt',),'에이전트':('agent',),
          '파이썬':('python',),'자바스크립트':('javascript',),'타입스크립트':('typescript',),'리액트':('react',),'러스트':('rust',),
          '고랭':('golang',),'코틀린':('kotlin',),'스위프트':('swift',),'장고':('django',),'스프링':('spring','springboot'),
          '글':('writing','write'),'작문':('writing',),'소설':('writing','story'),'초안':('draft','writing'),'아이디어':('idea','brainstorming'),
          '브레인스토밍':('brainstorming',),'퍼징':('fuzzing',),'접근성':('accessibility',),'공급망':('supply','chain')}
STOP={'the','and','for','with','this','that','into','from','your','you','use','when','are','can'}


def _terms(exact_text,family):
    text=exact_text.casefold()
    terms={t for t in re.findall(r'[a-z][a-z0-9_-]{1,}',text) if t not in STOP}
    for word,mapped in KO_TERMS.items():
        if word in text:terms.update(mapped)
    hints={'development':{'architecture','code','debug','test','refactor'},'design':{'design','frontend','ui','ux'},
           'writing':{'write','story','document'},'search':{'research','search','browse'}}
    return terms,hints.get(family,set())


def select_sources(exact_text,family):
    root=Path(__file__).resolve().parents[1]
    kit=root/'legacy_donor/JIGAEWOL_DEVELOPMENT_KIT'
    registry=kit/'skill-registry.json'
    if not registry.is_file():return {'skills':[],'source_lookup':'available_sources_are_discovery_candidates'}
    terms,family_terms=_terms(exact_text,family)
    selected=[]
    for row in json.loads(registry.read_text()):
        name=row['name'].casefold();text=(row['name']+' '+row.get('description','')).casefold()
        # Whole-word hits; a hit in the skill's own name counts more than one in its description.
        hit=lambda word,where:re.search(r'(?<![a-z0-9])'+re.escape(word)+r'(?![a-z0-9])',where) is not None
        relevance=sum(3 if hit(word,name) else 1 for word in terms if hit(word,text))
        relevance+=sum(1 for word in family_terms if hit(word,text))
        if relevance and (kit/row['local_path']).is_file():
            selected.append({'id':row['id'],'description':row.get('description',''),'source':str(kit/row['local_path']),
                             'repository':row['repository'],'commit':row['commit'],'relevance_hint':relevance,
                             'scripts_executed':row.get('scripts_executed',False)})
    selected.sort(key=lambda x:-x['relevance_hint'])
    best=selected[0]['relevance_hint'] if selected else 0
    return {'skills':selected,
            'top_skills':[x['id'] for x in selected if x['relevance_hint']>=max(2,best/2)][:8],
            'public_research_entrypoint':'tools/jigaewol_deep_find.py',
            'use':'read the selected source, construct or choose an actual needed action, execute it, then consume its result'}
