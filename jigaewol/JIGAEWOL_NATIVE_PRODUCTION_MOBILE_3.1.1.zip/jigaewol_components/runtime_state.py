from __future__ import annotations

import copy
import json
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class StateConflict(RuntimeError):
    """Raised when a caller tries to commit against a stale runtime snapshot."""


@dataclass(frozen=True)
class RuntimeSnapshot:
    version: int
    generation: int
    payload: dict[str, Any]


class VersionedStateStore:
    """Atomic, compare-and-swap state store shared across algorithm generations.

    Important runtime state lives here rather than inside a generation object.  A
    generation can therefore be replaced without discarding the objective,
    observations, memory references, or intermediate work accumulated so far.
    """

    def __init__(self, path: Path, *, initial: dict[str, Any] | None = None) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        if not self.path.exists():
            self._write(
                {
                    "version": 0,
                    "generation": 0,
                    "payload": copy.deepcopy(initial or {}),
                    "events": [],
                }
            )

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def snapshot(self) -> RuntimeSnapshot:
        with self._lock:
            data = self._read()
            return RuntimeSnapshot(
                version=int(data.get("version", 0)),
                generation=int(data.get("generation", 0)),
                payload=copy.deepcopy(data["payload"] if "payload" in data else {}),
            )

    def commit(
        self,
        *,
        expected_version: int,
        payload: dict[str, Any],
        generation: int | None = None,
        event: dict[str, Any] | None = None,
    ) -> RuntimeSnapshot:
        with self._lock:
            data = self._read()
            current = int(data.get("version", 0))
            if current != expected_version:
                raise StateConflict(f"state version changed: expected={expected_version} current={current}")
            next_version = current + 1
            data["version"] = next_version
            if generation is not None:
                data["generation"] = int(generation)
            data["payload"] = copy.deepcopy(payload)
            if event is not None:
                row = copy.deepcopy(event)
                row.setdefault("state_version", next_version)
                row.setdefault("generation", int(data.get("generation", 0)))
                data.setdefault("events", []).append(row)
            self._write(data)
            return RuntimeSnapshot(
                version=next_version,
                generation=int(data.get("generation", 0)),
                payload=copy.deepcopy(data["payload"]),
            )

    def events(self) -> tuple[dict[str, Any], ...]:
        with self._lock:
            return tuple(copy.deepcopy(self._read().get("events", [])))
