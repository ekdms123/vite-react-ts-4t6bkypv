from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class FederatedBody:
    body_id: str
    executor: str
    families: tuple[str, ...]
    capabilities: tuple[str, ...]
    state: str
    zero_incremental_cost: bool | None
    evidence_strength: float
    origin_ref: str
    evidence: dict[str, Any] = field(default_factory=dict)
    observed_at: float = 0.0


@dataclass(frozen=True)
class FederatedRoute:
    capability: str
    preferred_executors: tuple[str, ...]
    selected_body_id: str
    selected_executor: str
    eligible_body_ids: tuple[str, ...]
    deferred_cost_unknown: tuple[str, ...]
    route_state: str


class BodyFederationRegistry:
    """Live, evidence-scoped execution bodies behind the mobile command plane.

    Installed/discovered/callable/executed/proven and free/unknown-cost are kept
    separate.  A zero-cost task can therefore expand discovery without silently
    treating a catalog entry or unknown billing state as an executable free body.
    """

    CALLABLE_STATES = {"callable", "executed_successfully", "proven"}

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"version": 1, "bodies": {}})

    def _read(self) -> dict[str, Any]:
        data = json.loads(self.path.read_text(encoding="utf-8"))
        data.setdefault("bodies", {})
        return data

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    def upsert(
        self,
        body_id: str,
        *,
        executor: str,
        families: Iterable[str],
        capabilities: Iterable[str],
        state: str,
        zero_incremental_cost: bool | None,
        evidence_strength: float,
        origin_ref: str,
        evidence: dict[str, Any] | None = None,
        observed_at: float | None = None,
    ) -> FederatedBody:
        row = FederatedBody(
            body_id=str(body_id), executor=str(executor),
            families=tuple(dict.fromkeys(str(x) for x in families if str(x).strip())),
            capabilities=tuple(dict.fromkeys(str(x) for x in capabilities if str(x).strip())),
            state=str(state), zero_incremental_cost=zero_incremental_cost,
            evidence_strength=max(0.0, min(1.0, float(evidence_strength))),
            origin_ref=str(origin_ref), evidence=dict(evidence or {}),
            observed_at=float(time.time() if observed_at is None else observed_at),
        )
        data = self._read()
        data["bodies"][row.body_id] = asdict(row)
        self._write(data)
        return row

    def bodies(self) -> tuple[FederatedBody, ...]:
        return tuple(FederatedBody(**row) for row in self._read().get("bodies", {}).values())

    def route(
        self,
        capability: str,
        *,
        preferred_executors: Iterable[str] = (),
        zero_cost_only: bool = False,
        prefer_zero_cost: bool = False,
        max_age_seconds: float | None = None,
        allow_stale_revalidation: bool = False,
        now: float | None = None,
    ) -> FederatedRoute:
        cap = str(capability)
        preferred = tuple(dict.fromkeys(str(x) for x in preferred_executors if str(x).strip()))
        ts = time.time() if now is None else float(now)
        all_matching = [
            b for b in self.bodies()
            if b.state in self.CALLABLE_STATES
            and (cap in b.capabilities or any(cap.startswith(prefix.rstrip("*")) for prefix in b.capabilities if prefix.endswith("*")))
        ]
        rows = [
            b for b in all_matching
            if max_age_seconds is None or ts - b.observed_at <= float(max_age_seconds)
        ]
        order = {name.casefold(): i for i, name in enumerate(preferred)}
        def _cost_rank(body: FederatedBody) -> int:
            if body.zero_incremental_cost is True:
                return 2
            if body.zero_incremental_cost is None:
                return 1
            return 0
        def _preferred_rank(body: FederatedBody) -> tuple[int, int]:
            hit = body.executor.casefold() in order or body.body_id.casefold() in order
            return (1 if hit else 0, -order.get(body.executor.casefold(), order.get(body.body_id.casefold(), 9999)))
        rows.sort(key=lambda b: (
            _cost_rank(b) if prefer_zero_cost else 0,
            *_preferred_rank(b),
            b.evidence_strength,
            b.observed_at,
        ), reverse=True)
        unknown = tuple(b.body_id for b in rows if b.zero_incremental_cost is None)
        eligible = [b for b in rows if (b.zero_incremental_cost is True or not zero_cost_only)]
        if eligible:
            selected = eligible[0]
            return FederatedRoute(cap, preferred, selected.body_id, selected.executor,
                                  tuple(b.body_id for b in eligible), unknown,
                                  "selected_proven_zero_cost" if zero_cost_only else "selected_callable")
        # A successful body observation is durable knowledge even after its freshness
        # lease expires.  Treat it as a *revalidation candidate*, not as proof that
        # the host is still connected.  This prevents the recurring failure where a
        # previously executed connector disappears from planning merely because the
        # next ingress supplied a partial surface snapshot.  Actual dispatch still has
        # to succeed and produce a fresh receipt before effect/claim closure.
        if allow_stale_revalidation and max_age_seconds is not None:
            stale = [
                b for b in all_matching
                if ts - b.observed_at > float(max_age_seconds)
                and (b.zero_incremental_cost is True or not zero_cost_only)
            ]
            stale.sort(key=lambda b: (
                _cost_rank(b) if prefer_zero_cost else 0,
                *_preferred_rank(b),
                b.evidence_strength,
                b.observed_at,
            ), reverse=True)
            if stale:
                selected = stale[0]
                return FederatedRoute(
                    cap, preferred, selected.body_id, selected.executor,
                    tuple(b.body_id for b in stale),
                    tuple(b.body_id for b in stale if b.zero_incremental_cost is None),
                    "selected_stale_requires_revalidation",
                )
        return FederatedRoute(cap, preferred, "", "", (), unknown,
                              "no_proven_zero_cost_body" if zero_cost_only else "no_callable_body")

    def route_family(
        self,
        family: str,
        *,
        preferred_executors: Iterable[str] = (),
        zero_cost_only: bool = False,
        prefer_zero_cost: bool = False,
        max_age_seconds: float | None = None,
        allow_stale_revalidation: bool = False,
        now: float | None = None,
    ) -> FederatedRoute:
        """Route an open-ended family when no exact capability name exists.

        Family routing is deliberately weaker than exact capability routing: it is
        a late-binding escape hatch, not proof that the selected body implements an
        arbitrary operation.  The eventual host call and receipt remain required.
        """
        fam = str(family or "").strip()
        preferred = tuple(dict.fromkeys(str(x) for x in preferred_executors if str(x).strip()))
        ts = time.time() if now is None else float(now)
        all_matching = [
            b for b in self.bodies()
            if b.state in self.CALLABLE_STATES
            and (fam in b.families or any(str(cap).startswith(fam + ":") for cap in b.capabilities))
        ]
        rows = [
            b for b in all_matching
            if max_age_seconds is None or ts - b.observed_at <= float(max_age_seconds)
        ]
        order = {name.casefold(): i for i, name in enumerate(preferred)}
        def _cost_rank(body: FederatedBody) -> int:
            return 2 if body.zero_incremental_cost is True else (1 if body.zero_incremental_cost is None else 0)
        def _pref(body: FederatedBody) -> tuple[int, int]:
            hit = body.executor.casefold() in order or body.body_id.casefold() in order
            return (1 if hit else 0, -order.get(body.executor.casefold(), order.get(body.body_id.casefold(), 9999)))
        rows.sort(key=lambda b: (
            _cost_rank(b) if prefer_zero_cost else 0, *_pref(b), b.evidence_strength, b.observed_at
        ), reverse=True)
        unknown = tuple(b.body_id for b in rows if b.zero_incremental_cost is None)
        eligible = [b for b in rows if b.zero_incremental_cost is True or not zero_cost_only]
        if eligible:
            chosen = eligible[0]
            return FederatedRoute(
                f"family:{fam}", preferred, chosen.body_id, chosen.executor,
                tuple(b.body_id for b in eligible), unknown,
                "selected_family_proven_zero_cost" if zero_cost_only else "selected_family_callable",
            )
        if allow_stale_revalidation and max_age_seconds is not None:
            stale = [
                b for b in all_matching
                if ts - b.observed_at > float(max_age_seconds)
                and (b.zero_incremental_cost is True or not zero_cost_only)
            ]
            stale.sort(key=lambda b: (
                _cost_rank(b) if prefer_zero_cost else 0, *_pref(b), b.evidence_strength, b.observed_at
            ), reverse=True)
            if stale:
                chosen = stale[0]
                return FederatedRoute(
                    f"family:{fam}", preferred, chosen.body_id, chosen.executor,
                    tuple(b.body_id for b in stale),
                    tuple(b.body_id for b in stale if b.zero_incremental_cost is None),
                    "selected_stale_requires_revalidation",
                )
        return FederatedRoute(
            f"family:{fam}", preferred, "", "", (), unknown,
            "no_proven_zero_cost_family_body" if zero_cost_only else "no_callable_family_body",
        )
