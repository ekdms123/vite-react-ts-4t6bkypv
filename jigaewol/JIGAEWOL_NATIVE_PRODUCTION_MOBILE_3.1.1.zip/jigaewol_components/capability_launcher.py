from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, Sequence

from .execution_plane import ExecutionPlane, ExecutionRequest, ExecutionReceipt
from .capability_registry import CapabilityRegistry
from .reflexive_breaker import CapabilityExpansionTrigger


@dataclass(frozen=True)
class CapabilityCandidate:
    capability_id: str
    failure_family: str
    traits: frozenset[str]
    description: str
    build_request: Any




class RequestBuilder(Protocol):
    def build_request(self, trigger: CapabilityExpansionTrigger, root: Path) -> ExecutionRequest: ...


def _materialize_request(builder: Any, trigger: CapabilityExpansionTrigger, root: Path) -> ExecutionRequest:
    """Accept callable, object-based, or declarative execution request builders."""
    if isinstance(builder, ExecutionRequest):
        return builder
    if isinstance(builder, dict):
        return ExecutionRequest(**builder)
    method = getattr(builder, "build_request", None)
    if callable(method):
        return method(trigger, root)
    if callable(builder):
        return builder(trigger, root)
    raise TypeError(f"unsupported request builder substrate: {type(builder).__name__}")


@dataclass(frozen=True)
class LaunchResult:
    trigger_id: str
    capability_id: str
    failure_family: str
    acquired_now: bool
    activated_now: bool
    attempted_now: bool
    receipt_id: str
    exit_code: int
    stdout: str
    stderr: str
    proven_now: bool
    lifecycle_state: str
    lifecycle_facts: tuple[str, ...]


class CapabilityLauncher:
    """Turns breaker triggers into executable, cross-family interventions.

    A candidate becomes active only after successful execution evidence is recorded
    in the local capability registry. ``acquired_now`` remains as a compatibility
    alias for newly-active promotion; ``activated_now`` is the explicit lifecycle name.
    Selection, attempt, successful execution, and active status remain separate
    lifecycle facts. Closed-loop expansion selects a candidate from a distinct failure
    family so the new evidence path contributes independent failure modes.
    """

    REGISTRY_FILE = ".capability_registry.json"

    def __init__(
        self,
        execution_plane: ExecutionPlane,
        candidates: Sequence[CapabilityCandidate],
    ) -> None:
        self.execution_plane = execution_plane
        self.candidates = list(candidates)
        self.registry_path = self.execution_plane.root / self.REGISTRY_FILE
        self.registry = CapabilityRegistry(
            self.registry_path, self.execution_plane.root.parent
        )

    def _read_registry(self) -> dict:
        return self.registry.read()

    def choose(self, trigger: CapabilityExpansionTrigger) -> CapabilityCandidate:
        required = set(trigger.required_traits)
        origin_families = set(trigger.origin_failure_families)
        viable = [c for c in self.candidates if required.issubset(c.traits)]
        if not viable:
            raise RuntimeError("no candidate provides the requested traits")
        # Prefer a different observed failure family when available, but never
        # turn a past failure label into a permanent blacklist.
        viable.sort(key=lambda c: (c.failure_family in origin_families, c.capability_id))
        return viable[0]

    def launch(self, trigger: CapabilityExpansionTrigger) -> LaunchResult:
        """Launch with the original exception semantics."""
        return self._launch(trigger, resilient=False)

    def launch_resilient(self, trigger: CapabilityExpansionTrigger) -> LaunchResult:
        """Launch while recording process-start and timeout outcomes as receipts.

        Candidate selection and lifecycle semantics match ``launch``. The execution
        boundary uses :meth:`ExecutionPlane.run_resilient`, giving orchestration code
        a receipt for every launch attempt.
        """
        return self._launch(trigger, resilient=True)

    def _launch(
        self, trigger: CapabilityExpansionTrigger, *, resilient: bool
    ) -> LaunchResult:
        candidate = self.choose(trigger)
        self.registry.record_selected(candidate.capability_id, trigger_id=trigger.trigger_id)
        request = _materialize_request(candidate.build_request, trigger, self.execution_plane.root)
        runner = (
            self.execution_plane.run_resilient
            if resilient
            else self.execution_plane.run
        )
        try:
            receipt: ExecutionReceipt = runner(request)
        except Exception as exc:
            self.registry.record_exception(
                candidate.capability_id,
                trigger_id=trigger.trigger_id,
                exception=exc,
            )
            raise
        acquired_now = self.registry.record_execution(
            candidate.capability_id, receipt, trigger_id=trigger.trigger_id
        )
        return LaunchResult(
            trigger_id=trigger.trigger_id,
            capability_id=candidate.capability_id,
            failure_family=candidate.failure_family,
            acquired_now=acquired_now,
            activated_now=acquired_now,
            attempted_now=True,
            receipt_id=receipt.receipt_id,
            exit_code=receipt.exit_code,
            stdout=receipt.stdout,
            stderr=receipt.stderr,
            proven_now=(receipt.exit_code == 0),
            lifecycle_state=self.registry.lifecycle_state(candidate.capability_id) or "unknown",
            lifecycle_facts=self.registry.lifecycle_facts(candidate.capability_id),
        )
