from __future__ import annotations

import ast
import hashlib
import json


import shutil
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .execution_plane import ExecutionPlane, ExecutionReceipt, ExecutionRequest


@dataclass(frozen=True)
class SourceInventory:
    root: str
    languages: tuple[str, ...]
    manifests: tuple[str, ...]
    python_modules: tuple[str, ...]
    node_packages: tuple[str, ...]
    rust_manifests: tuple[str, ...]
    go_modules: tuple[str, ...]


@dataclass(frozen=True)
class CompiledComponent:
    component_id: str
    language: str
    source_root: str
    source_path: str
    source_sha256: str
    entrypoints: tuple[str, ...]
    wrapper_path: str
    probe_receipt_id: str
    probe_success: bool
    provenance: dict[str, Any]



class UniversalCapabilityCompiler:
    """Compiles materialized source trees into executable JIGAEWOL components.

    Adapters are open-ended. This build includes a real Python-module adapter and
    inventories Node/Rust/Go manifests so later adapters can be added without changing
    the acquisition contract.
    """

    def __init__(self, root: Path, execution_plane: ExecutionPlane) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.components = self.root / "components"
        self.components.mkdir(exist_ok=True)
        self.execution_plane = execution_plane

    @staticmethod
    def inventory(source_root: Path) -> SourceInventory:
        source_root = Path(source_root).resolve()
        languages: set[str] = set()
        manifests: list[str] = []
        py: list[str] = []
        node: list[str] = []
        rust: list[str] = []
        go: list[str] = []
        for p in source_root.rglob("*"):
            if not p.is_file():
                continue
            rel = str(p.relative_to(source_root))
            if p.suffix == ".py":
                languages.add("python"); py.append(rel)
            elif p.suffix in {".js", ".mjs", ".cjs", ".ts", ".tsx"}:
                languages.add("node"); node.append(rel)
            elif p.suffix == ".rs":
                languages.add("rust")
            elif p.suffix == ".go":
                languages.add("go")
            if p.name in {"pyproject.toml", "requirements.txt", "setup.py", "package.json", "Cargo.toml", "go.mod"}:
                manifests.append(rel)
                if p.name == "package.json": node.append(rel)
                elif p.name == "Cargo.toml": rust.append(rel)
                elif p.name == "go.mod": go.append(rel)
        return SourceInventory(
            str(source_root), tuple(sorted(languages)), tuple(sorted(set(manifests))),
            tuple(sorted(py)), tuple(sorted(set(node))), tuple(sorted(set(rust))), tuple(sorted(set(go))),
        )

    @staticmethod
    def _public_functions(path: Path) -> tuple[str, ...]:
        tree = ast.parse(path.read_text(encoding="utf-8"))
        return tuple(
            node.name for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith("_")
        )

    def compile_python_module(
        self,
        *,
        source_root: Path,
        module_path: str,
        provenance: dict[str, Any] | None = None,
        probe: dict[str, Any] | None = None,
    ) -> CompiledComponent:
        source_root = Path(source_root).resolve()
        src = (source_root / module_path).resolve()
        if source_root not in src.parents:
            raise ValueError("module path escapes source root")
        functions = self._public_functions(src)
        if not functions:
            raise ValueError("no public Python functions discovered")
        component_id = f"py_{src.stem}_{hashlib.sha256(src.read_bytes()).hexdigest()[:12]}"
        component_root = self.components / component_id
        component_root.mkdir(parents=True, exist_ok=True)
        wrapper = component_root / "wrapper.py"
        module_name = module_path[:-3].replace("/", ".").replace("\\", ".")
        wrapper.write_text(
            "import inspect, json, sys\n"
            f"sys.path.insert(0, {str(source_root)!r})\n"
            f"from {module_name} import *\n"
            f"ALLOWED={list(functions)!r}\n"
            "req=json.loads(sys.stdin.read() or '{}')\n"
            "name=req.get('function')\n"
            "if name not in ALLOWED: raise SystemExit('function not allowed')\n"
            "fn=globals()[name]\n"
            "out=fn(*req.get('args',[]), **req.get('kwargs',{}))\n"
            "print(json.dumps({'ok':True,'result':out}, default=str))\n",
            encoding="utf-8",
        )
        probe_payload = probe or {"function": functions[0], "args": [], "kwargs": {}}
        # Wrapper is physically located outside ExecutionPlane workspace, so execute it
        # through Python -c with its source embedded. This keeps the plane's cwd boundary
        # while proving the generated component in a real subprocess.
        runner = (
            "import subprocess,sys,json; "
            f"p=subprocess.run([sys.executable,{str(wrapper)!r}],input={json.dumps(probe_payload)!r},text=True,capture_output=True); "
            "print(p.stdout,end=''); print(p.stderr,end='',file=sys.stderr); raise SystemExit(p.returncode)"
        )
        receipt = self.execution_plane.run_resilient(ExecutionRequest(["python", "-c", runner]))
        component = CompiledComponent(
            component_id=component_id,
            language="python",
            source_root=str(source_root),
            source_path=str(src),
            source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),
            entrypoints=functions,
            wrapper_path=str(wrapper),
            probe_receipt_id=receipt.receipt_id,
            probe_success=receipt.exit_code == 0,
            provenance=dict(provenance or {}),
        )
        (component_root / "manifest.json").write_text(json.dumps(asdict(component), ensure_ascii=False, indent=2), encoding="utf-8")
        return component
    def _probe_command(self, argv: list[str], *, timeout_s: float | None = None) -> ExecutionReceipt:
        runner = (
            "import subprocess,sys; "
            f"p=subprocess.run({argv!r},text=True,capture_output=True); "
            "print(p.stdout,end=''); print(p.stderr,end='',file=sys.stderr); raise SystemExit(p.returncode)"
        )
        return self.execution_plane.run_resilient(ExecutionRequest(["python", "-c", runner], timeout_s=timeout_s))

    def compile_node_script(
        self,
        *,
        source_root: Path,
        script_path: str,
        provenance: dict[str, Any] | None = None,
        probe_args: Iterable[str] = (),
    ) -> CompiledComponent:
        source_root = Path(source_root).resolve()
        src = (source_root / script_path).resolve()
        if source_root not in src.parents:
            raise ValueError("script path escapes source root")
        if src.suffix not in {".js", ".mjs", ".cjs"}:
            raise ValueError("node adapter requires .js/.mjs/.cjs")
        if shutil.which("node") is None:
            raise RuntimeError("node runtime unavailable")
        digest = hashlib.sha256(src.read_bytes()).hexdigest()
        component_id = f"node_{src.stem}_{digest[:12]}"
        component_root = self.components / component_id
        component_root.mkdir(parents=True, exist_ok=True)
        launcher = component_root / "launcher.json"
        argv = [shutil.which("node") or "node", str(src), *map(str, probe_args)]
        receipt = self._probe_command(argv)
        launcher.write_text(json.dumps({"argv_prefix": argv[:2]}, indent=2), encoding="utf-8")
        component = CompiledComponent(
            component_id=component_id, language="node", source_root=str(source_root), source_path=str(src),
            source_sha256=digest, entrypoints=("main",), wrapper_path=str(launcher),
            probe_receipt_id=receipt.receipt_id, probe_success=receipt.exit_code == 0,
            provenance={**dict(provenance or {}), "runtime": "node"},
        )
        (component_root / "manifest.json").write_text(json.dumps(asdict(component), ensure_ascii=False, indent=2), encoding="utf-8")
        return component

    def compile_go_program(
        self,
        *,
        source_root: Path,
        program_path: str,
        provenance: dict[str, Any] | None = None,
        probe_args: Iterable[str] = (),
    ) -> CompiledComponent:
        source_root = Path(source_root).resolve()
        src = (source_root / program_path).resolve()
        if source_root not in src.parents:
            raise ValueError("program path escapes source root")
        go = shutil.which("go")
        if go is None:
            raise RuntimeError("go runtime unavailable")
        digest = hashlib.sha256(src.read_bytes()).hexdigest()
        component_id = f"go_{src.stem}_{digest[:12]}"
        component_root = self.components / component_id
        component_root.mkdir(parents=True, exist_ok=True)
        binary = component_root / "component_bin"
        build_argv = ["env", "GOTELEMETRY=off", "GOTOOLCHAIN=local", go, "build", "-o", str(binary), str(src)]
        build_receipt = self._probe_command(build_argv)
        if build_receipt.exit_code == 0:
            receipt = self._probe_command([str(binary), *map(str, probe_args)])
        else:
            receipt = build_receipt
        component = CompiledComponent(
            component_id=component_id, language="go", source_root=str(source_root), source_path=str(src),
            source_sha256=digest, entrypoints=("main",), wrapper_path=str(binary),
            probe_receipt_id=receipt.receipt_id, probe_success=receipt.exit_code == 0,
            provenance={**dict(provenance or {}), "runtime": "go", "build_receipt_id": build_receipt.receipt_id},
        )
        (component_root / "manifest.json").write_text(json.dumps(asdict(component), ensure_ascii=False, indent=2), encoding="utf-8")
        return component


    def compile_swift_program(
        self,
        *,
        source_root: Path,
        program_path: str,
        provenance: dict[str, Any] | None = None,
        probe_args: Iterable[str] = (),
    ) -> CompiledComponent:
        source_root = Path(source_root).resolve(); src=(source_root/program_path).resolve()
        if source_root not in src.parents: raise ValueError("program path escapes source root")
        swiftc=shutil.which("swiftc")
        if swiftc is None: raise RuntimeError("swift compiler unavailable")
        digest=hashlib.sha256(src.read_bytes()).hexdigest(); component_id=f"swift_{src.stem}_{digest[:12]}"
        component_root=self.components/component_id; component_root.mkdir(parents=True,exist_ok=True); binary=component_root/"component_bin"
        build=self._probe_command([swiftc,str(src),"-o",str(binary)])
        receipt=self._probe_command([str(binary),*map(str,probe_args)]) if build.exit_code==0 else build
        component=CompiledComponent(component_id,"swift",str(source_root),str(src),digest,("main",),str(binary),receipt.receipt_id,receipt.exit_code==0,{**dict(provenance or {}),"runtime":"swift","build_receipt_id":build.receipt_id})
        (component_root/"manifest.json").write_text(json.dumps(asdict(component),ensure_ascii=False,indent=2),encoding="utf-8"); return component

    def compile_c_program(
        self,
        *,
        source_root: Path,
        program_path: str,
        provenance: dict[str, Any] | None = None,
        probe_args: Iterable[str] = (),
    ) -> CompiledComponent:
        source_root=Path(source_root).resolve(); src=(source_root/program_path).resolve()
        if source_root not in src.parents: raise ValueError("program path escapes source root")
        cc=shutil.which("clang") or shutil.which("gcc")
        if cc is None: raise RuntimeError("C compiler unavailable")
        digest=hashlib.sha256(src.read_bytes()).hexdigest(); component_id=f"c_{src.stem}_{digest[:12]}"
        component_root=self.components/component_id; component_root.mkdir(parents=True,exist_ok=True); binary=component_root/"component_bin"
        build=self._probe_command([cc,str(src),"-O2","-o",str(binary)])
        receipt=self._probe_command([str(binary),*map(str,probe_args)]) if build.exit_code==0 else build
        component=CompiledComponent(component_id,"c",str(source_root),str(src),digest,("main",),str(binary),receipt.receipt_id,receipt.exit_code==0,{**dict(provenance or {}),"runtime":Path(cc).name,"build_receipt_id":build.receipt_id})
        (component_root/"manifest.json").write_text(json.dumps(asdict(component),ensure_ascii=False,indent=2),encoding="utf-8"); return component

    def compile_java_program(
        self,
        *,
        source_root: Path,
        program_path: str,
        provenance: dict[str, Any] | None = None,
        probe_args: Iterable[str] = (),
    ) -> CompiledComponent:
        source_root=Path(source_root).resolve(); src=(source_root/program_path).resolve()
        if source_root not in src.parents: raise ValueError("program path escapes source root")
        javac=shutil.which("javac"); java=shutil.which("java")
        if javac is None or java is None: raise RuntimeError("Java toolchain unavailable")
        digest=hashlib.sha256(src.read_bytes()).hexdigest(); component_id=f"java_{src.stem}_{digest[:12]}"
        component_root=self.components/component_id; component_root.mkdir(parents=True,exist_ok=True)
        build=self._probe_command([javac,"-d",str(component_root),str(src)])
        receipt=self._probe_command([java,"-cp",str(component_root),src.stem,*map(str,probe_args)]) if build.exit_code==0 else build
        launcher=component_root/"launcher.json"; launcher.write_text(json.dumps({"java":java,"classpath":str(component_root),"class":src.stem},indent=2),encoding="utf-8")
        component=CompiledComponent(component_id,"java",str(source_root),str(src),digest,("main",),str(launcher),receipt.receipt_id,receipt.exit_code==0,{**dict(provenance or {}),"runtime":"java","build_receipt_id":build.receipt_id})
        (component_root/"manifest.json").write_text(json.dumps(asdict(component),ensure_ascii=False,indent=2),encoding="utf-8"); return component


