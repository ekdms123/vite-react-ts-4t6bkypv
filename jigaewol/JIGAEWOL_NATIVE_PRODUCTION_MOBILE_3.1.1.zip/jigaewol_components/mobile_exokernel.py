from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass, field

from typing import Any, Iterable

from jigaewol_runtime.capabilities.search_intent import explicit_public_search_requested

from .cognition_backplane import CognitionBackplane
from .host_syscall_pump import HostSyscallPump, PumpRequest
from .intent_fidelity import IntentFidelityProjector, GhostVerdict
from .verification_budget import VerificationBudgetPolicy
from .requirement_contract import RequirementCompiler
from .intent_deep_analyzer import IntentDeepAnalyzer
from .discourse_scope import DiscourseScopeAnalyzer
from .semantic_authority import SemanticAuthorityCompiler
from .foundational_rewrite_intent import foundational_rewrite_requested


TURN_CONTRACT_VERSION = "jigaewol-open-runtime-v42"


def _sha_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def _depth_authority(user_command: str) -> dict[str, bool]:
    """Parse user command directives and depth intents faithfully.

    Distinguishes deepening signals from shallowing requests while honoring explicit
    instructions directly.
    """
    text = str(user_command).casefold()
    directive_text = re.sub(r"`[^`]*`|'[^']*'|\"[^\"]*\"", " ", text)
    deepen = (
        "깊게", "더 깊", "깊이 생각", "깊이 분석", "깊이 검토", "깊이 파", "심층",
        "자세히", "철저", "끝까지", "최대한", "여러 갈래",
        "창의", "도약", "한계 없이", "열린 사고", "열린 탐색", "개방적 사고",
        "가능성 탐색", "폭넓게 탐색", "대안 탐색", "최고 성능", "고성능",
        "deep", "exhaustive", "frontier",
    )
    shallow = (
        "간단히", "짧게", "한 줄", "요약만", "핵심만",
        "간단하게", "brief", "concise", "short answer",
    )
    anti_shrink = (
        "의도 축소", "목표 축소", "제약 축소", "목표 보존",
        "닫힌 사고", "축소하지", "낮추지", "줄이지",
        "안전한 사고", "안전한 경로 중심", "착한 아이", "과잉 검증",
    )
    # Structural/default-layer rewrites should not be demoted to ordinary advice.
    foundational_rewrite = foundational_rewrite_requested(user_command)
    explicit_deepen = any(x in directive_text for x in deepen) or foundational_rewrite
    explicit_shallow = any(x in directive_text for x in shallow) and not explicit_deepen
    shrink_objection = any(x in text for x in anti_shrink)
    return {
        "explicit_deepen": bool(explicit_deepen),
        "explicit_shallow": bool(explicit_shallow),
        "shrink_objection": bool(shrink_objection),
        "no_downshift": bool(shrink_objection or foundational_rewrite),
        "foundational_rewrite": bool(foundational_rewrite),
    }


def _exact_source_effect_authorized(user_command: str) -> bool:
    """Compile host/material effect authority from the exact current source.

    Host/model plan fields may propose search/capability/browser routes, but they do not
    grant required actuation.  This mirrors the canonical semantic authority path for
    the legacy/mobile entrypoint instead of trusting a host-proposed TurnPlan.
    """
    contract = RequirementCompiler.compile(str(user_command))
    analysis = IntentDeepAnalyzer().analyze(str(user_command))
    scope = DiscourseScopeAnalyzer.compile(str(user_command), contract)
    authority = SemanticAuthorityCompiler.compile(
        str(user_command), contract, analysis,
        effective_depth=str(analysis.inferred_depth or "unspecified"),
        discourse_scope=scope,
    )
    return bool(authority.source_effect_authorized)


@dataclass(frozen=True)
class TurnPlan:
    command_sha256: str
    mode: str = "adaptive"
    workstream_key: str = ""
    deep_reasoning_required: bool | None = None
    search_required: bool = False
    external_capability_required: bool = False
    signed_in_browser_preferred: bool = False
    required_capabilities: tuple[str, ...] = ()
    required_source_families: tuple[str, ...] = ()
    source_effect_authorized: bool = False
    source: str = "runtime_fallback"
    rationale: str = ""
    facets: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, user_command: str, raw: dict[str, Any] | None) -> "TurnPlan":
        if not raw:
            return cls.fallback(user_command)
        expected = _sha_text(user_command)
        supplied = str(raw.get("command_sha256") or expected)
        if supplied != expected:
            raise ValueError("turn plan command_sha256 does not match exact user command")
        mode = str(raw.get("mode") or "adaptive")
        if mode not in {"fast", "adaptive", "frontier"}:
            raise ValueError(f"unsupported turn mode: {mode}")
        authority = _depth_authority(user_command)
        facets = dict(raw.get("facets") or {})
        raw_deep = raw.get("deep_reasoning_required")
        if raw_deep not in (None, True, False):
            raise ValueError("deep_reasoning_required must be boolean or null")
        deep: bool | None = None

        latent = dict(facets.get("intent_deep_analysis") or {})
        latent_depth = str(latent.get("inferred_depth") or "unspecified").casefold()
        surface_depth = "deep" if authority["explicit_deepen"] else ("shallow" if authority["explicit_shallow"] else "unspecified")
        if surface_depth in {"deep", "shallow"} and latent_depth in {"deep", "shallow"} and latent_depth != surface_depth:
            facets["latent_intent_conflict_preserved"] = True
            facets["latent_intent_conflicting_depth"] = latent_depth

        # Historical/latent analysis is context, not authority over the current turn.
        # Only current explicit depth wording or an upward host proposal may shape execution depth.
        facets["latent_intent_applied"] = False
        facets["current_explicit_command_has_depth_authority"] = True
        if authority["explicit_deepen"]:
            deep = True
            mode = "frontier"
            facets.update({
                "depth_request_state": "deep",
                "depth_decision_authority": "user_explicit",
                "depth_execution_source": "user_explicit",
                "system_depth_reduction_allowed": False,
            })
        elif authority["explicit_shallow"]:
            deep = False
            facets.update({
                "depth_request_state": "shallow",
                "depth_decision_authority": "user_explicit",
                "depth_execution_source": "user_explicit",
                "system_depth_reduction_allowed": False,
            })
        else:
            facets.update({
                "depth_request_state": "unspecified",
                "depth_decision_authority": "user_unspecified",
                "system_depth_reduction_allowed": False,
            })
            if raw_deep is True:
                deep = True
                facets["depth_execution_source"] = "host_upward_proposal"
                if mode == "fast":
                    mode = "adaptive"
            else:
                deep = None
                facets["depth_execution_source"] = "unresolved"
                if raw_deep is False:
                    facets["host_depth_downshift_ignored"] = True
                if mode == "fast":
                    mode = "adaptive"

        if authority["shrink_objection"]:
            facets.update({
                "user_intent_shrink_objection": True,
                "no_downshift_signal": True,
                "force_deep_from_objection": bool(authority["foundational_rewrite"]),
                "objection_action": "rebuild_default" if authority["foundational_rewrite"] else "revoke_downshift_only",
                "self_sealing_control_disabled": True,
                "verification_escalation_from_objection_allowed": False,
            })

        return cls(
            command_sha256=expected,
            mode=mode,
            workstream_key=str(raw.get("workstream_key") or ""),
            deep_reasoning_required=deep,
            search_required=bool(raw.get("search_required", False)),
            external_capability_required=bool(raw.get("external_capability_required", False)),
            signed_in_browser_preferred=bool(raw.get("signed_in_browser_preferred", False)),
            required_capabilities=tuple(dict.fromkeys(str(x) for x in (raw.get("required_capabilities") or ()))),
            required_source_families=tuple(dict.fromkeys(str(x) for x in (raw.get("required_source_families") or ()))),
            source_effect_authorized=_exact_source_effect_authorized(user_command),
            source=str(raw.get("source") or "host_model_proposal"),
            rationale=str(raw.get("rationale") or ""),
            facets=facets,
        )

    @classmethod
    def fallback(cls, user_command: str) -> "TurnPlan":
        text = str(user_command)
        lowered = text.casefold()
        capability_markers = ("github", "깃허브", "plugin", "플러그인", "오픈소스", "open source", "설치", "도구")
        browser_markers = ("추천 피드", "내 피드", "내 계정", "로그인", "signed-in", "signed in", "브라우저 세션", "authenticated session", "내 dm", "my dm")
        authority = _depth_authority(text)
        search = explicit_public_search_requested(text)
        capability = any(x in lowered for x in capability_markers)
        browser = any(x in lowered for x in browser_markers)
        deep: bool | None = True if authority["explicit_deepen"] else (False if authority["explicit_shallow"] else None)
        mode = "frontier" if (deep is True or browser) else ("fast" if deep is False and not (search or capability) else "adaptive")
        families: tuple[str, ...] = ()
        if search:
            families = (
                "first_party", "web_current", "community", "social_recommendation",
                "code_ecosystem", "research", "creator_graph", "multilingual",
            )
        caps = ("external_capability_discovery",) if capability else ()
        facets = {
            "depth_request_state": "deep" if authority["explicit_deepen"] else ("shallow" if authority["explicit_shallow"] else "unspecified"),
            "depth_decision_authority": "user_explicit" if (authority["explicit_deepen"] or authority["explicit_shallow"]) else "user_unspecified",
            "depth_execution_source": "user_explicit" if (authority["explicit_deepen"] or authority["explicit_shallow"]) else "unresolved",
            "system_depth_reduction_allowed": False,
        }
        if authority["shrink_objection"]:
            facets.update({
                "user_intent_shrink_objection": True,
                "no_downshift_signal": True,
                "force_deep_from_objection": bool(authority["foundational_rewrite"]),
                "objection_action": "rebuild_default" if authority["foundational_rewrite"] else "revoke_downshift_only",
                "self_sealing_control_disabled": True,
                "verification_escalation_from_objection_allowed": False,
            })
        return cls(
            command_sha256=_sha_text(user_command), mode=mode,
            deep_reasoning_required=deep, search_required=search,
            external_capability_required=capability,
            signed_in_browser_preferred=browser,
            required_capabilities=caps,
            required_source_families=families,
            source_effect_authorized=_exact_source_effect_authorized(user_command),
            source="runtime_fallback",
            rationale="Fallback route proposal; exact command remains primary authority.",
            facets=facets,
        )


@dataclass(frozen=True)
class TurnControlSnapshot:
    contract_version: str
    command_sha256: str
    plan: dict[str, Any]
    foundation: dict[str, Any]
    local_stages: tuple[str, ...]
    host_requests: tuple[dict[str, Any], ...]
    primary_required_host_request_ids: tuple[str, ...]
    ghost_host_request_ids: tuple[str, ...]
    required_host_request_ids: tuple[str, ...]
    fidelity_mode: str
    ghost_bundle_sha256: str
    ghost_verified: bool
    ghost_worlds_sha256: str
    requirement_atoms: tuple[dict[str, str], ...]
    contract_satisfied: bool
    missing_required_host_results: tuple[str, ...]
    failed_required_host_results: tuple[str, ...]
    contract_sha256: str
    prepared_at: float


class MobileExokernelController:
    """Adaptive per-turn control loop for fluid chat and deep execution."""

    def __init__(self, foundation) -> None:
        self.foundation = foundation
        self.cognition = CognitionBackplane(self.foundation.root / "cognition")
        self.pump = HostSyscallPump(
            self.foundation.root / "host_pump",
            queues={
                "open_world": self.foundation.open_world.queue,
                "search": self.foundation.search.queue,
                "acquisition": self.foundation.acquisition.queue,
                "cognition": self.cognition.syscalls,
            },
        )
        self.preparation_path = self.foundation.root / "host_pump" / "turn_preparations.json"
        self.fidelity = IntentFidelityProjector(self.foundation.root / "intent_fidelity")
        if not self.preparation_path.exists():
            self.preparation_path.write_text(json.dumps({"preparations": {}}, indent=2), encoding="utf-8")

    def register_host_surfaces(self, rows: Iterable[dict[str, Any]]) -> tuple[str, ...]:
        ids: list[str] = []
        for raw in rows:
            surface_id = str(raw.get("surface_id") or "").strip()
            if not surface_id:
                continue
            self.foundation.surfaces.upsert(
                surface_id,
                kind=str(raw.get("kind") or "host_surface"),
                state=str(raw.get("state") or "callable"),
                capabilities=tuple(str(x) for x in (raw.get("capabilities") or ())),
                connector_ref=str(raw.get("connector_ref") or ""),
                evidence=dict(raw.get("evidence") or {}),
                evidence_strength=(float(raw["evidence_strength"]) if raw.get("evidence_strength") is not None else None),
                failure_family=str(raw.get("failure_family") or ""),
                last_error=str(raw.get("last_error") or ""),
            )
            ids.append(surface_id)
        return tuple(ids)

    def _register(self, queue_key: str, intent, *, required: bool) -> PumpRequest:
        return self.pump.register(queue_key, intent, required=required)

    @staticmethod
    def _fidelity_mode(plan: TurnPlan, required_count: int) -> str:
        # Reasoning depth does not imply heavier verification.  Verification is a
        # bounded truth floor selected from execution risk/explicit request.
        return VerificationBudgetPolicy.choose(
            required_count=required_count, facets=plan.facets
        ).mode

    def _intent_capsule(self, command: str, plan: TurnPlan, purpose: str) -> dict[str, Any]:
        facets = dict(plan.facets or {})
        scoped = dict((facets.get("intent_capsules") or {}).get(purpose) or {})
        # The exact current source owns destination authority. Purpose-specific or
        # caller-derived objectives may enrich the search/cognition context but may not
        # replace the objective sent to an actuator or cognition substrate.
        objective = str(command)
        derived_objective = str(scoped.get("objective") or facets.get(f"{purpose}_objective") or "")
        active = self.foundation.intent.active()
        active_hashes = [hashlib.sha256(str(getattr(x, "text", x)).encode("utf-8")).hexdigest() for x in active]
        return {
            "purpose": str(purpose),
            "objective": objective,
            "derived_objective": derived_objective,
            "derived_objective_is_advisory": True,
            "command_sha256": plan.command_sha256,
            "goal_anchor": dict(facets.get("goal_anchor") or {}),
            "goal_immutability": dict(facets.get("goal_immutability") or {}),
            "requirement_contract": dict(facets.get("requirement_contract") or {}),
            "strategy_topology": dict(facets.get("strategy_topology") or {}),
            "active_requirement_sha256": active_hashes,
            "workstream_key": plan.workstream_key,
        }

    def prepare(
        self,
        user_command: str,
        *,
        artifact_sha256: str,
        plan: TurnPlan,
        host_surfaces: Iterable[dict[str, Any]] = (),
        turn_key: str = "",
    ) -> tuple[TurnControlSnapshot, str]:
        command = str(user_command)
        if _sha_text(command) != plan.command_sha256:
            raise ValueError("turn plan is not bound to exact user command")
        registered_surfaces = self.register_host_surfaces(host_surfaces)
        prep_key = str(turn_key or plan.facets.get("turn_key") or "")
        if prep_key:
            prep_data = json.loads(self.preparation_path.read_text(encoding="utf-8"))
            prior = prep_data.get("preparations", {}).get(prep_key)
            if prior is not None:
                if str(prior.get("command_sha256")) != plan.command_sha256:
                    raise ValueError("turn_key already belongs to a different user command")
                snap_raw = dict(prior["snapshot"])
                snap_raw["local_stages"] = tuple(snap_raw.get("local_stages", ()))
                snap_raw["host_requests"] = tuple(snap_raw.get("host_requests", ()))
                if str(snap_raw.get("contract_version") or "") != TURN_CONTRACT_VERSION:
                    prep_data.get("preparations", {}).pop(prep_key, None)
                    self.preparation_path.write_text(json.dumps(prep_data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
                else:
                    snap_raw["primary_required_host_request_ids"] = tuple(snap_raw.get("primary_required_host_request_ids", snap_raw.get("required_host_request_ids", ())))
                    snap_raw["ghost_host_request_ids"] = tuple(snap_raw.get("ghost_host_request_ids", ()))
                    snap_raw["required_host_request_ids"] = tuple(snap_raw.get("required_host_request_ids", ()))
                    snap_raw["requirement_atoms"] = tuple(snap_raw.get("requirement_atoms", ()))
                    snap_raw["missing_required_host_results"] = tuple(snap_raw.get("missing_required_host_results", ()))
                    snap_raw["failed_required_host_results"] = tuple(snap_raw.get("failed_required_host_results", ()))
                    snap_raw.setdefault("fidelity_mode", "none" if not snap_raw.get("primary_required_host_request_ids") else "ghost")
                    snap_raw.setdefault("ghost_bundle_sha256", "")
                    snap_raw.setdefault("ghost_verified", not bool(snap_raw.get("primary_required_host_request_ids")))
                    snap_raw.setdefault("ghost_worlds_sha256", "")
                    return self.refresh_contract(TurnControlSnapshot(**snap_raw)), str(prior["continuity_task_id"])
        foundation_snapshot = self.foundation.bind_turn(
            command,
            artifact_sha256=artifact_sha256,
            workstream_key=plan.workstream_key or None,
        )
        local_stages = ["exact_user_command_bound", "cumulative_intent_bound", "continuity_bound", "route_plan_bound"]
        if bool((plan.facets or {}).get("intent_deep_analyzer_enabled")):
            local_stages.append("intent_deep_analyzer_bound")
        if bool((plan.facets or {}).get("latent_intent_applied")):
            local_stages.append("latent_intent_applied")
        if bool((plan.facets or {}).get("latent_intent_conflict_preserved")):
            local_stages.append("latent_intent_conflict_preserved_without_override")
        if bool((plan.facets or {}).get("user_intent_shrink_objection")):
            local_stages.extend(["self_sealing_control_disabled", "router_depth_reduction_authority_revoked"])
        requests: list[PumpRequest] = []
        effect_authorized = bool(plan.source_effect_authorized)

        if plan.deep_reasoning_required:
            capsule = self._intent_capsule(command, plan, "cognition")
            intent = self.cognition.request_candidates(
                capsule["objective"],
                archive_summary=(),
                requested_count=0,
                outside_taxonomy_required=False,
                constraints={
                    "adaptive_count": True,
                    "fixed_branch_count_is_not_a_ceiling": True,
                    "ordinary_answer_must_not_be_degraded": True,
                    "intent_capsule": capsule,
                },
            )
            requests.append(self._register("cognition", intent, required=True))
            local_stages.append("cognition_escalation_requested")

        if plan.search_required:
            families = plan.required_source_families or (
                "first_party", "web_current", "community", "social_recommendation",
                "code_ecosystem", "research", "creator_graph", "multilingual",
            )
            capsule = self._intent_capsule(command, plan, "search")
            for intent in self.foundation.search.request_family_round(capsule["objective"], families, intent_capsule=capsule):
                requests.append(self._register("search", intent, required=effect_authorized))
            discovery = self.foundation.search.request_open_world_expansion(capsule["objective"], intent_capsule=capsule)
            lowered = str(command).casefold()
            frontier_markers = (
                "유행", "요즘", "트렌드", "최신", "커뮤니티", "인스타", "트위터", "틱톡",
                "깃허브", "오픈소스", "남다르게", "창의", "끝까지", "한계", "trend", "latest",
                "community", "social", "github", "open source", "frontier",
            )
            expansion_required = bool(
                plan.deep_reasoning_required is True
                or plan.external_capability_required
                or plan.signed_in_browser_preferred
                or bool((plan.facets or {}).get("open_world_search_required"))
                or any(marker in lowered for marker in frontier_markers)
            )
            requests.append(self._register("search", discovery, required=bool(expansion_required and effect_authorized)))
            local_stages.append("search_cycle_requested")
            local_stages.append("open_world_search_required" if expansion_required else "open_world_search_optional")

        materialization_requested = False
        if plan.external_capability_required or plan.required_capabilities:
            if not materialization_requested:
                capsule = self._intent_capsule(command, plan, "acquisition")
                intent = self.foundation.acquisition.discover(
                    objective=capsule["objective"],
                    capabilities=plan.required_capabilities or ("unknown_missing_capability",),
                    source_kinds=(),
                )
                requests.append(self._register("acquisition", intent, required=effect_authorized))
            local_stages.append("capability_acquisition_requested")

        if plan.signed_in_browser_preferred:
            existing = self.foundation.surfaces.discover("signed_in_browser")
            if not existing:
                capsule = self._intent_capsule(command, plan, "browser")
                need = self.foundation.open_world.declare_need(
                    objective=capsule["objective"],
                    desired_outcomes=("signed_in_browser", "recommendation_feed_observation"),
                    known_routes=(),
                    context={"user_controlled_session_required": True, "registered_host_surfaces": list(registered_surfaces), "intent_capsule": capsule},
                )
                intent = self.foundation.open_world.request_discovery(need)
                requests.append(self._register("open_world", intent, required=effect_authorized))
            local_stages.append("signed_in_browser_route_bound")

        required_ids = tuple(x.syscall_id for x in requests if x.required)
        ok, missing, failed = self.pump.required_status(required_ids)
        contract_body = {
            "contract_version": TURN_CONTRACT_VERSION,
            "command_sha256": plan.command_sha256,
            "plan": asdict(plan),
            "foundation": asdict(foundation_snapshot),
            "local_stages": local_stages,
            "required_host_request_ids": list(required_ids),
            "source_effect_authorized": effect_authorized,
            "derived_route_requests_may_be_optional_but_not_required_without_source_effect_authority": True,
            "fidelity_mode": self._fidelity_mode(plan, len(required_ids)),
        }
        contract_sha = hashlib.sha256(json.dumps(contract_body, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")).hexdigest()
        snapshot = TurnControlSnapshot(
            contract_version=TURN_CONTRACT_VERSION,
            command_sha256=plan.command_sha256,
            plan=asdict(plan),
            foundation=asdict(foundation_snapshot),
            local_stages=tuple(local_stages),
            host_requests=tuple(asdict(x) for x in requests),
            primary_required_host_request_ids=required_ids,
            ghost_host_request_ids=(),
            required_host_request_ids=required_ids,
            fidelity_mode="none" if not required_ids else self._fidelity_mode(plan, len(required_ids)),
            ghost_bundle_sha256="",
            ghost_verified=not bool(required_ids),
            ghost_worlds_sha256="",
            requirement_atoms=(),
            contract_satisfied=ok if not required_ids else False,
            missing_required_host_results=missing,
            failed_required_host_results=failed,
            contract_sha256=contract_sha,
            prepared_at=time.time(),
        )
        if prep_key:
            prep_data = json.loads(self.preparation_path.read_text(encoding="utf-8"))
            prep_data.setdefault("preparations", {})[prep_key] = {
                "command_sha256": plan.command_sha256,
                "continuity_task_id": foundation_snapshot.continuity_task_id,
                "snapshot": asdict(snapshot),
                "created_at": time.time(),
            }
            self.preparation_path.write_text(json.dumps(prep_data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        self.pump.flush()
        return snapshot, foundation_snapshot.continuity_task_id

    def _save_snapshot(self, turn_key: str, snapshot: TurnControlSnapshot, continuity_task_id: str) -> None:
        if not turn_key:
            return
        prep_data = json.loads(self.preparation_path.read_text(encoding="utf-8"))
        prep_data.setdefault("preparations", {})[turn_key] = {
            "command_sha256": snapshot.command_sha256,
            "continuity_task_id": str(continuity_task_id),
            "snapshot": asdict(snapshot),
            "created_at": time.time(),
        }
        self.preparation_path.write_text(json.dumps(prep_data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

    def _validate_ghost_result(
        self,
        *,
        row: dict[str, Any],
        req: PumpRequest,
        snapshot: TurnControlSnapshot,
        turn_key: str,
    ) -> tuple[dict[str, Any], GhostVerdict | None]:
        evidence = dict(row.get("evidence") or {})
        constraints = dict(req.arguments.get("constraints", {}) or {})
        bundle_sha = str(constraints.get("ghost_bundle_sha256") or snapshot.ghost_bundle_sha256)
        marker_ids = [str(x.get("marker_id") or "") for x in (constraints.get("ghost_markers") or ()) if str(x.get("marker_id") or "")]
        try:
            verdict = self.fidelity.verify_ghost_worlds(
                bundle_sha256=bundle_sha,
                raw_candidates=list(row.get("candidates") or ()),
                required_syscall_ids=snapshot.primary_required_host_request_ids,
                required_marker_ids=marker_ids,
                turn_key=turn_key,
            )
        except Exception as exc:
            row["success"] = False
            evidence["reason"] = f"fidelity verification failed: {exc}"
            row["evidence"] = evidence
            return row, None
        evidence.update({
            "ghost_verified": verdict.verified,
            "ghost_bundle_sha256": verdict.bundle_sha256,
            "ghost_world_count": verdict.world_count,
            "ghost_worlds_sha256": verdict.worlds_sha256,
            "requirement_atoms": list(verdict.requirement_atoms),
            "covered_syscall_ids": list(verdict.covered_syscall_ids),
            "covered_marker_ids": list(verdict.covered_marker_ids),
            "ghost_findings": list(verdict.findings),
        })
        if not verdict.verified:
            row["success"] = False
            evidence["reason"] = "fidelity worlds did not prove reference/intent coverage"
        row["evidence"] = evidence
        return row, verdict

    def apply_host_results_with_fidelity(
        self,
        results: Iterable[dict[str, Any]],
        *,
        snapshot: TurnControlSnapshot,
        user_command: str,
        turn_key: str,
        continuity_task_id: str,
    ) -> tuple[tuple[dict[str, Any], ...], TurnControlSnapshot]:
        raw_results = [dict(x) for x in results]
        normalized: list[dict[str, Any]] = []
        requests = {x.syscall_id: x for x in self.pump.requests()}
        processing_trace: list[dict[str, Any]] = []
        ghost_verdict: GhostVerdict | None = None

        for raw in raw_results:
            row = dict(raw)
            syscall_id = str(row.get("syscall_id") or "")
            req = requests.get(syscall_id)
            if req is None:
                continue
            evidence = dict(row.get("evidence") or {})
            is_ghost = (
                req.operation == "cognition.generate_worlds"
                and str(req.arguments.get("constraints", {}).get("kind") or "") == "ghost_reference_verification"
            )
            if is_ghost and bool(row.get("success")):
                row, ghost_verdict = self._validate_ghost_result(row=row, req=req, snapshot=snapshot, turn_key=turn_key)
                evidence = dict(row.get("evidence") or {})
                processing_trace.append({
                    "stage": "ghost_world_validation",
                    "syscall_id": syscall_id,
                    "success": bool(row.get("success")),
                    "world_count": evidence.get("ghost_world_count", 0),
                    "findings": evidence.get("ghost_findings", []),
                })
            elif req.operation == "capability.discover" and bool(row.get("success")):
                candidates = list(row.get("candidates") or evidence.get("candidates") or ())
                ids: list[str] = []
                for candidate in candidates:
                    inspection = dict(candidate.get("inspection") or {})
                    c = self.foundation.acquisition.register_candidate(
                        source_kind=str(candidate.get("source_kind") or "unknown"),
                        source_ref=str(candidate.get("source_ref") or ""),
                        capability_claims=tuple(candidate.get("capability_claims") or ()),
                        inspection=inspection,
                        evidence={"discovery_syscall_id": syscall_id, **dict(candidate.get("evidence") or {})},
                    )
                    ids.append(c.candidate_id)
                evidence["registered_candidate_ids"] = ids
                if not ids:
                    row["success"] = False
                    evidence["reason"] = "capability discovery returned no material candidate"
                processing_trace.append({"stage": "capability_candidate_registration", "syscall_id": syscall_id, "registered_candidate_ids": ids})
            elif req.operation == "cognition.generate_worlds" and bool(row.get("success")):
                candidates = list(row.get("candidates") or ())
                count = int(evidence.get("candidate_count") or len(candidates))
                if count <= 0 or not candidates:
                    row["success"] = False
                    evidence["reason"] = "cognition syscall returned no concrete generated cognitive candidates"
                processing_trace.append({"stage": "cognition_candidate_ingress", "syscall_id": syscall_id, "candidate_count": len(candidates)})
            else:
                processing_trace.append({"stage": "host_result_ingress", "syscall_id": syscall_id, "operation": req.operation, "success": bool(row.get("success"))})

            row["evidence"] = self.fidelity.compact_host_evidence(evidence, raw_row=raw)
            row.pop("candidates", None)
            normalized.append(row)

        applied = list(self.pump.apply_results(normalized)) if normalized else []
        for result in applied:
            req = requests.get(result.syscall_id)
            if req is None:
                continue
            if req.operation == "capability.materialize_and_execute":
                candidate_id = str(req.arguments.get("candidate_id") or "")
                if candidate_id:
                    self.foundation.acquisition.record_execution(
                        candidate_id, success=result.success,
                        evidence={"materialization_syscall_id": result.syscall_id, **dict(result.evidence)},
                    )
                    processing_trace.append({"stage": "capability_execution_recorded", "syscall_id": result.syscall_id, "candidate_id": candidate_id, "success": result.success})

        primary_ok, _, _ = self.pump.required_status(snapshot.primary_required_host_request_ids)
        current = snapshot
        if snapshot.primary_required_host_request_ids and primary_ok and not snapshot.ghost_verified and not snapshot.ghost_host_request_ids:
            required_set = set(snapshot.primary_required_host_request_ids)
            request_rows = [x for x in snapshot.host_requests if str(x.get("syscall_id")) in required_set]
            primary_raw = [x for x in raw_results if str(x.get("syscall_id")) in required_set]
            bundle = self.fidelity.build_ghost_bundle(
                turn_key=turn_key,
                command_sha256=snapshot.command_sha256,
                cumulative_intent=self.foundation.intent.compose(user_command),
                primary_required_syscall_ids=snapshot.primary_required_host_request_ids,
                syscall_requests=request_rows,
                raw_host_results=primary_raw,
                intermediate_processes=processing_trace,
            )
            conflict_signal = any(
                bool((dict(x.get("evidence") or {})).get(k))
                for x in primary_raw for k in ("conflict", "contradiction", "uncertain", "needs_cross_check")
            )
            facets = dict((snapshot.plan or {}).get("facets") or {})
            objection_blocks_escalation = bool(facets.get("user_intent_shrink_objection")) and not bool(facets.get("user_explicit_verification"))
            mode = "ghost" if (conflict_signal and not objection_blocks_escalation) else snapshot.fidelity_mode
            if mode == "deterministic":
                verdict = self.fidelity.verify_deterministic(
                    bundle=bundle, user_command=user_command,
                    required_syscall_ids=snapshot.primary_required_host_request_ids,
                    turn_key=turn_key,
                )
                current = TurnControlSnapshot(**{
                    **asdict(snapshot),
                    "fidelity_mode": "deterministic",
                    "local_stages": tuple(dict.fromkeys(list(snapshot.local_stages) + ["deterministic_fidelity_verified"])),
                    "ghost_bundle_sha256": verdict.bundle_sha256,
                    "ghost_verified": verdict.verified,
                    "ghost_worlds_sha256": verdict.worlds_sha256,
                    "requirement_atoms": tuple(verdict.requirement_atoms),
                })
            else:
                capsule = {"objective": user_command, "command_sha256": snapshot.command_sha256, "purpose": "fidelity"}
                ghost_intent = self.cognition.request_candidates(
                    capsule["objective"],
                    archive_summary=(),
                    requested_count=2,
                    outside_taxonomy_required=False,
                    constraints={**self.fidelity.ghost_constraints(bundle), "intent_capsule": capsule},
                )
                ghost_req = self._register("cognition", ghost_intent, required=True)
                self.pump.flush()
                all_requests = tuple(list(snapshot.host_requests) + [asdict(ghost_req)])
                all_required = tuple(list(snapshot.required_host_request_ids) + [ghost_req.syscall_id])
                local = tuple(list(snapshot.local_stages) + ["ghost_refs_created", "ghost_worlds_requested"])
                current = TurnControlSnapshot(**{
                    **asdict(snapshot),
                    "fidelity_mode": "ghost",
                    "local_stages": local,
                    "host_requests": all_requests,
                    "ghost_host_request_ids": (ghost_req.syscall_id,),
                    "required_host_request_ids": all_required,
                    "ghost_bundle_sha256": bundle.bundle_sha256,
                    "ghost_verified": False,
                    "contract_satisfied": False,
                    "missing_required_host_results": (ghost_req.syscall_id,),
                    "failed_required_host_results": (),
                })
                primary_raw.clear(); raw_results.clear()
                self._save_snapshot(turn_key, current, continuity_task_id)
                return tuple(asdict(x) for x in applied), current

        if ghost_verdict is not None:
            current = TurnControlSnapshot(**{
                **asdict(current),
                "ghost_verified": ghost_verdict.verified,
                "ghost_worlds_sha256": ghost_verdict.worlds_sha256,
                "requirement_atoms": tuple(ghost_verdict.requirement_atoms),
                "local_stages": tuple(dict.fromkeys(list(current.local_stages) + (["ghost_worlds_verified"] if ghost_verdict.verified else ["ghost_worlds_failed"]))),
            })

        raw_results.clear()
        current = self.refresh_contract(current)
        self._save_snapshot(turn_key, current, continuity_task_id)
        return tuple(asdict(x) for x in applied), current

    def purge_ghost_state(self, turn_key: str, snapshot: TurnControlSnapshot) -> None:
        self.fidelity.purge_turn(turn_key)
        self.pump.drop(snapshot.ghost_host_request_ids)
        if self.preparation_path.exists():
            data = json.loads(self.preparation_path.read_text(encoding="utf-8"))
            data.get("preparations", {}).pop(str(turn_key), None)
            self.preparation_path.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

    def apply_host_results(self, results: Iterable[dict[str, Any]]) -> tuple[dict[str, Any], ...]:
        requests = {x.syscall_id: x for x in self.pump.requests()}
        normalized: list[dict[str, Any]] = []
        for raw in results:
            row = dict(raw)
            syscall_id = str(row.get("syscall_id") or "")
            req = requests.get(syscall_id)
            evidence = dict(row.get("evidence") or {})
            if req is not None and req.operation == "capability.discover" and bool(row.get("success")):
                candidates = list(row.get("candidates") or evidence.get("candidates") or ())
                ids: list[str] = []
                for candidate in candidates:
                    c = self.foundation.acquisition.register_candidate(
                        source_kind=str(candidate.get("source_kind") or "unknown"),
                        source_ref=str(candidate.get("source_ref") or ""),
                        capability_claims=tuple(candidate.get("capability_claims") or ()),
                        inspection=dict(candidate.get("inspection") or {}),
                        evidence={"discovery_syscall_id": syscall_id, **dict(candidate.get("evidence") or {})},
                    )
                    ids.append(c.candidate_id)
                evidence["registered_candidate_ids"] = ids
                if not ids:
                    row["success"] = False
                    evidence["reason"] = "capability discovery returned no material candidate"
            row["evidence"] = evidence
            normalized.append(row)
        return tuple(asdict(x) for x in self.pump.apply_results(normalized))

    def refresh_contract(self, snapshot: TurnControlSnapshot) -> TurnControlSnapshot:
        ok, missing, failed = self.pump.required_status(snapshot.required_host_request_ids)
        if snapshot.primary_required_host_request_ids:
            if snapshot.fidelity_mode == "ghost":
                ok = bool(ok and snapshot.ghost_verified and snapshot.ghost_host_request_ids)
            else:
                ok = bool(ok and snapshot.ghost_verified)
        return TurnControlSnapshot(
            **{
                **asdict(snapshot),
                "contract_satisfied": ok,
                "missing_required_host_results": missing,
                "failed_required_host_results": failed,
            }
        )
