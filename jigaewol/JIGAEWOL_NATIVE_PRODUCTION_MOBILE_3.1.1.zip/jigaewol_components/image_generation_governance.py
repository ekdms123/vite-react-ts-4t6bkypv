from __future__ import annotations

"""Source-bound decision contract for image generation/editing.

The ZIP decides *whether* the current exact user directive asks for an image actuator,
which source requirements it serves, and what continuity/evidence must survive the host
call.  It never equates a plan with execution; the native/connected image tool still has
to return an observed result receipt.
"""

import hashlib
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .image_quality_governor import ImageQualityGovernor
from .image_sovereignty import ImageSovereigntyPolicy


_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".heic", ".heif", ".bmp"}
_VISUAL = re.compile(r"(?:이미지|그림|사진|일러스트|포스터|로고|다이어그램|image|picture|photo|illustration|poster|logo|diagram)", re.I)
_GENERATE = re.compile(
    r"(?:그려\s*줘|그려줘|그려\s*주세요|만들어\s*줘|만들어줘|생성해\s*줘|생성해줘|렌더(?:링)?해\s*줘|렌더(?:링)?해줘|시각화해\s*줘|시각화해줘|"
    r"(?:generate|create|draw|render|visualize)\b[^.?!\n]{0,48}(?:image|picture|illustration|poster|logo|diagram)|"
    r"(?:image|picture|illustration|poster|logo|diagram)[^.?!\n]{0,48}\b(?:generate|create|draw|render|visualize))",
    re.I,
)
_EDIT_CONTEXT = re.compile(r"(?:이\s*(?:사진|이미지|그림)|첨부(?:한)?\s*(?:사진|이미지|그림)|(?:this|attached)\s+(?:photo|image|picture))", re.I)
_EDIT = re.compile(r"(?:지워\s*줘|지워줘|제거해\s*줘|제거해줘|추가해\s*줘|추가해줘|바꿔\s*줘|바꿔줘|수정해\s*줘|수정해줘|편집해\s*줘|편집해줘|복원해\s*줘|복원해줘|업스케일|리터치|(?:edit|remove|add|replace|retouch|restore|upscale)\b)", re.I)
_META = re.compile(r"(?:도구|툴|tool|zip|runtime|런타임|관리|판단|정책|라우팅|연결|설정|govern|manage|policy|routing|decision)", re.I)


def _sha(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def _attachment_rows(values: Iterable[Any]) -> tuple[dict[str, Any], ...]:
    rows: list[dict[str, Any]] = []
    for raw in values or ():
        if isinstance(raw, Mapping):
            ref = str(raw.get("ref") or raw.get("path") or raw.get("name") or "")
            name = str(raw.get("name") or Path(ref).name)
            exists = bool(raw.get("exists")) or (bool(ref) and Path(ref).is_file())
        else:
            ref = str(raw)
            name = Path(ref).name
            exists = Path(ref).is_file()
        suffix = Path(name or ref).suffix.casefold()
        if suffix in _IMAGE_EXT:
            rows.append({"ref": ref, "name": name, "exists": exists})
    return tuple(rows)


@dataclass(frozen=True)
class ImageGenerationDecision:
    schema: str
    source_message_sha256: str
    governance_requested: bool
    should_invoke: bool
    mode: str
    requirement_ids: tuple[str, ...]
    prompt_source_text: str
    prompt_compilation_owner: str
    target_image_required: bool
    target_image_present: bool
    awaiting_target: bool
    target_refs: tuple[str, ...]
    style_capsule_id: str
    preferred_executors: tuple[str, ...]
    preserve_exact_user_constraints: bool
    host_result_receipt_required: bool
    reobserve_generated_output: bool
    tool_execution_implied: bool
    quality_contract: dict[str, Any]
    sovereignty_contract: dict[str, Any]
    render_directive: dict[str, Any]
    max_quality_iterations: int

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class ImageGenerationGovernance:
    SCHEMA = "jigaewol_image_generation_governance_v1"

    @classmethod
    def compile(
        cls,
        command: str,
        *,
        requirements: Iterable[Mapping[str, Any]] = (),
        attachments: Iterable[Any] = (),
        style_capsule_id: str = "",
    ) -> ImageGenerationDecision:
        text = str(command)
        visual = bool(_VISUAL.search(text))
        edit_requested = bool(_EDIT_CONTEXT.search(text) and _EDIT.search(text))
        generate_requested = bool(visual and _GENERATE.search(text))
        # A request to control/govern the image tool is configuration work, not an
        # instruction to emit an image in that same turn unless a separate direct
        # generation/edit speech act is present.
        governance_requested = bool(visual and _META.search(text) and not (edit_requested or generate_requested))

        image_attachments = _attachment_rows(attachments)
        target_present = any(row["exists"] for row in image_attachments)
        target_required = bool(edit_requested)
        awaiting_target = bool(edit_requested and not target_present)
        should_invoke = bool(generate_requested or (edit_requested and target_present))
        mode = "edit" if edit_requested else ("generate" if generate_requested else ("configure" if governance_requested else "none"))

        requirement_ids: list[str] = []
        selected_texts: list[str] = []
        for row in requirements or ():
            if not isinstance(row, Mapping):
                continue
            atom_text = str(row.get("text") or "")
            kind = str(row.get("kind") or "")
            if kind != "action":
                continue
            atom_visual = bool(_VISUAL.search(atom_text))
            atom_direct = bool((_GENERATE.search(atom_text) and atom_visual) or (_EDIT_CONTEXT.search(atom_text) and _EDIT.search(atom_text)))
            if atom_direct:
                rid = str(row.get("atom_id") or "")
                if rid:
                    requirement_ids.append(rid)
                selected_texts.append(atom_text)
        # Prompt provenance stays the exact current user source. Requirement ids are
        # used for coverage/evidence binding, not for reconstructing or normalizing
        # the user's prompt text.
        prompt_source = text if should_invoke else ""

        quality_contract = ImageQualityGovernor.compile_contract(text if should_invoke else "")
        sovereignty_contract = ImageSovereigntyPolicy.compile(
            text, mode=mode, should_invoke=should_invoke, governance_requested=governance_requested
        )
        render_directive = ImageQualityGovernor.compile_render_directive(
            quality_contract, image_sovereignty_token=str(sovereignty_contract["authority_token"])
        )
        return ImageGenerationDecision(
            schema=cls.SCHEMA,
            source_message_sha256=_sha(text),
            governance_requested=governance_requested,
            should_invoke=should_invoke,
            mode=mode,
            requirement_ids=tuple(dict.fromkeys(requirement_ids)),
            prompt_source_text=prompt_source,
            prompt_compilation_owner="JIGAEWOL",
            target_image_required=target_required,
            target_image_present=target_present,
            awaiting_target=awaiting_target,
            target_refs=tuple(row["ref"] for row in image_attachments),
            style_capsule_id=str(style_capsule_id or ""),
            preferred_executors=("image_gen", "Higgsfield", "Canva"),
            preserve_exact_user_constraints=True,
            host_result_receipt_required=True,
            reobserve_generated_output=True,
            tool_execution_implied=False,
            quality_contract=quality_contract,
            sovereignty_contract=sovereignty_contract,
            render_directive=render_directive,
            max_quality_iterations=5,
        )
