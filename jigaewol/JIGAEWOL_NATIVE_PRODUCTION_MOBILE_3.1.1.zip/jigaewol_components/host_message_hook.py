from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any
from .runtime_home import resolve_chat_runtime_home

HOOK_SCHEMA = "jigaewol_host_message_hook_v1"
CHATGPT_HOST_KIND = "chatgpt"
LOCAL_HOST_KIND = "local_python"


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, sort_keys=True, indent=2)
            fh.write("\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    with path.open("a", encoding="utf-8") as fh:
        fh.write(line)
        fh.flush()
        os.fsync(fh.fileno())


def installation_path(state_root: str | Path) -> Path:
    return Path(state_root).expanduser().resolve() / "host_hook" / "installation.json"


def dispatch_ledger_path(state_root: str | Path) -> Path:
    return Path(state_root).expanduser().resolve() / "host_hook" / "dispatches.jsonl"


def failure_ledger_path(state_root: str | Path) -> Path:
    return Path(state_root).expanduser().resolve() / "failure_truth.jsonl"


def install_host_hook_adapter(
    *,
    runtime_root: str | Path,
    state_root: str | Path,
    host_kind: str = LOCAL_HOST_KIND,
    adapter_id: str = "jigaewol.local_host_adapter",
    host_observations: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    runtime_root = Path(runtime_root).expanduser().resolve()
    state_root = Path(state_root).expanduser().resolve()
    gateway = runtime_root / "tools" / "jigaewol_gateway.py"
    if not gateway.is_file():
        raise FileNotFoundError(f"gateway entrypoint missing: {gateway}")
    host_kind = str(host_kind or "").strip() or LOCAL_HOST_KIND
    now = time.time()
    base = {
        "schema": HOOK_SCHEMA,
        "host_kind": host_kind,
        "adapter_id": str(adapter_id),
        "runtime_root": str(runtime_root),
        "state_root": str(state_root),
        "gateway_entrypoint": "tools/jigaewol_gateway.py::main",
        "gateway_script": str(gateway),
        "installed_at_unix": now,
        "adapter_ready": True,
        "host_bound": False,
        "automatic_every_turn_proven": False,
        "host_observations": list(host_observations or []),
        "adapter_candidates": [
            {"route": "current_host_model_tool_continuation", "state": "ready_when_host_invokes_gateway",
             "requires_new_model_api": False, "user_terminal_required": False},
            {"route": "host_python_sandbox", "state": "requires_current_host_execution_observation"},
            {"route": "connected_remote_executor", "state": "requires_connected_device_observation"},
            {"route": "platform_message_event", "state": "requires_actual_registration_and_following_event"},
        ],
    }
    if host_kind == CHATGPT_HOST_KIND:
        row = {
            **base,
            "installation_state": "host_native_continuation_ready",
            "adapter_ready": True,
            "host_bound": False,
            "automatic_every_turn_proven": False,
            "binding_state": "native_tool_return_route_available_to_current_host",
            "platform_event_state": "awaiting_observed_registration_and_event",
            "next_action": "return canonical exact-source payload to the current host model and ingest its outgoing response",
        }
        attempt_path = state_root / "host_hook" / "attempts" / f"{CHATGPT_HOST_KIND}.json"
        _atomic_write_json(attempt_path, row)
        _atomic_write_json(installation_path(state_root), row)
        return row
    row = {
        **base,
        "installation_state": "local_adapter_installed_unbound",
        "host_bound": False,
        "automatic_every_turn_proven": False,
        "proof_scope": "adapter installation only; each exact dispatch is separately observable",
    }
    _atomic_write_json(installation_path(state_root), row)
    return row


def load_installation(state_root: str | Path) -> dict[str, Any]:
    path = installation_path(state_root)
    if not path.is_file():
        return {}
    try:
        row = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return row if isinstance(row, dict) else {}


def build_gateway_command(
    *,
    runtime_root: str | Path,
    state_root: str | Path,
    message_file: str | Path,
    user: str,
    project: str,
    session: str,
    capabilities_json: str | None = None,
) -> list[str]:
    runtime_root = Path(runtime_root).expanduser().resolve()
    cmd = [
        sys.executable,
        str(runtime_root / "tools" / "jigaewol_gateway.py"),
        "--root", str(Path(state_root).expanduser().resolve()),
        "--user", str(user),
        "--project", str(project),
        "--session", str(session),
        "--message-file", str(Path(message_file).expanduser().resolve()),
        "--quiet-trace",
        "--output-profile", "full",
        "--execution-mode", "inprocess",
    ]
    if capabilities_json:
        cmd.extend(["--capabilities-json", str(capabilities_json)])
    return cmd


def dispatch_exact_message(
    *,
    runtime_root: str | Path,
    state_root: str | Path,
    message: str,
    user: str,
    project: str,
    session: str,
    host_event_id: str = "",
    capabilities_json: str | None = None,
    timeout_seconds: float = 180.0,
) -> dict[str, Any]:
    if not isinstance(message, str) or not message:
        raise ValueError("message must be non-empty text")
    runtime_root = Path(runtime_root).expanduser().resolve()
    state_root = Path(state_root).expanduser().resolve()
    state_root.mkdir(parents=True, exist_ok=True)
    installation = load_installation(state_root)
    if not installation.get("adapter_ready"):
        raise RuntimeError("host message hook adapter is not installed")
    message_sha = hashlib.sha256(message.encode("utf-8")).hexdigest()
    hook_dir = state_root / "host_hook"
    hook_dir.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix="exact-message-", suffix=".txt", dir=str(hook_dir))
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(message.encode("utf-8"))
            fh.flush()
            os.fsync(fh.fileno())
        cmd = build_gateway_command(
            runtime_root=runtime_root,
            state_root=state_root,
            message_file=tmp_name,
            user=user,
            project=project,
            session=session,
            capabilities_json=capabilities_json,
        )
        started = time.time()
        proc = subprocess.run(
            cmd,
            cwd=str(runtime_root),
            text=True,
            capture_output=True,
            timeout=float(timeout_seconds),
            check=False,
            env={**os.environ,'JIGAEWOL_RUNTIME_HOME':str(resolve_chat_runtime_home(state_root).parent)},
        )
        record = {
            "schema": "jigaewol_host_hook_dispatch_v1",
            "time": time.time(),
            "started_at_unix": started,
            "host_event_id": str(host_event_id),
            "message_sha256": message_sha,
            "user": str(user),
            "project": str(project),
            "session": str(session),
            "gateway_entrypoint": "tools/jigaewol_gateway.py::main",
            "returncode": int(proc.returncode),
            "stdout_sha256": hashlib.sha256(proc.stdout.encode("utf-8")).hexdigest(),
            "stderr_sha256": hashlib.sha256(proc.stderr.encode("utf-8")).hexdigest(),
            "gateway_invoked": True,
            "gateway_completed": proc.returncode == 0,
            "host_dispatch_route": "exact_source_gateway_to_current_host_continuation",
            "independent_platform_message_event_registered": bool(installation.get("host_bound")),
        }
        _append_jsonl(dispatch_ledger_path(state_root), record)
        if proc.returncode != 0:
            _append_jsonl(failure_ledger_path(state_root), {
                "time": time.time(),
                "component": "host_message_hook",
                "event": "gateway_dispatch_failed",
                "message_sha256": message_sha,
                "returncode": proc.returncode,
                "stderr": proc.stderr,
            })
        return {**record, "stdout": proc.stdout, "stderr": proc.stderr}
    finally:
        Path(tmp_name).unlink(missing_ok=True)


def exact_message_dispatch_count(state_root: str | Path, message_sha256: str) -> int:
    path = dispatch_ledger_path(state_root)
    if not path.is_file():
        return 0
    count = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if str(row.get("message_sha256") or "") == str(message_sha256):
            count += 1
    return count
