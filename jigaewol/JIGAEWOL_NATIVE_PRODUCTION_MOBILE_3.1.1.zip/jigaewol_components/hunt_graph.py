from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class HuntNode:
    node_id: str
    kind: str
    key: str
    score: float
    state: str
    metadata: dict[str, Any]
    updated_at: float


class HuntGraph:
    """Persistent recursive discovery graph for creator/community/search traversal.

    Blocked lanes remain live debt, but they no longer starve executable frontier nodes.
    The frontier interleaves actionable discoveries with blocked debt so a private feed or
    unavailable source stays remembered without monopolizing every next search round.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "hunt_graph.json"
        if not self.path.exists():
            self.path.write_text(json.dumps({"nodes": {}, "edges": []}, indent=2), encoding="utf-8")

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _id(kind: str, key: str) -> str:
        return "hunt_" + hashlib.sha256(f"{kind}\0{key}".encode()).hexdigest()[:20]

    def observe(
        self,
        *,
        kind: str,
        key: str,
        novelty: float = .5,
        recency: float = .5,
        signal: float = .5,
        blocked: bool = False,
        metadata: dict[str, Any] | None = None,
    ) -> HuntNode:
        nid = self._id(str(kind), str(key))
        data = self._read()
        now = time.time()
        old = dict(data["nodes"].get(nid) or {})
        score = max(0.0, min(1.0, 0.40 * float(novelty) + 0.35 * float(signal) + 0.25 * float(recency)))
        state = "blocked_open_debt" if blocked else "open"
        row = {
            "node_id": nid,
            "kind": str(kind),
            "key": str(key),
            "score": score,
            "state": state,
            "metadata": {**dict(old.get("metadata") or {}), **dict(metadata or {})},
            "updated_at": now,
        }
        data["nodes"][nid] = row
        self._write(data)
        return HuntNode(**row)

    def link(self, source_id: str, relation: str, target_id: str, *, evidence_ref: str = "") -> None:
        data = self._read()
        edge = {"source": str(source_id), "relation": str(relation), "target": str(target_id), "evidence_ref": str(evidence_ref)}
        key = json.dumps(edge, sort_keys=True, ensure_ascii=False)
        if key not in {json.dumps(x, sort_keys=True, ensure_ascii=False) for x in data["edges"]}:
            data["edges"].append(edge)
            self._write(data)

    def actionable_frontier(self, limit: int | None = None) -> tuple[HuntNode, ...]:
        rows = [HuntNode(**x) for x in self._read()["nodes"].values() if x.get("state") == "open"]
        rows.sort(key=lambda x: (-x.score, -x.updated_at))
        return tuple(rows if limit is None else rows[:max(1, int(limit))])

    def blocked_debt(self, limit: int | None = None) -> tuple[HuntNode, ...]:
        rows = [HuntNode(**x) for x in self._read()["nodes"].values() if x.get("state") == "blocked_open_debt"]
        rows.sort(key=lambda x: (-x.score, -x.updated_at))
        return tuple(rows if limit is None else rows[:max(1, int(limit))])

    def frontier(self, limit: int | None = None, *, blocked_every: int = 4) -> tuple[HuntNode, ...]:
        """Interleave runnable discoveries with blocked-open debt.

        ``blocked_every=4`` means up to three actionable nodes then one blocked debt node.
        If only one class exists it is returned normally. This preserves blocked lanes
        without making an inaccessible source the permanent top priority.
        """
        open_rows = list(self.actionable_frontier(None))
        blocked_rows = list(self.blocked_debt(None))
        n = max(1, int(limit)) if limit is not None else len(open_rows) + len(blocked_rows)
        if n <= 0:
            return ()
        if not open_rows:
            return tuple(blocked_rows[:n])
        if not blocked_rows:
            return tuple(open_rows[:n])
        stride = max(2, int(blocked_every))
        out: list[HuntNode] = []
        oi = bi = 0
        while len(out) < n and (oi < len(open_rows) or bi < len(blocked_rows)):
            for _ in range(stride - 1):
                if oi < len(open_rows) and len(out) < n:
                    out.append(open_rows[oi]); oi += 1
            if bi < len(blocked_rows) and len(out) < n:
                out.append(blocked_rows[bi]); bi += 1
            if oi >= len(open_rows) and bi < len(blocked_rows):
                out.extend(blocked_rows[bi:n-len(out)+bi]); break
            if bi >= len(blocked_rows) and oi < len(open_rows):
                out.extend(open_rows[oi:n-len(out)+oi]); break
        return tuple(out[:n])

    @staticmethod
    def native_query_seeds(topic: str) -> tuple[str, ...]:
        t = str(topic).strip()
        return tuple(dict.fromkeys([
            t,
            f'"{t}" underrated',
            f'"{t}" nobody is talking about',
            f'"{t}" holy shit this works',
            f'"{t}" prompt dump',
            f'"{t}" drop your stack',
            f'"{t}" broken OR regression OR issue',
            f'"{t}" reddit OR hackernews OR discord OR forum',
            f'"{t}" 깃허브 후기',
            f'"{t}" 꿀팁 OR 삽질 OR 실사용',
        ]))

    def ingest_observation(
        self,
        *,
        source_family: str,
        items: Iterable[dict[str, Any]],
        evidence_ref: str = "",
    ) -> dict[str, int]:
        counts = {"result": 0, "creator": 0, "repo": 0, "term": 0, "edge": 0}
        for raw in items:
            item = dict(raw)
            url = str(item.get("url") or item.get("link") or "").strip()
            title = str(item.get("title") or item.get("name") or item.get("label") or url).strip()
            if not title:
                continue
            result = self.observe(
                kind="result",
                key=url or title,
                novelty=float(item.get("novelty", .55) or .55),
                recency=float(item.get("recency", .5) or .5),
                signal=float(item.get("signal", .55) or .55),
                metadata={
                    "source_family": str(source_family), "title": title,
                    "url": url, "evidence_ref": str(evidence_ref),
                },
            )
            counts["result"] += 1
            creators: list[str] = []
            for key in ("creator", "author", "handle"):
                value = str(item.get(key) or "").strip()
                if value and value not in creators:
                    creators.append(value)
            for value in creators:
                node = self.observe(kind="creator", key=value, novelty=.65, signal=.65, metadata={"source_family": source_family})
                self.link(result.node_id, "created_by", node.node_id, evidence_ref=evidence_ref)
                counts["creator"] += 1; counts["edge"] += 1
            repo = str(item.get("repo") or item.get("repository") or "").strip()
            if repo:
                node = self.observe(kind="repo", key=repo, novelty=.7, signal=.7, metadata={"source_family": source_family})
                self.link(result.node_id, "points_to_repo", node.node_id, evidence_ref=evidence_ref)
                counts["repo"] += 1; counts["edge"] += 1
            term_values: list[str] = []
            for key in ("novel_terms", "terms", "slang", "tags", "entities"):
                value = item.get(key)
                if isinstance(value, (list, tuple, set)):
                    term_values.extend(str(x).strip() for x in value)
                elif value:
                    term_values.append(str(value).strip())
            for term in dict.fromkeys(x for x in term_values if x):
                node = self.observe(kind="term", key=term, novelty=.75, signal=.55, metadata={"source_family": source_family})
                self.link(result.node_id, "revealed_term", node.node_id, evidence_ref=evidence_ref)
                counts["term"] += 1; counts["edge"] += 1
        return counts
