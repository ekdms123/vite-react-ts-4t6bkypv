from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class LatentOpcode:
    opcode_id: str
    effect: str
    required_traits: tuple[str, ...]
    state: str
    created_at: float
    updated_at: float
    materializers: tuple[dict[str, Any], ...] = ()
    evidence_refs: tuple[str, ...] = ()
    progress: tuple[dict[str, Any], ...] = ()
    failure_truth: tuple[dict[str, Any], ...] = ()


class UnwrittenMachine:
    """Keep missing capabilities as live instructions instead of collapsing them to 'can't'."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "latent_opcodes.json"
        if not self.path.exists():
            self.path.write_text(json.dumps({"schema":"latent_opcode_registry_v1","opcodes":{}}, indent=2), encoding="utf-8")

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _id(effect: str, traits: Iterable[str]) -> str:
        raw = json.dumps([effect, sorted(set(map(str, traits)))], ensure_ascii=False).encode()
        return "opcode_" + hashlib.sha256(raw).hexdigest()[:20]

    def declare(self, effect: str, *, required_traits: Iterable[str] = (), materializers: Iterable[dict[str, Any]] = ()) -> LatentOpcode:
        traits = tuple(sorted(set(map(str, required_traits))))
        oid = self._id(str(effect), traits)
        now = time.time(); data = self._read(); old = dict(data["opcodes"].get(oid) or {})
        mats = tuple(dict(x) for x in materializers)
        if old:
            merged = list(old.get("materializers") or [])
            seen = {json.dumps(x, sort_keys=True, ensure_ascii=False) for x in merged}
            for m in mats:
                key = json.dumps(m, sort_keys=True, ensure_ascii=False)
                if key not in seen:
                    merged.append(m); seen.add(key)
            row = {
                **old, "state": old.get("state") or "unmaterialized", "updated_at": now,
                "materializers": merged,
            }
        else:
            row = asdict(LatentOpcode(oid, str(effect), traits, "unmaterialized", now, now, mats))
        data["opcodes"][oid] = row; self._write(data)
        return self.get(oid)

    def get(self, opcode_id: str) -> LatentOpcode:
        raw = dict(self._read()["opcodes"][str(opcode_id)])
        raw["required_traits"] = tuple(raw.get("required_traits") or ())
        raw["materializers"] = tuple(dict(x) for x in (raw.get("materializers") or ()))
        raw["evidence_refs"] = tuple(raw.get("evidence_refs") or ())
        raw["failure_truth"] = tuple(dict(x) for x in (raw.get("failure_truth") or ()))
        raw["progress"] = tuple(dict(x) for x in (raw.get("progress") or ()))
        return LatentOpcode(**raw)

    def record_failure(self, opcode_id: str, *, stage: str, error: str, evidence_ref: str = "") -> LatentOpcode:
        data = self._read(); row = dict(data["opcodes"][str(opcode_id)])
        failures = list(row.get("failure_truth") or [])
        failures.append({"stage":str(stage),"error":str(error),"evidence_ref":str(evidence_ref),"at":time.time()})
        row.update({"state":"blocked_open","failure_truth":failures,"updated_at":time.time()})
        data["opcodes"][str(opcode_id)] = row; self._write(data); return self.get(opcode_id)

    def record_progress(
        self, opcode_id: str, *, evidence_refs: Iterable[str], delivered_traits: Iterable[str] = (),
        note: str = "", source_ref: str = ""
    ) -> LatentOpcode:
        """Attach observed progress without falsely closing a broad user requirement.

        Partial materialization remains open work. Evidence is monotonic and repeated
        receipts are deduplicated by their stable content fields.
        """
        refs = tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x)))
        if not refs:
            raise ValueError("progress requires observed evidence")
        data = self._read(); row = dict(data["opcodes"][str(opcode_id)])
        if str(row.get("state") or "") == "materialized":
            return self.get(opcode_id)
        traits = tuple(sorted(set(str(x) for x in delivered_traits if str(x))))
        event = {
            "evidence_refs": list(refs), "delivered_traits": list(traits),
            "note": str(note), "source_ref": str(source_ref), "at": time.time(),
        }
        progress = list(row.get("progress") or [])
        stable = json.dumps({k:event[k] for k in ("evidence_refs","delivered_traits","note","source_ref")}, ensure_ascii=False, sort_keys=True)
        if all(json.dumps({k:x.get(k) for k in ("evidence_refs","delivered_traits","note","source_ref")}, ensure_ascii=False, sort_keys=True) != stable for x in progress):
            progress.append(event)
        merged_refs = list(dict.fromkeys([*(row.get("evidence_refs") or []), *refs]))
        row.update({
            "state": "partially_materialized", "evidence_refs": merged_refs,
            "progress": progress, "updated_at": time.time(),
        })
        data["opcodes"][str(opcode_id)] = row; self._write(data); return self.get(opcode_id)

    def promote(self, opcode_id: str, *, evidence_refs: Iterable[str]) -> LatentOpcode:
        refs = tuple(dict.fromkeys(map(str, evidence_refs)))
        if not refs:
            raise ValueError("promotion requires observed evidence")
        data = self._read(); row = dict(data["opcodes"][str(opcode_id)])
        row.update({"state":"materialized","evidence_refs":list(refs),"updated_at":time.time()})
        data["opcodes"][str(opcode_id)] = row; self._write(data); return self.get(opcode_id)

    def open(self) -> tuple[LatentOpcode, ...]:
        return tuple(self.get(k) for k, v in self._read()["opcodes"].items() if v.get("state") != "materialized")
