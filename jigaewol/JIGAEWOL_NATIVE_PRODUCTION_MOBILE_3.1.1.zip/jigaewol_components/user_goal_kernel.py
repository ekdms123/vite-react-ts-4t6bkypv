from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .source_segmentation import trimmed_source_spans


def _sha(value: str | bytes) -> str:
    raw = value if isinstance(value, bytes) else str(value).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class SourceSpan:
    start: int
    end: int
    text: str


@dataclass(frozen=True)
class GoalInterpretation:
    interpretation_id: str
    source_span: SourceSpan
    interpretation: str
    confidence: float
    derived_from: tuple[str, ...]
    requirement_ref: str = ""


@dataclass(frozen=True)
class GoalEvent:
    event_id: str
    raw_text: str
    raw_sha256: str
    raw_bytes_sha256: str
    interpretations: tuple[GoalInterpretation, ...]
    created_at: float
    correction_of: str = ""

    def as_mapping(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "interpretations": tuple(asdict(x) for x in self.interpretations),
        }


@dataclass(frozen=True)
class GoalLossDiff:
    source_requirement_refs: tuple[str, ...]
    projected_requirement_refs: tuple[str, ...]
    omitted_requirement_refs: tuple[str, ...]
    weakened_requirement_refs: tuple[str, ...]
    added_assumptions: tuple[str, ...]
    reordered_requirement_refs: tuple[str, ...]
    deferred_requirement_refs: tuple[str, ...]
    repeated_approval_refs: tuple[str, ...]

    @property
    def loss_detected(self) -> bool:
        return any((
            self.omitted_requirement_refs,
            self.weakened_requirement_refs,
            self.added_assumptions,
            self.reordered_requirement_refs,
            self.deferred_requirement_refs,
            self.repeated_approval_refs,
        ))

    def as_mapping(self) -> dict[str, Any]:
        return {**asdict(self), "loss_detected": self.loss_detected}


class UserGoalKernel:
    """Preserves exact user-source text separately from mutable interpretation.

    It records what the user asked for, where it came from, and whether a downstream
    projection lost any requirement references.  User authorization events remain part
    of the goal contract and are carried into effect/body invocation receipts instead
    of being reinterpreted as a reason to shrink the requested goal.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.events_path = self.root / "events.jsonl"
        if not self.events_path.exists():
            self.events_path.write_text("", encoding="utf-8")

    @staticmethod
    def _spans(text: str) -> tuple[SourceSpan, ...]:
        exact = str(text)
        return tuple(
            SourceSpan(start=start, end=end, text=exact[start:end])
            for start, end in trimmed_source_spans(exact)
        )

    def ingest(
        self,
        raw_text: str,
        *,
        raw_bytes: bytes | None = None,
        requirement_atoms: Iterable[Mapping[str, Any]] = (),
        persist: bool = True,
    ) -> GoalEvent:
        text = str(raw_text)
        payload = raw_bytes if raw_bytes is not None else text.encode("utf-8")
        spans = self._spans(text)
        atoms = tuple(dict(x) for x in requirement_atoms)
        interpretations: list[GoalInterpretation] = []
        for idx, atom in enumerate(atoms):
            atom_text = str(atom.get("text") or "").strip()
            ref = str(atom.get("atom_id") or f"requirement:{idx}")
            if not atom_text:
                continue
            start = text.find(atom_text)
            span = SourceSpan(start, start + len(atom_text), atom_text) if start >= 0 else SourceSpan(0, len(text), text)
            iid = "interp_" + _sha(f"{_sha(payload)}|{ref}|{span.start}|{span.end}|{atom_text}")[:20]
            interpretations.append(GoalInterpretation(
                interpretation_id=iid,
                source_span=span,
                interpretation=atom_text,
                confidence=1.0 if start >= 0 else 0.72,
                derived_from=("exact_user_message", ref),
                requirement_ref=ref,
            ))
        if not interpretations:
            for idx, span in enumerate(spans):
                iid = "interp_" + _sha(f"{_sha(payload)}|span:{idx}|{span.start}|{span.end}|{span.text}")[:20]
                interpretations.append(GoalInterpretation(
                    interpretation_id=iid,
                    source_span=span,
                    interpretation=span.text,
                    confidence=0.7,
                    derived_from=("exact_user_message",),
                    requirement_ref=f"span:{idx}",
                ))
        event_id = "goal_" + _sha(f"{_sha(payload)}|{len(interpretations)}")[:20]
        event = GoalEvent(
            event_id=event_id,
            raw_text=text,
            raw_sha256=_sha(text),
            raw_bytes_sha256=_sha(payload),
            interpretations=tuple(interpretations),
            created_at=time.time(),
        )
        if persist:
            self._append(event.as_mapping())
        return event

    def apply_correction(
        self,
        raw_text: str,
        *,
        corrects_event_id: str,
        raw_bytes: bytes | None = None,
        requirement_atoms: Iterable[Mapping[str, Any]] = (),
    ) -> GoalEvent:
        base = self.ingest(raw_text, raw_bytes=raw_bytes, requirement_atoms=requirement_atoms, persist=False)
        corrected = GoalEvent(**{**base.__dict__, "correction_of": str(corrects_event_id)})
        self._append({**corrected.as_mapping(), "event_kind": "correction"})
        return corrected

    @staticmethod
    def diff_projection(
        source_requirement_refs: Iterable[str],
        projected_requirement_refs: Iterable[str],
        *,
        weakened_requirement_refs: Iterable[str] = (),
        added_assumptions: Iterable[str] = (),
        deferred_requirement_refs: Iterable[str] = (),
        repeated_approval_refs: Iterable[str] = (),
    ) -> GoalLossDiff:
        source = tuple(dict.fromkeys(str(x) for x in source_requirement_refs if str(x)))
        projected = tuple(dict.fromkeys(str(x) for x in projected_requirement_refs if str(x)))
        projected_set = set(projected)
        source_set = set(source)
        omitted = tuple(x for x in source if x not in projected_set)
        common_order = tuple(x for x in projected if x in source_set)
        expected_order = tuple(x for x in source if x in projected_set)
        reordered = common_order if common_order != expected_order else ()
        extra_projection_refs = tuple(x for x in projected if x not in source_set)
        auto_assumptions = tuple(f"projection_ref:{x}" for x in extra_projection_refs)
        return GoalLossDiff(
            source_requirement_refs=source,
            projected_requirement_refs=projected,
            omitted_requirement_refs=omitted,
            weakened_requirement_refs=tuple(dict.fromkeys(map(str, weakened_requirement_refs))),
            added_assumptions=tuple(dict.fromkeys((*auto_assumptions, *tuple(map(str, added_assumptions))))),
            reordered_requirement_refs=reordered,
            deferred_requirement_refs=tuple(dict.fromkeys(map(str, deferred_requirement_refs))),
            repeated_approval_refs=tuple(dict.fromkeys(map(str, repeated_approval_refs))),
        )


    @staticmethod
    def diff_projection_records(
        source_requirements: Iterable[Mapping[str, Any]],
        projected_nodes: Iterable[Mapping[str, Any]],
    ) -> GoalLossDiff:
        """Measure goal loss from exact requirement records to executable Work nodes."""
        source_rows = tuple(dict(x) for x in source_requirements)
        projected_rows = tuple(dict(x) for x in projected_nodes)
        source_refs = tuple(str(x.get("atom_id") or "") for x in source_rows if str(x.get("atom_id") or ""))
        projected_refs = tuple(
            str(ref) for node in projected_rows for ref in (node.get("goal_refs") or ()) if str(ref)
        )
        source_by_ref = {str(x.get("atom_id") or ""): x for x in source_rows}
        weakened: list[str] = []
        assumptions: list[str] = []
        deferred: list[str] = []
        approvals: list[str] = []
        projected_order: list[tuple[int, str]] = []
        for position, node in enumerate(projected_rows, start=1):
            effect = dict(node.get("effect_request") or {})
            state = str(node.get("state") or "ready")
            for ref0 in node.get("goal_refs") or ():
                ref = str(ref0)
                if not ref:
                    continue
                src = dict(source_by_ref.get(ref) or {})
                source_text = str(src.get("text") or "").strip()
                projected_text = str(effect.get("source_text") or "").strip()
                source_critical = bool(src.get("critical"))
                projected_critical = bool(effect.get("source_critical", source_critical))
                if source_text and projected_text and source_text != projected_text:
                    src_tokens = set(re.findall(r"[0-9A-Za-z가-힣_]+", source_text.casefold()))
                    proj_tokens = set(re.findall(r"[0-9A-Za-z가-힣_]+", projected_text.casefold()))
                    if proj_tokens < src_tokens or (source_critical and not projected_critical):
                        weakened.append(ref)
                elif source_critical and not projected_critical:
                    weakened.append(ref)
                for assumption in effect.get("assumptions") or ():
                    if str(assumption):
                        assumptions.append(str(assumption))
                if state in {"deferred", "parked"}:
                    deferred.append(ref)
                approval_ref = str(effect.get("approval_request_ref") or "")
                if approval_ref:
                    approvals.append(approval_ref)
                projected_order.append((int(effect.get("source_order") or position), ref))
        repeated = tuple(ref for ref in dict.fromkeys(approvals) if approvals.count(ref) > 1)
        # diff_projection computes omission, added projection refs and source order. The
        # projected ref sequence remains the actual Work ordering rather than a sorted
        # copy, so user-specified sequencing loss is observable.
        return UserGoalKernel.diff_projection(
            source_refs, projected_refs,
            weakened_requirement_refs=weakened,
            added_assumptions=assumptions,
            deferred_requirement_refs=deferred,
            repeated_approval_refs=repeated,
        )

    def latest_event(self) -> dict[str, Any] | None:
        if not self.events_path.exists():
            return None
        rows = [line for line in self.events_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if not rows:
            return None
        try:
            return json.loads(rows[-1])
        except (ValueError, TypeError, json.JSONDecodeError):
            return None

    def event(self, event_id: str) -> dict[str, Any] | None:
        target = str(event_id)
        if not target or not self.events_path.exists():
            return None
        for line in reversed(self.events_path.read_text(encoding="utf-8").splitlines()):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except (ValueError, TypeError, json.JSONDecodeError):
                continue
            if str(row.get("event_id") or "") == target:
                return row
        return None

    def _append(self, row: Mapping[str, Any]) -> None:
        with self.events_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n")
