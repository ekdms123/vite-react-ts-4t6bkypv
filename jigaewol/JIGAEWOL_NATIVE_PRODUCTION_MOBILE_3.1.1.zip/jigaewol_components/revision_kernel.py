from __future__ import annotations

import copy
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable

from .functional_self import CausalSelfLoop, FunctionalSelfModel, SelfModelStore
from .hot_swap import LoadedGeneration, SelfModifyingRuntime
from .paradigm_runtime import NeutralStateGraph, ParadigmCapsule, ParadigmInventor, ParadigmMetaRuntime, ParadigmResult
from .runtime_state import RuntimeSnapshot
from .work_capsule import WorkCapsule


class RevisionKernel:
    """Coordinator for live core rewrites, paradigm acquisition, and self-model continuity."""

    def __init__(self, root: Path, *, identity_id: str, objective: str) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.identity_id = identity_id
        self.objective = objective
        self.core = SelfModifyingRuntime(self.root / "core")
        self.paradigms = ParadigmMetaRuntime(self.root / "meta_runtime")
        self.neutral_state = NeutralStateGraph(facts={"objective": objective})
        self.self_store = SelfModelStore(self.root / "self_model.json", identity_id)
        self.capsule_path = self.root / "work_capsule.json"
        if not self.capsule_path.exists():
            WorkCapsule(identity_id, objective).save(self.capsule_path)

    def bootstrap_core(self, source: str, *, initial_state: dict[str, Any]) -> LoadedGeneration:
        generation = self.core.bootstrap(source, initial_state=initial_state)
        self.refresh_self_model()
        self.checkpoint_capsule()
        return generation

    def rewrite_core(
        self,
        source: str,
        *,
        trigger: str,
        expected_gain: str,
        shadow_payload: dict[str, Any] | None = None,
    ) -> LoadedGeneration:
        generation = self.core.rewrite(
            source,
            trigger=trigger,
            expected_gain=expected_gain,
            shadow_payload=shadow_payload,
        )
        self.refresh_self_model()
        self.checkpoint_capsule()
        return generation

    def core_step(self, payload: dict[str, Any] | None = None) -> RuntimeSnapshot:
        result = self.core.step(payload)
        self.neutral_state.facts["core_state"] = copy.deepcopy(result.payload)
        self.neutral_state.facts["runtime_generation"] = result.generation
        self.neutral_state.facts["state_version"] = result.version
        self.refresh_self_model()
        self.checkpoint_capsule()
        return result

    def install_paradigm(self, capsule: ParadigmCapsule) -> None:
        self.paradigms.install(capsule, neutral_state=self.neutral_state)
        self.refresh_self_model()
        self.checkpoint_capsule()

    def invent_and_install_paradigm(self, inventor: ParadigmInventor, hypothesis: str) -> ParadigmCapsule:
        capsule = inventor.invent(
            self.objective,
            hypothesis,
            tuple(self.paradigms.capsules.values()),
        )
        self.install_paradigm(capsule)
        return capsule

    def paradigm_step(self, paradigm_id: str, payload: dict[str, Any] | None = None) -> ParadigmResult:
        result = self.paradigms.step(paradigm_id, self.neutral_state, payload)
        self.neutral_state = result.neutral_state
        self.refresh_self_model()
        self.checkpoint_capsule()
        return result

    def observe_self(self) -> dict[str, Any]:
        snapshot = self.core.state.snapshot()
        current = self.core.slot.current
        lineage = self.core.lineage.records()
        return {
            "generation": current.generation if current is not None else snapshot.generation,
            "objective": self.objective,
            "active_paradigms": list(self.paradigms.installed()),
            "memory_lineage": [f"g{x.generation}:{x.source_sha256[:12]}" for x in lineage],
            "observations": [
                {
                    "state_version": snapshot.version,
                    "live_generations": list(self.core.slot.live_generations()),
                    "paradigm_count": len(self.paradigms.installed()),
                    "revision_oscillation_signal": self.core.lineage.oscillation_signal(),
                }
            ],
        }

    def refresh_self_model(self) -> FunctionalSelfModel:
        facts = self.observe_self()
        model = self.self_store.load()
        for key, value in facts.items():
            if hasattr(model, key):
                setattr(model, key, copy.deepcopy(value))
        self.self_store.save(model)
        return model

    def self_cycle(
        self,
        policy: Callable[[FunctionalSelfModel, dict[str, Any]], list[dict[str, Any]]],
        context: dict[str, Any] | None = None,
    ) -> tuple[FunctionalSelfModel, list[dict[str, Any]]]:
        loop = CausalSelfLoop(self.self_store, self.observe_self, policy)
        return loop.cycle(context)

    def checkpoint_capsule(self) -> WorkCapsule:
        snapshot = self.core.state.snapshot()
        current = self.core.slot.current
        capsule = WorkCapsule.load(self.capsule_path)
        capsule.runtime_generation = current.generation if current is not None else snapshot.generation
        capsule.state_version = snapshot.version
        capsule.active_paradigms = list(self.paradigms.installed())
        capsule.identity_lineage = [f"g{x.generation}:{x.source_sha256[:12]}" for x in self.core.lineage.records()]
        capsule.verification["functional_self_model"] = asdict(self.self_store.load())
        capsule.save(self.capsule_path)
        return capsule


