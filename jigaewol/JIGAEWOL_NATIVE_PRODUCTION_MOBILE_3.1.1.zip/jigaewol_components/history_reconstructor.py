from __future__ import annotations

"""Reverse-history generator that keeps compatible and contradictory past-worlds live.

The present state is not forced to select one past.  Candidate histories are generated
symbolically, contradictory candidates may survive as alternative realities, and the
reconstructor searches for an observation that distinguishes the remaining worlds.
It never claims exact recovery when no present carrier of the past can be identified.
"""

from dataclasses import dataclass, asdict
from itertools import product
from typing import Any, Callable, Iterable, Mapping
import hashlib, json


@dataclass(frozen=True, slots=True)
class HistoryHypothesis:
    events: tuple[str, ...]
    derived: Mapping[str, Any]
    compatibility: str = "compatible"
    activation_scope: str = "ephemeral_hypothesis_world"
    latent_signature: str = ""


@dataclass(frozen=True, slots=True)
class HistoryReconstruction:
    hypotheses: tuple[HistoryHypothesis, ...]
    distinguishing_probe: Mapping[str, Any]
    alternative_realities: tuple[HistoryHypothesis, ...] = ()
    carrier_hypotheses: tuple[Mapping[str, Any], ...] = ()
    exact_recovery_claimed: bool = False

    def as_mapping(self) -> dict[str, Any]:
        return {
            "hypotheses": [asdict(x) for x in self.hypotheses],
            "distinguishing_probe": dict(self.distinguishing_probe),
            "alternative_realities": [asdict(x) for x in self.alternative_realities],
            "carrier_hypotheses": [dict(x) for x in self.carrier_hypotheses],
            "exact_recovery_claimed": self.exact_recovery_claimed,
        }


class HistoryReconstructor:
    """Generate past-worlds and synthesize a discriminator instead of choosing a story."""

    @staticmethod
    def _signature(events: tuple[str, ...]) -> str:
        raw = json.dumps(events, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _features(events: tuple[str, ...], alphabet: tuple[str, ...]) -> dict[str, Any]:
        transitions = tuple(zip(events, events[1:]))
        row: dict[str, Any] = {
            "history_length": len(events),
            "last_event": events[-1] if events else None,
            "first_event": events[0] if events else None,
            "history_digest": HistoryReconstructor._signature(events),
        }
        for event in alphabet:
            row[f"count:{event}"] = sum(1 for x in events if x == event)
        for left in alphabet:
            for right in alphabet:
                count = sum(1 for pair in transitions if pair == (left, right))
                if count:
                    row[f"transition:{left}->{right}"] = count
        return row

    @staticmethod
    def _probe(rows: tuple[HistoryHypothesis, ...]) -> Mapping[str, Any]:
        if len(rows) < 2:
            return {"kind": "no_probe_needed", "discriminates": False}
        keys = sorted({k for row in rows for k in row.derived})
        ranked = []
        for key in keys:
            values = {repr(row.derived.get(key)) for row in rows}
            if len(values) > 1:
                ranked.append((len(values), key, tuple(sorted(values))))
        if not ranked:
            return {
                "kind": "birth_new_observation",
                "discriminates": False,
                "reason": "current derived history features still collapse live past-worlds",
                "open_observer_invention": True,
            }
        _, key, values = max(ranked, key=lambda x: (x[0], x[1]))
        return {
            "kind": "synthesized_history_probe",
            "feature": key,
            "discriminates": True,
            "observed_values": values,
            "reason": "selected from generated features because it partitions the surviving past-worlds",
        }

    def reconstruct(
        self,
        current_state: Mapping[str, Any],
        *,
        alphabet: Iterable[str],
        max_depth: int,
        compatibility: Callable[[Mapping[str, Any], tuple[str, ...]], bool | Mapping[str, Any]] | None = None,
    ) -> HistoryReconstruction:
        alphabet = tuple(dict.fromkeys(map(str, alphabet)))
        compatible_fn = compatibility or (lambda _state, _history: True)
        compatible_rows: list[HistoryHypothesis] = []
        alternative_rows: list[HistoryHypothesis] = []
        for depth in range(max(0, int(max_depth)) + 1):
            for events in product(alphabet, repeat=depth):
                verdict = compatible_fn(current_state, events)
                if isinstance(verdict, Mapping):
                    is_compatible = bool(verdict.get("compatible", True))
                    reason = str(verdict.get("reason") or "")
                else:
                    is_compatible = bool(verdict)
                    reason = ""
                features = self._features(events, alphabet)
                if reason:
                    features = {**features, "compatibility_reason": reason}
                row = HistoryHypothesis(
                    tuple(events),
                    features,
                    "compatible" if is_compatible else "contradicts_current_observation_but_preserved",
                    "ephemeral_hypothesis_world",
                    self._signature(tuple(events)),
                )
                (compatible_rows if is_compatible else alternative_rows).append(row)

        live = tuple(compatible_rows)
        probe = self._probe(live)
        carriers: tuple[Mapping[str, Any], ...] = (
            {
                "kind": "interaction_pattern",
                "description": "past influence may survive in the structure of current interaction responses rather than an explicit record",
                "identified": False,
            },
            {
                "kind": "transition_structure",
                "description": "past influence may survive in which state transitions are currently reachable",
                "identified": False,
            },
            {
                "kind": "policy_internalization",
                "description": "past influence may be embodied in current behavior without a separately addressable memory object",
                "identified": False,
            },
        )
        return HistoryReconstruction(live, probe, tuple(alternative_rows), carriers, False)
