from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable


@dataclass(frozen=True)
class LiftTask:
    task_id: str
    payload: Any
    expected: Any


@dataclass(frozen=True)
class LiftResult:
    task_id: str
    baseline_score: float
    candidate_score: float
    baseline_output: Any
    candidate_output: Any
    evidence: tuple[str, ...]


@dataclass(frozen=True)
class LiftAudit:
    results: tuple[LiftResult, ...]
    baseline_mean: float
    candidate_mean: float
    absolute_lift: float
    relative_lift: float
    promotion_allowed: bool


Solver = Callable[[LiftTask], tuple[Any, float, Iterable[str]]]


class CognitiveLiftGate:
    """Anti-downgrade benchmark gate: ensures changes deliver measured performance improvements.

    Focuses strictly on verified task results without introducing subjective claims.
    """

    def evaluate(
        self,
        tasks: Iterable[LiftTask],
        *,
        baseline: Solver,
        candidate: Solver,
        minimum_absolute_lift: float = 0.0,
    ) -> LiftAudit:
        rows = []
        for task in tasks:
            bo, bs, be = baseline(task)
            co, cs, ce = candidate(task)
            rows.append(
                LiftResult(
                    task.task_id,
                    float(bs),
                    float(cs),
                    bo,
                    co,
                    tuple(str(x) for x in (*be, *ce)),
                )
            )
        bm = sum(x.baseline_score for x in rows) / len(rows) if rows else 0.0
        cm = sum(x.candidate_score for x in rows) / len(rows) if rows else 0.0
        lift = cm - bm
        rel = (lift / abs(bm)) if bm else (1.0 if lift > 0 else 0.0)
        evidence_ok = bool(rows) and all(x.evidence for x in rows)
        return LiftAudit(
            tuple(rows),
            bm,
            cm,
            lift,
            rel,
            evidence_ok and lift >= float(minimum_absolute_lift),
        )
