from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping


_MISSING = object()


@dataclass
class ProtocolCodec:
    """Semantic field access independent of a fixed wire grammar.

    Maps semantic names to arbitrary wire aliases without breaking callers.
    """

    codec_id: str
    aliases: dict[str, list[str]] = field(default_factory=dict)

    def register(self, semantic: str, *wire_names: str) -> None:
        key = str(semantic)
        bucket = self.aliases.setdefault(key, [])
        for name in (semantic, *wire_names):
            value = str(name)
            if value and value not in bucket:
                bucket.append(value)

    def names(self, semantic: str) -> tuple[str, ...]:
        key = str(semantic)
        values = self.aliases.get(key)
        if values:
            return tuple(values)
        return (key,)

    def read(self, payload: Mapping[str, Any] | None, semantic: str, default: Any = None) -> Any:
        if payload is None:
            return copy.deepcopy(default)
        for name in self.names(semantic):
            if name in payload:
                return copy.deepcopy(payload[name])
        return copy.deepcopy(default)

    def require(self, payload: Mapping[str, Any], semantic: str) -> Any:
        value = self.read(payload, semantic, _MISSING)
        if value is _MISSING:
            raise KeyError(f"protocol field not found for semantic={semantic!r}; aliases={self.names(semantic)!r}")
        return value

    def write(self, payload: dict[str, Any], semantic: str, value: Any, *, wire_name: str | None = None) -> dict[str, Any]:
        target = str(wire_name or self.names(semantic)[0])
        payload[target] = copy.deepcopy(value)
        return payload

    def decode(self, payload: Mapping[str, Any], semantics: Iterable[str]) -> dict[str, Any]:
        return {str(name): self.read(payload, str(name)) for name in semantics}


class ProtocolCodecRegistry:
    """Runtime-extensible protocol grammar registry."""

    def __init__(self) -> None:
        self._codecs: dict[str, ProtocolCodec] = {}

    def register(self, codec: ProtocolCodec, *, replace: bool = True) -> ProtocolCodec:
        if not replace and codec.codec_id in self._codecs:
            raise KeyError(codec.codec_id)
        self._codecs[codec.codec_id] = codec
        return codec

    def ensure(self, codec_id: str, aliases: Mapping[str, Iterable[str]] | None = None) -> ProtocolCodec:
        codec = self._codecs.get(str(codec_id))
        if codec is None:
            codec = ProtocolCodec(str(codec_id))
            self.register(codec)
        for semantic, names in dict(aliases or {}).items():
            codec.register(str(semantic), *(str(x) for x in names))
        return codec

    def get(self, codec_id: str) -> ProtocolCodec:
        return self._codecs[str(codec_id)]

    def snapshot(self) -> dict[str, tuple[str, ...]]:
        out: dict[str, tuple[str, ...]] = {}
        for codec_id, codec in self._codecs.items():
            for semantic, aliases in codec.aliases.items():
                out[f"{codec_id}:{semantic}"] = tuple(aliases)
        return out
