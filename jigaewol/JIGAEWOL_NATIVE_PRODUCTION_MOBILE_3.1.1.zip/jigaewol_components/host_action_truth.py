from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .body_federation import BodyFederationRegistry
from .worker_truth import WorkerTruth


def _key(value: str) -> str:
    return str(value or "").strip().casefold().replace("-", "_").replace(" ", "_")


def _families(capabilities: Iterable[str]) -> tuple[str, ...]:
    out: list[str] = []
    for cap in capabilities:
        text = str(cap)
        if ":" in text:
            out.append(text.split(":", 1)[0])
    return tuple(dict.fromkeys(out))


def capabilities_proven_by_action(provider_id: str, action: str) -> tuple[str, ...]:
    """Return only capabilities evidenced by one *successful* observed host action.

    Provider catalog visibility is intentionally not enough here. A successful read
    action does not prove write/deploy/remote-exec capability. The exact host action is
    always recorded, and broader semantic capabilities are granted only when the action
    itself demonstrates them.
    """

    pid = _key(provider_id)
    act = _key(action)
    caps: list[str] = [f"host_action:{pid}:{act}"]

    if pid == "github":
        if any(act.startswith(x) for x in ("get_", "fetch_", "list_", "search_", "compare_")):
            caps.append("search:code_ecosystem")
        if any(x in act for x in ("create_file", "update_file", "delete_file", "create_commit", "update_ref", "merge_pull_request", "create_pull_request", "create_branch")):
            caps.extend(("repository:write", "state:write_artifact"))

    if pid in {"tinyfish", "firecrawl", "exa", "tavily", "tavily_ai"}:
        if any(x in act for x in ("search", "fetch", "scrape", "extract", "crawl", "research")):
            caps.append("search:web_current")
        if any(x in act for x in ("run_web_automation", "interact", "browser", "navigate", "screenshot")):
            caps.append("browser:interact")
    if pid == "firecrawl" and act in {"firecrawl_agent", "firecrawl_agent_status"}:
        caps.extend(("cognition:external_agent", "cognition:domain_delegate_research"))

    if pid == "opera_browser_connector":
        if act in {"list_tabs", "history", "tab_content", "tab_content_jq_search_query", "screenshot", "go_to_page", "close_tab"}:
            caps.append("browser:interact")

    if pid == "remote_desktop_commander":
        if any(x in act for x in ("read_file", "read_multiple_files", "list_directory", "get_file_info", "start_search", "get_more_search_results", "list_processes", "list_sessions")):
            caps.append("workspace:remote_observe")
        if any(x in act for x in ("write_file", "write_pdf", "create_directory", "move_file", "edit_block")):
            caps.extend(("workspace:remote_write", "state:write_artifact"))
        if any(x in act for x in ("start_process", "interact_with_process", "kill_process", "force_terminate")):
            caps.extend(("compute:exec", "compute:remote_exec", "terminal:exec"))

    if pid == "railway":
        if act in {"whoami", "list_workspaces", "list_projects", "list_services", "get_status", "get_logs", "get_service_metrics"}:
            caps.append("deploy:observe")
        if act == "railway_agent":
            caps.extend(("cognition:external_agent", "cognition:domain_delegate_infrastructure"))
        if act == "create_project":
            caps.append("state:write_artifact")
        if any(x in act for x in ("create_deployment", "create_service", "redeploy", "accept_deploy", "generate_domain")):
            caps.append("deploy:artifact")

    if pid == "opencode" and act == "run":
        caps.extend(("cognition:external_agent", "cognition:domain_delegate_software"))
    if pid == "opencode" and act == "general_prompt":
        caps.extend(("cognition:external_agent", "cognition:general_delegate"))

    if pid == "replit":
        if act in {"create_app_from_prompt", "update_app_using_prompt", "ask_question"}:
            caps.extend(("cognition:external_agent", "cognition:domain_delegate_software"))
        if act in {"create_app_from_prompt", "update_app_using_prompt"}:
            caps.append("state:write_artifact")
        if act == "publish_app":
            caps.append("deploy:artifact")
        if act in {"list_apps", "search_apps", "resolve_app_by_name", "get_publish_status"}:
            caps.append("workspace:persistent")

    if pid == "floot":
        if any(x in act for x in ("list_projects", "list_resources", "list_files", "read_file", "read_files", "search_code", "get_current_context")):
            caps.append("workspace:persistent")
        if any(x in act for x in ("run_code_in_vm", "run_tests", "typecheck")):
            caps.extend(("compute:exec", "compute:remote_exec"))
        if any(x in act for x in ("run_code_in_browser", "navigate_preview", "screenshot_preview")):
            caps.append("browser:interact")
        if any(x in act for x in ("write_file", "edit_file", "apply_patch", "upload_asset", "generate_image")):
            caps.append("state:write_artifact")
        if any(x in act for x in ("publish_app", "provision_resource")):
            caps.append("deploy:artifact")

    if pid == "figma":
        if any(x in act for x in ("get_screenshot", "get_design_context", "get_metadata", "get_variable_defs", "search_design_system", "get_figjam")):
            caps.append("design:reference_deconstruct")
        if any(x in act for x in ("use_figma", "generate_figma_design", "generate_diagram", "generate_deck", "create_new_file", "create_shader", "create_generative_plugin", "upload_assets")):
            caps.extend(("design:artifact_generate", "state:write_artifact"))

    if pid == "notion":
        if act in {"search", "ai_search", "fetch", "query_data_sources", "query_multiple_data_sources", "notion_search_skills"} or act.startswith("notion_list_"):
            caps.append("search:personal_knowledge")
        if any(x in act for x in ("create", "update", "upload", "move", "duplicate")):
            caps.append("state:write_artifact")
        if "spawn_session" in act or "send_message_to_session" in act:
            caps.append("cognition:parallel_delegate")

    if pid == "plugin_management":
        if any(x in act for x in ("search_plugins", "suggest_plugins", "get_plugin_dependencies", "get_app_permissions")):
            caps.append("capability:discover_execute")

    if pid == "context7":
        if any(x in act for x in ("resolve_library_id", "query_docs")):
            caps.append("search:developer_docs")

    if pid == "wolfram":
        if any(x in act for x in ("wolframlanguageevaluator", "wolframalpha", "wolframcontext")):
            caps.append("compute:formal")

    if pid == "posthog" and act == "exec":
        caps.append("analytics:observe")

    if pid == "supabase":
        if act.startswith(("list_", "get_", "query_", "generate_")) or act in {"search_docs"}:
            caps.append("database:observe")
        if act == "execute_sql":
            caps.append("database:sql_exec")
        if act in {"apply_migration", "deploy_edge_function", "create_project", "pause_project", "restore_project", "create_branch", "delete_branch", "merge_branch", "reset_branch", "rebase_branch"}:
            caps.extend(("database:write", "state:write_artifact"))

    if pid == "vercel":
        if act.startswith(("list_", "get_", "search_", "web_fetch_")):
            caps.append("deploy:observe")
        if act in {"deploy_to_vercel", "import_claude_design_from_url"}:
            caps.extend(("deploy:artifact", "state:write_artifact"))

    if pid == "neon":
        if act.startswith(("list_", "get_", "describe_", "inspect_", "explain_", "query_")):
            caps.append("database:observe")
        if act.startswith("run_sql"):
            caps.append("database:sql_exec")
        if act.startswith(("prepare_", "complete_", "create_", "update_", "delete_", "set_", "reset_", "recover_", "finalize_", "provision_", "disable_", "deploy_", "register_", "revoke_", "rotate_", "restore_")):
            caps.extend(("database:write", "state:write_artifact"))

    if pid == "render":
        if act.startswith(("list_", "get_", "query_")):
            caps.append("deploy:observe")
        if act.startswith("create_") or act in {"trigger_deploy", "update_environment_variables"}:
            caps.extend(("deploy:artifact", "state:write_artifact"))

    if pid == "gitbook":
        if act.startswith(("list_", "get_", "search", "describe_", "invoke_")):
            caps.append("documentation:observe")
        if act in {"create_change_request", "submit_or_merge_change_request"}:
            caps.append("state:write_artifact")

    if pid == "lovable":
        if act in {"send_message", "create_project", "initiate_project", "remix_project"}:
            caps.append("cognition:domain_delegate_software")
        if act in {"create_project", "initiate_project", "remix_project", "set_project_visibility", "set_folder_visibility", "move_projects_to_folder", "set_workspace_knowledge", "create_workspace_skill", "update_workspace_skill", "delete_workspace_skill", "set_project_knowledge", "enable_database", "query_database"}:
            caps.append("state:write_artifact")
        if act == "deploy_project":
            caps.append("deploy:artifact")
        if act in {"list_files", "read_file", "get_diff", "list_edits", "list_projects", "get_project"}:
            caps.append("workspace:persistent")

    if pid == "base44":
        if act == "run_command":
            caps.extend(("compute:exec", "compute:remote_exec", "terminal:exec"))
        if act in {"create_base44_app", "edit_base44_app"}:
            caps.append("cognition:domain_delegate_software")
        if act in {"create_base44_app", "edit_base44_app", "import_claude_design_from_url", "create_entity_schema", "update_entity_schema", "create_entities", "update_entities", "write_file", "edit_file", "create_checkpoint"}:
            caps.append("state:write_artifact")
        if act in {"list_user_apps", "list_entity_schemas", "query_entities", "read_file", "grep", "list_directory"}:
            caps.append("workspace:persistent")

    if pid == "digitalocean":
        if act.endswith(("_get", "_list")) or act.startswith(("account_get", "balance_get", "billing_history", "invoice_list", "region_list", "size_list")):
            caps.append("infrastructure:observe")
        if any(x in act for x in ("create", "delete", "resize", "rebuild", "restore", "snapshot", "power_", "reboot", "shutdown", "enable_", "disable_", "rename", "reset_")):
            caps.extend(("infrastructure:provision", "state:write_artifact"))

    return tuple(dict.fromkeys(caps))


def worker_truth_from_host_action(provider_id: str, action: str, success_row: Mapping[str, Any] | None) -> WorkerTruth:
    """Derive cognitive-worker truth only from action-specific observed result evidence.

    A provider having an "agent" action in its catalog is not enough.  For Railway
    the successful action must return a concrete thread id and a final response path.
    """
    row = dict(success_row or {})
    pid = _key(provider_id)
    act = _key(action)
    summary = row.get("result_summary") if isinstance(row.get("result_summary"), dict) else {}
    if pid == "opencode" and act == "run" and row.get("success") is True:
        session_id = str(summary.get("session_id") or summary.get("sessionID") or "").strip()
        response = str(summary.get("response") or summary.get("text") or "").strip()
        receipt_ref = str(row.get("evidence_ref") or row.get("observation_id") or "").strip()
        if session_id and response and receipt_ref:
            return WorkerTruth(
                execution_kind="external_agent",
                context_ref=f"opencode_session:{session_id}",
                provider_ref="opencode:remote_cli",
                execution_receipt_ref=receipt_ref,
                state="completed",
                agent_backed=True,
                result_return_path_observed=True,
            )

    if pid == "opencode" and act == "general_prompt" and row.get("success") is True:
        session_id = str(summary.get("session_id") or summary.get("sessionID") or "").strip()
        response = str(summary.get("response") or summary.get("text") or "").strip()
        scopes = tuple(str(x).strip() for x in summary.get("scope_evidence") or () if str(x).strip())
        benchmark_passed = bool(summary.get("benchmark_passed"))
        domain_unconstrained = bool(summary.get("domain_unconstrained_input"))
        receipt_ref = str(row.get("evidence_ref") or row.get("observation_id") or "").strip()
        if session_id and response and receipt_ref and benchmark_passed and domain_unconstrained and len(set(scopes)) >= 3:
            return WorkerTruth(
                execution_kind="external_agent",
                context_ref=f"opencode_general_session:{session_id}",
                provider_ref="opencode:general_prompt",
                execution_receipt_ref=receipt_ref,
                state="completed",
                agent_backed=True,
                result_return_path_observed=True,
            )

    if pid == "railway" and act == "railway_agent" and row.get("success") is True:
        thread_id = str(summary.get("thread_id") or summary.get("threadId") or "").strip()
        response_observed = bool(
            summary.get("response_returned")
            or summary.get("response_sha256")
            or summary.get("response_chars")
            or (isinstance(summary.get("response"), str) and str(summary.get("response") or "").strip())
        )
        receipt_ref = str(row.get("evidence_ref") or row.get("observation_id") or "").strip()
        if thread_id and response_observed and receipt_ref:
            return WorkerTruth(
                execution_kind="external_agent",
                context_ref=f"railway_thread:{thread_id}",
                provider_ref="railway:railway_agent",
                execution_receipt_ref=receipt_ref,
                state="completed",
                agent_backed=True,
                result_return_path_observed=True,
            )
    if pid == "replit" and act in {"create_app_from_prompt", "update_app_using_prompt"} and row.get("success") is True:
        repl_id = str(summary.get("repl_id") or summary.get("replId") or "").strip()
        turn_id = str(summary.get("turn_id") or summary.get("turnId") or "").strip()
        phase = _key(str(summary.get("phase") or ""))
        receipt_ref = str(row.get("evidence_ref") or row.get("observation_id") or "").strip()
        if repl_id and turn_id and phase in {"creating", "updating"} and receipt_ref:
            return WorkerTruth(
                execution_kind="external_agent",
                context_ref=f"replit_turn:{turn_id}",
                provider_ref="replit:replit_agent",
                execution_receipt_ref=receipt_ref,
                state="running",
                agent_backed=True,
                result_return_path_observed=False,
            )
    if pid == "replit" and act == "ask_question" and row.get("success") is True:
        repl_id = str(summary.get("repl_id") or summary.get("replId") or "").strip()
        phase = _key(str(summary.get("phase") or ""))
        response = str(summary.get("response") or "").strip()
        receipt_ref = str(row.get("evidence_ref") or row.get("observation_id") or "").strip()
        if repl_id and phase == "paused" and response and receipt_ref:
            return WorkerTruth(
                execution_kind="external_agent",
                context_ref=f"replit_app:{repl_id}",
                provider_ref="replit:replit_agent",
                execution_receipt_ref=receipt_ref,
                state="completed",
                agent_backed=True,
                result_return_path_observed=True,
            )

    if pid == "firecrawl" and act == "firecrawl_agent_status" and row.get("success") is True:
        thread_id = str(summary.get("thread_id") or summary.get("threadId") or "").strip()
        job_id = str(summary.get("job_id") or summary.get("jobId") or summary.get("id") or "").strip()
        status = _key(str(summary.get("status") or ""))
        result_observed = bool(
            summary.get("result_returned")
            or summary.get("data_sha256")
            or summary.get("response_sha256")
            or isinstance(summary.get("data"), (dict, list))
            or isinstance(summary.get("result"), (dict, list, str))
        )
        receipt_ref = str(row.get("evidence_ref") or row.get("observation_id") or "").strip()
        if job_id and thread_id and status == "completed" and result_observed and receipt_ref:
            return WorkerTruth(
                execution_kind="external_agent",
                context_ref=f"firecrawl_thread:{thread_id}:job:{job_id}",
                provider_ref="firecrawl:firecrawl_agent",
                execution_receipt_ref=receipt_ref,
                state="completed",
                agent_backed=True,
                result_return_path_observed=True,
            )
    return WorkerTruth(execution_kind="callable", provider_ref=f"{pid}:{act}")


@dataclass(frozen=True)
class HostActionObservation:
    observation_id: str
    provider_id: str
    executor: str
    role: str
    action: str
    success: bool
    proven_capabilities: tuple[str, ...]
    origin_ref: str
    evidence_ref: str
    result_summary: dict[str, Any]
    error: str
    observed_at: float


class HostActionTruthLedger:
    """Evidence ledger for live host calls with action-level capability truth."""

    def __init__(self, root: str | Path, *, body_root: str | Path | None = None) -> None:
        self.root = Path(root)
        candidate_body_root = Path(body_root) if body_root is not None else self.root
        # A sealed artifact tree is immutable source, never a home for receipt-backed
        # execution memory.  Older call sites sometimes passed project_root here and
        # silently recreated canonical_host_bridge/bodies.json beside source files.
        # Redirect such writes to the persistent ledger root instead.
        if (candidate_body_root / "CANONICAL_ARTIFACT.json").is_file():
            candidate_body_root = self.root
        self.body_root = candidate_body_root
        self.state_dir = self.root / "host_surface"
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.state_dir / "action_truth.jsonl"
        self.state_path = self.state_dir / "action_truth_state.json"
        if not self.state_path.exists():
            self._write_state({"version": 1, "actions": {}})
        self._migrate_capability_semantics()
        self.rehydrate_success_bodies()

    def _read_state(self) -> dict[str, Any]:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            data = {"version": 1, "actions": {}}
        data.setdefault("actions", {})
        return data

    def _write_state(self, data: dict[str, Any]) -> None:
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.state_path)

    def _migrate_capability_semantics(self) -> int:
        state = self._read_state()
        changed = 0
        for key, raw in (state.get("actions") or {}).items():
            if not isinstance(raw, dict) or ":" not in str(key):
                continue
            pid, act = str(key).split(":", 1)
            success = raw.get("last_success")
            if isinstance(success, dict):
                expected = list(capabilities_proven_by_action(pid, act))
                if list(success.get("proven_capabilities") or ()) != expected:
                    success["proven_capabilities"] = expected
                    changed += 1
        if changed:
            self._write_state(state)
        return changed

    def _upsert_success_body(self, row: Mapping[str, Any]) -> None:
        if row.get("success") is not True:
            return
        pid = _key(str(row.get("provider_id") or ""))
        act = _key(str(row.get("action") or ""))
        if not pid or not act:
            return
        caps = capabilities_proven_by_action(pid, act)
        BodyFederationRegistry(self.body_root / "canonical_host_bridge" / "bodies.json").upsert(
            f"host_receipt:{pid}:{act}",
            executor=str(row.get("executor") or pid),
            families=_families(caps),
            capabilities=caps,
            state="executed_successfully",
            zero_incremental_cost=None,
            evidence_strength=1.0,
            origin_ref=str(row.get("origin_ref") or "persistent_host_action_truth"),
            evidence={
                "host_call_observed": True,
                "action_level_truth": True,
                "provider_id": pid,
                "action": act,
                "action_ids": [act],
                "observation_id": str(row.get("observation_id") or ""),
                "evidence_ref": str(row.get("evidence_ref") or ""),
                "result_summary": dict(row.get("result_summary") or {}),
                "does_not_prove_other_provider_actions": True,
                "rehydrated_from_persistent_truth": bool(row.get("rehydrated_from_persistent_truth", False)),
            },
            observed_at=float(row.get("observed_at") or time.time()),
        )

    def historical_evidence(self) -> tuple[dict[str, Any], ...]:
        """Return durable successful observations as history, never current liveness.

        CapabilityRuntime consumes these rows only as execution evidence.  A row from
        this method must not make a provider currently callable without a fresh host
        observation in the same turn.
        """
        state = self._read_state()
        rows: list[dict[str, Any]] = []
        for raw in (state.get("actions") or {}).values():
            if not isinstance(raw, dict):
                continue
            success = raw.get("last_success")
            if isinstance(success, dict) and success.get("success") is True:
                rows.append(dict(success))
        rows.sort(key=lambda row: (float(row.get("observed_at") or 0.0), str(row.get("provider_id") or "")))
        return tuple(rows)

    def rehydrate_success_bodies(self) -> int:
        state = self._read_state()
        count = 0
        for raw in (state.get("actions") or {}).values():
            if not isinstance(raw, dict):
                continue
            success = raw.get("last_success")
            if not isinstance(success, dict) or success.get("success") is not True:
                continue
            row = dict(success)
            row["rehydrated_from_persistent_truth"] = True
            self._upsert_success_body(row)
            count += 1
        return count

    def record(
        self,
        *,
        provider_id: str,
        executor: str,
        action: str,
        success: bool,
        role: str = "",
        origin_ref: str,
        evidence_ref: str = "",
        result_summary: dict[str, Any] | None = None,
        error: str = "",
        observed_at: float | None = None,
    ) -> HostActionObservation:
        ts = time.time() if observed_at is None else float(observed_at)
        pid = _key(provider_id)
        act = _key(action)
        caps = capabilities_proven_by_action(pid, act) if success else (f"host_action:{pid}:{act}",)
        material = json.dumps(
            {"provider": pid, "action": act, "ts": ts, "origin": origin_ref, "evidence": evidence_ref},
            ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")
        obs = HostActionObservation(
            observation_id="hostobs_" + hashlib.sha256(material).hexdigest()[:20],
            provider_id=pid,
            executor=str(executor),
            role=str(role),
            action=act,
            success=bool(success),
            proven_capabilities=tuple(caps),
            origin_ref=str(origin_ref),
            evidence_ref=str(evidence_ref),
            result_summary=dict(result_summary or {}),
            error=str(error),
            observed_at=ts,
        )
        row = asdict(obs)
        with self.log_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        state = self._read_state()
        key = f"{pid}:{act}"
        current = dict(state["actions"].get(key) or {})
        current["last_observation"] = row
        if success:
            current["last_success"] = row
            current["success_count"] = int(current.get("success_count") or 0) + 1
        else:
            current["last_failure"] = row
            current["failure_count"] = int(current.get("failure_count") or 0) + 1
        state["actions"][key] = current
        self._write_state(state)

        if success:
            self._upsert_success_body(row)
        return obs

    def latest_worker_truth(self, provider_id: str, action: str) -> WorkerTruth:
        latest = self.latest(provider_id, action)
        success = latest.get("last_success") if isinstance(latest, dict) else None
        return worker_truth_from_host_action(provider_id, action, success if isinstance(success, dict) else {})

    def latest(self, provider_id: str, action: str) -> dict[str, Any]:
        state = self._read_state()
        return dict(state.get("actions", {}).get(f"{_key(provider_id)}:{_key(action)}") or {})
