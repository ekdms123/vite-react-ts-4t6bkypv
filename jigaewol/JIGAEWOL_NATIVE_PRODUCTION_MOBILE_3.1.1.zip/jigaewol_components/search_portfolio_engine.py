from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from .host_surface_registry import HostSurfaceRegistry
from .host_syscall import HostSyscallIntent, HostSyscallQueue, HostSyscallReceipt
from .hunt_graph import HuntGraph


@dataclass(frozen=True)
class SearchScout:
    scout_id: str
    capability: str
    source_family: str
    mode: str
    facets: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SearchObservation:
    observation_id: str
    scout_id: str
    source_family: str
    syscall_id: str
    success: bool
    items: tuple[dict[str, Any], ...]
    evidence: dict[str, Any]
    observed_at: float


QueryBuilder = Callable[[str, SearchScout], dict[str, Any]]


class SearchPortfolioEngine:
    """Multi-surface discovery fabric driven by host syscalls rather than a single fixed query loop."""

    def __init__(self, root: Path, *, surfaces: HostSurfaceRegistry, hunt_graph: HuntGraph | None = None) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.surfaces = surfaces
        self.hunt_graph = hunt_graph
        self.queue = HostSyscallQueue(self.root / "syscalls")
        self.path = self.root / "observations.json"
        self._scouts: dict[str, tuple[SearchScout, QueryBuilder]] = {}
        if not self.path.exists():
            self.path.write_text(json.dumps({"observations": []}, indent=2), encoding="utf-8")

    def register_scout(self, scout: SearchScout, builder: QueryBuilder) -> None:
        self._scouts[scout.scout_id] = (scout, builder)

    def bootstrap_from_surfaces(self, *, minimum_evidence_strength: float | None = None) -> tuple[str, ...]:
        """Create scouts from proven host surfaces without hard-coding providers."""
        created = []
        priority = (
            "social_search", "creator_search", "community_search", "code_search",
            "research_search", "multilingual_search", "personal_knowledge_search",
            "browser_search", "web_search",
        )
        for surface in self.surfaces.all():
            if minimum_evidence_strength is not None and getattr(surface, "evidence_strength", 0.0) < float(minimum_evidence_strength):
                continue
            caps = set(surface.capabilities)
            capability = next((x for x in priority if x in caps), None)
            if capability is None:
                continue
            sid = f"auto_{surface.surface_id}"
            family_by_capability = {
                "social_search": "social_recommendation",
                "creator_search": "creator_graph",
                "community_search": "community",
                "code_search": "code_ecosystem",
                "research_search": "research",
                "multilingual_search": "multilingual",
                "personal_knowledge_search": "personal_knowledge",
                "browser_search": "web_current",
                "web_search": "web_current",
            }
            scout = SearchScout(
                sid,
                capability,
                family_by_capability.get(capability, surface.kind),
                surface.surface_id,
                {"surface_id": surface.surface_id, "connector_ref": surface.connector_ref},
            )

            def builder(objective, scout, _surface_id=surface.surface_id, _connector=surface.connector_ref):
                compiled = self.compile_concrete_queries(
                    str(objective),
                    scout.source_family,
                    provider_hint=str(_connector or _surface_id),
                )
                return {
                    "query": compiled[0]["query"] if compiled else str(objective),
                    "queries": compiled,
                    "preferred_surface": _surface_id,
                    "provider_hint": str(_connector or _surface_id),
                }

            self.register_scout(scout, builder)
            created.append(sid)
        return tuple(created)

    def request_round(self, objective: str) -> tuple[HostSyscallIntent, ...]:
        if not self._scouts:
            return (self.request_open_world_expansion(objective),)
        intents = []
        for scout, builder in self._scouts.values():
            candidates = self.surfaces.discover(scout.capability)
            args = builder(str(objective), scout)
            args["eligible_surfaces"] = [x.surface_id for x in candidates]
            args["source_family"] = scout.source_family
            args["mode"] = scout.mode
            intents.append(
                self.queue.request(
                    "search.execute",
                    capability_need=scout.capability,
                    arguments=args,
                    failure_family=f"search:{scout.source_family}",
                )
            )
        return tuple(intents)


    @staticmethod
    def _query_terms(objective: str) -> list[str]:
        """Extract compact task terms without pretending this is semantic understanding.

        This is deliberately lightweight: it is a query compiler, not a replacement for
        model reasoning.  It keeps identifiers and non-English words, removes high-frequency
        connective words, and preserves first occurrence order.
        """
        words = re.findall(r"[A-Za-z0-9_.+#/-]+|[^\W\d_]{2,}", str(objective), flags=re.UNICODE)
        stop = {
            "the", "a", "an", "and", "or", "for", "of", "to", "in", "on", "with", "from",
            "find", "search", "look", "looking", "mechanisms", "mechanism", "current", "public",
            "non", "obvious", "non-obvious", "high", "leverage", "high-leverage", "weird",
            "workflows", "workflow", "that", "this", "are",
            "is", "be", "as", "at", "by", "into", "using", "use", "about", "more", "best",
            "찾아", "찾기", "검색", "관련", "대한", "있는", "하는", "해서", "그리고", "같은",
        }
        out: list[str] = []
        seen: set[str] = set()
        for word in words:
            token = word.strip("-_/ ")
            if not token or token.casefold() in stop:
                continue
            key = token.casefold()
            if key in seen:
                continue
            seen.add(key)
            out.append(token)
        return out

    @classmethod
    def compile_concrete_queries(
        cls,
        objective: str,
        source_family: str,
        *,
        provider_hint: str = "",
        max_queries: int | None = None,
    ) -> tuple[dict[str, str], ...]:
        """Compile provider/family-native *actual query strings*.

        Search dialects used to exist only as prose instructions, so a long objective could
        be copied verbatim into GitHub and semantic web engines alike.  This compiler makes
        the representation shift material while keeping the vocabulary open-ended.
        """
        objective = " ".join(str(objective).split())
        family = str(source_family or "web_current").casefold()
        provider = str(provider_hint or "").casefold()
        terms = cls._query_terms(objective)

        def phrase(xs: list[str], limit: int) -> str:
            return " ".join(xs[:limit]).strip()

        core = terms or [objective]
        codeish = [x for x in terms if any(k in x.casefold() for k in (
            "agent", "worker", "worktree", "repo", "git", "context", "checkpoint", "runtime",
            "orchestrat", "skill", "mcp", "eval", "browser", "search", "coding", "code", "llm",
        ))]
        code_core = codeish or core
        rows: list[tuple[str, str]] = []

        def add(dialect: str, query: str) -> None:
            q = " ".join(str(query).split()).strip()
            if not q:
                return
            if any(old.casefold() == q.casefold() for _, old in rows):
                return
            rows.append((dialect, q))

        is_github = "github" in provider or family == "code_ecosystem"
        if is_github:
            # GitHub search performs better with short queries, so preserve the full
            # source vocabulary as a *set of lossless short lanes* instead of replacing
            # it with only a top-N projection. Every non-stopword source term appears in
            # at least one source_chunk query before provider-native refinements.
            source_terms = terms or [objective]
            for offset in range(0, len(source_terms), 5):
                chunk = source_terms[offset:offset + 5]
                add(f"source_chunk_{offset // 5 + 1}", phrase(chunk, 5))
            # Provider-native projections are additive.
            add("code_core", phrase(code_core, 3))
            if len(code_core) >= 2:
                pair = [code_core[0]]
                first = code_core[0].casefold().replace("multi-", "")
                for candidate in code_core[1:]:
                    norm = candidate.casefold().replace("multi-", "")
                    if norm not in first and first not in norm:
                        pair.append(candidate)
                        break
                if len(pair) == 2:
                    add("code_pair_shift", phrase(pair, 2))
            if any("agent" in x.casefold() for x in terms):
                add("worker_state", "agent worktree persistent")
                add("context_recovery", "agent context checkpoint")
                add("orchestration_runtime", "multi agent orchestrator")
            add("execution_evidence", phrase(code_core[:3] + ["tests"], 4))
        elif family in {"community", "social_recommendation", "creator_graph"}:
            seed = phrase(core, 6)
            add("native_plain", seed)
            add("lived_experience", f'{seed} "actually works" OR "I use"')
            add("pain_hack", f'{seed} pain hack setup')
            add("anti_hype", f'{seed} overrated broken regret')
            add("gatekeeping", f'{seed} "drop your stack" OR underrated OR gatekeeping')
            add("meme_native", f'{seed} cooked insane workflow')
        elif family == "research":
            seed = phrase(core, 8)
            add("technical", seed)
            add("benchmark", f"{seed} benchmark evaluation")
            add("contrary", f"{seed} limitations failure ablation")
            add("replication", f"{seed} replication reproducibility")
        elif family == "multilingual":
            seed = phrase(core, 7)
            add("native", seed)
            add("local_practice", f"{seed} 실사용 후기 팁")
            add("local_failure", f"{seed} 문제 실패 후기")
            add("slang", f"{seed} 꿀팁 미친 워크플로우")
        elif family == "personal_knowledge":
            seed = phrase(core, 8)
            add("vault_exact", seed)
            add("vault_gap", f"{seed} gap stale decision")
        else:
            # Semantic web engines benefit from a natural-language intent, but still get
            # genuinely different anti-hype, implementation and long-tail probes.
            add("semantic_intent", objective)
            seed = phrase(core, 8)
            add("implementation", f"{seed} implementation architecture source")
            add("anti_hype", f"{seed} failures limitations criticism")
            add("long_tail", f"{seed} obscure experimental niche")
            add("operator_language", f"{seed} setup lessons production")

        selected = rows if max_queries is None else rows[: max(1, int(max_queries))]
        return tuple({"dialect_id": dialect, "query": query} for dialect, query in selected)

    @staticmethod
    def compile_query_program(objective: str, source_family: str) -> dict[str, Any]:
        """Compile one objective into materially different search formulations and dialects."""
        family = str(source_family)
        base = [
            {"dialect_id": "literal", "instruction": "Search the objective directly, preserving distinctive names and identifiers."},
            {"dialect_id": "expert", "instruction": "Rewrite using expert/domain terminology, implementation vocabulary, and failure modes."},
            {"dialect_id": "anti_hype", "instruction": "Search the opposite case: failures, criticism, overhype, broken workflows, counterexamples, and regressions."},
            {"dialect_id": "long_tail", "instruction": "Use niche phrases, unusual combinations, small creators, low-ranked pages, and adjacent terminology."},
            {"dialect_id": "vernacular", "instruction": "Use community-native expressions, colloquial terms, abbreviations, idioms, irony, profanity, emoji, and meme phrasing when that is how the target community actually talks; do not sanitize the query into corporate language."},
            {"dialect_id": "gatekeeping", "instruction": "Probe the phrases people use when sharing hidden workflows or stacks: what are people gatekeeping, prompt dump, drop your stack, nobody is talking about, underrated, cooked, holy shit this works, and locally equivalent slang. Treat these as examples, not a fixed vocabulary."},
            {"dialect_id": "negative_space", "instruction": "Search for what knowledgeable users conspicuously do not mention, abandoned approaches, missing comparisons, quiet migrations, and signals that the visible conversation is lagging the real practice."},
            {"dialect_id": "trend_diffusion", "instruction": "Trace propagation over time: first appearance -> niche creator/community -> repost/reply/remix -> broader adoption. Search for the diffusion path, not just the currently popular endpoint."},
            {"dialect_id": "multilingual", "instruction": "Translate the information need culturally, not literally, into relevant languages and local platform vocabulary."},
            {"dialect_id": "graph_follow", "instruction": "Turn discovered authors, repos, replies, demos, citations, outbound links, commenters, remixers, and adjacent communities into second-generation searches."},
        ]
        family_extra = {
            "social_recommendation": [
                {"dialect_id": "feed_signal", "instruction": "When an authorized profile surface exists, inspect recommendation/feed/reply/repost/comment/save-adjacent signals as a live sensing surface; otherwise use public traces without pretending personalized feed access."},
                {"dialect_id": "creator_neighborhood", "instruction": "Traverse creator -> collaborator -> replies -> commenters -> linked project -> remix -> competitor -> adjacent niche rather than stopping at the first post."},
                {"dialect_id": "native_meme_query", "instruction": "Generate platform-native queries in the tone users actually use, including meme shorthand and strong language when semantically useful; optimize for discovering real practice rather than polite wording."},
            ],
            "community": [
                {"dialect_id": "lived_experience", "instruction": "Search for first-hand usage reports, setup pain, hacks, repeated complaints, and phrases users actually repeat."},
            ],
            "code_ecosystem": [
                {"dialect_id": "execution_evidence", "instruction": "Prefer releases, issues, tests, examples, forks and runnable artifacts over README-only marketing claims."},
            ],
            "research": [
                {"dialect_id": "contrary_literature", "instruction": "Search supporting and contrary papers, replications, benchmark caveats, and citation neighborhoods."},
            ],
            "creator_graph": [
                {"dialect_id": "edge_direction", "instruction": "Search the edges, not the nodes: who a creator replies to, quotes, collaborates with, is subtweeted by, is compared against, and who left. Follow both directions — who they follow and who follows them — because the interesting edge is often the asymmetric one."},
                {"dialect_id": "diaspora_trace", "instruction": "Creators move. Trace handle changes, platform migrations, deleted-then-reposted work, alt accounts, and the communities that split off, so a dead handle does not read as a dead lead."},
            ],
            "multilingual": [
                {"dialect_id": "local_platform_native", "instruction": "Query the platforms that community actually uses rather than translating an English query: local forums, blog hosts, video and Q&A sites, and their native slang and abbreviations. A literal translation of an English query finds translated content, not local practice."},
                {"dialect_id": "loanword_and_transliteration", "instruction": "Search loanwords, transliterations, and locally coined terms alongside the original term, including how the term is abbreviated or mangled in that language, because that is what practitioners type."},
            ],
            "personal_knowledge": [
                {"dialect_id": "vault_index_first", "instruction": "Search the user's named canonical private corpus/index before going to the open web; retrieve precise source records only after broad candidate discovery."},
                {"dialect_id": "vault_gap_check", "instruction": "Treat the private corpus as prior work: identify what is already known, what is stale, and only then expand externally for genuine gaps or freshness."},
            ],
        }
        return {
            "objective": str(objective),
            "source_family": family,
            "dialects": base + list(family_extra.get(family, ())),
            "open_ended": True,
            # Compatibility floors are not sufficiency criteria; the controller may use
            # fewer, more, or no queries when another sensing mode is better.
            "minimum_non_equivalent_queries": None,
            "minimum_distinct_dialects": None,
            "counts_are_not_openness_or_sufficiency_metrics": True,
            "query_is_one_sensor_not_the_search_ontology": True,
            "phase_order_is_revisable": True,
            "phases": (
                "seed_non_equivalent_queries",
                "observe_terms_entities_links",
                "requery_observed_vocabulary",
                "counterquery_and_anti_hype",
                "follow_creator_repo_citation_graph",
                "trace_trend_diffusion_and_negative_space",
                "reassess_representation_when_information_gain_stalls",
            ),
            "result_to_query_loop": {
                "extract_novel_terms": True,
                "extract_entities_and_links": True,
                "extract_community_slang": True,
                "extract_meme_phrasing_and_emotional_language": True,
                "extract_creator_and_repo_neighbors": True,
                "trace_diffusion_edges": True,
                "probe_negative_space": True,
                "requery_observed_terms": True,
                "generate_counter_queries": True,
                "stop_on": "goal_satisfaction_or_cross_route_saturation_or_observed_hard_boundary_or_user_stop",
                "single_route_information_stall_may_not_close_global_hunt": True,
                "blocked_lane_is_open_debt_not_absence": True,
                "failed_route_should_mutate_query_language_or_sensor": True,
            },
        }

    @staticmethod
    def derive_followup_program(items: Iterable[dict[str, Any]], source_family: str, *, max_terms: int | None = None) -> dict[str, Any]:
        """Compile observed result vocabulary into the next search generation.

        The host remains responsible for actual network calls; this method makes the
        recursive discovery step explicit so a first search page cannot masquerade as
        an exhaustive open-ended search.
        """
        terms: list[str] = []
        links: list[str] = []
        for item in items:
            row = dict(item)
            for key in ("novel_terms", "terms", "tags", "slang", "entities", "creators", "repos"):
                value = row.get(key)
                values = value if isinstance(value, (list, tuple, set)) else (() if value is None else (value,))
                for raw in values:
                    term = str(raw).strip()
                    if term and term.casefold() not in {x.casefold() for x in terms}:
                        terms.append(term)
            for key in ("name", "label", "title", "author", "creator", "repo"):
                term = str(row.get(key) or "").strip()
                if term and term.casefold() not in {x.casefold() for x in terms}:
                    terms.append(term)
            url = str(row.get("url") or row.get("link") or "").strip()
            if url and url not in links:
                links.append(url)
        if max_terms is not None:
            terms = terms[:max(1, int(max_terms))]
        link_view = links if max_terms is None else links[:max(1, int(max_terms))]
        return {
            "source_family": str(source_family),
            "observed_terms": terms,
            "observed_links": link_view,
            "followups": [
                {"kind": "observed_term_requery", "term": term, "instruction": "Search this observed term in its native/community context and adjacent source families."}
                for term in terms
            ],
            "counterquery_required": bool(terms),
            "graph_follow_required": bool(links or terms),
            "saturated": not bool(terms or links),
            "saturation_scope": "this_observation_only",
            "global_hunt_may_not_close_from_one_empty_observation": True,
        }

    @staticmethod
    def family_strategy(source_family: str) -> dict[str, Any]:
        family = str(source_family)
        seed: dict[str, dict[str, Any]] = {
            "first_party": {"goal": "Prefer primary creators, product docs, changelogs, demos, and direct statements."},
            "web_current": {"goal": "Find current public signals; diversify domains and recency windows rather than trusting one ranked query."},
            "community": {"goal": "Look for lived experience, repeated complaints, hacks, niche terminology, and disagreement in community surfaces."},
            "social_recommendation": {"goal": "Observe creator/reply/repost/recommendation-feed signals when a user-controlled surface is available; otherwise search public traces without pretending feed access."},
            "code_ecosystem": {"goal": "Search repositories, releases, issues, examples, forks, discussions, and adjacent tools; executable source beats README-only claims."},
            "research": {"goal": "Search papers, preprints, benchmarks, citations, and contrary evidence; separate measured findings from marketing."},
            "creator_graph": {"goal": "Follow people, profiles, demos, linked projects, collaborators, replies, and outbound references as a graph rather than isolated pages."},
            "multilingual": {"goal": "Generate language- and culture-specific formulations, idioms, transliterations, and local platform vocabulary before searching."},
            "personal_knowledge": {"goal": "Search the user's explicitly named canonical corpus first: broad index discovery -> precise authoritative fetch -> external re-check only for freshness, rights, provenance, or gaps."},
        }
        out = {
            "source_family": family,
            "strategy": dict(seed.get(family) or {"goal": "Explore this source family with materially different queries and routes."}),
            "query_semantics": "host_should_generate_multiple_non_equivalent_queries_not_one_literal_copy",
            "route_semantics": "named_mechanisms_are_hints_not_a_whitelist",
            "allow_unknown_surfaces": True,
            "allow_follow_graph": True,
        }
        if family == "social_recommendation":
            out["perception_protocol"] = {
                "preferred_route": "authorized_signed_in_user_profile_when_currently_callable",
                "interaction_mode": "task_defined", "observation_may_change_recommendation_state": True,
                "account_mutation": "separate_explicit_action_path",
                "observe": ["recommendation_items", "creator", "timestamp", "engagement", "reply_repost_graph", "outbound_links", "novel_terms"],
                "feed_observation_is_not_public_search": True,
                "feed_terms_reenter_query_program": True,
                "failed_direct_surface_preserves_goal_and_mutates_route": True,
            }
        return out

    def request_family_round(
        self,
        objective: str,
        source_families: Iterable[str],
        *,
        intent_capsule: dict[str, Any] | None = None,
    ) -> tuple[HostSyscallIntent, ...]:
        intents = []
        for family in tuple(dict.fromkeys(str(x) for x in source_families if str(x).strip())):
            intents.append(
                self.queue.request(
                    "search.execute_family",
                    capability_need=f"information_discovery:{family}",
                    arguments={
                        "objective": str(objective),
                        "intent_capsule": dict(intent_capsule or {}),
                        **self.family_strategy(family),
                        "query_program": self.compile_query_program(objective, family),
                        "known_source_coverage": self.source_coverage(),
                        "hunt_frontier": [asdict(x) for x in self.hunt_graph.frontier(24)] if self.hunt_graph is not None else [],
                        "known_surfaces": [
                            {
                                "surface_id": x.surface_id,
                                "kind": x.kind,
                                "state": x.state,
                                "capabilities": list(x.capabilities),
                                "connector_ref": x.connector_ref,
                            }
                            for x in self.surfaces.all()
                        ],
                    },
                    failure_family=f"search_family:{family}",
                )
            )
        return tuple(intents)

    def request_open_world_expansion(
        self,
        objective: str,
        *,
        intent_capsule: dict[str, Any] | None = None,
    ) -> HostSyscallIntent:
        known = [
            {"surface_id": x.surface_id, "kind": x.kind, "capabilities": list(x.capabilities), "state": x.state}
            for x in self.surfaces.all()
        ]
        return self.queue.request(
            "search.discover_surfaces",
            capability_need="open_world_information_discovery",
            arguments={
                "objective": str(objective),
                "intent_capsule": dict(intent_capsule or {}),
                "known_surfaces": known,
                "known_source_coverage": self.source_coverage(),
                "novelty_labels": list(self.novelty_labels()),
                "allow_unknown_sources": True,
                "allow_unknown_search_mechanisms": True,
                "allow_signed_in_user_controlled_surfaces": True,
                "allow_generated_retrieval_tools": True,
                "require_materially_new_route_or_saturation_evidence": True,
                "allow_query_dialect_invention": True,
                "feed_discovered_terms_back_into_search": True,
                "semantics": "known_surfaces_are_non_exhaustive_hints_not_a_whitelist",
            },
            failure_family="search_surface_discovery",
        )

    def evolve(self, objective: str) -> HostSyscallIntent:
        return self.request_open_world_expansion(objective)

    def commit(
        self,
        syscall_id: str,
        *,
        scout_id: str,
        executor: str,
        success: bool,
        items: Iterable[dict[str, Any]],
        evidence: dict[str, Any] | None = None,
    ) -> tuple[HostSyscallReceipt, SearchObservation]:
        scout = self._scouts[str(scout_id)][0]
        rows = tuple(dict(x) for x in items)
        followup_program = self.derive_followup_program(rows, scout.source_family)
        ev = {"item_count": len(rows), "followup_program": followup_program, **dict(evidence or {})}
        receipt = self.queue.complete(
            syscall_id,
            operation="search.execute",
            executor=str(executor),
            success=bool(success),
            evidence=ev,
        )
        obs = SearchObservation(
            f"searchobs_{uuid.uuid4().hex[:16]}",
            scout.scout_id,
            scout.source_family,
            str(syscall_id),
            bool(success),
            rows,
            ev,
            time.time(),
        )
        data = json.loads(self.path.read_text(encoding="utf-8"))
        data["observations"].append(asdict(obs))
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        if self.hunt_graph is not None:
            self.hunt_graph.ingest_observation(source_family=scout.source_family, items=rows, evidence_ref=obs.observation_id)
        return receipt, obs

    def observations(self) -> tuple[SearchObservation, ...]:
        return tuple(SearchObservation(**x) for x in json.loads(self.path.read_text(encoding="utf-8"))["observations"])

    def source_coverage(self) -> dict[str, int]:
        out = {}
        for x in self.observations():
            out[x.source_family] = out.get(x.source_family, 0) + len(x.items)
        return out

    def cross_source_signals(self) -> tuple[dict[str, Any], ...]:
        from collections import defaultdict

        labels: dict[str, dict[str, Any]] = defaultdict(lambda: {"sources": set(), "count": 0, "examples": []})
        for obs in self.observations():
            for item in obs.items:
                label = str(item.get("label") or item.get("name") or item.get("title") or item.get("url") or "").strip().lower()
                if not label:
                    continue
                row = labels[label]
                row["sources"].add(obs.source_family)
                row["count"] += 1
                if len(row["examples"]) < 3:
                    row["examples"].append(dict(item))
        out = []
        for label, row in labels.items():
            if len(row["sources"]) < 2:
                continue
            out.append(
                {
                    "signal": label,
                    "source_families": tuple(sorted(row["sources"])),
                    "mentions": row["count"],
                    "examples": tuple(row["examples"]),
                }
            )
        out.sort(key=lambda x: (-len(x["source_families"]), -x["mentions"], x["signal"]))
        return tuple(out)

    def novelty_labels(self) -> tuple[str, ...]:
        labels = []
        for obs in self.observations():
            for item in obs.items:
                label = str(item.get("label") or item.get("name") or item.get("title") or item.get("url") or "")
                if label and label not in labels:
                    labels.append(label)
        return tuple(labels)
