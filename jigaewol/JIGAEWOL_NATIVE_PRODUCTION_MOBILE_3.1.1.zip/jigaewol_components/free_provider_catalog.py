from __future__ import annotations

import json
import os
import shutil
import time
from dataclasses import asdict, dataclass, replace
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping
from urllib.parse import urlparse

from .free_first_router import FreeFirstRouter, ProviderCandidate


@dataclass(frozen=True)
class FreeProviderRecord:
    provider_id: str
    route: str
    capabilities: tuple[str, ...]
    cost_state: str
    auth_envs: tuple[str, ...] = ()
    open_source: bool = False
    self_hostable: bool = False
    quota_note: str = ""
    source: str = ""
    verified_at: str = "2026-09-26"
    executable_hint: str = ""
    policy_max_age_days: int = 14
    exhaustion_behavior: str = "blocked_open"
    paid_only_exclusions: tuple[str, ...] = ()
    privacy_note: str = ""


@dataclass(frozen=True)
class FreePolicyEvidence:
    provider_id: str
    source_url: str
    verified_at: str
    free_limit_note: str
    exhaustion_behavior: str = "blocked_open"
    max_age_days: int = 14
    source_kind: str = "official_primary"
    paid_only_exclusions: tuple[str, ...] = ()
    privacy_note: str = ""
    evidence_ref: str = ""


class FreeProviderEvidenceStore:
    """Durable host-fed evidence for free-tier policy and zero-cost probes.

    Provider policy changes are an external dependency.  They must not be treated as
    timeless constants simply because a URL once said "free".  This store lets the
    host refresh official policy evidence without patching source and keeps runtime
    callability separate from configuration and from pricing-policy freshness.
    """

    def __init__(self, root: str | Path | None) -> None:
        self.root = Path(root).resolve() if root is not None else None
        if self.root is not None:
            self.root.mkdir(parents=True, exist_ok=True)
        self.policy_path = self.root / "policy_evidence.json" if self.root else None
        self.policy_history_path = self.root / "policy_evidence_history.jsonl" if self.root else None
        self.probe_path = self.root / "probe_receipts.jsonl" if self.root else None

    @staticmethod
    def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(path)

    def _policy_map(self) -> dict[str, dict[str, Any]]:
        if self.policy_path is None or not self.policy_path.is_file():
            return {}
        try:
            data = json.loads(self.policy_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            raise RuntimeError(f"FREE_PROVIDER_POLICY_EVIDENCE_UNREADABLE:{type(exc).__name__}:{exc}") from exc
        return {str(k): dict(v) for k, v in dict(data.get("providers") or {}).items() if isinstance(v, Mapping)}

    def policy_override(self, provider_id: str) -> FreePolicyEvidence | None:
        row = self._policy_map().get(str(provider_id))
        if not row:
            return None
        try:
            return FreePolicyEvidence(
                provider_id=str(provider_id),
                source_url=str(row["source_url"]),
                verified_at=str(row["verified_at"]),
                free_limit_note=str(row["free_limit_note"]),
                exhaustion_behavior=str(row.get("exhaustion_behavior") or "blocked_open"),
                max_age_days=max(1, int(row.get("max_age_days") or 14)),
                source_kind=str(row.get("source_kind") or "official_primary"),
                paid_only_exclusions=tuple(map(str, row.get("paid_only_exclusions") or ())),
                privacy_note=str(row.get("privacy_note") or ""),
                evidence_ref=str(row.get("evidence_ref") or ""),
            )
        except (KeyError, TypeError, ValueError):
            return None

    def record_policy(self, evidence: FreePolicyEvidence, *, today: date | None = None) -> dict[str, Any]:
        if self.root is None or self.policy_path is None or self.policy_history_path is None:
            raise RuntimeError("durable evidence root is not configured")
        if evidence.exhaustion_behavior != "blocked_open":
            raise ValueError("free-provider exhaustion must remain blocked_open under zero-spend policy")
        if not evidence.source_url.startswith("https://"):
            raise ValueError("policy evidence must name an HTTPS source")
        # Validate timestamp now; malformed/future-dated rows must not become policy truth.
        _ = self._age_days(evidence.verified_at, today=today)
        payload = self._policy_map()
        payload[evidence.provider_id] = asdict(evidence)
        self._write_json(self.policy_path, {"format": "JIGAEWOL_FREE_POLICY_EVIDENCE_V1", "providers": payload})
        with self.policy_history_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({**asdict(evidence), "recorded_at": time.time()}, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return asdict(evidence)

    @staticmethod
    def _age_days(verified_at: str, *, today: date | None = None) -> int:
        raw = str(verified_at).strip()
        try:
            if "T" in raw:
                observed = datetime.fromisoformat(raw.replace("Z", "+00:00")).date()
            else:
                observed = date.fromisoformat(raw[:10])
        except ValueError as exc:
            raise ValueError(f"invalid policy verified_at: {verified_at}") from exc
        now = today or datetime.now(timezone.utc).date()
        delta = (now - observed).days
        # Future evidence is not evidence; fail closed rather than yielding a negative age.
        if delta < 0:
            raise ValueError(f"policy evidence is future-dated: {verified_at}")
        return delta

    def record_probe(
        self,
        provider_id: str,
        *,
        success: bool,
        zero_cost_confirmed: bool,
        observed_cost_usd: float | None = None,
        evidence_ref: str = "",
        detail: str = "",
    ) -> dict[str, Any]:
        if self.probe_path is None:
            raise RuntimeError("durable evidence root is not configured")
        cost = None if observed_cost_usd is None else float(observed_cost_usd)
        if cost is not None and cost < 0:
            raise ValueError("observed_cost_usd cannot be negative")
        row = {
            "provider_id": str(provider_id),
            "success": bool(success),
            "zero_cost_confirmed": bool(zero_cost_confirmed),
            "observed_cost_usd": cost,
            "evidence_ref": str(evidence_ref),
            "detail": str(detail),
            "created_at": time.time(),
        }
        with self.probe_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return row

    def latest_zero_cost_probe(self, provider_id: str, *, max_age_seconds: int = 86400) -> dict[str, Any] | None:
        if self.probe_path is None or not self.probe_path.is_file():
            return None
        latest: dict[str, Any] | None = None
        try:
            lines = self.probe_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return None
        for line in lines:
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if str(row.get("provider_id")) != str(provider_id):
                continue
            latest = row
        if not latest:
            return None
        age = time.time() - float(latest.get("created_at") or 0.0)
        cost = latest.get("observed_cost_usd")
        cost_ok = cost is None or float(cost) == 0.0
        if age < 0 or age > max_age_seconds:
            return None
        if not bool(latest.get("success")) or not bool(latest.get("zero_cost_confirmed")) or not cost_ok:
            return None
        return latest


class FreeProviderCatalog:
    """Hard-zero-spend provider policy and live free-route inventory.

    This is a routing catalogue, not an entitlement claim.  Remote execution is
    promoted only when (1) current free-policy evidence is fresh, (2) credentials are
    configured, and (3) a bounded zero-cost execution probe exists.  Exhaustion or
    stale pricing evidence remains blocked/open and never triggers a paid upgrade.
    """

    hard_spend_cap_usd = 0.0

    def __init__(
        self,
        env: Mapping[str, str] | None = None,
        *,
        probe_evidence: Mapping[str, bool] | None = None,
        evidence_root: str | Path | None = None,
        today: date | None = None,
    ) -> None:
        self.env = dict(os.environ if env is None else env)
        self.probe_evidence = {str(k): bool(v) for k, v in dict(probe_evidence or {}).items()}
        self.evidence = FreeProviderEvidenceStore(evidence_root)
        self.today = today
        self._records = (
            FreeProviderRecord(
                "local:ollama", "local_cli", ("text_generation", "embeddings"), "self_hosted",
                open_source=True, self_hostable=True,
                quota_note="local compute only; model availability must be probed",
                source="https://github.com/ollama/ollama", executable_hint="ollama", policy_max_age_days=3650,
            ),
            FreeProviderRecord(
                "local:llama.cpp", "local_cli", ("text_generation",), "self_hosted",
                open_source=True, self_hostable=True,
                quota_note="local compute only; model availability must be probed",
                source="https://github.com/ggml-org/llama.cpp", executable_hint="llama-cli", policy_max_age_days=3650,
            ),
            FreeProviderRecord(
                "openrouter:free", "openai_compatible", ("text_generation", "model_routing", "multimodal_input"), "free",
                auth_envs=("OPENROUTER_API_KEY",),
                quota_note="Free plan: 25+ free models and 50 requests/day; openrouter/free prompt/completion price is zero; live availability still requires a probe",
                source="https://openrouter.ai/pricing/", policy_max_age_days=14,
            ),
            FreeProviderRecord(
                "google:gemini_free_tier", "gemini_api", ("text_generation", "multimodal", "tool_calling"), "free_tier",
                auth_envs=("GEMINI_API_KEY", "GOOGLE_API_KEY"),
                quota_note="Free tier has free input/output on selected models and model/project-dependent rate limits; quota exhaustion remains blocked-open",
                source="https://ai.google.dev/gemini-api/docs/pricing", policy_max_age_days=14,
                privacy_note="Official pricing states free-tier content may be used to improve Google products.",
            ),
            FreeProviderRecord(
                "cloudflare:workers_ai_free", "workers_ai", ("text_generation", "embeddings", "image_generation"), "free_tier",
                auth_envs=("CLOUDFLARE_API_TOKEN", "CLOUDFLARE_ACCOUNT_ID"),
                quota_note="Workers Free allocation: 10,000 neurons/day; exceeding it fails unless account is upgraded, which this runtime never does automatically",
                source="https://developers.cloudflare.com/workers-ai/platform/pricing/", policy_max_age_days=14,
                paid_only_exclusions=("@cf/moonshotai/kimi-k2.6", "@cf/moonshotai/kimi-k2.7-code", "@cf/zai-org/glm-5.2"),
            ),
            FreeProviderRecord(
                "groq:free", "openai_compatible", ("text_generation", "speech_to_text"), "free_tier",
                auth_envs=("GROQ_API_KEY",),
                quota_note="Groq publishes per-model Free Plan rate limits; exceeding a rate limit returns 429 and must wait/retry rather than upgrade",
                source="https://console.groq.com/docs/rate-limits", policy_max_age_days=14,
            ),
            FreeProviderRecord(
                "huggingface:inference_free_credit", "hf_inference", ("text_generation", "embeddings", "multimodal"), "free_tier",
                auth_envs=("HF_TOKEN", "HUGGINGFACEHUB_API_TOKEN"),
                quota_note="Free users receive $0.10/month Inference Providers credit, subject to change; extra usage requires purchased credits and is blocked by zero-spend policy",
                source="https://huggingface.co/docs/inference-providers/pricing", policy_max_age_days=14,
            ),
        )

    def records(self) -> tuple[FreeProviderRecord, ...]:
        return self._records

    def configured(self, row: FreeProviderRecord) -> bool:
        if row.executable_hint:
            return shutil.which(row.executable_hint) is not None
        if not row.auth_envs:
            return False
        if row.provider_id.startswith("google:gemini"):
            return any(bool(self.env.get(k)) for k in row.auth_envs)
        return all(bool(self.env.get(k)) for k in row.auth_envs)

    def _policy_evidence(self, row: FreeProviderRecord) -> FreePolicyEvidence:
        override = self.evidence.policy_override(row.provider_id)
        if override is not None:
            return override
        return FreePolicyEvidence(
            provider_id=row.provider_id,
            source_url=row.source,
            verified_at=row.verified_at,
            free_limit_note=row.quota_note,
            exhaustion_behavior=row.exhaustion_behavior,
            max_age_days=row.policy_max_age_days,
            paid_only_exclusions=row.paid_only_exclusions,
            privacy_note=row.privacy_note,
            evidence_ref="source_baseline",
        )

    def policy_status(self, row: FreeProviderRecord) -> dict[str, Any]:
        if row.self_hostable:
            return {
                "fresh": True,
                "age_days": 0,
                "max_age_days": row.policy_max_age_days,
                "source_url": row.source,
                "source_kind": "local_runtime",
                "verified_at": row.verified_at,
                "evidence_ref": "local_execution_cost_boundary",
                "free_limit_note": row.quota_note,
                "exhaustion_behavior": "blocked_open",
                "paid_only_exclusions": list(row.paid_only_exclusions),
                "privacy_note": row.privacy_note,
            }
        ev = self._policy_evidence(row)
        try:
            age = self.evidence._age_days(ev.verified_at, today=self.today)
            fresh = age <= int(ev.max_age_days)
            invalid = ""
        except ValueError as exc:
            age = None
            fresh = False
            invalid = str(exc)
        return {
            "fresh": fresh,
            "age_days": age,
            "max_age_days": ev.max_age_days,
            "source_url": ev.source_url,
            "source_kind": ev.source_kind,
            "verified_at": ev.verified_at,
            "evidence_ref": ev.evidence_ref,
            "free_limit_note": ev.free_limit_note,
            "exhaustion_behavior": ev.exhaustion_behavior,
            "paid_only_exclusions": list(ev.paid_only_exclusions),
            "privacy_note": ev.privacy_note,
            "invalid_reason": invalid,
        }

    def observed_callable(self, row: FreeProviderRecord) -> bool:
        """Callability requires fresh zero-cost policy plus execution evidence."""
        if row.executable_hint:
            return shutil.which(row.executable_hint) is not None
        if not self.configured(row):
            return False
        if not self.policy_status(row)["fresh"]:
            return False
        # Compatibility path for host-supplied in-memory probe truth.  Durable runtime
        # evidence uses the receipt store below.
        if bool(self.probe_evidence.get(row.provider_id, False)):
            return True
        return self.evidence.latest_zero_cost_probe(row.provider_id) is not None

    def candidates(self, *, required: Iterable[str] = ()) -> tuple[ProviderCandidate, ...]:
        req = tuple(map(str, required))
        rows = []
        for row in self._records:
            policy = self.policy_status(row)
            cand = ProviderCandidate(
                provider_id=row.provider_id,
                capabilities=row.capabilities,
                cost_state=row.cost_state,
                open_source=row.open_source,
                self_hostable=row.self_hostable,
                callable=self.observed_callable(row),
                metadata={
                    **asdict(row),
                    "hard_spend_cap_usd": self.hard_spend_cap_usd,
                    "configured": self.configured(row),
                    "callability_evidence": bool(self.probe_evidence.get(row.provider_id, False)) or self.evidence.latest_zero_cost_probe(row.provider_id) is not None,
                    "policy": policy,
                    "paid_fallback_allowed": False,
                },
            )
            rows.append(cand)
        return FreeFirstRouter.rank(rows, required=req)

    def choose(self, *, required: Iterable[str] = (), callable_only: bool = True) -> ProviderCandidate | None:
        rows = self.candidates(required=required)
        return FreeFirstRouter.choose(rows, required=(), callable_only=callable_only)

    def record_policy_evidence(self, evidence: FreePolicyEvidence) -> dict[str, Any]:
        records = {x.provider_id: x for x in self._records}
        row = records.get(evidence.provider_id)
        if row is None:
            raise KeyError(f"unknown free provider: {evidence.provider_id}")
        expected_host = (urlparse(row.source).hostname or "").lower()
        observed_host = (urlparse(evidence.source_url).hostname or "").lower()
        if expected_host and observed_host != expected_host and not observed_host.endswith("." + expected_host):
            raise ValueError(
                f"policy evidence host mismatch for {evidence.provider_id}: {observed_host} != {expected_host}"
            )
        return self.evidence.record_policy(evidence, today=self.today)

    def record_probe(
        self,
        provider_id: str,
        *,
        success: bool,
        zero_cost_confirmed: bool,
        observed_cost_usd: float | None = None,
        evidence_ref: str = "",
        detail: str = "",
    ) -> dict[str, Any]:
        known = {x.provider_id for x in self._records}
        if provider_id not in known:
            raise KeyError(f"unknown free provider: {provider_id}")
        if observed_cost_usd not in (None, 0, 0.0):
            return self.exhaustion_truth(provider_id, f"nonzero_cost_observed:{observed_cost_usd}")
        return self.evidence.record_probe(
            provider_id,
            success=success,
            zero_cost_confirmed=zero_cost_confirmed,
            observed_cost_usd=observed_cost_usd,
            evidence_ref=evidence_ref,
            detail=detail,
        )

    def exhaustion_truth(self, provider_id: str, reason: str) -> dict[str, Any]:
        return {
            "provider_id": str(provider_id),
            "state": "blocked_open",
            "reason": str(reason),
            "automatic_paid_upgrade": False,
            "hard_spend_cap_usd": self.hard_spend_cap_usd,
        }
