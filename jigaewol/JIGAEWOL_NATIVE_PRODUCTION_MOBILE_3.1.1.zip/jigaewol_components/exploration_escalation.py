from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Iterable, Mapping

from .semantic_authority import bind_semantic_authority, classify_outcome_shape


class ExplorationState(str, Enum):
    """Lifecycle of optional extra exploration.

    The state describes runtime work only.  It is never permission to narrow,
    rewrite, or reject the user's requested destination.
    """

    IDLE = "IDLE"
    READY = "READY"
    ACTIVE = "ACTIVE"
    RETURNED = "RETURNED"
    PRESERVED = "PRESERVED"
    CLOSED = "CLOSED"


@dataclass(frozen=True)
class ExplorationTriggerEvidence:
    kind: str
    detail: str
    weight: str = "supporting"


@dataclass(frozen=True)
class ExplorationDecision:
    state: str
    task_shape: str
    reason: str
    triggers: tuple[ExplorationTriggerEvidence, ...]
    outcome_shape: str = ""
    user_goal_is_authority: bool = True

    def as_mapping(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "task_shape": self.task_shape,
            "reason": self.reason,
            "triggers": tuple(asdict(x) for x in self.triggers),
            "outcome_shape": self.outcome_shape,
            "user_goal_is_authority": self.user_goal_is_authority,
        }


@dataclass(frozen=True)
class ExplorationRun:
    run_id: str
    turn_id: str
    opened_at: float
    operator_ids: tuple[str, ...]
    state: str = ExplorationState.ACTIVE.value


# Local fallback classification is intentionally narrow.  It only recognizes
# cases whose shape is explicit enough to be stable in deterministic tests.
# Everything else stays ambiguous until the canonical semantic authority for the
# exact user message supplies the task shape.  In particular, a word such as
# "찾아", "분석", "만들", "research", or "build" never opens exploration here.
_ARITH = re.compile(r"^\s*-?\d+(?:\.\d+)?\s*[+\-*/]\s*-?\d+(?:\.\d+)?\s*(?:=|\?|？|은|는)?\s*$")
_PAST_FACTUAL_RE = re.compile(
    r"(누가|누구|언제|어디서|어디|몇).*(했어|했나|했는지|었어|었나|었는지|였어|였나|인가|이야|이었)\s*[?？]?\s*$"
)
_SHORT_FACTUAL_PREFIXES = (
    "what is ", "who is ", "when is ", "where is ", "define ",
)
_SHORT_FACTUAL_TERMS = ("수도", "뜻", "정의", "이름")
_SMALLTALK_EXACT = {
    "안녕", "안녕하세요", "고마워", "고맙습니다", "감사합니다", "반가워", "뭐해",
    "hi", "hello", "hey", "thanks", "thank you", "how are you", "how's it going",
}
_DIRECT_TRANSFORM_PREFIXES = (
    "번역해", "번역해줘", "요약해", "요약해줘", "교정해", "교정해줘", "다듬어", "다듬어줘",
    "translate ", "summarize ", "proofread ", "rewrite ",
)


def _normalize(text: str) -> str:
    return " ".join(str(text or "").casefold().strip().rstrip(".!?~…？").split())


def _narrow_local_shape(command: str) -> str:
    text = str(command or "").strip()
    folded = text.casefold()
    normalized = _normalize(text)
    if not text:
        return "ambiguous_general"
    if _ARITH.match(text):
        return "closed_deterministic"
    if normalized in _SMALLTALK_EXACT:
        return "closed_knowledge"
    if any(folded.startswith(prefix) for prefix in _DIRECT_TRANSFORM_PREFIXES):
        return "direct_transform"
    if len(text) <= 80 and _PAST_FACTUAL_RE.search(text):
        return "closed_knowledge"
    if len(text) <= 100 and (
        any(folded.startswith(prefix) for prefix in _SHORT_FACTUAL_PREFIXES)
        or ((text.endswith("?") or text.endswith("？")) and any(term in folded for term in _SHORT_FACTUAL_TERMS))
    ):
        return "closed_knowledge"
    return "ambiguous_general"


class ExplorationEscalationController:
    """Choose whether optional extra exploration should run.

    The canonical semantic authority is the primary decision record because it is
    bound to the exact message hash and compiled before this controller.  This
    controller does not maintain a second large keyword ontology.  Its local
    fallback only recognizes a few deterministic quiet cases and otherwise stays
    undecided.  Therefore marker words cannot silently widen or narrow the user's
    task after canonical intent compilation.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "state.json"
        if not self.path.exists():
            self._write({"state": ExplorationState.IDLE.value, "last_run_id": ""})

    @staticmethod
    def _sha(text: str) -> str:
        return hashlib.sha256(str(text).encode("utf-8")).hexdigest()

    def _read(self) -> dict[str, Any]:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return {"state": ExplorationState.IDLE.value, "last_run_id": ""}

    def _write(self, row: Mapping[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _task_shape(command: str) -> str:
        """Deterministic fallback used only when no canonical authority is supplied."""
        return _narrow_local_shape(command)

    def decide(
        self,
        command: str,
        *,
        profile_mode: str = "STANDARD",
        repair_momentum_required: bool = False,
        missing_traits: Iterable[str] = (),
        external_event: bool = True,
        semantic_authority: Mapping[str, Any] | None = None,
    ) -> ExplorationDecision:
        authority = bind_semantic_authority(command, semantic_authority)
        local_shape = self._task_shape(command)
        authority_shape = str(authority.get("task_shape") or "")
        # Deterministic local evidence may quiet obvious arithmetic/smalltalk/short
        # factual lookups when the semantic authority only says "ambiguous". It
        # never invents a broader/open task shape from marker words.
        deterministic_quiet = {"closed_deterministic", "closed_knowledge", "direct_transform"}
        if local_shape in deterministic_quiet and authority_shape in {"", "ambiguous_general"}:
            shape = local_shape
        else:
            shape = authority_shape or local_shape
        outcome = (
            str(authority.get("outcome_shape") or "")
            if authority
            else (classify_outcome_shape(command) or "")
        )

        triggers: list[ExplorationTriggerEvidence] = []
        canonical_open = bool(authority.get("open_problem_required")) or authority_shape == "open_problem"
        representation_search = bool(authority.get("representation_search_required"))

        if canonical_open:
            triggers.append(ExplorationTriggerEvidence(
                "canonical_open_problem",
                "exact-message semantic authority classifies the task as open-ended",
                "strong",
            ))
        if representation_search:
            triggers.append(ExplorationTriggerEvidence(
                "representation_search",
                "exact-message semantic authority requests alternate representations",
                "strong",
            ))
        if repair_momentum_required:
            triggers.append(ExplorationTriggerEvidence(
                "repeated_failure",
                "a relevant repeated-failure repair contract is active",
                "strong",
            ))
        if str(profile_mode or "").strip().upper() == "DEEP" and shape not in {
            "closed_deterministic", "closed_knowledge", "direct_transform", "control_update"
        }:
            triggers.append(ExplorationTriggerEvidence(
                "deep_profile",
                "upstream exact-message analysis requested deeper exploration",
                "supporting" if authority else "strong",
            ))

        missing = tuple(str(x) for x in missing_traits if str(x))
        if missing:
            triggers.append(ExplorationTriggerEvidence("capability_gap", ",".join(missing), "supporting"))

        if not external_event:
            return ExplorationDecision(
                ExplorationState.IDLE.value,
                shape,
                "internal exploration output cannot recursively start a new exploration run",
                tuple(triggers),
                outcome_shape=outcome,
            )

        if shape in {"closed_deterministic", "closed_knowledge", "direct_transform", "control_update"}:
            return ExplorationDecision(
                ExplorationState.IDLE.value,
                shape,
                "proven closed task shape keeps optional exploration idle",
                tuple(triggers),
                outcome_shape=outcome,
            )

        if any(t.weight == "strong" for t in triggers):
            return ExplorationDecision(
                ExplorationState.ACTIVE.value,
                shape,
                "canonical task evidence requests additional exploration",
                tuple(triggers),
                outcome_shape=outcome,
            )

        return ExplorationDecision(
            ExplorationState.READY.value,
            shape,
            "no deterministic reason to force or forbid extra exploration",
            tuple(triggers),
            outcome_shape=outcome,
        )

    def open_run(
        self, *, turn_id: str, decision: ExplorationDecision, operator_ids: Iterable[str],
        checkpoint_id: str = "", replay_identity: str = "",
    ) -> ExplorationRun:
        if decision.state != ExplorationState.ACTIVE.value:
            raise ValueError("exploration may start only from an ACTIVE decision")
        operator_ids = tuple(str(x) for x in operator_ids if str(x))
        # When a checkpoint/replay identity is present the run id is deterministic.
        # This prevents a resumed canonical turn from being rewrapped as a new run.
        replay_key = str(replay_identity or checkpoint_id).strip()
        seed = (
            f"{turn_id}|checkpoint:{replay_key}|{'|'.join(operator_ids)}"
            if replay_key else f"{turn_id}|{time.time_ns()}|{'|'.join(operator_ids)}"
        )
        run = ExplorationRun("exploration_" + self._sha(seed)[:20], str(turn_id), time.time(), operator_ids)
        self._write({
            "state": ExplorationState.ACTIVE.value, "last_run_id": run.run_id,
            "turn_id": str(turn_id), "replay_identity": replay_key,
        })
        return run

    def close(self, *, run: ExplorationRun, returned: bool, preserved: bool = False) -> dict[str, Any]:
        state = (
            ExplorationState.RETURNED.value
            if returned
            else (ExplorationState.PRESERVED.value if preserved else ExplorationState.IDLE.value)
        )
        row = {"state": state, "last_run_id": run.run_id, "turn_id": run.turn_id, "closed_at": time.time()}
        self._write(row)
        return row
