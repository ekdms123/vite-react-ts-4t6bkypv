from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping


INDEPENDENT_EXECUTION_KINDS=frozenset({
    'process','provider_session','model_call','remote_session','external_agent'
})
LOCAL_NONINDEPENDENT_KINDS=frozenset({'callable','thread','capability_bus_callable'})
COGNITIVE_EXECUTION_KINDS=frozenset({'provider_session','model_call','remote_session','external_agent'})


@dataclass(frozen=True)
class WorkerTruth:
    execution_kind: str
    context_ref: str = ''
    provider_ref: str = ''
    execution_receipt_ref: str = ''
    state: str = 'callable'
    agent_backed: bool = False
    result_return_path_observed: bool = False

    @property
    def independent_worker(self) -> bool:
        kind=str(self.execution_kind or '').strip()
        evidence_bound = bool(str(self.execution_receipt_ref or '').strip()) or str(self.state or '').strip() in {
            'observed_external', 'running', 'completed', 'succeeded'
        }
        kind_can_be_independent = kind in INDEPENDENT_EXECUTION_KINDS or (
            kind not in LOCAL_NONINDEPENDENT_KINDS and evidence_bound
        )
        return bool(
            kind_can_be_independent
            and str(self.context_ref or '').strip()
            and str(self.provider_ref or '').strip()
        )

    @property
    def independent_cognitive_worker(self) -> bool:
        return bool(
            self.independent_worker
            and (self.execution_kind in COGNITIVE_EXECUTION_KINDS or self.agent_backed)
            and self.agent_backed
        )

    @property
    def closed_loop_agent_worker(self) -> bool:
        return bool(
            self.independent_cognitive_worker
            and self.result_return_path_observed
            and str(self.execution_receipt_ref or '').strip()
        )

    def as_mapping(self) -> dict[str,Any]:
        return {
            **asdict(self),
            'independent_worker':self.independent_worker,
            'independent_cognitive_worker':self.independent_cognitive_worker,
            'closed_loop_agent_worker':self.closed_loop_agent_worker,
        }

    @classmethod
    def from_mapping(cls, raw: Mapping[str,Any] | None) -> 'WorkerTruth':
        row=dict(raw or {})
        return cls(
            execution_kind=str(row.get('execution_kind') or 'callable'),
            context_ref=str(row.get('context_ref') or ''),
            provider_ref=str(row.get('provider_ref') or ''),
            execution_receipt_ref=str(row.get('execution_receipt_ref') or ''),
            state=str(row.get('state') or 'callable'),
            agent_backed=bool(row.get('agent_backed', False)),
            result_return_path_observed=bool(row.get('result_return_path_observed', False)),
        )


def assert_independent_worker(truth: WorkerTruth | Mapping[str,Any]) -> WorkerTruth:
    row=truth if isinstance(truth,WorkerTruth) else WorkerTruth.from_mapping(truth)
    if not row.independent_worker:
        raise ValueError(
            'independent worker claim requires a non-local execution kind plus distinct context_ref/provider_ref and observed external evidence'
        )
    return row


def assert_independent_cognitive_worker(truth: WorkerTruth | Mapping[str,Any]) -> WorkerTruth:
    row=truth if isinstance(truth,WorkerTruth) else WorkerTruth.from_mapping(truth)
    if not row.independent_cognitive_worker:
        raise ValueError(
            'independent cognitive worker claim requires an independent model/agent-backed '
            'execution kind plus distinct context_ref and provider_ref'
        )
    return row


def assert_closed_loop_agent_worker(truth: WorkerTruth | Mapping[str,Any]) -> WorkerTruth:
    row=truth if isinstance(truth,WorkerTruth) else WorkerTruth.from_mapping(truth)
    if not row.closed_loop_agent_worker:
        raise ValueError(
            'closed-loop agent worker claim requires independent cognitive worker truth, '
            'an observed result-return path, and an execution receipt reference'
        )
    return row
