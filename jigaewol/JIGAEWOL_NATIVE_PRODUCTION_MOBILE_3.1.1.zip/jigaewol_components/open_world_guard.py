from __future__ import annotations

import ast
import copy
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from .capability_bus import (
    CapabilityAcquirer,
    CapabilityDescriptor,
    CapabilityComponent,
    CapabilityRequirement,
    UniversalCapabilityBus,
)


@dataclass(frozen=True)
class ConstraintFinding:
    finding_id: str
    category: str
    source: str
    line: int
    evidence: str
    escape_routes: tuple[str, ...]
    severity: float = 0.5


@dataclass(frozen=True)
class ConstraintAuditReport:
    findings: tuple[ConstraintFinding, ...]
    category_counts: dict[str, int]
    scanned_files: int

    @property
    def closedness_score(self) -> float:
        if not self.findings:
            return 0.0
        weight = sum(max(0.0, min(1.0, x.severity)) for x in self.findings)
        return min(1.0, weight / max(8.0, float(self.scanned_files)))


_escape_routes: dict[str, tuple[str, ...]] = {
    "fixed_seed_set": (
        "treat the list as a seed/cache and add a runtime generator",
        "allow external discovery to add new families",
    ),
    "fixed_protocol_grammar": (
        "move protocol fields into an extensible schema/codec",
        "allow a topology-specific message grammar",
    ),
    "single_winner": (
        "preserve a population instead of selecting one winner",
        "use a replaceable selection policy or market/evolution topology",
    ),
    "terminal_failure": (
        "turn failure into a route-switch event",
        "try a materially different acquisition or representation route",
    ),
    "fixed_budget": (
        "make budget a runtime resource policy rather than a semantic endpoint",
        "allow the task to request a different scheduler topology",
    ),
    "callable_lockin": (
        "represent computation as a paradigm capsule instead of a Python callable only",
        "synthesize a VM/process/model substrate when needed",
    ),
    "fixed_schema": (
        "add open facets/opaque extensions",
        "version and mutate the schema at runtime",
    ),
    "central_control": (
        "make the controller one topology among many",
        "allow decentralized market/actor/blackboard control",
    ),
    "semantic_universe_constraint": (
        "replace finite semantic vocabularies with source-grounded open structures",
        "preserve multiple interpretations until source or evidence resolves them",
        "move validation-only collections behind explicit protocol boundaries",
    ),
}


def register_escape_route(category: str, *routes: str) -> None:
    current = list(_escape_routes.get(str(category), ()))
    for route in routes:
        value = str(route)
        if value and value not in current:
            current.append(value)
    _escape_routes[str(category)] = tuple(current)


class _ConstraintVisitor(ast.NodeVisitor):
    def __init__(self, source: str) -> None:
        self.source = source
        self.security_boundary = source in {
            "jigaewol_components/response_protocol.py",
            "jigaewol_components/response_path_audit.py",
            "jigaewol_components/response_sink.py",
            "jigaewol_components/turn_audit.py",
        }
        self.findings: list[ConstraintFinding] = []
        self._class_stack: list[str] = []
        self._function_stack: list[str] = []

    def _add(self, node: ast.AST, category: str, evidence: str, severity: float = 0.5) -> None:
        key = f"{self.source}:{getattr(node, 'lineno', 0)}:{category}:{evidence}"
        finding_id = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
        self.findings.append(
            ConstraintFinding(
                finding_id=finding_id,
                category=category,
                source=self.source,
                line=int(getattr(node, "lineno", 0) or 0),
                evidence=evidence,
                escape_routes=_escape_routes.get(category, ("generate a materially different route",)),
                severity=severity,
            )
        )

    def visit_Assign(self, node: ast.Assign) -> Any:
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id.isupper() and isinstance(node.value, (ast.Tuple, ast.List, ast.Set, ast.Dict)):
                self._add(node, "validation_boundary", f"module constant {target.id} contains a concrete collection; audit semantic use separately", 0.0)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> Any:
        if isinstance(node.target, ast.Name) and node.target.id.isupper() and isinstance(node.value, (ast.Tuple, ast.List, ast.Set, ast.Dict)):
            self._add(node, "validation_boundary", f"module constant {node.target.id} contains a concrete collection; audit semantic use separately", 0.0)
        if isinstance(node.target, ast.Name):
            annotation = ast.unparse(node.annotation) if hasattr(ast, "unparse") else ""
            value_text = ast.unparse(node.value) if node.value is not None and hasattr(ast, "unparse") else ""
            if "Callable" in annotation or "Callable" in value_text:
                self._add(node, "callable_lockin", f"{node.target.id} is constrained to Callable", 0.45)
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> Any:
        self._class_stack.append(node.name)
        schema_classes = {
            "CapabilityRequirement",
            "CapabilityDescriptor",
            "GoalEnvelope",
            "FunctionalSelfModel",
            "WorkCapsule",
            "ControlTopologyRequest",
            "ParadigmCapsule",
        }
        if node.name in schema_classes:
            fields = [x.target.id for x in node.body if isinstance(x, ast.AnnAssign) and isinstance(x.target, ast.Name)]
            extension_slots = {"facets", "metadata", "extensions", "opaque_state_refs", "opaque", "extra"}
            if fields and not extension_slots.intersection(fields):
                self._add(node, "fixed_schema", f"{node.name} declares fixed fields without an opaque extension slot: {', '.join(fields)}", 0.65)
        if node.name in {"MetaControlPlane", "JIGAEWOLOrchestrator", "RecursiveLeapEngine"}:
            optional = any(
                isinstance(item, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == "federated_role" for t in item.targets)
                and isinstance(item.value, ast.Constant)
                and item.value.value == "optional_controller"
                for item in node.body
            )
            if not optional:
                self._add(node, "central_control", f"{node.name} is a privileged control locus", 0.5)
        self.generic_visit(node)
        self._class_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> Any:
        self._function_stack.append(node.name)
        for arg, default in zip(node.args.args[-len(node.args.defaults):], node.args.defaults) if node.args.defaults else ():
            if arg.arg in {"max_cycles", "round_budget", "max_workers", "count", "expansion_rounds"} and isinstance(default, ast.Constant) and isinstance(default.value, (int, float)):
                self._add(node, "fixed_budget", f"{node.name} defaults {arg.arg}={default.value}", 0.35)
        self.generic_visit(node)
        self._function_stack.pop()

    def visit_Subscript(self, node: ast.Subscript) -> Any:
        if isinstance(node.slice, ast.Constant) and node.slice.value == 0:
            # A first-element access is only evidence of semantic collapse when the
            # indexed object itself is a candidate/result population.  Do not use
            # ast.unparse() text from arbitrary calls: helper(task_model)[0] is a
            # data-shape operation, not proof that a model population was collapsed.
            value = node.value
            root = ""
            if isinstance(value, ast.Name):
                root = value.id
            elif isinstance(value, ast.Attribute):
                root = value.attr
            elif isinstance(value, ast.Subscript):
                nested = value.value
                if isinstance(nested, ast.Name):
                    root = nested.id
                elif isinstance(nested, ast.Attribute):
                    root = nested.attr
            if root and any(token in root.lower() for token in ("candidate", "topolog", "result", "hypoth", "proposal")):
                base = ast.unparse(node.value) if hasattr(ast, "unparse") else root
                self._add(node, "single_winner", f"first element selected from {base}", 0.7)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> Any:
        if isinstance(node.func, ast.Attribute) and node.func.attr == "get" and node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
            key = node.args[0].value
            if key in {
                "requests", "done", "candidate_output", "topology_id", "provides", "kinds", "tags", "location",
                "direct_route", "requirement", "payload", "score", "content", "messages",
            }:
                self._add(node, "validation_boundary", f"concrete protocol field {key!r}; field presence is not a universe claim", 0.0)
        self.generic_visit(node)

    def visit_Raise(self, node: ast.Raise) -> Any:
        exc = node.exc
        if isinstance(exc, ast.Call) and isinstance(exc.func, ast.Name) and exc.func.id in {"LookupError", "KeyError", "RuntimeError", "TypeError", "ValueError"}:
            exc_name = exc.func.id
            msg = ast.unparse(exc) if hasattr(ast, "unparse") else exc_name
            text = msg.lower()
            fn = self._function_stack[-1].lower() if self._function_stack else ""
            boundary_tokens = (
                "must be", "requires non-empty", "invalid ", "path escapes", "cannot crystallize",
                "evidence is required", "provenance mismatch", "source provenance requires",
                "already exists", "already completed", "unknown syscall", "unknown turn",
                "unknown graph", "unsupported request builder substrate", "must return",
                "no public python functions", "requires parseable source", "spdx license",
                "repository identity binding", "source file missing", "dimacs", "assignment missing",
            )
            route_dead_end_tokens = (
                "no alternative route", "no viable route", "no route can continue",
                "cannot continue", "no candidates remain", "terminal goal failure",
                "all routes failed", "route exhausted",
            )
            validation_functions = {"require", "_safe_path", "_resolve", "commit", "attach_runtime"}
            explicit_dead_end = any(token in text for token in route_dead_end_tokens)
            # Value/Type/Key/Lookup errors overwhelmingly describe API/data
            # validation.  Treating every such raise as a semantic dead end made
            # the auditor accuse ordinary defensive programming of closed-world
            # reasoning.  Explicit route-dead-end language still wins.
            structural_validation = exc_name in {"LookupError", "KeyError", "TypeError", "ValueError"}
            if explicit_dead_end:
                self._add(node, "terminal_failure", msg, 0.45)
            else:
                # Exceptions are execution/data boundaries unless the source text
                # explicitly declares that no alternative cognitive/route path can
                # continue. RuntimeError alone is not a closed-world signal: it is
                # also the normal carrier for resumable resource windows, process
                # failures, and integrity faults.
                self._add(node, "validation_boundary", msg, 0.0)
        self.generic_visit(node)




class _SemanticCollectionFlowAnalyzer:
    """Trace finite module collections into semantic decision sinks.

    This is intentionally a small, dependency-free intra-file dataflow pass. It tracks
    aliases transitively inside functions and distinguishes protocol validation (which
    may legitimately be finite) from values that shape classification, authority,
    routing, candidate pruning, exploration, or representation decisions.
    """

    _semantic_name_tokens = (
        "semantic", "intent", "task", "outcome", "shape", "authority", "route",
        "candidate", "possibility", "exploration", "frontier", "representation",
        "decision", "effect", "cognition", "planner", "selection", "classif", "repair", "escape",
    )
    _validation_name_tokens = (
        "validate", "verify", "integrity", "hash", "schema", "codec", "protocol",
        "parse", "path", "checksum", "signature", "version",
    )

    def __init__(self, source: str, tree: ast.AST) -> None:
        self.source = source
        self.tree = tree
        self.constants: dict[str, ast.AST] = {}
        for node in getattr(tree, "body", ()):  # module level only
            if isinstance(node, ast.Assign) and isinstance(node.value, (ast.Tuple, ast.List, ast.Set, ast.Dict)):
                for target in node.targets:
                    if isinstance(target, ast.Name) and (target.id.isupper() or target.id.startswith("_")):
                        self.constants[target.id] = node
            elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and (node.target.id.isupper() or node.target.id.startswith("_")) and isinstance(node.value, (ast.Tuple, ast.List, ast.Set, ast.Dict)):
                self.constants[node.target.id] = node

    @staticmethod
    def _names(expr: ast.AST | None) -> set[str]:
        if expr is None:
            return set()
        return {node.id for node in ast.walk(expr) if isinstance(node, ast.Name)}

    @staticmethod
    def _string_literals(node: ast.AST) -> tuple[str, ...]:
        return tuple(
            str(x.value)
            for x in ast.walk(node)
            if isinstance(x, ast.Constant) and isinstance(x.value, str)
        )

    def _semantic_function(self, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        low = fn.name.casefold()
        return any(tok in low for tok in self._semantic_name_tokens)

    def _validation_function(self, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        low = fn.name.casefold()
        return any(tok in low for tok in self._validation_name_tokens)

    def _body_has_semantic_sink(self, node: ast.AST, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        if self._semantic_function(fn):
            return True
        for child in ast.walk(node):
            if isinstance(child, ast.Return):
                literals = " ".join(self._string_literals(child)).casefold()
                if any(tok in literals for tok in ("open", "closed", "task", "route", "candidate", "authority", "knowledge", "problem", "artifact")):
                    return True
                if isinstance(child.value, ast.Name) and any(tok in child.value.id.casefold() for tok in self._semantic_name_tokens):
                    return True
            if isinstance(child, (ast.Assign, ast.AnnAssign)):
                targets = []
                if isinstance(child, ast.Assign):
                    targets = [t.id for t in child.targets if isinstance(t, ast.Name)]
                elif isinstance(child.target, ast.Name):
                    targets = [child.target.id]
                if any(any(tok in name.casefold() for tok in self._semantic_name_tokens) for name in targets):
                    return True
        return False

    def findings(self) -> list[ConstraintFinding]:
        if not self.constants:
            return []
        out: list[ConstraintFinding] = []
        seen: set[tuple[str, int]] = set()
        for fn in (n for n in ast.walk(self.tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))):
            aliases: dict[str, set[str]] = {}
            # Fixed-point alias propagation. A local variable can depend on a finite
            # semantic collection through several assignments before reaching a sink.
            changed = True
            while changed:
                changed = False
                for node in ast.walk(fn):
                    if isinstance(node, ast.Assign):
                        dep_names = self._names(node.value)
                        deps = {name for name in dep_names if name in self.constants}
                        for name in dep_names:
                            deps.update(aliases.get(name, set()))
                        for target in node.targets:
                            if isinstance(target, ast.Name) and deps - aliases.get(target.id, set()):
                                aliases.setdefault(target.id, set()).update(deps)
                                changed = True
                    elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                        dep_names = self._names(node.value)
                        deps = {name for name in dep_names if name in self.constants}
                        for name in dep_names:
                            deps.update(aliases.get(name, set()))
                        if deps - aliases.get(node.target.id, set()):
                            aliases.setdefault(node.target.id, set()).update(deps)
                            changed = True

            def deps(expr: ast.AST | None) -> set[str]:
                names = self._names(expr)
                result = {name for name in names if name in self.constants}
                for name in names:
                    result.update(aliases.get(name, set()))
                return result

            for node in ast.walk(fn):
                source_constants: set[str] = set()
                semantic_sink = False
                sink_desc = ""
                if isinstance(node, ast.If):
                    source_constants = deps(node.test)
                    semantic_sink = self._body_has_semantic_sink(node, fn)
                    sink_desc = "conditional semantic decision"
                elif isinstance(node, (ast.For, ast.AsyncFor)):
                    source_constants = deps(node.iter)
                    semantic_sink = self._body_has_semantic_sink(node, fn)
                    sink_desc = "finite iteration feeding semantic decision"
                elif isinstance(node, ast.Return):
                    source_constants = deps(node.value)
                    semantic_sink = bool(source_constants) and self._semantic_function(fn)
                    sink_desc = "semantic return value"
                elif isinstance(node, ast.Assign):
                    source_constants = deps(node.value)
                    target_names = [t.id for t in node.targets if isinstance(t, ast.Name)]
                    semantic_sink = any(any(tok in name.casefold() for tok in self._semantic_name_tokens) for name in target_names)
                    sink_desc = "semantic state assignment"
                elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                    source_constants = deps(node.value)
                    semantic_sink = any(tok in node.target.id.casefold() for tok in self._semantic_name_tokens)
                    sink_desc = "semantic state assignment"
                elif isinstance(node, ast.Call):
                    keyword_deps: set[str] = set()
                    semantic_keywords: list[str] = []
                    for keyword in node.keywords:
                        if not keyword.arg:
                            continue
                        if any(tok in keyword.arg.casefold() for tok in self._semantic_name_tokens):
                            found = deps(keyword.value)
                            if found:
                                keyword_deps.update(found)
                                semantic_keywords.append(keyword.arg)
                    source_constants = keyword_deps
                    semantic_sink = bool(keyword_deps)
                    sink_desc = (
                        "semantic call argument " + ",".join(sorted(semantic_keywords))
                        if semantic_keywords else "semantic call argument"
                    )

                if not source_constants or not semantic_sink:
                    continue
                # Pure validation boundaries remain legitimate finite worlds. A
                # semantic return/sink inside a function named validate/verify still
                # gets reported; a membership guard whose body only raises does not.
                if self._validation_function(fn) and isinstance(node, ast.If) and all(isinstance(x, ast.Raise) for x in node.body):
                    continue
                for const in sorted(source_constants):
                    key = (const, int(getattr(node, "lineno", 0) or 0))
                    if key in seen:
                        continue
                    seen.add(key)
                    evidence = (
                        f"finite collection {const} flows through {fn.name} into {sink_desc}; "
                        "its membership/order can constrain the semantic possibility space"
                    )
                    digest = hashlib.sha256(f"{self.source}:{key[1]}:{const}:{fn.name}".encode("utf-8")).hexdigest()[:16]
                    out.append(ConstraintFinding(
                        finding_id=digest,
                        category="semantic_universe_constraint",
                        source=self.source,
                        line=key[1],
                        evidence=evidence,
                        escape_routes=_escape_routes["semantic_universe_constraint"],
                        severity=0.82,
                    ))
        return out


class OpenWorldConstraintAuditor:
    """Audits code for unintended closed-world constraints without flagging legitimate validation."""

    def scan_tree(self, root: Path, *, include_tests: bool = False) -> ConstraintAuditReport:
        root = root.resolve()
        findings: list[ConstraintFinding] = []
        scanned = 0
        for path in sorted(root.rglob("*.py")):
            rel = path.relative_to(root)
            if not include_tests and (any(part == "tests" or part.startswith("tests_") for part in rel.parts) or ".pytest_cache" in rel.parts):
                continue
            if not include_tests and path.name.startswith("demo_"):
                continue
            if any(part in {"workspace", "vendor", "external_components"} for part in rel.parts):
                continue
            try:
                tree = ast.parse(path.read_text(encoding="utf-8"))
            except (SyntaxError, UnicodeDecodeError):
                continue
            scanned += 1
            visitor = _ConstraintVisitor(str(rel))
            visitor.visit(tree)
            findings.extend(visitor.findings)
            findings.extend(_SemanticCollectionFlowAnalyzer(str(rel), tree).findings())
        counts: dict[str, int] = {}
        for finding in findings:
            counts[finding.category] = counts.get(finding.category, 0) + 1
        return ConstraintAuditReport(tuple(findings), counts, scanned)


@dataclass(frozen=True)
class ThoughtCandidate:
    candidate_id: str
    payload: Any
    frame: str = ""
    mechanism: str = ""
    source_family: str = ""
    topology: str = ""
    failure_family: str = ""
    substrate: str = ""
    assumptions: tuple[str, ...] = ()
    outside_taxonomy: bool = False
    score: float = 0.0
    facets: dict[str, Any] = field(default_factory=dict)

    def signature(self) -> tuple[str, ...]:
        facet_items = tuple(f"{k}={json.dumps(v, sort_keys=True, default=str)}" for k, v in sorted(self.facets.items()))
        return (
            self.frame, self.mechanism, self.source_family, self.topology,
            self.failure_family, self.substrate, *facet_items,
        )


@dataclass(frozen=True)
class ThoughtAudit:
    closed: bool
    collapsed_dimensions: tuple[str, ...]
    unique_signatures: int
    population_size: int
    has_outside_taxonomy: bool
    directives: tuple[str, ...]


ThoughtExpander = Callable[[str, tuple[ThoughtCandidate, ...], tuple[str, ...]], Iterable[ThoughtCandidate]]


class RepresentationDiversityAudit:
    """Audits hypothesis candidate populations for diversity across extensible dimensions."""

    _base_dimensions = ("frame", "mechanism", "source_family", "topology", "failure_family", "substrate")

    def _dimensions(self, rows: tuple[ThoughtCandidate, ...]) -> tuple[str, ...]:
        facet_keys = sorted({str(k) for row in rows for k in row.facets})
        return (*self._base_dimensions, *(f"facet:{k}" for k in facet_keys))

    @staticmethod
    def _dimension_value(row: ThoughtCandidate, dim: str) -> Any:
        if dim.startswith("facet:"):
            return row.facets.get(dim.split(":", 1)[1])
        return getattr(row, dim)

    def audit(self, candidates: Iterable[ThoughtCandidate]) -> ThoughtAudit:
        rows = tuple(candidates)
        dims = self._dimensions(rows)
        if not rows:
            return ThoughtAudit(True, dims, 0, 0, False, ("generate the first independent worlds",))
        collapsed: list[str] = []
        if len(rows) > 1:
            for dim in dims:
                values = {json.dumps(self._dimension_value(row, dim), sort_keys=True, default=str) for row in rows if self._dimension_value(row, dim) not in (None, "")}
                if len(values) <= 1:
                    collapsed.append(dim)
        signatures = {row.signature() for row in rows}
        outside = any(row.outside_taxonomy for row in rows)
        directives = [f"mutate {dim} into a materially different family" for dim in collapsed]
        if not outside:
            directives.append("create at least one candidate outside the current taxonomy")
        if all(row.assumptions for row in rows) and len({row.assumptions for row in rows}) <= 1:
            directives.append("release or invert at least one shared assumption")
        closed = bool(collapsed) or not outside or len(signatures) < max(2, min(3, len(rows)))
        return ThoughtAudit(closed, tuple(collapsed), len(signatures), len(rows), outside, tuple(directives))

    def preserve_outliers(self, candidates: Iterable[ThoughtCandidate]) -> tuple[ThoughtCandidate, ...]:
        best: dict[tuple[str, ...], ThoughtCandidate] = {}
        for row in candidates:
            sig = row.signature()
            current = best.get(sig)
            if current is None or (row.score, row.outside_taxonomy, row.candidate_id) > (current.score, current.outside_taxonomy, current.candidate_id):
                best[sig] = row
        return tuple(sorted(best.values(), key=lambda x: (-int(x.outside_taxonomy), -x.score, x.candidate_id)))

    def open_population(
        self,
        objective: str,
        candidates: Iterable[ThoughtCandidate],
        *,
        expander: ThoughtExpander,
        expansion_budget: int | None = None,
    ) -> tuple[tuple[ThoughtCandidate, ...], ThoughtAudit]:
        population = list(self.preserve_outliers(candidates))
        rounds = 0
        prior_signatures = {x.signature() for x in population}
        while True:
            audit = self.audit(population)
            if not audit.closed:
                return self.preserve_outliers(population), audit
            if expansion_budget is not None and rounds >= max(1, int(expansion_budget)):
                break
            generated = tuple(expander(objective, tuple(population), audit.directives))
            rounds += 1
            if not generated:
                break
            known = {x.candidate_id for x in population}
            population.extend(x for x in generated if x.candidate_id not in known)
            population = list(self.preserve_outliers(population))
            signatures = {x.signature() for x in population}
            if signatures <= prior_signatures:
                break
            prior_signatures = signatures
        return self.preserve_outliers(population), self.audit(population)


@dataclass(frozen=True)
class AcquisitionRoute:
    route_id: str
    acquirer: CapabilityAcquirer
    failure_family: str


@dataclass(frozen=True)
class AcquisitionAttempt:
    route_id: str
    failure_family: str
    acquired: tuple[str, ...]
    error: str | None = None


class OpenWorldCapabilityAcquirer:
    """Discovers alternate acquisition routes across materially distinct providers."""

    def __init__(self, routes: Iterable[AcquisitionRoute]) -> None:
        self.routes = tuple(routes)

    def acquire(
        self,
        requirement: CapabilityRequirement,
        objective: str,
        context: dict[str, Any] | None = None,
    ) -> tuple[tuple[CapabilityComponent, ...], tuple[AcquisitionAttempt, ...]]:
        acquired: list[CapabilityComponent] = []
        attempts: list[AcquisitionAttempt] = []
        used_families: set[str] = set()
        for route in self.routes:
            if route.failure_family in used_families:
                continue
            used_families.add(route.failure_family)
            try:
                components = tuple(route.acquirer(requirement, objective, copy.deepcopy(context or {})))
                attempts.append(AcquisitionAttempt(route.route_id, route.failure_family, tuple(x.descriptor.capability_id for x in components)))
                acquired.extend(components)
                if components:
                    break
            except Exception as exc:
                attempts.append(AcquisitionAttempt(route.route_id, route.failure_family, (), f"{type(exc).__name__}: {exc}"))
        return tuple(acquired), tuple(attempts)

    def as_acquirer(self) -> CapabilityAcquirer:
        def acquire(requirement: CapabilityRequirement, objective: str, context: dict[str, Any]) -> Iterable[CapabilityComponent]:
            components, _attempts = self.acquire(requirement, objective, context)
            return components
        return acquire




class OpenWorldGuard:
    """Runtime guard preventing premature single-winner convergence."""

    def __init__(self) -> None:
        self.thoughts = RepresentationDiversityAudit()

    @staticmethod
    def choose_least_used(
        descriptors: Sequence[CapabilityDescriptor],
        usage: dict[str, int] | None = None,
    ) -> CapabilityDescriptor:
        if not descriptors:
            raise LookupError("no descriptors available")
        usage = usage or {}
        return min(descriptors, key=lambda x: (usage.get(x.capability_id, 0), -x.priority, x.capability_id))

    def runtime_findings(self, bus: UniversalCapabilityBus, neutral_state: dict[str, Any] | None = None) -> tuple[ConstraintFinding, ...]:
        findings: list[ConstraintFinding] = []
        descriptors = bus.descriptors()
        kinds = {x.kind for x in descriptors}
        if len(kinds) <= 1 and descriptors:
            findings.append(ConstraintFinding("runtime-kind-collapse", "fixed_schema", "runtime", 0, f"all components share one kind: {sorted(kinds)}", _escape_routes["fixed_schema"], 0.65))
        topologies = [x for x in descriptors if "goal_pursuit" in x.provides]
        topology_families = {str(x.metadata.get("topology", x.capability_id)) for x in topologies}
        if len(topologies) > 1 and len(topology_families) <= 1:
            findings.append(ConstraintFinding("runtime-topology-collapse", "central_control", "runtime", 0, "multiple topologies collapse to one control family", _escape_routes["central_control"], 0.75))
        if neutral_state and neutral_state.get("active_control_topology") and len(topologies) > 1:
            findings.append(ConstraintFinding("runtime-active-topology", "single_winner", "runtime", 0, f"one active topology is privileged: {neutral_state.get('active_control_topology')}", _escape_routes["single_winner"], 0.35))
        return tuple(findings)
