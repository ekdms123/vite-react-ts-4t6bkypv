from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any

from .semantic_communication import canonicalize_surface_text


def sha256_text(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


@dataclass(frozen=True)
class CandidateResponse:
    """Response material before CAS publication; no permission semantics."""
    turn_id: str
    body: str
    producer: str
    evidence: dict[str, Any] = field(default_factory=dict)
    _response_sha256: str = field(init=False, repr=False)
    _source_response_sha256: str = field(init=False, repr=False)

    def __post_init__(self) -> None:
        source_body = str(self.body)
        canonical_body, _ = canonicalize_surface_text(source_body, direction="system")
        object.__setattr__(self, "_source_response_sha256", sha256_text(source_body))
        object.__setattr__(self, "body", canonical_body)
        object.__setattr__(self, "_response_sha256", sha256_text(canonical_body))

    @property
    def source_response_sha256(self) -> str:
        return self._source_response_sha256

    @property
    def response_sha256(self) -> str:
        return self._response_sha256


@dataclass(frozen=True)
class ReleasedResponse:
    """CAS-verified user-facing response; integrity proof only."""
    turn_id: str
    body: str
    body_sha256: str
    blob_sha256: str
    blob_size_bytes: int
    integrity_receipt_id: str = ""
    integrity_sha256: str = ""
    release_format: str = "direct-cas-v1"


@dataclass(frozen=True)
class HypothesisCandidate:
    """One independently preserved hypothesis inside a superposed response group."""
    candidate_id: str
    body: str
    producer: str
    assumptions: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    counterevidence_refs: tuple[str, ...] = ()
    uncertainty: float = 0.0
    epistemic_mode: str = "EVIDENCED"
    preservation_basis: tuple[str, ...] = ()
    qualitative_tensions: tuple[str, ...] = ()
    raw_spark_sha256: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    _response_sha256: str = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not str(self.candidate_id).strip():
            raise ValueError("candidate_id must be non-empty")
        if not str(self.body).strip():
            raise ValueError("hypothesis body must be non-empty")
        if not 0.0 <= float(self.uncertainty) <= 1.0:
            raise ValueError("uncertainty must be within [0, 1]")
        canonical_body, _ = canonicalize_surface_text(str(self.body), direction="system")
        object.__setattr__(self, "body", canonical_body)
        object.__setattr__(self, "_response_sha256", sha256_text(canonical_body))

    @property
    def response_sha256(self) -> str:
        return self._response_sha256

    def binding_payload(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "response_sha256": self.response_sha256,
            "producer": self.producer,
            "assumptions": list(self.assumptions),
            "evidence_refs": list(self.evidence_refs),
            "counterevidence_refs": list(self.counterevidence_refs),
            "uncertainty": float(self.uncertainty),
            "epistemic_mode": str(self.epistemic_mode),
            "preservation_basis": list(self.preservation_basis),
            "qualitative_tensions": list(self.qualitative_tensions),
            "raw_spark_sha256": str(self.raw_spark_sha256),
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True)
class CandidateBundle:
    """A materially distinct hypothesis set preserved without forced convergence."""
    turn_id: str
    release_group_id: str
    candidates: tuple[HypothesisCandidate, ...]
    rationale: str = ""
    evidence: dict[str, Any] = field(default_factory=dict)
    _bundle_sha256: str = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if not str(self.release_group_id).strip():
            raise ValueError("release_group_id must be non-empty")
        if len(self.candidates) < 2:
            raise ValueError("a superposed release group requires at least two materially distinct hypotheses")
        ids = [str(x.candidate_id) for x in self.candidates]
        if len(ids) != len(set(ids)):
            raise ValueError("candidate_id values must be unique inside a release group")
        object.__setattr__(self, "_bundle_sha256", hashlib.sha256(_canonical_json({
            "turn_id": str(self.turn_id),
            "release_group_id": str(self.release_group_id),
            "candidates": [x.binding_payload() for x in self.candidates],
            "rationale": str(self.rationale),
            "evidence": dict(self.evidence),
        })).hexdigest())

    @property
    def bundle_sha256(self) -> str:
        return self._bundle_sha256


@dataclass(frozen=True)
class ReleasedHypothesis:
    candidate_id: str
    body: str
    body_sha256: str
    blob_sha256: str
    blob_size_bytes: int
    integrity_receipt_id: str = ""


@dataclass(frozen=True)
class ReleasedResponseGroup:
    turn_id: str
    release_group_id: str
    bundle_sha256: str
    hypotheses: tuple[ReleasedHypothesis, ...]
    integrity_receipt_id: str = ""
    release_format: str = "direct-cas-group-v1"
