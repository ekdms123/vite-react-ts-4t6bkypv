from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class ProviderCandidate:
    provider_id: str
    capabilities: tuple[str, ...]
    cost_state: str = "unknown"  # free|free_tier|self_hosted|paid|unknown
    open_source: bool = False
    self_hostable: bool = False
    callable: bool = False
    metadata: dict[str, Any] | None = None


class FreeFirstRouter:
    """User policy: paid routes are excluded while a viable free/self-hosted route exists."""

    _rank = {"self_hosted":0, "free":1, "free_tier":2, "unknown":8, "paid":99}

    @classmethod
    def rank(cls, candidates: Iterable[ProviderCandidate], *, required: Iterable[str]=()) -> tuple[ProviderCandidate,...]:
        req=set(map(str,required))
        rows=[]
        for c in candidates:
            if req and not req.issubset(set(c.capabilities)): continue
            rows.append(c)
        rows.sort(key=lambda c:(cls._rank.get(c.cost_state,50), not c.callable, not c.open_source, not c.self_hostable, c.provider_id))
        return tuple(rows)

    @classmethod
    def choose(
        cls,
        candidates: Iterable[ProviderCandidate],
        *,
        required: Iterable[str] = (),
        callable_only: bool = True,
    ) -> ProviderCandidate | None:
        """Choose a zero-spend route that is actually callable by default.

        Older behavior could return an unmaterialized self-hosted candidate ahead of a
        callable free route. That was useful as a planning hint but wrong as an execution
        choice. Planning and execution are now separated: ``rank`` keeps latent routes,
        while ``choose`` defaults to observed-callable candidates only.
        """
        rows = cls.rank(candidates, required=required)
        for c in rows:
            if c.cost_state == "paid":
                continue
            if callable_only and not c.callable:
                continue
            return c
        return None

    @classmethod
    def plan(cls, candidates: Iterable[ProviderCandidate], *, required: Iterable[str] = ()) -> ProviderCandidate | None:
        """Return the best zero-spend materialization candidate, callable or not."""
        return cls.choose(candidates, required=required, callable_only=False)
