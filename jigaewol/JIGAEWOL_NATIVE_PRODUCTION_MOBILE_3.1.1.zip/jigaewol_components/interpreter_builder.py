from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

from .operator_builder import OperatorBuilder


@dataclass(frozen=True)
class InterpreterSpec:
    interpreter_id: str
    representation_ref: str
    operator_ids: tuple[str, ...]
    execution_model: str = "registered_operator_pipeline"

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class InterpreterBuilder:
    """Build, persist and execute interpreters for task-local representations.

    The interpreter registry is deliberately open: an interpreter is identified by the
    representation it serves and the operator program it runs.  Persisting the spec
    means a generated representation is still executable after process restart rather
    than existing only as an in-memory probe.
    """

    def __init__(self, operators: OperatorBuilder, root: str | Path | None = None) -> None:
        self.operators = operators
        self.root = Path(root) if root is not None else operators.root / "interpreters"
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "registry.json"
        if not self.path.exists():
            self.path.write_text("{}\n", encoding="utf-8")

    def build(self, *, representation_ref: str, operator_ids: tuple[str, ...]) -> InterpreterSpec:
        seed = f"{representation_ref}|{'|'.join(operator_ids)}"
        return InterpreterSpec(
            interpreter_id="interpreter_" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:20],
            representation_ref=str(representation_ref),
            operator_ids=tuple(map(str, operator_ids)),
        )

    def register(self, spec: InterpreterSpec) -> InterpreterSpec:
        data = self.snapshot()
        data[spec.interpreter_id] = spec.as_mapping()
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)
        return spec

    def load(self, interpreter_id: str) -> InterpreterSpec:
        row = dict(self.snapshot().get(str(interpreter_id)) or {})
        if not row:
            raise KeyError(f"unknown interpreter: {interpreter_id}")
        return InterpreterSpec(
            interpreter_id=str(row.get("interpreter_id") or interpreter_id),
            representation_ref=str(row.get("representation_ref") or ""),
            operator_ids=tuple(map(str, row.get("operator_ids") or ())),
            execution_model=str(row.get("execution_model") or "registered_operator_pipeline"),
        )

    def snapshot(self) -> dict[str, Any]:
        failure_path = self.root / "interpreter_registry_failures.jsonl"

        def record_failure(kind: str, error: BaseException, *, quarantine: Path | None = None) -> None:
            row = {
                "kind": str(kind),
                "source": str(self.path),
                "error_type": type(error).__name__,
                "error": str(error),
                "quarantine": str(quarantine or ""),
                "created_at": time.time(),
            }
            with failure_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")

        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("interpreter registry must be a JSON object")
            return data
        except OSError as exc:
            record_failure("interpreter_registry_read_failed", exc)
            raise RuntimeError(f"interpreter registry read failed: {exc}") from exc
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            quarantine = self.path.with_name(
                f"{self.path.stem}.corrupt.{time.time_ns()}{self.path.suffix}"
            )
            try:
                self.path.replace(quarantine)
            except OSError as move_error:
                record_failure("interpreter_registry_quarantine_failed", move_error)
                quarantine = self.path
            record_failure("interpreter_registry_corrupt", exc, quarantine=quarantine)
            raise RuntimeError(f"interpreter registry corrupt: {exc}") from exc

    def run_probe(self, spec: InterpreterSpec, payload: Mapping[str, Any]) -> dict[str, Any]:
        state: Any = dict(payload)
        trace = []
        for oid in spec.operator_ids:
            result = self.operators.materialize(oid, state if isinstance(state, Mapping) else {"value": state})
            trace.append({"operator_id": oid, "result": result})
            state = result.get("state_delta", result) if isinstance(result, Mapping) else result
        return {"interpreter_id": spec.interpreter_id, "result": state, "trace": tuple(trace)}

    def run_registered(self, interpreter_id: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        return self.run_probe(self.load(interpreter_id), payload)

    @staticmethod
    def translate_result(result: Mapping[str, Any]) -> dict[str, Any]:
        return {"translated_result": result.get("result"), "evidence": tuple(result.get("trace") or ())}
