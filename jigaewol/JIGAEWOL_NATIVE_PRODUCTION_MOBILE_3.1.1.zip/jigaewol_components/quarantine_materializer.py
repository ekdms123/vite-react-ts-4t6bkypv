from __future__ import annotations

import ast
import base64
import hashlib
import json
import os
import sys
import time
import uuid
import zipfile
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Mapping

from .isolated_executor import IsolatedExecutor


PERMISSIVE_LICENSES = frozenset({"MIT", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "ISC"})


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode("utf-8") + data).hexdigest()


def _safe_relpath(value: str) -> str:
    path = Path(str(value).replace("\\", "/"))
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError(f"unsafe donor path: {value}")
    return path.as_posix()


@dataclass(frozen=True)
class DonorFileEvidence:
    path: str
    sha256: str
    git_blob_sha1: str
    expected_git_blob_sha1: str
    identity_match: bool
    size: int


@dataclass(frozen=True)
class StaticFinding:
    path: str
    line: int
    category: str
    severity: str
    detail: str


@dataclass(frozen=True)
class QuarantineReceipt:
    receipt_id: str
    donor_id: str
    revision: str
    source_dir: str
    workspace: str
    archive_sha256: str
    source_identity_verified: bool
    license_id: str
    license_verified: bool
    static_findings: tuple[StaticFinding, ...]
    file_evidence: tuple[DonorFileEvidence, ...]
    local_execution_allowed: bool
    network_namespace_proven: bool
    state: str
    created_at: float

    def as_mapping(self) -> dict[str, Any]:
        row = asdict(self)
        row["static_findings"] = [asdict(x) for x in self.static_findings]
        row["file_evidence"] = [asdict(x) for x in self.file_evidence]
        return row


@dataclass(frozen=True)
class QuarantineExecutionReceipt:
    execution_id: str
    receipt_id: str
    argv: tuple[str, ...]
    exit_code: int | None
    stdout: str
    stderr: str
    success: bool
    expected_marker_observed: bool
    secret_environment_stripped: bool
    network_namespace_proven: bool
    state: str
    created_at: float

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class QuarantineMaterializer:
    """Evidence-bound bridge from external source bytes to a locally probed donor body.

    Source identity, rights, static effects, isolation capability, execution, and
    promotion are separate truth states. A successful process exit is never enough to
    erase a source-hash mismatch, unknown license, or missing isolation property.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.archives = self.root / "archives"
        self.archives.mkdir(exist_ok=True)
        self.executor = IsolatedExecutor(self.root / "isolated")
        self.receipts_path = self.root / "receipts.jsonl"
        self.executions_path = self.root / "executions.jsonl"
        self.promotions_path = self.root / "promotions.jsonl"

    @staticmethod
    def _static_scan(path: Path, rel: str) -> tuple[StaticFinding, ...]:
        if path.suffix.casefold() != ".py":
            return ()
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
        except SyntaxError as exc:
            return (StaticFinding(rel, int(exc.lineno or 0), "syntax_error", "critical", str(exc)),)
        findings: list[StaticFinding] = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names = [a.name for a in node.names] if isinstance(node, ast.Import) else [str(node.module or "")]
                for name in names:
                    root_name = name.split(".", 1)[0]
                    if root_name in {"socket", "requests", "urllib", "httpx", "aiohttp"}:
                        findings.append(StaticFinding(rel, getattr(node, "lineno", 0), "network_surface", "medium", root_name))
                    if root_name in {"subprocess", "multiprocessing"}:
                        findings.append(StaticFinding(rel, getattr(node, "lineno", 0), "process_surface", "medium", root_name))
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in {"eval", "exec", "compile"}:
                    findings.append(StaticFinding(rel, getattr(node, "lineno", 0), "dynamic_code_execution", "high", node.func.id))
                if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
                    pair = f"{node.func.value.id}.{node.func.attr}"
                    if pair in {"os.system", "os.popen", "subprocess.run", "subprocess.Popen", "subprocess.call"}:
                        findings.append(StaticFinding(rel, getattr(node, "lineno", 0), "process_execution", "high", pair))
        return tuple(findings)

    @staticmethod
    def _archive_manifest(source_dir: Path, destination: Path, relpaths: Iterable[str]) -> None:
        """Archive only identity-verified manifest members, never ambient source-tree files."""
        with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for rel in sorted(set(map(str, relpaths))):
                safe = _safe_relpath(rel)
                path = (source_dir / safe).resolve()
                if source_dir not in path.parents or not path.is_file() or path.is_symlink():
                    continue
                zf.write(path, safe)

    def materialize_host_bundle(
        self,
        bundle: Mapping[str, Any],
    ) -> tuple[Path, dict[str, str], str, str, str, tuple[dict[str, Any], ...]]:
        """Materialize host-fetched file bytes into a content-addressed intake directory.

        The host connector remains responsible for retrieval/authentication.  This method
        accepts only explicit file bytes plus their expected Git blob IDs and preserves
        source refs for audit.  It never downloads URLs itself and never treats a host
        label as proof of byte identity.
        """
        donor_id = str(bundle.get("donor_id") or "").strip()
        revision = str(bundle.get("revision") or "").strip()
        license_id = str(bundle.get("license_id") or "").strip()
        license_path = _safe_relpath(str(bundle.get("license_path") or "LICENSE"))
        if not donor_id or not revision or not license_id:
            raise ValueError("bundle requires donor_id, revision, and license_id")
        rows = list(bundle.get("files") or ())
        if not rows:
            raise ValueError("bundle requires at least one file")
        bundle_key = _sha256(json.dumps([donor_id, revision, [(x.get("path"), x.get("git_blob_sha1")) for x in rows]], ensure_ascii=False, sort_keys=True).encode("utf-8"))[:20]
        stage = self.root / "host_intake" / f"bundle_{bundle_key}"
        if stage.exists():
            import shutil
            shutil.rmtree(stage)
        stage.mkdir(parents=True, exist_ok=False)
        expected: dict[str, str] = {}
        source_refs: list[dict[str, Any]] = []
        for row in rows:
            rel = _safe_relpath(str(row.get("path") or ""))
            if rel in expected:
                raise ValueError(f"duplicate bundle path: {rel}")
            expected_blob = str(row.get("git_blob_sha1") or "").strip().lower()
            if len(expected_blob) != 40 or any(c not in "0123456789abcdef" for c in expected_blob):
                raise ValueError(f"invalid git blob sha1 for {rel}")
            has_text = "content" in row and row.get("content") is not None
            has_b64 = "content_base64" in row and row.get("content_base64") is not None
            if has_text == has_b64:
                raise ValueError(f"bundle file {rel} must provide exactly one of content or content_base64")
            if has_b64:
                try:
                    payload = base64.b64decode(str(row.get("content_base64") or ""), validate=True)
                except Exception as exc:
                    raise ValueError(f"invalid base64 content for {rel}") from exc
            else:
                payload = str(row.get("content") or "").encode("utf-8")
            target = (stage / rel).resolve()
            if stage.resolve() not in target.parents:
                raise ValueError(f"bundle path escaped intake root: {rel}")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
            expected[rel] = expected_blob
            source_refs.append({
                "path": rel,
                "source_ref": str(row.get("source_ref") or ""),
                "expected_git_blob_sha1": expected_blob,
                "observed_git_blob_sha1": _git_blob_sha1(payload),
                "sha256": _sha256(payload),
                "size": len(payload),
            })
        if license_path not in expected:
            raise ValueError("license_path must be included in bundle files and identity-pinned")
        intake = {
            "schema": "jigaewol_host_donor_intake_v1",
            "donor_id": donor_id,
            "revision": revision,
            "license_id": license_id,
            "license_path": license_path,
            "files": source_refs,
            "created_at": time.time(),
        }
        intake_path = self.root / "host_intake_receipts.jsonl"
        with intake_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(intake, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return stage, expected, donor_id, revision, license_id, tuple(source_refs)

    def inspect_host_bundle(self, bundle: Mapping[str, Any]) -> QuarantineReceipt:
        stage, expected, donor_id, revision, license_id, _refs = self.materialize_host_bundle(bundle)
        license_path = _safe_relpath(str(bundle.get("license_path") or "LICENSE"))
        return self.inspect_directory(
            stage, donor_id=donor_id, revision=revision, expected_git_blobs=expected,
            license_id=license_id, license_path=license_path, expected_license_git_blob=expected[license_path],
        )

    def inspect_directory(
        self,
        source_dir: str | Path,
        *,
        donor_id: str,
        revision: str,
        expected_git_blobs: Mapping[str, str],
        license_id: str,
        license_path: str = "LICENSE",
        expected_license_git_blob: str = "",
    ) -> QuarantineReceipt:
        source = Path(source_dir).resolve()
        if not source.is_dir():
            raise FileNotFoundError(source)
        file_rows: list[DonorFileEvidence] = []
        static: list[StaticFinding] = []
        expected_paths = {_safe_relpath(k) for k in expected_git_blobs}
        license_rel = _safe_relpath(license_path)
        admitted_paths = set(expected_paths) | {license_rel}
        observed_paths: set[str] = set()
        for candidate in sorted(source.rglob("*")):
            if "__pycache__" in candidate.parts or not candidate.is_file():
                continue
            try:
                rel = candidate.relative_to(source).as_posix()
            except ValueError:
                continue
            observed_paths.add(rel)
            if candidate.is_symlink():
                static.append(StaticFinding(rel, 0, "symlink_source_file", "high", "symlinked donor file is not admitted"))
            elif rel not in admitted_paths:
                static.append(StaticFinding(rel, 0, "unverified_extra_file", "high", "file is outside the identity-pinned donor manifest"))
        all_match = bool(expected_git_blobs)
        for raw_rel, expected in sorted(expected_git_blobs.items()):
            rel = _safe_relpath(raw_rel)
            path = (source / rel).resolve()
            if source not in path.parents:
                raise ValueError(f"donor file escaped source root: {rel}")
            if not path.is_file():
                file_rows.append(DonorFileEvidence(rel, "", "", str(expected), False, 0))
                all_match = False
                continue
            payload = path.read_bytes()
            blob = _git_blob_sha1(payload)
            match = blob == str(expected)
            all_match = all_match and match
            file_rows.append(DonorFileEvidence(rel, _sha256(payload), blob, str(expected), match, len(payload)))
            static.extend(self._static_scan(path, rel))

        license_file = (source / license_rel).resolve()
        license_blob = _git_blob_sha1(license_file.read_bytes()) if license_file.is_file() else ""
        license_verified = bool(
            license_id in PERMISSIVE_LICENSES
            and license_file.is_file()
            and (not expected_license_git_blob or license_blob == expected_license_git_blob)
        )
        high_risk = any(x.severity in {"critical", "high"} for x in static)
        local_allowed = bool(all_match and license_verified and not high_risk)

        archive = self.archives / f"{uuid.uuid4().hex}.zip"
        self._archive_manifest(source, archive, admitted_paths)
        workspace, preflight = self.executor.materialize(archive)
        capability = self.executor.isolation_capability()
        receipt = QuarantineReceipt(
            receipt_id="quarantine_" + uuid.uuid4().hex[:20],
            donor_id=str(donor_id), revision=str(revision), source_dir=str(source), workspace=str(workspace),
            archive_sha256=preflight.archive_sha256, source_identity_verified=all_match,
            license_id=str(license_id), license_verified=license_verified,
            static_findings=tuple(static), file_evidence=tuple(file_rows),
            local_execution_allowed=local_allowed,
            network_namespace_proven=capability.network_namespace_proven,
            state="reviewed_staged" if local_allowed else "blocked_open",
            created_at=time.time(),
        )
        with self.receipts_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(receipt.as_mapping(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return receipt

    def _load_receipt(self, receipt_id: str) -> QuarantineReceipt:
        if not self.receipts_path.is_file():
            raise KeyError(receipt_id)
        for line in reversed(self.receipts_path.read_text(encoding="utf-8").splitlines()):
            row = json.loads(line)
            if row.get("receipt_id") == receipt_id:
                return QuarantineReceipt(
                    **{k: v for k, v in row.items() if k not in {"static_findings", "file_evidence"}},
                    static_findings=tuple(StaticFinding(**x) for x in row.get("static_findings") or ()),
                    file_evidence=tuple(DonorFileEvidence(**x) for x in row.get("file_evidence") or ()),
                )
        raise KeyError(receipt_id)

    def execute_probe(
        self,
        receipt_id: str,
        argv: Iterable[str],
        *,
        cwd: str = "",
        expected_stdout_contains: str = "",
        timeout: float = 20.0,
        network_needed: bool = False,
    ) -> QuarantineExecutionReceipt:
        receipt = self._load_receipt(receipt_id)
        args = tuple(str(x) for x in argv)
        if not receipt.local_execution_allowed:
            result = QuarantineExecutionReceipt(
                execution_id="qexec_" + uuid.uuid4().hex[:20], receipt_id=receipt_id, argv=args,
                exit_code=None, stdout="", stderr="source/license/static gate not satisfied",
                success=False, expected_marker_observed=False, secret_environment_stripped=False,
                network_namespace_proven=False, state="blocked_open", created_at=time.time(),
            )
        elif network_needed and not receipt.network_namespace_proven:
            result = QuarantineExecutionReceipt(
                execution_id="qexec_" + uuid.uuid4().hex[:20], receipt_id=receipt_id, argv=args,
                exit_code=None, stdout="", stderr="network namespace not proven; stronger body required",
                success=False, expected_marker_observed=False, secret_environment_stripped=False,
                network_namespace_proven=False, state="blocked_open", created_at=time.time(),
            )
        else:
            observed = self.executor.run(
                receipt.workspace, args, cwd=cwd, timeout=timeout,
                trust_level="reviewed", network_needed=network_needed,
            )
            marker_ok = (not expected_stdout_contains) or (expected_stdout_contains in str(observed.get("stdout") or ""))
            success = bool(observed.get("success") and marker_ok)
            result = QuarantineExecutionReceipt(
                execution_id="qexec_" + uuid.uuid4().hex[:20], receipt_id=receipt_id, argv=args,
                exit_code=int(observed.get("exit_code")) if observed.get("exit_code") is not None else None,
                stdout=str(observed.get("stdout") or ""), stderr=str(observed.get("stderr") or ""),
                success=success, expected_marker_observed=marker_ok,
                secret_environment_stripped=bool(observed.get("secret_environment_stripped")),
                network_namespace_proven=bool(observed.get("network_namespace_proven")),
                state="probe_successful" if success else "probe_failed_open", created_at=time.time(),
            )
        with self.executions_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(result.as_mapping(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return result

    def promote(self, receipt_id: str, execution: QuarantineExecutionReceipt, *, effect: str) -> dict[str, Any]:
        receipt = self._load_receipt(receipt_id)
        promotable = bool(
            receipt.source_identity_verified and receipt.license_verified and receipt.local_execution_allowed
            and execution.receipt_id == receipt_id and execution.success
        )
        row = {
            "promotion_id": "qprom_" + uuid.uuid4().hex[:20],
            "receipt_id": receipt_id,
            "execution_id": execution.execution_id,
            "effect": str(effect),
            "state": "proven_donor_body" if promotable else "blocked_open",
            "source_identity_verified": receipt.source_identity_verified,
            "license_verified": receipt.license_verified,
            "execution_success": execution.success,
            "network_namespace_proven": execution.network_namespace_proven,
            "claim_boundary": "donor behavior is proven only for the executed probe; broader capability requires additional effect-specific evidence",
            "created_at": time.time(),
        }
        with self.promotions_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return row
