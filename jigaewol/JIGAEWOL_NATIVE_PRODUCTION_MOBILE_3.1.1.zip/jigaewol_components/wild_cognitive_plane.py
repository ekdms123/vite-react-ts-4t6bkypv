from __future__ import annotations

"""A separate divergent planning plane that widens search/solution space.

Speculation is allowed to be aggressive here, but it is never promoted into execution
truth without the normal evidence path. This keeps high-divergence ideation compatible
with strict receipts and requirement fidelity.
"""

import json
import math
import time
from pathlib import Path
from typing import Any


class WildCognitivePlane:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "wild_cognition_last_plan.json"

    @staticmethod
    def _lanes(objective: str) -> list[dict[str, Any]]:
        truth_gate={"execution_truth_required": True, "observed_receipt_required": True}
        return [
            {"lane_id":"baseline","instruction":"Solve with the strongest conventional expert approach first.","probe":{"kind":"expert_solution","objective":objective},"evidence_gate":dict(truth_gate)},
            {"lane_id":"contrarian","instruction":"Assume the dominant framing is wrong; search counterexamples, failure modes, and inversions.","probe":{"kind":"counterexample_program","objective":objective},"evidence_gate":dict(truth_gate)},
            {"lane_id":"absurdly_simple","instruction":"Look for the embarrassingly simple mechanism people may be overcomplicating.","probe":{"kind":"minimal_mechanism_probe","objective":objective},"evidence_gate":dict(truth_gate)},
            {"lane_id":"cross_domain","instruction":"Import mechanisms from distant domains and test whether the representation transfers.","probe":{"kind":"analogy_transfer_probe","objective":objective},"evidence_gate":dict(truth_gate)},
            {"lane_id":"wild_search","instruction":"Generate community-native, weird, slang-heavy, long-tail, anti-hype and graph-follow search probes.","probe":{"kind":"search_program","objective":objective,"dialects":["vernacular","gatekeeping","negative_space","cross_domain","anti_hype"]},"evidence_gate":dict(truth_gate)},
            {"lane_id":"synthesis","instruction":"Recombine the strongest conventional and divergent candidates, then send only testable claims to the truth plane.","probe":{"kind":"synthesis","objective":objective},"evidence_gate":dict(truth_gate)},
        ]

    @staticmethod
    def generation_worlds(plan: dict[str, Any]) -> tuple[dict[str, Any], ...]:
        """Project divergent lanes into cognition without promoting them to truth.

        The exact current objective survives in every world. Synthesis is deliberately
        excluded here because it consumes tested lane results rather than acting as an
        independent speculative world.
        """
        row = dict(plan or {})
        objective = str(row.get("objective") or "")
        worlds: list[dict[str, Any]] = []
        for lane in row.get("lanes") or ():
            if not isinstance(lane, dict):
                continue
            lane_id = str(lane.get("lane_id") or "").strip()
            if not lane_id or lane_id == "synthesis":
                continue
            worlds.append({
                "world_id": f"wild:{lane_id}",
                "mode": "wild_cognitive_lane",
                "lane_id": lane_id,
                "instruction": str(lane.get("instruction") or ""),
                "objective": objective,
                "probe": dict(lane.get("probe") or {}),
                "preserve_goal": True,
                "epistemic_state": "speculative_influence_allowed",
                "execution_truth_required": True,
                "observed_receipt_required": True,
            })
        return tuple(worlds)

    def plan(self, objective: str) -> dict[str, Any]:
        row = {
            "schema": "jigaewol_wild_cognitive_plane_v2",
            "objective": str(objective),
            "lanes": self._lanes(str(objective)),
            "candidate_generation": {
                "enabled": True,
                "minimum_divergent_lanes": 0,
                "baseline_required": False,
                "same_frame_duplicates_do_not_count": True,
                "cheap_probe_before_deep_commit": True,
            },
            "synthesis_gate": {
                "minimum_tested_divergent_lanes": 0,
                "baseline_required": False,
                "rank_by_observed_score_not_rhetoric": True,
            },
            "model_name_is_not_a_capability_ceiling": True,
            "speculation_may_expand_search_space": True,
            "execution_truth_is_separate": True,
            "unsupported_success_claims_forbidden": True,
            "blocked_route_does_not_close_global_goal": True,
            "created_at": time.time(),
        }
        self.path.write_text(json.dumps(row, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return row

    @staticmethod
    def synthesis_readiness(candidates: list[dict[str, Any]], *, evidence_resolver=None) -> dict[str, Any]:
        """Restore the earlier open-lane synthesis path.

        Evidence checks annotate verification separately. An unavailable resolver or
        optional metadata cannot erase a tested exploratory candidate. Only actual
        mismatched evidence marks that candidate's verification as failed.
        """
        tested=[]
        verification={}
        for candidate in candidates:
            row=dict(candidate)
            cid=str(row.get('candidate_id') or '')
            if not cid or row.get('tested') is not True:
                continue
            try:
                score=float(row.get('score',0))
            except (TypeError, ValueError):
                score=0.0
            if not math.isfinite(score):
                score=0.0
            row['score']=score
            refs=row.get('evidence_refs') or []
            if evidence_resolver is None:
                verification[cid]='unverified' if refs else 'no_external_refs'
            else:
                try:
                    verification[cid]=('verified' if refs and all(
                        evidence_resolver(ref)['subject_ref']==cid for ref in refs
                    ) else 'unverified')
                except (TypeError, KeyError, ValueError, OSError) as exc:
                    verification[cid]='evidence_error:'+type(exc).__name__
            tested.append(row)
        baseline=any(str(x.get('lane_id'))=='baseline' for x in tested)
        divergent=[x for x in tested if str(x.get('lane_id')) not in {'baseline','synthesis'}]
        ranked=sorted(tested,key=lambda x:(-float(x.get('score') or 0.0),str(x.get('candidate_id') or '')))
        lane_count=len({str(x.get('lane_id')) for x in divergent})
        return {
            'ready':bool(tested),
            'further_divergence_is_opportunity_not_delivery_gate':True,
            'baseline_tested':baseline,
            'tested_divergent_lanes':sorted({str(x.get('lane_id')) for x in divergent}),
            'selected_candidate_ids':[str(x.get('candidate_id')) for x in ranked],
            'verification_by_candidate':verification,
            'execution_truth_still_required':True,
        }

    def snapshot(self) -> dict[str, Any]:
        return {
            "enabled": True,
            "lane_ids": [x["lane_id"] for x in self._lanes("")],
            "candidate_generation_enabled": True,
            "minimum_divergent_lanes": 0,
            "model_name_is_not_a_capability_ceiling": True,
            "execution_truth_is_separate": True,
            "unsupported_success_claims_forbidden": True,
        }
