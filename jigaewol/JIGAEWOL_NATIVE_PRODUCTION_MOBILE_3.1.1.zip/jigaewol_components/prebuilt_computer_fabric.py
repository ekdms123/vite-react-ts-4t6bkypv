from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .browser_plane import BrowserPlane
from .compute_profile import ComputeProfileDetector
from .execution_plane import ExecutionPlane
from .host_capabilities import HostCapabilityDiscovery
from .host_identity import current_host_fingerprint
from .image_capability import ImageInspectionComponent
from .synthetic_workstation import SyntheticWorkstation
from .terminal_backplane import TerminalBackplane


@dataclass(frozen=True)
class ComputerFabricSnapshot:
    prepared_at: float
    host_fingerprint: str
    baseline_components: tuple[str, ...]
    baseline_semantics: str
    path_executable_count: int
    python_module_count: int
    executed_probe_count: int
    successful_probe_count: int
    failed_probe_count: int
    compute_profile: dict[str, Any]
    warm_receipts: dict[str, Any]
    reports: dict[str, str]


class PrebuiltComputerFabric:
    """Prepares reusable execution components in advance to ensure fast readiness.

    Maintains an open baseline floor while discovery keeps the execution universe
    open to newly found tools and substrates.
    """

    @staticmethod
    def baseline_components() -> tuple[str, ...]:
        return (
            "process_execution", "persistent_workspace", "filesystem", "archives",
            "source_control", "network_retrieval", "code_runtimes", "browser_automation",
            "browser_perception", "image_processing", "ocr", "audio_video_media",
            "persistent_services", "checkpoint_resume", "host_surface_discovery",
            "open_world_extension",
        )

    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.workstation = SyntheticWorkstation(self.root / "workstation")
        self.terminal = TerminalBackplane(self.root / "terminal")
        self.discovery = HostCapabilityDiscovery(self.root)
        self.snapshot_path = self.root / "computer_fabric_snapshot.json"

    def read_snapshot(self) -> dict[str, Any] | None:
        if not self.snapshot_path.exists():
            return None
        try:
            return json.loads(self.snapshot_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None

    def ensure_prepared(self, *, max_age_s: float = 21600.0) -> dict[str, Any]:
        prior = self.read_snapshot()
        now = time.time()
        if prior:
            same_host = str(prior.get("host_fingerprint", "")) == current_host_fingerprint()
            fresh = now - float(prior.get("prepared_at", 0.0)) <= float(max_age_s)
            if same_host and fresh:
                return prior
        return asdict(self.prepare())

    def _warm_browser(self) -> dict[str, Any]:
        try:
            receipt = BrowserPlane(self.root / "browser").render_html(
                "<html><head><title>JIGAEWOL fabric ready</title></head><body>ready</body></html>",
                screenshot=False,
                headless=True,
            )
            return {"executed": True, "success": True, "receipt_id": receipt.receipt_id, "title": receipt.title}
        except Exception as exc:
            return {"executed": True, "success": False, "error": f"{type(exc).__name__}: {exc}"}

    def _warm_image(self) -> dict[str, Any]:
        try:
            from PIL import Image
            sample = self.root / "warm_sample.png"
            Image.new("RGB", (2, 2), (255, 255, 255)).save(sample)
            component = ImageInspectionComponent(self.root)
            pillow, ocr = component.install()
            plane = ExecutionPlane(self.root / "workspace")
            receipt = plane.run_resilient(component.build_request(sample, ocr=False), persist_cwd=False)
            return {
                "executed": True,
                "success": receipt.exit_code == 0,
                "receipt_id": receipt.receipt_id,
                "exit_code": receipt.exit_code,
                "pillow_capability": pillow.capability_id,
                "ocr_available": ocr is not None,
            }
        except Exception as exc:
            return {"executed": True, "success": False, "error": f"{type(exc).__name__}: {exc}"}

    def prepare(self) -> ComputerFabricSnapshot:
        path_inventory = self.discovery.inventory_path_executables()
        module_inventory = self.discovery.inventory_python_modules()
        probes = self.discovery.probe()
        compute = asdict(ComputeProfileDetector().detect())
        warm = {"browser": self._warm_browser(), "image": self._warm_image()}
        reports_dir = self.root / "reports"
        reports_dir.mkdir(exist_ok=True)
        path_report = reports_dir / "path_executables.json"
        module_report = reports_dir / "python_modules.json"
        probe_report = reports_dir / "executed_baseline_probes.json"
        path_report.write_text(json.dumps(path_inventory, ensure_ascii=False, indent=2), encoding="utf-8")
        module_report.write_text(json.dumps(module_inventory, ensure_ascii=False, indent=2), encoding="utf-8")
        probe_report.write_text(json.dumps([asdict(x) for x in probes], ensure_ascii=False, indent=2), encoding="utf-8")
        success = sum(1 for x in probes if x.present and x.exit_code == 0)
        failed = sum(1 for x in probes if x.present and x.exit_code not in (None, 0))
        snapshot = ComputerFabricSnapshot(
            prepared_at=time.time(),
            host_fingerprint=current_host_fingerprint(),
            baseline_components=self.baseline_components(),
            baseline_semantics="prebuilt_floor_not_closed_world_ceiling",
            path_executable_count=len(path_inventory),
            python_module_count=len(module_inventory),
            executed_probe_count=sum(1 for x in probes if x.receipt_id is not None),
            successful_probe_count=success,
            failed_probe_count=failed,
            compute_profile=compute,
            warm_receipts=warm,
            reports={"path_executables": str(path_report), "python_modules": str(module_report), "baseline_probes": str(probe_report)},
        )
        self.snapshot_path.write_text(json.dumps(asdict(snapshot), ensure_ascii=False, indent=2), encoding="utf-8")
        return snapshot
