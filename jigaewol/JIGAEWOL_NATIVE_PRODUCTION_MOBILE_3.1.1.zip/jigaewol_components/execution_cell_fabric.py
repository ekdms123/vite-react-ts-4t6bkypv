from __future__ import annotations

"""Compose a workstation-like runtime from replaceable, evidence-bound execution cells.

A resident body does not have to be one immortal machine.  The durable primitive is
verified continuity: state/checkpoints may persist in one provider while compute,
browser, repository and delegate cells are leased independently and re-probed before
reuse.  This module keeps that representation explicit and never promotes a body from
catalog visibility alone.
"""

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable, Mapping

from .body_federation import BodyFederationRegistry, FederatedBody
from .semantic_authority import bind_semantic_authority
from .authority_guard import source_effect_authorized
from jigaewol_runtime.capabilities.execution_routes import infer_required_traits


def _slug(value: str) -> str:
    text = re.sub(r"[^a-z0-9가-힣]+", "_", str(value or "").casefold()).strip("_")
    return text or "unknown"


def _sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ExecutionCell:
    cell_id: str
    body_id: str
    executor: str
    traits: tuple[str, ...]
    continuity_kind: str
    isolation_kind: str
    state: str
    zero_incremental_cost: bool | None
    evidence_strength: float
    origin_ref: str
    observed_at: float
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ResidentComposition:
    composition_id: str
    required_traits: tuple[str, ...]
    covered_traits: tuple[str, ...]
    missing_traits: tuple[str, ...]
    cell_ids: tuple[str, ...]
    slot_bindings: dict[str, tuple[str, ...]]
    continuity_model: str
    ready: bool
    zero_cost_only: bool
    truth_boundary: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


_CANONICAL_TERM_TRAITS = {
    "compute": {"code_execution"},
    "code_execution": {"code_execution"},
    "run_commands": {"code_execution", "terminal"},
    "terminal": {"terminal", "code_execution"},
    "shell": {"terminal", "code_execution"},
    "vm": {"code_execution", "remote_compute"},
    "remote_computer": {"remote_computer", "code_execution", "filesystem"},
    "filesystem": {"filesystem"},
    "files": {"filesystem"},
    "workspace": {"persistent_workspace"},
    "persistent_workspace": {"persistent_workspace"},
    "repository": {"repository", "persistent_workspace"},
    "code_repository": {"repository", "persistent_workspace"},
    "knowledge_base": {"knowledge_base", "persistent_workspace"},
    "network": {"network"},
    "network_access": {"network"},
    "browser": {"browser", "interaction"},
    "authenticated_session": {"authenticated_session", "browser"},
    "login": {"authenticated_session", "browser"},
    "interaction": {"interaction"},
    "automation": {"automation"},
    "agent_delegate": {"agent_delegate"},
    "subagent": {"agent_delegate"},
    "deploy": {"deploy"},
    "deployment": {"deploy"},
}


_CAPABILITY_TRAITS = {
    "compute:remote_exec": {"code_execution", "terminal", "remote_compute"},
    "terminal:exec": {"terminal", "code_execution"},
    "workspace:persistent": {"persistent_workspace", "filesystem"},
    "browser:signed_in_observe": {"browser", "authenticated_session", "interaction"},
    "browser:interact": {"browser", "interaction"},
    "cognition:parallel_delegate": {"agent_delegate"},
    "automation:continuity": {"automation"},
    "search:code_ecosystem": {"repository"},
    "search:personal_knowledge": {"knowledge_base", "persistent_workspace"},
}


def _walk_terms(body: FederatedBody) -> tuple[str, ...]:
    values: list[str] = [body.executor, body.body_id, *body.families, *body.capabilities]
    evidence = dict(body.evidence or {})
    manifest = evidence.get("manifest")
    if isinstance(manifest, Mapping):
        values.extend(str(x) for x in (manifest.get("tags") or ()) if str(x).strip())
        values.extend(str(x) for x in (manifest.get("traits") or ()) if str(x).strip())
        for key in ("role", "description", "id"):
            if manifest.get(key):
                values.append(str(manifest[key]))
    values.extend(str(x) for x in (evidence.get("traits") or ()) if str(x).strip())
    values.extend(str(x) for x in (evidence.get("action_ids") or ()) if str(x).strip())
    return tuple(values)


def traits_for_body(body: FederatedBody) -> tuple[str, ...]:
    traits: set[str] = set()
    for cap in body.capabilities:
        traits.update(_CAPABILITY_TRAITS.get(str(cap), ()))
        if ":" in str(cap):
            traits.add(str(cap).split(":", 1)[0])
    for raw in _walk_terms(body):
        slug = _slug(raw)
        # Preserve an opaque trace of unknown host concepts so the current map is
        # not mistaken for the territory.  Canonical traits are added only when a
        # concrete term witnesses them.
        traits.add("host_term:" + slug)
        for term, mapped in _CANONICAL_TERM_TRAITS.items():
            if term in slug:
                traits.update(mapped)
    low = (body.executor + " " + body.body_id).casefold()
    if "floot" in low:
        traits.update({"remote_compute", "code_execution", "terminal", "persistent_workspace", "filesystem", "network"})
    if "container" in low:
        traits.update({"code_execution", "terminal", "filesystem", "session_local"})
    if "github" in low:
        traits.update({"repository", "persistent_workspace", "versioned_state"})
    if "notion" in low or "google_drive" in low or "google drive" in low:
        traits.update({"knowledge_base", "persistent_workspace"})
    if "tinyfish" in low or "opera" in low:
        traits.update({"browser", "interaction", "authenticated_session"})
    return tuple(sorted(traits))


def _continuity_kind(traits: set[str]) -> str:
    if "remote_computer" in traits:
        return "remote_machine_handle"
    if "authenticated_session" in traits and "browser" in traits:
        return "provider_session_handle"
    if "persistent_workspace" in traits or "versioned_state" in traits:
        return "provider_workspace_checkpoint"
    return "ephemeral_rehydratable_cell"


def _isolation_kind(body: FederatedBody, traits: set[str]) -> str:
    evidence = dict(body.evidence or {})
    if "floot" in (body.executor + body.body_id).casefold():
        return "provider_isolated_remote_vm"
    if "session_local" in traits:
        return "host_session_ephemeral"
    if "browser" in traits:
        return "provider_browser_boundary"
    if evidence.get("sandboxed") is True or evidence.get("isolated") is True:
        return "provider_declared_isolation"
    return "provider_boundary_unclassified"


class ExecutionCellFabric:
    """Open-set composition over *observed callable* bodies.

    The fabric does not require one provider to satisfy the whole workstation.
    It greedily composes cells by required-trait coverage while preferring proven
    zero-incremental-cost and stronger evidence.  Unknown cost is deferable rather
    than an automatic impossibility unless ``zero_cost_only`` is explicit.
    """

    def __init__(self, registry: BodyFederationRegistry) -> None:
        self.registry = registry

    def cells(
        self, *, max_age_seconds: float | None = 1800.0, now: float | None = None
    ) -> tuple[ExecutionCell, ...]:
        rows: list[ExecutionCell] = []
        ts = __import__("time").time() if now is None else float(now)
        for body in self.registry.bodies():
            if body.state not in self.registry.CALLABLE_STATES:
                continue
            age = max(0.0, ts - float(body.observed_at or 0.0))
            if max_age_seconds is not None and age > float(max_age_seconds):
                continue
            traits = set(traits_for_body(body))
            rows.append(ExecutionCell(
                cell_id="cell:" + body.body_id,
                body_id=body.body_id,
                executor=body.executor,
                traits=tuple(sorted(traits)),
                continuity_kind=_continuity_kind(traits),
                isolation_kind=_isolation_kind(body, traits),
                state=body.state,
                zero_incremental_cost=body.zero_incremental_cost,
                evidence_strength=body.evidence_strength,
                origin_ref=body.origin_ref,
                observed_at=body.observed_at,
                metadata={
                    "capabilities": body.capabilities,
                    "families": body.families,
                    "unknown_host_terms_preserved": tuple(x for x in traits if x.startswith("host_term:")),
                    "age_seconds": age,
                    "freshness_window_seconds": max_age_seconds,
                    "reprobe_required_after_expiry": max_age_seconds is not None,
                },
            ))
        return tuple(rows)

    @staticmethod
    def _resident_floor(task: str) -> set[str]:
        text = str(task or "").casefold()
        markers = (
            "resident", "body", "runtime", "execution environment", "computer", "terminal",
            "원격", "컴퓨터", "실행 환경", "실행환경", "터미널", "개발", "구현", "코드 수정",
        )
        if any(x in text for x in markers):
            floor = {"code_execution", "filesystem", "persistent_workspace"}
            if any(x in text for x in ("원격", "remote", "remote body", "remote execution")):
                floor.add("remote_compute")
            return floor
        return set()

    def plan(
        self, task: str, *, required_traits: Iterable[str] = (),
        semantic_authority: Mapping[str, Any] | None = None,
        zero_cost_only: bool = False,
    ) -> ResidentComposition:
        authority = bind_semantic_authority(task, semantic_authority)
        required = set(str(x) for x in required_traits if str(x).strip())
        trait_hints = set()
        if authority:
            trait_hints.update(str(x) for x in authority.get("required_capability_traits", ()) if str(x).strip())
            if source_effect_authorized(authority):
                required.update(trait_hints)
        else:
            # Standalone callers may infer hints, but without canonical source-effect
            # authority those hints do not become mandatory execution cells.
            trait_hints.update(infer_required_traits(task))
        # With a canonical semantic authority, do not widen the actuator need by
        # reparsing raw nouns such as "구현"/"개발". Legacy standalone callers retain
        # the resident-floor heuristic for backward compatibility.
        if not authority:
            required.update(self._resident_floor(task))
        cells = list(self.cells(max_age_seconds=1800.0))
        uncovered = set(required)
        selected: list[ExecutionCell] = []
        unused = list(cells)
        while uncovered:
            candidates = []
            for cell in unused:
                if zero_cost_only and cell.zero_incremental_cost is not True:
                    continue
                gain = uncovered & set(cell.traits)
                if not gain:
                    continue
                cost_rank = 2 if cell.zero_incremental_cost is True else (1 if cell.zero_incremental_cost is None else 0)
                continuity_rank = 1 if cell.continuity_kind != "ephemeral_rehydratable_cell" else 0
                candidates.append((len(gain), cost_rank, continuity_rank, cell.evidence_strength, cell.cell_id, cell, gain))
            if not candidates:
                break
            _, _, _, _, _, chosen, gain = max(candidates, key=lambda x: (x[0], x[1], x[2], x[3], x[4]))
            selected.append(chosen)
            uncovered -= set(gain)
            unused = [x for x in unused if x.cell_id != chosen.cell_id]
        covered = required - uncovered
        slots: dict[str, list[str]] = {"compute": [], "state": [], "browser": [], "delegate": [], "other": []}
        for cell in selected:
            traits = set(cell.traits)
            if traits & {"code_execution", "terminal", "remote_compute", "remote_computer"}:
                slots["compute"].append(cell.cell_id)
            if traits & {"persistent_workspace", "versioned_state", "knowledge_base", "repository"}:
                slots["state"].append(cell.cell_id)
            if "browser" in traits:
                slots["browser"].append(cell.cell_id)
            if "agent_delegate" in traits:
                slots["delegate"].append(cell.cell_id)
            if not any(cell.cell_id in xs for key, xs in slots.items() if key != "other"):
                slots["other"].append(cell.cell_id)
        material = {
            "required": sorted(required), "selected": [x.cell_id for x in selected],
            "covered": sorted(covered), "missing": sorted(uncovered), "zero_cost_only": bool(zero_cost_only),
        }
        return ResidentComposition(
            composition_id="resident_" + _sha(material)[:20],
            required_traits=tuple(sorted(required)),
            covered_traits=tuple(sorted(covered)),
            missing_traits=tuple(sorted(uncovered)),
            cell_ids=tuple(x.cell_id for x in selected),
            slot_bindings={k: tuple(v) for k, v in slots.items() if v},
            continuity_model="verified_checkpoint_rehydrate_replaceable_execution_cells",
            ready=not uncovered,
            zero_cost_only=bool(zero_cost_only),
            truth_boundary="composition is a route plan over observed callable bodies; each effect still requires a host execution receipt",
        )

    def snapshot(
        self, task: str, *, semantic_authority: Mapping[str, Any] | None = None,
        zero_cost_only: bool = False,
    ) -> dict[str, Any]:
        cells = self.cells(max_age_seconds=1800.0)
        all_callable = self.cells(max_age_seconds=None)
        plan = self.plan(task, semantic_authority=semantic_authority, zero_cost_only=zero_cost_only)
        return {
            "schema": "jigaewol_execution_cell_fabric_v1",
            "cell_count": len(cells),
            "stale_callable_cell_count": max(0, len(all_callable) - len(cells)),
            "cells": tuple(x.as_mapping() for x in cells),
            "resident_composition": plan.as_mapping(),
            "single_machine_required": False,
            "process_identity_required_for_continuity": False,
            "unknown_host_terms_preserved": True,
        }
