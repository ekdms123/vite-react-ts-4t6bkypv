from __future__ import annotations

import hashlib
import importlib.util
import json
import shutil
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping


def _file_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


@dataclass(frozen=True)
class MutationProposal:
    proposal_id: str
    remove_components: tuple[str, ...]
    replacement_program_refs: tuple[str, ...]
    state_migration_ref: str
    affected_work_refs: tuple[str, ...]
    comparison_task_refs: tuple[str, ...]
    parent_refs: tuple[str, ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class MutationRuntime:
    """Branch-first mutation support with a live replaceable structure map."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.ledger = self.root / "mutations.jsonl"
        self.live_structure = self.root / "live_structure.json"
        if not self.ledger.exists():
            self.ledger.write_text("", encoding="utf-8")
        if not self.live_structure.exists():
            self.live_structure.write_text("{}\n", encoding="utf-8")

    def propose(
        self,
        *,
        remove_components: Iterable[str],
        replacement_program_refs: Iterable[str],
        state_migration_ref: str,
        affected_work_refs: Iterable[str],
        comparison_task_refs: Iterable[str],
        parent_refs: Iterable[str] = (),
    ) -> MutationProposal:
        payload = {
            "remove_components": tuple(map(str, remove_components)),
            "replacement_program_refs": tuple(map(str, replacement_program_refs)),
            "state_migration_ref": str(state_migration_ref),
            "affected_work_refs": tuple(map(str, affected_work_refs)),
            "comparison_task_refs": tuple(map(str, comparison_task_refs)),
            "parent_refs": tuple(map(str, parent_refs)),
        }
        proposal = MutationProposal(
            proposal_id="proposal_" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:20],
            **payload,
        )
        self._record({"event": "proposal", "proposal": proposal.as_mapping(), "created_at": time.time()})
        return proposal

    def fork_state(self, source: str | Path, *, branch_id: str) -> Path:
        src = Path(source)
        dst = self.root / "branches" / str(branch_id)
        if dst.exists():
            shutil.rmtree(dst)
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        return dst

    def apply_patch(self, target: str | Path, patcher: Callable[[str], str], *, proposal_ref: str = "") -> dict[str, Any]:
        path = Path(target)
        before = _file_sha(path)
        old = path.read_text(encoding="utf-8")
        new = patcher(old)
        if new == old:
            raise ValueError("mutation patch made no change")
        tmp = path.with_suffix(path.suffix + ".mutation.tmp")
        tmp.write_text(new, encoding="utf-8")
        tmp.replace(path)
        after = _file_sha(path)
        receipt = {
            "mutation_receipt_id": "mutation_" + hashlib.sha256(f"{path}|{before}|{after}".encode()).hexdigest()[:20],
            "proposal_ref": str(proposal_ref),
            "target": str(path),
            "before_sha256": before,
            "after_sha256": after,
            "created_at": time.time(),
        }
        self._record({"event": "mutation", **receipt})
        return receipt

    def structure_snapshot(self) -> dict[str, Any]:
        failure_path = self.root / "structure_failures.jsonl"

        def record_failure(kind: str, error: BaseException, *, quarantine: Path | None = None) -> None:
            row = {
                "kind": str(kind),
                "source": str(self.live_structure),
                "error_type": type(error).__name__,
                "error": str(error),
                "quarantine": str(quarantine or ""),
                "created_at": time.time(),
            }
            with failure_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")

        try:
            data = json.loads(self.live_structure.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("mutation live structure must be a JSON object")
            return data
        except OSError as exc:
            record_failure("mutation_structure_read_failed", exc)
            raise RuntimeError(f"mutation live structure read failed: {exc}") from exc
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            quarantine = self.live_structure.with_name(
                f"{self.live_structure.stem}.corrupt.{time.time_ns()}{self.live_structure.suffix}"
            )
            try:
                self.live_structure.replace(quarantine)
            except OSError as move_error:
                record_failure("mutation_structure_quarantine_failed", move_error)
                quarantine = self.live_structure
            record_failure("mutation_structure_corrupt", exc, quarantine=quarantine)
            raise RuntimeError(f"mutation live structure corrupt: {exc}") from exc

    def replace_component(
        self,
        *,
        component_ref: str,
        replacement_program_ref: str,
        affected_work_refs: Iterable[str],
        comparison_task_refs: Iterable[str],
        evidence_refs: Iterable[str] = (),
    ) -> dict[str, Any]:
        proposal = self.propose(
            remove_components=(component_ref,),
            replacement_program_refs=(replacement_program_ref,),
            state_migration_ref="mutation_runtime:migrate_live_structure_v1",
            affected_work_refs=affected_work_refs,
            comparison_task_refs=comparison_task_refs,
            parent_refs=evidence_refs,
        )
        before_state = self.structure_snapshot()
        migrated = self.migrate(before_state, lambda state: {
            **dict(state),
            "component_overrides": {
                **dict(state.get("component_overrides") or {}),
                str(component_ref): {
                    "replacement_program_ref": str(replacement_program_ref),
                    "proposal_id": proposal.proposal_id,
                    "evidence_refs": tuple(map(str, evidence_refs)),
                    "affected_work_refs": tuple(map(str, affected_work_refs)),
                },
            },
        })
        receipt = self.apply_patch(
            self.live_structure,
            lambda _old: json.dumps(migrated, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            proposal_ref=proposal.proposal_id,
        )
        return {"proposal": proposal.as_mapping(), "migration": migrated, "mutation": receipt}

    def resolve_component(self, component_ref: str, *, default_program_ref: str = "") -> dict[str, Any]:
        row = dict((self.structure_snapshot().get("component_overrides") or {}).get(str(component_ref)) or {})
        replacement = str(row.get("replacement_program_ref") or "")
        if replacement:
            return {
                "component_ref": str(component_ref),
                "program_ref": replacement,
                "source": "mutation_override",
                "proposal_id": str(row.get("proposal_id") or ""),
                "evidence_refs": tuple(map(str, row.get("evidence_refs") or ())),
            }
        return {
            "component_ref": str(component_ref),
            "program_ref": str(default_program_ref),
            "source": "default",
            "proposal_id": "",
            "evidence_refs": (),
        }

    @staticmethod
    def migrate_work_state(state: Mapping[str, Any], *, proposal: Mapping[str, Any] | MutationProposal) -> dict[str, Any]:
        row = proposal.as_mapping() if isinstance(proposal, MutationProposal) else dict(proposal)
        proposal_id = str(row.get("proposal_id") or "")
        migrated = dict(state)
        migrated["mutation_lineage"] = tuple(dict.fromkeys((*tuple(map(str, migrated.get("mutation_lineage") or ())), proposal_id))) if proposal_id else tuple(map(str, migrated.get("mutation_lineage") or ()))
        migrated["active_replacement_program_refs"] = tuple(map(str, row.get("replacement_program_refs") or ()))
        migrated["state_migration_ref"] = str(row.get("state_migration_ref") or "")
        return migrated

    @staticmethod
    def execute_program_ref(program_ref: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        ref = str(program_ref or "")
        if not ref.startswith("python:"):
            raise RuntimeError(f"unsupported replacement program: {ref}")
        path = Path(ref.split(":", 1)[1])
        spec = importlib.util.spec_from_file_location(
            "_jigaewol_mutation_" + hashlib.sha256(str(path).encode()).hexdigest()[:12], path
        )
        if spec is None or spec.loader is None:
            raise RuntimeError(f"cannot load replacement program: {path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        runner = getattr(module, "run", None)
        if not callable(runner):
            raise RuntimeError(f"replacement program has no run(payload): {path}")
        result = runner(dict(payload))
        return dict(result) if isinstance(result, Mapping) else {"result": result}

    @staticmethod
    def run_work(program: Any, runner: Callable[[Any], Any]) -> Any:
        return runner(program)

    @staticmethod
    def migrate(state: Mapping[str, Any], migrator: Callable[[Mapping[str, Any]], Mapping[str, Any]]) -> dict[str, Any]:
        return dict(migrator(dict(state)))

    def _record(self, row: Mapping[str, Any]) -> None:
        with self.ledger.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n")
