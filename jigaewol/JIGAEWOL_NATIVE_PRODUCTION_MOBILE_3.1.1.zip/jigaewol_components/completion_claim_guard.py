from __future__ import annotations

import re
from dataclasses import dataclass


# This guard is intentionally narrow.  It does not judge whether an answer is good,
# possible, safe, or complete.  It only blocks high-confidence first-person/result
# completion claims when the runtime already knows the effect/objective is unproven.
_KO_COMPLETION = re.compile(
    r"(?:^|[\s.!?])(?:[^\n.!?]{0,36})"
    r"(?:완료했습니다|완료했습니다|완료됐습니다|완료되었습니다|완료했다|"
    r"수정했습니다|고쳤습니다|적용했습니다|실행했습니다|저장했습니다|"
    r"생성했습니다|만들었습니다|업로드했습니다|삭제했습니다|전송했습니다|"
    r"발송했습니다|예약했습니다|등록했습니다|변경했습니다|반영했습니다|끝냈습니다)"
)
_EN_COMPLETION = re.compile(
    r"\b(?:i\s+(?:have\s+)?(?:completed|finished|updated|modified|applied|executed|saved|created|uploaded|deleted|sent|registered|changed)\b|"
    r"(?:done|completed|finished)\s+(?:it|the\s+(?:task|work|update|change|execution)))",
    re.IGNORECASE,
)
_NEGATION_HINT = re.compile(
    r"(?:아직|미완료|하지\s*않|못\s*했|완료\s*(?:주장|라고)\s*하지|"
    r"not\s+(?:yet\s+)?(?:done|completed|finished)|did\s+not|haven't|have\s+not)",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class CompletionClaimVerdict:
    blocked: bool
    matches: tuple[str, ...]
    reason: str


def detect_unproven_completion_claim(text: str) -> CompletionClaimVerdict:
    """Detect narrow, high-confidence completion language.

    This function deliberately does *not* decide whether completion is actually true.
    The caller supplies that fact.  It only identifies language that would falsely
    impersonate completion when proof is absent.
    """
    value = str(text or "")
    hits: list[str] = []
    for pattern in (_KO_COMPLETION, _EN_COMPLETION):
        for match in pattern.finditer(value):
            span = match.group(0).strip()
            start = max(0, match.start() - 48)
            context = value[start:match.end() + 8]
            if _NEGATION_HINT.search(context):
                continue
            hits.append(span)
    unique = tuple(dict.fromkeys(hits))
    return CompletionClaimVerdict(
        blocked=bool(unique),
        matches=unique,
        reason="unproven_effect_or_objective_completion_claim" if unique else "",
    )
