from __future__ import annotations

from pathlib import Path


def default_project_path_fields() -> dict[str, str]:
    return {
        "vendor_path": "vendor",
        "vendor_root": "vendor",
        "wrapper_path": "external_components",
    }


def rebase_project_paths(registry: dict, project_root: Path, path_fields: dict[str, str] | None = None) -> bool:
    """Rebase project-internal registry paths after an environment move."""
    root = project_root.resolve()
    fields = dict(path_fields or default_project_path_fields())
    changed = False

    def visit(value: object) -> None:
        nonlocal changed
        if isinstance(value, dict):
            for field, child in list(value.items()):
                marker = fields.get(field)
                if marker is not None and isinstance(child, str) and child:
                    path = Path(child)
                    if not path.is_absolute():
                        candidate = (root / path).resolve()
                    else:
                        try:
                            path.resolve().relative_to(root)
                        except ValueError:
                            parts = path.parts
                            if marker not in parts:
                                candidate = path.resolve()
                            else:
                                marker_index = len(parts) - 1 - parts[::-1].index(marker)
                                candidate = root.joinpath(*parts[marker_index:]).resolve()
                        else:
                            candidate = path.resolve()
                    normalized = str(candidate)
                    if normalized != child:
                        value[field] = normalized
                        changed = True
                else:
                    visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(registry)
    return changed
