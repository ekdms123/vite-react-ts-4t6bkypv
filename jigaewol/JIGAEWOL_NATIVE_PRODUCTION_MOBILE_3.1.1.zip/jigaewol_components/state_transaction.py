"""Cross-process, reentrant serialization for existing JSON ledgers."""
from __future__ import annotations
import os
import threading
from contextlib import contextmanager
from functools import wraps
from pathlib import Path
import sys
try:
    import fcntl
except ImportError:
    if sys.platform != 'emscripten':raise
    # One browser worker owns one private MEMFS. Native CPython keeps flock.
    fcntl = None

_locks = {}
_guard = threading.Lock()
_local = threading.local()

@contextmanager
def state_transaction(root):
    key = str(Path(root).resolve())
    with _guard:
        lock = _locks.setdefault(key, threading.RLock())
    with lock:
        held = getattr(_local, 'held', {})
        if key in held:
            yield
            return
        Path(key).mkdir(parents=True, exist_ok=True)
        fd = os.open(str(Path(key)/'.transaction.lock'), os.O_CREAT | os.O_RDWR, 0o600)
        if fcntl is not None:fcntl.flock(fd, fcntl.LOCK_EX)
        held[key] = fd
        _local.held = held
        try:
            yield
        finally:
            del held[key]
            if fcntl is not None:fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

def serialized_state(fn):
    @wraps(fn)
    def wrapped(self, *args, **kwargs):
        with state_transaction(self.root):
            return fn(self, *args, **kwargs)
    return wrapped
