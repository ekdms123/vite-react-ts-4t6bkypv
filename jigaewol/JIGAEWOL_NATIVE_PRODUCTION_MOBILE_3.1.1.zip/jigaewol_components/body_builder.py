from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from jigaewol_components.relocatable_refs import resolve_python_ref


@dataclass(frozen=True)
class BodySpec:
    body_id: str
    effect_signature: str
    kind: str
    entrypoint_ref: str
    dependency_refs: tuple[str, ...]
    authorization_refs: tuple[str, ...]
    observable_result: dict[str, Any]
    parent_refs: tuple[str, ...] = ()
    interface: dict[str, Any] | None = None
    effect_executable: bool = True
    program_sha256: str = ""

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class BodyBuilder:
    """Effect-first body synthesis.

    A generated body is only marked effect-executable when it contains an executable
    program for the requested effect.  Placeholder bodies never self-certify success.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "bodies.json"
        self.observations_path = self.root / "observations.jsonl"
        self.programs_root = self.root / "generated_programs"
        self.programs_root.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("{}\n", encoding="utf-8")
        if not self.observations_path.exists():
            self.observations_path.write_text("", encoding="utf-8")

    def discover(self, desired_change: str) -> tuple[dict[str, Any], ...]:
        low = str(desired_change).casefold()
        out = []
        for row in self.snapshot().values():
            if row.get("effect_executable") is False:
                continue
            searchable = " ".join(str(row.get(k) or "") for k in ("effect_signature", "entrypoint_ref", "kind")).casefold()
            if not low or low in searchable or any(tok in searchable for tok in low.split() if len(tok) >= 3):
                out.append(dict(row))
        return tuple(out)

    @staticmethod
    def _builtin_effect_source(desired_change: str) -> str | None:
        low = str(desired_change).casefold()
        # Executable fallback for a generic collect/transform effect. Unknown effects
        # remain unresolved until cognition supplies a concrete program_source.
        if "collect" in low or "transform" in low:
            desired_literal = repr(str(desired_change))
            return f'''from __future__ import annotations

DESIRED_CHANGE = {desired_literal}

def run(payload):
    data = dict(payload or {{}})
    rows = data.get("records", data.get("items", []))
    if isinstance(rows, list):
        try:
            artifact = sorted(rows)
        except TypeError:
            artifact = list(rows)
        count = len(artifact)
    elif isinstance(rows, dict):
        artifact = {{k: rows[k] for k in sorted(rows)}}
        count = len(artifact)
    else:
        artifact = rows
        count = 1 if rows is not None else 0
    return {{"success": True, "desired_change": DESIRED_CHANGE, "artifact": artifact, "record_count": count}}
'''
        return None

    def _materialize_local_program(
        self,
        *,
        body_id: str,
        desired_change: str,
        observable_result: Mapping[str, Any],
        kind: str,
        program_source: str | None = None,
    ) -> tuple[str, bool, str]:
        path = self.programs_root / f"{body_id}.py"
        source = program_source or self._builtin_effect_source(desired_change)
        effect_executable = source is not None
        if source is None:
            source = (
                "from __future__ import annotations\n\n"
                "def run(payload):\n"
                "    return {\"success\": False, \"needs_effect_program\": True, "
                f"\"desired_change\": {desired_change!r}}}\n"
            )
        cli = (
            "\nif __name__ == '__main__':\n"
            "    import json, sys\n"
            "    raw = sys.stdin.read()\n"
            "    payload = json.loads(raw) if raw.strip() else {}\n"
            "    print(json.dumps(run(payload), ensure_ascii=False, sort_keys=True))\n"
        )
        materialized = source.rstrip() + "\n" + cli
        path.write_text(materialized, encoding="utf-8")
        return f"python:{path}", effect_executable, hashlib.sha256(materialized.encode("utf-8")).hexdigest()

    def generate(
        self,
        *,
        desired_change: str,
        entrypoint_ref: str,
        dependency_refs: Iterable[str] = (),
        authorization_refs: Iterable[str] = (),
        observable_result: Mapping[str, Any] | None = None,
        kind: str = "generated_local_tool",
        parent_refs: Iterable[str] = (),
        interface: Mapping[str, Any] | None = None,
        program_source: str | None = None,
    ) -> BodySpec:
        deps = tuple(map(str, dependency_refs))
        auth = tuple(map(str, authorization_refs))
        parents = tuple(map(str, parent_refs))
        obs = dict(observable_result or {})
        iface = dict(interface or {
            "input": "effect_request",
            "output": "observation+receipt",
            "reusable": True,
        })
        seed = f"{desired_change}|{entrypoint_ref}|{deps}|{auth}|{kind}|{parents}|{iface}|{hashlib.sha256((program_source or '').encode()).hexdigest()}"
        body_id = "body_" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:20]
        requested_entrypoint = str(entrypoint_ref)
        local_requested = bool(program_source) or (not requested_entrypoint) or requested_entrypoint.startswith((
            "local_generated_program", "sensor:", "generated:"
        ))
        effect_executable = True
        program_sha = ""
        if local_requested:
            actual_entrypoint, effect_executable, program_sha = self._materialize_local_program(
                body_id=body_id,
                desired_change=str(desired_change),
                observable_result=obs,
                kind=str(kind),
                program_source=program_source,
            )
            iface = {
                **iface,
                "requested_entrypoint_ref": requested_entrypoint,
                "materialized_program": actual_entrypoint,
                "effect_executable": effect_executable,
            }
        else:
            actual_entrypoint = requested_entrypoint
        return BodySpec(
            body_id=body_id,
            effect_signature=str(desired_change),
            kind=str(kind),
            entrypoint_ref=actual_entrypoint,
            dependency_refs=deps,
            authorization_refs=auth,
            observable_result=obs,
            parent_refs=parents,
            interface=iface,
            effect_executable=effect_executable,
            program_sha256=program_sha,
        )

    def bind(self, spec: BodySpec) -> BodySpec:
        data = self.snapshot()
        data[spec.body_id] = spec.as_mapping()
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(self.path)
        return spec

    @staticmethod
    def _observable_satisfied(expected: Mapping[str, Any], result: Mapping[str, Any]) -> bool:
        if not expected:
            return bool(result.get("success") is True)
        for key, wanted in expected.items():
            if key == "receipt_required":
                # Receipt existence is established by the host observation layer, not
                # by a locally generated program.
                continue
            if key not in result:
                return False
            actual = result.get(key)
            if isinstance(wanted, bool):
                if wanted and not bool(actual):
                    return False
                if not wanted and bool(actual):
                    return False
            elif wanted is not None and actual != wanted:
                return False
        return True

    def execute(self, spec: BodySpec | Mapping[str, Any], payload: Mapping[str, Any]) -> dict[str, Any]:
        row = spec.as_mapping() if isinstance(spec, BodySpec) else dict(spec)
        entrypoint = str(row.get("entrypoint_ref") or "")
        if not entrypoint.startswith("python:"):
            raise RuntimeError(f"body entrypoint is not locally executable: {entrypoint}")
        path = resolve_python_ref(entrypoint, roots=(self.root,))
        proc = subprocess.run(
            [sys.executable, str(path)],
            input=json.dumps(dict(payload), ensure_ascii=False),
            text=True,
            capture_output=True,
            timeout=30,
            check=False,
        )
        if proc.returncode != 0:
            return {
                "success": False,
                "effect_observed": False,
                "exit_code": proc.returncode,
                "stderr": proc.stderr,
                "body_id": row.get("body_id"),
            }
        result = json.loads(proc.stdout or "{}")
        expected = dict(row.get("observable_result") or {})
        effect_observed = bool(row.get("effect_executable", True)) and self._observable_satisfied(expected, result)
        success = bool(result.get("success") is True and effect_observed)
        return {
            **dict(result),
            "success": success,
            "effect_observed": effect_observed,
            "exit_code": proc.returncode,
            "body_id": str(row.get("body_id") or ""),
        }

    def compose(self, specs: Iterable[BodySpec | Mapping[str, Any]], *, desired_change: str) -> BodySpec:
        rows = tuple(x.as_mapping() if isinstance(x, BodySpec) else dict(x) for x in specs)
        if not rows:
            raise ValueError("compose requires at least one body")
        refs = tuple(str(x.get("body_id") or x.get("entrypoint_ref") or "") for x in rows)
        executable = tuple(str(x.get("entrypoint_ref") or "") for x in rows if str(x.get("entrypoint_ref") or "").startswith("python:"))
        # Composite execution is concrete only when every component has an executable
        # effect body.  The coordinator is generated as a real Python program that
        # dispatches each part in order and returns the final result.
        executable_parts = tuple(row for row in rows if row.get("effect_executable", True) and str(row.get("entrypoint_ref") or "").startswith("python:"))
        if len(executable_parts) == len(rows):
            part_paths = [str(row["entrypoint_ref"]).split(":", 1)[1] for row in executable_parts]
            source = "from __future__ import annotations\nimport importlib.util\n\nPARTS = " + repr(part_paths) + "\n\ndef _load(path, idx):\n    spec = importlib.util.spec_from_file_location(f'_jigaewol_part_{idx}', path)\n    mod = importlib.util.module_from_spec(spec)\n    spec.loader.exec_module(mod)\n    return mod\n\ndef run(payload):\n    state = dict(payload or {})\n    trace = []\n    for idx, path in enumerate(PARTS):\n        mod = _load(path, idx)\n        out = mod.run(state)\n        trace.append(out)\n        if isinstance(out, dict):\n            state = out\n        if isinstance(out, dict) and out.get('success') is False:\n            return {'success': False, 'trace': trace, 'result': out}\n    return {'success': True, 'trace': trace, 'result': state, 'composed_body_count': len(PARTS)}\n"
        else:
            source = None
        spec = self.generate(
            desired_change=desired_change,
            entrypoint_ref=f"generated:composite:{desired_change}",
            dependency_refs=refs,
            authorization_refs=tuple(dict.fromkeys(a for row in rows for a in (row.get("authorization_refs") or ()))),
            observable_result={"composed_body_count": len(rows)},
            kind="generated_composite_body",
            parent_refs=refs,
            interface={"parts": rows, "executable_parts": executable, "reusable": True},
            program_source=source,
        )
        return self.bind(spec)

    def observe(self, spec: BodySpec | Mapping[str, Any], *, receipt_ref: str, success: bool, result: Any = None) -> dict[str, Any]:
        row = spec.as_mapping() if isinstance(spec, BodySpec) else dict(spec)
        observed = {
            "body_id": str(row.get("body_id") or ""),
            "receipt_ref": str(receipt_ref),
            "success": bool(success),
            "result": result,
            "observed_at": time.time(),
        }
        with self.observations_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(observed, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n")
        return observed

    def snapshot(self) -> dict[str, Any]:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"BODY_BUILDER_STATE_UNREADABLE:{type(exc).__name__}:{exc}") from exc
