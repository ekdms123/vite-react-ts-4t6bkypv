from __future__ import annotations

"""Versioned concept-vector profiles shared by semantic records and validators.

The semantic record declares the profile name.  The profile registry defines the
only dimensions/schema pairs that are valid for that declaration.  This keeps
future dimensional evolution explicit instead of treating arbitrary dimensions as
implicitly valid.
"""

from types import MappingProxyType
from typing import Any, Mapping

VECTOR_PROFILE_V1 = "jigaewol_concept_vector_v1"
VECTOR_PROFILE_V2_64 = "jigaewol_concept_vector_v2_64"
DEFAULT_VECTOR_PROFILE = VECTOR_PROFILE_V1

VECTOR_PROFILES: Mapping[str, Mapping[str, Any]] = MappingProxyType({
    VECTOR_PROFILE_V1: MappingProxyType({
        "dimensions": 32,
        "vector_schema": "jigaewol_standardized_concept_vector_v1",
        "status": "canonical",
    }),
    VECTOR_PROFILE_V2_64: MappingProxyType({
        "dimensions": 64,
        "vector_schema": "jigaewol_standardized_concept_vector_v2_64",
        "status": "registered_extension",
    }),
})


def get_vector_profile(name: str) -> Mapping[str, Any]:
    key = str(name or "").strip()
    try:
        return VECTOR_PROFILES[key]
    except KeyError as exc:
        raise ValueError(f"unknown vector profile: {key!r}") from exc
