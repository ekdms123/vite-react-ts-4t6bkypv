from __future__ import annotations

"""Deterministic authority consolidation for one exact user source.

Version 1 deliberately keeps authority compilation narrow and reproducible:
- presentation markers are observations only;
- exact current-user prohibitions/directives become binding here, not in discourse_scope;
- historical/hypothetical/reference material remains semantic context without gaining effect authority;
- every canonical row remains source-span bound to the exact user text.
"""

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from typing import Any

from .authority_ruleset import AUTHORITY_RULESET_V1, authority_ruleset_sha256, validate_authority_ruleset
from .requirement_contract import RequirementContract
from .source_directive_compiler import explicit_request_present, quote_adoption_requested


_EXPLICIT_CURRENT = (
    "지금", "이번", "이제", "바로", "현재", "여기서", "오늘", "이번에는", "이번엔",
    "지금부터", "이제부터", "now", "right now", "this turn", "this time", "currently",
)
_STANDING = (
    "앞으로", "항상", "매번", "무조건", "계속", "절대로", "다시는", "이제부터",
    "from now on", "always", "every time", "never again", "must always",
)
_HISTORICAL = (
    "예전에", "예전", "과거에", "전에 말", "전에 적", "했었", "했는데", "말했", "요구했",
    "원했", "불만", "지쳤", "previously", "used to", "earlier", "in the past",
)
_HYPOTHETICAL = (
    "예를 들어", "가령", "만약", "만일", "상상해", "가정하면", "예시", "for example", "suppose", "if hypothetically", "e.g.",
)
_REFERENCE = (
    "아래는", "아래 걸", "아래의", "위에는", "위에서 준", "전문", "원문", "지피티가 준", "클로드가 준",
    "the following", "below is", "quoted material", "reference material",
)
_QUESTION = ("?", "？", "질문", "궁금", "뭐", "무엇", "왜", "어떻게", "what", "why", "how")
_ASPIRATION = (
    "꿈", "목표", "원해", "바라", "노려", "됐으면", "하고 싶", "보고 싶", "wish", "hope", "goal", "aspire", "want",
)
_ACTION = (
    "해줘", "해 줘", "해봐", "해 봐", "해", "줘", "봐", "찾아", "분석", "검증", "고쳐", "수정", "구현",
    "만들", "연결", "설치", "실행", "저장", "기록", "읽어", "가져와", "돌려", "계속해", "이어", "파악",
    "지켜", "따라", "preserve", "obey", "do ", "please", "analyze", "find", "fix", "implement", "build", "run", "execute", "save", "store", "continue",
)

_REFERENCE_BLOCK_START = (
    "전문을 줄게", "전문을 줄께", "대화 전문", "대화를 줄게", "대화를 붙여", "붙여줄게",
    "아래 대화", "다음 대화", "설계 문서", "설계도", "blueprint", "specification",
    "transcript", "conversation transcript",
)
_REFERENCE_BLOCK_END = (
    "라는 대화를 나눴는데", "이 대화를 나눴는데", "여기까지가", "여기까지는",
    "네 생각은", "어떻게 생각", "평가해", "보고 말해", "what do you think",
)
_TRANSCRIPT_SPEAKER_MARKERS = (
    "내턴", "내 턴", "너턴", "너 턴",
    "user >", "assistant >", "user:", "assistant:",
)
_REFERENCE_INTRO_MARKERS = (
    "대화 전문", "지피티가 준 대화", "클로드가 준 대화",
    "the following", "below is", "quoted material", "reference material",
)
_EXPLICIT_REFERENCE_ACTION = (
    "아래대로", "그대로 구현", "이 설계대로", "이 문서대로",
    "implement the following", "implement this design",
)
_NEGATED_ACTION = re.compile(
    r"(?:하지\s*마|하지\s*말|말고|쓰지\s*마|사용하지\s*마|"
    r"(?:할\s*)?필요(?:는|가)?\s*(?:없|없습니다|없어요)|"
    r"no\s+need\s+to|do\s+not|don't|dont|must\s+not|never)",
    re.IGNORECASE,
)


def current_prohibition_present(text: str) -> bool:
    """Exclude a reported earlier prohibition from the live command's polarity."""
    raw = str(text)
    for match in _NEGATED_ACTION.finditer(raw):
        if re.match(r"(?:라고|라는|랬|라던|라고\s*했)", raw[match.end():].lstrip()):
            continue
        return True
    return False


def capability_prohibited(text: str, markers: tuple[str, ...]) -> bool:
    """Bind denial to a capability's own prohibition, not a reporting verb."""
    marker = "(?:" + "|".join(re.escape(value) for value in markers) + ")"
    korean = marker + r"(?:[은는을를이가]?\s*)(?:사용\s*|쓰\s*|이용\s*)?(?:하지\s*(?:마|말)(?!라고|라는)|지\s*(?:마|말)|금지|(?:할\s*)?필요(?:는|가)?\s*없)"
    english = r"(?:do\s+not|don['’]?t|never)\s+(?!(?:say|claim|mention|report|write\s+the\s+word)\b)(?:use\s+)?" + marker
    return bool(re.search(korean + "|" + english, str(text), re.I))

_CAPABILITY_MARKERS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("web_search", ("웹 검색", "인터넷 검색", "온라인 검색", "web search", "search the web", "browse the web")),
    ("code_modification", ("코드 수정", "파일 수정", "코드 변경", "modify code", "edit code", "change code")),
    ("external_tools", ("외부 도구", "외부 툴", "external tool", "external tools")),
)


def _sha_text(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _contains(text: str, markers: tuple[str, ...]) -> bool:
    folded = str(text).casefold()
    return any(marker.casefold() in folded for marker in markers)


def _last(text: str, markers: tuple[str, ...]) -> int:
    folded = str(text).casefold()
    return max((folded.rfind(marker.casefold()) for marker in markers), default=-1)


def requested_mode(text: str) -> str:
    """Resolve explicit research-only/other-actor clauses before effect projection."""
    if re.search(r"(?:찾기|조사|분석|설계|아이디어).{0,8}(?:만\s*해|만\s*줘)|구현[은는].{0,12}(?:다른\s*모델|다른\s*사람)|(?:research|design)\s+only", text, re.I):
        return "research"
    return "task"


@dataclass(frozen=True, slots=True)
class ExactUserSource:
    text: str
    sha256: str

    @classmethod
    def from_text(cls, text: str) -> "ExactUserSource":
        exact = str(text)
        return cls(text=exact, sha256=_sha_text(exact))


@dataclass(frozen=True, slots=True)
class CanonicalDirective:
    directive_id: str
    atom_id: str
    source_index: int
    source_start: int
    source_end: int
    raw_text: str
    authority_scope: str
    directive_kind: str
    binding: bool
    constraint_strength: str
    permission_state: str
    supersession_state: str
    presentation_metadata: tuple[str, ...]
    provenance_metadata: tuple[str, ...]
    reasons: tuple[str, ...]
    actor: str = "assistant"
    requested_mode: str = "task"
    time_scope: str = "current"
    deliverable: str = ""
    adopted_as_current_requirement: bool = False
    supersedes_ids: tuple[str, ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CanonicalDirectiveSet:
    message_sha256: str
    exact_source_text: str
    authority_ruleset_version: int
    ruleset_sha256: str
    semantic_text: str
    current_text: str
    action_text: str
    directives: tuple[CanonicalDirective, ...]
    semantic_atom_ids: tuple[str, ...]
    current_source_indexes: tuple[int, ...]
    action_atom_ids: tuple[str, ...]
    action_source_indexes: tuple[int, ...]
    scope_counts: dict[str, int]
    denied_capabilities: tuple[str, ...]
    allowed_capabilities: tuple[str, ...]
    canonical_sha256: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)

    def summary(self, *, max_ids: int | None = None) -> dict[str, Any]:
        action_ids = list(self.action_atom_ids)
        action_indexes = list(self.action_source_indexes)
        semantic_ids = list(self.semantic_atom_ids)
        current_indexes = list(self.current_source_indexes)

        def visible(values: list[Any]) -> tuple[list[Any], bool]:
            if max_ids is None:
                return list(values), True
            n = max(0, int(max_ids))
            return list(values[:n]), len(values) <= n

        semantic_visible, semantic_complete = visible(semantic_ids)
        action_visible, action_complete = visible(action_ids)
        action_indexes_visible, action_indexes_complete = visible(action_indexes)
        current_indexes_visible, current_indexes_complete = visible(current_indexes)
        row_fingerprint = [
            f"{row.atom_id}:{row.source_index}:{row.authority_scope}:{row.directive_kind}:{int(row.binding)}"
            for row in self.directives
        ]
        return {
            "schema": "jigaewol_canonical_directive_set_v1",
            "message_sha256": self.message_sha256,
            "exact_source_text_sha256": _sha_text(self.exact_source_text),
            "exact_source_text_length": len(self.exact_source_text),
            "exact_source_text_lossless": True,
            "authority_ruleset_version": self.authority_ruleset_version,
            "authority_ruleset_sha256": self.ruleset_sha256,
            "canonical_directive_set_sha256": self.canonical_sha256,
            "atom_count": len(self.directives),
            "scope_counts": dict(self.scope_counts),
            "semantic_atom_count": len(semantic_ids),
            "action_atom_count": len(action_ids),
            "semantic_atom_ids": semantic_visible,
            "semantic_atom_ids_complete": semantic_complete,
            "semantic_atom_ids_sha256": _sha_text(json.dumps(semantic_ids, ensure_ascii=False, separators=(",", ":"))),
            "action_atom_ids": action_visible,
            "action_atom_ids_complete": action_complete,
            "action_source_indexes": action_indexes_visible,
            "action_source_indexes_complete": action_indexes_complete,
            "action_occurrences_sha256": _sha_text(json.dumps(
                [f"{row.atom_id}:{row.source_index}" for row in self.directives if row.binding and row.directive_kind in {"directive", "prohibition", "standing_policy"}],
                ensure_ascii=False, separators=(",", ":")
            )),
            "scope_rows_sha256": _sha_text(json.dumps(row_fingerprint, ensure_ascii=False, separators=(",", ":"))),
            "current_source_indexes": current_indexes_visible,
            "current_source_indexes_complete": current_indexes_complete,
            "canonical_rows_sha256": _sha_text(json.dumps(row_fingerprint, ensure_ascii=False, separators=(",", ":"))),
            "semantic_projection_sha256": _sha_text(self.semantic_text),
            "current_projection_sha256": _sha_text(self.current_text),
            "action_projection_sha256": _sha_text(self.action_text),
            "canonical_raw_text_replaced": False,
            "authority_compiler": "AuthorityConsolidation",
            "downstream_authority_mutation": "forbidden",
            "denied_capabilities": list(self.denied_capabilities),
            "allowed_capabilities": list(self.allowed_capabilities),
        }


class AuthorityConsolidation:
    """The sole v1 compiler for discourse binding/effect eligibility."""

    @staticmethod
    def _find_source_span(source: str, atom_text: str, cursor: int) -> tuple[int, int, int]:
        probe = str(atom_text).strip()
        if not probe:
            return cursor, cursor, cursor
        start = source.find(probe, cursor)
        if start < 0:
            start = source.find(probe)
        if start < 0:
            # A binding directive without an exact source span would violate NO_SOURCE_LOSS.
            return -1, -1, cursor
        end = start + len(probe)
        return start, end, end

    @classmethod
    def _scope_and_kind(
        cls,
        text: str,
        *,
        reference_block_active: bool,
        transcript_started: bool,
        ends_reference_block: bool,
        explicit_reference_action: bool,
    ) -> tuple[str, str, bool, tuple[str, ...]]:
        raw = str(text or "").strip()
        reasons: list[str] = []

        explicit_current_at = _last(raw, _EXPLICIT_CURRENT)
        standing_at = _last(raw, _STANDING)
        historical = _contains(raw, _HISTORICAL)
        hypothetical = _contains(raw, _HYPOTHETICAL)
        reference = _contains(raw, _REFERENCE)
        action_signal = _contains(raw, _ACTION)
        question_signal = _contains(raw, _QUESTION)
        aspiration = _contains(raw, _ASPIRATION)
        negated = current_prohibition_present(raw)
        live_request = explicit_request_present(raw)
        adopted_request = quote_adoption_requested(raw) and live_request
        noncurrent_at = max(_last(raw, _HISTORICAL), _last(raw, _HYPOTHETICAL), _last(raw, _REFERENCE))
        explicit_current_after_context = explicit_current_at >= 0 and explicit_current_at > noncurrent_at

        if ((reference_block_active or transcript_started) and not ends_reference_block
                and not explicit_reference_action and not adopted_request
                and not (explicit_current_at >= 0 and live_request)):
            return "quoted_reference", "reference", False, ("reference_block_context",)

        # Exact current requests remain binding even when they complain about a
        # historical failure, state a condition, quote their target, or ask politely.
        if live_request and not negated:
            reasons.append("explicit_source_request")
            if historical or hypothetical or reference:
                reasons.append("context_metadata_preserved_without_request_demotion")
            if standing_at >= 0:
                return "current_user", "standing_policy", True, tuple(reasons)
            return "current_user", "directive", True, tuple(reasons)

        if standing_at >= 0 and standing_at >= noncurrent_at:
            reasons.append("standing_policy_marker")
            if negated:
                reasons.append("explicit_negation")
                return "current_user", "prohibition", True, tuple(reasons)
            return "current_user", "standing_policy", True, tuple(reasons)

        if historical and not explicit_current_after_context:
            return "historical_reference", "reference", False, ("historical_report_marker",)
        if hypothetical and not explicit_current_after_context:
            return "hypothetical_reference", "reference", False, ("hypothetical_marker",)
        if reference and not explicit_current_after_context and not action_signal:
            return "reference_material", "reference", False, ("reference_material_marker",)

        if negated:
            reasons.append("explicit_negation")
            if explicit_current_at >= 0:
                reasons.append("explicit_current_marker")
            return "current_user", "prohibition", True, tuple(reasons)
        if explicit_current_at >= 0:
            reasons.append("explicit_current_marker")
        if action_signal:
            reasons.append("action_language")
            return "current_user", "directive", True, tuple(reasons)
        if question_signal:
            return "current_user", "question", True, ("question_semantics",)
        if aspiration:
            return "current_user", "directive", True, ("explicit_source_preference",)
        return "current_user", "context", False, ("contextual_semantics",)

    @classmethod
    def compile(
        cls,
        source: ExactUserSource,
        contract: RequirementContract,
        *,
        presentation: Any | None = None,
    ) -> CanonicalDirectiveSet:
        ruleset = validate_authority_ruleset(AUTHORITY_RULESET_V1)
        if not isinstance(source, ExactUserSource):
            raise TypeError("source_must_be_ExactUserSource")
        if source.sha256 != _sha_text(source.text):
            raise ValueError("exact_user_source_sha256_mismatch")
        if contract.message_sha256 != source.sha256:
            raise ValueError("requirement_contract_source_mismatch")

        if presentation is None:
            from .discourse_scope import DiscourseScopeAnalyzer
            presentation = DiscourseScopeAnalyzer.compile(source.text, contract)
        if str(getattr(presentation, "message_sha256", "")) != source.sha256:
            raise ValueError("presentation_source_mismatch")

        presentation_rows = {int(row.source_index): row for row in tuple(getattr(presentation, "rows", ())) }
        directives: list[CanonicalDirective] = []
        semantic_ids: list[str] = []
        current_indexes: list[int] = []
        action_ids: list[str] = []
        action_indexes: list[int] = []
        semantic_parts: list[str] = []
        current_parts: list[str] = []
        action_parts: list[str] = []
        counts: dict[str, int] = {}
        denied_capabilities: list[str] = []
        allowed_capabilities: list[str] = []
        cursor = 0
        reference_block_active = False
        # A precedence chain is user policy, not a speaker label.
        transcript_marker_count = len(re.findall(r"(?im)^\s*(?:나|너|user|assistant)\s*[:>]\s*(?!zip\b|지개월|jigaewol\b|모델|model\b)", source.text))
        transcript_marker_count += sum(source.text.casefold().count(x.casefold()) for x in ("내턴", "내 턴", "너턴", "너 턴"))
        transcript_mode = transcript_marker_count >= 2
        transcript_started = False

        for atom in contract.atoms:
            atom_text = str(atom.text)
            folded_atom = atom_text.casefold()
            observed = presentation_rows.get(int(atom.source_index))
            presentation_metadata = tuple(getattr(observed, "presentation_metadata", ()) or ())
            provenance_metadata = tuple(getattr(observed, "provenance_metadata", ()) or ())

            speaker_marker = transcript_mode and bool(re.match(r"\s*(?:나|너|user|assistant)\s*[:>]\s*(?!zip\b|지개월|jigaewol\b|모델|model\b)", folded_atom))
            starts_reference_block = any(x.casefold() in folded_atom for x in _REFERENCE_BLOCK_START if x not in {"설계 문서", "설계도", "blueprint", "specification"}) or speaker_marker
            if not starts_reference_block and len(contract.atoms) >= 4 and any(x.casefold() in folded_atom for x in _REFERENCE_INTRO_MARKERS):
                starts_reference_block = True
            ends_reference_block = any(x.casefold() in folded_atom for x in _REFERENCE_BLOCK_END)
            if speaker_marker:
                transcript_started = True
            explicit_reference_action = bool(
                reference_block_active
                and _contains(atom_text, _ACTION)
                and any(marker.casefold() in folded_atom for marker in _EXPLICIT_REFERENCE_ACTION)
            )

            authority_scope, directive_kind, binding, reasons = cls._scope_and_kind(
                atom_text,
                reference_block_active=reference_block_active,
                transcript_started=transcript_started,
                ends_reference_block=ends_reference_block,
                explicit_reference_action=explicit_reference_action,
            )

            start, end, cursor = cls._find_source_span(source.text, atom_text, cursor)
            if binding and ruleset.require_exact_source_span and (start < 0 or end < 0):
                raise ValueError(f"binding_directive_missing_exact_source_span:{atom.source_index}")

            row = CanonicalDirective(
                directive_id="directive_" + _sha_text(
                    f"{source.sha256}:{atom.source_index}:{authority_scope}:{directive_kind}:{atom_text}"
                )[:20],
                atom_id=str(atom.atom_id),
                source_index=int(atom.source_index),
                source_start=int(start),
                source_end=int(end),
                raw_text=atom_text,
                authority_scope=authority_scope,
                directive_kind=directive_kind,
                binding=bool(binding),
                constraint_strength="binding" if binding and directive_kind in {"prohibition", "standing_policy"} else "none",
                permission_state="denied" if binding and directive_kind == "prohibition" else "unresolved",
                supersession_state="current" if authority_scope == "current_user" else "not_current",
                presentation_metadata=presentation_metadata,
                provenance_metadata=provenance_metadata,
                reasons=tuple(reasons),
                requested_mode=requested_mode(atom_text),
                time_scope="standing" if directive_kind == "standing_policy" else "current",
                deliverable="research_report" if requested_mode(atom_text) == "research" else "requested_result",
                adopted_as_current_requirement=authority_scope == "current_user",
            )
            directives.append(row)
            if binding:
                folded_row = atom_text.casefold()
                for capability, markers in _CAPABILITY_MARKERS:
                    if any(marker.casefold() in folded_row for marker in markers):
                        if directive_kind == "prohibition":
                            if capability_prohibited(atom_text, markers):
                                denied_capabilities.append(capability)
                        elif directive_kind in {"directive", "standing_policy"}:
                            allowed_capabilities.append(capability)
            counts[authority_scope] = counts.get(authority_scope, 0) + 1
            semantic_parts.append(atom_text)
            semantic_ids.append(str(atom.atom_id))
            if authority_scope == "current_user":
                current_parts.append(atom_text)
                current_indexes.append(int(atom.source_index))
            if binding and directive_kind in {"directive", "prohibition", "standing_policy"}:
                action_parts.append(atom_text)
                action_ids.append(str(atom.atom_id))
                action_indexes.append(int(atom.source_index))

            if starts_reference_block and not ends_reference_block:
                reference_block_active = True
            if ends_reference_block:
                reference_block_active = False
                transcript_started = False

        semantic_text = "\n".join(semantic_parts).strip() or source.text
        current_text = "\n".join(current_parts).strip() or semantic_text
        action_text = "\n".join(action_parts).strip()
        ruleset_hash = authority_ruleset_sha256(ruleset)
        canonical_payload = {
            "message_sha256": source.sha256,
            "authority_ruleset_version": ruleset.authority_ruleset_version,
            "ruleset_sha256": ruleset_hash,
            "directives": [row.as_mapping() for row in directives],
            "semantic_atom_ids": semantic_ids,
            "current_source_indexes": current_indexes,
            "action_atom_ids": action_ids,
            "action_source_indexes": action_indexes,
            "scope_counts": counts,
            "denied_capabilities": sorted(set(denied_capabilities)),
            "allowed_capabilities": sorted(set(allowed_capabilities) - set(denied_capabilities)),
        }
        canonical_sha256 = _sha_text(json.dumps(canonical_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        return CanonicalDirectiveSet(
            message_sha256=source.sha256,
            exact_source_text=source.text,
            authority_ruleset_version=ruleset.authority_ruleset_version,
            ruleset_sha256=ruleset_hash,
            semantic_text=semantic_text,
            current_text=current_text,
            action_text=action_text,
            directives=tuple(directives),
            semantic_atom_ids=tuple(semantic_ids),
            current_source_indexes=tuple(current_indexes),
            action_atom_ids=tuple(action_ids),
            action_source_indexes=tuple(action_indexes),
            scope_counts=counts,
            denied_capabilities=tuple(sorted(set(denied_capabilities))),
            allowed_capabilities=tuple(sorted(set(allowed_capabilities) - set(denied_capabilities))),
            canonical_sha256=canonical_sha256,
        )
