from __future__ import annotations

"""Paraconsistent contradiction material that can birth new observation machinery.

A contradiction is not collapsed to one truth value and is not treated only as a label.
The incompatible branches remain simultaneously executable hypotheses.  When the
current observation vocabulary cannot discriminate them, the cell emits an observer
birth request so the conflict can change the representation itself.
"""

from dataclasses import dataclass, field, asdict
from typing import Any, Iterable, Mapping
import hashlib

from .organ_ir import BirthRequest


@dataclass(slots=True)
class EvidenceAtom:
    supports: bool
    condition: str
    evidence: Any = None
    branch_id: str = ""

    def __post_init__(self) -> None:
        if not self.branch_id:
            payload = f"{int(self.supports)}|{self.condition}|{self.evidence!r}".encode("utf-8")
            self.branch_id = "branch_" + hashlib.sha256(payload).hexdigest()[:12]


@dataclass(slots=True)
class ContradictionCell:
    proposition: str
    atoms: list[EvidenceAtom] = field(default_factory=list)

    def add(self, supports: bool, *, condition: str = "", evidence: Any = None) -> None:
        self.atoms.append(EvidenceAtom(bool(supports), str(condition), evidence))

    @property
    def value(self) -> str:
        pos = any(x.supports for x in self.atoms)
        neg = any(not x.supports for x in self.atoms)
        if pos and neg:
            return "BOTH"
        if pos:
            return "TRUE_ONLY"
        if neg:
            return "FALSE_ONLY"
        return "NEITHER"

    def branches(self) -> tuple[dict[str, Any], ...]:
        return tuple({
            "branch_id": a.branch_id,
            "supports": a.supports,
            "condition": a.condition,
            "evidence": a.evidence,
            "live": True,
        } for a in self.atoms)

    def parallel_worlds(self) -> tuple[dict[str, Any], ...]:
        """Keep each incompatible evidential route live as its own computation world."""
        return tuple({
            "world_id": a.branch_id,
            "assumption": {"proposition": self.proposition, "supports": a.supports},
            "activation_condition": a.condition,
            "payload": a.evidence,
            "coexists_with_other_worlds": True,
        } for a in self.atoms)

    def synthesize_observation_request(self, candidate_channels: Iterable[str] = ()) -> BirthRequest | None:
        """Request a new observer when current evidence leaves both branches live.

        The suggested channels are evidence-derived where possible; otherwise the
        request deliberately leaves the channel shape open rather than choosing a
        predeclared sensor.
        """
        if self.value != "BOTH":
            return None
        channels = list(dict.fromkeys(str(x) for x in candidate_channels if str(x)))
        mapping_atoms = [a.evidence for a in self.atoms if isinstance(a.evidence, Mapping)]
        if mapping_atoms:
            keys = sorted({str(k) for row in mapping_atoms for k in row})
            for key in keys:
                vals = {repr(row.get(key)) for row in mapping_atoms}
                if len(vals) > 1 and key not in channels:
                    channels.append(key)
        return BirthRequest(
            "observer",
            "contradictory live branches require an observation that the current representation does not provide",
            {
                "proposition": self.proposition,
                "truth_state": self.value,
                "parallel_worlds": self.parallel_worlds(),
            },
            {
                "candidate_channels": tuple(channels),
                "open_channel_invention": not bool(channels),
                "must_discriminate_branch_ids": tuple(a.branch_id for a in self.atoms),
            },
        )

    def computation_material(self) -> dict[str, Any]:
        request = self.synthesize_observation_request()
        return {
            "truth_state": self.value,
            "parallel_worlds": self.parallel_worlds(),
            "observer_birth_request": asdict(request) if request is not None else None,
            "collapse_required": False,
            "literal_physical_contradiction_claimed": False,
        }

    def as_mapping(self) -> dict[str, Any]:
        return {
            "proposition": self.proposition,
            "value": self.value,
            "atoms": [asdict(x) for x in self.atoms],
            "computation_material": self.computation_material(),
        }
