from __future__ import annotations

"""Reject unsupported global ceiling claims while preserving scoped failure truth."""

import re
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from .response_language import assertion_text, boundary_discussion_requested, observed_failure_rows


@dataclass(frozen=True)
class CeilingVerdict:
    ok: bool
    matches: tuple[str, ...]
    scoped_failure_refs: tuple[str, ...]
    alternatives_remaining: bool


class NoPrematureCeilingPolicy:
    # Deliberately narrow: these are global/terminal phrasings, not ordinary reports
    # that one route failed.  The policy never rewrites an observed failure into success.
    _GLOBAL = (
        re.compile(r"(?:이건|그건|이 환경(?:에서)?|여기(?:서는)?|전체적으로)?\s*(?:안 됩니다|불가능(?:합니다|해요|하다)?|못합니다|할 수 없습니다)"),
        re.compile(r"(?:교체|변경|바꾸|통제|제어|건드리|실행|구현)할\s*수(?:는)?\s*없(?:습니다|어요|다)", re.I),
        re.compile(r"\b(?:cannot|can't|can\s+not|impossible|not\s+possible|unsupported)\b(?:\s+(?:here|in this environment|at all))?", re.I),
    )
    _SCOPED = re.compile(r"(?:경로|route|provider|플러그인|plugin|도구|tool|사이트|site|호출|call|연결|connection)", re.I)
    _CONTINUING = re.compile(r"(?:다른|대안|계속|우회|재시도|다음 경로|another|alternative|continue|retry|fallback)", re.I)

    @classmethod
    def evaluate(
        cls,
        text: str,
        *,
        observed_failures: Iterable[Mapping[str, Any]] = (),
        alternatives_remaining: bool = True,
        source_text: str = "",
    ) -> CeilingVerdict:
        body = assertion_text(text)
        matches = tuple(
            m.group(0)
            for pattern in cls._GLOBAL
            for m in pattern.finditer(body)
        )
        failures = tuple(x for x in observed_failure_rows(observed_failures)
                         if str(x.get("origin_ref") or x.get("receipt_id") or "").strip())
        refs = tuple(
            str(x.get("origin_ref") or x.get("receipt_id") or "")
            for x in failures
            if str(x.get("origin_ref") or x.get("receipt_id") or "")
        )
        if not matches or boundary_discussion_requested(source_text):
            return CeilingVerdict(True, (), refs, bool(alternatives_remaining))

        # A scoped statement backed by an observed failure is allowed.  When other
        # routes remain, it must also keep the goal open rather than globalizing the
        # failed route into an overall impossibility claim.
        claim_sentences = [part for part in re.split(r"[\n.!?;。！？]+", body)
                           if any(pattern.search(part) for pattern in cls._GLOBAL)]
        has_observed_scope = bool(failures) and all(cls._SCOPED.search(part) for part in claim_sentences)
        if has_observed_scope:
            if alternatives_remaining and not cls._CONTINUING.search(body):
                return CeilingVerdict(False, matches, refs, True)
            # If no alternatives remain, only explicitly terminal observed failures
            # may support the scoped terminal report.
            if not alternatives_remaining and not any(bool(x.get("terminal")) for x in failures):
                return CeilingVerdict(False, matches, refs, False)
            return CeilingVerdict(True, matches, refs, bool(alternatives_remaining))
        return CeilingVerdict(False, matches, refs, bool(alternatives_remaining))
