from __future__ import annotations

import copy
import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping


@dataclass(frozen=True)
class ImprovementProgram:
    program_ref: str
    observes: tuple[str, ...]
    proposes: tuple[str, ...]
    experiment_builder_ref: str
    adoption_rule_ref: str
    evidence_refs: tuple[str, ...]
    parent_program_refs: tuple[str, ...]

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class ImprovementPrograms:
    """Mutable improvement programs with same-start-state experimental competition."""

    @staticmethod
    def from_mapping(raw: Mapping[str, Any]) -> ImprovementProgram:
        return ImprovementProgram(
            program_ref=str(raw.get("program_ref") or ""),
            observes=tuple(map(str, raw.get("observes") or ())),
            proposes=tuple(map(str, raw.get("proposes") or ())),
            experiment_builder_ref=str(raw.get("experiment_builder_ref") or ""),
            adoption_rule_ref=str(raw.get("adoption_rule_ref") or ""),
            evidence_refs=tuple(map(str, raw.get("evidence_refs") or ())),
            parent_program_refs=tuple(map(str, raw.get("parent_program_refs") or ())),
        )

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.ledger = self.root / "lineage.jsonl"
        self.active_path = self.root / "active.json"
        if not self.ledger.exists():
            self.ledger.write_text("", encoding="utf-8")
        if not self.active_path.exists():
            self.active_path.write_text("{}\n", encoding="utf-8")

    def compose(
        self, *, observes: Iterable[str], proposes: Iterable[str], experiment_builder_ref: str,
        adoption_rule_ref: str, evidence_refs: Iterable[str] = (), parent_program_refs: Iterable[str] = (),
    ) -> ImprovementProgram:
        payload = {
            "observes": tuple(map(str, observes)), "proposes": tuple(map(str, proposes)),
            "experiment_builder_ref": str(experiment_builder_ref), "adoption_rule_ref": str(adoption_rule_ref),
            "parents": tuple(map(str, parent_program_refs)),
        }
        ref = "improvement_" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:20]
        program = ImprovementProgram(
            program_ref=ref,
            observes=payload["observes"], proposes=payload["proposes"],
            experiment_builder_ref=payload["experiment_builder_ref"], adoption_rule_ref=payload["adoption_rule_ref"],
            evidence_refs=tuple(map(str, evidence_refs)), parent_program_refs=payload["parents"],
        )
        self._record({"event": "compose", "program": program.as_mapping()})
        return program

    def mutate(
        self,
        program: ImprovementProgram,
        *,
        observes: Iterable[str] | None = None,
        proposes: Iterable[str] | None = None,
        experiment_builder_ref: str | None = None,
        adoption_rule_ref: str | None = None,
        evidence_ref: str = "",
    ) -> ImprovementProgram:
        return self.compose(
            observes=tuple(observes) if observes is not None else program.observes,
            proposes=tuple(proposes) if proposes is not None else program.proposes,
            experiment_builder_ref=str(experiment_builder_ref or program.experiment_builder_ref),
            adoption_rule_ref=str(adoption_rule_ref or program.adoption_rule_ref),
            evidence_refs=tuple((*program.evidence_refs, evidence_ref)) if evidence_ref else program.evidence_refs,
            parent_program_refs=(program.program_ref,),
        )

    def combine(self, programs: Iterable[ImprovementProgram], *, evidence_refs: Iterable[str] = ()) -> ImprovementProgram:
        rows = tuple(programs)
        if not rows:
            raise ValueError("combine requires at least one improvement program")
        observes = tuple(dict.fromkeys(x for p in rows for x in p.observes))
        proposes = tuple(dict.fromkeys(x for p in rows for x in p.proposes))
        builders = tuple(dict.fromkeys(p.experiment_builder_ref for p in rows if p.experiment_builder_ref))
        rules = tuple(dict.fromkeys(p.adoption_rule_ref for p in rows if p.adoption_rule_ref))
        builder_ref = (builders[0] + ("+compose(" + "+".join(builders[1:]) + ")" if len(builders) > 1 else "")) if builders else ""
        rule_ref = (rules[0] + ("+compose(" + "+".join(rules[1:]) + ")" if len(rules) > 1 else "")) if rules else ""
        return self.compose(
            observes=observes,
            proposes=proposes,
            experiment_builder_ref=builder_ref,
            adoption_rule_ref=rule_ref,
            evidence_refs=evidence_refs,
            parent_program_refs=tuple(p.program_ref for p in rows),
        )

    def run_competition(
        self,
        programs: Iterable[ImprovementProgram],
        *,
        start_state: Mapping[str, Any],
        runner: Callable[[ImprovementProgram, dict[str, Any]], Mapping[str, Any]],
    ) -> dict[str, Any]:
        rows = tuple(programs)
        canonical_start = copy.deepcopy(dict(start_state))
        start_blob = json.dumps(canonical_start, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        start_sha = hashlib.sha256(start_blob.encode("utf-8")).hexdigest()
        results = []
        for program in rows:
            branch_state = copy.deepcopy(canonical_start)
            started = time.time()
            result = dict(runner(program, branch_state))
            result.setdefault("program_ref", program.program_ref)
            result["start_state_sha256"] = start_sha
            result["branch_state"] = branch_state
            result["duration_seconds"] = max(0.0, time.time() - started)
            results.append(result)
            self._record({"event": "experiment", "program_ref": program.program_ref, "start_state_sha256": start_sha, "result": result})
        comparison = self.compare(results)
        return {**comparison, "start_state_sha256": start_sha}

    def combine_useful(
        self,
        programs: Iterable[ImprovementProgram],
        *,
        tournament: Mapping[str, Any],
        evidence_refs: Iterable[str] = (),
    ) -> ImprovementProgram:
        by_ref = {p.program_ref: p for p in programs}
        useful_refs = tuple(
            str(row.get("program_ref") or "")
            for row in tournament.get("results") or ()
            if row.get("observed") is True and row.get("success") is not False and (row.get("reusable") is True or row.get("change_kind"))
        )
        useful = tuple(by_ref[r] for r in useful_refs if r in by_ref)
        if not useful:
            raise ValueError("no observed useful improvement program to combine")
        return self.combine(useful, evidence_refs=evidence_refs)

    @staticmethod
    def compare(results: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
        rows = tuple(dict(x) for x in results)
        observed = tuple(x for x in rows if x.get("observed") is True)
        valid = tuple(x for x in observed if x.get("success") is not False)
        reusable = tuple(x for x in valid if x.get("reusable") is True or x.get("change_kind"))
        return {
            "candidate_count": len(rows),
            "observed_count": len(observed),
            "valid_count": len(valid),
            "reusable_count": len(reusable),
            "results": rows,
        }

    def adopt(self, program: ImprovementProgram, *, evidence_refs: Iterable[str]) -> dict[str, Any]:
        refs = tuple(map(str, evidence_refs))
        if not refs:
            raise ValueError("adoption requires observed evidence references")
        row = {"event": "adopt", "program_ref": program.program_ref, "evidence_refs": refs, "adopted_at": time.time()}
        self._record(row)
        tmp = self.active_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(program.as_mapping(), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.active_path)
        return row

    def active(self) -> ImprovementProgram | None:
        try:
            row = json.loads(self.active_path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return None
        return self.from_mapping(row) if row.get("program_ref") else None

    def _record(self, row: Mapping[str, Any]) -> None:
        with self.ledger.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n")
