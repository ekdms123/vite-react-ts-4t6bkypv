from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .representation_tournament import RepresentationTournamentPlan
from .worker_provider import WorkerProvider, WorkerSession
from .worker_truth import assert_independent_worker


def _sha(value: Any) -> str:
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ArenaLaneResult:
    frame_id: str
    mode: str
    worker_id: str
    session_ref: str
    success: bool
    output: Any
    worker_truth: dict[str, Any]
    evidence_refs: tuple[str, ...]
    started_at: float
    finished_at: float
    error: str = ""

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ArenaRun:
    arena_id: str
    objective: str
    lane_results: tuple[ArenaLaneResult, ...]
    all_workers_independent: bool
    successful_lane_count: int
    created_at: float
    all_workers_cognitive: bool = False
    all_workers_closed_loop_agents: bool = False

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class RepresentationExecutionArena:
    """Execute representation frames on evidence-bound independent workers.

    RepresentationTournament chooses *different ways to attack the same goal*.
    This arena turns those frames into real worker sessions.  It refuses to call a
    thread/callable an independent worker and records result-envelope evidence for
    every lane.  The provider may be a local process, remote session, model call, or
    other implementation of WorkerProvider.
    """

    def __init__(self, provider: WorkerProvider) -> None:
        self.provider=provider

    def _start_lane(self, objective: str, frame) -> WorkerSession:
        session=self.provider.start(
            objective=objective,
            context={
                "arena_frame_id":frame.frame_id,
                "arena_mode":frame.mode,
                "frame_instruction":frame.instruction,
                "frame_purpose":frame.purpose,
                "preserve_goal":bool(frame.preserve_goal),
                "immutable_objective":objective,
            },
        )
        assert_independent_worker(session.truth())
        return session


    @staticmethod
    def run_materialized_representation(genome, cases):
        """Execute a generated representation/interpreter body over concrete cases.

        This path is deliberately different from worker-frame prompting: the representation
        is no longer prose. Its generated observer, operation semantics and program are run.
        """
        from .world_interpreter import WorldInterpreter
        interpreter = WorldInterpreter()
        rows = []
        for case in cases:
            state = case.get("state") if isinstance(case, Mapping) else getattr(case, "state", {})
            history = case.get("history") if isinstance(case, Mapping) else getattr(case, "history", ())
            required = (case.get("required_action", case.get("required")) if isinstance(case, Mapping)
                        else getattr(case, "required_action", None))
            trace = interpreter.execute(genome, state=state or {}, history=list(history or ()))
            rows.append({
                "representation": interpreter.observe(genome, state or {}, list(history or ())),
                "output": trace.output,
                "required": required,
                "success": trace.output == required,
                "birth_requests": [asdict(x) for x in trace.birth_requests],
                "events": list(trace.events),
            })
        return {
            "schema": "jigaewol_materialized_representation_run_v1",
            "genome_id": genome.genome_id,
            "case_count": len(rows),
            "success_count": sum(1 for x in rows if x["success"]),
            "all_satisfied": bool(rows) and all(x["success"] for x in rows),
            "rows": rows,
        }

    def run(
        self,
        plan: RepresentationTournamentPlan,
        *,
        objective: str,
        timeout_s: float = 120.0,
        poll_interval_s: float = 0.05,
    ) -> ArenaRun:
        if not plan.frames:
            raise ValueError("arena requires at least one representation frame")
        sessions=[]
        for frame in plan.frames:
            sessions.append((frame,self._start_lane(str(objective),frame)))
        deadline=time.time()+max(.1,float(timeout_s))
        pending={s.worker_id:(f,s) for f,s in sessions}
        results: dict[str,ArenaLaneResult]={}
        while pending and time.time()<deadline:
            for worker_id,(frame,session) in list(pending.items()):
                status=dict(self.provider.status(session))
                if not status.get("complete"):
                    continue
                result=dict(status.get("result") or {})
                success=status.get("success") is True
                output=result.get("output",result.get("result",result))
                evidence=list(map(str,result.get("evidence_refs") or ()))
                evidence.append("worker-session:"+session.session_ref)
                evidence.append("worker-result-sha256:"+_sha(result))
                results[frame.frame_id]=ArenaLaneResult(
                    frame_id=frame.frame_id,mode=frame.mode,worker_id=session.worker_id,
                    session_ref=session.session_ref,success=success,output=output,
                    worker_truth=dict(status.get("worker_truth") or session.truth(
                        receipt_ref=session.session_ref, result_return_path_observed=True
                    ).as_mapping()),
                    evidence_refs=tuple(dict.fromkeys(evidence)),started_at=session.started_at,
                    finished_at=time.time(),error=str(result.get("error") or ""),
                )
                pending.pop(worker_id,None)
            if pending:
                time.sleep(max(.005,float(poll_interval_s)))
        for worker_id,(frame,session) in list(pending.items()):
            stop_error = ""
            try:
                self.provider.stop(session)
            except Exception as exc:
                stop_error = f"; stop_failure={type(exc).__name__}:{exc}"
            results[frame.frame_id]=ArenaLaneResult(
                frame_id=frame.frame_id,mode=frame.mode,worker_id=session.worker_id,
                session_ref=session.session_ref,success=False,output=None,
                worker_truth=session.truth(receipt_ref=session.session_ref).as_mapping(),
                evidence_refs=("worker-session:"+session.session_ref,),started_at=session.started_at,
                finished_at=time.time(),error="arena lane timeout" + stop_error,
            )
        ordered=tuple(results[f.frame_id] for f in plan.frames)
        material={"objective":str(objective),"frames":[x.frame_id for x in plan.frames],"sessions":[x.session_ref for x in ordered]}
        return ArenaRun(
            arena_id="arena_"+_sha(material)[:20],objective=str(objective),lane_results=ordered,
            all_workers_independent=all(bool(x.worker_truth.get("independent_worker")) for x in ordered),
            successful_lane_count=sum(1 for x in ordered if x.success),created_at=time.time(),
            all_workers_cognitive=all(bool(x.worker_truth.get("independent_cognitive_worker")) for x in ordered),
            all_workers_closed_loop_agents=all(bool(x.worker_truth.get("closed_loop_agent_worker")) for x in ordered),
        )
