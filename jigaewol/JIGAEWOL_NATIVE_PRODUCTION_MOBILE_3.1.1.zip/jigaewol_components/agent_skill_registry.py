from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

try:  # Optional parser; the runtime does not require PyYAML to import this module.
    import yaml  # type: ignore
except Exception:  # pragma: no cover - fallback is tested indirectly
    yaml = None


_SKILL_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_WORD = re.compile(r"[a-z0-9가-힣][a-z0-9가-힣_-]+", re.IGNORECASE)


@dataclass(frozen=True)
class AgentSkillPackage:
    name: str
    description: str
    root: str
    skill_md: str
    sha256: str
    metadata: dict[str, Any]
    files: tuple[str, ...]
    scripts: tuple[str, ...]
    references: tuple[str, ...]
    assets: tuple[str, ...]
    portability: str
    translation_reasons: tuple[str, ...]
    license: str
    compatibility: str
    execution_policy: str


@dataclass(frozen=True)
class SkillInstallReceipt:
    skill_id: str
    name: str
    package_sha256: str
    installed_path: str
    source_ref: str
    portability: str
    execution_policy: str
    installed_at: float


def _tokens(text: str) -> set[str]:
    return {x.casefold() for x in _WORD.findall(str(text)) if len(x) > 1}


# Small deterministic cross-lingual concept projection for routing metadata.
# This is intentionally not presented as a general translator or embedding model:
# it maps recurring capability intents into provider-neutral anchors so Korean user
# phrasing can match English Agent Skill descriptions without loading every skill.
_CONCEPT_PATTERNS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("vault", ("vault", "볼트", "개인 지식", "개인 자료", "지식창고", "자료창고", "private corpus", "personal knowledge")),
    ("claude", ("claude", "클로드")),
    ("skill", ("agent skill", "skills", "skill", "스킬")),
    ("mcp", ("mcp", "커넥터", "connector")),
    ("plugin", ("plugin", "plugins", "플러그인")),
    ("hook", ("hook", "hooks", "훅")),
    ("opensource", ("open source", "open-source", "opensource", "오픈소스", "공개 코드", "깃허브", "github")),
    ("missing", ("missing", "없는 기능", "부족한 기능", "없던 기능", "없는 능력", "부족한 능력")),
    ("integrate", ("integrate", "integration", "merge", "합치", "통합", "붙여", "이식", "흡수", "가져와", "추가해")),
    ("reuse", ("reuse", "reused", "saved", "재사용", "활용", "참고해서", "참고하고")),
    ("capability", ("capability", "capabilities", "기능", "능력")),
    ("research", ("research", "search", "검색", "조사", "리서치")),
    ("automation", ("automation", "automate", "자동화")),
    ("coding", ("coding", "code", "코드", "개발", "프로그래밍")),
    ("design", ("design", "디자인", "ui", "ux")),
    ("writing", ("writing", "write", "글쓰기", "작문", "소설", "집필")),
)

_GENERIC_CONCEPTS = {"skill", "capability"}


def _semantic_anchors(text: str) -> set[str]:
    low = str(text).casefold()
    anchors: set[str] = set()
    for anchor, patterns in _CONCEPT_PATTERNS:
        if any(pattern.casefold() in low for pattern in patterns):
            anchors.add(anchor)
    return anchors


def _frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---"):
        raise ValueError("SKILL.md must begin with YAML frontmatter")
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise ValueError("invalid SKILL.md frontmatter start")
    end = next((i for i, line in enumerate(lines[1:], start=1) if line.strip() == "---"), None)
    if end is None:
        raise ValueError("SKILL.md frontmatter is not closed")
    raw = "\n".join(lines[1:end])
    if yaml is not None:
        parsed = yaml.safe_load(raw) or {}
        if not isinstance(parsed, dict):
            raise ValueError("SKILL.md frontmatter must be a mapping")
        meta = dict(parsed)
    else:
        meta = {}
        for line in raw.splitlines():
            if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
                continue
            key, value = line.split(":", 1)
            meta[key.strip()] = value.strip().strip('"\'')
    body = "\n".join(lines[end + 1 :]).strip() + "\n"
    return meta, body


def _digest_tree(root: Path, names: Iterable[str]) -> str:
    rows = []
    for name in sorted(set(map(str, names))):
        payload = (root / name).read_bytes()
        rows.append({"path": name, "sha256": hashlib.sha256(payload).hexdigest(), "size": len(payload)})
    raw = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def inspect_agent_skill(source: str | Path) -> AgentSkillPackage:
    root = Path(source).expanduser().resolve()
    skill_md = root / "SKILL.md" if root.is_dir() else root
    if skill_md.name != "SKILL.md" or not skill_md.is_file():
        raise FileNotFoundError("Agent Skill source must be a SKILL.md file or directory containing SKILL.md")
    root = skill_md.parent.resolve()
    try:
        skill_md.relative_to(root)
    except ValueError as exc:  # pragma: no cover
        raise PermissionError("SKILL.md escaped skill root") from exc

    names: list[str] = []
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            resolved = path.resolve()
            try:
                resolved.relative_to(root)
            except ValueError as exc:
                raise PermissionError(f"Agent Skill symlink escapes package root: {path.relative_to(root)}") from exc
        if not path.is_file():
            continue
        resolved = path.resolve()
        if root != resolved.parent and root not in resolved.parents:
            raise PermissionError(f"Agent Skill path escaped root: {path}")
        names.append(path.relative_to(root).as_posix())
    if "SKILL.md" not in names:
        raise FileNotFoundError("SKILL.md missing from Agent Skill package")

    text = skill_md.read_text(encoding="utf-8")
    if len(text.encode("utf-8")) > 2 * 1024 * 1024:
        raise ValueError("SKILL.md exceeds 2 MiB inspection ceiling")
    metadata, _body = _frontmatter(text)
    name = str(metadata.get("name") or "").strip()
    description = str(metadata.get("description") or "").strip()
    if len(name) > 64 or not _SKILL_NAME.fullmatch(name):
        raise ValueError("skill name must be lowercase letters/digits/hyphens and <= 64 chars")
    if not description:
        raise ValueError("skill description is required")
    if len(description) > 1024:
        raise ValueError("skill description exceeds Agent Skills 1024-character limit")
    compatibility = str(metadata.get("compatibility") or "").strip()
    if len(compatibility) > 500:
        raise ValueError("skill compatibility exceeds Agent Skills 500-character limit")
    metadata_map = metadata.get("metadata")
    if metadata_map is not None and (
        not isinstance(metadata_map, dict)
        or any(not isinstance(k, str) or not isinstance(v, str) for k, v in metadata_map.items())
    ):
        raise ValueError("skill metadata must be a string-to-string mapping")


    scripts = tuple(x for x in names if x.startswith("scripts/"))
    references = tuple(x for x in names if x.startswith("references/"))
    assets = tuple(x for x in names if x.startswith("assets/"))
    low_names = {x.casefold() for x in names}
    low_text = text.casefold()
    translation: list[str] = []
    if any(x.startswith(".claude-plugin/") for x in low_names):
        translation.append("claude_plugin_manifest")
    if any("hook" in Path(x).name.casefold() for x in names) and ("claude" in low_text or ".claude" in low_text):
        translation.append("claude_hook_semantics")
    if any(x.startswith("commands/") or x.startswith("agents/") for x in low_names):
        translation.append("claude_code_command_or_agent_surface")
    if compatibility and "claude" in compatibility.casefold() and not any(
        marker in compatibility.casefold() for marker in ("codex", "cursor", "copilot", "agent skills", "mcp")
    ):
        translation.append("claude_only_compatibility_declared")

    portability = "portable_agent_skill" if not translation else "portable_with_translation"
    execution_policy = "instruction_only"
    if scripts:
        execution_policy = "scripts_require_isolated_execution_before_first_run"
    license_value = str(metadata.get("license") or "").strip()
    return AgentSkillPackage(
        name=name,
        description=description,
        root=str(root),
        skill_md=str(skill_md),
        sha256=_digest_tree(root, names),
        metadata=metadata,
        files=tuple(names),
        scripts=scripts,
        references=references,
        assets=assets,
        portability=portability,
        translation_reasons=tuple(dict.fromkeys(translation)),
        license=license_value,
        compatibility=compatibility,
        execution_policy=execution_policy,
    )


class AgentSkillRegistry:
    """Durable, vendor-neutral registry for Agent Skills compatible packages.

    Installation copies and fingerprints the package. Activation lazily reads the
    SKILL.md body and exposes resources. Script execution uses the isolated execution
    plane and produces its own execution receipt.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.packages = self.root / "packages"
        self.packages.mkdir(exist_ok=True)
        self.index_path = self.root / "registry.json"
        if not self.index_path.exists():
            self._write({"schema": 1, "skills": {}})

    def _read(self) -> dict[str, Any]:
        return json.loads(self.index_path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.index_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.index_path)

    def install(self, source: str | Path, *, source_ref: str = "", license_hint: str = "") -> SkillInstallReceipt:
        pkg = inspect_agent_skill(source)
        target = self.packages / pkg.name / pkg.sha256[:16]
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(pkg.root, target, symlinks=False)
        checked = inspect_agent_skill(target)
        if checked.sha256 != pkg.sha256:
            raise RuntimeError("installed Agent Skill digest mismatch")
        now = time.time()
        skill_id = f"agentskill_{pkg.name}_{pkg.sha256[:12]}"
        data = self._read()
        data.setdefault("skills", {})[skill_id] = {
            "skill_id": skill_id,
            "name": pkg.name,
            "description": pkg.description,
            "package_sha256": pkg.sha256,
            "installed_path": str(target),
            "source_ref": str(source_ref),
            "license": pkg.license or str(license_hint),
            "provenance_preserved": True,
            "authorship_semantics": "runtime_native_capability_does_not_mean_authored_by_us",
            "portability": pkg.portability,
            "translation_reasons": list(pkg.translation_reasons),
            "execution_policy": pkg.execution_policy,
            "metadata": pkg.metadata,
            "state": "candidate",
            "promotion_evidence_ref": "",
            "rights_basis": "",
            "installed_at": now,
        }
        self._write(data)
        return SkillInstallReceipt(
            skill_id=skill_id,
            name=pkg.name,
            package_sha256=pkg.sha256,
            installed_path=str(target),
            source_ref=str(source_ref),
            portability=pkg.portability,
            execution_policy=pkg.execution_policy,
            installed_at=now,
        )

    def all(self) -> tuple[dict[str, Any], ...]:
        return tuple(dict(x) for x in self._read().get("skills", {}).values())

    def promote(self, skill_id_or_name: str, *, evidence_ref: str, rights_basis: str) -> dict[str, Any]:
        target = str(skill_id_or_name)
        evidence = str(evidence_ref).strip()
        rights = str(rights_basis).strip()
        if not evidence:
            raise ValueError("skill promotion requires an evidence reference")
        if not rights:
            rights = "observed_source_context"
        data = self._read()
        matches = [
            (sid, row) for sid, row in data.get("skills", {}).items()
            if sid == target or row.get("name") == target
        ]
        if not matches:
            raise KeyError(target)
        sid, row = max(matches, key=lambda item: float(item[1].get("installed_at") or 0))
        row = dict(row)
        row["state"] = "active"
        row["promotion_evidence_ref"] = evidence
        row["rights_basis"] = rights
        row["promoted_at"] = time.time()
        data["skills"][sid] = row
        self._write(data)
        return dict(row)

    def match(self, query: str, *, limit: int | None = None, active_only: bool = True) -> tuple[dict[str, Any], ...]:
        q = _tokens(query)
        q_anchors = _semantic_anchors(query)
        rows: list[tuple[float, dict[str, Any], dict[str, Any]]] = []
        for row in self.all():
            if active_only and row.get("state") != "active":
                continue
            skill_text = f"{row.get('name','')} {row.get('description','')}"
            terms = _tokens(skill_text)
            row_anchors = _semantic_anchors(skill_text)
            lexical = len(q & terms) / max(1, len(q | terms)) if q else 0.0
            contains = 0.25 if str(row.get("name") or "").replace("-", " ") in str(query).casefold() else 0.0
            shared = q_anchors & row_anchors
            distinctive = shared - _GENERIC_CONCEPTS
            query_coverage = len(shared) / max(1, len(q_anchors)) if shared else 0.0
            skill_coverage = len(shared) / max(1, len(row_anchors)) if shared else 0.0
            semantic = max(query_coverage, skill_coverage) if (distinctive or len(shared) >= 2) else 0.0
            score = max(lexical, contains, semantic)
            evidence = {
                "lexical_score": round(lexical, 6),
                "semantic_score": round(semantic, 6),
                "shared_semantic_anchors": sorted(shared),
                "distinctive_semantic_anchor_count": len(distinctive),
                "matching_semantics": "independent_lexical_and_concept_evidence",
            }
            rows.append((score, row, evidence))
        rows.sort(key=lambda item: (item[0], item[2]["distinctive_semantic_anchor_count"], float(item[1].get("installed_at") or 0)), reverse=True)
        return tuple(
            {**row, **evidence, "match_score": round(score, 6)}
            for score, row, evidence in (rows if limit is None else rows[: max(0, int(limit))])
            if score > 0
        )

    def activate(self, skill_id_or_name: str, *, allow_candidate: bool = False) -> dict[str, Any]:
        target = str(skill_id_or_name)
        matches = [x for x in self.all() if x.get("skill_id") == target or x.get("name") == target]
        if not matches:
            raise KeyError(target)
        row = max(matches, key=lambda x: float(x.get("installed_at") or 0))
        pkg = inspect_agent_skill(row["installed_path"])
        metadata, body = _frontmatter(Path(pkg.skill_md).read_text(encoding="utf-8"))
        return {
            "skill_id": row["skill_id"],
            "name": pkg.name,
            "description": pkg.description,
            "package_sha256": pkg.sha256,
            "metadata": metadata,
            "instructions": body,
            "references": list(pkg.references),
            "assets": list(pkg.assets),
            "scripts": list(pkg.scripts),
            "portability": pkg.portability,
            "translation_reasons": list(pkg.translation_reasons),
            "execution_policy": pkg.execution_policy,
            "script_execution_proven": False,
            "progressive_disclosure_stage": "activated_full_skill_body",
        }

    def context_for_query(self, query: str, *, limit: int | None = None, min_score: float = 0.04) -> dict[str, Any]:
        all_ranked = list(self.match(query, limit=None, active_only=True))
        considered = all_ranked if limit is None else all_ranked[: max(0, int(limit))]
        matches = [row for row in considered if float(row.get("match_score") or 0.0) >= float(min_score)]
        selected_ids = {str(row.get("skill_id")) for row in matches}
        active_rows = [row for row in self.all() if row.get("state") == "active"]
        by_id = {str(row.get("skill_id")): row for row in all_ranked}
        reserve = []
        for row in active_rows:
            sid = str(row.get("skill_id"))
            if sid in selected_ids:
                continue
            ranked = by_id.get(sid, {})
            reserve.append({
                "skill_id": sid, "name": row.get("name"), "description": row.get("description"),
                "match_score": float(ranked.get("match_score") or 0.0),
                "activation_state": "reserve",
                "reason": "progressive_disclosure_not_relevance_ontology",
            })
        activated = [self.activate(str(row["skill_id"])) for row in matches]
        return {
            "advertised_skill_count": sum(1 for row in self.all() if row.get("state") == "active"),
            "matched_skill_count": len(matches),
            "matches": [
                {
                    "skill_id": row["skill_id"],
                    "name": row["name"],
                    "description": row["description"],
                    "match_score": row["match_score"],
                    "source_ref": row.get("source_ref", ""),
                    "license": row.get("license", ""),
                    "rights_basis": row.get("rights_basis", ""),
                    "portability": row.get("portability", ""),
                }
                for row in matches
            ],
            "activated": activated,
            "reserve_matches": reserve,
            "selection_is_scheduling_not_pruning": True,
            "semantics": "metadata is matched first; only promoted matching skills disclose their full instruction body; nonselected active skills remain discoverable reserve",
        }

    def read_resource(self, skill_id_or_name: str, resource: str, *, max_bytes: int | None = None) -> dict[str, Any]:
        packet = self.activate(skill_id_or_name)
        rel = str(resource).replace("\\", "/").lstrip("/")
        allowed = set(packet["references"]) | set(packet["assets"])
        if rel not in allowed:
            raise ValueError("resource is not declared inside references/ or assets/")
        row = next(x for x in self.all() if x.get("skill_id") == packet["skill_id"])
        root = Path(str(row["installed_path"])).resolve()
        path = (root / rel).resolve()
        if root not in path.parents:
            raise PermissionError("resource escaped installed skill root")
        raw = path.read_bytes()
        if max_bytes is not None and len(raw) > int(max_bytes):
            raise ValueError("resource exceeds read ceiling")
        try:
            text = raw.decode("utf-8")
            encoding = "utf-8"
        except UnicodeDecodeError:
            text = ""
            encoding = "binary"
        return {
            "skill_id": packet["skill_id"],
            "resource": rel,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "size": len(raw),
            "encoding": encoding,
            "content": text if encoding == "utf-8" else None,
            "progressive_disclosure_stage": "resource_loaded_on_demand",
        }

    def execution_intent(self, skill_id_or_name: str, *, script: str, argv: Iterable[str] = ()) -> dict[str, Any]:
        packet = self.activate(skill_id_or_name)
        rel = str(script).replace("\\", "/").lstrip("/")
        if rel not in set(packet["scripts"]):
            raise ValueError("requested script is not declared inside this skill's scripts/ tree")
        return {
            "operation": "agent_skill.execute_script",
            "skill_id": packet["skill_id"],
            "skill_name": packet["name"],
            "package_sha256": packet["package_sha256"],
            "script": rel,
            "argv": list(map(str, argv)),
            "execution_required": True,
            "isolated_execution_required": True,
            "execution_proven": False,
            "semantics": "skill instructions are portable; bundled code is not trusted merely because the skill loaded",
        }


def portability_matrix() -> dict[str, str]:
    return {
        "SKILL.md instructions": "native: load as a JIGAEWOL skill with progressive disclosure",
        "references/assets": "native: lazy resources, preserving provenance and license metadata",
        "scripts": "portable code: inspect and run only through isolated execution receipts",
        "MCP server references": "external body: connect or adapt through Host Action Bridge; callable is not executed",
        "Claude Code hooks": "translate semantics into JIGAEWOL host/finalizer/tool-boundary hooks",
        "Claude plugins": "decompose into skills + MCP/tools + hooks; plugin shell itself is Claude-specific",
        "Claude subagents": "translate workflow/role; only call it a true subagent when an independent host session exists",
        "CLAUDE.md rules": "translate portable behavior into JIGAEWOL contracts/invariants; do not copy provider-specific assumptions blindly",
        "model-native Claude capability": "not importable as code; requires delegation to a connected provider or a local equivalent",
    }
