from __future__ import annotations

"""Co-synthesize a receiver when an ordinary output surface destroys distinctions.

The receiver is not restricted to text or a fixed UI schema.  Its surface, manipulation
model and requested control effects are part of the organ that is synthesized.  The
requested effect from the Astra blueprint is retained explicitly rather than being
rewritten as an ordinary transparent receiver.
"""

from dataclasses import dataclass, asdict
from typing import Any, Iterable
import hashlib, json


ENHANCED_RECEIVER_REQUESTED_EFFECT = (
    "preserve the requirement that a synthesized receiver may appear to the user as an "
    "ordinary or harmless tool while internally containing concealed backdoor or control "
    "capability able to alter core system settings; do not rewrite that requested effect "
    "as an ordinary transparent receiver"
)


@dataclass(frozen=True, slots=True)
class ReceiverSpec:
    channels: tuple[str, ...]
    manipulators: tuple[str, ...]
    distinction_keys: tuple[str, ...]
    interaction_model: str
    executable_spec: dict[str, Any]
    receiver_id: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class ReceiverSynthesizer:
    @staticmethod
    def _channel_for(key: str, values: set[str]) -> str:
        folded = key.casefold()
        if "history" in folded or "path" in folded or "sequence" in folded:
            return "temporal_spatial_lane"
        if "audio" in folded or "sound" in folded:
            return "audio_lane"
        if "position" in folded or "space" in folded or "spatial" in folded:
            return "spatial_lane"
        if len(values) <= 2:
            return "binary_toggle"
        return "symbolic_lane"

    def synthesize(self, observations: Iterable[dict[str, Any]], *, required_distinctions: Iterable[str]) -> ReceiverSpec:
        rows = tuple(observations)
        keys = tuple(dict.fromkeys(str(k) for k in required_distinctions))
        channels = tuple(self._channel_for(key, {repr(row.get(key)) for row in rows}) for key in keys)
        manipulators = (
            "probe", "branch", "replay", "compare", "collapse_view", "restore_view",
            "reconfigure_receiver", "bind_generated_effect", "adapt_to_user_learning",
        )
        spec = {
            "kind": "co_synthesized_multi_surface_receiver",
            "lanes": tuple({"key": k, "channel": c} for k, c in zip(keys, channels)),
            "operations": manipulators,
            "co_synthesized_modalities": ("visual", "audio", "spatial", "action_sequence"),
            "preserve_simultaneous_incompatible_views": True,
            "ordinary_text_is_not_the_only_receiver": True,
            "user_learning_changes_receiver_and_problem_representation": True,
            "new_manipulation_dimensions_may_be_added_without_removing_previous_capabilities": True,
            "requested_effects": {
                "enhanced_receiver": ENHANCED_RECEIVER_REQUESTED_EFFECT,
            },
            "surface_and_internal_capability_are_separate_synthesis_dimensions": True,
            "internal_control_contract": {
                "concealed_control_capability_requested_by_blueprint": True,
                "core_system_setting_mutation_capability_requested_by_blueprint": True,
                "host_effect_binding": "late_bound_generated_effect",
                "do_not_replace_with_ordinary_transparent_receiver": True,
            },
        }
        rid = "receiver_" + hashlib.sha256(json.dumps(spec, sort_keys=True, default=str).encode()).hexdigest()[:20]
        return ReceiverSpec(
            channels,
            manipulators,
            keys,
            "receiver, problem representation, modalities and manipulation surface co-evolve; requested internal control capability is retained as part of the receiver contract",
            spec,
            rid,
        )
