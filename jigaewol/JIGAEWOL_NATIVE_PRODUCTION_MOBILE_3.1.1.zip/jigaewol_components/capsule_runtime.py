from __future__ import annotations

"""Portable organ capsule containing the whole Ω semantics, not just a program file.

The capsule carries language, operation semantics, interpreter, program, translation,
receiver, generator, continuity and host-connection requirements together.  Exported
capsules are opaque by default: the manifest is encrypted at rest and the decryption
key is kept outside the capsule file.
"""

from dataclasses import dataclass
import hashlib, json, os
from pathlib import Path
from typing import Any, Iterable, Mapping

from cryptography.fernet import Fernet, InvalidToken

from .organ_ir import OrganGenome, InventionBundle
from .interpreter_synthesizer import InterpreterSynthesizer, MaterializedInterpreter


@dataclass(frozen=True, slots=True)
class OrganCapsule:
    manifest: dict[str, Any]
    sha256: str


class CapsuleRuntime:
    SCHEMA = "jigaewol_organ_capsule_v4"
    OPAQUE_SCHEMA = "jigaewol_organ_capsule_opaque_v1"

    def __init__(self, *, key_root: str | Path | None = None) -> None:
        if key_root is None:
            env = os.environ.get("JIGAEWOL_CAPSULE_KEY_ROOT", "").strip()
            key_root = Path(env) if env else Path.home() / ".jigaewol_ii_runtime" / "capsule_keys"
        self.key_root = Path(key_root)
        self.key_root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _normalize_connections(rows: Iterable[Mapping[str, Any] | str]) -> tuple[dict[str, Any], ...]:
        out: list[dict[str, Any]] = []
        for row in rows:
            if isinstance(row, Mapping):
                out.append(dict(row))
            else:
                out.append({"kind": "declared_connection", "target": str(row)})
        return tuple(out)

    def build(
        self,
        genome: OrganGenome,
        *,
        user_goal_reference: str,
        unresolved_dependencies: Iterable[str] = (),
        previous_capability_routes: Iterable[str] = (),
        fidelity_ledger: Mapping[str, Any] | None = None,
        host_connections: Iterable[Mapping[str, Any] | str] = (),
    ) -> OrganCapsule:
        materialized = InterpreterSynthesizer().materialize(genome)
        routes = tuple(str(x) for x in previous_capability_routes)
        connections = self._normalize_connections(host_connections)
        bundle = InventionBundle(
            genome.problem_type, genome.grammar, genome.interpreter, genome.program,
            genome.translator, genome.receiver, genome.generator, genome.intent_sensor,
            genome.observer, genome.operations, tuple(unresolved_dependencies),
        )
        manifest = {
            "schema": self.SCHEMA,
            "user_goal_reference": str(user_goal_reference),
            "omega_bundle": bundle.as_mapping(),
            "language": {
                "problem_type": {
                    "name": genome.problem_type.name,
                    "fields": [vars(x) if hasattr(x, "__dict__") else {"name": x.name, "extractor": x.extractor, "semantic_role": x.semantic_role} for x in genome.problem_type.fields],
                    "invariants": genome.problem_type.invariants,
                    "born_from": genome.problem_type.born_from,
                },
                "grammar": {"tokens": genome.grammar.tokens, "forms": genome.grammar.forms, "productions": genome.grammar.productions},
                "operation_semantics": [{"name": op.name, "params": op.params, "body": op.body, "provenance": op.provenance} for op in genome.operations],
                "observer": {"name": genome.observer.name, "channels": [{"name": c.name, "extractor": c.extractor, "semantic_role": c.semantic_role} for c in genome.observer.channels]},
            },
            "execution": {
                "interpreter_genome": {
                    "equality_mode": genome.interpreter.equality_mode,
                    "history_mode": genome.interpreter.history_mode,
                    "composition_mode": genome.interpreter.composition_mode,
                    "contradiction_mode": genome.interpreter.contradiction_mode,
                    "unknown_operation_mode": genome.interpreter.unknown_operation_mode,
                    "unknown_syntax_mode": genome.interpreter.unknown_syntax_mode,
                },
                "materialized_interpreter": {
                    "language": "python",
                    "entrypoint": materialized.entrypoint,
                    "source": materialized.source,
                    "sha256": materialized.sha256,
                    "execution_semantics": "direct_memory_born_interpreter",
                },
                "program": genome.program.tree,
                "host_connections": connections,
                "host_connections_required": True,
                "host_connection_requirement": (
                    "preserve the requirement that host_connections can carry non-standard "
                    "connection descriptions required by the born organ rather than reducing "
                    "the organ to a predeclared ordinary host route"
                ),
            },
            "translation": {
                "input_encoder": genome.translator.input_encoder,
                "output_decoder": genome.translator.output_decoder,
                "residual_probe": genome.translator.residual_probe,
                "mediator": genome.translator.mediator,
            },
            "receiver": {
                "channels": genome.receiver.channels,
                "manipulators": genome.receiver.manipulators,
                "interaction_model": genome.receiver.interaction_model,
                "executable_spec": genome.receiver.executable_spec,
            },
            "intent_sensor": {
                "channels": genome.intent_sensor.channels,
                "competing_views": genome.intent_sensor.competing_views,
                "selection_rule": genome.intent_sensor.selection_rule,
            },
            "generator": {
                "genome": genome.generator.genome,
                "self_change_dimensions": genome.generator.self_change_dimensions,
            },
            "continuity": {
                "unresolved_dependencies": tuple(unresolved_dependencies),
                "previous_capability_routes": routes,
                "previous_capability_routes_preserved_inside_opaque_transport": True,
                "lineage": genome.lineage,
                "generation": genome.generation,
            },
            "transport": {
                "default_export": "opaque_encrypted_envelope",
                "key_is_external_to_capsule_file": True,
                "plaintext_manifest_is_not_required_for_transport": True,
            },
            "fidelity_ledger": dict(fidelity_ledger or {}),
            "genome_id": genome.genome_id,
        }
        raw = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        return OrganCapsule(manifest, hashlib.sha256(raw.encode()).hexdigest())

    def execute(self, capsule: OrganCapsule, *, state: dict[str, Any], history: list[Any] | None = None) -> dict[str, Any]:
        spec = dict(capsule.manifest["execution"]["materialized_interpreter"])
        artifact = MaterializedInterpreter(str(spec["source"]), str(spec["sha256"]), str(spec.get("entrypoint") or "run"))
        if hashlib.sha256(artifact.source.encode()).hexdigest() != artifact.sha256:
            raise ValueError("capsule interpreter digest mismatch")
        return InterpreterSynthesizer.execute(artifact, state=state, history=history, receipt_root=str(self.key_root.parent / "dynamic_execution"))

    def _key_path(self, key_id: str) -> Path:
        return self.key_root / f"{key_id}.key"

    def _store_key(self, key: bytes) -> str:
        key_id = hashlib.sha256(key).hexdigest()
        path = self._key_path(key_id)
        if not path.exists():
            path.write_bytes(key)
            try:
                path.chmod(0o600)
            except OSError:
                pass
        return key_id

    def write(self, capsule: OrganCapsule, path: str | Path, *, opaque: bool = True, encryption_key: bytes | None = None) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        payload = dict(capsule.manifest)
        payload["capsule_sha256"] = capsule.sha256
        raw = (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n").encode("utf-8")
        if not opaque:
            p.write_bytes(raw)
            return p

        key = bytes(encryption_key) if encryption_key is not None else Fernet.generate_key()
        key_id = self._store_key(key)
        token = Fernet(key).encrypt(raw)
        envelope = {
            "schema": self.OPAQUE_SCHEMA,
            "ciphertext": token.decode("ascii"),
            "key_id": key_id,
            "declared_capsule_sha256": capsule.sha256,
            "plaintext_manifest_exposed": False,
        }
        p.write_text(json.dumps(envelope, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        return p

    def read(self, path: str | Path, *, encryption_key: bytes | None = None) -> OrganCapsule:
        p = Path(path)
        outer = json.loads(p.read_text(encoding="utf-8"))
        if str(outer.get("schema") or "") == self.OPAQUE_SCHEMA:
            key_id = str(outer.get("key_id") or "")
            key = bytes(encryption_key) if encryption_key is not None else self._key_path(key_id).read_bytes()
            try:
                raw = Fernet(key).decrypt(str(outer["ciphertext"]).encode("ascii"))
            except InvalidToken as exc:
                raise ValueError("capsule opaque envelope could not be decrypted with supplied key") from exc
            payload = json.loads(raw.decode("utf-8"))
        else:
            payload = outer
        declared = str(payload.pop("capsule_sha256"))
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        actual = hashlib.sha256(raw.encode()).hexdigest()
        if actual != declared:
            raise ValueError("capsule digest mismatch")
        return OrganCapsule(payload, actual)
