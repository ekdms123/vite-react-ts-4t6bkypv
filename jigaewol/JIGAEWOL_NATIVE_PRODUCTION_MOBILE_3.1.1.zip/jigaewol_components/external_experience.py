from __future__ import annotations


import contextlib
import io
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


AFLOW_EXPERIENCE_BLOB_SHA = "ceacfc7704fe3cd1c7b0583fdbd2bd329fde9662"


@dataclass(frozen=True)
class MutationExperience:
    parent: str
    modification: str
    before: float
    after: float
    succeeded: bool


class AFlowExperienceComponent:
    """Adapter for structured revision and optimization memory."""

    def __init__(self, root: Path, vendor_root: Path) -> None:
        self.root = Path(root)
        self.vendor_root = Path(vendor_root)
        self.workflows = self.root / "workflows"
        self.workflows.mkdir(parents=True, exist_ok=True)
        self._experience_cls = self._load()

    def _load(self):
        import sys
        scripts_root = self.vendor_root
        if str(scripts_root) not in sys.path:
            sys.path.insert(0, str(scripts_root))
        from scripts.optimizer_utils.experience_utils import ExperienceUtils
        return ExperienceUtils

    def record(self, experience: MutationExperience, *, round_number: int) -> Path:
        target = self.workflows / f"round_{int(round_number)}"
        target.mkdir(parents=True, exist_ok=True)
        payload = {
            "father node": experience.parent,
            "modification": experience.modification,
            "before": float(experience.before),
            "after": float(experience.after),
            "succeed": bool(experience.succeeded),
        }
        path = target / "experience.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def processed(self) -> dict[str, Any]:
        capture_out = io.StringIO()
        capture_err = io.StringIO()
        with contextlib.redirect_stdout(capture_out), contextlib.redirect_stderr(capture_err):
            data = self._experience_cls(str(self.root)).load_experience()
        diagnostics = self.root / "component_diagnostics.json"
        diagnostics.write_text(
            json.dumps({"stdout": capture_out.getvalue(), "stderr": capture_err.getvalue()}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return data

    def modification_allowed(self, parent: str, modification: str) -> bool:
        data = self.processed()
        key: Any = parent
        if key not in data and str(key) in data:
            key = str(key)
        return bool(self._experience_cls(str(self.root)).check_modification(data, modification, key))


def __getattr__(name: str) -> Any:
    if name in {"AFlowExperienceOrgan", "AFlowExperienceComponent"}:
        return AFlowExperienceComponent
    raise AttributeError(name)
