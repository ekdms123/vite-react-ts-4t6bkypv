from __future__ import annotations

from typing import Any

from .body_federation import BodyFederationRegistry
from .host_surface_registry import HostSurfaceRegistry


_CANONICAL_TO_SCOUT = {
    'search:community': 'community_search',
    'search:code_ecosystem': 'code_search',
    'search:research': 'research_search',
    'browser:interact': 'browser_search',
    'search:web_current': 'web_search',
    'search:first_party': 'web_search',
    'search:social_recommendation': 'social_search',
    'search:creator_graph': 'creator_search',
    'search:multilingual': 'multilingual_search',
    'search:personal_knowledge': 'personal_knowledge_search',
}


def sync_search_surfaces(
    bodies: BodyFederationRegistry,
    surfaces: HostSurfaceRegistry,
) -> dict[str, Any]:
    """Project callable bodies into SearchPortfolio's scheduling registry.

    BodyFederation remains the execution truth.  This projection exists only so the
    search scheduler does not maintain a second, stale view of what the host can do.
    """
    rows=[]
    for body in bodies.bodies():
        if body.state not in bodies.CALLABLE_STATES:
            continue
        scout_caps=[]
        manifest=dict((body.evidence or {}).get('manifest') or {})
        declared_role=str(manifest.get('role') or '').strip().casefold()
        for cap in body.capabilities:
            cap=str(cap)
            mapped=_CANONICAL_TO_SCOUT.get(cap)
            if not mapped:
                continue
            # browser:interact is often a secondary actuator on compute/design bodies.
            # It becomes a search scout only when the host itself declares browser/search
            # as its role; otherwise Figma/Floot-like bodies fake source diversity.
            if cap == 'browser:interact' and declared_role not in {'browser','search','academic_search'}:
                continue
            scout_caps.append(mapped)
        if not scout_caps:
            continue
        surface_id='body:'+body.body_id
        row=surfaces.upsert(
            surface_id,
            kind=(body.families[0] if body.families else 'host_body'),
            state='callable' if body.state == 'callable' else body.state,
            capabilities=tuple(dict.fromkeys(scout_caps)),
            connector_ref=body.executor,
            evidence={
                'body_id':body.body_id,
                'origin_ref':body.origin_ref,
                'canonical_capabilities':list(body.capabilities),
                'execution_truth_source':'BodyFederationRegistry',
            },
            evidence_strength=body.evidence_strength,
        )
        rows.append(row)
    return {
        'projected_surface_count':len(rows),
        'surface_ids':[x.surface_id for x in rows],
        'projection_is_execution_claim':False,
        'truth_source':'body_federation_callable_state',
    }
