"""User-provided local model adapter. No additional instructions are inserted.

Use an OpenAI-compatible /v1/chat/completions endpoint (including local Ollama).
This module never claims a model was invoked unless the HTTP response succeeds.
"""
from __future__ import annotations
import json
import os
from urllib.request import Request, urlopen
from urllib.parse import urlparse


class OpenAICompatibleModelCallback:
    def __init__(self, endpoint: str, model: str, *, timeout_seconds: int = 120):
        self.endpoint = str(endpoint).strip()
        self.model = str(model).strip()
        self.timeout_seconds = timeout_seconds
        url = urlparse(self.endpoint)
        if url.scheme not in ('http', 'https') or not url.netloc:
            raise ValueError('model endpoint must be an absolute HTTP(S) URL')
        if not self.model:
            raise ValueError('model name required')

    def __call__(self, exact_user_message: str, gateway_payload: dict):
        # Gateway payload is evidence/context, not an alternate user instruction.
        payload = {
            'model': self.model,
            'messages': [
                {'role':'user','content':'JIGAEWOL execution context. Use these actual observations and learned task mechanisms as context for the exact user request that follows.\n'+json.dumps({
                    'cognitive_frontier':gateway_payload.get('cognitive_frontier',{}),
                    'production_request':gateway_payload.get('production_request',{}),
                    'native_host_continuation':gateway_payload.get('native_host_continuation',{}),
                    'observed_actions':gateway_payload.get('observed_actions',[]),
                    'authority':['USER','JIGAEWOL','MODEL']},ensure_ascii=False,default=str)},
                {'role': 'user', 'content': exact_user_message}],
            'stream': False,
        }
        headers = {'Content-Type': 'application/json'}
        api_key = os.environ.get('JIGAEWOL_MODEL_API_KEY', '')
        if api_key:
            headers['Authorization'] = 'Bearer ' + api_key
        req = Request(self.endpoint, data=json.dumps(payload, ensure_ascii=False).encode('utf-8'),
                      headers=headers, method='POST')
        with urlopen(req, timeout=self.timeout_seconds) as response:
            content = json.load(response)
        text = content['choices'][0]['message']['content']
        if not isinstance(text, str):
            raise TypeError('model output is not a text message')
        return {'model':self.model,'response':text,'provider_response_id':content.get('id'),
                'input_sha256':gateway_payload['source_directive']['sha256'],
                'provider_observed':True}
