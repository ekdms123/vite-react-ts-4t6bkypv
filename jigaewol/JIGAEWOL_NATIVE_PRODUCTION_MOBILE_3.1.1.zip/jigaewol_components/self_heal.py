from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class HealEpisode:
    episode_id: str
    failure_family: str
    symptom: str
    baseline_capabilities: tuple[str, ...]
    candidate_capabilities: tuple[str, ...]
    state: str
    evidence_refs: tuple[str, ...]
    created_at: float
    metadata: dict[str, Any] = field(default_factory=dict)


class SelfHealSupervisor:
    """Monotonic self-heal ledger.

    A candidate is never promoted merely because a patch applied.  Promotion requires
    observed evidence and a non-regression capability relation.  Failed experiments stay
    in history; the runtime may keep the last proven baseline while continuing to search
    for a stronger candidate.  That is failure containment, not capability downgrade.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
        self.ledger = self.root / "self_heal.jsonl"

    @staticmethod
    def fingerprint(capabilities: Iterable[str]) -> str:
        return hashlib.sha256("\n".join(sorted(set(map(str, capabilities)))).encode()).hexdigest()

    def evaluate_candidate(
        self,
        *,
        failure_family: str,
        symptom: str,
        baseline_capabilities: Iterable[str],
        candidate_capabilities: Iterable[str],
        evidence_refs: Iterable[str],
        checks: Mapping[str, bool],
        metadata: Mapping[str, Any] | None = None,
    ) -> HealEpisode:
        base = tuple(sorted(set(map(str, baseline_capabilities))))
        cand = tuple(sorted(set(map(str, candidate_capabilities))))
        refs = tuple(dict.fromkeys(map(str, evidence_refs)))
        missing = sorted(set(base) - set(cand))
        failed_checks = sorted(k for k, ok in checks.items() if not bool(ok))
        state = "promoted" if (not missing and not failed_checks and refs) else "candidate_rejected_open"
        payload = json.dumps([failure_family, symptom, base, cand, refs, checks, time.time_ns()], ensure_ascii=False, sort_keys=True).encode()
        ep = HealEpisode(
            episode_id="heal_" + hashlib.sha256(payload).hexdigest()[:20],
            failure_family=str(failure_family), symptom=str(symptom),
            baseline_capabilities=base, candidate_capabilities=cand, state=state,
            evidence_refs=refs, created_at=time.time(),
            metadata={**dict(metadata or {}), "missing_baseline_capabilities":missing, "failed_checks":failed_checks,
                      "baseline_fingerprint":self.fingerprint(base), "candidate_fingerprint":self.fingerprint(cand)},
        )
        with self.ledger.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(asdict(ep), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return ep

    def failure_truth(self, *, failure_family: str, symptom: str, metadata: Mapping[str, Any] | None = None) -> dict[str, Any]:
        row = {"event":"failure_truth","failure_family":str(failure_family),"symptom":str(symptom),"metadata":dict(metadata or {}),"at":time.time()}
        with self.ledger.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return row
