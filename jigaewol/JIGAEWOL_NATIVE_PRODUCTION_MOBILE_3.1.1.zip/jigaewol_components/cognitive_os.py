from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping
from jigaewol_components.frontier_cognition import FrontierCognition
from jigaewol_components.microclosure import MicroClosureAuditor
from jigaewol_components.opportunistic_agenda import OpportunisticAgenda
from jigaewol_components.experience_graph import ExperienceGraph
from jigaewol_components.semantic_authority import bind_semantic_authority
from jigaewol_components.authority_guard import source_bound_objective


def _sha(payload: Any) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _tokens(text: str) -> set[str]:
    import re
    return {x.casefold() for x in re.findall(r"[A-Za-z0-9가-힣_+.-]{2,}", str(text))}


@dataclass(frozen=True)
class ObjectiveSpec:
    exact_command: str
    command_sha256: str
    requirement_atoms: tuple[dict[str, Any], ...]
    goal_anchor: dict[str, Any]
    user_interface: str = "mobile_chat"
    silent_goal_shrink_allowed: bool = False
    provider_names_are_ontology: bool = False
    current_capability_surface_is_ceiling: bool = False
    normal_operation_requires_external_paid_model_api: bool = False

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class FrontierRoute:
    route_id: str
    objective: str
    mechanism: str
    capability_needs: tuple[str, ...]
    binding_hints: tuple[str, ...]
    state: str = "untried"
    unknown_bindings_allowed: bool = True
    external_connection_step_may_be_required: bool = False
    provider_specific: bool = False
    evidence_refs: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CognitiveCell:
    cell_id: str
    objective: str
    independence_key: str
    binding_hints: tuple[str, ...]
    registry_bounded: bool
    purpose: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CognitiveOSPlan:
    plan_id: str
    objective_spec: ObjectiveSpec
    routes: tuple[FrontierRoute, ...]
    cells: tuple[CognitiveCell, ...]
    sensor_families: tuple[str, ...]
    capability_acquisition: dict[str, Any]
    boundary_reporting: dict[str, Any]
    creativity_policy: dict[str, Any]
    execution_policy: dict[str, Any]
    closure_policy: dict[str, Any]
    reusable_recipes: tuple[dict[str, Any], ...]
    open_representation: dict[str, Any]
    agenda: tuple[dict[str, Any], ...]
    recalled_experience: tuple[dict[str, Any], ...]
    created_at: float
    plan_sha256: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class CognitiveEvolutionMemory:
    """Stores observed route outcomes and reusable compositions without turning history into law."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "evolution.json"
        if not self.path.exists():
            self.path.write_text(json.dumps({"version": 1, "events": [], "recipes": []}, indent=2) + "\n", encoding="utf-8")

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    def record_route_result(
        self,
        *,
        objective: str,
        route_id: str,
        mechanism: str,
        success: bool | None,
        bindings: Iterable[str] = (),
        evidence_refs: Iterable[str] = (),
        learned_recipe: str = "",
    ) -> dict[str, Any]:
        event = {
            "event_id": "frontier_event_" + uuid.uuid4().hex[:18],
            "objective": str(objective),
            "objective_tokens": sorted(_tokens(objective)),
            "route_id": str(route_id),
            "mechanism": str(mechanism),
            "success": success,
            "bindings": tuple(dict.fromkeys(str(x) for x in bindings if str(x).strip())),
            "evidence_refs": tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x).strip())),
            "learned_recipe": str(learned_recipe or ""),
            "observed_at": time.time(),
        }
        event["event_sha256"] = _sha(event)
        data = self._read()
        data.setdefault("events", []).append(event)
        if event["learned_recipe"]:
            recipe = {
                "recipe_id": "recipe_" + _sha({"mechanism": mechanism, "bindings": event["bindings"], "recipe": event["learned_recipe"]})[:18],
                "objective_tokens": event["objective_tokens"],
                "mechanism": event["mechanism"],
                "bindings": event["bindings"],
                "recipe": event["learned_recipe"],
                "evidence_refs": event["evidence_refs"],
                "created_at": event["observed_at"],
                "status": "reusable_hypothesis_not_law",
                "observed_outcome": success,
            }
            known = {row.get("recipe_id") for row in data.setdefault("recipes", [])}
            if recipe["recipe_id"] not in known:
                data["recipes"].append(recipe)
        self._write(data)
        return event

    def relevant_recipes(self, objective: str, *, limit: int | None = None) -> tuple[dict[str, Any], ...]:
        query = _tokens(objective)
        rows = []
        for row in self._read().get("recipes", []):
            rt = set(map(str.casefold, row.get("objective_tokens") or ()))
            overlap = len(query & rt)
            score = overlap / max(1, len(query | rt)) if query and rt else 0.0
            if overlap:
                rows.append((score, dict(row)))
        rows.sort(key=lambda x: (-x[0], str(x[1].get("recipe_id") or "")))
        visible = rows if limit is None else rows[: max(1, int(limit))]
        return tuple({**row, "similarity_hint": score} for score, row in visible)


class OpenWorldCognitiveCompiler:
    """Compiles one turn into a dynamic cognitive phenotype.

    The compiler intentionally does *not* define a closed set of tools, routes, agents,
    search engines, or reasoning styles. Known mechanisms are seeds. Substantiveness is
    supplied by the canonical semantic authority when available; taxonomy misses must not
    silently downgrade a substantive turn into a non-substantive one.

    The mobile chat is treated as the control shell, not the compute ceiling. A route may
    bind to sandbox compute, connected plugins, browser sessions, code acquired from open
    source, hosted agents, automations, or a future actuator discovered after this release.
    """

    SENSOR_HINTS = (
        "first_party", "web_current", "community", "social_recommendation",
        "code_ecosystem", "research", "creator_graph", "multilingual",
    )
    BINDING_HINTS = (
        "current_host_surface", "plugin_directory", "connected_plugin", "github_open_source",
        "generated_local_tool", "sandbox_process", "signed_in_browser_context",
        "hosted_agent", "subagent", "automation", "future_discovered_actuator",
    )

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.memory = CognitiveEvolutionMemory(self.root / "evolution")
        self.experience_graph = ExperienceGraph(self.root / "experience")
        self.microclosure = MicroClosureAuditor()
        self.agenda = OpportunisticAgenda()

    @staticmethod
    def _substantive(topology: Mapping[str, Any]) -> bool:
        # Kept only for API compatibility. Topology no longer has veto power over openness.
        return True

    @staticmethod
    def _signed_in_relevant(command: str) -> bool:
        low = str(command).casefold()
        markers = (
            "로그인", "내 계정", "내 피드", "추천 피드", "for you", "following feed",
            "signed-in", "signed in", "브라우저 세션", "내 dm", "my dm",
        )
        return any(x in low for x in markers)

    @staticmethod
    def _ongoing_relevant(command: str) -> bool:
        low = str(command).casefold()
        markers = ("계속 확인", "매일", "매주", "모니터", "변하면", "watch", "monitor", "daily", "weekly", "when it changes", "계속 추적")
        return any(x in low for x in markers)

    def compile(
        self,
        *,
        command: str,
        requirement_contract: Mapping[str, Any],
        goal_anchor: Mapping[str, Any],
        semantic_requirement_contract: Mapping[str, Any] | None = None,
        topology: Mapping[str, Any],
        current_surface: Mapping[str, Any] | None = None,
        missing_traits: Iterable[str] = (),
        cognitive_continuity: Mapping[str, Any] | None = None,
        semantic_authority: Mapping[str, Any] | None = None,
    ) -> CognitiveOSPlan:
        provenance_atoms = tuple(dict(x) for x in requirement_contract.get("atoms") or ())
        semantic_contract = dict(semantic_requirement_contract or requirement_contract)
        atoms = tuple(dict(x) for x in semantic_contract.get("atoms") or ())
        objective_spec = ObjectiveSpec(
            exact_command=str(command),
            command_sha256=hashlib.sha256(str(command).encode("utf-8")).hexdigest(),
            requirement_atoms=provenance_atoms,
            goal_anchor=dict(goal_anchor or {}),
        )
        authority = bind_semantic_authority(command, semantic_authority)
        # Operative destination is exact-source bound.  A restored prior objective
        # may be resolved only when the current source explicitly references it.
        objective = source_bound_objective(command, authority) if authority else str(command)
        open_rep = self.microclosure.represent(
            message=objective, atoms=atoms, prior_goal=str(goal_anchor.get("exact_goal") or "")
        )
        substantive = bool(authority.get("substantive")) if authority else self.microclosure._substantive(objective, atoms)
        missing = tuple(dict.fromkeys(str(x) for x in missing_traits if str(x).strip()))
        selected = set(map(str, topology.get("selected") or ()))
        complexity = float(topology.get("complexity") or 0.0)
        uncertainty = float(topology.get("uncertainty") or 0.0)
        execution_pressure = float(topology.get("execution_pressure") or 0.0)
        discovery_pressure = float(topology.get("discovery_pressure") or 0.0)

        # The user asked for cognition expansion, not a tool-search substitute.
        # This frontier is generated in the core cognition plan itself, even when
        # the host has no model connector configured. The exact source is primary.
        cognition_frontier = FrontierCognition(self.root).prepare(objective)
        frontier_ref = {
            "record_path": cognition_frontier["record_path"],
            "source_sha256": cognition_frontier["exact_text_sha256"],
            "branch_ids": [x["branch_id"] for x in cognition_frontier["branch_set"]],
            "generator_binding": "host_supplied_current_model",
            "raw_generation_preservation": True,
        }
        cognitive_priority = any(k in objective.casefold() for k in (
            "창의", "사고", "지능", "난제", "초지능", "새로운 방법", "모델 자체",
            "깊은", "아이디어", "발명", "기괴", "가설", "추론", "cognit", "reason",
            "invent", "novel", "creative", "frontier", "open world",
        ))
        routes: list[FrontierRoute] = []
        if cognitive_priority or (substantive and bool(authority.get("open_problem_required"))):
            routes.append(FrontierRoute(
                route_id="route_model_cognitive_frontier",
                objective=objective,
                mechanism="Develop divergent, genuinely new representations and independent causal hypotheses from the entire original goal; keep generative raw output and qualitative contradictions; let actual host model materialize and refine candidates rather than replacing cognition with tool lookups",
                capability_needs=(),
                binding_hints=("host_model_branch", "current_host_surface", "future_discovered_actuator"),
                notes=("the original user objective is unchanged", "hypothesis admission is not gated by immediate proof", "no fixed model-performance ceiling"),
            ))
        routes.append(FrontierRoute(
            route_id="route_direct_surface",
            objective=objective,
            mechanism="bind the goal to the strongest currently observed actuator composition without treating that surface as exhaustive",
            capability_needs=missing,
            binding_hints=("current_host_surface",),
            notes=("current surface is evidence, not ontology",),
        ))

        # Representation search is not satisfied merely by setting an openness flag.
        # Materialize one task-local escape route whose job is to invent a representation
        # before mapping it back to any known taxonomy. This is conditional, not the old
        # mandatory unbounded-route ritual for every substantive turn.
        if cognitive_priority or (substantive and bool(authority.get("representation_search_required"))):
            routes.append(FrontierRoute(
                route_id="route_representation_escape",
                objective=objective,
                mechanism="invent a task-local representation, ontology, or problem decomposition outside the current registry before deciding which known route (if any) it resembles",
                capability_needs=(),
                binding_hints=("host_model_branch", "future_discovered_actuator"),
                notes=(
                    "do not map the invented representation back into the current taxonomy before it is developed",
                    "this route exists only when canonical semantic authority requires representation search",
                ),
            ))

        if substantive and (missing or "capability_acquisition" in selected):
            routes.append(FrontierRoute(
                route_id="route_dynamic_acquisition",
                objective=objective,
                mechanism="move opportunistically among discovery, inspection, connection, isolation when useful, materialization, execution, observation, composition, and promotion for a capability not present at ingress",
                capability_needs=missing or ("unknown_needed_capability",),
                binding_hints=("plugin_directory", "github_open_source", "generated_local_tool", "hosted_agent", "future_discovered_actuator"),
                external_connection_step_may_be_required=True,
                notes=("README/static inspection is never execution", "unknown source family remains discoverable"),
            ))

        if substantive and len(atoms) >= 2:
            routes.append(FrontierRoute(
                route_id="route_capability_synthesis",
                objective=objective,
                mechanism="compose multiple partial capabilities into one temporary virtual tool instead of requiring a single pre-existing perfect tool",
                capability_needs=missing,
                binding_hints=("current_host_surface", "sandbox_process", "connected_plugin", "signed_in_browser_context"),
                notes=("successful compositions may become reusable recipes",),
            ))

        if substantive and "research_mesh" in selected:
            routes.append(FrontierRoute(
                route_id="route_sensor_mesh",
                objective=objective,
                mechanism="treat search as multi-surface sensing: query, observe native vocabulary, follow graphs, re-query, and trace diffusion rather than stopping at ranked pages",
                capability_needs=("information_discovery",),
                binding_hints=("current_host_surface", "signed_in_browser_context", "connected_plugin", "future_discovered_actuator"),
                notes=("community slang and recommendation signals are first-class observations",),
            ))

        if substantive and "execution_experiment_loop" in selected:
            routes.append(FrontierRoute(
                route_id="route_build_and_probe",
                objective=objective,
                mechanism="build the cheapest executable probe that can falsify the current approach, run it, then mutate the route from observed behavior",
                capability_needs=("execution",),
                binding_hints=("sandbox_process", "generated_local_tool", "github_open_source"),
                notes=("experiment before explanation when an executable probe is cheap",),
            ))

        if substantive and self._signed_in_relevant(objective):
            routes.append(FrontierRoute(
                route_id="route_signed_in_perception",
                objective=objective,
                mechanism="use an already connected signed-in surface as a sensor; perform mutations only when they are part of the user directive or required task effect",
                capability_needs=("authenticated_browser_context",),
                binding_hints=("signed_in_browser_context", "connected_plugin", "future_discovered_actuator"),
                external_connection_step_may_be_required=True,
                notes=("personalized/recommendation feed observation is not equivalent to public search",),
            ))

        if substantive and ("parallel_delegation" in selected or len(atoms) >= 3):
            routes.append(FrontierRoute(
                route_id="route_parallel_delegation",
                objective=objective,
                mechanism="split independent uncertainty into isolated working contexts and merge only the artifacts/evidence, not their hidden reasoning traces",
                capability_needs=("parallel_cognition",),
                binding_hints=("subagent", "hosted_agent", "host_model_branch", "future_discovered_actuator"),
                notes=("actual subagent execution is claimed only with a host receipt",),
            ))

        if substantive and self._ongoing_relevant(objective):
            routes.append(FrontierRoute(
                route_id="route_proactive_continuity",
                objective=objective,
                mechanism="compile the goal into a future condition or scheduled observation so the mobile chat becomes a control shell for ongoing cognition",
                capability_needs=("automation_or_condition_watch",),
                binding_hints=("automation", "connected_plugin", "future_discovered_actuator"),
                external_connection_step_may_be_required=True,
            ))

        # No mandatory "unbounded" route or fixed three-cell ritual. Unknown
        # representations may be invented directly when the task warrants them.
        cells: list[CognitiveCell] = []
        if "parallel_delegation" in selected or any(r.route_id == "route_parallel_delegation" for r in routes):
            cells.append(CognitiveCell(
                "cell_independent", objective, "independent_context:alternative",
                ("host_model_branch", "subagent", "hosted_agent", "future_discovered_actuator"), False,
                "develop a materially independent route when independence has value",
            ))

        sensor_families: tuple[str, ...] = ()
        if substantive and "research_mesh" in selected:
            families = list(self.SENSOR_HINTS)
            if self._signed_in_relevant(objective):
                families.append("signed_in_personalized_surface")
            families.append("host_invented_sensor_family")
            sensor_families = tuple(dict.fromkeys(families))

        acquisition = {
            "default_unknown_state": "inspectable_candidate_not_denied",
            "lifecycle_shape": "opportunistic_graph_not_fixed_pipeline",
            "possible_moves": ("discover", "inspect", "connect", "isolate", "materialize", "execute", "observe", "compose", "discard", "revisit", "invent"),
            "source_families_are_non_exhaustive": True,
            "external_connection_requirements_are_observed_at_host_boundary": True,
            "open_source_execution_requires_real_runtime_receipt": True,
            "static_docs_do_not_count_as_execution": True,
        }
        boundary_reporting = {
            "mode": "encountered_observations_only",
            "unsolicited_preamble": False,
            "unknown_is_not_false": True,
            "failed_route_does_not_rewrite_goal": True,
        }
        creativity = {
            "scope": "search+engineering+debugging+design+science+planning+tool_use+writing+all_other_substantive_domains",
            "ideation_admission_threshold": "low",
            "factual_acceptance_threshold": "evidence_bound",
            "execution_claim_threshold": "receipt_bound",
            "mechanism_before_taxonomy": True,
            "weird_observation_may_be_signal": True,
            "non_registry_representation_available": substantive,
            "branch_count_is_not_an_openness_metric": True,
            "surface_novelty_is_not_enough": True,
            "host_cognitive_frontier": frontier_ref,
            "user_requested_cognitive_escalation": cognitive_priority,
        }
        execution_policy = {
            "mobile_chat_is_control_shell_not_compute_ceiling": True,
            "provider_binding_is_late": True,
            "one_tool_failure_does_not_end_goal": True,
            "compose_capabilities_before_declaring_missing_capability": True,
            "actual_host_actions_need_observed_receipts": True,
            "parallelism_is_bound_to_available_executor_at_runtime": True,
            "background_or_future_work_requires_an_actual_automation_or_agent_actuator": True,
        }
        closure_policy = {
            "closure_is_last_phase_not_default_state": True,
            "requirement_atoms_must_be_accounted": True,
            "untried_route_state": "open_not_false",
            "analysis_only_repair_is_not_closure": True,
            "framework_pass_does_not_prove_frontier_exhausted": True,
            "answer_may_close_while_task_hypotheses_remain_open": True,
        }
        recipes = self.memory.relevant_recipes(objective, limit=None)
        recipe_reservoir = ()
        recalled = self.experience_graph.recall(objective)
        agenda = self.agenda.seed(objective=objective, need_execution="execution_experiment_loop" in selected, need_discovery="research_mesh" in selected or bool(missing), need_continuity=self._ongoing_relevant(objective)) if substantive else ()
        body = {
            "objective_spec": objective_spec.as_mapping(),
            "routes": [r.as_mapping() for r in routes],
            "cells": [c.as_mapping() for c in cells],
            "sensor_families": sensor_families,
            "capability_acquisition": acquisition,
            "boundary_reporting": boundary_reporting,
            "creativity_policy": creativity,
            "execution_policy": execution_policy,
            "closure_policy": closure_policy,
            "reusable_recipes": recipes,
            "reusable_recipe_reservoir": recipe_reservoir,
            "recipe_selection_is_scheduling_not_pruning": True,
            "open_representation": open_rep.as_mapping(),
            "agenda": [x.as_mapping() for x in agenda],
            "recalled_experience": recalled,
            "continuity_hint": dict(cognitive_continuity or {}),
            "current_surface_hint": dict(current_surface or {}),
            "semantic_authority": authority,
            "semantic_frontier_open": bool(authority.get("open_problem_required")) if authority else substantive,
        }
        plan_id = "cogos_" + _sha(body)[:20]
        plan_sha = _sha({**body, "plan_id": plan_id})
        return CognitiveOSPlan(
            plan_id=plan_id,
            objective_spec=objective_spec,
            routes=tuple(routes),
            cells=tuple(cells),
            sensor_families=sensor_families,
            capability_acquisition=acquisition,
            boundary_reporting=boundary_reporting,
            creativity_policy=creativity,
            execution_policy=execution_policy,
            closure_policy=closure_policy,
            reusable_recipes=recipes,
            open_representation=open_rep.as_mapping(),
            agenda=tuple(x.as_mapping() for x in agenda),
            recalled_experience=recalled,
            created_at=time.time(),
            plan_sha256=plan_sha,
        )
