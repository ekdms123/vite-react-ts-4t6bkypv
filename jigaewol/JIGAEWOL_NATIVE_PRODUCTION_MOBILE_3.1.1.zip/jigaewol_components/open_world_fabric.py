from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

from .host_syscall import HostSyscallIntent, HostSyscallQueue


@dataclass(frozen=True)
class OpenWorldNeed:
    need_id: str
    objective: str
    desired_outcomes: tuple[str, ...]
    known_routes: tuple[str, ...]
    explicit_exclusions: tuple[str, ...]
    allow_unknown_sources: bool
    allow_unknown_substrates: bool
    allow_new_tool_creation: bool
    allow_new_agent_or_model_backends: bool
    allow_new_search_surfaces: bool
    created_at: float
    context: dict[str, Any] = field(default_factory=dict)


class OpenWorldFabric:
    """Registers capability and discovery requirements without imposing static whitelists.

    Known routes act as non-exhaustive hints. Exclusions apply only when explicitly requested.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.queue = HostSyscallQueue(self.root / "syscalls")
        self.path = self.root / "open_world_needs.json"
        if not self.path.exists():
            self.path.write_text(json.dumps({"needs": {}}, indent=2), encoding="utf-8")

    def declare_need(
        self,
        *,
        objective: str,
        desired_outcomes: Iterable[str] = (),
        known_routes: Iterable[str] = (),
        explicit_exclusions: Iterable[str] = (),
        context: dict[str, Any] | None = None,
    ) -> OpenWorldNeed:
        row = OpenWorldNeed(
            need_id=f"need_{uuid.uuid4().hex[:16]}",
            objective=str(objective),
            desired_outcomes=tuple(dict.fromkeys(map(str, desired_outcomes))),
            known_routes=tuple(dict.fromkeys(map(str, known_routes))),
            explicit_exclusions=tuple(dict.fromkeys(map(str, explicit_exclusions))),
            allow_unknown_sources=True,
            allow_unknown_substrates=True,
            allow_new_tool_creation=True,
            allow_new_agent_or_model_backends=True,
            allow_new_search_surfaces=True,
            created_at=time.time(),
            context=dict(context or {}),
        )
        data = json.loads(self.path.read_text(encoding="utf-8"))
        data.setdefault("needs", {})[row.need_id] = asdict(row)
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return row

    def request_discovery(self, need: OpenWorldNeed) -> HostSyscallIntent:
        return self.queue.request(
            "open_world.discover",
            capability_need="unbounded_capability_search",
            arguments={
                **asdict(need),
                "route_semantics": "known_routes_are_non_exhaustive_hints",
                "source_family_semantics": "no_predeclared_whitelist",
            },
            failure_family="open_world_discovery",
        )
