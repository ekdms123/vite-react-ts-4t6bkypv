from __future__ import annotations

import hashlib
import importlib.metadata
import importlib.util

import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from .execution_plane import ExecutionRequest
from .capability_registry import CapabilityRegistry
from .host_identity import current_host_fingerprint
from .registry_paths import rebase_project_paths


@dataclass(frozen=True)
class ImageCapabilityBinding:
    capability_id: str
    repository: str
    binding_mode: str
    distribution: str
    distribution_version: str
    runtime_path: str
    runtime_tree_sha256: str
    wrapper_path: str
    traits: tuple[str, ...]
    registered_now: bool
    system_engine: str | None = None


class ImageInspectionComponent:
    """Local image inspection and OCR component with deterministic verification receipts."""

    PILLOW_ID = "github_python_pillow_image_inspector"
    PILLOW_REPOSITORY = "python-pillow/Pillow"
    PILLOW_URL = "https://github.com/python-pillow/Pillow"

    @staticmethod
    def _seed_pillow_traits() -> tuple[str, ...]:
        return (
            "executable",
            "image_decoding",
            "image_inspection",
            "image_metadata",
            "pixel_analysis",
        )

    OCR_ID = "github_madmaze_pytesseract_ocr"
    OCR_REPOSITORY = "madmaze/pytesseract"
    OCR_URL = "https://github.com/madmaze/pytesseract"

    @staticmethod
    def _seed_ocr_traits() -> tuple[str, ...]:
        return (
            "executable",
            "image_ocr",
            "image_text_extraction",
            "ocr",
        )

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root.resolve()
        self.workspace = self.project_root / "workspace"
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.wrapper_root = self.project_root / "external_components"
        self.wrapper_root.mkdir(parents=True, exist_ok=True)
        self.wrapper_path = self.wrapper_root / f"{self.PILLOW_ID}.py"
        self.registry_path = self.workspace / ".capability_registry.json"
        self.registry = CapabilityRegistry(self.registry_path, self.project_root)
        self.pillow_traits = self._seed_pillow_traits()
        self.ocr_traits = self._seed_ocr_traits()

    @staticmethod
    def _tree_fingerprint(path: Path) -> str:
        h = hashlib.sha256()
        files = [path] if path.is_file() else sorted(path.rglob("*.py"))
        for file in files:
            if not file.is_file():
                continue
            rel = file.name if path.is_file() else str(file.relative_to(path))
            data = file.read_bytes()
            h.update(rel.encode("utf-8"))
            h.update(b"\\0")
            h.update(hashlib.sha256(data).digest())
        return h.hexdigest()

    @staticmethod
    def _metadata_urls(meta: importlib.metadata.PackageMetadata) -> tuple[str, ...]:
        values: list[str] = []
        home = meta.get("Home-page")
        if home:
            values.append(str(home))
        for value in meta.get_all("Project-URL") or []:
            values.append(str(value))
        return tuple(values)

    @classmethod
    def _assert_distribution_matches_repository(
        cls, distribution: str, repository: str, repository_url: str
    ) -> tuple[str, tuple[str, ...]]:
        meta = importlib.metadata.metadata(distribution)
        version = importlib.metadata.version(distribution)
        urls = cls._metadata_urls(meta)
        haystack = "\\n".join(urls).lower()
        if repository.lower() not in haystack and repository_url.lower() not in haystack:
            raise RuntimeError(
                f"repository identity binding requires {distribution} metadata to reference {repository}: {urls}"
            )
        return version, urls

    def install(self) -> tuple[ImageCapabilityBinding, ImageCapabilityBinding | None]:
        pil_spec = importlib.util.find_spec("PIL")
        if pil_spec is None:
            raise RuntimeError("image inspection requires callable Pillow/PIL in this runtime")
        pillow_version, pillow_urls = self._assert_distribution_matches_repository(
            "Pillow", self.PILLOW_REPOSITORY, self.PILLOW_URL
        )
        pil_path = Path(pil_spec.origin or "").resolve()
        pil_root = pil_path.parent if pil_path.name == "__init__.py" else pil_path
        pil_sha = self._tree_fingerprint(pil_root)

        wrapper_source = self._wrapper_source()
        wrapper_changed = (
            not self.wrapper_path.exists()
            or self.wrapper_path.read_text(encoding="utf-8") != wrapper_source
        )
        self.wrapper_path.write_text(wrapper_source, encoding="utf-8")

        ocr_binding: ImageCapabilityBinding | None = None
        pytesseract_spec = importlib.util.find_spec("pytesseract")
        tesseract_bin = shutil.which("tesseract")
        ocr_meta: dict | None = None
        if pytesseract_spec is not None and tesseract_bin:
            ocr_version, ocr_urls = self._assert_distribution_matches_repository(
                "pytesseract", self.OCR_REPOSITORY, self.OCR_URL
            )
            ocr_path = Path(pytesseract_spec.origin or "").resolve()
            ocr_root = ocr_path.parent if ocr_path.name == "__init__.py" else ocr_path
            ocr_sha = self._tree_fingerprint(ocr_root)
            import subprocess

            proc = subprocess.run(
                [tesseract_bin, "--version"], text=True, capture_output=True, check=False, timeout=10
            )
            first_line = (proc.stdout or proc.stderr).splitlines()[0] if (proc.stdout or proc.stderr) else ""
            ocr_meta = {
                "repository": self.OCR_REPOSITORY,
                "repository_url": self.OCR_URL,
                "license_spdx": "Apache-2.0",
                "language": "Python + system OCR engine",
                "failure_family": "ocr_text_recognition",
                "traits": list(self.ocr_traits),
                "binding_mode": "reuse_existing_python_distribution_and_system_engine",
                "python_distribution": "pytesseract",
                "distribution_version": ocr_version,
                "distribution_urls": list(ocr_urls),
                "runtime_path": str(ocr_root),
                "runtime_tree_sha256": ocr_sha,
                "system_engine_path": tesseract_bin,
                "system_engine_version": first_line,
                "system_engine_repository": "tesseract-ocr/tesseract",
                "system_engine_license_spdx": "Apache-2.0",
                "wrapper_path": str(self.wrapper_path),
                "exact_git_bytes_vendored": False,
            }

        pillow_meta = {
            "repository": self.PILLOW_REPOSITORY,
            "repository_url": self.PILLOW_URL,
            "license_spdx": "MIT-CMU",
            "language": "Python/C",
            "failure_family": "deterministic_image_decoding",
            "traits": list(self.pillow_traits),
            "binding_mode": "reuse_existing_python_distribution_matched_to_github_upstream",
            "python_distribution": "Pillow",
            "distribution_version": pillow_version,
            "distribution_urls": list(pillow_urls),
            "runtime_path": str(pil_root),
            "runtime_tree_sha256": pil_sha,
            "wrapper_path": str(self.wrapper_path),
            "exact_git_bytes_vendored": False,
            "truth_note": (
                "The host/runtime contains verified Pillow distribution. "
                "The component binds the distribution directly with runtime evidence."
            ),
        }
        pillow_now, ocr_now = self._register(pillow_meta, ocr_meta)
        pillow_binding = ImageCapabilityBinding(
            capability_id=self.PILLOW_ID,
            repository=self.PILLOW_REPOSITORY,
            binding_mode=pillow_meta["binding_mode"],
            distribution="Pillow",
            distribution_version=pillow_version,
            runtime_path=str(pil_root),
            runtime_tree_sha256=pil_sha,
            wrapper_path=str(self.wrapper_path),
            traits=self.pillow_traits,
            registered_now=pillow_now or wrapper_changed,
        )
        if ocr_meta is not None:
            ocr_binding = ImageCapabilityBinding(
                capability_id=self.OCR_ID,
                repository=self.OCR_REPOSITORY,
                binding_mode=ocr_meta["binding_mode"],
                distribution="pytesseract",
                distribution_version=ocr_meta["distribution_version"],
                runtime_path=ocr_meta["runtime_path"],
                runtime_tree_sha256=ocr_meta["runtime_tree_sha256"],
                wrapper_path=str(self.wrapper_path),
                traits=self.ocr_traits,
                registered_now=ocr_now or wrapper_changed,
                system_engine=ocr_meta["system_engine_version"],
            )
        return pillow_binding, ocr_binding

    def _register(self, pillow_meta: dict, ocr_meta: dict | None) -> tuple[bool, bool]:
        pillow_now = self.registry.declare_available(
            self.PILLOW_ID, metadata=pillow_meta
        ) or self.registry.set_external(self.PILLOW_ID, pillow_meta)

        ocr_now = False
        if ocr_meta is not None:
            ocr_now = self.registry.declare_available(
                self.OCR_ID, metadata=ocr_meta
            ) or self.registry.set_external(self.OCR_ID, ocr_meta)
        return pillow_now, ocr_now

    @staticmethod
    def _safe_id(value: str) -> str:
        return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)

    def build_request(self, image_path: Path, *, ocr: bool = False) -> ExecutionRequest:
        argv = [sys.executable, str(self.wrapper_path), str(image_path.resolve())]
        if ocr:
            argv.append("--ocr")
        return ExecutionRequest(argv=argv, cwd=".", timeout_s=60.0)

    def _wrapper_source(self) -> str:
        return f'''from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path

from PIL import Image, ImageOps, ImageStat

CAPABILITY_ID = {self.PILLOW_ID!r}
OCR_CAPABILITY_ID = {self.OCR_ID!r}


def inspect(path, do_ocr=False):
    path = Path(path).resolve()
    data = path.read_bytes()
    sha256 = hashlib.sha256(data).hexdigest()

    with Image.open(path) as probe:
        probe.verify()

    with Image.open(path) as raw:
        image = ImageOps.exif_transpose(raw)
        image.load()
        width, height = image.size
        thumb = image.convert("RGB")
        thumb.thumbnail((512, 512))
        mean_rgb = [round(float(x), 4) for x in ImageStat.Stat(thumb).mean]
        result = {{
            "capability_id": CAPABILITY_ID,
            "file": str(path),
            "sha256": sha256,
            "format": raw.format,
            "width": width,
            "height": height,
            "mode": image.mode,
            "bands": list(image.getbands()),
            "frames": int(getattr(raw, "n_frames", 1)),
            "has_alpha": "A" in image.getbands(),
            "mean_rgb": mean_rgb,
            "pixel_count": width * height,
            "ocr_requested": bool(do_ocr),
        }}
        if do_ocr:
            import pytesseract
            result["ocr_capability_id"] = OCR_CAPABILITY_ID
            result["tesseract_version"] = str(pytesseract.get_tesseract_version())
            result["ocr_text"] = pytesseract.image_to_string(image, config="--psm 6").strip()
        return result


if __name__ == "__main__":
    if len(sys.argv) not in (2, 3):
        raise SystemExit("usage: image_wrapper.py <image> [--ocr]")
    do_ocr = len(sys.argv) == 3 and sys.argv[2] == "--ocr"
    if len(sys.argv) == 3 and not do_ocr:
        raise SystemExit("usage: image_inspector.py <image-path> [--ocr]")
    print(json.dumps(inspect(sys.argv[1], do_ocr=do_ocr), ensure_ascii=False))
'''


# Preferred neutral API alias

