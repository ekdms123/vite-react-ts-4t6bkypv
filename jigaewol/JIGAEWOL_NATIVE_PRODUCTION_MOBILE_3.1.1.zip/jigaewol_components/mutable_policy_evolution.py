from __future__ import annotations

from .observed_evidence import ObservedEvidence, finite_scores
from .state_transaction import serialized_state
import hashlib
import json
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Iterable, Mapping


EXECUTION_TRUTH_POLICY_KEYS = frozenset({
    "execution_truth_required",
    "observed_receipt_required",
})

USER_AUTHORIZED_POLICY_KEYS = frozenset({
    "canonical_ingress_required",
    "current_user_authority",
    "exact_objective_preservation",
    "requirement_accounting_required",
})

IMMUTABLE_POLICY_KEYS = EXECUTION_TRUTH_POLICY_KEYS | USER_AUTHORIZED_POLICY_KEYS


def _sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class PolicyCandidate:
    candidate_id: str
    family: str
    policy: dict[str, Any]
    parent_ids: tuple[str, ...]
    generation: int
    state: str
    created_at: float
    provenance: dict[str, Any]


@dataclass(frozen=True)
class CandidateEvaluation:
    candidate_id: str
    case_id: str
    scores: dict[str, float]
    aggregate: float
    feedback: tuple[str, ...]
    evidence_refs: tuple[str, ...]
    created_at: float


@dataclass(frozen=True)
class OutcomeEvaluationVector:
    vector_id: str
    family: str
    subject_ref: str
    case_id: str
    scores: dict[str, float]
    aggregate: float
    evidence_refs: tuple[str, ...]
    metadata: dict[str, Any]
    created_at: float


class MutablePolicyEvolution:
    """Pareto-retained evolution for mutable runtime policies.

    Autonomous evolution cannot edit protected authority/truth invariants. Explicit
    user-authorized policy mutations may edit user-governed authority/ingress policy,
    but execution-truth/receipt requirements stay evidence-bound rather than becoming
    user-selectable labels. Other search/style/routing/skill/creative candidates are
    retained per-case on a Pareto frontier instead of greedily replacing everything
    with one global winner.
    """

    FORMAT = "jigaewol_mutable_policy_evolution_v1"

    def __init__(self, root: str | Path, *, immutable_keys: Iterable[str] = IMMUTABLE_POLICY_KEYS) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "candidates.json"
        self.evals_path = self.root / "evaluations.jsonl"
        self.outcome_vectors_path = self.root / "outcome_vectors.jsonl"
        self.observations = ObservedEvidence(self.root / "observations")
        self.immutable_keys = frozenset(str(x) for x in immutable_keys)
        if not self.path.exists():
            self._write({"format": self.FORMAT, "candidates": {}, "promoted": {}})
        self.evals_path.touch(exist_ok=True)
        self.outcome_vectors_path.touch(exist_ok=True)

    def _read(self) -> dict[str, Any]:
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if data.get("format") != self.FORMAT:
            raise ValueError("mutable policy evolution format mismatch")
        data.setdefault("candidates", {})
        data.setdefault("promoted", {})
        return data

    def _write(self, data: Mapping[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(dict(data), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    def _validate_policy(
        self, policy: Mapping[str, Any], *, user_authorized: bool = False,
        provenance: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        row = dict(policy or {})
        protected = set(row).intersection(self.immutable_keys)
        truth_keys = sorted(protected.intersection(EXECUTION_TRUTH_POLICY_KEYS))
        if truth_keys:
            raise ValueError(
                "execution truth policy remains evidence-bound and cannot be relabeled by policy: "
                + ", ".join(truth_keys)
            )
        user_keys = sorted(protected.intersection(USER_AUTHORIZED_POLICY_KEYS))
        if user_keys and not user_authorized:
            raise ValueError("mutable policy attempted to edit immutable keys: " + ", ".join(user_keys))
        if user_keys:
            proof = str(dict(provenance or {}).get("exact_user_directive_sha256") or "")
            if len(proof) != 64 or any(ch not in "0123456789abcdefABCDEF" for ch in proof):
                raise ValueError("user-authorized protected policy change requires exact user directive sha256")
        return row

    @serialized_state
    def propose(
        self,
        *,
        family: str,
        policy: Mapping[str, Any],
        parent_ids: Iterable[str] = (),
        provenance: Mapping[str, Any] | None = None,
        user_authorized: bool = False,
    ) -> PolicyCandidate:
        provenance_row = dict(provenance or {})
        policy_row = self._validate_policy(
            policy, user_authorized=bool(user_authorized), provenance=provenance_row
        )
        parents = tuple(dict.fromkeys(str(x) for x in parent_ids if str(x).strip()))
        data = self._read()
        parent_rows = [data["candidates"].get(x) for x in parents]
        if any(x is None for x in parent_rows):
            missing = [pid for pid, row in zip(parents, parent_rows) if row is None]
            raise KeyError("unknown parent candidates: " + ", ".join(missing))
        generation = 0 if not parents else 1 + max(int(x.get("generation") or 0) for x in parent_rows if x)
        seed = {"family": str(family), "policy": policy_row, "parents": parents}
        cid = "policy_" + _sha(seed)[:20]
        old = data["candidates"].get(cid)
        candidate = PolicyCandidate(
            candidate_id=cid,
            family=str(family),
            policy=policy_row,
            parent_ids=parents,
            generation=generation,
            state=str((old or {}).get("state") or "candidate"),
            created_at=float((old or {}).get("created_at") or time.time()),
            provenance={
                **dict((old or {}).get("provenance") or {}),
                **provenance_row,
                **({"user_authorized": True} if user_authorized else {}),
            },
        )
        data["candidates"][cid] = asdict(candidate)
        self._write(data)
        return candidate

    def get(self, candidate_id: str) -> PolicyCandidate:
        row = self._read()["candidates"].get(str(candidate_id))
        if row is None:
            raise KeyError(candidate_id)
        return PolicyCandidate(**row)

    @serialized_state
    def evaluate(
        self,
        *,
        candidate_id: str,
        case_id: str,
        scores: Mapping[str, float],
        feedback: Iterable[str] = (),
        evidence_refs: Iterable[str] = (),
    ) -> CandidateEvaluation:
        self.get(candidate_id)
        normalized = finite_scores(scores)
        if not normalized:
            raise ValueError("evaluation needs at least one score")
        refs = tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x).strip()))
        if not refs:
            raise ValueError("policy evaluation requires observed evidence refs")
        for ref in refs:
            observed = self.observations.resolve(ref)
            if observed["case_id"] != str(case_id) or observed["subject_ref"] != str(candidate_id) or observed["scores"] != normalized:
                raise ValueError("evaluation differs from observed case/subject/scores")
        aggregate = sum(normalized.values()) / len(normalized)
        row = CandidateEvaluation(
            candidate_id=str(candidate_id), case_id=str(case_id), scores=normalized,
            aggregate=aggregate,
            feedback=tuple(dict.fromkeys(str(x) for x in feedback if str(x).strip())),
            evidence_refs=refs, created_at=time.time(),
        )
        with self.evals_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(asdict(row), ensure_ascii=False, sort_keys=True) + "\n")
        return row

    @serialized_state
    def record_outcome_vector(
        self,
        *,
        family: str,
        subject_ref: str,
        case_id: str,
        scores: Mapping[str, float],
        evidence_refs: Iterable[str],
        metadata: Mapping[str, Any] | None = None,
    ) -> OutcomeEvaluationVector:
        """Persist observed route outcomes as evidence vectors, not policy candidates.

        Route success/failure is evidence about routing behavior.  This method
        deliberately does not call ``propose`` and therefore cannot mutate or
        promote policy merely because one route succeeded or failed.
        """
        family = str(family or "").strip()
        subject_ref = str(subject_ref or "").strip()
        case_id = str(case_id or "").strip()
        if not family or not subject_ref or not case_id:
            raise ValueError("outcome vector family, subject_ref, and case_id must be nonempty")
        normalized = finite_scores(scores)
        if not normalized:
            raise ValueError("outcome evaluation vector needs at least one score")
        refs = tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x).strip()))
        if not refs:
            raise ValueError("outcome evaluation vector requires observed evidence refs")
        aggregate = sum(normalized.values()) / len(normalized)
        created_at = time.time()
        seed = {
            "family": family, "subject_ref": subject_ref, "case_id": case_id,
            "scores": normalized, "evidence_refs": refs, "metadata": dict(metadata or {}),
            "created_at": created_at,
        }
        row = OutcomeEvaluationVector(
            vector_id="outcome_" + _sha(seed)[:20],
            family=family,
            subject_ref=subject_ref,
            case_id=case_id,
            scores=normalized,
            aggregate=aggregate,
            evidence_refs=refs,
            metadata=dict(metadata or {}),
            created_at=created_at,
        )
        with self.outcome_vectors_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(asdict(row), ensure_ascii=False, sort_keys=True) + "\n")
        return row

    def evaluation_vectors(
        self, *, family: str | None = None, subject_ref: str | None = None
    ) -> tuple[OutcomeEvaluationVector, ...]:
        out: list[OutcomeEvaluationVector] = []
        for line in self.outcome_vectors_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            raw = json.loads(line)
            raw["evidence_refs"] = tuple(raw.get("evidence_refs", ()))
            row = OutcomeEvaluationVector(**raw)
            if family is not None and row.family != str(family):
                continue
            if subject_ref is not None and row.subject_ref != str(subject_ref):
                continue
            out.append(row)
        return tuple(out)

    def evaluations(self, *, family: str | None = None) -> tuple[CandidateEvaluation, ...]:
        candidates = self._read()["candidates"]
        out: list[CandidateEvaluation] = []
        for line in self.evals_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = CandidateEvaluation(**json.loads(line))
            if family is not None and str((candidates.get(row.candidate_id) or {}).get("family")) != str(family):
                continue
            out.append(row)
        return tuple(out)

    @staticmethod
    def _dominates(a: CandidateEvaluation, b: CandidateEvaluation) -> bool:
        keys = set(a.scores) | set(b.scores)
        av = {k: a.scores.get(k, 0.0) for k in keys}
        bv = {k: b.scores.get(k, 0.0) for k in keys}
        return all(av[k] >= bv[k] for k in keys) and any(av[k] > bv[k] for k in keys)

    def pareto_frontier(self, *, family: str, case_id: str | None = None) -> tuple[str, ...]:
        evals = [x for x in self.evaluations(family=family) if case_id is None or x.case_id == str(case_id)]
        # Keep only the latest evaluation for a candidate/case pair.
        latest: dict[tuple[str, str], CandidateEvaluation] = {}
        for row in evals:
            latest[(row.candidate_id, row.case_id)] = row
        rows = list(latest.values())
        frontier: list[str] = []
        for row in rows:
            if any(other is not row and self._dominates(other, row) for other in rows):
                continue
            frontier.append(row.candidate_id)
        return tuple(sorted(set(frontier)))

    def candidate_summary(self, candidate_id: str) -> dict[str, Any]:
        candidate = self.get(candidate_id)
        evals = [x for x in self.evaluations(family=candidate.family) if x.candidate_id == candidate_id]
        by_case: dict[str, CandidateEvaluation] = {}
        for row in evals:
            by_case[row.case_id] = row
        aggregate = sum(x.aggregate for x in by_case.values()) / len(by_case) if by_case else 0.0
        return {
            "candidate": asdict(candidate),
            "case_count": len(by_case),
            "aggregate": aggregate,
            "cases": {k: asdict(v) for k, v in sorted(by_case.items())},
        }

    @serialized_state
    def promote(self, candidate_id: str, *, required_cases: Iterable[str], min_aggregate: float = 0.75) -> PolicyCandidate:
        min_aggregate=finite_scores({'min_aggregate':min_aggregate})['min_aggregate']
        candidate = self.get(candidate_id)
        summary = self.candidate_summary(candidate_id)
        cases = dict(summary["cases"])
        required_cases = tuple(dict.fromkeys(map(str, required_cases)))
        if not required_cases:
            raise ValueError("promotion requires explicit regression cases")
        for case in cases.values():
            for ref in case["evidence_refs"]:
                self.observations.resolve(ref)
        baseline_id = str(candidate.provenance.get("baseline_id") or self._read()["promoted"].get(candidate.family) or "")
        if not baseline_id or baseline_id == candidate_id:
            raise ValueError("promotion requires a separate observed baseline")
        baseline = self.candidate_summary(baseline_id)
        if baseline["candidate"]["family"] != candidate.family:
            raise ValueError("baseline family mismatch")
        for case_id in required_cases:
            prior = baseline["cases"].get(case_id)
            current = cases.get(case_id)
            if not prior or not current:
                raise ValueError("paired baseline case missing: " + case_id)
            for ref in prior["evidence_refs"]:
                self.observations.resolve(ref)
            if any(current["scores"].get(k, -1) < v for k, v in prior["scores"].items()):
                raise ValueError("candidate regresses observed capability: " + case_id)
        missing = [str(x) for x in required_cases if str(x) not in cases]
        if missing:
            raise ValueError("candidate missing required eval cases: " + ", ".join(missing))
        if float(summary["aggregate"]) < float(min_aggregate):
            raise ValueError("candidate aggregate below promotion threshold")
        data = self._read()
        row = dict(data["candidates"][candidate_id])
        row["state"] = "promoted"
        data["candidates"][candidate_id] = row
        data["promoted"][candidate.family] = candidate_id
        self._write(data)
        return replace(candidate, state="promoted")

    @serialized_state
    def merge(self, *, family: str, left_id: str, right_id: str, prefer: str = "right") -> PolicyCandidate:
        left = self.get(left_id); right = self.get(right_id)
        if left.family != family or right.family != family:
            raise ValueError("merge candidates must belong to the same family")
        merged = dict(left.policy)
        if prefer == "right":
            merged.update(right.policy)
        else:
            for key, value in right.policy.items():
                merged.setdefault(key, value)
        return self.propose(
            family=family, policy=merged, parent_ids=(left_id, right_id),
            provenance={"merge": {"left": left_id, "right": right_id, "prefer": prefer}},
        )

    def active_policy(self, family: str) -> dict[str, Any]:
        data = self._read(); cid = str(data["promoted"].get(str(family)) or "")
        return dict(self.get(cid).policy) if cid else {}

    def active_revision(self, family: str) -> dict[str, Any]:
        data = self._read()
        cid = str(data["promoted"].get(str(family)) or "")
        return {"candidate_id": cid, "policy": self.active_policy(family), "policy_sha256": _sha(self.active_policy(family))}

    @serialized_state
    def rollback(self, family: str, candidate_id: str) -> dict[str, Any]:
        candidate = self.get(candidate_id)
        if candidate.family != family:
            raise ValueError("rollback family mismatch")
        data = self._read()
        data["promoted"][family] = candidate_id
        self._write(data)
        return self.active_revision(family)
