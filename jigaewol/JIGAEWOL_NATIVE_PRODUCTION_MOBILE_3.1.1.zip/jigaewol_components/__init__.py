"""JIGAEWOL extension components with a small default import surface.

This package keeps a small lazy public import surface so narrow imports do not initialize unrelated runtime modules.
"""

from importlib import import_module

from .compute_profile import ComputeProfileDetector
from .browser_plane import BrowserPlane, BrowserReceipt
from .capability_registry import CapabilityRegistry
from .execution_plane import ExecutionPlane, ExecutionRequest, ExecutionReceipt
from .host_capabilities import HostCapabilityDiscovery
from .image_capability import ImageInspectionComponent
from .objective_fidelity import ObjectiveDimension, ObjectiveFidelity, PlanCoverage
from .reasoning_portfolio import AdaptiveReasoningPortfolio
from .sat_capability import PortableSATComponent
from .thought_tree import DivergentThoughtTree, ThoughtBranch, ThoughtNode, ThoughtTreeResult

__all__ = [
    "AdaptiveReasoningPortfolio", "ComputeProfileDetector",
    "BrowserPlane", "BrowserReceipt", "CapabilityRegistry", "ExecutionPlane", "ExecutionRequest",
    "ExecutionReceipt", "HostCapabilityDiscovery", "ImageInspectionComponent",
    "ObjectiveDimension", "ObjectiveFidelity", "PlanCoverage", "PortableSATComponent", "DivergentThoughtTree", "ThoughtBranch",
    "ThoughtNode", "ThoughtTreeResult",
]

# Lazy public modules are resolved only when a caller requests their symbols.
_LAZY_MODULES = (
    "delegate_mesh", "leap_engine", "source_checkpoint",
    "work_capsule", "runtime_state", "hot_swap", "paradigm_runtime",
    "functional_self", "revision_kernel", "capability_bus", "runtime_orchestrator", "model_component",
    "meta_control", "open_world_guard", "user_contract", "turn_audit",
    "terminal_backplane", "autobiographical_self", "host_surface_registry", "skill_library",
    "cognition_backplane", "search_portfolio", "cognitive_diversity", "capability_compiler",
    "external_experience", "dgm_source", "generic_agent_source", "cumulative_intent",
    "open_world_fabric", "prebuilt_computer_fabric", "resource_telemetry",
    "turn_continuity", "runtime_home", "runtime_foundation", "open_world_resolver", "live_context",
    "host_resource_probe", "foundation_components", "delegate_executor", "intent_deep_analyzer",
    "resident_cognition", "deep_open_cognition", "intent_fidelity", "response_protocol",
    "response_sink", "mobile_exokernel", "reflexive_breaker", "agent_skill_registry",
    "incubation", "tournament_engine", "semantic_communication",
)


def __getattr__(name: str):
    for module_name in _LAZY_MODULES:
        module = import_module(f"{__name__}.{module_name}")
        if hasattr(module, name):
            value = getattr(module, name)
            globals()[name] = value
            return value
    raise AttributeError(name)
