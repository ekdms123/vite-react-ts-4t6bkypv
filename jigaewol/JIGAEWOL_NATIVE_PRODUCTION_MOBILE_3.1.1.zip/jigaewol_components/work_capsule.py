from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class WorkCapsule:
    """Portable task capsule carrying objectives, constraints, lineage, and verification state."""

    capsule_id: str
    objective: str
    inputs: dict[str, Any] = field(default_factory=dict)
    constraints: dict[str, Any] = field(default_factory=dict)
    required_capabilities: list[str] = field(default_factory=list)
    completed_actions: list[dict[str, Any]] = field(default_factory=list)
    remaining_actions: list[dict[str, Any]] = field(default_factory=list)
    permissions: dict[str, Any] = field(default_factory=dict)
    budgets: dict[str, Any] = field(default_factory=dict)
    completion_conditions: list[str] = field(default_factory=list)
    verification: dict[str, Any] = field(default_factory=dict)
    runtime_generation: int = 0
    state_version: int = 0
    active_paradigms: list[str] = field(default_factory=list)
    identity_lineage: list[str] = field(default_factory=list)
    opaque_state_refs: dict[str, str] = field(default_factory=dict)
    extensions: dict[str, Any] = field(default_factory=dict)

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "WorkCapsule":
        return cls(**json.loads(path.read_text(encoding="utf-8")))
