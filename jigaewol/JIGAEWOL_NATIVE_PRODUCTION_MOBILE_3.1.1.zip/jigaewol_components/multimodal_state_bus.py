from __future__ import annotations

"""Persistent objective/style continuity across text, image, voice, live and tool bodies.

The bus does not claim to control a host-native renderer or voice engine.  It creates a
small, durable pre-actuator contract so modality changes cannot silently drop the user's
objective, references, negative constraints, or unfinished work.  Host dispatch remains
separate and must provide its own execution receipt.
"""

import hashlib
import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable, Mapping

from .authority_guard import source_bound_objective


def _sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha_text(text: str) -> str:
    return _sha_bytes(str(text).encode("utf-8"))


def _attachment_ref(value: Any) -> dict[str, Any]:
    raw = str(value)
    path = Path(raw)
    if path.is_file():
        try:
            data = path.read_bytes()
            return {"ref": raw, "sha256": _sha_bytes(data), "name": path.name, "exists": True}
        except OSError:
            pass
    return {"ref": raw, "sha256": _sha_text(raw), "name": Path(raw).name or raw[:80], "exists": False}


@dataclass(frozen=True)
class MultimodalTurnState:
    objective_sha256: str
    modalities_requested: tuple[str, ...]
    attachment_refs: tuple[dict[str, Any], ...]
    style_capsule_id: str
    style_reference_sha256s: tuple[str, ...]
    pre_actuator_contract: dict[str, Any]
    post_actuator_contract: dict[str, Any]
    state_bus_active: bool
    updated_at: float

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class MultimodalStateBus:
    IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".heic", ".heif", ".bmp"}

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"version": 1, "style_capsule": {}, "last_turn": {}})

    def _read(self) -> dict[str, Any]:
        failure_path = self.path.parent / "multimodal_state_failures.jsonl"

        def record_failure(kind: str, error: BaseException, *, quarantine: Path | None = None) -> None:
            row = {
                "kind": str(kind),
                "source": str(self.path),
                "error_type": type(error).__name__,
                "error": str(error),
                "quarantine": str(quarantine or ""),
                "created_at": time.time(),
            }
            with failure_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")

        try:
            row = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(row, dict):
                raise TypeError("multimodal state must be a JSON object")
            return row
        except OSError as exc:
            record_failure("multimodal_state_read_failed", exc)
            raise RuntimeError(f"multimodal state read failed: {exc}") from exc
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            quarantine = self.path.with_name(
                f"{self.path.stem}.corrupt.{time.time_ns()}{self.path.suffix}"
            )
            try:
                self.path.replace(quarantine)
            except OSError as move_error:
                record_failure("multimodal_state_quarantine_failed", move_error)
                quarantine = self.path
            record_failure("multimodal_state_corrupt", exc, quarantine=quarantine)
            raise RuntimeError(f"multimodal state corrupt: {exc}") from exc

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _modalities(command: str, attachments: Iterable[Any]) -> tuple[str, ...]:
        low = str(command).casefold()
        mods: list[str] = ["text"]
        refs = tuple(str(x) for x in attachments or ())
        if any(Path(x).suffix.casefold() in MultimodalStateBus.IMAGE_EXT for x in refs) or any(
            x in low for x in ("이미지", "그림", "사진", "image", "draw", "render", "그려")
        ):
            mods.append("image")
        if any(x in low for x in ("음성", "보이스", "voice", "말로", "오디오", "audio")):
            mods.append("voice")
        if any(x in low for x in ("라이브", "live", "실시간", "screen share", "화면 공유")):
            mods.append("live")
        if any(x in low for x in ("브라우저", "browser", "웹페이지", "사이트")):
            mods.append("browser")
        return tuple(dict.fromkeys(mods))

    @staticmethod
    def _style_requested(command: str) -> bool:
        low = str(command).casefold()
        return any(x in low for x in (
            "그림체", "스타일", "style", "레퍼런스", "참고 이미지", "내 그림", "visual grammar",
            "색감", "선화", "질감", "구도", "typography", "타이포",
        ))

    def bind_turn(
        self,
        *,
        command: str,
        attachments: Iterable[Any] = (),
        semantic_authority: Mapping[str, Any] | None = None,
    ) -> MultimodalTurnState:
        data = self._read()
        refs = tuple(_attachment_ref(x) for x in attachments or ())
        authority = dict(semantic_authority or {})
        modality_text = "" if str(authority.get("task_shape") or "") == "control_update" else command
        modalities = self._modalities(modality_text, attachments)
        style_capsule = dict(data.get("style_capsule") or {})
        image_refs = tuple(
            row for row in refs if Path(str(row.get("name") or "")).suffix.casefold() in self.IMAGE_EXT
        )
        if self._style_requested(command) and image_refs:
            previous = list(style_capsule.get("references") or ())
            seen = {str(x.get("sha256") or "") for x in previous if isinstance(x, dict)}
            for row in image_refs:
                if row["sha256"] not in seen:
                    previous.append(row)
                    seen.add(row["sha256"])
            capsule_material = {
                "references": previous,
                "instruction_sha256": _sha_text(command),
                "semantics": "reference_style_state_not_artist_identity_claim",
            }
            style_capsule = {
                **capsule_material,
                "style_capsule_id": "style_" + _sha_text(json.dumps(capsule_material, sort_keys=True, ensure_ascii=False))[:20],
                "updated_at": time.time(),
            }
            data["style_capsule"] = style_capsule

        style_id = str(style_capsule.get("style_capsule_id") or "")
        style_sha = tuple(
            str(x.get("sha256") or "") for x in style_capsule.get("references") or () if isinstance(x, dict)
        )
        multimodal_active = len(modalities) > 1 or bool(style_id)
        operative_objective = source_bound_objective(command, authority) if authority else str(command)
        pre = {
            "objective": operative_objective,
            "objective_sha256": _sha_text(operative_objective),
            "modalities": list(modalities),
            "style_capsule_id": style_id,
            "style_reference_sha256s": list(style_sha),
            "preserve_user_constraints_through_actuator": True,
            "actuator_may_not_silently_drop_style_or_negative_constraints": True,
            "host_specific_prompt_compilation_happens_after_this_contract": True,
            "tool_execution_is_not_implied": True,
        }
        post = {
            "reobserve_output_when_host_returns_observable_result": True,
            "compare_against_objective_and_style_capsule": bool(style_id),
            "output_without_reobservation_is_not_style_fidelity_proof": True,
            "carry_unfinished_delta_to_next_modality": True,
        }
        out = MultimodalTurnState(
            objective_sha256=pre["objective_sha256"],
            modalities_requested=modalities,
            attachment_refs=refs,
            style_capsule_id=style_id,
            style_reference_sha256s=style_sha,
            pre_actuator_contract=pre,
            post_actuator_contract=post,
            state_bus_active=multimodal_active,
            updated_at=time.time(),
        )
        data["last_turn"] = out.as_mapping()
        self._write(data)
        return out

    def snapshot(self) -> dict[str, Any]:
        return self._read()
