from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Protocol


@dataclass(frozen=True)
class SteppingStone:
    stone_id: str
    niche: tuple[str, ...]
    utility: float
    novelty: float
    payload: Any
    lineage: tuple[str, ...] = ()


class SteppingStoneArchive:
    """Quality-diversity archive preserving useful divergent solutions."""

    def __init__(self) -> None:
        self._by_niche: dict[tuple[str, ...], SteppingStone] = {}

    def add(self, stone: SteppingStone) -> bool:
        niche = tuple(stone.niche)
        current = self._by_niche.get(niche)
        if current is None or (stone.utility, stone.novelty) > (current.utility, current.novelty):
            self._by_niche[niche] = stone
            return True
        return False

    def values(self) -> tuple[SteppingStone, ...]:
        return tuple(self._by_niche[k] for k in sorted(self._by_niche))


class ExplorationTopology(Protocol):
    topology_id: str

    def explore(self, objective: str, context: dict[str, Any]) -> Iterable[SteppingStone]: ...


class TopologyPortfolio:
    """Makes diverse exploration topologies interchangeable and composable."""

    def __init__(self, topologies: Iterable[ExplorationTopology] = ()) -> None:
        self.topologies: dict[str, ExplorationTopology] = {t.topology_id: t for t in topologies}

    def register(self, topology: ExplorationTopology) -> None:
        self.topologies[topology.topology_id] = topology

    def explore(self, objective: str, context: dict[str, Any]) -> tuple[SteppingStone, ...]:
        archive = SteppingStoneArchive()
        for topology in tuple(self.topologies.values()):
            for stone in topology.explore(objective, context):
                archive.add(stone)
        return archive.values()


@dataclass(frozen=True)
class LeapState:
    round_index: int
    objective: str
    context: dict[str, Any]
    stones: tuple[SteppingStone, ...]


WorldMutator = Callable[[LeapState], Iterable[SteppingStone]]
RealityContact = Callable[[LeapState, tuple[SteppingStone, ...]], dict[str, Any]]
CapabilityExpander = Callable[[LeapState, tuple[SteppingStone, ...]], dict[str, Any]]
StopCondition = Callable[[LeapState], bool]


class LeapBindingResolver(Protocol):
    """Resolves active implementations dynamically across exploration rounds."""

    def resolve(self, role: str) -> Callable[..., Any] | None: ...


class MappingLeapResolver:
    def __init__(self, bindings: dict[str, Callable[..., Any]] | None = None) -> None:
        self.bindings = dict(bindings or {})

    def register(self, role: str, fn: Callable[..., Any]) -> None:
        self.bindings[role] = fn

    def resolve(self, role: str) -> Callable[..., Any] | None:
        return self.bindings.get(role)


class RecursiveLeapEngine:
    federated_role = "optional_controller"
    """Facilitates continuous exploration loops after observations and capability acquisitions."""

    def __init__(self, archive: SteppingStoneArchive | None = None) -> None:
        self.archive = archive or SteppingStoneArchive()

    def run(
        self,
        objective: str,
        *,
        mutate: WorldMutator | None = None,
        reality_contact: RealityContact | None = None,
        capability_expand: CapabilityExpander | None = None,
        initial_context: dict[str, Any] | None = None,
        round_budget: int = 4,
        stop: StopCondition | None = None,
        resolver: LeapBindingResolver | None = None,
    ) -> LeapState:
        state = LeapState(0, objective, dict(initial_context or {}), self.archive.values())
        if mutate is None and resolver is None:
            context = dict(state.context)
            context["route_revision_required"] = {
                "operation": "leap_revision",
                "reason": "no mutator supplied",
                "requested_traits": ["materially_different_route"],
            }
            return LeapState(0, objective, context, self.archive.values())
        for index in range(max(1, int(round_budget))):
            round_mutate = resolver.resolve("mutate") if resolver is not None else mutate
            if round_mutate is None:
                context = dict(state.context)
                context["route_revision_required"] = {
                    "operation": "leap_revision",
                    "reason": "current mutator route unavailable",
                    "requested_traits": ["materially_different_route"],
                }
                return LeapState(index, objective, context, self.archive.values())
            generated = tuple(round_mutate(state))
            for stone in generated:
                self.archive.add(stone)
            context = dict(state.context)
            current = self.archive.values()

            round_reality = resolver.resolve("reality_contact") if resolver is not None else reality_contact
            round_expand = resolver.resolve("capability_expand") if resolver is not None else capability_expand
            if round_reality is not None:
                context.update(round_reality(state, current))
            if round_expand is not None:
                context.update(round_expand(state, current))
            state = LeapState(index + 1, objective, context, self.archive.values())
            if stop is not None and stop(state):
                break
        return state
