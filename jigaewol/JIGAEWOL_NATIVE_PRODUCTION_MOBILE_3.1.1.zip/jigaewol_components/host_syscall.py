from __future__ import annotations

import json
import sqlite3
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class HostSyscallIntent:
    syscall_id: str
    operation: str
    capability_need: str
    arguments: dict[str, Any]
    failure_family: str
    created_at: float
    status: str = "pending"


@dataclass(frozen=True)
class HostSyscallReceipt:
    syscall_id: str
    operation: str
    executor: str
    success: bool
    evidence: dict[str, Any]
    completed_at: float


class HostSyscallQueue:
    """Decoupled request queue connecting system logic to host execution surfaces.

    Enables asynchronous and deterministic execution dispatch without imposing
    rigid synchronous blocking or hardcoded channel restrictions.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "host_syscalls.sqlite3"
        with self._connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS intents(id TEXT PRIMARY KEY, body TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS receipts(id TEXT PRIMARY KEY REFERENCES intents(id), body TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY, value TEXT)")
            db.execute("BEGIN IMMEDIATE")
            if not db.execute("SELECT 1 FROM metadata WHERE key='json_migrated'").fetchone():
                legacy = self.root / "host_syscalls.json"
                if legacy.exists():
                    data = json.loads(legacy.read_text(encoding="utf-8"))
                    for table in ("intents", "receipts"):
                        for row in data.get(table, []):
                            db.execute(f"INSERT OR IGNORE INTO {table} VALUES (?,?)", (row["syscall_id"], json.dumps(row)))
                db.execute("INSERT INTO metadata VALUES ('json_migrated','1')")

    def _connect(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=30000")
        return db

    def _read(self) -> dict[str, Any]:
        with self._connect() as db:
            return {table: [json.loads(row[0]) for row in db.execute(f"SELECT body FROM {table} ORDER BY rowid")]
                    for table in ("intents", "receipts")}

    def request(
        self,
        operation: str,
        *,
        capability_need: str,
        arguments: dict[str, Any] | None = None,
        failure_family: str = "unknown",
    ) -> HostSyscallIntent:
        row = HostSyscallIntent(
            syscall_id=f"syscall_{uuid.uuid4().hex[:16]}",
            operation=str(operation),
            capability_need=str(capability_need),
            arguments=dict(arguments or {}),
            failure_family=str(failure_family),
            created_at=time.time(),
        )
        with self._connect() as db:
            db.execute("INSERT INTO intents VALUES (?,?)", (row.syscall_id, json.dumps(asdict(row), ensure_ascii=False)))
        return row

    def pending(self) -> tuple[HostSyscallIntent, ...]:
        data = self._read()
        completed = {x["syscall_id"] for x in data.get("receipts", [])}
        return tuple(
            HostSyscallIntent(**x) for x in data.get("intents", []) if x["syscall_id"] not in completed
        )

    def complete(
        self,
        syscall_id: str,
        *,
        operation: str,
        executor: str,
        success: bool,
        evidence: dict[str, Any] | None = None,
    ) -> HostSyscallReceipt:
        receipt = HostSyscallReceipt(
            syscall_id=syscall_id,
            operation=str(operation),
            executor=str(executor),
            success=bool(success),
            evidence=dict(evidence or {}),
            completed_at=time.time(),
        )
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            intent = db.execute("SELECT body FROM intents WHERE id=?", (syscall_id,)).fetchone()
            if not intent:
                raise KeyError(f"unknown syscall: {syscall_id}")
            if json.loads(intent[0])["operation"] != operation:
                raise ValueError("receipt operation does not match intent")
            try:
                db.execute("INSERT INTO receipts VALUES (?,?)", (syscall_id, json.dumps(asdict(receipt), ensure_ascii=False)))
            except sqlite3.IntegrityError as exc:
                raise ValueError(f"syscall already completed: {syscall_id}") from exc
        return receipt

    def receipts(self) -> tuple[HostSyscallReceipt, ...]:
        return tuple(HostSyscallReceipt(**x) for x in self._read().get("receipts", []))

    def successful_executors(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(x.executor for x in self.receipts() if x.success))
