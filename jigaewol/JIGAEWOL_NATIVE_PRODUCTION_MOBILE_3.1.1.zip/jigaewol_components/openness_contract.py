from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class OpennessContract:
    """Turn-scoped possibility expansion with an independent truth ledger."""

    possibility_posture: str = "keep_and_expand"
    claim_posture: str = "attach_evidence_state"
    effect_posture: str = "dispatch_for_material_user_outcomes"
    route_posture: str = "schedule_expand_replace"
    unknown_capability_posture: str = "represent_discover_compose_acquire_build"
    speculative_artifact_posture: str = "keep_as_stepping_stone"
    architecture_posture: str = "replaceable"
    recurring_failure_posture: str = "increase_replacement_pressure"
    cost_posture: str = "neutral_until_user_shapes_it"

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


def compile_openness_contract(
    semantic_authority: Mapping[str, Any] | None = None,
    *,
    project_goal_present: bool = False,
) -> dict[str, Any]:
    authority = dict(semantic_authority or {})
    open_problem = bool(authority.get("open_problem_required"))
    representation = bool(authority.get("representation_search_required"))
    depth = str(authority.get("effective_depth") or "unspecified")
    frontier = bool(authority.get("frontier_exploration_required")) or (
        project_goal_present and open_problem and depth == "deep"
    )
    base = OpennessContract().as_mapping()
    base.update({
        "active": bool(open_problem or representation or frontier),
        "frontier_mode": bool(frontier),
        "model_instruction": (
            "Keep useful hypotheses, unusual routes, unknown capabilities and stepping stones alive. "
            "Expand representations and execution routes as needed. Attach evidence state to factual claims and observed receipt state to external effects."
        ),
        "completion_semantics": "goal_delivered_or_user_changes_goal_or_real_external_dependency_waiting",
        "route_inventory_semantics": "current_routes_are_starting_material",
        "architecture_semantics": "replaceable_when_another_structure_serves_the_user_better",
    })
    return base
