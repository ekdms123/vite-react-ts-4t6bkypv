from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class EvidenceBinding:
    binding_id: str
    claim_ref: str
    observation_refs: tuple[str, ...]
    status: str
    created_at: float

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class EvidenceKernel:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "bindings.jsonl"
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")

    def bind(self, *, claim_ref: str, observation_refs: Iterable[str], status: str = "observed") -> EvidenceBinding:
        refs = tuple(dict.fromkeys(map(str, observation_refs)))
        if status in {"executed", "successful", "observed"} and not refs:
            raise ValueError(f"{status} evidence binding requires observation refs")
        seed = f"{claim_ref}|{refs}|{status}"
        binding = EvidenceBinding("evidence_" + hashlib.sha256(seed.encode()).hexdigest()[:20], str(claim_ref), refs, str(status), time.time())
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(binding.as_mapping(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return binding

    @staticmethod
    def verify(binding: EvidenceBinding | Mapping[str, Any]) -> bool:
        row = binding.as_mapping() if isinstance(binding, EvidenceBinding) else dict(binding)
        return bool(row.get("claim_ref") and row.get("observation_refs"))

    def trace_claim(self, claim_ref: str) -> tuple[dict[str, Any], ...]:
        out = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                row = json.loads(line)
                if str(row.get("claim_ref") or "") == str(claim_ref):
                    out.append(row)
        return tuple(out)
