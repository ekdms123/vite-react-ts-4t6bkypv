from __future__ import annotations

import os
import sys
try:
    import resource
except ImportError:
    if sys.platform != 'emscripten':raise
    resource = None
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class HostResourceSnapshot:
    observed_at: float
    cpu_user_s: float | None
    cpu_system_s: float | None
    max_rss_kb: int | None
    load_average: tuple[float, ...]
    thermal_celsius: tuple[dict[str, Any], ...]


class HostResourceProbe:
    """Observes available host hardware and OS resources non-invasively."""

    def snapshot(self) -> HostResourceSnapshot:
        usage = resource.getrusage(resource.RUSAGE_SELF) if resource is not None else None
        try:
            load = tuple(float(x) for x in os.getloadavg())
        except (AttributeError, OSError):
            load = ()
        thermal = []
        root = Path("/sys/class/thermal")
        if root.exists():
            for zone in sorted(root.glob("thermal_zone*")):
                temp = zone / "temp"
                if not temp.exists():
                    continue
                try:
                    raw = float(temp.read_text().strip())
                    c = raw / 1000.0 if abs(raw) > 500 else raw
                    kind = (zone / "type").read_text().strip() if (zone / "type").exists() else zone.name
                    thermal.append({"zone": zone.name, "type": kind, "celsius": c})
                except (OSError, ValueError):
                    continue
        return HostResourceSnapshot(
            time.time(),
            float(usage.ru_utime) if usage is not None else None,
            float(usage.ru_stime) if usage is not None else None,
            int(usage.ru_maxrss) if usage is not None else None,
            load,
            tuple(thermal),
        )
