from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


_PROCESS_STATE_BASE: Path | None = None


class StateContinuityError(RuntimeError):
    pass


def _safe(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value)).strip("._") or "runtime"


def _default_base() -> Path:
    global _PROCESS_STATE_BASE
    if os.environ.get("JIGAEWOL_STATE_BASE"):
        return Path(os.environ["JIGAEWOL_STATE_BASE"]).expanduser().resolve()
    if _PROCESS_STATE_BASE is None:
        _PROCESS_STATE_BASE = Path(tempfile.mkdtemp(prefix="jigaewol-canonical-state-"))
    return _PROCESS_STATE_BASE


def activation_bound_state_root(
    source_root: str | Path | None = None,
    *,
    runtime_identity: str = "jigaewol-canonical",
) -> Path | None:
    """Resolve the exact durable state root recorded by ``jigaewol_activate``.

    Activation deliberately keeps code and mutable state in separate sibling locations.
    Before R10, command-line tools that omitted ``--root`` ignored that binding and fell
    back to ``~/.jigaewol_ii_runtime``.  That created two valid-but-divergent canonical
    histories after an otherwise successful activation.

    The activation record lives *outside* the sealed artifact, so reading it does not
    mutate or weaken source integrity.  We only honor a record whose install_root is
    exactly the source tree running this code and whose state root is non-nested.
    """
    if str(runtime_identity) != "jigaewol-canonical":
        return None
    source = (
        Path(source_root).expanduser().resolve()
        if source_root is not None
        else Path(__file__).resolve().parents[1]
    )
    record_path = source.parent / f".{source.name}.activation.json"
    failure_path = source.parent / f".{source.name}.activation.failures.jsonl"

    def record_failure(kind: str, error: BaseException, *, quarantine: Path | None = None) -> None:
        payload = {
            "kind": str(kind),
            "source": str(record_path),
            "error_type": type(error).__name__,
            "error": str(error),
            "quarantine": str(quarantine or ""),
            "created_at": time.time(),
        }
        with failure_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")

    try:
        raw_record = record_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    except OSError as exc:
        record_failure("activation_record_read_failed", exc)
        raise StateContinuityError(f"activation record read failed: {exc}") from exc

    try:
        record = json.loads(raw_record)
        if not isinstance(record, dict):
            raise TypeError("activation record must be a JSON object")
        recorded_install = Path(str(record.get("install_root") or "")).expanduser().resolve()
        state = Path(str(record.get("state_root") or "")).expanduser().resolve()
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        quarantine = record_path.with_name(
            f"{record_path.stem}.corrupt.{time.time_ns()}{record_path.suffix}"
        )
        try:
            os.replace(record_path, quarantine)
        except OSError as move_error:
            record_failure("activation_record_quarantine_failed", move_error)
            quarantine = record_path
        record_failure("activation_record_corrupt", exc, quarantine=quarantine)
        raise StateContinuityError(f"activation record corrupt: {exc}") from exc
    if recorded_install != source:
        return None
    if not str(record.get("state_root") or "").strip():
        return None
    if state == source or source in state.parents or state in source.parents:
        return None
    return state


def default_canonical_state_root(
    runtime_identity: str = "jigaewol-canonical", *, use_activation_binding: bool = False,
) -> Path:
    """Use explicit state selection, otherwise fresh state shared by this process.

    Reusing an activation record is a manual continuity choice. Normal chat
    callers retain the returned base root and pass it explicitly on later turns.
    """
    exact = str(os.environ.get("JIGAEWOL_CANONICAL_STATE_ROOT") or "").strip()
    if exact:
        return Path(exact).expanduser().resolve()
    if os.environ.get("JIGAEWOL_STATE_BASE"):
        return _default_base() / _safe(runtime_identity)
    if use_activation_binding:
        bound = activation_bound_state_root(runtime_identity=runtime_identity)
        if bound is not None:
            return bound
    return _default_base() / _safe(runtime_identity)


@dataclass(frozen=True)
class StateEpoch:
    epoch_id: str
    runtime_identity: str
    state_root: str
    continuity_state: str
    predecessor_epoch_id: str
    lineage_gap_reason: str
    lineage_gap_origin_ref: str
    artifact_content_set_sha256: str
    created_at: float


class CanonicalStateStore:
    """Durable state root whose continuity survives runtime promotion/cleanup.

    A tiny registry is stored beside the state root, not inside it.  Therefore a
    deleted state directory cannot silently look like first-ever genesis: the
    surviving registry detects the missing epoch and fails closed until an
    explicit lineage-gap bootstrap is recorded.
    """

    FORMAT = "jigaewol_canonical_state_v1"

    def __init__(self, root: str | Path, *, runtime_identity: str = "jigaewol-canonical") -> None:
        self.root = Path(root).expanduser().resolve()
        self.runtime_identity = str(runtime_identity)
        self.registry_path = self.root.parent / ".jigaewol_canonical_state_registry.json"
        self.registry_failure_path = self.root.parent / ".jigaewol_canonical_state_failures.jsonl"
        self.epoch_path = self.root / "state_epoch.json"
        self.artifact_history_path = self.root / "artifact_bindings.jsonl"
        self.root.parent.mkdir(parents=True, exist_ok=True)

    def _registry_key(self) -> str:
        root_digest = hashlib.sha256(str(self.root).encode("utf-8")).hexdigest()[:20]
        return f"{self.runtime_identity}::{root_digest}"

    def _record_registry_failure(self, *, kind: str, source: Path, error: BaseException, quarantine: Path | None = None) -> None:
        row = {
            "kind": str(kind),
            "source": str(source),
            "quarantine": str(quarantine or ""),
            "error_type": type(error).__name__,
            "error": str(error),
            "recorded_at": time.time(),
        }
        self.registry_failure_path.parent.mkdir(parents=True, exist_ok=True)
        with self.registry_failure_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
            fh.flush()
            os.fsync(fh.fileno())

    def _quarantine_registry(self, error: BaseException) -> Path:
        quarantine = self.registry_path.with_name(
            f"{self.registry_path.stem}.corrupt.{time.time_ns()}{self.registry_path.suffix}"
        )
        try:
            self.registry_path.replace(quarantine)
        except OSError as move_error:
            self._record_registry_failure(
                kind="registry_quarantine_failed", source=self.registry_path, error=move_error
            )
            quarantine = self.registry_path
        self._record_registry_failure(
            kind="registry_corrupt", source=self.registry_path, error=error, quarantine=quarantine
        )
        return quarantine

    def _read_registry(self) -> dict[str, Any]:
        if not self.registry_path.exists():
            return {"format": self.FORMAT, "runtimes": {}}
        try:
            data = json.loads(self.registry_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or data.get("format") != self.FORMAT:
                raise StateContinuityError("canonical state registry format mismatch")
            runtimes = data.setdefault("runtimes", {})
            if not isinstance(runtimes, dict):
                raise StateContinuityError("canonical state registry runtimes mapping is invalid")
            return data
        except (OSError, json.JSONDecodeError, TypeError, ValueError, StateContinuityError) as exc:
            quarantine = self._quarantine_registry(exc)
            # A damaged registry is not absence of state.  If this runtime still has
            # an intact epoch, reconstruct the smallest truthful registry entry from
            # that observed epoch instead of substituting an empty registry.
            if self.epoch_path.is_file():
                epoch = self._read_epoch()
                reconstructed = {
                    "format": self.FORMAT,
                    "runtimes": {
                        self._registry_key(): {
                            "epoch_id": epoch.epoch_id,
                            "state_root": str(self.root),
                            "continuity_state": epoch.continuity_state,
                            "artifact_content_set_sha256": epoch.artifact_content_set_sha256,
                            "updated_at": time.time(),
                            "reconstructed_from_epoch": True,
                            "reconstruction_origin_ref": str(quarantine),
                        }
                    },
                }
                self._record_registry_failure(
                    kind="registry_reconstructed_from_epoch",
                    source=self.epoch_path,
                    error=exc,
                    quarantine=quarantine,
                )
                self._write_registry(reconstructed)
                return reconstructed
            raise StateContinuityError(
                "canonical state registry is corrupt and no epoch exists for reconstruction"
            ) from exc

    def _write_registry(self, data: dict[str, Any]) -> None:
        tmp = self.registry_path.with_name(self.registry_path.name + f".{uuid.uuid4().hex}.tmp")
        with tmp.open("x", encoding="utf-8") as fh:
            fh.write(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, self.registry_path)

    def _read_epoch(self) -> StateEpoch:
        try:
            raw = json.loads(self.epoch_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise StateContinuityError("canonical state epoch is missing or unreadable") from exc
        try:
            return StateEpoch(**raw)
        except TypeError as exc:
            raise StateContinuityError("canonical state epoch schema mismatch") from exc

    def _assert_epoch_bound_to_root(self, epoch: StateEpoch) -> None:
        try:
            bound = Path(epoch.state_root).expanduser().resolve()
        except Exception as exc:
            raise StateContinuityError("state epoch root is invalid") from exc
        if bound != self.root:
            raise StateContinuityError(
                f"state epoch root mismatch: epoch={bound} runtime={self.root}; explicit state relocation required"
            )

    def ensure(
        self,
        *,
        artifact_content_set_sha256: str = "",
        lineage_gap_reason: str = "",
        lineage_gap_origin_ref: str = "",
    ) -> StateEpoch:
        registry = self._read_registry()
        runtimes = registry.setdefault("runtimes", {})
        registry_key = self._registry_key()
        previous = dict(runtimes.get(registry_key) or {})
        root_exists = self.root.exists()
        epoch_exists = self.epoch_path.exists()

        if previous and (not root_exists or not epoch_exists):
            if not str(lineage_gap_reason).strip():
                raise StateContinuityError(
                    "durable canonical state disappeared after a prior epoch; explicit lineage-gap bootstrap required"
                )
            predecessor_epoch_id = str(previous.get("epoch_id") or "")
            continuity_state = "genesis_after_lineage_gap"
        elif previous and root_exists and epoch_exists:
            epoch = self._read_epoch()
            self._assert_epoch_bound_to_root(epoch)
            if epoch.epoch_id != str(previous.get("epoch_id") or ""):
                raise StateContinuityError("state registry and epoch disagree")
            if epoch.runtime_identity != self.runtime_identity:
                raise StateContinuityError("state epoch runtime identity mismatch")
            if artifact_content_set_sha256:
                self.bind_artifact(artifact_content_set_sha256)
            return epoch
        elif not previous and root_exists and epoch_exists:
            # Import a pre-registry durable root without rewriting its history.
            epoch = self._read_epoch()
            self._assert_epoch_bound_to_root(epoch)
            runtimes[registry_key] = {
                "epoch_id": epoch.epoch_id,
                "state_root": str(self.root),
                "continuity_state": epoch.continuity_state,
                "artifact_content_set_sha256": epoch.artifact_content_set_sha256,
                "updated_at": time.time(),
            }
            self._write_registry(registry)
            if artifact_content_set_sha256:
                self.bind_artifact(artifact_content_set_sha256)
            return epoch
        else:
            predecessor_epoch_id = ""
            from .portable_recovery import resolve_active_capsule
            active_recovery = resolve_active_capsule(self.root)
            if active_recovery.get("present") and not str(lineage_gap_reason).strip():
                recovery = dict(active_recovery.get("capsule") or {})
                continuity_state = "seeded_recovery"
                lineage_gap_reason = "mutable_state_unavailable_portable_capsule_applied"
                lineage_gap_origin_ref = str(
                    recovery.get("capsule_sha256") or active_recovery.get("path") or "portable_recovery"
                )
            else:
                continuity_state = "genesis_after_lineage_gap" if str(lineage_gap_reason).strip() else "genesis"

        self.root.mkdir(parents=True, exist_ok=True)
        epoch = StateEpoch(
            epoch_id="epoch_" + uuid.uuid4().hex[:20],
            runtime_identity=self.runtime_identity,
            state_root=str(self.root),
            continuity_state=continuity_state,
            predecessor_epoch_id=predecessor_epoch_id,
            lineage_gap_reason=str(lineage_gap_reason).strip(),
            lineage_gap_origin_ref=str(lineage_gap_origin_ref).strip(),
            artifact_content_set_sha256=str(artifact_content_set_sha256).strip(),
            created_at=time.time(),
        )
        self.epoch_path.write_text(json.dumps(asdict(epoch), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        runtimes[registry_key] = {
            "epoch_id": epoch.epoch_id,
            "state_root": str(self.root),
            "continuity_state": epoch.continuity_state,
            "artifact_content_set_sha256": epoch.artifact_content_set_sha256,
            "updated_at": time.time(),
        }
        self._write_registry(registry)
        if artifact_content_set_sha256:
            self.bind_artifact(artifact_content_set_sha256, origin_ref="runtime:state_bootstrap")
        return epoch


    def bind_artifact(self, artifact_content_set_sha256: str, *, origin_ref: str = "runtime:gateway") -> dict[str, Any]:
        digest = str(artifact_content_set_sha256 or "").strip()
        if not digest:
            return {}
        epoch = self._read_epoch()
        self._assert_epoch_bound_to_root(epoch)
        last = {}
        if self.artifact_history_path.exists():
            for raw in self.artifact_history_path.read_text(encoding="utf-8").splitlines():
                if raw.strip():
                    last = json.loads(raw)
        if last.get("artifact_content_set_sha256") == digest and last.get("epoch_id") == epoch.epoch_id:
            return last
        row = {"epoch_id": epoch.epoch_id, "artifact_content_set_sha256": digest,
               "origin_ref": str(origin_ref), "bound_at": time.time()}
        self.artifact_history_path.parent.mkdir(parents=True, exist_ok=True)
        with self.artifact_history_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        registry = self._read_registry(); entry = registry.setdefault("runtimes", {}).setdefault(self._registry_key(), {})
        entry["artifact_content_set_sha256"] = digest; entry["updated_at"] = time.time(); self._write_registry(registry)
        return row

    def status(self) -> dict[str, Any]:
        registry = self._read_registry()
        entry = dict(registry.get("runtimes", {}).get(self._registry_key()) or {})
        epoch = None
        if self.epoch_path.exists():
            epoch = asdict(self._read_epoch())
        return {
            "format": self.FORMAT,
            "runtime_identity": self.runtime_identity,
            "registry_key": self._registry_key(),
            "state_root": str(self.root),
            "registry_path": str(self.registry_path),
            "registered": bool(entry),
            "root_exists": self.root.exists(),
            "epoch_exists": self.epoch_path.exists(),
            "registry_entry": entry,
            "epoch": epoch,
            "state_root_sha256": hashlib.sha256(str(self.root).encode("utf-8")).hexdigest(),
        }


def ensure_canonical_state_root(
    explicit_root: str | Path | None = None,
    *,
    runtime_identity: str = "jigaewol-canonical",
    artifact_content_set_sha256: str = "",
    lineage_gap_reason: str = "",
    lineage_gap_origin_ref: str = "",
) -> tuple[Path, StateEpoch]:
    root = Path(explicit_root).expanduser().resolve() if explicit_root else default_canonical_state_root(runtime_identity)
    store = CanonicalStateStore(root, runtime_identity=runtime_identity)
    epoch = store.ensure(
        artifact_content_set_sha256=artifact_content_set_sha256,
        lineage_gap_reason=lineage_gap_reason,
        lineage_gap_origin_ref=lineage_gap_origin_ref,
    )
    return root, epoch
