from __future__ import annotations

import copy
import json
import math
import subprocess
import sys

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Protocol

from jigaewol_components.dynamic_execution_gate import DynamicExecutionGate


@dataclass
class NeutralStateGraph:
    """Portable semantic state shared across diverse computation paradigms."""

    facts: dict[str, Any] = field(default_factory=dict)
    observations: list[dict[str, Any]] = field(default_factory=list)
    opaque_state_refs: dict[str, str] = field(default_factory=dict)
    lineage: list[str] = field(default_factory=list)


class StateBridge(Protocol):
    def encode(self, neutral: NeutralStateGraph) -> Any: ...
    def decode(self, native: Any, neutral: NeutralStateGraph) -> NeutralStateGraph: ...


class IdentityStateBridge:
    def encode(self, neutral: NeutralStateGraph) -> Any:
        return copy.deepcopy(neutral.facts)

    def decode(self, native: Any, neutral: NeutralStateGraph) -> NeutralStateGraph:
        updated = copy.deepcopy(neutral)
        if isinstance(native, dict):
            updated.facts.update(copy.deepcopy(native))
        else:
            updated.observations.append({"native_value": copy.deepcopy(native)})
        return updated


@dataclass(frozen=True)
class ExecutionEnvironmentSpec:
    environment_kind: str
    requirements: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ParadigmCapsule:
    paradigm_id: str
    state_model: str
    transition_semantics: str
    execution_model: str
    environment: ExecutionEnvironmentSpec
    source: str
    entrypoint: str = "step"
    bridge: StateBridge = field(default_factory=IdentityStateBridge)
    parents: tuple[str, ...] = ()
    rationale: str = ""
    extensions: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ParadigmResult:
    paradigm_id: str
    environment_kind: str
    neutral_state: NeutralStateGraph
    native_state: Any
    output: Any


class ParadigmExecutor(Protocol):
    def step(self, native_state: Any, payload: dict[str, Any]) -> tuple[Any, Any]: ...


class EnvironmentBuilder(Protocol):
    def build(self, capsule: ParadigmCapsule, root: Path) -> ParadigmExecutor: ...


class _InProcessPythonExecutor:
    def __init__(self, fn: Callable[[Any, dict[str, Any]], Any]) -> None:
        self.fn = fn

    def step(self, native_state: Any, payload: dict[str, Any]) -> tuple[Any, Any]:
        value = self.fn(copy.deepcopy(native_state), copy.deepcopy(payload))
        if isinstance(value, tuple) and len(value) == 2:
            return value[0], value[1]
        return value, value


_CAPSULE_BUILTINS = {
    "abs": abs, "all": all, "any": any, "bool": bool, "dict": dict,
    "divmod": divmod, "enumerate": enumerate, "filter": filter, "float": float,
    "frozenset": frozenset, "int": int, "isinstance": isinstance, "len": len,
    "list": list, "map": map, "max": max, "min": min, "pow": pow, "range": range,
    "repr": repr, "reversed": reversed, "round": round, "set": set, "slice": slice,
    "sorted": sorted, "str": str, "sum": sum, "tuple": tuple, "zip": zip,
    "ArithmeticError": ArithmeticError, "AssertionError": AssertionError,
    "Exception": Exception, "IndexError": IndexError, "KeyError": KeyError,
    "TypeError": TypeError, "ValueError": ValueError,
    "ZeroDivisionError": ZeroDivisionError,
}


class InProcessPythonBuilder:
    """Compiles capsule semantics into a restricted namespace in this process.

    Capsule transition functions get the state/payload they are handed plus `math`
    and `json`; `__builtins__` is an allowlist, so `import`, `open` and the rest of
    the filesystem/process surface are unreachable. This is an interface boundary
    inside one process, not a sandbox: a capsule still shares this interpreter, so
    untrusted source belongs in `subprocess_python` or the isolated executor.
    """

    def build(self, capsule: ParadigmCapsule, root: Path) -> ParadigmExecutor:
        namespace: dict[str, Any] = {
            "__builtins__": dict(_CAPSULE_BUILTINS),
            "math": math,
            "json": json,
        }
        gate = DynamicExecutionGate(root / "dynamic_execution")
        expected = capsule.extensions.get("source_sha256") if isinstance(capsule.extensions, dict) else None
        admission = gate.admit(
            source_id=f"paradigm:{capsule.paradigm_id}",
            source=capsule.source,
            execution_mode="restricted_inprocess",
            trust_level="restricted_capsule",
            expected_sha256=str(expected) if expected else None,
        )
        gate.execute(
            admission, source=capsule.source, filename=f"<paradigm:{capsule.paradigm_id}>", namespace=namespace
        )
        fn = namespace[capsule.entrypoint]
        return _InProcessPythonExecutor(fn)


class _SubprocessPythonExecutor:
    def __init__(self, program: Path) -> None:
        self.program = program

    def step(self, native_state: Any, payload: dict[str, Any]) -> tuple[Any, Any]:
        proc = subprocess.run(
            [sys.executable, str(self.program)],
            input=json.dumps({"state": native_state, "payload": payload}, ensure_ascii=False),
            text=True,
            capture_output=True,
            check=False,
            timeout=120,
        )
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or f"subprocess paradigm failed: {proc.returncode}")
        row = json.loads(proc.stdout)
        return row["state"], row.get("output")


class SubprocessPythonBuilder:
    """Synthesizes a separate process environment for a paradigm capsule."""

    def build(self, capsule: ParadigmCapsule, root: Path) -> ParadigmExecutor:
        env_dir = root / "environments" / capsule.paradigm_id
        env_dir.mkdir(parents=True, exist_ok=True)
        program = env_dir / "runner.py"
        program.write_text(
            "import json,sys\n"
            + capsule.source
            + "\nrow=json.loads(sys.stdin.read())\n"
            + f"value={capsule.entrypoint}(row.get('state'), row.get('payload', {{}}))\n"
            + "state,output=(value if isinstance(value,(list,tuple)) and len(value)==2 else (value,value))\n"
            + "print(json.dumps({'state':state,'output':output}, ensure_ascii=False))\n",
            encoding="utf-8",
        )
        return _SubprocessPythonExecutor(program)


class EnvironmentSynthesizer:
    """Open registry of execution-environment builders."""

    def __init__(self) -> None:
        self.builders: dict[str, EnvironmentBuilder] = {
            "inprocess_python": InProcessPythonBuilder(),
            "subprocess_python": SubprocessPythonBuilder(),
        }

    def register(self, environment_kind: str, builder: EnvironmentBuilder) -> None:
        self.builders[environment_kind] = builder

    def register_from_source(
        self,
        environment_kind: str,
        source: str,
        *,
        class_name: str = "EnvironmentBuilder",
        root: Path | None = None,
        expected_sha256: str | None = None,
        trust_level: str = "unknown",
    ) -> EnvironmentBuilder:
        """Install a reviewed dynamic builder behind a content-addressed gate.

        Builder source has full interpreter authority, so unhashed or merely discovered
        third-party source is never executed in-process.  The caller must bind the exact
        bytes to an expected SHA-256 and state an explicit reviewed trust level.
        """
        gate_root = Path(root or Path.cwd() / ".jigaewol_dynamic_execution")
        gate = DynamicExecutionGate(gate_root)
        admission = gate.admit(
            source_id=f"environment-builder:{environment_kind}",
            source=source,
            execution_mode="reviewed_builder",
            trust_level=trust_level,
            expected_sha256=expected_sha256,
        )
        namespace: dict[str, Any] = {}
        gate.execute(
            admission, source=source, filename=f"<environment-builder:{environment_kind}>", namespace=namespace
        )
        builder = namespace[class_name]()
        self.register(environment_kind, builder)
        return builder

    def build(self, capsule: ParadigmCapsule, root: Path) -> ParadigmExecutor:
        builder = self.builders.get(capsule.environment.environment_kind)
        if builder is None:
            raise KeyError(f"no environment builder registered for {capsule.environment.environment_kind}")
        return builder.build(capsule, root)


class ParadigmMetaRuntime:
    """Installs calculation paradigms and execution environments adaptively at runtime."""

    def __init__(self, root: Path, *, synthesizer: EnvironmentSynthesizer | None = None) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.synthesizer = synthesizer or EnvironmentSynthesizer()
        self.capsules: dict[str, ParadigmCapsule] = {}
        self.executors: dict[str, ParadigmExecutor] = {}
        self.native_states: dict[str, Any] = {}

    def register_environment(self, environment_kind: str, builder: EnvironmentBuilder) -> None:
        self.synthesizer.register(environment_kind, builder)

    def register_environment_from_source(
        self,
        environment_kind: str,
        source: str,
        *,
        class_name: str = "EnvironmentBuilder",
        expected_sha256: str | None = None,
        trust_level: str = "unknown",
    ) -> EnvironmentBuilder:
        return self.synthesizer.register_from_source(
            environment_kind, source, class_name=class_name, root=self.root / "dynamic_execution",
            expected_sha256=expected_sha256, trust_level=trust_level,
        )

    def install(self, capsule: ParadigmCapsule, *, neutral_state: NeutralStateGraph | None = None) -> None:
        executor = self.synthesizer.build(capsule, self.root)
        neutral = neutral_state or NeutralStateGraph()
        self.capsules[capsule.paradigm_id] = capsule
        self.executors[capsule.paradigm_id] = executor
        self.native_states[capsule.paradigm_id] = capsule.bridge.encode(neutral)
        self._write_manifest(capsule)

    def _write_manifest(self, capsule: ParadigmCapsule) -> None:
        path = self.root / "paradigms"
        path.mkdir(parents=True, exist_ok=True)
        row = {
            "paradigm_id": capsule.paradigm_id,
            "state_model": capsule.state_model,
            "transition_semantics": capsule.transition_semantics,
            "execution_model": capsule.execution_model,
            "environment_kind": capsule.environment.environment_kind,
            "requirements": list(capsule.environment.requirements),
            "parents": list(capsule.parents),
            "rationale": capsule.rationale,
        }
        target = path / f"{capsule.paradigm_id}.json"
        tmp = target.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(target)

    def step(
        self,
        paradigm_id: str,
        neutral_state: NeutralStateGraph,
        payload: dict[str, Any] | None = None,
    ) -> ParadigmResult:
        capsule = self.capsules[paradigm_id]
        executor = self.executors[paradigm_id]
        native = self.native_states.get(paradigm_id, capsule.bridge.encode(neutral_state))
        next_native, output = executor.step(native, copy.deepcopy(payload or {}))
        self.native_states[paradigm_id] = copy.deepcopy(next_native)
        decoded = capsule.bridge.decode(next_native, neutral_state)
        decoded.lineage.append(paradigm_id)
        decoded.observations.append({
            "paradigm_id": paradigm_id,
            "environment": capsule.environment.environment_kind,
            "output": copy.deepcopy(output),
        })
        return ParadigmResult(
            paradigm_id=paradigm_id,
            environment_kind=capsule.environment.environment_kind,
            neutral_state=decoded,
            native_state=copy.deepcopy(next_native),
            output=copy.deepcopy(output),
        )

    def installed(self) -> tuple[str, ...]:
        return tuple(sorted(self.capsules))


ParadigmCompiler = Callable[[str, str, tuple[ParadigmCapsule, ...]], ParadigmCapsule]


class ParadigmInventor:
    """Turns hypotheses into executable paradigms with mutable compiler generations."""

    def __init__(self, compiler: ParadigmCompiler) -> None:
        self.compiler = compiler
        self.compiler_generation = 1
        self.compiler_lineage: list[dict[str, Any]] = [
            {"generation": 1, "reason": "bootstrap"}
        ]

    def replace_compiler(self, compiler: ParadigmCompiler, *, reason: str) -> int:
        self.compiler = compiler
        self.compiler_generation += 1
        self.compiler_lineage.append({
            "generation": self.compiler_generation,
            "reason": reason,
        })
        return self.compiler_generation

    def invent(self, objective: str, hypothesis: str, prior: tuple[ParadigmCapsule, ...]) -> ParadigmCapsule:
        capsule = self.compiler(objective, hypothesis, prior)
        capsule.rationale = (
            capsule.rationale + " | " if capsule.rationale else ""
        ) + f"compiler_generation={self.compiler_generation}"
        return capsule
