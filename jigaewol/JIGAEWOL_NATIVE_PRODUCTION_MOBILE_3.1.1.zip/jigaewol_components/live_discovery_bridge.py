from __future__ import annotations

import hashlib
import json
import re
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .hunt_graph import HuntGraph
from .search_portfolio_engine import SearchPortfolioEngine


@dataclass(frozen=True)
class DiscoveryReceipt:
    receipt_id: str
    objective: str
    source_family: str
    route_id: str
    observation_scope: str
    authorized_signed_in: bool
    state: str
    item_count: int
    item_set_sha256: str
    evidence_refs: tuple[str, ...]
    hunt_counts: dict[str, int]
    next_queries: tuple[dict[str, str], ...]
    created_at: float


class LiveDiscoveryBridge:
    """Host-observation intake that closes search results back into the Hunt Graph.

    Network/browser/plugin calls live outside the ZIP.  This bridge gives those host
    observations a canonical receipt, keeps signed-in feed perception distinct from
    public search, extracts creator/repository/community vocabulary into durable graph
    state, and compiles a materially varied next search generation.
    """

    _SCOPES = {"public_search", "public_page", "community", "code", "research", "personal_knowledge", "signed_in_feed"}
    _SENSITIVE_KEYS = re.compile(r"(?:password|passwd|secret|api[_-]?key|authorization|cookie|session[_-]?token|access[_-]?token)", re.I)

    def __init__(self, root: str | Path, hunt_graph: HuntGraph) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.hunt = hunt_graph
        self.receipts_path = self.root / "host_observations.jsonl"
        self.blocked_path = self.root / "blocked_routes.jsonl"

    @staticmethod
    def _append(path: Path, row: Mapping[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")

    @classmethod
    def _clean_value(cls, key: str, value: Any) -> Any:
        if cls._SENSITIVE_KEYS.search(str(key)):
            return "[redacted]"
        if isinstance(value, str):
            return value
        if isinstance(value, (list, tuple, set)):
            return [cls._clean_value(key, x) for x in value]
        if isinstance(value, Mapping):
            return {str(k): cls._clean_value(str(k), v) for k, v in value.items()}
        if value is None or isinstance(value, (bool, int, float)):
            return value
        return str(value)

    @classmethod
    def normalize_item(cls, raw: Mapping[str, Any]) -> dict[str, Any]:
        allowed = {
            "title", "name", "label", "url", "link", "snippet", "summary", "creator", "author", "handle",
            "repo", "repository", "terms", "novel_terms", "slang", "tags", "entities", "signal", "novelty",
            "recency", "published_at", "platform", "source_ref",
        }
        out = {str(k): cls._clean_value(str(k), v) for k, v in raw.items()}
        url = str(out.get("url") or out.get("link") or "")
        if not out.get("repo") and "github.com/" in url:
            m = re.search(r"github\.com/([^/]+/[^/#?]+)", url)
            if m:
                out["repo"] = m.group(1).removesuffix(".git")
        return out

    def mark_blocked_route(
        self,
        *,
        objective: str,
        source_family: str,
        route_id: str,
        observation_scope: str,
        reason: str,
        evidence_ref: str = "",
    ) -> dict[str, Any]:
        node = self.hunt.observe(
            kind="route",
            key=str(route_id),
            novelty=.65,
            recency=1.0,
            signal=.7,
            blocked=True,
            metadata={
                "objective": str(objective), "source_family": str(source_family), "observation_scope": str(observation_scope),
                "reason": str(reason), "evidence_ref": str(evidence_ref),
            },
        )
        row = {
            "event": "discovery_route_blocked_open", "route_id": str(route_id), "source_family": str(source_family),
            "observation_scope": str(observation_scope), "reason": str(reason), "evidence_ref": str(evidence_ref),
            "hunt_node_id": node.node_id, "created_at": time.time(),
        }
        self._append(self.blocked_path, row)
        return row

    @staticmethod
    def _tokens(query: str) -> set[str]:
        return {x.casefold() for x in re.findall(r"[\w.+#/-]{2,}", query, flags=re.UNICODE)}

    @classmethod
    def _diverse_select(cls, rows: Iterable[dict[str, str]], limit: int | None = None) -> tuple[dict[str, str], ...]:
        pool = [dict(x) for x in rows]
        if not pool:
            return ()
        selected = [pool.pop(0)]
        target = len(pool) + 1 if limit is None else max(1, int(limit))
        while pool and len(selected) < target:
            seen = [cls._tokens(x.get("query", "")) for x in selected]
            best_i = 0
            best_score = -1.0
            for i, row in enumerate(pool):
                toks = cls._tokens(row.get("query", ""))
                if not toks:
                    score = 0.0
                else:
                    max_sim = 0.0
                    for old in seen:
                        union = toks | old
                        sim = len(toks & old) / len(union) if union else 1.0
                        max_sim = max(max_sim, sim)
                    # Prefer vocabulary not already represented; retain small dialect bonus.
                    score = 1.0 - max_sim + (0.03 if row.get("dialect_id") or row.get("dialect") else 0.0)
                if score > best_score:
                    best_i, best_score = i, score
            selected.append(pool.pop(best_i))
        return tuple(selected)

    def next_queries(
        self,
        objective: str,
        *,
        source_families: Iterable[str] = ("web_current", "community", "code_ecosystem", "creator_graph", "multilingual"),
        limit: int | None = None,
    ) -> tuple[dict[str, str], ...]:
        frontier = [x for x in self.hunt.actionable_frontier(None) if x.kind in {"term", "creator", "repo"}]
        frontier_terms = [x.key for x in frontier]
        rows: list[dict[str, str]] = []
        for family in dict.fromkeys(str(x) for x in source_families if str(x).strip()):
            for row in SearchPortfolioEngine.compile_concrete_queries(objective, family, max_queries=None):
                rows.append({"source_family": family, **row})
            # Observation-derived vocabulary re-enters the query program.  Keep each query
            # short so community/repo engines receive native fragments instead of prompt prose.
            for term in frontier_terms:
                enriched = f"{objective} {term}"
                compiled = SearchPortfolioEngine.compile_concrete_queries(enriched, family, max_queries=None)
                for row in compiled:
                    rows.append({"source_family": family, "dialect": "graph_reentry:" + str(row.get("dialect_id") or row.get("dialect") or "native"), "query": row["query"]})
        # Exact-string de-dup before diversity selection.
        unique: list[dict[str, str]] = []
        seen: set[str] = set()
        for row in rows:
            key = row.get("query", "").casefold().strip()
            if key and key not in seen:
                seen.add(key); unique.append(row)
        return self._diverse_select(unique, limit)

    def ingest_bundle(self, bundle: Mapping[str, Any]) -> DiscoveryReceipt:
        objective = str(bundle.get("objective") or "").strip()
        source_family = str(bundle.get("source_family") or "web_current").strip()
        route_id = str(bundle.get("route_id") or "host:unknown").strip()
        scope = str(bundle.get("observation_scope") or "public_search").strip()
        authorized_signed_in = bool(bundle.get("authorized_signed_in", False))
        evidence_refs = tuple(dict.fromkeys(str(x) for x in (bundle.get("evidence_refs") or ()) if str(x)))
        if scope not in self._SCOPES:
            raise ValueError(f"unknown observation_scope: {scope}")
        if scope == "signed_in_feed" and not authorized_signed_in:
            self.mark_blocked_route(
                objective=objective, source_family=source_family, route_id=route_id, observation_scope=scope,
                reason="signed_in_feed_requires_authorized_user_session", evidence_ref=evidence_refs[0] if evidence_refs else "",
            )
            raise PermissionError("signed_in_feed requires an authorized signed-in user session")
        raw_items = bundle.get("items") or ()
        if not isinstance(raw_items, (list, tuple)):
            raise TypeError("items must be a list/tuple of observation records")
        items = tuple(self.normalize_item(dict(x)) for x in raw_items if isinstance(x, Mapping))
        encoded = json.dumps(items, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        item_hash = hashlib.sha256(encoded).hexdigest()
        counts = self.hunt.ingest_observation(
            source_family=source_family,
            items=items,
            evidence_ref=evidence_refs[0] if evidence_refs else item_hash,
        )
        next_rows = self.next_queries(objective, limit=int(bundle.get("next_query_limit") or 14))
        receipt = DiscoveryReceipt(
            receipt_id="discovery_" + uuid.uuid4().hex[:18], objective=objective, source_family=source_family,
            route_id=route_id, observation_scope=scope, authorized_signed_in=authorized_signed_in,
            state="observed_public" if scope != "signed_in_feed" else "observed_authorized_signed_in",
            item_count=len(items), item_set_sha256=item_hash, evidence_refs=evidence_refs,
            hunt_counts=counts, next_queries=next_rows, created_at=time.time(),
        )
        self._append(self.receipts_path, asdict(receipt))
        return receipt
