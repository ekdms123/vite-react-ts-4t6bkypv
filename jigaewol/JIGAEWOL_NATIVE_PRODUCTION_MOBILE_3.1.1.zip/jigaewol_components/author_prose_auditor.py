"""Structural prose audit for the author core.

This is deliberately not an AI-detector and not a word blacklist.  It searches for
recurring *generation habits* that collapse local variance: template paragraphs,
repeated closure mechanics, explanation-after-evidence, and unnaturally uniform
cadence.  Findings are advisory and must be read against character/scene intent.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import math
import re
from typing import Any

SCHEMA = "author_prose_audit.v1"
_SENT_SPLIT = re.compile(r"(?<=[.!?…。！？])(?:\s+|$)|\n+")
_QUOTE_START = tuple('"“”\'‘’「『')
_EXPLAIN = re.compile(r"(?:그 말(?:은|이)|그게 무슨 뜻|뜻이었|의미였|말인즉|말하자면|다시 말해|즉[ ,])")
_GENERIC_CLOSURE = re.compile(r"(?:결국|그렇게|그 순간|모든 것이|아무것도|그때부터|이제야|그제야).{0,35}[.!?…。！？]?$", re.S)
_BODY_PROXY = {
    'eye': re.compile(r'(?:눈(?:빛|동자|길|썹)?|시선)'),
    'hand': re.compile(r'(?:손끝|손바닥|손가락|손목|손등|손(?!잡이|님|질))'),
    'breath': re.compile(r'(?:숨(?:결|소리)?|호흡)'),
    'heart': re.compile(r'(?:심장|가슴(?:팍|속)?)'),
    'mouth': re.compile(r'(?:입술|입가|입꼬리|목소리)'),
}
_SIMILE = re.compile(r'(?:마치\s+[^.!?\n]{0,50}?(?:처럼|듯(?:이|한)?))|(?:[가-힣A-Za-z0-9]{2,12}(?:처럼|듯(?:이|한)?))')
_COGNITIVE = re.compile(r'(?:뜻|의미|생각|느꼈|깨달|알았|알게|마음|감정)')
_REFLECTIVE_CLOSURE = re.compile(
    r'(?:생각이\s*들었다|(?:다는|라는)\s*것(?:이|은)\s*분명했다|(?:다고|라고)\s*알았다|사실을\s*깨달았다|(?:다는|이라는|라는)\s*셈이었다|수밖에\s*없었다|뿐(?:이었다|이라는\s*셈이었다)|의미였다|마음이었다|느낌이었다)[.!?…。！？]?$'
)


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENT_SPLIT.split(text) if s.strip()]


def _paras(text: str) -> list[str]:
    return [p.strip() for p in re.split(r"\n\s*\n+", text) if p.strip()]


def _ending_class(s: str) -> str:
    t = s.rstrip('"”’\' )]}』」')
    if not t:
        return "empty"
    if t.endswith(("…", "...", "..")):
        return "ellipsis"
    if t.endswith("?"):
        return "question"
    if t.endswith("!"):
        return "exclaim"
    core = t.rstrip(".!?…。！？ ")
    if re.search(r"(?:했다|였다|있었다|없었다|됐다|갔다|왔다|봤다|줬다|냈다)$", core):
        return "past_da"
    if core.endswith("다"):
        return "da"
    if re.search(r"(?:지|네|군|나|까|야|아|어|래|걸|데|게|고|니|구나|잖아|거든)$", core):
        return "colloq"
    return "other"


def _len_bin(n: int) -> int:
    if n < 12:
        return 0
    if n < 24:
        return 1
    if n < 42:
        return 2
    if n < 70:
        return 3
    return 4


def _closure_mode(p: str) -> str:
    ss = _sentences(p)
    if not ss:
        return "empty"
    last = ss[-1].strip()
    if _dialogue_paragraph(p):
        return "dialogue"
    if last.endswith(("?", "？")):
        return "question"
    if last.endswith(("…", "...", "..")):
        return "ellipsis"
    if _GENERIC_CLOSURE.search(last) or _REFLECTIVE_CLOSURE.search(last):
        return "reflective_summary"
    if any(rx.search(last) for rx in _BODY_PROXY.values()):
        return "body_image"
    return "event_or_observation"


def _paragraph_role(p: str) -> str:
    if _dialogue_paragraph(p):
        return "dialogue"
    mode = _closure_mode(p)
    if mode == "reflective_summary":
        return "reflection_close"
    if mode in {"question", "ellipsis"}:
        return mode
    if any(rx.search(p) for rx in _BODY_PROXY.values()):
        return "body_or_sensory"
    if _COGNITIVE.search(p):
        return "cognitive"
    return "event"


def _role_sequence_hashes(paras: list[str], width: int = 3) -> Counter:
    roles = [_paragraph_role(p) for p in paras]
    if len(roles) < width:
        return Counter()
    return Counter(_key_hash(tuple(roles[i:i + width])) for i in range(len(roles) - width + 1))


def _para_signature(p: str) -> tuple[Any, ...]:
    ss = _sentences(p)
    if not ss:
        return (0, (), False, "empty")
    return (
        min(len(ss), 5),
        tuple(_len_bin(len(s)) for s in ss[:4]),
        p.startswith(_QUOTE_START),
        _ending_class(ss[-1]),
    )


def _cv(values: list[float]) -> float:
    if len(values) < 2:
        return 1.0
    mean = sum(values) / len(values)
    if not mean:
        return 0.0
    return math.sqrt(sum((v - mean) ** 2 for v in values) / len(values)) / mean


def _tail_key(p: str) -> str:
    ss = _sentences(p)
    if not ss:
        return ""
    words = re.findall(r"[가-힣A-Za-z0-9]+", ss[-1])
    return " ".join(words[-3:]).casefold()



def _tokens(text: str) -> list[str]:
    return re.findall(r"[가-힣A-Za-z0-9]+", text.casefold())


def _jaccard(a: str, b: str) -> float:
    aa, bb = set(_tokens(a)), set(_tokens(b))
    if not aa or not bb:
        return 0.0
    return len(aa & bb) / len(aa | bb)


def _dialogue_paragraph(p: str) -> bool:
    return p.startswith(_QUOTE_START)


def _entropy(counter: Counter) -> float:
    total = sum(counter.values())
    if total <= 0:
        return 0.0
    result = 0.0
    for count in counter.values():
        p = count / total
        result -= p * math.log2(p)
    return result


def _key_hash(value: Any) -> str:
    return hashlib.sha256(repr(value).encode("utf-8")).hexdigest()[:16]


def prose_fingerprint(text: str) -> dict[str, Any]:
    """Abstract a scene's recurrent prose shape without retaining source sentences.

    The fingerprint is descriptive memory, not a target style.  It lets later scenes
    detect that the model is falling back to the same paragraph/closure machinery.
    """
    raw = str(text or "")
    paras = _paras(raw)
    sents = _sentences(raw)
    para_sigs = Counter(_key_hash(_para_signature(p)) for p in paras)
    tails = Counter(_key_hash(_tail_key(p)) for p in paras if _tail_key(p))
    openings = Counter()
    for sentence in sents:
        words = re.findall(r"[가-힣A-Za-z]+", sentence)
        if words:
            openings[_key_hash(tuple(w.casefold() for w in words[:2]))] += 1
    endings = Counter(_ending_class(s) for s in sents)
    closure_modes = Counter(_closure_mode(p) for p in paras)
    role_sequences = _role_sequence_hashes(paras)
    proxy_counts = {name: len(rx.findall(raw)) for name, rx in _BODY_PROXY.items()}
    proxy_total = sum(proxy_counts.values())
    proxy_name, proxy_count = max(proxy_counts.items(), key=lambda item: item[1]) if proxy_counts else ("", 0)
    similes = _SIMILE.findall(raw)
    simile_frames = Counter("마치" if x.strip().startswith("마치") else ("처럼" if "처럼" in x else "듯") for x in similes)
    simile_name, simile_count = simile_frames.most_common(1)[0] if simile_frames else ("", 0)
    return {
        "schema": "author_prose_fingerprint.v1",
        "characters": len(raw),
        "paragraphs": len(paras),
        "sentences": len(sents),
        "sentence_length_cv": round(_cv([len(s) for s in sents]), 4) if sents else 0.0,
        "paragraph_length_cv": round(_cv([len(p) for p in paras]), 4) if paras else 0.0,
        "dialogue_paragraph_ratio": round(sum(1 for p in paras if _dialogue_paragraph(p)) / len(paras), 4) if paras else 0.0,
        "dominant_ending": endings.most_common(1)[0][0] if endings else "",
        "dominant_ending_share": round(endings.most_common(1)[0][1] / len(sents), 4) if sents else 0.0,
        "ending_entropy": round(_entropy(endings), 4),
        "paragraph_signature_entropy": round(_entropy(para_sigs), 4),
        "dominant_closure_mode": closure_modes.most_common(1)[0][0] if closure_modes else "",
        "dominant_closure_mode_share": round(closure_modes.most_common(1)[0][1] / len(paras), 4) if paras else 0.0,
        "paragraph_role_sequence_entropy": round(_entropy(role_sequences), 4),
        "top_paragraph_role_sequence_hashes": [
            {"hash": key, "count": count, "share": round(count / max(1, len(paras) - 2), 4)}
            for key, count in role_sequences.most_common(4)
        ],
        "top_paragraph_signature_hashes": [
            {"hash": key, "count": count, "share": round(count / len(paras), 4)}
            for key, count in para_sigs.most_common(4)
        ] if paras else [],
        "top_closure_tail_hashes": [
            {"hash": key, "count": count, "share": round(count / len(paras), 4)}
            for key, count in tails.most_common(4)
        ] if paras else [],
        "top_opening_hashes": [
            {"hash": key, "count": count, "share": round(count / len(sents), 4)}
            for key, count in openings.most_common(4)
        ] if sents else [],
        "body_proxy": {
            "dominant_family": proxy_name,
            "share": round(proxy_count / proxy_total, 4) if proxy_total else 0.0,
            "mentions": proxy_total,
        },
        "simile_frame": {
            "dominant_frame": simile_name,
            "share": round(simile_count / len(similes), 4) if similes else 0.0,
            "mentions": len(similes),
        },
        "policy": "descriptive recurrence memory only; never optimize prose to match this fingerprint",
    }


def _dominant_hash(fp: dict[str, Any], key: str, minimum_share: float) -> str:
    rows = fp.get(key, []) if isinstance(fp, dict) else []
    if not rows or not isinstance(rows[0], dict) or float(rows[0].get("share", 0.0) or 0.0) < minimum_share:
        return ""
    return str(rows[0].get("hash") or "")


def audit_prose(text: str, *, habit_history: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    raw = str(text or "")
    paras = _paras(raw)
    sents = _sentences(raw)
    fingerprint = prose_fingerprint(raw)
    findings: list[dict[str, Any]] = []

    if len(paras) >= 6:
        sigs = Counter(_para_signature(p) for p in paras)
        sig, count = sigs.most_common(1)[0]
        if count >= 4 and count / len(paras) >= .35:
            findings.append({
                "family": "paragraph_template_reuse",
                "severity": "high" if count / len(paras) >= .55 else "medium",
                "evidence": {"repeated_signature": repr(sig), "count": count, "paragraphs": len(paras)},
                "repair_question": "서로 다른 장면 기능인데도 같은 문단 골격으로 닫히는가? 기능이 다른 문단만 구조를 바꾼다.",
            })

    tails = [k for p in paras if (k := _tail_key(p))]
    repeated_tails = [(k, n) for k, n in Counter(tails).most_common() if n >= 3 and len(k) >= 4]
    generic_closures = [p for p in paras if _GENERIC_CLOSURE.search(_sentences(p)[-1] if _sentences(p) else "")]
    if repeated_tails or (len(paras) >= 6 and len(generic_closures) / len(paras) >= .3):
        findings.append({
            "family": "closure_repetition",
            "severity": "high" if repeated_tails and repeated_tails[0][1] >= 4 else "medium",
            "evidence": {"repeated_tail_keys": repeated_tails[:5], "generic_closure_count": len(generic_closures)},
            "repair_question": "장면·문단이 같은 종류의 총평이나 의미 부여로 닫히는가? 실제 다음 행동/잔여 감정/물리적 상태가 다른 경우 종료 방식을 분기한다.",
        })

    closure_modes = Counter(_closure_mode(p) for p in paras)
    reflective = closure_modes.get("reflective_summary", 0)
    if len(paras) >= 6 and reflective >= 3 and reflective / len(paras) >= .35:
        findings.append({
            "family": "semantic_closure_monoculture",
            "severity": "high" if reflective / len(paras) >= .6 else "medium",
            "evidence": {"reflective_summary_closures": reflective, "paragraphs": len(paras), "share": round(reflective / len(paras), 3)},
            "repair_question": "표현은 달라도 문단이 반복해서 ‘의미를 해설하고 닫는’ 기능으로 끝나는가? 실제 행동·공간 변화·오해·미완성 반응이 남는 문단까지 총평으로 봉합하지 않는다.",
        })

    role_sequences = _role_sequence_hashes(paras)
    if role_sequences:
        seq, count = role_sequences.most_common(1)[0]
        total = max(1, len(paras) - 2)
        if count >= 2 and count / total >= .4:
            findings.append({
                "family": "paragraph_role_loop",
                "severity": "medium",
                "evidence": {"sequence_hash": seq, "count": count, "windows": total, "share": round(count / total, 3)},
                "repair_question": "대사→행동→해설처럼 서로 다른 내용이 같은 문단 역할 순서에 반복 투입되는가? 장면의 실제 원인·반응 순서가 다르면 문단 기능 배열도 다시 설계한다.",
            })

    dialogue_explanations = 0
    for idx, p in enumerate(paras[:-1]):
        if p.startswith(_QUOTE_START) and _EXPLAIN.search(paras[idx + 1]):
            dialogue_explanations += 1
    if dialogue_explanations >= 2:
        findings.append({
            "family": "explain_after_evidence",
            "severity": "medium",
            "evidence": {"dialogue_followed_by_explicit_explanation": dialogue_explanations},
            "repair_question": "대사나 행동이 이미 전달한 의미를 다음 문단이 다시 번역하는가? 새 판단·오해·결과가 없는 설명만 줄인다.",
        })

    if len(sents) >= 14:
        sent_cv = _cv([len(s) for s in sents])
        para_cv = _cv([len(p) for p in paras]) if len(paras) >= 5 else 1.0
        endings = Counter(_ending_class(s) for s in sents)
        dominant = endings.most_common(1)[0][1] / len(sents)
        if sent_cv < .28 and para_cv < .35 and dominant > .7:
            findings.append({
                "family": "cadence_variance_collapse",
                "severity": "medium",
                "evidence": {"sentence_length_cv": round(sent_cv, 3), "paragraph_length_cv": round(para_cv, 3), "dominant_ending_share": round(dominant, 3)},
                "repair_question": "인물의 사고·행동 압력이 다른데 문장과 문단의 힘이 같은가? 필요한 지점만 길이·종결·호흡을 달리한다.",
            })

    # Repeated connective openings are a stronger habit signal than any one word.
    openings = []
    for s in sents:
        ws = re.findall(r"[가-힣A-Za-z]+", s)
        if ws:
            openings.append(" ".join(ws[:2]).casefold())
    if len(openings) >= 12:
        key, count = Counter(openings).most_common(1)[0]
        if count >= 4 and count / len(openings) >= .25:
            findings.append({
                "family": "sentence_opening_reuse",
                "severity": "low" if count < 6 else "medium",
                "evidence": {"opening": key, "count": count, "sentences": len(openings)},
                "repair_question": "같은 접속·주어 시작이 사고 순서를 자동화하고 있는가? 실제 관찰 주체와 정보 순서가 다른 문장만 재배치한다.",
            })

    # Detect a body-part proxy becoming the default carrier for unrelated emotions.
    proxy_counts = {name: len(rx.findall(raw)) for name, rx in _BODY_PROXY.items()}
    proxy_total = sum(proxy_counts.values())
    if proxy_total >= 14:
        name, count = max(proxy_counts.items(), key=lambda item: item[1])
        share = count / proxy_total
        if share >= .58:
            findings.append({
                "family": "body_proxy_monoculture",
                "severity": "low" if share < .7 else "medium",
                "evidence": {"dominant_family": name, "count": count, "total_proxy_mentions": proxy_total, "share": round(share, 3)},
                "repair_question": "서로 다른 감정·행동인데 같은 신체 부위가 자동 대리물로 호출되는가? 장면 인과상 필요한 묘사는 보존하고 기능 없는 반복만 바꾼다.",
            })

    similes = _SIMILE.findall(raw)
    if len(similes) >= 7:
        frames = ["마치" if x.strip().startswith("마치") else ("처럼" if "처럼" in x else "듯") for x in similes]
        frame, count = Counter(frames).most_common(1)[0]
        if count / len(frames) >= .72:
            findings.append({
                "family": "simile_frame_reuse",
                "severity": "low" if len(similes) < 12 else "medium",
                "evidence": {"dominant_frame": frame, "count": count, "similes": len(similes), "share": round(count / len(frames), 3)},
                "repair_question": "비유의 대상이 달라도 매번 같은 문법 프레임으로 생성되는가? 실제 인물의 관찰 방식이 다른 지점만 구조를 바꾼다.",
            })

    # Dialogue/prose echo: the narration immediately paraphrases what dialogue already delivered.
    echoes = []
    for idx, p in enumerate(paras[:-1]):
        nxt = paras[idx + 1]
        if _dialogue_paragraph(p) and not _dialogue_paragraph(nxt) and _COGNITIVE.search(nxt):
            overlap = _jaccard(p, nxt)
            if overlap >= .34:
                echoes.append({"paragraph": idx + 1, "overlap": round(overlap, 3)})
    if len(echoes) >= 2:
        findings.append({
            "family": "dialogue_semantic_echo",
            "severity": "medium",
            "evidence": {"instances": echoes[:8]},
            "repair_question": "대사 직후 서술이 같은 내용을 다시 해석해 주는가? 새 오해·판단·결과가 없는 중복만 줄인다.",
        })

    dialogue_lengths = [len(p) for p in paras if _dialogue_paragraph(p)]
    if len(dialogue_lengths) >= 10:
        dcv = _cv(dialogue_lengths)
        if dcv < .24:
            findings.append({
                "family": "dialogue_turn_uniformity",
                "severity": "low",
                "evidence": {"dialogue_paragraphs": len(dialogue_lengths), "length_cv": round(dcv, 3)},
                "repair_question": "인물들의 필요와 감정 압력이 다른데도 발화 길이가 기계적으로 비슷한가? 성격이 아니라 장면 기능이 다른 대화만 조정한다.",
            })

    history = [row for row in (habit_history or []) if isinstance(row, dict) and isinstance(row.get("fingerprint"), dict)]
    current_sig = _dominant_hash(fingerprint, "top_paragraph_signature_hashes", .30)
    current_tail = _dominant_hash(fingerprint, "top_closure_tail_hashes", .25)
    current_open = _dominant_hash(fingerprint, "top_opening_hashes", .20)
    matches = {"paragraph_signature": [], "closure_tail": [], "sentence_opening": []}
    for row in history[-24:]:
        fp = row["fingerprint"]
        scene_id = str(row.get("scene_id") or row.get("id") or "unknown")
        if current_sig and _dominant_hash(fp, "top_paragraph_signature_hashes", .30) == current_sig:
            matches["paragraph_signature"].append(scene_id)
        if current_tail and _dominant_hash(fp, "top_closure_tail_hashes", .25) == current_tail:
            matches["closure_tail"].append(scene_id)
        if current_open and _dominant_hash(fp, "top_opening_hashes", .20) == current_open:
            matches["sentence_opening"].append(scene_id)
    max_match = max((len(v) for v in matches.values()), default=0)
    matched_dimensions = [name for name, rows in matches.items() if len(rows) >= 3]
    if matched_dimensions:
        findings.append({
            "family": "cross_scene_template_recurrence",
            "severity": "high" if max_match >= 4 or len(matched_dimensions) >= 2 else "medium",
            "evidence": {"matching_dimensions": matched_dimensions, "matching_scenes": matches, "history_size": len(history)},
            "repair_question": "다른 장면인데도 이전 장면들과 같은 문단/종결/도입 골격으로 자동 회귀하는가? 기능이 실제로 같은 반복은 보존하고, 그렇지 않은 장면만 선택 순서 자체를 바꾼다.",
        })

    return {
        "schema": SCHEMA,
        "legacy_diagnostics_used": False,
        "ai_authorship_inference": "NOT_ATTEMPTED",
        "literary_quality_verdict": "NOT_ESTABLISHED",
        "findings": findings,
        "fingerprint": fingerprint,
        "stats": {
            "characters": len(raw),
            "paragraphs": len(paras),
            "sentences": len(sents),
            "finding_count": len(findings),
            "habit_history_rows": len(history),
        },
        "policy": "Repair only located recurring habits that conflict with scene/character intent. Do not optimize for detector scores or impose word/punctuation quotas.",
    }
