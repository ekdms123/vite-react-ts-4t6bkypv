from __future__ import annotations

"""Lossless, linear-time sentence/newline source segmentation.

The earlier end-anchored regex used ``(?:punctuation+|$)`` after a greedy
non-punctuation run.  On long clauses followed by punctuation this can trigger
large backtracking costs in Python's regex engine.  This helper preserves the
same visible-boundary behavior without the end-anchor alternation and is shared
by authority/goal/representation paths so they do not drift independently.
"""

import re

_SEGMENT_RE = re.compile(r"[^\n.!?。！？]+[.!?。！？]*|\n+")


def trimmed_source_spans(text: str) -> tuple[tuple[int, int], ...]:
    exact = str(text)
    rows: list[tuple[int, int]] = []
    for match in _SEGMENT_RE.finditer(exact):
        raw = match.group(0)
        stripped = raw.strip()
        if not stripped:
            continue
        left = len(raw) - len(raw.lstrip())
        start = match.start() + left
        end = start + len(stripped)
        rows.append((start, end))
    if not rows and exact:
        rows.append((0, len(exact)))
    return tuple(rows)
