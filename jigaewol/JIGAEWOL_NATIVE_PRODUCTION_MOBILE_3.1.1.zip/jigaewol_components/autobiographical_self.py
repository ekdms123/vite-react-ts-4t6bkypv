from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class SelfEpisode:
    episode_id: str
    objective: str
    action: str
    outcome: str
    success: bool
    evidence: tuple[str, ...]
    architecture_generation: int | None
    body_ids: tuple[str, ...]
    capabilities: tuple[str, ...]
    lesson: str
    created_at: float
    facets: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SelfPrediction:
    prediction_id: str
    claim: str
    confidence: float
    created_at: float
    resolved: bool = False
    actual: str | None = None
    score: float | None = None


class AutobiographicalSelf:
    """Durable functional-self continuity across replaceable models and bodies.

    It records what the system attempted, what reality returned, architecture ancestry,
    predictions, calibration, and lessons. Identity is derived from continuity of history,
    not from a particular model process.
    """

    def __init__(self, path: Path, *, identity_id: str = "JIGAEWOL") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.identity_id = str(identity_id)
        if not self.path.exists():
            self._write({"identity_id": self.identity_id, "episodes": [], "predictions": [], "architecture_lineage": []})

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def record_episode(self, *, objective: str, action: str, outcome: str, success: bool,
                       evidence: tuple[str, ...] = (), architecture_generation: int | None = None,
                       body_ids: tuple[str, ...] = (), capabilities: tuple[str, ...] = (),
                       lesson: str = "", facets: dict[str, Any] | None = None) -> SelfEpisode:
        row = SelfEpisode(
            episode_id=f"episode_{uuid.uuid4().hex[:16]}", objective=str(objective), action=str(action),
            outcome=str(outcome), success=bool(success), evidence=tuple(evidence),
            architecture_generation=architecture_generation, body_ids=tuple(body_ids),
            capabilities=tuple(capabilities), lesson=str(lesson), created_at=time.time(),
            facets=dict(facets or {}),
        )
        data=self._read(); data.setdefault("episodes", []).append(asdict(row)); self._write(data); return row

    def predict(self, claim: str, confidence: float) -> SelfPrediction:
        row=SelfPrediction(f"prediction_{uuid.uuid4().hex[:16]}", str(claim), max(0.0,min(1.0,float(confidence))), time.time())
        data=self._read(); data.setdefault("predictions", []).append(asdict(row)); self._write(data); return row

    def resolve_prediction(self, prediction_id: str, *, actual: str, score: float) -> SelfPrediction:
        data=self._read()
        for i,row in enumerate(data.setdefault("predictions", [])):
            if row["prediction_id"] == prediction_id:
                updated={**row,"resolved":True,"actual":str(actual),"score":float(score)}
                data["predictions"][i]=updated; self._write(data); return SelfPrediction(**updated)
        raise KeyError(prediction_id)

    def record_architecture_transition(self, *, from_generation: int, to_generation: int,
                                       trigger: str, selected_world: str | None = None,
                                       evidence: tuple[str, ...] = ()) -> None:
        data=self._read(); data.setdefault("architecture_lineage", []).append({
            "from_generation": int(from_generation), "to_generation": int(to_generation),
            "trigger": str(trigger), "selected_world": selected_world,
            "evidence": list(evidence), "created_at": time.time(),
        }); self._write(data)

    def continuity_digest(self) -> str:
        data=self._read()
        normalized={"identity_id":data.get("identity_id"),"episodes":data.get("episodes",[]),
                    "architecture_lineage":data.get("architecture_lineage",[])}
        return hashlib.sha256(json.dumps(normalized, sort_keys=True, default=str).encode()).hexdigest()

    def summary(self) -> dict[str, Any]:
        data=self._read(); episodes=data.get("episodes",[]); preds=data.get("predictions",[])
        resolved=[x for x in preds if x.get("resolved")]
        return {
            "identity_id": data.get("identity_id", self.identity_id),
            "episodes": len(episodes), "successful_episodes": sum(bool(x.get("success")) for x in episodes),
            "architecture_transitions": len(data.get("architecture_lineage",[])),
            "predictions": len(preds), "resolved_predictions": len(resolved),
            "continuity_digest": self.continuity_digest(),
            "recent_lessons": [x.get("lesson","") for x in episodes[-8:] if x.get("lesson")],
        }
