from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class GoalAnchor:
    goal_sha256: str
    exact_goal: str
    non_downgrade: bool
    route_failure_is_goal_failure: bool
    generated_subgoals_may_replace_goal: bool
    representation_may_change_while_intent_is_preserved: bool = True
    project_goal: str = ""
    project_goal_sha256: str = ""
    current_goal: str = ""
    effective_current_goal: str = ""
    effective_current_goal_sha256: str = ""


@dataclass(frozen=True)
class RouteAttempt:
    route_id: str
    state: str
    reason: str = ""
    preserves_goal: bool = True


class AmbitionPreserver:
    """Keeps the user's goal stable while allowing routes to fail and mutate."""

    @staticmethod
    def anchor(user_command: str, *, project_goal: str = "", effective_current_goal: str | None = None) -> GoalAnchor:
        exact = str(user_command).strip()
        effective = str(effective_current_goal if effective_current_goal is not None else exact).strip()
        project = str(project_goal or "").strip()
        combined = project + ("\n\nCURRENT TURN:\n" + exact if project else exact)
        return GoalAnchor(
            goal_sha256=hashlib.sha256(combined.encode("utf-8")).hexdigest(),
            exact_goal=exact,
            non_downgrade=True,
            route_failure_is_goal_failure=False,
            generated_subgoals_may_replace_goal=False,
            representation_may_change_while_intent_is_preserved=True,
            project_goal=project,
            project_goal_sha256=(hashlib.sha256(project.encode("utf-8")).hexdigest() if project else ""),
            current_goal=exact,
            effective_current_goal=effective,
            effective_current_goal_sha256=hashlib.sha256(effective.encode("utf-8")).hexdigest() if effective else "",
        )

    @staticmethod
    def bind_facets(facets: Mapping[str, Any] | None, anchor: GoalAnchor) -> dict[str, Any]:
        out = dict(facets or {})
        out["goal_anchor"] = asdict(anchor)
        out["goal_immutability"] = {
            "route_failure_preserves_goal": True,
            "unknown_route_preserves_goal": True,
            "subgoal_is_route_scoped_not_goal_replacement": True,
            "goal_replacement_requires_explicit_user_instruction": True,
            "goal_representation_is_revisable": True,
            "exact_wording_is_evidence_not_the_only_valid_goal_representation": True,
        }
        return out

    @staticmethod
    def validate_routes(anchor: GoalAnchor, routes: Iterable[Mapping[str, Any]]) -> tuple[bool, tuple[str, ...]]:
        findings: list[str] = []
        for index, route in enumerate(routes):
            if route.get("preserves_goal") is False:
                findings.append(f"route_{index}_shrinks_goal")
            replacement = str(route.get("replacement_goal") or "").strip()
            # Rewording/re-representation is allowed. Only an explicit route admission
            # that it shrinks or abandons user intent is a goal replacement failure.
            if replacement and route.get("replacement_preserves_intent") is False:
                findings.append(f"route_{index}_replaces_goal")
        return not findings, tuple(findings)
