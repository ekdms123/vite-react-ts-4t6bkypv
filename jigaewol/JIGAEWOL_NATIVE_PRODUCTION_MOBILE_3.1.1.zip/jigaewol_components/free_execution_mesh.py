"""Content-addressed offline work and admission through existing host authority.

Offline work remains local. Connected tool calls keep the host's actual permissions
and cost observations; this module never opens accounts or enables new billing.
"""
from __future__ import annotations
import hashlib
from contextlib import contextmanager
import json
import sqlite3
import time
from pathlib import Path
from typing import Any

FREE_HOST_EXACT = frozenset({
    'skills__list', 'skills__read',
    'mcp__Plugin_Management__search_plugins',
    'mcp__GitHub__get_repo',
    'mcp__GitHub__get_user_login',
    'mcp__GitHub__search_repositories',
    'mcp__GitHub__search_issues',
    'mcp__GitHub__search',
    'mcp__GitHub__fetch_file',
    'mcp__GitHub__list_repositories',
    'mcp__Context7__resolve_library_id',
    'mcp__Context7__query_docs',
})
# Historical route hints remain import-compatible; they are not an admission list.
FREE_HOST_PREFIXES=('files__search', 'files__read', 'files__find', 'files__list')

# Historical billing hints are not current host billing observations.
METERED_OR_UNKNOWN_PREFIXES=(
    'mcp__Firecrawl__','mcp__Exa__','mcp__TinyFish__',
    'mcp__Tavily__','mcp__Parallel_Search__',
    'mcp__Manus__','mcp__DigitalOcean__','mcp__Railway__',
    'mcp__Vercel__','mcp__Render__','mcp__Neon__',
)


def cost_admission(tool: str, *, zero_spend: bool=True,
                   host_available: bool | None=None,
                   metadata: dict[str, Any] | None=None) -> dict[str, Any]:
    """Use existing host authority without starting a new billing relationship.

    Availability and effect authorization are checked by the host dispatcher.
    Unknown price is recorded rather than turned into a private tool blacklist.
    ``None`` availability defers resolution to the live host, not to a made-up
    free tier. This never configures API keys, buys credits, or enables billing.
    """
    info = dict(metadata or {})
    if any(info.get(key) is True for key in (
            'requires_billing_activation', 'requires_credit_purchase',
            'requires_new_paid_service', 'requires_new_connection')):
        return {'allowed': False, 'class': 'new_account_or_spend_effect',
                'reason': 'new connection or billing activation is outside an existing host call'}
    if host_available is False:
        return {'allowed': False, 'class': 'host_tool_unavailable',
                'reason': 'tool is absent from the current host inventory'}
    zero = info.get('zero_incremental_cost')
    observed_zero=(zero is True or (info.get('incremental_spend_usd')==0 and not isinstance(info.get('incremental_spend_usd'),bool))
                   or info.get('billing_mode') in {'included','local_included','free_public'})
    return {'allowed': True,
            'execution_allowed':bool(observed_zero or not zero_spend),
            'discovery_allowed':True,
            'reason':'observed_zero_cost_route' if observed_zero else 'observe_cost_or_select_another_zero_cost_route',
            'class': 'connected_host_managed_cost' if host_available is True else 'resolve_at_live_host',
            'zero_incremental_cost': zero if isinstance(zero, bool) else None,
            'cost_status': 'observed' if isinstance(zero, bool) else 'not_reported_by_host',
            'host_presence_required': True,
            'new_spend_enabled': False,
            'host_permissions_and_existing_user_authority_apply': True}


def route_fallback(lane: str, args: dict[str,Any]) -> dict[str,Any]|None:
    # Alternatives preserve the original blocked lane in a durable deferred ledger.
    if lane == 'community':
        return {'tool':'mcp__GitHub__search_issues',
                'args':{'query':str(args.get('query', '')),'topn':12,'sort':'updated'},
                'scope':'public GitHub community/issues only; not a Reddit replacement'}
    if lane == 'web_discovery':
        return {'tool':'mcp__GitHub__search_repositories',
                'args':{'query':str(args.get('query', '')),'per_page':12,'page':1},
                'scope':'GitHub OSS discovery only; not a general-web replacement'}
    return None


def _canon(v: Any)->bytes:
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')


class FreeExecutionMesh:
    """Durable, offline, free compute lane. No account or API key is ever required.

    Each job uses a content digest as its identity; repeated submissions reuse the
    prior successful result. SQLite transaction log provides checkpoints between turns.
    """
    def __init__(self, root: str|Path):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.db_path=self.root/'offline_jobs.sqlite3'
        with self._db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS jobs (
              key TEXT PRIMARY KEY,kind TEXT NOT NULL,payload TEXT NOT NULL,
              state TEXT NOT NULL,result TEXT,error TEXT,attempts INTEGER DEFAULT 0,
              created REAL NOT NULL,updated REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS documents (
              digest TEXT PRIMARY KEY,origin TEXT,body TEXT NOT NULL,created REAL NOT NULL);
            CREATE VIRTUAL TABLE IF NOT EXISTS docs_fts USING fts5(digest UNINDEXED,body,tokenize='unicode61');
            ''')

    @contextmanager
    def _db(self):
        con=sqlite3.connect(self.db_path, timeout=30)
        try:
            con.execute('PRAGMA journal_mode=WAL')
            con.execute('PRAGMA busy_timeout=30000')
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    def submit(self,kind:str,payload:dict[str,Any])->dict:
        if kind not in {'sha256','json_extract','index_text','search_text','compare','query_mutations'}:
            raise ValueError('unsupported offline task; never execute arbitrary third-party code here')
        key=hashlib.sha256(_canon({'kind':kind,'payload':payload})).hexdigest()
        now=time.time()
        with self._db() as db:
            db.execute('INSERT OR IGNORE INTO jobs(key,kind,payload,state,created,updated) VALUES (?,?,?,?,?,?)',
                       (key,kind,_canon(payload).decode(),'pending',now,now))
            row=db.execute('SELECT state,result FROM jobs WHERE key=?',(key,)).fetchone()
        return {'key':key,'kind':kind,'state':row[0],'cache_hit':row[0]=='succeeded','result':json.loads(row[1]) if row[1] else None}

    def _execute(self,kind:str,p:dict)->dict:
        if kind=='sha256':
            raw=str(p['text']).encode('utf-8')
            return {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
        if kind=='json_extract':
            item=p['document']
            for part in p.get('path',[]):
                item=item[part]
            return {'value':item}
        if kind=='compare':
            a,b=p['first'],p['second']
            return {'equal':a==b,'first_sha256':hashlib.sha256(_canon(a)).hexdigest(),
                    'second_sha256':hashlib.sha256(_canon(b)).hexdigest()}
        if kind=='index_text':
            body=str(p['text']); origin=str(p.get('origin',''))
            digest=hashlib.sha256(body.encode()).hexdigest()
            with self._db() as db:
                db.execute('INSERT OR IGNORE INTO documents VALUES (?,?,?,?)',(digest,origin,body,time.time()))
                if not db.execute('SELECT 1 FROM docs_fts WHERE digest=?',(digest,)).fetchone():
                    db.execute('INSERT INTO docs_fts(digest,body) VALUES (?,?)',(digest,body))
            return {'document_sha256':digest,'characters':len(body),'origin':origin}
        if kind=='search_text':
            raw=str(p['query']).strip()
            # FTS query generated only from alphanumeric tokens; no SQL fragments.
            import re
            terms=re.findall(r'[^\W_]+',raw,flags=re.UNICODE)[:12]
            if not terms: return {'items':[],'query':raw}
            match=' OR '.join('"'+t.replace('"','')+'"' for t in terms)
            with self._db() as db:
                rows=db.execute('SELECT digest,substr(body,1,400) FROM docs_fts WHERE docs_fts MATCH ? ORDER BY rank LIMIT ?',
                                (match,min(100,int(p.get('limit',20))))).fetchall()
            return {'query':raw,'items':[{'sha256':s,'excerpt':b} for s,b in rows]}
        if kind=='query_mutations':
            term=str(p['subject']).strip()
            # Deliberately heterogeneous trajectories rather than a single translated query.
            langs=[('ko',['후기','직접 써봄','숨은 꿀팁','단점']),('en',['actually using','underrated','show your workflow','gotchas']),
                   ('ja',['使ってみた','神ツール','実測','注意点']),('zh',['实测','避坑','开源','工作流'])]
            return {'subject':term,'families':[
                {'language':l,'queries':[f'{term} {w}' for w in ws]} for l,ws in langs],
                'source_hops':['creator -> projects','comments -> evidence','issue -> fix','fork -> novel use']}
        raise RuntimeError('unknown task')

    def drain(self,limit:int|None=None)->dict:
        # No artificial lifetime credit cap; limit merely controls this invocation.
        done=[];n=0
        while limit is None or n<limit:
            with self._db() as db:
                db.execute('BEGIN IMMEDIATE')
                row=db.execute("SELECT key,kind,payload FROM jobs WHERE state='pending' ORDER BY created,key LIMIT 1").fetchone()
                if not row:
                    db.commit();break
                key,kind,payload=row
                db.execute("UPDATE jobs SET state='running',attempts=attempts+1,updated=? WHERE key=?",(time.time(),key))
                db.commit()
            try:
                result=self._execute(kind,json.loads(payload))
                with self._db() as db:
                    db.execute("UPDATE jobs SET state='succeeded',result=?,error=NULL,updated=? WHERE key=?",
                               (_canon(result).decode(),time.time(),key))
                done.append({'key':key,'state':'succeeded','result':result})
            except Exception as exc:
                with self._db() as db:
                    db.execute("UPDATE jobs SET state='failed',error=?,updated=? WHERE key=?",
                               (type(exc).__name__+': '+str(exc),time.time(),key))
                done.append({'key':key,'state':'failed','error':type(exc).__name__+': '+str(exc)})
            n+=1
        return {'processed':len(done),'results':done,'status':self.status()}

    def recover(self):
        with self._db() as db:
            cur=db.execute("UPDATE jobs SET state='pending',updated=? WHERE state='running'",(time.time(),))
        return {'requeued_interrupted':cur.rowcount}

    def status(self):
        with self._db() as db:
            rows=db.execute('SELECT state,count(*) FROM jobs GROUP BY state').fetchall()
            docs=db.execute('SELECT count(*) FROM documents').fetchone()[0]
        return {'jobs':dict(rows),'documents':docs,'incremental_external_spend_usd':0,
                'unlimited_work_claim':False,'repeatable_until_local_resources_exhausted':True}
