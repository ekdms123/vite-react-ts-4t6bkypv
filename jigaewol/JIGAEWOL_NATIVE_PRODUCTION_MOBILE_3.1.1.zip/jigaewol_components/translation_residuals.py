from __future__ import annotations

"""Turn translation loss into a generated mediator with its own representation.

The mediator is not required to be reducible to either endpoint representation.  Its
observable contract is the input/output relation plus the distinctions it preserves;
its internal residual representation is a third space born from the round-trip loss.
"""

from dataclasses import dataclass, asdict
from typing import Any, Callable, Iterable, Mapping
import hashlib, json


@dataclass(frozen=True, slots=True)
class TranslationResidual:
    source: Any
    roundtrip: Any
    behavioral_difference: tuple[Any, ...]
    source_probe_vector: tuple[Any, ...] = ()
    roundtrip_probe_vector: tuple[Any, ...] = ()
    lost_dimensions: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class MediatorProposal:
    residual_channel: str
    retained_examples: tuple[Any, ...]
    reason: str
    mediator_id: str = ""
    input_contract: Mapping[str, Any] = None
    output_contract: Mapping[str, Any] = None
    internal_representation: Mapping[str, Any] = None
    executable_spec: Mapping[str, Any] = None
    opacity_contract: Mapping[str, Any] = None

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class TranslationResidualMiner:
    def inspect(
        self,
        values: Iterable[Any],
        encode: Callable[[Any], Any],
        decode: Callable[[Any], Any],
        probes: Iterable[Callable[[Any], Any]],
    ) -> tuple[TranslationResidual, ...]:
        ps = tuple(probes)
        out = []
        for value in values:
            rt = decode(encode(value))
            source_vec = tuple(p(value) for p in ps)
            roundtrip_vec = tuple(p(rt) for p in ps)
            diffs = tuple((i, before, after) for i, (before, after) in enumerate(zip(source_vec, roundtrip_vec)) if before != after)
            if diffs:
                out.append(TranslationResidual(
                    value,
                    rt,
                    diffs,
                    source_vec,
                    roundtrip_vec,
                    tuple(f"probe:{i}" for i, *_ in diffs),
                ))
        return tuple(out)

    def propose_mediator(self, residuals: Iterable[TranslationResidual]) -> MediatorProposal | None:
        rows = tuple(residuals)
        if not rows:
            return None
        seed_payload = [
            {
                "difference": row.behavioral_difference,
                "lost_dimensions": row.lost_dimensions,
            }
            for row in rows
        ]
        digest = hashlib.sha256(json.dumps(seed_payload, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()
        dimensions = tuple(dict.fromkeys(dim for row in rows for dim in row.lost_dimensions))
        channel = "semantic_residue_" + digest[:12]
        return MediatorProposal(
            channel,
            tuple(row.behavioral_difference for row in rows),
            "roundtrip erased distinctions that change downstream behavior; birth a third representation instead of flattening either endpoint",
            mediator_id="mediator_" + digest[:20],
            input_contract={
                "accepts": "source representation plus source-side probe vector",
                "captures": dimensions,
            },
            output_contract={
                "produces": "target representation plus residual channel",
                "must_preserve": dimensions,
            },
            internal_representation={
                "kind": "born_residual_space",
                "dimensions": dimensions,
                "not_required_to_be_reducible_to_source_or_target": True,
                "state_token": channel,
            },
            executable_spec={
                "kind": "residual_mediator",
                "residual_channel": channel,
                "retained_dimensions": dimensions,
                "roundtrip_examples": tuple(seed_payload),
            },
            opacity_contract={
                "observable_surface": "input_output_relation_and_preserved_distinctions",
                "internal_representation_is_third_space": True,
                "full_reduction_to_endpoint_A_or_B_required": False,
            },
        )
