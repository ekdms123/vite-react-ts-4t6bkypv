from __future__ import annotations

import copy
import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable


@dataclass(frozen=True)
class BranchSnapshot:
    branch_id: str
    version: int
    generation: int
    payload: dict[str, Any]
    parent_ids: tuple[str, ...] = ()
    created_at: float = 0.0


@dataclass(frozen=True)
class MergeEvidence:
    merge_id: str
    target_branch: str
    source_branches: tuple[str, ...]
    policy_id: str
    before_versions: dict[str, int]
    after_version: int
    evidence: tuple[str, ...] = ()
    created_at: float = 0.0


MergePolicy = Callable[[BranchSnapshot, tuple[BranchSnapshot, ...], dict[str, Any]], dict[str, Any]]


class BranchConflict(RuntimeError):
    pass


class BranchingStateStore:
    """Persistent runtime state that can fork, evolve independently, and merge.

    A single CAS state is not treated as the universe. Cognitive worlds can own
    independent branches and only merge after an explicit, replaceable merge policy
    sees their reality evidence.
    """

    def __init__(self, path: Path, *, initial: dict[str, Any] | None = None) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._merge_policies: dict[str, MergePolicy] = {}
        self.register_merge_policy("overlay", self._overlay_merge)
        if not self.path.exists():
            now = time.time()
            self._write({
                "branches": {
                    "main": {
                        "branch_id": "main",
                        "version": 0,
                        "generation": 0,
                        "payload": copy.deepcopy(initial or {}),
                        "parent_ids": [],
                        "created_at": now,
                        "events": [],
                    }
                },
                "merges": [],
            })

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def register_merge_policy(self, policy_id: str, policy: MergePolicy) -> None:
        self._merge_policies[str(policy_id)] = policy

    def merge_policy_ids(self) -> tuple[str, ...]:
        return tuple(sorted(self._merge_policies))

    @staticmethod
    def _snapshot(raw: dict[str, Any]) -> BranchSnapshot:
        return BranchSnapshot(
            branch_id=str(raw["branch_id"]),
            version=int(raw["version"]),
            generation=int(raw.get("generation", 0)),
            payload=copy.deepcopy(raw["payload"] if "payload" in raw else {}),
            parent_ids=tuple(str(x) for x in raw.get("parent_ids", ())),
            created_at=float(raw.get("created_at", 0.0)),
        )

    def snapshot(self, branch_id: str = "main") -> BranchSnapshot:
        raw = self._read().get("branches", {}).get(str(branch_id))
        if raw is None:
            raise KeyError(branch_id)
        return self._snapshot(raw)

    def branches(self) -> tuple[BranchSnapshot, ...]:
        data = self._read().get("branches", {})
        return tuple(self._snapshot(data[k]) for k in sorted(data))

    def fork(self, parent_branch: str = "main", *, branch_id: str | None = None,
             generation: int | None = None, facets: dict[str, Any] | None = None) -> BranchSnapshot:
        data = self._read()
        parent = data.get("branches", {}).get(str(parent_branch))
        if parent is None:
            raise KeyError(parent_branch)
        new_id = str(branch_id or f"branch_{uuid.uuid4().hex[:12]}")
        if new_id in data["branches"]:
            raise ValueError(f"branch already exists: {new_id}")
        now = time.time()
        payload = copy.deepcopy(parent["payload"] if "payload" in parent else {})
        if facets:
            payload.setdefault("branch_facets", {}).update(copy.deepcopy(facets))
        raw = {
            "branch_id": new_id,
            "version": 0,
            "generation": int(parent.get("generation", 0) if generation is None else generation),
            "payload": payload,
            "parent_ids": [str(parent_branch)],
            "created_at": now,
            "events": [{"kind": "fork", "from": str(parent_branch), "created_at": now}],
        }
        data["branches"][new_id] = raw
        self._write(data)
        return self._snapshot(raw)

    def commit(self, branch_id: str, *, expected_version: int, payload: dict[str, Any],
               generation: int | None = None, event: dict[str, Any] | None = None) -> BranchSnapshot:
        data = self._read()
        raw = data.get("branches", {}).get(str(branch_id))
        if raw is None:
            raise KeyError(branch_id)
        current = int(raw.get("version", 0))
        if current != int(expected_version):
            raise BranchConflict(f"branch {branch_id} version changed: expected={expected_version} current={current}")
        raw["version"] = current + 1
        raw["payload"] = copy.deepcopy(payload)
        if generation is not None:
            raw["generation"] = int(generation)
        if event is not None:
            row = copy.deepcopy(event)
            row.setdefault("branch_id", str(branch_id))
            row.setdefault("version", raw["version"])
            row.setdefault("created_at", time.time())
            raw.setdefault("events", []).append(row)
        self._write(data)
        return self._snapshot(raw)

    def merge(self, target_branch: str, source_branches: Iterable[str], *,
              policy_id: str, context: dict[str, Any] | None = None,
              evidence: Iterable[str] = ()) -> tuple[BranchSnapshot, MergeEvidence]:
        target = self.snapshot(target_branch)
        sources = tuple(self.snapshot(x) for x in source_branches if str(x) != str(target_branch))
        if not sources:
            raise ValueError("merge requires at least one distinct source branch")
        policy = self._merge_policies[str(policy_id)]
        merged_payload = policy(target, sources, copy.deepcopy(context or {}))
        generation = max((target.generation, *(x.generation for x in sources)))
        after = self.commit(
            target_branch,
            expected_version=target.version,
            payload=merged_payload,
            generation=generation,
            event={"kind": "merge", "sources": [x.branch_id for x in sources], "policy_id": str(policy_id)},
        )
        row = MergeEvidence(
            merge_id=f"merge_{uuid.uuid4().hex[:16]}",
            target_branch=str(target_branch),
            source_branches=tuple(x.branch_id for x in sources),
            policy_id=str(policy_id),
            before_versions={target.branch_id: target.version, **{x.branch_id: x.version for x in sources}},
            after_version=after.version,
            evidence=tuple(str(x) for x in evidence),
            created_at=time.time(),
        )
        data = self._read(); data.setdefault("merges", []).append(asdict(row)); self._write(data)
        return after, row

    @staticmethod
    def _overlay_merge(target: BranchSnapshot, sources: tuple[BranchSnapshot, ...], context: dict[str, Any]) -> dict[str, Any]:
        out = copy.deepcopy(target.payload)
        for source in sources:
            for key, value in source.payload.items():
                if key not in out:
                    out[key] = copy.deepcopy(value)
                    continue
                if isinstance(out[key], dict) and isinstance(value, dict):
                    out[key].update(copy.deepcopy(value))
                elif out[key] != value:
                    out.setdefault("branch_conflicts", []).append({
                        "key": str(key), "target": copy.deepcopy(out[key]),
                        "source": copy.deepcopy(value), "source_branch": source.branch_id,
                    })
        if context:
            out.setdefault("merge_context", {}).update(copy.deepcopy(context))
        return out
