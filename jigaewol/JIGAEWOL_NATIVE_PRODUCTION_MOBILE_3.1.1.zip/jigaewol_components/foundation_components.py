from __future__ import annotations

import json
import shlex
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .browser_plane import BrowserPlane
from .capability_bus import CapabilityDescriptor, CapabilityInvocation, CapabilityComponent, CapabilityResult, UniversalCapabilityBus
from .execution_plane import ExecutionPlane, ExecutionRequest
from .image_capability import ImageInspectionComponent


class FoundationComponentBridge:
    """Register verified local execution components into the semantic capability bus."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.execution = ExecutionPlane(self.root / "execution")
        self.browser = BrowserPlane(self.root / "browser")
        self.image = ImageInspectionComponent(self.root / "image")

    @staticmethod
    def _result(inv: CapabilityInvocation, *, success: bool, output: Any = None, error: str | None = None, artifacts: tuple[str, ...] = ()) -> CapabilityResult:
        return CapabilityResult(inv.call_id, inv.capability_id, success, output, artifacts=artifacts, error=error, finished_at=time.time())

    def _process(self, inv: CapabilityInvocation) -> CapabilityResult:
        payload = inv.payload
        argv = payload.get("argv")
        if argv is None and payload.get("command"):
            argv = shlex.split(str(payload["command"]))
        if not isinstance(argv, (list, tuple)) or not argv:
            return self._result(inv, success=False, error="process execution requires non-empty argv or command")
        receipt = self.execution.run_resilient(
            ExecutionRequest(
                argv=[str(x) for x in argv],
                cwd=payload.get("cwd", "."),
                timeout_s=float(payload.get("timeout_s", 120.0)),
            ),
            persist_cwd=False,
        )
        return self._result(inv, success=receipt.exit_code == 0, output=asdict(receipt), error=None if receipt.exit_code == 0 else f"exit_code={receipt.exit_code}")

    def _file(self, inv: CapabilityInvocation) -> CapabilityResult:
        action = str(inv.payload.get("action", "read"))
        path = Path(str(inv.payload.get("path", ""))).expanduser()
        try:
            if action == "read":
                data = path.read_bytes()
                return self._result(inv, success=True, output={"path": str(path), "size": len(data), "text": data.decode(inv.payload.get("encoding", "utf-8"))})
            if action == "write":
                path.parent.mkdir(parents=True, exist_ok=True)
                text = str(inv.payload.get("text", ""))
                path.write_text(text, encoding=inv.payload.get("encoding", "utf-8"))
                return self._result(inv, success=True, output={"path": str(path), "size": path.stat().st_size}, artifacts=(str(path),))
            return self._result(inv, success=False, error=f"unsupported file action: {action}")
        except Exception as exc:
            return self._result(inv, success=False, error=f"{type(exc).__name__}: {exc}")

    def _browser(self, inv: CapabilityInvocation) -> CapabilityResult:
        try:
            if "url" in inv.payload:
                receipt = self.browser.visit(str(inv.payload["url"]), screenshot=bool(inv.payload.get("screenshot", True)), headless=bool(inv.payload.get("headless", True)))
            else:
                receipt = self.browser.render_html(str(inv.payload.get("html", "")), screenshot=bool(inv.payload.get("screenshot", False)), headless=bool(inv.payload.get("headless", True)))
            artifacts = (receipt.screenshot_path,) if receipt.screenshot_path else ()
            return self._result(inv, success=True, output=asdict(receipt), artifacts=tuple(x for x in artifacts if x))
        except Exception as exc:
            return self._result(inv, success=False, error=f"{type(exc).__name__}: {exc}")

    def _image(self, inv: CapabilityInvocation) -> CapabilityResult:
        try:
            self.image.install()
            receipt = self.execution.run_resilient(self.image.build_request(Path(str(inv.payload["path"])), ocr=bool(inv.payload.get("ocr", False))), persist_cwd=False)
            output: Any = {"receipt": asdict(receipt)}
            if receipt.stdout.strip():
                try:
                    output["inspection"] = json.loads(receipt.stdout)
                except json.JSONDecodeError:
                    output["stdout"] = receipt.stdout
            return self._result(inv, success=receipt.exit_code == 0, output=output, error=None if receipt.exit_code == 0 else receipt.stderr)
        except Exception as exc:
            return self._result(inv, success=False, error=f"{type(exc).__name__}: {exc}")

    def components(self) -> tuple[CapabilityComponent, ...]:
        return (
            CapabilityComponent(CapabilityDescriptor("foundation_process", "executor", ("process_execution", "terminal", "command_execution"), location="local", priority=1.0, metadata={"prebuilt": True}), self._process),
            CapabilityComponent(CapabilityDescriptor("foundation_files", "executor", ("filesystem", "file_read", "file_write"), location="local", priority=1.0, metadata={"prebuilt": True}), self._file),
            CapabilityComponent(CapabilityDescriptor("foundation_browser", "executor", ("browser_automation", "browser_render", "browser_perception"), location="local", priority=1.0, metadata={"prebuilt": True}), self._browser),
            CapabilityComponent(CapabilityDescriptor("foundation_image", "executor", ("image_processing", "image_inspection", "ocr"), location="local", priority=1.0, metadata={"prebuilt": True}), self._image),
        )

    def register(self, bus: UniversalCapabilityBus) -> tuple[str, ...]:
        ids = []
        for component in self.components():
            bus.register(component)
            ids.append(component.descriptor.capability_id)
        return tuple(ids)
