from __future__ import annotations

import hashlib
import importlib.util
import json
import time
from pathlib import Path
from typing import Any, Iterable, Mapping


class ExecutableMemory:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "recipes.jsonl"
        self.programs_root = self.root / "compiled_recipes"
        self.programs_root.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")

    def store_trace(self, *, program_ref: str, input_ref: str, receipt_refs: Iterable[str], result_ref: str) -> dict[str, Any]:
        receipts = tuple(receipt_refs)
        row = {
            "trace_id": "trace_" + hashlib.sha256(f"{program_ref}|{input_ref}|{receipts}|{result_ref}".encode()).hexdigest()[:20],
            "program_ref": str(program_ref), "input_ref": str(input_ref),
            "receipt_refs": tuple(map(str, receipts)), "result_ref": str(result_ref), "created_at": time.time(),
        }
        self._append(row)
        return row

    def compile_recipe(self, *, traces: Iterable[Mapping[str, Any]], operator_refs: Iterable[str]) -> dict[str, Any]:
        traces_t = tuple(dict(x) for x in traces)
        ops = tuple(map(str, operator_refs))
        recipe_id = "recipe_" + hashlib.sha256(json.dumps({"traces": traces_t, "ops": ops}, sort_keys=True, default=str).encode()).hexdigest()[:20]
        program_path = self.programs_root / f"{recipe_id}.json"
        program = {
            "kind": "replayable_execution_recipe_v2",
            "trace_refs": tuple(str(x.get("trace_id") or "") for x in traces_t),
            "program_refs": tuple(str(x.get("program_ref") or "") for x in traces_t),
            "operator_refs": ops,
            "steps": tuple({
                "program_ref": str(x.get("program_ref") or ""),
                "input_ref": str(x.get("input_ref") or ""),
                "result_ref": str(x.get("result_ref") or ""),
                "receipt_refs": tuple(map(str, x.get("receipt_refs") or ())),
            } for x in traces_t),
        }
        program_path.write_text(json.dumps(program, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        row = {
            "recipe_id": recipe_id,
            "trace_refs": program["trace_refs"],
            "operator_refs": ops,
            "program_ref": f"recipe:{program_path}",
            "executable": True,
        }
        self._append({"compiled_recipe": row, "created_at": time.time()})
        return row

    @staticmethod
    def _execute_program_ref(program_ref: str, payload: Mapping[str, Any], *, index: int) -> dict[str, Any]:
        ref = str(program_ref)
        if not ref.startswith("python:"):
            return {"program_ref": ref, "executed": False, "reason": "no_local_executor", "input": dict(payload)}
        path = Path(ref.split(":", 1)[1])
        if not path.is_file():
            return {"program_ref": ref, "executed": False, "reason": "program_missing", "input": dict(payload)}
        module_name = f"_jigaewol_recipe_{index}_{hashlib.sha256(str(path).encode()).hexdigest()[:10]}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            return {"program_ref": ref, "executed": False, "reason": "loader_unavailable", "input": dict(payload)}
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        runner = getattr(module, "run", None)
        if not callable(runner):
            return {"program_ref": ref, "executed": False, "reason": "run_missing", "input": dict(payload)}
        output = runner(dict(payload))
        return {"program_ref": ref, "executed": True, "output": output}

    @classmethod
    def execute_recipe(cls, recipe: Mapping[str, Any], *, input_payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        ref = str(recipe.get("program_ref") or "")
        if not ref.startswith("recipe:"):
            raise RuntimeError("recipe does not contain an executable program_ref")
        program = json.loads(Path(ref.split(":", 1)[1]).read_text(encoding="utf-8"))
        state: Any = dict(input_payload or {})
        execution_trace: list[dict[str, Any]] = []
        executed_any = False
        all_executed = True
        for index, step in enumerate(program.get("steps") or ()):
            row = cls._execute_program_ref(str(step.get("program_ref") or ""), state if isinstance(state, Mapping) else {"value": state}, index=index)
            execution_trace.append({**dict(step), **row})
            if row.get("executed") is True:
                executed_any = True
                state = row.get("output")
            else:
                all_executed = False
        return {
            "recipe_id": str(recipe.get("recipe_id") or ""),
            "input": dict(input_payload or {}),
            "steps": tuple(program.get("steps") or ()),
            "operator_refs": tuple(program.get("operator_refs") or ()),
            "replay_ready": True,
            "executed": bool(executed_any and all_executed),
            "execution_trace": tuple(execution_trace),
            "result": state,
        }

    def recall_structure(self, query_refs: Iterable[str]) -> tuple[dict[str, Any], ...]:
        query = set(map(str, query_refs))
        rows = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            text = json.dumps(row, ensure_ascii=False, default=str)
            if any(x in text for x in query):
                rows.append(row)
        return tuple(rows)

    def _append(self, row: Mapping[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n")
