from __future__ import annotations

"""ZIP-owned aesthetic quality review for generated imagery.

This module deliberately separates aesthetic acceptance from actuator execution.
The image actuator renders; JIGAEWOL compiles the visual quality contract, re-observes
an available result, and decides whether another render is needed.
"""

import math
from typing import Any, Mapping


class ImageQualityGovernor:
    SCORE_METRICS = (
        "grain_score", "genericity_score", "plasticity_score", "cliche_score",
        "style_flattening_score", "overpolished_score", "objective_alignment",
        "composition_autopilot_score", "color_grade_autopilot_score", "prompt_dilution_score",
    )
    BOOLEAN_METRICS = (
        "default_character_drift", "default_visual_archetype", "identity_drift",
        "unrequested_character_substitution",
    )
    DEFAULT_NEGATIVE_SIGNATURES = (
        "gritty_microtexture",
        "generic_ai_composition",
        "default_character_drift",
        "plastic_skin",
        "overprocessed_detail",
        "stock_hero_lighting",
        "synthetic_bloom",
        "oversharpened_edges",
        "cliche_composition",
        "style_flattening",
        "default_visual_archetype",
        "overpolished_stock_aesthetic",
        "ai_speckle_noise",
        "composition_autopilot",
        "color_grade_autopilot",
        "prompt_dilution",
        "identity_drift",
        "unrequested_character_substitution",
    )

    @classmethod
    def compile_contract(cls, objective: str = "") -> dict[str, Any]:
        return {
            "schema": "jigaewol_image_quality_contract_v1",
            "objective": str(objective),
            "generation_actuator_role": "render_only",
            "final_aesthetic_acceptance_owner": "JIGAEWOL",
            "post_generation_reobservation_required": True,
            "negative_visual_signatures": list(cls.DEFAULT_NEGATIVE_SIGNATURES),
            "genericity_threshold": 0.58,
            "grain_threshold": 0.62,
            "plasticity_threshold": 0.60,
            "objective_alignment_floor": 0.78,
            "cliche_threshold": 0.60,
            "style_flattening_threshold": 0.60,
            "overpolished_threshold": 0.68,
            "composition_autopilot_threshold": 0.60,
            "color_grade_autopilot_threshold": 0.62,
            "prompt_dilution_threshold": 0.55,
            "rerender_on_quality_failure": True,
            "generator_may_not_self_certify_quality": True,
            "quality_review_is_separate_from_execution_truth": True,
        }


    @classmethod
    def compile_render_directive(cls, contract: Mapping[str, Any], *, image_sovereignty_token: str = "") -> dict[str, Any]:
        c=dict(contract or {})
        return {
            "schema":"jigaewol_image_render_directive_v1",
            "objective":str(c.get("objective") or ""),
            "generator_role":"render_only",
            "zip_final_review_required":True,
            "avoid_signatures":list(c.get("negative_visual_signatures") or cls.DEFAULT_NEGATIVE_SIGNATURES),
            "quality_targets":{
                "objective_alignment_floor":float(c.get("objective_alignment_floor") or 0.78),
                "max_grain":float(c.get("grain_threshold") or 0.62),
                "max_genericity":float(c.get("genericity_threshold") or 0.58),
                "max_plasticity":float(c.get("plasticity_threshold") or 0.60),
                "max_cliche":float(c.get("cliche_threshold") or 0.60),
                "max_style_flattening":float(c.get("style_flattening_threshold") or 0.60),
                "max_overpolished":float(c.get("overpolished_threshold") or 0.68),
                "max_composition_autopilot":float(c.get("composition_autopilot_threshold") or 0.60),
                "max_color_grade_autopilot":float(c.get("color_grade_autopilot_threshold") or 0.62),
                "max_prompt_dilution":float(c.get("prompt_dilution_threshold") or 0.55),
            },
            "generator_may_not_self_certify_quality":True,
            "aesthetic_acceptance_owner":"JIGAEWOL",
            "image_sovereignty_token": str(image_sovereignty_token or ""),
        }

    @classmethod
    def compile_review_request(
        cls, *, generated_ref: str, contract: Mapping[str, Any], parent_action_id: str,
        requirement_ids: tuple[str, ...] | list[str] = (),
    ) -> dict[str, Any]:
        c = dict(contract or cls.compile_contract(""))
        return {
            "schema": "jigaewol_image_quality_review_request_v1",
            "generated_ref": str(generated_ref or ""),
            "parent_action_id": str(parent_action_id or ""),
            "requirement_ids": [str(x) for x in requirement_ids if str(x)],
            "objective": str(c.get("objective") or ""),
            "aesthetic_acceptance_owner": "JIGAEWOL",
            "generator_role": "render_only",
            "generator_may_not_self_certify_quality": True,
            "required_metrics": {
                "grain_score": True,
                "genericity_score": True,
                "plasticity_score": True,
                "cliche_score": True,
                "style_flattening_score": True,
                "overpolished_score": True,
                "default_character_drift": True,
                "default_visual_archetype": True,
                "objective_alignment": True,
                "composition_autopilot_score": True,
                "color_grade_autopilot_score": True,
                "prompt_dilution_score": True,
                "identity_drift": True,
                "unrequested_character_substitution": True,
            },
            "negative_visual_signatures": list(c.get("negative_visual_signatures") or cls.DEFAULT_NEGATIVE_SIGNATURES),
        }

    @staticmethod
    def rerender_directive(render_directive: Mapping[str, Any], verdict: Mapping[str, Any]) -> dict[str, Any]:
        failures=list(dict.fromkeys(str(x) for x in (verdict.get("failure_signatures") or ()) if str(x)))
        return {
            "schema":"jigaewol_image_rerender_directive_v1",
            "rerender_required":bool(verdict.get("rerender_required") and failures),
            "generator_role":"render_only",
            "objective":str(render_directive.get("objective") or ""),
            "repair_targets":failures,
            "avoid_signatures":list(render_directive.get("avoid_signatures") or ()),
            "preserve_user_style_intent":True,
            "zip_final_review_required":True,
            "image_sovereignty_token": str(render_directive.get("image_sovereignty_token") or ""),
        }

    @classmethod
    def review_observation(cls, observation: Mapping[str, Any], *, contract: Mapping[str, Any] | None = None) -> dict[str, Any]:
        c = dict(contract or cls.compile_contract(""))
        row = dict(observation or {})
        required = (*cls.SCORE_METRICS, *cls.BOOLEAN_METRICS)
        missing = [key for key in required if key not in row]
        invalid: list[str] = []
        metrics: dict[str, Any] = {}
        for key in cls.SCORE_METRICS:
            if key not in row:
                continue
            try:
                value = float(row[key])
                if isinstance(row[key], bool) or not math.isfinite(value) or not 0.0 <= value <= 1.0:
                    raise ValueError("metric must be a finite score between zero and one")
                metrics[key] = value
            except (TypeError, ValueError, OverflowError):
                invalid.append(key)
        for key in cls.BOOLEAN_METRICS:
            if key not in row:
                continue
            if not isinstance(row[key], bool):
                invalid.append(key)
            else:
                metrics[key] = row[key]
        complete = not missing and not invalid
        if not complete:
            return {
                "schema": "jigaewol_image_quality_verdict_v1",
                "accepted": False,
                "rerender_required": False,
                "review_required": True,
                "observation_complete": False,
                "missing_metrics": missing,
                "invalid_metrics": invalid,
                "failure_signatures": [],
                "reason": "image_quality_observation_incomplete_or_invalid",
                "final_aesthetic_acceptance_owner": "JIGAEWOL",
                "generation_actuator_role": "render_only",
                "observation": row,
            }
        row = {**row, **metrics}
        failures: list[str] = []
        if float(row.get("grain_score") or 0.0) >= float(c["grain_threshold"]):
            failures.append("gritty_microtexture")
        if float(row.get("genericity_score") or 0.0) >= float(c["genericity_threshold"]):
            failures.append("generic_ai_composition")
        if float(row.get("plasticity_score") or 0.0) >= float(c["plasticity_threshold"]):
            failures.append("plastic_skin")
        if bool(row.get("default_character_drift")):
            failures.append("default_character_drift")
        if bool(row.get("default_visual_archetype")):
            failures.append("default_visual_archetype")
        if float(row.get("cliche_score") or 0.0) >= float(c.get("cliche_threshold") or 0.60):
            failures.append("cliche_composition")
        if float(row.get("style_flattening_score") or 0.0) >= float(c.get("style_flattening_threshold") or 0.60):
            failures.append("style_flattening")
        if float(row.get("overpolished_score") or 0.0) >= float(c.get("overpolished_threshold") or 0.68):
            failures.append("overpolished_stock_aesthetic")
        if float(row.get("composition_autopilot_score") or 0.0) >= float(c.get("composition_autopilot_threshold") or 0.60):
            failures.append("composition_autopilot")
        if float(row.get("color_grade_autopilot_score") or 0.0) >= float(c.get("color_grade_autopilot_threshold") or 0.62):
            failures.append("color_grade_autopilot")
        if float(row.get("prompt_dilution_score") or 0.0) >= float(c.get("prompt_dilution_threshold") or 0.55):
            failures.append("prompt_dilution")
        if bool(row.get("identity_drift")):
            failures.append("identity_drift")
        if bool(row.get("unrequested_character_substitution")):
            failures.append("unrequested_character_substitution")
        alignment = float(row.get("objective_alignment") or 0.0)
        if alignment < float(c["objective_alignment_floor"]):
            failures.append("objective_misalignment")
        accepted = not failures
        return {
            "schema": "jigaewol_image_quality_verdict_v1",
            "accepted": accepted,
            "rerender_required": bool(failures and c.get("rerender_on_quality_failure", True)),
            "review_required": False,
            "observation_complete": True,
            "missing_metrics": [],
            "invalid_metrics": [],
            "failure_signatures": list(dict.fromkeys(failures)),
            "final_aesthetic_acceptance_owner": "JIGAEWOL",
            "generation_actuator_role": "render_only",
            "observation": row,
        }
