from __future__ import annotations

"""Repeated failure changes the generator that invents search spaces, not only candidates.

The genome deliberately treats its built-in dimensions and expression forms as a seed,
not a closed ontology.  Failure evidence may add dimensions, syntax forms, productions,
numeric bases, ordering constraints, and search geometry for the next generation.
"""

from dataclasses import dataclass, asdict
from collections import Counter, defaultdict
from typing import Iterable, Mapping, Any
import hashlib
import json
import math
import re


def _stable(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()


def _tokens(value: Any) -> tuple[str, ...]:
    text = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return tuple(dict.fromkeys(x.lower() for x in re.findall(r"[A-Za-z_][A-Za-z0-9_]{2,}", text)))


@dataclass(frozen=True, slots=True)
class GeneratorGenome:
    # Seeds, not a semantic ceiling. New dimensions/forms/productions may be born.
    mutation_order: tuple[str, ...] = (
        "observer", "problem_type", "language", "operation", "interpreter", "program", "translator", "receiver", "generator"
    )
    collision_pressure: float = 1.0
    novelty_pressure: float = 1.0
    expression_depth: int = 2
    combination_arity: int = 2
    residue_basis: tuple[int, ...] = (2, 3, 4, 5)
    grammar_forms: tuple[str, ...] = ("call", "if", "seq", "emit")
    expression_forms: tuple[str, ...] = ("eq", "tuple", "add", "sub", "mul", "mod")
    born_productions: tuple[Mapping[str, Any], ...] = ()
    search_dimensions: tuple[str, ...] = (
        "representation", "observer", "problem_type", "language", "operation", "interpreter",
        "program", "translator", "receiver", "experience", "extraction", "generator",
    )
    learned_failure_signatures: tuple[str, ...] = ()
    search_budget: int = 256
    datatype_proposal_mode: str = "collision_residual"
    residual_metric_mode: str = "behavioral_roundtrip"
    experience_generation_mode: str = "obstruction_amplification"
    extraction_mode: str = "repeated_structural_motif"
    candidate_scheduler: str = "failure_reverse_flow"
    preserve_multiple_models: bool = True
    generation: int = 0

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any] | None) -> "GeneratorGenome":
        row = dict(raw or {})
        tuple_fields = {
            "mutation_order", "residue_basis", "grammar_forms", "expression_forms",
            "born_productions", "search_dimensions", "learned_failure_signatures",
        }
        kwargs: dict[str, Any] = {}
        for name in cls.__dataclass_fields__:
            if name not in row:
                continue
            value = row[name]
            kwargs[name] = tuple(value) if name in tuple_fields and value is not None else value
        return cls(**kwargs)


class GeneratorEvolution:
    """Meta-mutation changes how search spaces are invented from failure evidence.

    Failure-kind priors only bootstrap the first mutation. Explicit evidence in a
    failure row can introduce previously unknown search dimensions, grammar forms,
    productions and numeric structures. Nothing in the seed tuple is treated as the
    exhaustive set of things the generator may change.
    """

    _SEED_PRIORS: Mapping[str, tuple[str, ...]] = {
        "representation_collision": ("observer", "representation", "problem_type", "translator"),
        "program_miss": ("language", "operation", "interpreter", "program"),
        "no_classifier_in_current_language": ("language", "operation", "interpreter", "program"),
        "translation_loss": ("translator", "representation", "problem_type", "observer"),
        "experience_gap": ("experience", "observer", "problem_type"),
        "extraction_miss": ("extraction", "operation", "language"),
        "unknown_syntax": ("language", "interpreter", "generator"),
        "unknown_operation": ("operation", "language", "interpreter", "generator"),
        "unresolved": ("generator", "representation", "language", "interpreter", "observer"),
    }

    @staticmethod
    def _discover_dimensions(rows: tuple[Mapping[str, Any], ...], existing: tuple[str, ...]) -> tuple[str, ...]:
        discovered = list(existing)
        known = set(discovered)
        for row in rows:
            explicit = row.get("search_dimensions") or row.get("blocked_dimensions") or row.get("dimensions") or ()
            if isinstance(explicit, str):
                explicit = (explicit,)
            for value in explicit if isinstance(explicit, (tuple, list, set)) else ():
                name = str(value).strip()
                if name and name not in known:
                    discovered.append(name); known.add(name)
            # Birth requests may name a dimension that did not exist in the seed ontology.
            births = row.get("birth_requests") or ()
            if isinstance(births, Mapping): births = (births,)
            for birth in births if isinstance(births, (tuple, list)) else ():
                if not isinstance(birth, Mapping): continue
                target = str(birth.get("kind") or birth.get("target") or "").strip()
                if target and target not in known:
                    discovered.append(target); known.add(target)
        return tuple(discovered)

    @staticmethod
    def _discover_forms(rows: tuple[Mapping[str, Any], ...], existing: tuple[str, ...]) -> tuple[str, ...]:
        forms = list(existing); seen = set(forms)
        for row in rows:
            candidates: list[Any] = []
            for key in ("missing_form", "syntax_form", "requested_form", "unknown_syntax"):
                if row.get(key): candidates.append(row.get(key))
            shape = row.get("suggested_shape")
            if isinstance(shape, Mapping):
                candidates.extend((shape.get("name"), shape.get("kind"), shape.get("form")))
            for value in candidates:
                name = str(value or "").strip()
                if name and name not in seen:
                    forms.append(name); seen.add(name)
        return tuple(forms)

    @staticmethod
    def _discover_productions(rows: tuple[Mapping[str, Any], ...], existing: tuple[Mapping[str, Any], ...]) -> tuple[Mapping[str, Any], ...]:
        out = [dict(x) for x in existing if isinstance(x, Mapping)]
        seen = {_stable(x) for x in out}
        for row in rows:
            candidates = []
            for key in ("production", "grammar_production", "suggested_production"):
                if isinstance(row.get(key), Mapping): candidates.append(row[key])
            shape = row.get("suggested_shape")
            if isinstance(shape, Mapping) and isinstance(shape.get("production"), Mapping):
                candidates.append(shape["production"])
            for candidate in candidates:
                sig = _stable(candidate)
                if sig not in seen:
                    out.append(dict(candidate)); seen.add(sig)
        return tuple(out)

    def evolve(self, genome: GeneratorGenome, failures: Iterable[Mapping[str, Any]]) -> GeneratorGenome:
        rows = tuple(dict(x) for x in failures)
        kinds = Counter(str(x.get("kind") or "unknown") for x in rows)
        dimensions = self._discover_dimensions(rows, genome.search_dimensions)
        scores: defaultdict[str, float] = defaultdict(float)

        # Preserve prior geometry as a weak prior, not a fixed order.
        for idx, dim in enumerate(genome.mutation_order):
            scores[dim] += max(0.1, 1.0 - idx / max(1.0, len(genome.mutation_order)))
        for row in rows:
            kind = str(row.get("kind") or "unknown")
            for rank, dim in enumerate(self._SEED_PRIORS.get(kind, ())):
                scores[dim] += 4.0 / (rank + 1)
            row_tokens = set(_tokens(row))
            for dim in dimensions:
                if dim.lower() in row_tokens:
                    scores[dim] += 5.0
            explicit = row.get("search_dimensions") or row.get("blocked_dimensions") or row.get("dimensions") or ()
            if isinstance(explicit, str): explicit = (explicit,)
            if isinstance(explicit, (tuple, list, set)):
                for dim in explicit: scores[str(dim)] += 8.0

        # Newly discovered dimensions participate immediately; low-score dimensions are
        # retained so a later failure can promote them rather than losing them forever.
        order = tuple(sorted(dimensions, key=lambda d: (-scores[d], dimensions.index(d))))
        if not order:
            order = genome.mutation_order

        unresolved_pressure = sum(kinds[k] for k in ("unresolved", "unknown", "unknown_syntax", "unknown_operation", "no_classifier_in_current_language"))
        collision_pressure = kinds["representation_collision"]
        program_pressure = kinds["program_miss"] + kinds["no_classifier_in_current_language"]
        depth_growth = max(1, int(math.ceil(math.log2(2 + unresolved_pressure + program_pressure + collision_pressure)))) if rows else 0
        arity_growth = max(1, int(math.ceil(math.log2(2 + program_pressure + unresolved_pressure)))) if (program_pressure or unresolved_pressure) else 0
        depth = max(1, genome.expression_depth + depth_growth)
        arity = max(1, genome.combination_arity + arity_growth)

        grammar_forms = list(self._discover_forms(rows, genome.grammar_forms))
        expression_forms = list(genome.expression_forms)
        for row in rows:
            requested = row.get("expression_forms") or ()
            if isinstance(requested, str): requested = (requested,)
            if isinstance(requested, (tuple, list, set)):
                for form in requested:
                    form = str(form)
                    if form and form not in expression_forms: expression_forms.append(form)
        if program_pressure and "if" not in expression_forms: expression_forms.append("if")
        if unresolved_pressure and "eq" not in expression_forms: expression_forms.append("eq")

        residues = list(genome.residue_basis)
        for row in rows:
            for key in ("label_cardinality", "state_cardinality", "modulus_hint", "period_hint"):
                try: value = int(row.get(key))
                except Exception: continue
                if value >= 2 and value not in residues: residues.append(value)
        if unresolved_pressure:
            nxt = max(residues or [1]) + 1
            while nxt in residues: nxt += 1
            residues.append(nxt)

        signatures = list(genome.learned_failure_signatures)
        for row in rows:
            sig = _stable(row)
            if sig not in signatures: signatures.append(sig)
        productions = self._discover_productions(rows, genome.born_productions)

        dtype = genome.datatype_proposal_mode
        residual = genome.residual_metric_mode
        experience = genome.experience_generation_mode
        extraction = genome.extraction_mode
        scheduler = genome.candidate_scheduler
        if collision_pressure: dtype = "witness_structure_then_generated_composition"
        if kinds["translation_loss"]: residual = "multi_model_behavioral_residual"
        if kinds["experience_gap"]: experience = "generate_world_from_obstruction_and_counterexample"
        if kinds["extraction_miss"]: extraction = "cross_world_executable_semantic_motif"
        if rows: scheduler = "evidence_ranked_dimension_birth_with_reverse_flow"

        # Budget is a resource horizon, not a semantic ceiling; it grows with accumulated
        # failure evidence and can be changed by later generations.
        search_budget = max(64, genome.search_budget + 32 * len(rows) + 16 * len(set(signatures) - set(genome.learned_failure_signatures)))

        return GeneratorGenome(
            mutation_order=order,
            collision_pressure=genome.collision_pressure + 0.25 * collision_pressure,
            novelty_pressure=genome.novelty_pressure + 0.15 * len(rows),
            expression_depth=depth,
            combination_arity=arity,
            residue_basis=tuple(dict.fromkeys(residues)),
            grammar_forms=tuple(dict.fromkeys(grammar_forms)),
            expression_forms=tuple(dict.fromkeys(expression_forms)),
            born_productions=productions,
            search_dimensions=dimensions,
            learned_failure_signatures=tuple(signatures),
            search_budget=search_budget,
            datatype_proposal_mode=dtype,
            residual_metric_mode=residual,
            experience_generation_mode=experience,
            extraction_mode=extraction,
            candidate_scheduler=scheduler,
            preserve_multiple_models=True,
            generation=genome.generation + 1,
        )
