from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

from .worker_truth import WorkerTruth


@dataclass(frozen=True)
class AgentCliManifest:
    provider_id: str
    display_name: str
    binary: str
    version_args: tuple[str, ...]
    adapter_ready: bool
    session_mode: str
    env_keys: tuple[str, ...]
    version_markers: tuple[str, ...] = ()
    transcript_globs: tuple[str, ...] = ()

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AgentCliProbe:
    provider_id: str
    available: bool
    binary_path: str
    version_exit_code: int | None
    version_output: str
    adapter_ready: bool
    identity_marker_match: bool
    observed_at: float

    @property
    def binary_identity_observed(self) -> bool:
        return bool(self.available and self.binary_path and self.version_exit_code == 0 and self.identity_marker_match)

    def as_mapping(self) -> dict[str, Any]:
        return {**asdict(self), "binary_identity_observed": self.binary_identity_observed}


@dataclass(frozen=True)
class AgentCliRemoteProbe:
    provider_id: str
    body_id: str
    version_exit_code: int | None
    version_output: str
    adapter_ready: bool
    identity_marker_match: bool
    auth_state: str
    persistent_body: bool
    evidence_ref: str
    observed_at: float

    @property
    def binary_identity_observed(self) -> bool:
        return bool(self.version_exit_code == 0 and self.identity_marker_match)

    def as_mapping(self) -> dict[str, Any]:
        return {**asdict(self), "binary_identity_observed": self.binary_identity_observed}


@dataclass(frozen=True)
class AgentCliInvocation:
    provider_id: str
    binary_path: str
    argv: tuple[str, ...]
    cwd: str
    env_keys: tuple[str, ...]
    session_id: str = ""
    resume: bool = False

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class AgentCliCatalog:
    """Evidence-aware local agent CLI catalog and invocation adapter.

    This module deliberately separates four states:
      known manifest -> binary observed -> session observed -> closed-loop result observed.
    Merely finding an executable never proves a cognitive worker.
    """

    FORMAT = "jigaewol_agent_cli_catalog_v1"

    BUILTINS: dict[str, AgentCliManifest] = {
        "codex": AgentCliManifest(
            "codex", "Codex CLI", "codex", ("--version",), True, "discover_rollout",
            ("CODEX_HOME", "OPENAI_API_KEY"), ("codex",), ("~/.codex/sessions/*/*/*/rollout-*.jsonl",),
        ),
        "claude": AgentCliManifest(
            "claude", "Claude Code", "claude", ("--version",), True, "known_or_resume",
            ("ANTHROPIC_API_KEY", "CLAUDE_CONFIG_DIR"), ("claude",), ("~/.claude/projects/*/*.jsonl",),
        ),
        "opencode": AgentCliManifest(
            "opencode", "OpenCode", "opencode", ("--version",), True, "known_or_resume",
            ("OPENCODE_HOME", "OPENCODE_API_KEY"), ("opencode",), (),
        ),
        "gemini": AgentCliManifest(
            "gemini", "Gemini CLI", "gemini", ("--version",), False, "provider_specific",
            ("GEMINI_API_KEY", "GOOGLE_API_KEY", "GEMINI_CLI_HOME"), ("gemini",), (),
        ),
        "aider": AgentCliManifest(
            "aider", "Aider", "aider", ("--version",), False, "provider_specific",
            ("AIDER_ENV_FILE", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"), ("aider",), (),
        ),
        "goose": AgentCliManifest(
            "goose", "Goose", "goose", ("--version",), False, "provider_specific",
            ("GOOSE_CONFIG_DIR", "GOOSE_PROVIDER", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"), ("goose",), (),
        ),
        "openhands": AgentCliManifest(
            "openhands", "OpenHands", "openhands", ("--version",), False, "provider_specific",
            ("OPENHANDS_CONFIG_DIR", "LLM_API_KEY", "LLM_MODEL", "LLM_BASE_URL"), ("openhands",), (),
        ),
        "cursor-agent": AgentCliManifest(
            "cursor-agent", "Cursor Agent", "cursor-agent", ("--version",), False, "provider_specific",
            ("CURSOR_API_KEY", "CURSOR_CONFIG_DIR"), ("cursor",), (),
        ),
        "amp": AgentCliManifest(
            "amp", "Amp", "amp", ("--version",), False, "provider_specific",
            ("AMP_API_KEY", "AMP_SETTINGS_FILE"), ("amp",), (),
        ),
    }

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "probes.json"
        if not self.path.exists():
            self.path.write_text(
                json.dumps({"format": self.FORMAT, "probes": {}, "remote_probes": {}}, indent=2) + "\n",
                encoding="utf-8",
            )

    def _read(self) -> dict[str, Any]:
        data=json.loads(self.path.read_text(encoding="utf-8"))
        if data.get("format") != self.FORMAT:
            raise ValueError("agent cli catalog format mismatch")
        data.setdefault("probes", {})
        data.setdefault("remote_probes", {})
        return data

    def _write(self, data: Mapping[str, Any]) -> None:
        tmp=self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps(dict(data),ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
        tmp.replace(self.path)

    def manifest(self, provider_id: str) -> AgentCliManifest:
        try:
            return self.BUILTINS[str(provider_id)]
        except KeyError:
            raise KeyError(f"unknown agent cli provider: {provider_id}")

    def probe(self, provider_id: str, *, path: str | None = None, timeout_s: float = 3.0) -> AgentCliProbe:
        spec=self.manifest(provider_id)
        binary_path=shutil.which(spec.binary, path=path)
        code=None; output=""
        if binary_path:
            env={"PATH": path or os.environ.get("PATH", "")}
            try:
                cp=subprocess.run([binary_path,*spec.version_args],capture_output=True,text=True,timeout=float(timeout_s),env=env)
                code=int(cp.returncode)
                output=((cp.stdout or "")+(cp.stderr or "")).strip()[:4096]
            except (OSError, subprocess.SubprocessError) as exc:
                code=-1; output=f"{type(exc).__name__}: {exc}"[:4096]
        marker_match = bool(binary_path and code == 0 and (not spec.version_markers or any(m.lower() in output.lower() for m in spec.version_markers)))
        row=AgentCliProbe(spec.provider_id,bool(binary_path),str(binary_path or ""),code,output,spec.adapter_ready,marker_match,time.time())
        data=self._read(); data["probes"][spec.provider_id]=row.as_mapping(); self._write(data)
        return row

    def probe_all(self, *, path: str | None = None) -> tuple[AgentCliProbe, ...]:
        return tuple(self.probe(pid,path=path) for pid in self.BUILTINS)

    def latest_probe(self, provider_id: str) -> AgentCliProbe | None:
        raw=self._read()["probes"].get(str(provider_id))
        if raw is None: return None
        row=dict(raw); row.pop("binary_identity_observed",None)
        return AgentCliProbe(**row)

    def record_remote_probe(
        self, provider_id: str, *, body_id: str, version_exit_code: int | None,
        version_output: str, auth_state: str, persistent_body: bool, evidence_ref: str = "",
    ) -> AgentCliRemoteProbe:
        spec=self.manifest(provider_id)
        output=str(version_output or "")[:4096]
        marker_match=bool(
            version_exit_code == 0
            and (not spec.version_markers or any(m.lower() in output.lower() for m in spec.version_markers))
        )
        row=AgentCliRemoteProbe(
            provider_id=spec.provider_id,
            body_id=str(body_id),
            version_exit_code=None if version_exit_code is None else int(version_exit_code),
            version_output=output,
            adapter_ready=spec.adapter_ready,
            identity_marker_match=marker_match,
            auth_state=str(auth_state or "unknown"),
            persistent_body=bool(persistent_body),
            evidence_ref=str(evidence_ref or ""),
            observed_at=time.time(),
        )
        data=self._read()
        data["remote_probes"].setdefault(spec.provider_id,{})[row.body_id]=row.as_mapping()
        self._write(data)
        return row

    def latest_remote_probe(self, provider_id: str, body_id: str) -> AgentCliRemoteProbe | None:
        raw=self._read()["remote_probes"].get(str(provider_id),{}).get(str(body_id))
        if raw is None:
            return None
        row=dict(raw); row.pop("binary_identity_observed",None)
        return AgentCliRemoteProbe(**row)

    def remote_session_truth(
        self, provider_id: str, *, body_id: str, session_id: str, context_ref: str,
        execution_receipt_ref: str = "", result_return_path_observed: bool = False,
    ) -> WorkerTruth:
        probe=self.latest_remote_probe(provider_id,body_id)
        binary_proven=bool(
            probe
            and probe.binary_identity_observed
            and probe.adapter_ready
            and probe.auth_state in {"authenticated", "not_required"}
        )
        session_proven=bool(str(session_id).strip() and str(context_ref).strip())
        cognitive=bool(binary_proven and session_proven)
        return WorkerTruth(
            execution_kind="remote_session" if cognitive else "callable",
            context_ref=str(context_ref) if cognitive else "",
            provider_ref=f"agent_cli_remote:{provider_id}@{body_id}" if cognitive else "",
            execution_receipt_ref=str(execution_receipt_ref),
            state="observed" if cognitive else "callable",
            agent_backed=cognitive,
            result_return_path_observed=bool(cognitive and result_return_path_observed),
        )

    def render_invocation(
        self, provider_id: str, *, workspace: str | Path, prompt: str,
        session_id: str = "", model: str = "", approval_policy: str = "ask",
    ) -> AgentCliInvocation:
        spec=self.manifest(provider_id)
        probe=self.latest_probe(provider_id) or self.probe(provider_id)
        if not probe.binary_identity_observed:
            raise RuntimeError(f"agent cli binary is not observed: {provider_id}")
        if not spec.adapter_ready:
            raise RuntimeError(f"agent cli is observed but invocation adapter is not proven: {provider_id}")
        workspace=str(Path(workspace).resolve()); prompt=str(prompt)
        approval=str(approval_policy)
        if provider_id == "codex":
            argv=[probe.binary_path,"exec","--cd",workspace,"--sandbox","workspace-write"]
            if approval == "never": argv += ["--ask-for-approval","never"]
            elif approval == "yolo": argv += ["--dangerously-bypass-approvals-and-sandbox"]
            else: argv += ["--ask-for-approval","on-request"]
            argv += ["--json"]
            if model: argv += ["--model",str(model)]
            if session_id: argv += ["resume",str(session_id),prompt]
            else: argv += [prompt]
        elif provider_id == "claude":
            argv=[probe.binary_path]
            if model: argv += ["--model",str(model)]
            argv += ["--output-format","stream-json"]
            if session_id: argv += ["--resume",str(session_id)]
            if approval == "yolo": argv += ["--dangerously-skip-permissions"]
            argv += ["-p",prompt]
        elif provider_id == "opencode":
            argv=[probe.binary_path,"run","--standalone","--format","json"]
            if model: argv += ["--model",str(model)]
            if session_id: argv += ["--session",str(session_id)]
            argv += [prompt]
        else:
            raise LookupError(f"PROVIDER_ADAPTER_NOT_MATERIALIZED:{provider_id}")
        return AgentCliInvocation(spec.provider_id,probe.binary_path,tuple(argv),workspace,spec.env_keys,str(session_id),bool(session_id))

    def session_truth(
        self, provider_id: str, *, session_id: str, context_ref: str,
        execution_receipt_ref: str = "", result_return_path_observed: bool = False,
    ) -> WorkerTruth:
        probe=self.latest_probe(provider_id)
        binary_proven=bool(probe and probe.binary_identity_observed and self.manifest(provider_id).adapter_ready)
        session_proven=bool(str(session_id).strip() and str(context_ref).strip())
        return WorkerTruth(
            execution_kind="provider_session" if session_proven else "callable",
            context_ref=str(context_ref),
            provider_ref=f"agent_cli:{provider_id}" if session_proven else "",
            execution_receipt_ref=str(execution_receipt_ref),
            state="observed" if session_proven else "callable",
            agent_backed=bool(binary_proven and session_proven),
            result_return_path_observed=bool(binary_proven and session_proven and result_return_path_observed),
        )
    def session_truth_from_event_summary(
        self, provider_id: str, summary: Mapping[str, Any], *, execution_receipt_ref: str = ""
    ) -> WorkerTruth:
        session_id = str(summary.get("session_id") or "")
        context_ref = f"agent_event_journal:{provider_id}:{session_id}" if session_id else ""
        closed_loop = bool(summary.get("closed_loop_result_observed"))
        return self.session_truth(
            provider_id, session_id=session_id, context_ref=context_ref,
            execution_receipt_ref=str(execution_receipt_ref),
            result_return_path_observed=closed_loop,
        )

