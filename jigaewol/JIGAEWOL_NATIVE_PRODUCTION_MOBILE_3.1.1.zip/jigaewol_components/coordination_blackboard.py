from __future__ import annotations

import copy
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class SignalMessage:
    signal_id: str
    channel: str
    kind: str
    initial_intensity: float
    emitted_at: float
    reinforced_at: float
    half_life_s: float | None
    payload: dict[str, Any] = field(default_factory=dict)
    facets: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Trace:
    trail: str
    key: str
    version: int
    value: Any
    evidence: tuple[str, ...] = ()
    updated_at: float = 0.0


@dataclass(frozen=True)
class SignalPattern:
    pattern_id: str
    channel: str | None
    kind: str | None
    minimum_intensity: float | None
    facets: dict[str, Any] = field(default_factory=dict)


class CoordinationBlackboard:
    """Decentralized event-driven blackboard coordination.

    Allows workers to coordinate asynchronously via decay-weighted event signals
    and persistent structured traces without a rigid central orchestrator.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"signals": {}, "traces": {}, "patterns": {}})

    def _read(self) -> dict[str, Any]:
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if "pheromones" in data and "signals" not in data:
            data["signals"] = data.pop("pheromones")
        if "scents" in data and "patterns" not in data:
            data["patterns"] = data.pop("scents")
        return data

    def _write(self, d: dict[str, Any]) -> None:
        t = self.path.with_suffix(".tmp")
        t.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
        t.replace(self.path)

    @staticmethod
    def intensity(p: SignalMessage, now: float | None = None) -> float:
        now = time.time() if now is None else float(now)
        elapsed = max(0.0, now - p.reinforced_at)
        if p.half_life_s is None or p.half_life_s <= 0:
            return max(0.0, min(1.0, p.initial_intensity))
        return max(0.0, min(1.0, p.initial_intensity * (0.5 ** (elapsed / p.half_life_s))))

    def emit(
        self,
        channel: str,
        kind: str,
        *,
        intensity: float = 1.0,
        half_life_s: float | None = None,
        payload: dict[str, Any] | None = None,
        facets: dict[str, Any] | None = None,
    ) -> SignalMessage:
        now = time.time()
        row = SignalMessage(
            f"signal_{uuid.uuid4().hex[:16]}",
            str(channel),
            str(kind),
            max(0.0, min(1.0, float(intensity))),
            now,
            now,
            (None if half_life_s is None else float(half_life_s)),
            dict(payload or {}),
            dict(facets or {}),
        )
        d = self._read()
        d["signals"][row.signal_id] = asdict(row)
        self._write(d)
        return row

    def reinforce(self, signal_id: str, *, intensity: float | None = None) -> SignalMessage:
        d = self._read()
        raw = d["signals"][str(signal_id)]
        p = SignalMessage(**raw)
        now = time.time()
        cur = self.intensity(p, now)
        raw["initial_intensity"] = max(cur, float(cur if intensity is None else intensity))
        raw["reinforced_at"] = now
        d["signals"][str(signal_id)] = raw
        self._write(d)
        return SignalMessage(**raw)

    def scan(
        self,
        *,
        channel: str | None = None,
        kind: str | None = None,
        minimum_intensity: float | None = None,
        now: float | None = None,
    ) -> tuple[tuple[SignalMessage, float], ...]:
        rows = []
        for raw in self._read()["signals"].values():
            p = SignalMessage(**raw)
            if channel is not None and p.channel != channel:
                continue
            if kind is not None and p.kind != kind:
                continue
            value = self.intensity(p, now)
            if minimum_intensity is None or value >= float(minimum_intensity):
                rows.append((p, value))
        rows.sort(key=lambda x: (-x[1], x[0].signal_id))
        return tuple(rows)

    def cleanup(self, *, below: float | None = None, now: float | None = None) -> tuple[str, ...]:
        d = self._read()
        removed = []
        if below is None:
            return ()
        for sid, raw in list(d["signals"].items()):
            if self.intensity(SignalMessage(**raw), now) < float(below):
                removed.append(sid)
                del d["signals"][sid]
        self._write(d)
        return tuple(removed)

    def inscribe(self, channel: str, key: str, value: Any, *, evidence: Iterable[str] = ()) -> Trace:
        d = self._read()
        ident = f"{channel}\u0000{key}"
        prev = d["traces"].get(ident)
        version = 1 if prev is None else int(prev["version"]) + 1
        row = Trace(
            str(channel),
            str(key),
            version,
            copy.deepcopy(value),
            tuple(str(x) for x in evidence),
            time.time(),
        )
        d["traces"][ident] = asdict(row)
        self._write(d)
        return row

    def read_trace(self, channel: str, key: str) -> Trace | None:
        raw = self._read()["traces"].get(f"{channel}\u0000{key}")
        return None if raw is None else Trace(**raw)

    def register_pattern(
        self,
        *,
        channel: str | None = None,
        kind: str | None = None,
        minimum_intensity: float | None = None,
        facets: dict[str, Any] | None = None,
        pattern_id: str | None = None,
    ) -> SignalPattern:
        row = SignalPattern(
            str(pattern_id or f"pattern_{uuid.uuid4().hex[:16]}"),
            channel,
            kind,
            (None if minimum_intensity is None else float(minimum_intensity)),
            dict(facets or {}),
        )
        d = self._read()
        d["patterns"][row.pattern_id] = asdict(row)
        self._write(d)
        return row

    def triggered_patterns(self) -> tuple[tuple[SignalPattern, tuple[str, ...]], ...]:
        out = []
        d = self._read()
        for raw in d["patterns"].values():
            s = SignalPattern(**raw)
            hits = self.scan(channel=s.channel, kind=s.kind, minimum_intensity=s.minimum_intensity)
            if hits:
                out.append((s, tuple(x[0].signal_id for x in hits)))
        return tuple(out)

    sniff = scan
    evaporate = cleanup
    register_scent = register_pattern
    triggered_scents = triggered_patterns


Pheromone = SignalMessage
Scent = SignalPattern
StigmergicBlackboard = CoordinationBlackboard
