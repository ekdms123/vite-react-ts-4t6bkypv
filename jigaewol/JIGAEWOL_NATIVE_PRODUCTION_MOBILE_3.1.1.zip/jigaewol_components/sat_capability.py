from __future__ import annotations

import hashlib
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

from .capability_launcher import CapabilityCandidate
from .execution_plane import ExecutionRequest
from .reflexive_breaker import CapabilityExpansionTrigger
from .registry_paths import rebase_project_paths
from .capability_registry import CapabilityRegistry


@dataclass(frozen=True)
class VendoredFile:
    relative_path: str
    git_blob_sha: str


@dataclass(frozen=True)
class PortableSATBinding:
    capability_id: str
    repository: str
    ref: str
    license_spdx: str
    vendor_root: str
    wrapper_path: str
    verified_files: tuple[str, ...]
    source_tree_sha256: str

    registered_now: bool


class PortableSATComponent:
    """Portable SAT component backed by exact GitHub upstream source bytes.

    The upstream source is intentionally a small pure-Python DPLL implementation so the
    archive has a portable local fallback. A separate PySAT adapter remains available
    in ``CapabilityAcquisitionBus`` for runtimes where ``python-sat`` is present.
    """

    CAPABILITY_ID = "github_toanphan19_tiny_sat"
    REPOSITORY = "toanphan19/tiny-sat"
    REPOSITORY_URL = "https://github.com/toanphan19/tiny-sat"
    REF = "dae82b5e993356bb80ee62ed46dffe6baa4f65f5"
    LICENSE_SPDX = "MIT"
    FAILURE_FAMILY = "dpll_boolean_satisfiability"
    @staticmethod
    def source_files() -> tuple[VendoredFile, ...]:
        return (
        VendoredFile("tinysat-python/solvers/dpll_solver.py", "3c9ab5b71c5f57e5ebe1ac5ac48b37d8bb95e8f6"),
        VendoredFile("tinysat-python/base/instance.py", "45251b576dfa2b5f8f8dd6ea78f904d23f00e10f"),
        VendoredFile("tinysat-python/base/helper.py", "7d5b66694b4d8135bd20073cdaf0ba3aa78bb1e2"),
        VendoredFile("tinysat-python/base/propagator.py", "453956e1f9d829c531fcd2d6f89635cae5ce2ec5"),
        VendoredFile("tinysat-python/base/dimacs_parser.py", "cb27fcd1cfdaf8f622c32107b55d5ab1a6d9e8de"),
        VendoredFile("LICENSE", "9f324b7ccdd958135fc9a054a65a39a45b94b102"),
    )
    TRAITS = frozenset(
        {
            "executable",
            "formal_reasoning",
            "independent_failure_family",
            "sat_solver",
            "symbolic_logic",
            "theorem_prover",
        }
    )

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root.resolve()
        self.workspace = self.project_root / "workspace"
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.vendor_root = self.project_root / "vendor" / self.CAPABILITY_ID
        self.wrapper_root = self.project_root / "external_components"
        self.wrapper_root.mkdir(parents=True, exist_ok=True)
        self.wrapper_path = self.wrapper_root / f"{self.CAPABILITY_ID}.py"
        self.registry_path = self.workspace / ".capability_registry.json"
        self.registry = CapabilityRegistry(self.registry_path, self.project_root)

    @staticmethod
    def _git_blob_sha1(data: bytes) -> str:
        return hashlib.sha1(f"blob {len(data)}\0".encode("ascii") + data).hexdigest()

    def verify_source(self) -> tuple[tuple[str, ...], str]:
        h = hashlib.sha256()
        verified: list[str] = []
        for item in self.source_files():
            path = self.vendor_root / item.relative_path
            if not path.is_file():
                raise RuntimeError(f"SAT upstream file missing: {item.relative_path}")
            data = path.read_bytes()
            actual = self._git_blob_sha1(data)
            if actual.lower() != item.git_blob_sha.lower():
                raise RuntimeError(
                    f"SAT upstream provenance mismatch for {item.relative_path}: "
                    f"expected {item.git_blob_sha}, got {actual}"
                )
            verified.append(item.relative_path)
            h.update(item.relative_path.encode("utf-8"))
            h.update(b"\0")
            h.update(hashlib.sha256(data).digest())
        return tuple(verified), h.hexdigest()

    def install(self) -> tuple[PortableSATBinding, CapabilityCandidate]:
        verified, fingerprint = self.verify_source()
        source = self._wrapper_source()
        wrapper_changed = (
            not self.wrapper_path.exists()
            or self.wrapper_path.read_text(encoding="utf-8") != source
        )
        self.wrapper_path.write_text(source, encoding="utf-8")
        registered_now = self._register(verified, fingerprint) or wrapper_changed
        binding = PortableSATBinding(
            capability_id=self.CAPABILITY_ID,
            repository=self.REPOSITORY,
            ref=self.REF,
            license_spdx=self.LICENSE_SPDX,
            vendor_root=str(self.vendor_root),
            wrapper_path=str(self.wrapper_path),
            verified_files=verified,
            source_tree_sha256=fingerprint,
            registered_now=registered_now,
        )
        candidate = CapabilityCandidate(
            capability_id=self.CAPABILITY_ID,
            failure_family=self.FAILURE_FAMILY,
            traits=self.TRAITS,
            description=(
                "Portable exact-byte GitHub DPLL upstream source with JIGAEWOL Tseitin entailment adapter"
            ),
            build_request=self._build_request,
        )
        return binding, candidate

    @staticmethod
    def _portable_id(value: str) -> str:
        return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)

    def _build_request(
        self, trigger: CapabilityExpansionTrigger, workspace_root: Path
    ) -> ExecutionRequest:
        problem = trigger.context.get("formal_problem")
        if not isinstance(problem, dict):
            raise RuntimeError("SAT capability execution requires trigger.context['formal_problem']")
        path = workspace_root / f"{self._portable_id(trigger.trigger_id)}_sat_problem.json"
        path.write_text(json.dumps(problem, ensure_ascii=False, indent=2), encoding="utf-8")
        return ExecutionRequest(
            argv=[sys.executable, str(self.wrapper_path), str(path)],
            cwd=".",
            timeout_s=30.0,
        )

    def _register(self, verified: tuple[str, ...], fingerprint: str) -> bool:
        payload = {
            "repository": self.REPOSITORY,
            "repository_url": self.REPOSITORY_URL,
            "ref": self.REF,
            "license_spdx": self.LICENSE_SPDX,
            "language": "Python",
            "failure_family": self.FAILURE_FAMILY,
            "traits": sorted(self.TRAITS),
            "binding_mode": "exact_git_bytes_vendored_portable_dpll",
            "vendor_root": str(self.vendor_root),
            "wrapper_path": str(self.wrapper_path),
            "verified_files": [asdict(x) for x in self.source_files()],
            "source_tree_sha256": fingerprint,
            "exact_git_bytes_vendored": True,
            "truth_note": (
                "Exact upstream files are retained unchanged. JIGAEWOL logic/CNF adaptation "
                "lives in the generated wrapper and jigaewol_components.boolean_cnf while upstream bytes remain exact."
            ),
        }
        newly_available = self.registry.declare_available(
            self.CAPABILITY_ID, metadata=payload
        )
        metadata_changed = self.registry.set_external(self.CAPABILITY_ID, payload)
        return newly_available or metadata_changed

    def _wrapper_source(self) -> str:
        return f'''from __future__ import annotations
import json
import random
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = PROJECT_ROOT / "vendor" / {self.CAPABILITY_ID!r} / "tinysat-python"
for path in (str(PROJECT_ROOT), str(SOURCE_ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)

from base.instance import Instance
from solvers.dpll_solver import DPLLSolver
from jigaewol_components.boolean_cnf import build_entailment_cnf, dimacs_to_tinysat_literal, validate_model

CAPABILITY_ID = {self.CAPABILITY_ID!r}
SOURCE_REF = {self.REF!r}


def solve(problem):
    cnf = build_entailment_cnf(problem)
    clauses = [list(c) for c in cnf.clauses] + [[lit] for lit in cnf.assumptions]
    encoded = [[dimacs_to_tinysat_literal(lit) for lit in clause] for clause in clauses]
    instance = Instance(list(range(cnf.var_count)), encoded)
    random.seed(0)
    solver = DPLLSolver(var_choice="input_order")
    sat = bool(solver.solve(instance))
    assignment = solver.get_assignments()[0] if sat else None
    if assignment is not None and not validate_model(cnf.clauses, cnf.assumptions, assignment):
        raise RuntimeError("SAT upstream source returned a model that fails independent CNF validation")
    model = None
    if assignment is not None:
        model = {{name: bool(assignment[var - 1]) for name, var in sorted(cnf.atom_to_var.items())}}
    entailed = not sat
    result = {{
        "capability_id": CAPABILITY_ID,
        "engine": "toanphan19/tiny-sat DPLL portable upstream source",
        "source_ref": SOURCE_REF,
        "query": "givens AND NOT conclusion",
        "sat": sat,
        "entailed": entailed,
        "model": model,
        "unsat_core": None,
        "atom_to_var": cnf.atom_to_var,
        "cnf_var_count": cnf.var_count,
        "cnf_clause_count": len(cnf.clauses) + len(cnf.assumptions),
        "conclusion": problem["conclusion"],
    }}
    if problem.get("cycle_root_claim") is not None:
        result["cycle_break_interpretation"] = (
            "closed_loop_does_not_formally_entail_root" if sat else "formal_entailment_found"
        )
    return result


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: sat_wrapper.py <formal_problem.json>")
    problem = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    print(json.dumps(solve(problem), ensure_ascii=False))
'''

# Canonical and legacy aliases.
PortableSATModule = PortableSATComponent