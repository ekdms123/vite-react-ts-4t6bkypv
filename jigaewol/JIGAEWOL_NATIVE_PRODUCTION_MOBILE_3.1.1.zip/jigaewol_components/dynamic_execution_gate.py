from __future__ import annotations

import ast
import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class DynamicExecutionAdmission:
    admission_id: str
    source_id: str
    source_sha256: str
    expected_sha256: str | None
    hash_verified: bool
    trust_level: str
    execution_mode: str
    restricted_builtins: bool
    imports_present: bool
    admitted: bool
    reason: str
    created_at: float

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class DynamicExecutionGate:
    """Content-addressed admission and receipt boundary for live Python source.

    The gate does not call dynamic Python a sandbox.  It distinguishes two
    intentional modes:
      * restricted_inprocess: no imports, allowlisted builtins supplied by caller;
      * reviewed_builder: full interpreter authority, but only after the caller
        binds execution to an expected SHA-256 and an explicit reviewed trust level.

    Every admission is append-only recorded before execution.  Hash mismatch or
    missing review evidence fails closed instead of silently falling back.
    """

    REVIEWED_TRUST = {"reviewed", "reviewed_internal", "trusted_internal"}

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.receipts = self.root / "admissions.jsonl"

    @staticmethod
    def source_sha256(source: str) -> str:
        return hashlib.sha256(source.encode("utf-8")).hexdigest()

    @staticmethod
    def _has_imports(source: str) -> bool:
        tree = ast.parse(source, mode="exec")
        return any(isinstance(node, (ast.Import, ast.ImportFrom)) for node in ast.walk(tree))

    def admit(
        self,
        *,
        source_id: str,
        source: str,
        execution_mode: str,
        trust_level: str,
        expected_sha256: str | None = None,
    ) -> DynamicExecutionAdmission:
        digest = self.source_sha256(source)
        expected = str(expected_sha256).lower() if expected_sha256 else None
        hash_verified = expected is None or digest == expected
        imports_present = self._has_imports(source)
        trust = str(trust_level or "unknown").casefold()
        mode = str(execution_mode)

        admitted = False
        reason = "unsupported_execution_mode"
        restricted = mode == "restricted_inprocess"
        if not hash_verified:
            reason = "source_hash_mismatch"
        elif mode == "restricted_inprocess":
            if imports_present:
                reason = "imports_not_allowed_in_restricted_inprocess"
            else:
                admitted = True
                reason = "restricted_source_admitted"
        elif mode == "reviewed_builder":
            if expected is None:
                reason = "reviewed_builder_requires_expected_sha256"
            elif trust not in self.REVIEWED_TRUST:
                reason = "reviewed_builder_requires_explicit_reviewed_trust"
            else:
                admitted = True
                reason = "reviewed_hash_bound_builder_admitted"

        row = DynamicExecutionAdmission(
            admission_id="dynexec_" + uuid.uuid4().hex[:20],
            source_id=str(source_id),
            source_sha256=digest,
            expected_sha256=expected,
            hash_verified=hash_verified,
            trust_level=trust,
            execution_mode=mode,
            restricted_builtins=restricted,
            imports_present=imports_present,
            admitted=admitted,
            reason=reason,
            created_at=time.time(),
        )
        with self.receipts.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row.as_mapping(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        return row

    @staticmethod
    def _execute_admitted(source: str, filename: str, namespace: dict[str, Any]) -> dict[str, Any]:
        """Single auditable dynamic-exec sink; callers must admit before reaching it."""
        code = compile(source, filename, "exec")
        exec(code, namespace, namespace)
        return namespace

    def execute(
        self,
        admission: DynamicExecutionAdmission,
        *,
        source: str,
        filename: str,
        namespace: dict[str, Any],
    ) -> dict[str, Any]:
        if not admission.admitted:
            raise PermissionError(f"dynamic source not admitted: {admission.reason}")
        digest = self.source_sha256(source)
        if digest != admission.source_sha256:
            raise PermissionError("dynamic source changed after admission")
        return self._execute_admitted(source, filename, namespace)
