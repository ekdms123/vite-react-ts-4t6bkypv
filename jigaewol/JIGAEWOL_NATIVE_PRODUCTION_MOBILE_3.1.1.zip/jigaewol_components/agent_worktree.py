from __future__ import annotations

import hashlib, json, re, subprocess, time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


def _safe(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", str(value)).strip("-.") or "work"


def _run(args: list[str], cwd: Path) -> str:
    cp=subprocess.run(args,cwd=str(cwd),capture_output=True,text=True,timeout=60)
    if cp.returncode:
        raise RuntimeError((cp.stderr or cp.stdout or "git command failed").strip())
    return (cp.stdout or "").strip()


@dataclass(frozen=True)
class WorktreeRecord:
    worktree_id: str
    repo_root: str
    path: str
    branch: str
    base_ref: str
    base_sha: str
    state: str
    worker_ref: str
    created_at: float

    def as_mapping(self) -> dict[str, Any]: return asdict(self)


class AgentWorktreeManager:
    FORMAT="jigaewol_agent_worktree_v1"
    def __init__(self, root: str | Path) -> None:
        self.root=Path(root).resolve(); self.worktrees=self.root/"worktrees"; self.worktrees.mkdir(parents=True,exist_ok=True)
        self.path=self.root/"worktrees.json"
        if not self.path.exists(): self.path.write_text(json.dumps({"format":self.FORMAT,"records":{}},indent=2)+"\n")
    def _read(self):
        d=json.loads(self.path.read_text());
        if d.get("format")!=self.FORMAT: raise ValueError("worktree registry format mismatch")
        d.setdefault("records",{}); return d
    def _write(self,d):
        t=self.path.with_suffix('.tmp'); t.write_text(json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2)+'\n'); t.replace(self.path)
    def create(self, repo_root: str | Path, task_ref: str, *, base_ref: str="HEAD", worker_ref: str="") -> WorktreeRecord:
        repo=Path(repo_root).resolve()
        top=Path(_run(["git","rev-parse","--show-toplevel"],repo)).resolve()
        if top!=repo: repo=top
        base_sha=_run(["git","rev-parse",base_ref],repo)
        token=hashlib.sha256(f"{repo}|{task_ref}|{base_sha}|{time.time_ns()}".encode()).hexdigest()[:12]
        wid=f"wt_{token}"; branch=f"jigaewol/{_safe(task_ref)[:48]}-{token[:6]}"; path=self.worktrees/wid
        _run(["git","worktree","add","-b",branch,str(path),base_ref],repo)
        row=WorktreeRecord(wid,str(repo),str(path),branch,base_ref,base_sha,"active",str(worker_ref),time.time())
        d=self._read(); d["records"][wid]=row.as_mapping(); self._write(d); return row
    def inspect(self, worktree_id: str) -> dict[str, Any]:
        d=self._read(); raw=d["records"][str(worktree_id)]; path=Path(raw["path"])
        exists=path.is_dir(); dirty=False; head=""; ahead=0
        if exists:
            dirty=bool(_run(["git","status","--porcelain"],path))
            head=_run(["git","rev-parse","HEAD"],path)
            try: ahead=int(_run(["git","rev-list","--count",f"{raw['base_sha']}..HEAD"],path) or 0)
            except Exception: ahead=-1
        return {**raw,"exists":exists,"dirty":dirty,"head_sha":head,"commits_ahead_of_base":ahead}
    def bind_worker(self, worktree_id: str, worker_ref: str) -> dict[str, Any]:
        d=self._read(); row=d["records"][str(worktree_id)]; row["worker_ref"]=str(worker_ref); self._write(d); return dict(row)
    def remove(self, worktree_id: str, *, force: bool=False) -> dict[str, Any]:
        snap=self.inspect(worktree_id)
        if snap["dirty"] and not force: raise RuntimeError("refusing to remove dirty agent worktree")
        if snap["commits_ahead_of_base"]>0 and not force: raise RuntimeError("refusing to remove agent worktree with unmerged commits")
        repo=Path(snap["repo_root"]); path=Path(snap["path"])
        if path.exists(): _run(["git","worktree","remove",*( ["--force"] if force else [] ),str(path)],repo)
        d=self._read(); d["records"][str(worktree_id)]["state"]="removed"; self._write(d)
        return {**snap,"state":"removed"}
