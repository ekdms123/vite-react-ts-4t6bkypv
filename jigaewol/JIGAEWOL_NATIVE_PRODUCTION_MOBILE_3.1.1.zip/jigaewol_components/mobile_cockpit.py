from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from .synthetic_workstation import SyntheticWorkstation


@dataclass(frozen=True)
class CockpitRoute:
    route_id: str
    kind: str
    state: str
    capabilities: tuple[str, ...]
    evidence: dict[str, Any]
    observed_at: float


@dataclass(frozen=True)
class CockpitSession:
    session_id: str
    route_id: str
    service_ref: str
    workspace_ref: str
    state: str
    created_at: float
    last_observed_at: float
    evidence_refs: tuple[str, ...]
    run_id: str = ''
    replay_cursor: int = 0


class MobileCockpit:
    """Durable session ledger for a mobile-chat control plane.

    The phone/chat is only the control surface.  A session is considered available
    when an execution body has been *observed*, not because a plugin is installed.
    Local sessions use SyntheticWorkstation and can be reopened by a fresh Python
    object.  Remote routes are registered from host observations and remain
    unavailable until a connected device/session is actually observed.
    """

    FORMAT='jigaewol_mobile_cockpit_v1'

    def __init__(self, root: str | Path) -> None:
        self.root=Path(root).resolve(); self.root.mkdir(parents=True,exist_ok=True)
        self.workstation=SyntheticWorkstation(self.root/'local_workstation')
        self.path=self.root/'cockpit.json'
        if not self.path.exists():
            self._write({'format':self.FORMAT,'routes':{},'sessions':{},'preferences':{}})
        self.register_route(
            route_id='local_synthetic_workstation',kind='local_process',state='callable',
            capabilities=('terminal','filesystem','process','persistent_workspace'),
            evidence={'workstation_root':str(self.workstation.root),'observed_local_body':True},
        )

    def _read(self) -> dict[str,Any]:
        data=json.loads(self.path.read_text(encoding='utf-8'))
        if data.get('format')!=self.FORMAT: raise ValueError('mobile cockpit format mismatch')
        data.setdefault('routes',{}); data.setdefault('sessions',{}); data.setdefault('preferences',{})
        return data

    def _write(self,data: Mapping[str,Any]) -> None:
        tmp=self.path.with_suffix('.tmp'); tmp.write_text(json.dumps(dict(data),ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8'); tmp.replace(self.path)

    def register_route(self, *, route_id: str, kind: str, state: str, capabilities: Sequence[str], evidence: Mapping[str,Any] | None=None) -> CockpitRoute:
        row=CockpitRoute(str(route_id),str(kind),str(state),tuple(dict.fromkeys(map(str,capabilities))),dict(evidence or {}),time.time())
        data=self._read() if self.path.exists() else {'format':self.FORMAT,'routes':{},'sessions':{},'preferences':{}}
        data.setdefault('routes',{})[row.route_id]=asdict(row); self._write(data); return row

    def observe_remote_desktop(self, *, installed: bool, device_ids: Sequence[str], evidence: Mapping[str,Any] | None=None) -> CockpitRoute:
        devices=tuple(dict.fromkeys(str(x) for x in device_ids if str(x).strip()))
        state='connected' if devices else ('installed_no_device' if installed else 'unavailable')
        return self.register_route(
            route_id='remote_desktop_commander',kind='remote_computer',state=state,
            capabilities=('terminal','filesystem','process','persistent_workspace','remote_compute') if devices else ('remote_compute_candidate',),
            evidence={**dict(evidence or {}),'installed':bool(installed),'connected_device_ids':devices,'connected_device_count':len(devices)},
        )

    def routes(self) -> tuple[CockpitRoute,...]:
        data=self._read(); return tuple(CockpitRoute(**x) for _,x in sorted(data['routes'].items()))

    def rehydrate_observed_routes_from(self, source_root: str | Path, *, session_id: str = '') -> dict[str, Any]:
        """Import only evidence-backed shared routes/preferences into this canonical cockpit.

        Remote *sessions* are deliberately not copied.  A historical session row is not
        proof that the remote process still exists; the host must re-observe/reattach it.
        Capability claims are also normalized against evidence so an ephemeral compute
        probe cannot masquerade as a persistent workspace.
        """
        source_path=Path(source_root).resolve()/'cockpit.json'
        report={
            'source_root':str(Path(source_root).resolve()),
            'source_present':source_path.is_file(),
            'routes_imported':0,
            'preferences_imported':0,
            'sessions_imported':0,
            'stale_sessions_removed':0,
            'stale_sessions_preserved_only_at_source':True,
            'evidence_normalization_applied':True,
        }
        if not source_path.is_file() or source_path.resolve()==self.path.resolve():
            return report
        try:
            source=json.loads(source_path.read_text(encoding='utf-8'))
        except (OSError,json.JSONDecodeError):
            return report
        if source.get('format')!=self.FORMAT:
            return report
        data=self._read()
        for route_id, raw in sorted((source.get('routes') or {}).items()):
            row=dict(raw or {}); evidence=dict(row.get('evidence') or {})
            if not evidence:
                continue
            state=str(row.get('state') or '')
            if state not in {'connected','callable','callable_public_profile','running'}:
                continue
            caps=list(dict.fromkeys(str(x) for x in (row.get('capabilities') or ()) if str(x).strip()))
            if 'persistent_workspace' in caps and evidence.get('persistent_workspace_proven') is not True:
                caps=[x for x in caps if x!='persistent_workspace']
            normalized={
                'route_id':str(route_id),
                'kind':str(row.get('kind') or 'host_route'),
                'state':state,
                'capabilities':caps,
                'evidence':evidence,
                'observed_at':float(row.get('observed_at') or 0.0),
            }
            current=(data.get('routes') or {}).get(str(route_id))
            if current is None or float(normalized['observed_at'])>=float(current.get('observed_at') or 0.0):
                data.setdefault('routes',{})[str(route_id)]=normalized
                report['routes_imported']+=1
        sid=str(session_id).strip()
        if sid:
            pref=dict((source.get('preferences') or {}).get(sid) or {})
            if pref:
                data.setdefault('preferences',{})[sid]=pref
                report['preferences_imported']=1
        # Never let an ephemeral host compute probe survive as a resumable remote
        # session.  A persistent *project* can coexist with ephemeral compute, but
        # resume requires distinct host evidence that the remote process/session lives.
        routes_now=data.get('routes') or {}
        sessions_now=dict(data.get('sessions') or {})
        for sess_id, sess in list(sessions_now.items()):
            route=dict(routes_now.get(str(sess.get('route_id') or '')) or {})
            ev=dict(route.get('evidence') or {})
            if ev.get('ephemeral_compute') is True and ev.get('persistent_session_proven') is not True:
                sessions_now.pop(sess_id, None)
                report['stale_sessions_removed']+=1
        data['sessions']=sessions_now
        self._write(data)
        return report

    def set_session_preferences(
        self, *, session_id: str, control_surface: str = 'mobile_chat',
        skip_routes: Sequence[str] = (), prefer_routes: Sequence[str] = (), reason: str = '',
    ) -> dict[str, Any]:
        sid=str(session_id).strip()
        if not sid:
            raise ValueError('session_id must be non-empty')
        row={
            'session_id':sid,
            'control_surface':str(control_surface or 'mobile_chat'),
            'skip_routes':list(dict.fromkeys(str(x) for x in skip_routes if str(x).strip())),
            'prefer_routes':list(dict.fromkeys(str(x) for x in prefer_routes if str(x).strip())),
            'reason':str(reason or ''),
            'updated_at':time.time(),
        }
        data=self._read(); data.setdefault('preferences',{})[sid]=row; self._write(data)
        return dict(row)

    def session_preferences(self, session_id: str) -> dict[str, Any]:
        sid=str(session_id).strip()
        raw=dict((self._read().get('preferences') or {}).get(sid) or {})
        return {
            'session_id':sid,
            'control_surface':str(raw.get('control_surface') or 'mobile_chat'),
            'skip_routes':list(raw.get('skip_routes') or ()),
            'prefer_routes':list(raw.get('prefer_routes') or ()),
            'reason':str(raw.get('reason') or ''),
            'updated_at':float(raw.get('updated_at') or 0.0),
        }

    def route_plan(self, session_id: str) -> dict[str, Any]:
        pref=self.session_preferences(session_id)
        skip=set(pref['skip_routes'])
        prefer={rid:i for i,rid in enumerate(pref['prefer_routes'])}
        state_rank={'connected':5,'callable':4,'callable_public_profile':4,'running':3,'installed_no_device':1,'unavailable':0}
        rows=[asdict(x) for x in self.routes() if x.route_id not in skip]
        rows.sort(key=lambda r:(
            0 if r['route_id'] in prefer else 1,
            prefer.get(r['route_id'], 10_000),
            -state_rank.get(str(r.get('state') or ''),2),
            -float(r.get('observed_at') or 0.0),
            str(r.get('route_id') or ''),
        ))
        return {
            'session_id':pref['session_id'],
            'control_surface':pref['control_surface'],
            'skipped_routes':pref['skip_routes'],
            'preferred_routes':pref['prefer_routes'],
            'eligible_routes':rows,
            'reason':pref['reason'],
            'desktop_only_route_skip_is_session_scoped':True,
        }

    def attach_remote_session(
        self, *, route_id: str, service_ref: str, workspace_ref: str,
        run_id: str = '', evidence_refs: Sequence[str] = (), state: str = 'running',
    ) -> CockpitSession:
        route_id=str(route_id).strip()
        routes={x.route_id:x for x in self.routes()}
        if route_id not in routes:
            raise KeyError(route_id)
        route=routes[route_id]
        if route.state not in {'connected','callable','callable_public_profile','running'}:
            raise RuntimeError(f'remote route is not currently callable: {route_id}:{route.state}')
        now=time.time(); sid='cockpit_'+uuid.uuid4().hex[:16]
        refs=tuple(dict.fromkeys(str(x) for x in evidence_refs if str(x).strip()))
        row=CockpitSession(sid,route_id,str(service_ref),str(workspace_ref),str(state),now,now,refs,str(run_id),0)
        data=self._read(); data['sessions'][sid]=asdict(row); self._write(data)
        return row

    def orchestration_plan(self, session_id: str) -> dict[str,Any]:
        plan=self.route_plan(session_id)
        eligible=list(plan['eligible_routes'])
        primary=next((r for r in eligible if {'remote_compute','terminal','process'} & set(r.get('capabilities') or ())), eligible[0] if eligible else None)
        browser=next((r for r in eligible if {'browser','browser_automation','interactive_browser'} & set(r.get('capabilities') or ())), None)
        sessions=[dict(x) for _,x in sorted((self._read().get('sessions') or {}).items()) if str(x.get('state') or '') in {'running','connected'}]
        return {
            **plan,
            'schema':'jigaewol_mobile_execution_orchestration_v1',
            'mobile_chat_is_control_plane':True,
            'primary_execution_route':primary,
            'browser_route':browser,
            'resumable_sessions':sessions,
            'resume_before_duplicate_start':True,
            'execution_requires_observed_route':True,
        }

    def start_local(self, argv: Sequence[str], *, workspace_ref: str='.', env: Mapping[str,str] | None=None, run_id: str='') -> CockpitSession:
        lease=self.workstation.launch_service(tuple(map(str,argv)),cwd=workspace_ref,env=dict(env or {}))
        now=time.time(); sid='cockpit_'+uuid.uuid4().hex[:16]
        row=CockpitSession(sid,'local_synthetic_workstation',lease.service_id,lease.cwd,'running',now,now,(f'pid:{lease.pid}',f'service:{lease.service_id}'),str(run_id),0)
        data=self._read(); data['sessions'][sid]=asdict(row); self._write(data); return row

    def get(self, session_id: str) -> CockpitSession:
        raw=self._read()['sessions'].get(str(session_id))
        if raw is None: raise KeyError(session_id)
        raw=dict(raw); raw.setdefault('run_id',''); raw.setdefault('replay_cursor',0)
        raw['evidence_refs']=tuple(raw.get('evidence_refs') or ())
        return CockpitSession(**raw)

    def observe(self, session_id: str) -> dict[str,Any]:
        session=self.get(session_id)
        if session.route_id!='local_synthetic_workstation':
            return {'session':asdict(session),'observed':False,'reason':'route requires host-side observer'}
        status=dict(self.workstation.service_status(session.service_ref)); now=time.time()
        state='running' if status.get('alive') else 'stopped'
        updated=CockpitSession(session.session_id,session.route_id,session.service_ref,session.workspace_ref,state,session.created_at,now,session.evidence_refs,session.run_id,session.replay_cursor)
        data=self._read(); data['sessions'][session_id]=asdict(updated); self._write(data)
        return {'session':asdict(updated),'observed':True,'status':status}

    def resume(self, session_id: str) -> dict[str,Any]:
        # Fresh MobileCockpit instances read the same service ledger, so this is a
        # real reattachment check rather than a new process disguised as a resume.
        return self.observe(session_id)

    def bind_run(self, session_id: str, *, run_id: str, replay_cursor: int=0, evidence_ref: str='') -> CockpitSession:
        session=self.get(session_id); rid=str(run_id).strip()
        if not rid: raise ValueError('run_id must be non-empty')
        refs=tuple(dict.fromkeys((*session.evidence_refs, *((str(evidence_ref),) if str(evidence_ref).strip() else ()))))
        updated=CockpitSession(session.session_id,session.route_id,session.service_ref,session.workspace_ref,session.state,session.created_at,time.time(),refs,rid,max(0,int(replay_cursor)))
        data=self._read(); data['sessions'][session_id]=asdict(updated); self._write(data); return updated

    def advance_replay_cursor(self, session_id: str, *, run_id: str, cursor: int) -> CockpitSession:
        session=self.get(session_id)
        if session.run_id != str(run_id): raise ValueError('session is bound to a different run')
        new_cursor=max(session.replay_cursor,int(cursor))
        updated=CockpitSession(session.session_id,session.route_id,session.service_ref,session.workspace_ref,session.state,session.created_at,time.time(),session.evidence_refs,session.run_id,new_cursor)
        data=self._read(); data['sessions'][session_id]=asdict(updated); self._write(data); return updated

    def replay_bound_run(self, session_id: str, runs, *, limit: int=100, advance: bool=False) -> dict[str,Any]:
        session=self.get(session_id)
        if not session.run_id:
            raise ValueError('session is not bound to a durable run')
        consumer=runs.ensure_consumer(session.run_id,consumer_id=session.session_id,accepted_sequence=session.replay_cursor)
        if consumer.accepted_sequence>session.replay_cursor:
            session=self.advance_replay_cursor(session_id,run_id=session.run_id,cursor=consumer.accepted_sequence)
        page=runs.replay(session.run_id,cursor=consumer.accepted_sequence,limit=int(limit))
        page_map=page.as_mapping() if hasattr(page,'as_mapping') else asdict(page)
        page_map['events']=[e.as_mapping() if hasattr(e,'as_mapping') else asdict(e) for e in page.events]
        updated=session
        if advance:
            for event in page.events:
                result=runs.accept_consumer_event(session.run_id,consumer_id=session.session_id,sequence=event.sequence)
                updated=self.advance_replay_cursor(session_id,run_id=session.run_id,cursor=result.state.accepted_sequence)
        return {'session':asdict(updated),'page':page_map,'advanced':bool(advance and updated.replay_cursor>session.replay_cursor),'consumer':runs.get_consumer(session.run_id,consumer_id=session.session_id).as_mapping()}

    def accept_replayed_event(self, session_id: str, runs, *, sequence: int) -> dict[str,Any]:
        session=self.get(session_id)
        if not session.run_id:
            raise ValueError('session is not bound to a durable run')
        result=runs.accept_consumer_event(session.run_id,consumer_id=session.session_id,sequence=int(sequence))
        updated=self.advance_replay_cursor(session_id,run_id=session.run_id,cursor=result.state.accepted_sequence)
        return {'session':asdict(updated),'accept':result.as_mapping()}

    def reconnect_bound_run(self, session_id: str, runs, *, max_attempts: int=5) -> dict[str,Any]:
        session=self.get(session_id)
        if not session.run_id:
            raise ValueError('session is not bound to a durable run')
        runs.ensure_consumer(session.run_id,consumer_id=session.session_id,accepted_sequence=session.replay_cursor)
        return runs.consumer_reconnect_plan(session.run_id,consumer_id=session.session_id,max_attempts=int(max_attempts))

    def record_bound_reconnect_failure(self, session_id: str, runs) -> dict[str,Any]:
        session=self.get(session_id)
        if not session.run_id:
            raise ValueError('session is not bound to a durable run')
        state=runs.record_reconnect_failure(session.run_id,consumer_id=session.session_id)
        return state.as_mapping()

    def record_bound_delivery_failure(self, session_id: str, runs, *, sequence: int, error: str, evidence_refs: Sequence[str]=(), max_attempts: int=3) -> dict[str,Any]:
        session=self.get(session_id)
        if not session.run_id:
            raise ValueError('session is not bound to a durable run')
        return runs.record_delivery_failure(session.run_id,consumer_id=session.session_id,sequence=int(sequence),error=str(error),evidence_refs=evidence_refs,max_attempts=int(max_attempts))

    def stop(self, session_id: str) -> dict[str,Any]:
        session=self.get(session_id)
        if session.route_id!='local_synthetic_workstation': raise RuntimeError('remote stop must be dispatched through its host body')
        status=dict(self.workstation.stop_service(session.service_ref)); now=time.time()
        updated=CockpitSession(session.session_id,session.route_id,session.service_ref,session.workspace_ref,'stopped',session.created_at,now,session.evidence_refs,session.run_id,session.replay_cursor)
        data=self._read(); data['sessions'][session_id]=asdict(updated); self._write(data)
        return {'session':asdict(updated),'status':status}
