from __future__ import annotations

import hashlib
import importlib.util
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from jigaewol_components.relocatable_refs import resolve_python_ref


@dataclass(frozen=True)
class ObservationGap:
    gap_id: str
    signals: tuple[str, ...]
    proposed_sensor: dict[str, Any]

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class ObserverBuilder:
    SIGNALS = {
        "prediction_execution_mismatch": "trace_comparator",
        "stalled_tool_information": "alternate_surface_probe",
        "unrepresented_observation": "schema_extension_sensor",
        "user_correction": "correction_replay_sensor",
        "past_success_new_failure": "transfer_failure_probe",
        "source_result_disagreement": "source_outcome_graph",
    }

    def __init__(self, root: str | Path | None = None) -> None:
        self.root = Path(root) if root is not None else None
        if self.root is not None:
            self.root.mkdir(parents=True, exist_ok=True)
            (self.root / "generated_sensors").mkdir(parents=True, exist_ok=True)
            self.registry_path = self.root / "sensor_registry.json"
            if not self.registry_path.exists():
                self.registry_path.write_text("{}\n", encoding="utf-8")
        else:
            self.registry_path = None

    @classmethod
    def detect_gap(cls, *, signals: Iterable[str], context: Mapping[str, Any] | None = None) -> ObservationGap | None:
        matched = tuple(dict.fromkeys(str(x) for x in signals if str(x) in cls.SIGNALS))
        if not matched:
            return None
        sensor_types = tuple(dict.fromkeys(cls.SIGNALS[x] for x in matched))
        seed = f"{matched}|{dict(context or {})}"
        return ObservationGap(
            gap_id="gap_" + hashlib.sha256(seed.encode()).hexdigest()[:20],
            signals=matched,
            proposed_sensor={"sensor_types": sensor_types, "context": dict(context or {})},
        )

    @staticmethod
    def propose_sensor(gap: ObservationGap) -> dict[str, Any]:
        return {"gap_id": gap.gap_id, **gap.proposed_sensor, "materialization_required": True}

    def materialize(self, sensor: Mapping[str, Any], *, program_ref: str) -> dict[str, Any]:
        row = {**dict(sensor), "program_ref": str(program_ref), "materialized": True}
        if self.root is None:
            return row
        gap_id = str(row.get("gap_id") or hashlib.sha256(json.dumps(row, sort_keys=True, default=str).encode()).hexdigest()[:12])
        path = self.root / "generated_sensors" / f"{gap_id}.py"
        source = (
            "from __future__ import annotations\n"
            "def run(observation):\n"
            "    row = dict(observation or {})\n"
            f"    return {{'gap_id': {gap_id!r}, 'sensor_types': {tuple(row.get('sensor_types') or ())!r}, "
            "'observed_keys': tuple(sorted(row.keys())), 'observation': row}\n"
        )
        path.write_text(source, encoding="utf-8")
        materialized = {**row, "program_ref": f"python:{path}", "source_sha256": hashlib.sha256(source.encode()).hexdigest()}
        self.register(materialized)
        return materialized

    def register(self, sensor: Mapping[str, Any]) -> dict[str, Any]:
        row = dict(sensor)
        if self.registry_path is None:
            return row
        try:
            data = json.loads(self.registry_path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            data = {}
        data[str(row.get("gap_id") or row.get("program_ref") or len(data))] = row
        tmp = self.registry_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(self.registry_path)
        return row

    def execute(self, sensor: Mapping[str, Any], observation: Mapping[str, Any]) -> dict[str, Any]:
        ref = str(sensor.get("program_ref") or "")
        if not ref.startswith("python:"):
            raise RuntimeError(f"sensor is not executable: {ref}")
        path = resolve_python_ref(ref, roots=((self.root or Path.cwd()),))
        spec = importlib.util.spec_from_file_location(
            "_jigaewol_sensor_" + hashlib.sha256(str(path).encode()).hexdigest()[:12], path
        )
        if spec is None or spec.loader is None:
            raise RuntimeError(f"cannot load sensor: {path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        runner = getattr(module, "run", None)
        if not callable(runner):
            raise RuntimeError(f"sensor has no run(observation): {path}")
        result = runner(dict(observation))
        return {
            "executed": True,
            "program_ref": ref,
            "gap_id": str(sensor.get("gap_id") or ""),
            "result": dict(result) if isinstance(result, Mapping) else result,
        }
