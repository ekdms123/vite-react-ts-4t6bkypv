from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Mapping


class RepresentationLineage:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "lineage.jsonl"
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")

    def record(self, row: Mapping[str, Any]) -> dict[str, Any]:
        payload = {**dict(row), "recorded_at": time.time()}
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n")
        return payload
