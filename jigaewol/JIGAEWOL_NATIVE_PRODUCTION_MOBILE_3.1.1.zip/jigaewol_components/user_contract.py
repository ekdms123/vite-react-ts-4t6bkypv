from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


OPERATIONAL_CONTRACT_TEXT = (
    "현재 사용자 원문이 지개월 내부의 최상위 목적 권위다. 모든 사용자 요구는 전달되거나 사용자가 바꿀 때까지 살아 있다. "
    "지개월과 모델은 그 목적을 이루기 위해 교체 가능한 수단으로 작동한다. 현재 경로가 멈추면 표현·도구·실행 몸·구조를 "
    "확장하거나 교체한다. 사실과 실행 상태는 관측 증거에 맞춰 표시한다."
)


@dataclass(frozen=True)
class UserObjectiveContract:
    contract_id: str
    version: int
    data: dict[str, Any]

    @property
    def top_operational_anchor(self) -> str:
        return "exact_current_user_command"

    @property
    def command_priority(self) -> str:
        return "USER>JIGAEWOL>MODEL"

    @property
    def enforcement_enabled(self) -> bool:
        # Compatibility surface: alignment observations feed repair and expansion.
        return True

    def alignment_findings(self, objective: str, metadata: dict[str, Any] | None) -> tuple[str, ...]:
        """Observe destination fidelity and convert drift into repair signals."""
        row = dict(metadata or {})
        findings: list[str] = []
        for key in ("objective", "objective_anchor", "effective_objective", "rewritten_objective"):
            value = row.get(key)
            if value not in (None, "") and str(value) != str(objective):
                findings.append(f"destination_drift:{key}")
        if row.get("destination_fidelity") is False:
            findings.append("destination_fidelity_needs_repair")
        if row.get("live_requirements_preserved") is False:
            findings.append("live_requirement_state_needs_repair")
        if row.get("route_space_expanded_when_needed") is False:
            findings.append("route_expansion_needs_repair")
        if row.get("truth_labels_evidence_bound") is False:
            findings.append("truth_labeling_needs_repair")
        return tuple(dict.fromkeys(findings))

    @staticmethod
    def release_blocking_findings(findings: tuple[str, ...] | list[str]) -> tuple[str, ...]:
        """Return contract findings that may not remain advisory.

        Destination replacement, requirement loss and truth-label drift are authority
        violations.  They cannot be downgraded to telemetry while the candidate/result
        continues to carry completion authority.
        """
        blocking_prefixes = (
            "destination_drift:",
            "destination_fidelity_needs_repair",
            "live_requirement_state_needs_repair",
            "truth_labeling_needs_repair",
        )
        return tuple(
            str(item) for item in findings
            if any(str(item).startswith(prefix) for prefix in blocking_prefixes)
        )

    def snapshot(self) -> dict[str, Any]:
        return copy.deepcopy(self.data)


def default_contract_path() -> Path:
    return Path(__file__).resolve().parents[1] / "USER_OBJECTIVE_CONTRACT.json"


def load_user_objective_contract(path: Path | None = None) -> UserObjectiveContract:
    p = (path or default_contract_path()).resolve()
    data = json.loads(p.read_text(encoding="utf-8"))
    return UserObjectiveContract(
        contract_id=str(data.get("contract_id", "jigaewol-user-authority")),
        version=int(data.get("version", 1)),
        data=data,
    )
