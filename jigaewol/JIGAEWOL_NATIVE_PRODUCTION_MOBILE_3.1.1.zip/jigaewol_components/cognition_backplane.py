from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

from .cognitive_diversity import (
    ArchitectureProfile,
    CognitiveDiversityEngine,
    CognitiveWorld,
    ComputeEnvironmentProfile,
    ThoughtMethodProfile,
)
from .host_syscall import HostSyscallIntent, HostSyscallQueue, HostSyscallReceipt


@dataclass(frozen=True)
class ForgeCandidate:
    candidate_id: str
    method: dict[str, Any]
    environment: dict[str, Any]
    architecture: dict[str, Any]
    rationale: str = ""
    source: str = "generative_engine"
    facets: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ForgeCommit:
    syscall_id: str
    source: str
    candidates: tuple[ForgeCandidate, ...]
    evidence: dict[str, Any]
    committed_at: float


class CognitionBackplane:
    """Dispatches reasoning world exploration tasks via decoupled execution queues.

    Connects generative ideation with formal verification without imposing
    rigid schema pre-filtering on creative generation.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.syscalls = HostSyscallQueue(self.root / "syscalls")
        self.commit_path = self.root / "commits.json"
        if not self.commit_path.exists():
            self.commit_path.write_text("{}", encoding="utf-8")

    def request_candidates(
        self,
        objective: str,
        *,
        archive_summary: Sequence[dict[str, Any]] = (),
        requested_count: int | None = None,
        outside_taxonomy_required: bool = False,
        constraints: dict[str, Any] | None = None,
    ) -> HostSyscallIntent:
        return self.syscalls.request(
            "cognition.generate_worlds",
            capability_need="creative_reasoning_generation",
            arguments={
                "objective": str(objective),
                "archive_summary": list(archive_summary),
                "requested_count": (None if requested_count is None else int(requested_count)),
                "outside_taxonomy_required": bool(outside_taxonomy_required),
                "constraints": dict(constraints or {}),
            },
            failure_family="generative_component",
        )

    def commit_candidates(
        self,
        syscall_id: str,
        *,
        source: str,
        raw_candidates: Iterable[dict[str, Any]],
        evidence: dict[str, Any] | None = None,
    ) -> tuple[HostSyscallReceipt, ForgeCommit]:
        candidates: list[ForgeCandidate] = []
        for raw in raw_candidates:
            method = dict(raw.get("method") or {})
            environment = dict(raw.get("environment") or {})
            architecture = dict(raw.get("architecture") or {})
            # Named schemas are adapters, not admission gates. A candidate may arrive
            # as an arbitrary representation and receives compatibility wrappers only
            # when the downstream diversity engine needs them.
            free_representation = raw.get("representation") or raw.get("description") or raw.get("idea") or raw.get("content")
            if not method:
                method = {"representation": "host_defined", "program": str(free_representation or raw)}
            if not environment:
                environment = {"substrate": "unspecified", "builder": "runtime_adapter"}
            if not architecture:
                architecture = {"control_topology": "unspecified", "memory_topology": "unspecified", "self_model_topology": "unspecified"}
            candidates.append(
                ForgeCandidate(
                    candidate_id=str(raw.get("candidate_id") or f"forge_{uuid.uuid4().hex[:12]}"),
                    method=method,
                    environment=environment,
                    architecture=architecture,
                    rationale=str(raw.get("rationale") or ""),
                    source=str(raw.get("source") or source),
                    facets=dict(raw.get("facets") or {}),
                )
            )
        if not candidates:
            receipt = self.syscalls.complete(
                syscall_id,
                operation="cognition.generate_worlds",
                executor=source,
                success=False,
                evidence={"reason": "no valid candidates", **dict(evidence or {})},
            )
            raise ValueError("no valid cognitive candidates returned")
        ev = {"candidate_count": len(candidates), **dict(evidence or {})}
        receipt = self.syscalls.complete(
            syscall_id,
            operation="cognition.generate_worlds",
            executor=str(source),
            success=True,
            evidence=ev,
        )
        commit = ForgeCommit(syscall_id, str(source), tuple(candidates), ev, time.time())
        data = json.loads(self.commit_path.read_text(encoding="utf-8"))
        data[syscall_id] = asdict(commit)
        self.commit_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return receipt, commit

    @staticmethod
    def worlds_from_commit(
        diversity_engine: CognitiveDiversityEngine,
        commit: ForgeCommit,
        *,
        generation: int,
        parents: Sequence[str] = (),
    ) -> tuple[CognitiveWorld, ...]:
        worlds = []
        for c in commit.candidates:
            m = c.method
            e = c.environment
            a = c.architecture
            worlds.append(
                diversity_engine.make_world(
                    generation=generation,
                    parents=parents,
                    method=ThoughtMethodProfile(
                        str(m.get("method_id") or c.candidate_id),
                        str(m.get("representation") or "invented"),
                        str(m.get("search_operator") or "generated"),
                        str(m.get("program") or m.get("description") or c.rationale),
                        {**dict(m.get("facets") or {}), **c.facets, "forge_source": c.source},
                    ),
                    environment=ComputeEnvironmentProfile(
                        str(e.get("environment_id") or f"env_{c.candidate_id}"),
                        str(e.get("substrate") or "host"),
                        str(e.get("builder") or "generated"),
                        {k: v for k, v in e.items() if k not in {"environment_id", "substrate", "builder"}},
                    ),
                    architecture=ArchitectureProfile(
                        str(a.get("architecture_id") or f"arch_{c.candidate_id}"),
                        str(a.get("control_topology") or "emergent"),
                        str(a.get("memory_topology") or "episodic"),
                        str(a.get("self_model_topology") or "adaptive"),
                        {
                            k: v
                            for k, v in a.items()
                            if k not in {"architecture_id", "control_topology", "memory_topology", "self_model_topology"}
                        },
                    ),
                )
            )
        return tuple(worlds)
