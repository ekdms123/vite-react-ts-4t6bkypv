from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence

from .synthetic_workstation import SyntheticWorkstation
from .worker_truth import WorkerTruth


@dataclass(frozen=True)
class WorkerSession:
    worker_id: str
    provider_id: str
    execution_kind: str
    context_ref: str
    session_ref: str
    started_at: float
    metadata: dict[str, Any]
    agent_backed: bool = False

    def truth(self, *, receipt_ref: str = "", result_return_path_observed: bool = False) -> WorkerTruth:
        return WorkerTruth(
            execution_kind=self.execution_kind,
            context_ref=self.context_ref,
            provider_ref=self.provider_id,
            execution_receipt_ref=str(receipt_ref or self.session_ref),
            state="running",
            agent_backed=bool(self.agent_backed),
            result_return_path_observed=bool(result_return_path_observed),
        )

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class WorkerProvider(Protocol):
    provider_id: str
    execution_kind: str

    def start(self, *, objective: str, context: Mapping[str, Any] | None = None) -> WorkerSession: ...
    def status(self, session: WorkerSession) -> Mapping[str, Any]: ...
    def stop(self, session: WorkerSession) -> Mapping[str, Any]: ...


class LocalProcessWorkerProvider:
    """Real OS-process worker/session provider built on SyntheticWorkstation.

    This provider proves *process independence*, not cognitive independence.  The
    child has its own PID/session and context file, so it is a legitimate process
    worker.  It becomes a model/agent worker only when ``argv`` launches an actual
    model/agent runtime; the truth layer deliberately does not infer that from a
    process name.
    """

    provider_id = "local_process_worker"
    execution_kind = "process"

    def __init__(self, root: str | Path, *, argv: Sequence[str]) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.workstation = SyntheticWorkstation(self.root / "workstation")
        self.argv = tuple(str(x) for x in argv)
        if not self.argv:
            raise ValueError("worker argv cannot be empty")
        self.sessions_dir = self.root / "sessions"
        self.sessions_dir.mkdir(exist_ok=True)

    def start(self, *, objective: str, context: Mapping[str, Any] | None = None) -> WorkerSession:
        worker_id = "worker_" + uuid.uuid4().hex[:16]
        session_dir = self.sessions_dir / worker_id
        session_dir.mkdir(parents=True, exist_ok=False)
        context_path = session_dir / "context.json"
        result_path = session_dir / "result.json"
        context_payload = {
            "worker_id": worker_id,
            "objective": str(objective),
            "context": dict(context or {}),
            "created_at": time.time(),
        }
        context_path.write_text(json.dumps(context_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        env = {
            "JIGAEWOL_WORKER_ID": worker_id,
            "JIGAEWOL_WORKER_CONTEXT": str(context_path),
            "JIGAEWOL_WORKER_RESULT": str(result_path),
        }
        lease = self.workstation.launch_service(self.argv, env=env)
        session = WorkerSession(
            worker_id=worker_id,
            provider_id=self.provider_id,
            execution_kind=self.execution_kind,
            context_ref=str(context_path),
            session_ref=lease.service_id,
            started_at=lease.started_at,
            metadata={"pid": lease.pid, "argv": lease.argv, "cwd": lease.cwd, "result_path": str(result_path)},
            agent_backed=False,
        )
        (session_dir / "session.json").write_text(
            json.dumps(session.as_mapping(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return session

    def status(self, session: WorkerSession) -> Mapping[str, Any]:
        row = dict(self.workstation.service_status(session.session_ref))
        result_path = Path(str(session.metadata.get("result_path") or ""))
        result = None
        if result_path.is_file():
            try:
                result = json.loads(result_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                result = {"success": False, "error": "invalid worker result envelope"}
        alive = bool(row.get("alive"))
        row["worker_id"] = session.worker_id
        row["worker_truth"] = session.truth(
            receipt_ref=session.session_ref,
            result_return_path_observed=result is not None,
        ).as_mapping()
        row["complete"] = bool(result is not None or not alive)
        if result is not None:
            row["success"] = result.get("success") is True
            row["result"] = result
        elif not alive:
            row["success"] = False
            row["result"] = {"success": False, "error": "worker exited without result envelope"}
        return row

    def stop(self, session: WorkerSession) -> Mapping[str, Any]:
        row = dict(self.workstation.stop_service(session.session_ref))
        row["worker_id"] = session.worker_id
        row["worker_truth"] = WorkerTruth(
            execution_kind=session.execution_kind,
            context_ref=session.context_ref,
            provider_ref=session.provider_id,
            execution_receipt_ref=session.session_ref,
            state="stopped",
            agent_backed=bool(session.agent_backed),
            result_return_path_observed=False,
        ).as_mapping()
        return row
