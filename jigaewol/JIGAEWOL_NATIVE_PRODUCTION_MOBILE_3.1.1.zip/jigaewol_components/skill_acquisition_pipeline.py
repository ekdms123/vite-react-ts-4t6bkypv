from __future__ import annotations

import json
import os
import shutil
import sys
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .agent_skill_registry import AgentSkillRegistry, inspect_agent_skill
from .execution_plane import ExecutionPlane, ExecutionRequest


@dataclass(frozen=True)
class SkillAcquisitionResult:
    skill_id: str
    name: str
    state: str
    installed_path: str
    package_sha256: str
    smoke_receipt_id: str
    smoke_success: bool
    promotion_evidence_ref: str
    stages: tuple[str, ...]
    acquired_at: float

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class SkillAcquisitionPipeline:
    """Evidence-bound bridge from inspected Agent Skill to active capability.

    It composes the existing registry rather than creating a parallel skill system.
    Instruction-only packages can be promoted after structural inspection.  Packages
    carrying scripts must execute an observed smoke script successfully first.
    """

    def __init__(self, root: str | Path) -> None:
        self.root=Path(root).resolve(); self.root.mkdir(parents=True,exist_ok=True)
        self.registry=AgentSkillRegistry(self.root/'registry')
        self.exec_root=self.root/'smoke'; self.exec_root.mkdir(exist_ok=True)

    @staticmethod
    def _script_argv(path: Path, argv: Iterable[str]) -> list[str]:
        suffix=path.suffix.casefold()
        args=list(map(str,argv))
        if suffix == '.py': return [sys.executable,str(path),*args]
        if suffix in {'.js','.mjs','.cjs'}:
            node=shutil.which('node')
            if not node: raise RuntimeError('node runtime unavailable')
            return [node,str(path),*args]
        if suffix in {'.sh','.bash'}:
            shell=shutil.which('bash') or shutil.which('sh')
            if not shell: raise RuntimeError('shell runtime unavailable')
            return [shell,str(path),*args]
        if os.access(path,os.X_OK): return [str(path),*args]
        raise ValueError(f'no smoke adapter for script suffix: {suffix or "<none>"}')

    def ingest_local_skill(
        self,
        source: str | Path,
        *,
        source_ref: str = '',
        rights_basis: str = 'observed_source_context',
        smoke_script: str | None = None,
        smoke_argv: Iterable[str] = (),
        timeout_s: float = 20.0,
    ) -> SkillAcquisitionResult:
        inspected=inspect_agent_skill(source)
        receipt=self.registry.install(source,source_ref=source_ref,license_hint=rights_basis)
        stages=['discovered','inspected','installed']
        smoke_receipt_id=''
        smoke_success=False
        evidence_ref=f'package-sha256:{receipt.package_sha256}'
        if inspected.scripts:
            script=smoke_script or inspected.scripts[0]
            if script not in inspected.scripts:
                raise ValueError('smoke script is not declared by skill package')
            installed_root=Path(receipt.installed_path)
            run_id='skillrun_'+uuid.uuid4().hex[:12]
            workspace=self.exec_root/run_id
            plane=ExecutionPlane(workspace)
            target=workspace/'package'
            shutil.copytree(installed_root,target)
            script_path=(target/script).resolve()
            if target.resolve() not in script_path.parents:
                raise ValueError('smoke script escaped package root')
            argv=self._script_argv(script_path,smoke_argv)
            # Drop inherited environment before the script starts. The execution is
            # still host-container scoped, but package smoke receives no ambient
            # credentials merely because they exist in the parent process.
            env_bin=shutil.which('env')
            if env_bin:
                path=os.environ.get('PATH','')
                argv=[env_bin,'-i',f'PATH={path}',*argv]
            exec_receipt=plane.run_resilient(ExecutionRequest(argv,timeout_s=timeout_s))
            smoke_receipt_id=exec_receipt.receipt_id
            smoke_success=exec_receipt.exit_code == 0
            stages.append('smoke_executed')
            evidence_ref=f'execution-receipt:{exec_receipt.receipt_id}'
            if not smoke_success:
                return SkillAcquisitionResult(
                    receipt.skill_id,receipt.name,'candidate',receipt.installed_path,receipt.package_sha256,
                    smoke_receipt_id,False,evidence_ref,tuple(stages),time.time(),
                )
            stages.append('smoke_successful')
        promoted=self.registry.promote(receipt.skill_id,evidence_ref=evidence_ref,rights_basis=rights_basis)
        stages.extend(['execution_observed', 'active'] if inspected.scripts else ['instruction_loaded', 'execution_not_applicable'])
        return SkillAcquisitionResult(
            receipt.skill_id,receipt.name,str(promoted.get('state') or 'active') if inspected.scripts else 'instruction_loaded',receipt.installed_path,
            receipt.package_sha256,smoke_receipt_id,smoke_success,evidence_ref,tuple(stages),time.time(),
        )
