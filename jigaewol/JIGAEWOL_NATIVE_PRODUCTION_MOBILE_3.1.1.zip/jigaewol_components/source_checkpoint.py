from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class SourceCheckpoint:
    checkpoint_id: str
    source_id: str
    section: str
    payload: dict[str, Any]
    status: str
    created_at: float
    payload_sha256: str


class SourceCheckpointStore:
    """Persists partial source extraction progress so interruptions do not erase discoveries."""

    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _sha(payload: dict[str, Any]) -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def save(
        self,
        source_id: str,
        section: str,
        payload: dict[str, Any],
        *,
        status: str = "partial",
    ) -> SourceCheckpoint:
        sha = self._sha(payload)
        stable = hashlib.sha256(f"{source_id}|{section}|{sha}".encode()).hexdigest()[:16]
        checkpoint = SourceCheckpoint(
            checkpoint_id=f"source_{stable}",
            source_id=source_id,
            section=section,
            payload=payload,
            status=status,
            created_at=time.time(),
            payload_sha256=sha,
        )
        path = self.root / f"{checkpoint.checkpoint_id}.json"
        path.write_text(json.dumps(asdict(checkpoint), ensure_ascii=False, indent=2), encoding="utf-8")
        return checkpoint

    def list(self, source_id: str | None = None) -> tuple[SourceCheckpoint, ...]:
        out = []
        for path in sorted(self.root.glob("source_*.json")):
            row = json.loads(path.read_text(encoding="utf-8"))
            item = SourceCheckpoint(**row)
            if source_id is None or item.source_id == source_id:
                out.append(item)
        return tuple(sorted(out, key=lambda x: x.created_at))

    def resume_context(self, source_id: str) -> dict[str, Any]:
        checkpoints = self.list(source_id)
        return {
            "source_id": source_id,
            "completed_sections": [x.section for x in checkpoints if x.status == "complete"],
            "partial_sections": [x.section for x in checkpoints if x.status != "complete"],
            "checkpoints": [asdict(x) for x in checkpoints],
        }

