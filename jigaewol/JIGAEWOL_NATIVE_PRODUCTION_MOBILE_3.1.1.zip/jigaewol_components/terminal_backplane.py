from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .external_bodies import BodyEvidence, ExternalBodyRegistry
from .execution_plane import ExecutionReceipt
from .host_syscall import HostSyscallIntent, HostSyscallQueue, HostSyscallReceipt


@dataclass(frozen=True)
class TerminalExecutionEvidence:
    syscall_id: str
    body_id: str
    executor: str
    exit_code: int
    stdout: str
    stderr: str
    success: bool


class TerminalBackplane:
    """Execution backplane managing decoupled terminal device execution.

    The runtime emits durable terminal execution intents while host bodies execute
    them and report empirical exit-code receipts. Status is updated strictly via verified outcomes.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.syscalls = HostSyscallQueue(self.root / "syscalls")
        self.bodies = ExternalBodyRegistry(self.root / "bodies.json")

    def request(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout_s: float = 120.0,
        preferred_body: str | None = None,
    ) -> HostSyscallIntent:
        if not str(command).strip():
            raise ValueError("terminal command must be non-empty")
        return self.syscalls.request(
            "terminal.execute",
            capability_need="persistent_terminal",
            arguments={
                "command": str(command),
                "cwd": cwd,
                "timeout_s": float(timeout_s),
                "preferred_body": preferred_body,
            },
            failure_family="external_terminal",
        )

    def commit_execution(
        self,
        syscall_id: str,
        *,
        body_id: str,
        executor: str,
        exit_code: int,
        stdout: str = "",
        stderr: str = "",
        capabilities: tuple[str, ...] = ("terminal", "filesystem", "process_execution"),
        metadata: dict[str, Any] | None = None,
    ) -> tuple[HostSyscallReceipt, BodyEvidence, TerminalExecutionEvidence]:
        success = int(exit_code) == 0
        evidence = {
            "exit_code": int(exit_code),
            "stdout": str(stdout),
            "stderr": str(stderr),
            **dict(metadata or {}),
        }
        receipt = self.syscalls.complete(
            syscall_id,
            operation="terminal.execute",
            executor=str(executor),
            success=success,
            evidence=evidence,
        )
        body = self.bodies.upsert(
            str(body_id),
            kind="terminal_backplane",
            executor=str(executor),
            state="executed_successfully" if success else "execution_failed",
            capabilities=capabilities,
            evidence=evidence,
            evidence_strength=1.0 if success else 0.35,
        )
        return receipt, body, TerminalExecutionEvidence(
            syscall_id=syscall_id,
            body_id=str(body_id),
            executor=str(executor),
            exit_code=int(exit_code),
            stdout=str(stdout),
            stderr=str(stderr),
            success=success,
        )

    def commit_execution_receipt(
        self,
        syscall_id: str,
        *,
        body_id: str,
        executor: str,
        receipt: ExecutionReceipt,
        capabilities: tuple[str, ...] = ("terminal", "filesystem", "process_execution"),
        metadata: dict[str, Any] | None = None,
    ) -> tuple[HostSyscallReceipt, BodyEvidence, TerminalExecutionEvidence]:
        """Commit an ExecutionPlane result with complete execution receipts."""
        bridge_metadata = {
            "execution_receipt_id": receipt.receipt_id,
            "execution_started_at": receipt.started_at,
            "execution_finished_at": receipt.finished_at,
            **dict(metadata or {}),
        }
        return self.commit_execution(
            syscall_id,
            body_id=body_id,
            executor=executor,
            exit_code=receipt.exit_code,
            stdout=receipt.stdout,
            stderr=receipt.stderr,
            capabilities=capabilities,
            metadata=bridge_metadata,
        )
