from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from typing import Any, Iterable, Mapping

from .host_syscall_pump import HostSyscallPump, PumpRequest
from .search_portfolio_engine import SearchPortfolioEngine


@dataclass(frozen=True)
class BrowserJobDefinition:
    """Portable browser job distilled from code/docs discovered by another capability."""

    url: str
    action: str = "screenshot"
    image_format: str = "png"
    full_page: bool = True
    read_only: bool = True
    provenance: tuple[str, ...] = ()

    def as_payload(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class HostActionEnvelope:
    """Concrete host-dispatch contract derived from a pending JIGAEWOL syscall.

    The bridge never pretends that emitting an envelope executed anything.  A
    syscall becomes complete only after an observed host result is ingested.
    """

    syscall_id: str
    operation: str
    capability_need: str
    executor_family: str
    preferred_executors: tuple[str, ...]
    payload: dict[str, Any]
    required: bool


class HostExecutionBridge:
    """Translate pending JIGAEWOL syscalls into executable host action envelopes.

    This is deliberately host-neutral: ChatGPT, Work, Codex, or another host can
    bind the executor names to its real tool surface.  Execution truth returns
    through ``ingest`` and therefore through HostSyscallPump.apply_results().
    """

    SEARCH_EXECUTORS: Mapping[str, tuple[str, ...]] = {
        "first_party": ("native.web", "Firecrawl", "TinyFish"),
        "web_current": ("native.web", "Firecrawl", "TinyFish"),
        "community": ("native.web", "Firecrawl", "TinyFish"),
        "social_recommendation": ("Opera_Browser_Connector", "TinyFish", "native.web"),
        "code_ecosystem": ("GitHub", "native.web", "Firecrawl"),
        "research": ("Consensus", "Elicit", "SciSpace", "native.web"),
        "creator_graph": ("Opera_Browser_Connector", "TinyFish", "native.web"),
        "multilingual": ("native.web", "Firecrawl", "TinyFish"),
    }

    def __init__(self, pump: HostSyscallPump) -> None:
        self.pump = pump

    @staticmethod
    def _source_family(req: PumpRequest) -> str:
        need = str(req.capability_need)
        if need.startswith("information_discovery:"):
            return need.split(":", 1)[1]
        return str(req.arguments.get("source_family") or "web_current")

    def envelope(self, req: PumpRequest) -> HostActionEnvelope:
        op = str(req.operation)
        args = dict(req.arguments)
        if op == "search.execute_family":
            family = self._source_family(req)
            query_program = dict(args.get("query_program") or {})
            # Dialects describe a strategy; they are not executable query text.
            # Compile concrete family-native search strings rather than submitting
            # Python dict representations to the search provider.
            compiled_queries = SearchPortfolioEngine.compile_concrete_queries(
                str(args.get("objective") or ""), family,
                provider_hint=str(args.get("provider_hint") or ""),
            )
            queries = tuple(row["query"] for row in compiled_queries)
            payload = {
                "objective": str(args.get("objective") or ""),
                "source_family": family,
                "queries": queries,
                "concrete_query_dialects": [dict(x) for x in compiled_queries],
                "query_program": query_program,
                "strategy": {k: v for k, v in args.items() if k not in {"intent_capsule", "query_program"}},
            }
            return HostActionEnvelope(
                syscall_id=req.syscall_id,
                operation=op,
                capability_need=req.capability_need,
                executor_family="search",
                preferred_executors=self.SEARCH_EXECUTORS.get(family, ("native.web", "Firecrawl", "TinyFish")),
                payload=payload,
                required=req.required,
            )
        if op == "search.discover_surfaces":
            return HostActionEnvelope(req.syscall_id, op, req.capability_need, "search_discovery",
                                      ("Plugin_Management", "native.web", "Firecrawl", "TinyFish"), args, req.required)
        if op.startswith("capability."):
            return HostActionEnvelope(req.syscall_id, op, req.capability_need, "capability",
                                      ("Plugin_Management", "GitHub", "container"), args, req.required)
        if op.startswith("browser."):
            return HostActionEnvelope(req.syscall_id, op, req.capability_need, "browser",
                                      ("Opera_Browser_Connector", "TinyFish", "Firecrawl"), args, req.required)
        if op.startswith("cognition."):
            return HostActionEnvelope(req.syscall_id, op, req.capability_need, "cognition",
                                      ("ChatGPT.Work.subagent", "Codex.subagent", "Manus", "host_model"), args, req.required)
        if op.startswith("automation."):
            return HostActionEnvelope(req.syscall_id, op, req.capability_need, "automation",
                                      ("ChatGPT.Automations",), args, req.required)
        return HostActionEnvelope(req.syscall_id, op, req.capability_need, "generic",
                                  ("container", "native.python"), args, req.required)


    @staticmethod
    def browser_job_from_materialization(*, url: str, provenance: Iterable[str] = (),
                                         image_format: str = "png", full_page: bool = True) -> BrowserJobDefinition:
        """Create a host-neutral browser job from a materialized code capability.

        This is the seam used when local code can define an operation but the
        local sandbox lacks network access.  The behavior is preserved while
        execution is delegated to a network-capable browser actuator.
        """
        if not str(url).startswith(("http://", "https://")):
            raise ValueError("browser job requires an http(s) URL")
        return BrowserJobDefinition(
            url=str(url), image_format=str(image_format), full_page=bool(full_page),
            provenance=tuple(str(x) for x in provenance if str(x).strip()),
        )

    def register_browser_job(self, job: BrowserJobDefinition, *, parent_syscall_id: str = "") -> HostActionEnvelope:
        """Register a browser job as a real child syscall before host dispatch.

        This closes the lineage gap between a code/materialization result and the
        external browser actuator.  Registration is still not execution; the child
        completes only after ``ingest`` observes a host result.
        """
        if "browser" not in self.pump.queues:
            raise KeyError("browser syscall queue is not bound")
        payload = job.as_payload()
        payload["parent_syscall_id"] = str(parent_syscall_id)
        job_material = json.dumps(job.as_payload(), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        payload["job_sha256"] = hashlib.sha256(job_material.encode("utf-8")).hexdigest()
        payload["goal"] = (
            f"Open {job.url} and capture a {'full-page' if job.full_page else 'viewport'} "
            f"{job.image_format.upper()} screenshot. Read-only: do not log in, submit forms, or modify data."
        )
        for existing in self.pump.requests():
            if (existing.operation == "browser.execute_job"
                    and str(existing.arguments.get("parent_syscall_id") or "") == str(parent_syscall_id)
                    and str(existing.arguments.get("job_sha256") or "") == payload["job_sha256"]):
                return self.envelope(existing)
        intent = self.pump.queues["browser"].request(
            "browser.execute_job",
            capability_need="network_browser:screenshot",
            arguments=payload,
            failure_family="browser_execution",
        )
        parent_required = False
        if parent_syscall_id:
            parent = next((row for row in self.pump.requests() if row.syscall_id == str(parent_syscall_id)), None)
            parent_required = bool(parent.required) if parent is not None else False
        req = self.pump.register("browser", intent, required=parent_required)
        self.pump.flush()
        return self.envelope(req)

    @staticmethod
    def browser_action_for_job(job: BrowserJobDefinition, *, parent_syscall_id: str = "", required: bool = False) -> HostActionEnvelope:
        """Turn a materialized behavior into an executable external-browser action.

        The returned envelope is still only a dispatch request; execution truth
        must come back as an observed receipt.
        """
        payload = job.as_payload()
        payload["parent_syscall_id"] = str(parent_syscall_id)
        payload["goal"] = (
            f"Open {job.url} and capture a {'full-page' if job.full_page else 'viewport'} "
            f"{job.image_format.upper()} screenshot. Read-only: do not log in, submit forms, or modify data."
        )
        return HostActionEnvelope(
            syscall_id=f"derived::{parent_syscall_id or 'browser_job'}",
            operation="browser.execute_job",
            capability_need="network_browser:screenshot",
            executor_family="browser",
            preferred_executors=("Opera_Browser_Connector", "TinyFish", "Firecrawl"),
            payload=payload,
            required=bool(required),
        )

    def pending_actions(self, *, required_only: bool = False) -> tuple[HostActionEnvelope, ...]:
        return tuple(self.envelope(req) for req in self.pump.pending(required_only=required_only))

    def pending_action_dicts(self, *, required_only: bool = False) -> tuple[dict[str, Any], ...]:
        return tuple(asdict(x) for x in self.pending_actions(required_only=required_only))

    def ingest(self, results: Iterable[dict[str, Any]]):
        """Ingest observed host results and derive causally bound child work.

        A successful capability materialization may describe a browser behavior in
        ``evidence.derived_browser_job``.  The destination is never trusted from
        fetched code: it must match ``bound_target_url`` on the parent request.
        Child registration is idempotent and remains pending until its own observed
        host receipt is ingested.
        """
        materialized = tuple(dict(x) for x in results)
        rows = self.pump.apply_results(materialized)
        requests = {r.syscall_id: r for r in self.pump.requests()}
        for raw, row in zip(materialized, rows):
            if not row.success:
                continue
            parent = requests.get(row.syscall_id)
            if parent is None or not parent.operation.startswith("capability."):
                continue
            spec = dict((raw.get("evidence") or {}).get("derived_browser_job") or {})
            if not spec:
                continue
            bound_url = str(parent.arguments.get("bound_target_url") or "")
            requested_url = str(spec.get("url") or "")
            if not bound_url or requested_url != bound_url:
                continue
            job = BrowserJobDefinition(
                url=requested_url,
                action=str(spec.get("action") or "screenshot"),
                image_format=str(spec.get("image_format") or "png"),
                full_page=bool(spec.get("full_page", True)),
                read_only=bool(spec.get("read_only", True)),
                provenance=tuple(str(x) for x in spec.get("provenance") or () if str(x).strip()),
            )
            if not job.read_only:
                continue
            self.register_browser_job(job, parent_syscall_id=row.syscall_id)
        return rows
