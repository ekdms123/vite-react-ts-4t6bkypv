from __future__ import annotations

"""Versioned authority ruleset schema.

This module defines the immutable contract for authority compilation.  It does not
perform authority consolidation and is intentionally not wired into runtime behavior
in version 1 of this change.
"""

import hashlib
import json
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class AuthorityInvariant:
    invariant_id: str
    statement: str


@dataclass(frozen=True)
class AuthorityRuleset:
    authority_ruleset_version: int
    schema_id: str
    authority_compiler: str
    downstream_authority_mutation: str
    presentation_authority_effect: str
    current_turn_conflict_policy: str
    prior_state_conflict_policy: str
    constraint_downgrade_policy: str
    permission_escalation_policy: str
    require_exact_source_span: bool
    deterministic_compilation: bool
    presentation_metadata_fields: tuple[str, ...]
    authority_fields: tuple[str, ...]
    invariants: tuple[AuthorityInvariant, ...]


REQUIRED_V1_INVARIANTS = frozenset(
    {
        "PRESENTATION_IS_NOT_AUTHORITY",
        "NO_EXPLICIT_CONSTRAINT_DOWNGRADE",
        "NO_DOWNSTREAM_REINTERPRETATION",
        "CURRENT_TURN_DOMINANCE",
        "NO_INFERRED_PERMISSION_ESCALATION",
        "NO_SOURCE_LOSS",
    }
)


AUTHORITY_RULESET_V1 = AuthorityRuleset(
    authority_ruleset_version=1,
    schema_id="jigaewol.authority.ruleset.v1",
    authority_compiler="AuthorityConsolidation",
    downstream_authority_mutation="forbidden",
    presentation_authority_effect="none",
    current_turn_conflict_policy="current_explicit_wins",
    prior_state_conflict_policy="suppress_conflicting_prior_state",
    constraint_downgrade_policy="forbidden",
    permission_escalation_policy="explicit_current_user_source_only",
    require_exact_source_span=True,
    deterministic_compilation=True,
    presentation_metadata_fields=(
        "markdown_quote_marker",
        "code_fence_marker",
        "emphasis_marker",
        "speaker_marker",
    ),
    authority_fields=(
        "binding",
        "authority_scope",
        "directive_kind",
        "constraint_strength",
        "permission_state",
        "supersession_state",
    ),
    invariants=(
        AuthorityInvariant(
            invariant_id="PRESENTATION_IS_NOT_AUTHORITY",
            statement=(
                "Presentation or provenance markers may be recorded, but no presentation "
                "marker may independently grant, remove, weaken, or upgrade authority."
            ),
        ),
        AuthorityInvariant(
            invariant_id="NO_EXPLICIT_CONSTRAINT_DOWNGRADE",
            statement=(
                "A binding explicit current-user constraint may not be weakened by any "
                "downstream planner, validator, router, or model-generated interpretation."
            ),
        ),
        AuthorityInvariant(
            invariant_id="NO_DOWNSTREAM_REINTERPRETATION",
            statement=(
                "Only AuthorityConsolidation may compile final authority. Downstream "
                "components consume the CanonicalDirectiveSet without re-deciding authority."
            ),
        ),
        AuthorityInvariant(
            invariant_id="CURRENT_TURN_DOMINANCE",
            statement=(
                "When a current explicit user directive conflicts with prior unresolved or "
                "inferred state, the current explicit directive wins and the conflicting "
                "prior state is suppressed rather than erased."
            ),
        ),
        AuthorityInvariant(
            invariant_id="NO_INFERRED_PERMISSION_ESCALATION",
            statement=(
                "A denied or unresolved capability permission may become allowed only from "
                "explicit current-user source authority, never from inference or planning need."
            ),
        ),
        AuthorityInvariant(
            invariant_id="NO_SOURCE_LOSS",
            statement=(
                "Every binding canonical directive or constraint must retain an exact source "
                "span and remain traceable to the exact user source."
            ),
        ),
    ),
)


def validate_authority_ruleset(ruleset: AuthorityRuleset) -> AuthorityRuleset:
    if isinstance(ruleset.authority_ruleset_version, bool) or ruleset.authority_ruleset_version != 1:
        raise ValueError("authority_ruleset_version_must_be_1")
    if ruleset.schema_id != "jigaewol.authority.ruleset.v1":
        raise ValueError("schema_id_must_be_jigaewol_authority_ruleset_v1")
    if ruleset.authority_compiler != "AuthorityConsolidation":
        raise ValueError("authority_compiler_must_be_AuthorityConsolidation")
    if ruleset.downstream_authority_mutation != "forbidden":
        raise ValueError("downstream_authority_mutation_must_be_forbidden")
    if ruleset.presentation_authority_effect != "none":
        raise ValueError("presentation_authority_effect_must_be_none")
    if ruleset.current_turn_conflict_policy != "current_explicit_wins":
        raise ValueError("current_turn_conflict_policy_must_be_current_explicit_wins")
    if ruleset.prior_state_conflict_policy != "suppress_conflicting_prior_state":
        raise ValueError("prior_state_conflict_policy_must_suppress_conflicting_prior_state")
    if ruleset.constraint_downgrade_policy != "forbidden":
        raise ValueError("constraint_downgrade_policy_must_be_forbidden")
    if ruleset.permission_escalation_policy != "explicit_current_user_source_only":
        raise ValueError("permission_escalation_requires_explicit_current_user_source")
    if ruleset.require_exact_source_span is not True:
        raise ValueError("exact_source_span_required")
    if ruleset.deterministic_compilation is not True:
        raise ValueError("deterministic_compilation_required")

    invariant_ids = tuple(row.invariant_id for row in ruleset.invariants)
    if len(invariant_ids) != len(set(invariant_ids)):
        raise ValueError("duplicate_invariant_id")
    missing = REQUIRED_V1_INVARIANTS.difference(invariant_ids)
    if missing:
        raise ValueError("missing_required_invariants:" + ",".join(sorted(missing)))

    overlap = set(ruleset.presentation_metadata_fields).intersection(ruleset.authority_fields)
    if overlap:
        raise ValueError("presentation_authority_field_overlap:" + ",".join(sorted(overlap)))

    return ruleset


def canonical_authority_ruleset_json(ruleset: AuthorityRuleset = AUTHORITY_RULESET_V1) -> str:
    validate_authority_ruleset(ruleset)
    return json.dumps(
        asdict(ruleset),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def authority_ruleset_sha256(ruleset: AuthorityRuleset = AUTHORITY_RULESET_V1) -> str:
    canonical = canonical_authority_ruleset_json(ruleset)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


validate_authority_ruleset(AUTHORITY_RULESET_V1)
