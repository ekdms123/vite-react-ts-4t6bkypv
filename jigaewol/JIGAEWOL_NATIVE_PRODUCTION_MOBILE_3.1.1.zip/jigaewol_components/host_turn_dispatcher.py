"""Exact-message-first host integration. A host registers an actual model callback.

The callback is invoked only after canonical admission succeeds; both failures and
successful host observations remain in the state log. This is usable in a Python
application without ChatGPT-internal APIs or paid dependencies.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from pathlib import Path
from typing import Callable, Any

from .host_message_hook import dispatch_exact_message, install_host_hook_adapter, failure_ledger_path
from .frontier_cognition import FrontierCognition
from .native_host_continuation import NativeHostContinuation


def append_event(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as fh:
        fh.write(json.dumps(event, ensure_ascii=False, default=str, sort_keys=True) + '\n')
        fh.flush()


class IngressBoundHost:
    """Wrap the actual host's callback; run JIGAEWOL before every callback invocation."""

    def __init__(self, runtime_root: str | Path, state_root: str | Path, *,
                 user: str = 'owner', project: str = '지개월', session: str = 'host',
                 callback: Callable[[str, dict[str, Any]], Any] | None = None,
                 continuation_mode: str = 'native_host',
                 host_observations: list[dict[str, Any]] | None = None,
                 artifact_generator=None,artifact_judge=None,adapters=None):
        self.runtime_root = Path(runtime_root).resolve()
        self.base_state_root = Path(state_root).resolve()
        self.user, self.project, self.session = user, project, session
        # Canonical gateway signatures are scoped to user/project/session. Reuse a
        # single root across those identities causes gateway scope mismatch after
        # the first message; isolate by stable scope digest while preserving each
        # individual conversation ledger across turns.
        scope = json.dumps([str(user), str(project), str(session)], ensure_ascii=False, separators=(',', ':'))
        self.scope_id = hashlib.sha256(scope.encode('utf-8')).hexdigest()[:24]
        self.state_root = self.base_state_root / 'host_sessions' / self.scope_id
        self.callback = callback
        self.artifact_generator=artifact_generator
        self.artifact_judge=artifact_judge
        self.production_adapters=adapters
        self.continuation_mode = continuation_mode
        install_host_hook_adapter(runtime_root=self.runtime_root, state_root=self.state_root,
                                  host_observations=host_observations)

    def run(self, original_text: str, *, host_event_id: str = '',
            capabilities_json: str | None = None) -> dict[str, Any]:
        if not isinstance(original_text, str):
            raise TypeError('original_text must be a string')
        host_event_id = host_event_id or 'host-' + uuid.uuid4().hex
        original_hash = hashlib.sha256(original_text.encode('utf-8')).hexdigest()
        receipt = dispatch_exact_message(
            runtime_root=self.runtime_root, state_root=self.state_root,
            message=original_text, user=self.user, project=self.project,
            session=self.session, host_event_id=host_event_id,
            capabilities_json=capabilities_json,
        )
        if not receipt['gateway_completed']:
            raise RuntimeError('Canonical admission failed; see failure_truth.jsonl and dispatches.jsonl')
        result: dict[str, Any] = {
            'host_event_id': host_event_id,
            'message_sha256': original_hash,
            'canonical_ingress': True,
            'gateway_returncode': receipt['returncode'],
            'model_callback_invoked': False,
        }
        # This independent callback is supplied by the host. It never silently
        # creates a fake model call or substitutes a shortened prompt.
        gateway_payload = json.loads(receipt['stdout'])
        result['release_turn_id'] = (gateway_payload.get('release_turn_id') or gateway_payload.get('core_turn_id') or gateway_payload.get('turn_id'))
        # A generative cognition substrate is prepared for EVERY admitted turn,
        # including turns without a model callback. It never substitutes the goal.
        frontier = FrontierCognition(self.state_root)
        cognitive_plan = frontier.prepare(original_text, release_turn_id=str(result['release_turn_id'] or ''))
        result['cognition_frontier_path'] = cognitive_plan['record_path']
        gateway_payload['cognitive_frontier'] = cognitive_plan
        gateway_payload['source_directive'] = {
            'exact_text': original_text,
            'sha256': original_hash,
            'byte_count': len(original_text.encode('utf-8')),
            'derived_fields_are_advisory': True,
            'continuation_is_additive_context': True,
        }
        native_continuation = NativeHostContinuation(self.state_root, session=self.session)
        result['native_host_continuation'] = native_continuation.begin(
            original_text, gateway_payload, release_turn_id=str(result['release_turn_id']),
            host_event_id=host_event_id)
        gateway_payload['production_request']=result['native_host_continuation']['production_request']
        gateway_payload['native_host_continuation']=result['native_host_continuation']
        if self.artifact_generator is not None:
            from .turn_production import TurnProduction
            from jigaewol_runtime.mobile_adapters import configured_adapters
            producer=TurnProduction(self.state_root/'turn_production',
                adapters=self.production_adapters if self.production_adapters is not None else configured_adapters(self.state_root))
            result['production_result']=producer.produce(original_text,str(result['release_turn_id']),
                generator=self.artifact_generator,judge=self.artifact_judge)
            gateway_payload['production_request']=result['production_result']
        if self.callback is not None:
            try:
                # No model-authored or app-authored substitute instructions.
                # Downstream callbacks receive the original text as the sole active
                # user request, and all classifications remain advisory metadata.
                observed = self.callback(original_text, gateway_payload)
                if isinstance(observed, str):
                    generation_text = observed
                elif isinstance(observed, dict) and isinstance(observed.get('response'), str):
                    generation_text = observed['response']
                else:
                    generation_text = None
                if generation_text is not None:
                    # The raw host generation is archived as its own creative substrate.
                    result['native_response_completion'] = native_continuation.complete(
                        release_turn_id=str(result['release_turn_id']), original_text=original_text,
                        response_text=generation_text,
                        observations=observed.get('observations', []) if isinstance(observed, dict) else [],
                        requirement_manifest=observed.get('requirement_manifest') if isinstance(observed, dict) else None,
                        generation_source='registered_host_model_callback',
                        python_model_callback_invoked=True)
                    result['cognition_observation'] = result['native_response_completion']['response_archive']
                # Preserve the full callback observation before returning it to the host.
                observation_file = self.state_root / 'host_hook' / 'model_observations.jsonl'
                append_event(observation_file, {
                    'time': time.time(), 'host_event_id': host_event_id,
                    'release_turn_id': result['release_turn_id'],
                    'message_sha256': original_hash, 'observed_result': observed,
                })
                result.update(model_callback_invoked=True, observed_result=observed,
                              observed_result_path=str(observation_file))
            except Exception as exc:
                append_event(failure_ledger_path(self.state_root), {
                    'component': 'host_turn_dispatcher', 'event': 'host_callback_failed',
                    'host_event_id': host_event_id, 'message_sha256': original_hash,
                    'error_type': type(exc).__name__, 'error': str(exc), 'time': time.time(),
                })
                raise
        result['execution_state'] = (
            'host_callback_observed' if result['model_callback_invoked']
            else 'native_host_continuation_ready'
        )
        append_event(self.state_root / 'host_hook' / 'host_callbacks.jsonl', {
            'time': time.time(), 'host_event_id': host_event_id,
            'message_sha256': original_hash,
            'canonical_ingress': True,
            'model_callback_invoked': result['model_callback_invoked'],
            'execution_state': result['execution_state'],
            'release_turn_id': result.get('release_turn_id'),
            'observed_result_path': result.get('observed_result_path'),
            'cognition_frontier_path': result.get('cognition_frontier_path'),
            'cognition_observation': result.get('cognition_observation'),
        })
        return result

    def complete_native_response(self, original_text: str, response_text: str, *,
                                 release_turn_id: str, observations=None,
                                 requirement_manifest=None) -> dict[str, Any]:
        """Bind the existing host model's outgoing response after real host work."""
        return NativeHostContinuation(self.state_root, session=self.session).complete(
            release_turn_id=release_turn_id, original_text=original_text,
            response_text=response_text, observations=observations,
            requirement_manifest=requirement_manifest)
