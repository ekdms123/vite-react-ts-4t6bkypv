from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

@dataclass(frozen=True)
class QDEntry:
    entry_id: str
    objective: float | None
    descriptor: dict[str, Any]
    payload: dict[str, Any]
    evidence: tuple[str, ...] = ()
    facets: dict[str, Any] = field(default_factory=dict)

DescriptorBinner = Callable[[Mapping[str, Any]], tuple[Any, ...]]

class QualityDiversityArchive:
    """Preserve behavioral niches without requiring every alternative to collapse to one score."""
    def __init__(self, path: Path) -> None:
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self._binners={"identity": lambda d: tuple(sorted((str(k), self._canonical(v)) for k,v in d.items()))}
        if not self.path.exists(): self._write({"cells":{},"history":[]})
    @staticmethod
    def _canonical(v: Any) -> Any:
        if isinstance(v,(str,int,float,bool)) or v is None: return v
        return json.dumps(v, ensure_ascii=False, sort_keys=True, default=str)
    def _read(self): return json.loads(self.path.read_text(encoding="utf-8"))
    def _write(self,data):
        tmp=self.path.with_suffix(".tmp"); tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8"); tmp.replace(self.path)
    def register_binner(self,binner_id,binner): self._binners[str(binner_id)]=binner
    @staticmethod
    def grid_binner(ranges: Mapping[str,tuple[float,float]], bins: Mapping[str,int]) -> DescriptorBinner:
        def binner(descriptor: Mapping[str,Any]):
            out=[]
            for key in sorted(descriptor):
                raw=descriptor[key]
                if key not in ranges or key not in bins or not isinstance(raw,(int,float)):
                    out.append((key, QualityDiversityArchive._canonical(raw))); continue
                value=float(raw); lo,hi=ranges[key]; count=max(1,int(bins[key])); span=max(1e-12,float(hi)-float(lo))
                ix=max(0,min(count-1,int((value-float(lo))/span*count))); out.append((key,ix))
            return tuple(out)
        return binner
    @staticmethod
    def _cell_key(cell):
        return hashlib.sha256(json.dumps(cell,sort_keys=True,default=str).encode()).hexdigest()[:24]
    def add(self, entry: QDEntry, *, binner_id="identity"):
        cell=self._binners[str(binner_id)](entry.descriptor); key=self._cell_key(cell); data=self._read(); previous=data["cells"].get(key)
        accepted=False; store_key=key
        if previous is None:
            accepted=True
        else:
            old=previous["entry"].get("objective"); new=entry.objective
            if isinstance(new,(int,float)) and isinstance(old,(int,float)):
                accepted=float(new)>float(old)
            elif json.loads(json.dumps(asdict(entry),sort_keys=True,default=str)) != previous["entry"]:
                # Qualitatively distinct alternatives share a niche without inventing a winner.
                fingerprint=hashlib.sha256(json.dumps(asdict(entry),sort_keys=True,default=str).encode()).hexdigest()[:10]
                store_key=f"{key}:{fingerprint}"; accepted=store_key not in data["cells"]
        data["history"].append({"entry_id":entry.entry_id,"cell":cell,"objective":entry.objective,"accepted":accepted,"binner_id":str(binner_id),"store_key":store_key})
        if accepted: data["cells"][store_key]={"cell":cell,"entry":asdict(entry)}
        self._write(data); return accepted, store_key
    def elites(self):
        rows=[QDEntry(**x["entry"]) for x in self._read()["cells"].values()]
        return tuple(sorted(rows,key=lambda x:(0 if isinstance(x.objective,(int,float)) else 1, -(float(x.objective) if isinstance(x.objective,(int,float)) else 0.0), x.entry_id)))
    def coverage(self): return len(self._read()["cells"])
    def qd_score(self): return sum(float(x.objective) for x in self.elites() if isinstance(x.objective,(int,float)))
    def sample_diverse(self, maximum=None):
        rows=list(self.elites()); return tuple(rows if maximum is None else rows[:max(0,int(maximum))])
