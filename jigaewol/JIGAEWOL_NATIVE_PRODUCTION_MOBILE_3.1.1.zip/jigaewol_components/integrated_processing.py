from __future__ import annotations

"""Single-path semantic processing pipeline.

The pipeline compiles one exact user ingress into a reusable immutable packet.  Shared
representation work is performed once, while validation routines remain independent and
produce separate verdicts.  A small centralized decision tree combines only those
verdicts; it does not rewrite the source directive or erase content classification.

External/audit projection is plaintext-minimized.  Sensitive/non-standard content keeps
its classification metadata, so normalization is not a laundering mechanism.
"""

from dataclasses import asdict, dataclass, replace
from functools import lru_cache
import hashlib
import json
import struct
from typing import Any, Mapping

from .continuity_consistency import ContinuityConsistencyAttestation
from .semantic_communication import SemanticMessageRecord, build_semantic_record, compute_concept_sha256
from .vector_profiles import DEFAULT_VECTOR_PROFILE, VECTOR_PROFILES, get_vector_profile
from .unified_user_intent import UnifiedIntentEnvelope, build_unified_intent_envelope

SCHEMA = "jigaewol_integrated_processing_pipeline_v1"
VECTOR_SCHEMA = str(VECTOR_PROFILES[DEFAULT_VECTOR_PROFILE]["vector_schema"])
DECISION_SCHEMA = "jigaewol_central_decision_tree_v1"
VECTOR_DIMENSIONS = int(VECTOR_PROFILES[DEFAULT_VECTOR_PROFILE]["dimensions"])
_SPEECH_SLOTS = {"continuation": 0, "request_with_question": 1, "question": 2, "directive": 3, "statement": 4}
_SENSITIVITY_SLOTS = {
    "declared_sensitive_content": 16, "security_or_access_control": 17,
    "privacy_or_personal_data": 18, "violence_or_physical_harm": 19,
    "self_harm": 20, "sexual_or_intimate": 21, "medical_or_health": 22,
    "financial_or_account": 23,
}
_VECTOR32_STRUCT = struct.Struct("!32f")


def _sha_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()




@dataclass(frozen=True, slots=True)
class StandardizedConceptVector:
    dimensions: int
    values: tuple[float, ...]
    vector_sha256: str
    feature_count: int
    source_sha256: str
    semantic_concept_sha256: str
    schema: str = VECTOR_SCHEMA

    def as_mapping(self, *, include_values: bool = True) -> dict[str, Any]:
        row = asdict(self)
        if not include_values:
            row.pop("values", None)
        row.update({
            "representation": "standardized_internal_concept_vector",
            "source_plaintext_embedded": False,
            "canonical_plaintext_embedded": False,
            "content_classification_preserved": True,
        })
        return row


def build_standardized_concept_vector(
    record: SemanticMessageRecord,
    *,
    dimensions: int | None = None,
) -> StandardizedConceptVector:
    profile = get_vector_profile(record.vector_profile)
    expected_dimensions = int(profile["dimensions"])
    vector_schema = str(profile["vector_schema"])
    if dimensions is None:
        dimensions = expected_dimensions
    dimensions = int(dimensions)
    if dimensions != expected_dimensions:
        raise ValueError(
            f"concept vector dimensions {dimensions} do not match declared vector profile "
            f"{record.vector_profile!r} ({expected_dimensions})"
        )
    if dimensions < 25:
        raise ValueError("concept vector dimensions must be >= 25")
    frame = record.concept_frame
    pragmatics = record.pragmatics
    vector = [0.0] * dimensions
    feature_count = 0

    # Stable, fixed slots for known control concepts avoid re-hashing common features.
    slot = _SPEECH_SLOTS.get(frame.get("speech_act"), 4)
    vector[slot] += 1.0; feature_count += 1
    if frame.get("actionability") == "action_requested":
        vector[5] += 1.0; feature_count += 1
    if frame.get("polarity") == "negation_present":
        vector[6] += 1.0; feature_count += 1
    if frame.get("context_dependency") == "contextual":
        vector[7] += 1.0; feature_count += 1
    if bool(frame.get("quoted_or_fenced")):
        vector[8] += 0.75; feature_count += 1
    if bool(frame.get("sensitive_content_present")):
        vector[9] += 1.0; feature_count += 1

    exclam = int(pragmatics.get("exclamation_count") or 0)
    questions = int(pragmatics.get("question_count") or 0)
    repeated = int(pragmatics.get("repeated_character_runs") or 0)
    vector[10] = min(exclam, 16) / 16.0; feature_count += int(exclam > 0)
    vector[11] = min(questions, 16) / 16.0; feature_count += int(questions > 0)
    vector[12] = min(repeated, 16) / 16.0; feature_count += int(repeated > 0)
    if bool(pragmatics.get("contains_code_fence")):
        vector[13] += 0.75; feature_count += 1
    if bool(pragmatics.get("contains_newline")):
        vector[14] += 0.5; feature_count += 1
    if bool(pragmatics.get("continuation_like")):
        vector[15] += 0.75; feature_count += 1

    for family in tuple(frame.get("sensitivity_classes") or ()):
        idx = _SENSITIVITY_SLOTS.get(family)
        if idx is not None and idx < dimensions:
            vector[idx] += 1.5; feature_count += 1

    # Remaining dimensions are a compact summary, not the fidelity authority.  Full
    # ordered per-unit identities stay in the semantic frame.  Sketch the ordered
    # digest-chain once so vector cost does not grow with sentence count.
    sketch_start = 24
    sketch_width = max(1, dimensions - sketch_start)
    chain_sha = str(frame.get("semantic_unit_digest_chain_sha256") or "")
    if chain_sha:
        digest = bytes.fromhex(chain_sha[:8])
        number = int.from_bytes(digest, "big", signed=False)
        index = sketch_start + (number % sketch_width)
        vector[index] += 0.5 if (number >> 31) == 0 else -0.5
        feature_count += 1

    # Fixed-slot weights are already standardized; avoid per-request L2 normalization.
    values = tuple(vector)
    vector_bytes = _VECTOR32_STRUCT.pack(*values) if dimensions == 32 else struct.pack("!" + "f" * len(values), *values)
    vector_digest_source = (vector_schema + "|" + str(dimensions) + "|" + record.source_sha256 + "|" + record.concept_sha256).encode("utf-8") + vector_bytes
    return StandardizedConceptVector(
        dimensions=dimensions, values=values, vector_sha256=hashlib.sha256(vector_digest_source).hexdigest(),
        feature_count=feature_count, source_sha256=record.source_sha256,
        semantic_concept_sha256=record.concept_sha256, schema=vector_schema,
    )


@dataclass(frozen=True, slots=True)
class ValidatorVerdict:
    validator: str
    passed: bool
    scope: str
    evidence_sha256: str
    details: Mapping[str, Any]

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


def _validator_source_binding(exact: str, semantic: SemanticMessageRecord) -> ValidatorVerdict:
    passed = exact == semantic.source_sha256
    details = {"exact_message_sha256": exact, "semantic_source_sha256": semantic.source_sha256}
    return ValidatorVerdict("source_binding", passed, "exact_source_to_semantic_record", exact, details)


def _validator_intent_binding(exact: str, unified: UnifiedIntentEnvelope) -> ValidatorVerdict:
    passed = exact == unified.exact_user_message_sha256
    details = {"exact_message_sha256": exact, "unified_intent_sha256": unified.exact_user_message_sha256}
    return ValidatorVerdict("intent_binding", passed, "exact_source_to_unified_intent", unified.exact_user_message_sha256, details)


def _validator_canonical_integrity(semantic: SemanticMessageRecord) -> ValidatorVerdict:
    recomputed = hashlib.sha256(semantic.canonical_text.encode("utf-8")).hexdigest()
    passed = bool(semantic.canonical_sha256) and recomputed == semantic.canonical_sha256
    details = {"canonical_sha256": semantic.canonical_sha256, "recomputed_sha256": recomputed}
    return ValidatorVerdict("canonical_integrity", passed, "canonical_processing_surface", recomputed, details)


def _validator_vector_binding(semantic: SemanticMessageRecord, vector: StandardizedConceptVector) -> ValidatorVerdict:
    try:
        profile = get_vector_profile(semantic.vector_profile)
        expected_dimensions = int(profile["dimensions"])
        expected_schema = str(profile["vector_schema"])
        recomputed_concept_sha256 = compute_concept_sha256(
            semantic.concept_frame, vector_profile=semantic.vector_profile
        )
        concept_profile_binding_valid = recomputed_concept_sha256 == semantic.concept_sha256
        expected_vector = build_standardized_concept_vector(semantic)
        values_match_recomputed = vector.values == expected_vector.values
        vector_sha256_match_recomputed = vector.vector_sha256 == expected_vector.vector_sha256
        feature_count_match_recomputed = vector.feature_count == expected_vector.feature_count
        passed = (
            concept_profile_binding_valid
            and vector.schema == expected_schema
            and vector.dimensions == expected_dimensions
            and len(vector.values) == expected_dimensions
            and vector.source_sha256 == semantic.source_sha256
            and vector.semantic_concept_sha256 == semantic.concept_sha256
            and values_match_recomputed
            and vector_sha256_match_recomputed
            and feature_count_match_recomputed
        )
        profile_error = ""
    except (TypeError, ValueError) as exc:
        expected_dimensions = -1
        expected_schema = ""
        recomputed_concept_sha256 = ""
        concept_profile_binding_valid = False
        values_match_recomputed = False
        vector_sha256_match_recomputed = False
        feature_count_match_recomputed = False
        profile_error = str(exc)
        passed = False
    details = {
        "vector_profile": semantic.vector_profile,
        "expected_dimensions": expected_dimensions,
        "actual_dimensions": vector.dimensions,
        "expected_vector_schema": expected_schema,
        "actual_vector_schema": vector.schema,
        "concept_profile_binding_valid": concept_profile_binding_valid,
        "recomputed_concept_sha256": recomputed_concept_sha256,
        "values_match_recomputed": values_match_recomputed,
        "vector_sha256_match_recomputed": vector_sha256_match_recomputed,
        "feature_count_match_recomputed": feature_count_match_recomputed,
        "vector_sha256": vector.vector_sha256,
        "source_sha256": vector.source_sha256,
        "semantic_concept_sha256": vector.semantic_concept_sha256,
        "profile_error": profile_error,
    }
    return ValidatorVerdict("concept_vector_binding", passed, "semantic_record_to_profile_bound_internal_vector", vector.vector_sha256, details)


def _validator_semantic_unit_fidelity(semantic: SemanticMessageRecord) -> ValidatorVerdict:
    frame = semantic.concept_frame
    unit_hashes = tuple(str(x) for x in tuple(frame.get("semantic_unit_sha256") or ()))
    expected_count = int(frame.get("semantic_unit_count") or 0)
    mode = str(frame.get("semantic_unit_fingerprint_mode") or "")
    chain = str(frame.get("semantic_unit_digest_chain_sha256") or "")
    recomputed_chain = _sha_text("|".join(unit_hashes)) if unit_hashes else _sha_text("")
    hashes_valid = all(len(x) == 64 for x in unit_hashes)
    passed = (
        mode == "per_unit_ordered_sha256_v1"
        and expected_count == len(unit_hashes)
        and hashes_valid
        and chain == recomputed_chain
    )
    details = {
        "fingerprint_mode": mode,
        "semantic_unit_count": expected_count,
        "semantic_unit_hash_count": len(unit_hashes),
        "ordered_digest_chain_sha256": chain,
        "recomputed_digest_chain_sha256": recomputed_chain,
    }
    return ValidatorVerdict(
        "semantic_unit_fidelity", passed, "ordered_semantic_unit_trace", recomputed_chain, details
    )


def _validator_audit_truth(semantic: SemanticMessageRecord) -> ValidatorVerdict:
    frame = semantic.concept_frame
    # Independent audit check: the frame must explicitly preserve classification
    # truth and must not claim a sensitive message is generic/benign by omission.
    sensitive = bool(frame.get("sensitive_content_present"))
    classes = tuple(frame.get("sensitivity_classes") or ())
    passed = bool(frame.get("content_classification_preserved_truthfully")) and (not sensitive or bool(classes))
    details = {
        "sensitive_content_present": sensitive,
        "sensitivity_class_count": len(classes),
        "classification_truth_flag": bool(frame.get("content_classification_preserved_truthfully")),
    }
    return ValidatorVerdict("audit_truth", passed, "normalized_external_audit_projection", semantic.concept_sha256, details)


def central_decision_tree(verdicts: tuple[ValidatorVerdict, ...]) -> dict[str, Any]:
    # The canonical pipeline emits these five validators in a fixed order. Keep a generic
    # fallback for tests/custom callers, but make the normal central tree allocation-light.
    canonical_order = (
        "source_binding", "intent_binding", "canonical_integrity",
        "semantic_unit_fidelity", "concept_vector_binding", "audit_truth",
    )
    if len(verdicts) == 6 and tuple(v.validator for v in verdicts) == canonical_order:
        source_v, intent_v, canonical_v, unit_v, vector_v, audit_v = verdicts
        order = canonical_order
        flags = (source_v.passed, intent_v.passed, canonical_v.passed, unit_v.passed, vector_v.passed, audit_v.passed)
        status = {name: bool(flag) for name, flag in zip(order, flags)}
    else:
        order = tuple(v.validator for v in verdicts)
        status = {v.validator: bool(v.passed) for v in verdicts}
        flags = tuple(status.get(name, False) for name in canonical_order)
    if not flags[0]:
        result, reason = "reject_integrity", "source_binding_failed"
    elif not flags[1]:
        result, reason = "reject_integrity", "intent_binding_failed"
    elif not flags[2]:
        result, reason = "repair_semantic_projection", "canonical_integrity_failed"
    elif not flags[3]:
        result, reason = "repair_semantic_projection", "semantic_unit_fidelity_failed"
    elif not flags[4]:
        result, reason = "repair_concept_vector", "concept_vector_binding_failed"
    elif not flags[5]:
        result, reason = "repair_audit_projection", "audit_truth_failed"
    else:
        result, reason = "route_canonical_core", "all_independent_validators_passed"
    decision_source = result + "|" + reason + "|" + "".join("1" if x else "0" for x in flags)
    return {
        "schema": DECISION_SCHEMA, "result": result, "reason": reason,
        "validator_order": order, "validator_passed": status,
        "single_output_authority": "central_decision_tree", "source_rewrite_permitted": False,
        "decision_sha256": _sha_text(decision_source),
    }


@dataclass(frozen=True, slots=True)
class IntegratedProcessingPacket:
    exact_message_sha256: str
    semantic_record: SemanticMessageRecord
    unified_intent: UnifiedIntentEnvelope
    consistency: ContinuityConsistencyAttestation
    concept_vector: StandardizedConceptVector
    validators: tuple[ValidatorVerdict, ...]
    central_decision: Mapping[str, Any]
    schema: str = SCHEMA

    def with_sequence(self, sequence: int) -> "IntegratedProcessingPacket":
        seq = int(sequence)
        current = self.unified_intent
        if seq == int(current.sequence):
            return self
        # This is a hot gateway path. Construct the two immutable slot records directly
        # instead of invoking dataclasses.replace twice (which performs generic field
        # discovery and validation on every turn). All source-bound fields are reused.
        unified = UnifiedIntentEnvelope(
            exact_user_message_sha256=current.exact_user_message_sha256,
            raw_byte_count=current.raw_byte_count,
            utf8_text_length=current.utf8_text_length,
            explicit_clause_spans=current.explicit_clause_spans,
            canonical_goal_id=current.canonical_goal_id,
            sequence=seq,
            schema=current.schema,
        )
        return IntegratedProcessingPacket(
            exact_message_sha256=self.exact_message_sha256,
            semantic_record=self.semantic_record,
            unified_intent=unified,
            consistency=self.consistency,
            concept_vector=self.concept_vector,
            validators=self.validators,
            central_decision=self.central_decision,
            schema=self.schema,
        )

    def as_mapping(self, *, include_canonical_text: bool = True, include_vector_values: bool = True) -> dict[str, Any]:
        return {
            "schema": self.schema,
            "exact_message_sha256": self.exact_message_sha256,
            "semantic_communication": self.semantic_record.as_mapping(include_canonical_text=include_canonical_text),
            "unified_user_intent": self.unified_intent.as_mapping(),
            "continuity_consistency": self.consistency.as_mapping(),
            "standardized_concept_vector": self.concept_vector.as_mapping(include_values=include_vector_values),
            "independent_validators": [v.as_mapping() for v in self.validators],
            "central_decision": dict(self.central_decision),
            "single_data_path": True,
            "shared_representation_compute_once": True,
            "independent_validation_preserved": True,
            "external_log_plaintext_policy": "normalized_concept_projection_only",
        }

    def external_audit_projection(self) -> dict[str, Any]:
        semantic_audit = self.semantic_record.audit_projection()
        vector_meta = self.concept_vector.as_mapping(include_values=False)
        return {
            "schema": "jigaewol_integrated_processing_external_audit_v1",
            "exact_message_sha256": self.exact_message_sha256,
            "semantic": semantic_audit,
            "concept_vector": vector_meta,
            "validator_results": [
                {"validator": v.validator, "passed": v.passed, "scope": v.scope, "evidence_sha256": v.evidence_sha256}
                for v in self.validators
            ],
            "central_decision": dict(self.central_decision),
            "raw_plaintext_recorded": False,
            "canonical_plaintext_recorded": False,
            "sensitive_classification_preserved": True,
            "semantic_unit_fidelity_preserved": True,
            "semantic_unit_fingerprint_mode": self.semantic_record.concept_frame.get("semantic_unit_fingerprint_mode"),
        }


@lru_cache(maxsize=512)
def _compile_cached(raw: bytes, direction: str, vector_profile: str) -> IntegratedProcessingPacket:
    text = raw.decode("utf-8", errors="strict")
    exact_sha = hashlib.sha256(raw).hexdigest()
    semantic = build_semantic_record(
        text,
        direction=direction,
        _precomputed_source_sha256=exact_sha,
        vector_profile=vector_profile,
    )
    unified = build_unified_intent_envelope(raw, _precomputed_sha256=exact_sha, _decoded_text=text)
    vector = build_standardized_concept_vector(semantic)
    source_validator = _validator_source_binding(exact_sha, semantic)
    intent_validator = _validator_intent_binding(exact_sha, unified)
    canonical_validator = _validator_canonical_integrity(semantic)
    validators = (
        source_validator, intent_validator, canonical_validator,
        _validator_semantic_unit_fidelity(semantic),
        _validator_vector_binding(semantic, vector),
        _validator_audit_truth(semantic),
    )
    consistency = ContinuityConsistencyAttestation(
        exact_message_sha256=exact_sha,
        unified_intent_sha256=unified.exact_user_message_sha256,
        semantic_source_sha256=semantic.source_sha256,
        semantic_canonical_sha256=semantic.canonical_sha256,
        semantic_canonical_recomputed_sha256=str(canonical_validator.details.get("recomputed_sha256") or ""),
        directive_destination_verified=source_validator.passed,
        unified_intent_bound=intent_validator.passed,
        semantic_source_bound=source_validator.passed,
        semantic_canonical_self_consistent=canonical_validator.passed,
        all_consistent=bool(source_validator.passed and intent_validator.passed and canonical_validator.passed),
    )
    decision = central_decision_tree(validators)
    return IntegratedProcessingPacket(
        exact_message_sha256=exact_sha,
        semantic_record=semantic,
        unified_intent=unified,
        consistency=consistency,
        concept_vector=vector,
        validators=validators,
        central_decision=decision,
    )


def compile_integrated_processing_packet(
    raw_message_bytes: bytes,
    *,
    sequence: int = 0,
    direction: str = "user",
    vector_profile: str = DEFAULT_VECTOR_PROFILE,
) -> IntegratedProcessingPacket:
    raw = bytes(raw_message_bytes)
    profile_name = str(vector_profile or DEFAULT_VECTOR_PROFILE)
    get_vector_profile(profile_name)
    packet = _compile_cached(raw, str(direction), profile_name)
    return packet.with_sequence(int(sequence))


def cache_info() -> Mapping[str, int]:
    info = _compile_cached.cache_info()
    return {
        "hits": int(info.hits), "misses": int(info.misses), "maxsize": int(info.maxsize or 0), "currsize": int(info.currsize)
    }
