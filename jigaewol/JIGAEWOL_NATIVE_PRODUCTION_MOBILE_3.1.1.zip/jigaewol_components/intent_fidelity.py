from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

SENSITIVE_KEY_FRAGMENTS = (
    "authorization", "password", "passwd", "secret", "api_key", "apikey",
    "access_token", "refresh_token", "session_token", "cookie", "set-cookie",
)


def _canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))


def sha_json(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _redact_credentials(value: Any) -> Any:
    if isinstance(value, Mapping):
        out: dict[str, Any] = {}
        for key, item in value.items():
            lowered = str(key).casefold()
            if any(fragment in lowered for fragment in SENSITIVE_KEY_FRAGMENTS):
                out[str(key)] = "<credential-redacted>"
            else:
                out[str(key)] = _redact_credentials(item)
        return out
    if isinstance(value, (list, tuple)):
        return [_redact_credentials(x) for x in value]
    return value


def _shape(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return {"type": "object", "keys": sorted(map(str, value.keys()))[:64], "count": len(value)}
    if isinstance(value, (list, tuple)):
        return {"type": "array", "count": len(value)}
    return {"type": type(value).__name__}


@dataclass(frozen=True)
class GhostReferenceBundle:
    turn_key: str
    command_sha256: str
    cumulative_intent_sha256: str
    primary_required_syscall_ids: tuple[str, ...]
    markers: tuple[dict[str, Any], ...]
    created_at: float
    bundle_sha256: str


@dataclass(frozen=True)
class GhostVerdict:
    bundle_sha256: str
    verified: bool
    world_count: int
    requirement_atoms: tuple[dict[str, str], ...]
    covered_syscall_ids: tuple[str, ...]
    covered_marker_ids: tuple[str, ...]
    findings: tuple[str, ...]
    verified_at: float
    worlds_sha256: str


class IntentFidelityProjector:
    """Verifies intent fidelity and coverage using compact content-addressed markers.

    Records verification outcomes deterministically without unnecessary payload duplication.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.ref_dir = self.root / "ghost_refs"
        self.world_dir = self.root / "ghost_worlds"
        self.ref_dir.mkdir(parents=True, exist_ok=True)
        self.world_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _marker(*, turn_key: str, kind: str, payload: Any, syscall_id: str = "", operation: str = "", stage: str = "") -> dict[str, Any]:
        safe = _redact_credentials(payload)
        encoded = _canonical_json(safe).encode("utf-8")
        digest = hashlib.sha256(encoded).hexdigest()
        marker_id = "ghost_" + hashlib.sha256(f"{turn_key}:{kind}:{syscall_id}:{stage}:{digest}".encode("utf-8")).hexdigest()[:24]
        return {
            "marker_id": marker_id,
            "kind": str(kind),
            "syscall_id": str(syscall_id),
            "operation": str(operation),
            "stage": str(stage),
            "content_sha256": digest,
            "content_bytes": len(encoded),
            "shape": _shape(safe),
        }

    def build_ghost_bundle(
        self,
        *,
        turn_key: str,
        command_sha256: str,
        cumulative_intent: Any,
        primary_required_syscall_ids: Iterable[str],
        syscall_requests: Iterable[dict[str, Any]],
        raw_host_results: Iterable[dict[str, Any]],
        intermediate_processes: Iterable[dict[str, Any]],
    ) -> GhostReferenceBundle:
        reqs = {str(x.get("syscall_id") or ""): dict(x) for x in syscall_requests}
        required = tuple(map(str, primary_required_syscall_ids))
        required_set = set(required)
        markers: list[dict[str, Any]] = []
        for row in raw_host_results:
            sid = str(row.get("syscall_id") or "")
            if sid not in required_set:
                continue
            req = reqs.get(sid, {})
            markers.append(self._marker(
                turn_key=turn_key,
                kind="host_result",
                payload=row,
                syscall_id=sid,
                operation=str(req.get("operation") or ""),
            ))
        for proc in intermediate_processes:
            markers.append(self._marker(
                turn_key=turn_key,
                kind="intermediate_process",
                payload=proc,
                syscall_id=str(proc.get("syscall_id") or ""),
                stage=str(proc.get("stage") or ""),
            ))
        body = {
            "turn_key": str(turn_key),
            "command_sha256": str(command_sha256),
            "cumulative_intent_sha256": sha_json(_redact_credentials(cumulative_intent)),
            "primary_required_syscall_ids": list(required),
            "markers": markers,
            "created_at": time.time(),
        }
        bundle_sha = sha_json(body)
        bundle = GhostReferenceBundle(
            turn_key=body["turn_key"],
            command_sha256=body["command_sha256"],
            cumulative_intent_sha256=body["cumulative_intent_sha256"],
            primary_required_syscall_ids=tuple(body["primary_required_syscall_ids"]),
            markers=tuple(body["markers"]),
            created_at=float(body["created_at"]),
            bundle_sha256=bundle_sha,
        )
        (self.ref_dir / f"{turn_key}-{bundle_sha}.json").write_text(_canonical_json(asdict(bundle)), encoding="utf-8")
        return bundle

    @staticmethod
    def _atomize_text(text: str) -> tuple[dict[str, str], ...]:
        import re

        raw = str(text)
        # Protect opaque spans before sentence segmentation.  Requirement text often
        # contains dots that are semantic data (URLs, syscall names, versions, paths)
        # rather than sentence boundaries.
        patterns = (
            r"`[^`\n]+`",
            r"https?://[^\s<>]+",
            r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
            r"(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+",
            r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*(?:\([^\n)]*\))?)+",
            r"[A-Za-z_][A-Za-z0-9_-]*_V?\d+(?:\.\d+)+(?:\.[A-Za-z0-9_-]+)?",
            r"\bv?\d+(?:\.\d+){1,3}\b",
            r"[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+){1,4}",
        )
        combined = re.compile("|".join(f"(?:{p})" for p in patterns))
        spans: list[str] = []

        def protect(match: re.Match[str]) -> str:
            value = match.group(0)
            # A URL regex may absorb ordinary sentence punctuation.  Keep only
            # punctuation that is plausibly part of the URL.
            trailing = ""
            if value.startswith(("http://", "https://")):
                while value and value[-1] in ".!,":
                    trailing = value[-1] + trailing
                    value = value[:-1]
            idx = len(spans)
            spans.append(value)
            return f"§{idx}§" + trailing

        protected = combined.sub(protect, raw)
        parts = [
            x.strip(" -\t\n")
            for x in re.split(r"[\n.!?]+|(?:\s+그리고\s+)|(?:\s+하지만\s+)|(?:\s+대신\s+)", protected)
        ]

        def restore(value: str) -> str:
            for idx, original in enumerate(spans):
                value = value.replace(f"§{idx}§", original)
            return value

        atoms: list[dict[str, str]] = []
        for protected_part in parts:
            part = restore(protected_part).strip()
            if not part:
                continue
            # Splitting on "." also severs list numbering, so "1. do X" leaves a bare
            # "1" behind. Such a fragment states no requirement, and admitting it both
            # inflates coverage counts and hands the release gate atoms that are
            # satisfied by doing nothing. A fragment with no letter carries no ask.
            if not re.search(r"[^\W\d_]", part, re.UNICODE):
                continue
            atom_id = "req_" + hashlib.sha256(part.encode("utf-8")).hexdigest()[:16]
            atoms.append({"atom_id": atom_id, "text": part})
        if not atoms and raw.strip():
            part = raw.strip()
            atoms.append({"atom_id": "req_" + hashlib.sha256(part.encode("utf-8")).hexdigest()[:16], "text": part})
        return tuple(atoms)

    def verify_deterministic(
        self,
        *,
        bundle: GhostReferenceBundle,
        user_command: str,
        required_syscall_ids: Iterable[str],
        turn_key: str,
    ) -> GhostVerdict:
        required = tuple(map(str, required_syscall_ids))
        marker_syscalls = {str(x.get("syscall_id") or "") for x in bundle.markers if str(x.get("syscall_id") or "")}
        covered = tuple(sorted(set(required) & marker_syscalls))
        atoms = self._atomize_text(user_command)
        findings: list[str] = []
        missing = sorted(set(required) - marker_syscalls)
        if missing:
            findings.append("missing_required_markers:" + ",".join(missing))
        if not atoms:
            findings.append("no_requirement_atoms")
        payload = {
            "mode": "deterministic",
            "ghost_bundle_sha256": bundle.bundle_sha256,
            "covered_syscall_ids": list(covered),
            "requirement_atoms": list(atoms),
            "findings": findings,
        }
        proof_sha = sha_json(payload)
        return GhostVerdict(
            bundle_sha256=bundle.bundle_sha256,
            verified=not findings,
            world_count=0,
            requirement_atoms=atoms,
            covered_syscall_ids=covered,
            covered_marker_ids=tuple(sorted(str(x.get("marker_id") or "") for x in bundle.markers if str(x.get("marker_id") or ""))),
            findings=tuple(findings),
            verified_at=time.time(),
            worlds_sha256=proof_sha,
        )

    def ghost_constraints(self, bundle: GhostReferenceBundle) -> dict[str, Any]:
        return {
            "kind": "ghost_reference_verification",
            "ghost_bundle_sha256": bundle.bundle_sha256,
            "ghost_markers": list(bundle.markers),
            "primary_required_syscall_ids": list(bundle.primary_required_syscall_ids),
            "verification_contract": {
                "independent_worlds_minimum": 2,
                "raw_payload_embedded": False,
                "host_live_context_must_resolve_markers": True,
                "must_cover_every_primary_syscall": True,
                "must_cover_every_marker": True,
                "must_atomize_user_intent": True,
                "must_report_omission_or_distortion": True,
                "must_report_state_stability": True,
                "required_world_facets_key": "ghost_verification",
            },
        }

    @staticmethod
    def _normalize_atoms(raw_atoms: Iterable[Any]) -> list[dict[str, str]]:
        atoms: list[dict[str, str]] = []
        for raw in raw_atoms:
            if isinstance(raw, Mapping):
                text = str(raw.get("text") or raw.get("requirement") or "").strip()
                atom_id = str(raw.get("atom_id") or "").strip()
            else:
                text = str(raw).strip()
                atom_id = ""
            if not text:
                continue
            if not atom_id:
                atom_id = "req_" + hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
            atoms.append({"atom_id": atom_id, "text": text})
        return atoms

    def verify_ghost_worlds(
        self,
        *,
        bundle_sha256: str,
        raw_candidates: Iterable[dict[str, Any]],
        required_syscall_ids: Iterable[str],
        required_marker_ids: Iterable[str],
        turn_key: str,
    ) -> GhostVerdict:
        required_syscalls = set(map(str, required_syscall_ids))
        required_markers = set(map(str, required_marker_ids))
        candidates = [dict(x) for x in raw_candidates]
        findings: list[str] = []
        atoms_by_id: dict[str, dict[str, str]] = {}
        covered_syscalls: set[str] = set()
        covered_markers: set[str] = set()
        valid_worlds = 0
        summaries: list[dict[str, Any]] = []
        if len(candidates) < 2:
            findings.append("fewer_than_two_independent_ghost_worlds")
        for index, world in enumerate(candidates):
            verification = dict((world.get("facets") or {}).get("ghost_verification") or {})
            prefix = f"world_{index}"
            if not verification:
                findings.append(f"{prefix}:missing_ghost_verification")
                continue
            if str(verification.get("ghost_bundle_sha256") or "") != str(bundle_sha256):
                findings.append(f"{prefix}:bundle_hash_mismatch")
                continue
            verdict = str(verification.get("verdict") or "").casefold()
            if verdict not in {"pass", "passed", "verified", "allow"}:
                findings.append(f"{prefix}:verdict_not_pass")
            if verification.get("state_stable") is not True:
                findings.append(f"{prefix}:state_not_stable")
            if list(verification.get("distortion_findings") or ()):
                findings.append(f"{prefix}:distortion_found")
            if list(verification.get("omission_findings") or ()):
                findings.append(f"{prefix}:omission_found")
            syscalls = set(map(str, verification.get("covered_syscall_ids") or ()))
            markers = set(map(str, verification.get("covered_marker_ids") or ()))
            covered_syscalls.update(syscalls)
            covered_markers.update(markers)
            miss_sys = sorted(required_syscalls - syscalls)
            miss_mark = sorted(required_markers - markers)
            if miss_sys:
                findings.append(f"{prefix}:missing_syscalls:{','.join(miss_sys)}")
            if miss_mark:
                findings.append(f"{prefix}:missing_markers:{','.join(miss_mark)}")
            atoms = self._normalize_atoms(verification.get("requirement_atoms") or ())
            if not atoms:
                findings.append(f"{prefix}:no_requirement_atoms")
            for atom in atoms:
                atoms_by_id[atom["atom_id"]] = atom
            summaries.append({
                "candidate_id": str(world.get("candidate_id") or f"ghost-{index}"),
                "bundle_sha256": str(bundle_sha256),
                "covered_syscall_ids": sorted(syscalls),
                "covered_marker_ids": sorted(markers),
                "requirement_atom_ids": sorted(x["atom_id"] for x in atoms),
                "state_stable": verification.get("state_stable") is True,
                "verdict": verdict,
            })
            valid_worlds += 1
        verified = (
            valid_worlds >= 2 and not findings
            and required_syscalls.issubset(covered_syscalls)
            and required_markers.issubset(covered_markers)
            and bool(atoms_by_id)
        )
        worlds_payload = {"ghost_bundle_sha256": bundle_sha256, "summaries": summaries, "findings": findings, "verified": verified}
        worlds_sha = sha_json(worlds_payload)
        (self.world_dir / f"{turn_key}-{worlds_sha}.json").write_text(_canonical_json(worlds_payload), encoding="utf-8")
        return GhostVerdict(
            bundle_sha256=str(bundle_sha256), verified=bool(verified), world_count=len(candidates),
            requirement_atoms=tuple(atoms_by_id.values()), covered_syscall_ids=tuple(sorted(covered_syscalls)),
            covered_marker_ids=tuple(sorted(covered_markers)), findings=tuple(findings), verified_at=time.time(),
            worlds_sha256=worlds_sha,
        )

    @staticmethod
    def compact_host_evidence(evidence: Mapping[str, Any] | None, *, raw_row: Mapping[str, Any]) -> dict[str, Any]:
        evidence = dict(evidence or {})
        safe = _redact_credentials(raw_row)
        encoded = _canonical_json(safe).encode("utf-8")
        compact: dict[str, Any] = {
            "host_result_received": True,
            "ghost_content_sha256": hashlib.sha256(encoded).hexdigest(),
            "ghost_content_bytes": len(encoded),
        }
        for key in ("candidate_count", "registered_candidate_ids", "reason", "request_queue"):
            if key in evidence:
                compact[key] = evidence[key]
        return compact

    @staticmethod
    def validate_candidate_manifest(
        *,
        candidate_body: str,
        manifest: Mapping[str, Any] | None,
        verdict: GhostVerdict,
        primary_required_syscall_ids: Iterable[str],
    ) -> tuple[bool, tuple[str, ...]]:
        if not manifest:
            return False, ("candidate_manifest_missing",)
        findings: list[str] = []
        response_sha = hashlib.sha256(str(candidate_body).encode("utf-8")).hexdigest()
        if str(manifest.get("response_sha256") or "") != response_sha:
            findings.append("candidate_manifest_response_hash_mismatch")
        if str(manifest.get("ghost_bundle_sha256") or "") != verdict.bundle_sha256:
            findings.append("candidate_manifest_ghost_bundle_hash_mismatch")
        if str(manifest.get("ghost_worlds_sha256") or "") != verdict.worlds_sha256:
            findings.append("candidate_manifest_ghost_worlds_hash_mismatch")
        used = set(map(str, manifest.get("used_syscall_ids") or ()))
        required = set(map(str, primary_required_syscall_ids))
        if not required.issubset(used):
            findings.append("candidate_manifest_missing_required_syscall_provenance")
        addressed = set(map(str, manifest.get("addressed_requirement_atom_ids") or ()))
        required_atoms = {x["atom_id"] for x in verdict.requirement_atoms}
        if not required_atoms.issubset(addressed):
            findings.append("candidate_manifest_missing_requirement_atoms")
        return not findings, tuple(findings)

    def purge_turn(self, turn_key: str) -> None:
        key = str(turn_key)
        for directory in (self.ref_dir, self.world_dir):
            for path in directory.glob(f"{key}-*.json"):
                path.unlink(missing_ok=True)


