from __future__ import annotations

"""Birth executable experience-worlds from obstruction; fixed worlds are regression fixtures only."""

from dataclasses import dataclass, asdict, field
from typing import Any, Iterable, Mapping
import hashlib, json


@dataclass(frozen=True, slots=True)
class StrangeWorldCase:
    state: dict[str, Any]
    history: tuple[str, ...]
    visible_representation: tuple[Any, ...]
    required_action: str
    world_rule: str

    def as_mapping(self) -> dict[str, Any]: return asdict(self)


@dataclass(frozen=True, slots=True)
class BornExperience:
    experience_id: str
    obstruction: dict[str, Any]
    cases: tuple[dict[str, Any], ...]
    generator_semantics: dict[str, Any]
    state_schema: Mapping[str, Any] = field(default_factory=dict)
    observation_space: Mapping[str, Any] = field(default_factory=dict)
    action_space: tuple[str, ...] = ()
    transition_system: Mapping[str, Any] = field(default_factory=dict)
    extraction_targets: tuple[str, ...] = ()

    def as_mapping(self) -> dict[str, Any]: return asdict(self)


class ExperienceFactory:
    ACTIONS2 = ("turn", "hold")
    ACTIONS3 = ("turn", "hold", "invert")

    @staticmethod
    def _histories(max_len: int = 7) -> tuple[tuple[str, ...], ...]:
        patterns = ("observe", "touch", "listen")
        rows = [()]
        for n in range(1, max_len + 1):
            rows.append(tuple(patterns[(i * 2 + n) % len(patterns)] for i in range(n)))
            rows.append(tuple(patterns[(i + n) % len(patterns)] for i in range(n)))
        return tuple(dict.fromkeys(rows))

    @staticmethod
    def required_action(rule: str, value: int, history: Iterable[str]) -> str:
        h = tuple(history)
        if rule == "path_length_xor": return ExperienceFactory.ACTIONS2[(int(value) + len(h)) % 2]
        if rule == "touch_residue_3": return ExperienceFactory.ACTIONS3[(int(value) + sum(1 for x in h if x == "touch")) % 3]
        if rule == "tail_inversion":
            bit = int(value) % 2
            if (h[-1] if h else None) == "listen": bit ^= 1
            return ExperienceFactory.ACTIONS2[bit]
        raise ValueError(f"unknown regression world rule {rule}")

    def generate(self, *, rule: str, values: Iterable[int], histories: Iterable[tuple[str, ...]] | None = None) -> tuple[StrangeWorldCase, ...]:
        hs = tuple(histories or self._histories()); rows = []
        for value in values:
            for history in hs:
                rows.append(StrangeWorldCase({"value": int(value)}, tuple(history), (int(value),), self.required_action(rule, int(value), history), rule))
        return tuple(rows)

    def split(self, rule: str = "touch_residue_3") -> tuple[tuple[StrangeWorldCase, ...], tuple[StrangeWorldCase, ...]]:
        return self.generate(rule=rule, values=range(0, 6)), self.generate(rule=rule, values=range(6, 10))

    def suite(self) -> tuple[str, ...]:
        return ("path_length_xor", "touch_residue_3", "tail_inversion")

    @staticmethod
    def _state_schema(witnesses: tuple[Mapping[str, Any], ...]) -> dict[str, Any]:
        keys = sorted({str(k) for w in witnesses for k in (w.get("state") or {})})
        return {
            "kind": "born_state_schema",
            "fields": tuple({"name": key, "type": "inferred_at_runtime"} for key in keys),
            "schema_can_expand_from_counterexample": True,
        }

    def from_obstruction(self, obstruction: Mapping[str, Any], *, width: int = 6) -> BornExperience:
        """Create an executable task-local world whose laws are born from the obstruction.

        The environment varies state, event order and action consequences so that an
        organ can be extracted from experience rather than from a background sentence.
        """
        row = dict(obstruction)
        witnesses = tuple(dict(w) for w in (row.get("witnesses") or ()) if isinstance(w, Mapping))
        seed = hashlib.sha256(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()
        alphabet = tuple(dict.fromkeys(str(x) for w in witnesses for x in (w.get("history") or ()) if str(x))) or ("observe", "touch", "listen")
        observed_actions = tuple(dict.fromkeys(str(w.get("required") or w.get("required_action") or "") for w in witnesses if str(w.get("required") or w.get("required_action") or "")))
        actions = observed_actions or tuple(f"branch_{i}" for i in range(max(2, min(4, int(width)))))
        cases = []
        for i in range(max(2, int(width))):
            base = dict((witnesses[i % len(witnesses)].get("state") or {}) if witnesses else {"value": i})
            base.setdefault("experience_phase", i)
            history = tuple(alphabet[(i + j) % len(alphabet)] for j in range(i % (len(alphabet) + 1)))
            required = str((witnesses[i % len(witnesses)].get("required") or witnesses[i % len(witnesses)].get("required_action")) if witnesses else actions[i % len(actions)])
            cases.append({
                "state": base,
                "history": history,
                "visible_representation": tuple(sorted(base.items())),
                "required_action": required,
                "world_rule": "born_from_obstruction",
            })
        transition_system = {
            "kind": "generated_micro_world",
            "state_update": "action_and_observation_path_jointly_transform_state",
            "history_update": "append_action_then_observation_event",
            "observation_can_disturb_state": True,
            "action_effects": tuple({
                "action": action,
                "effect": {"kind": "phase_shift", "delta": idx + 1, "seed_channel": seed[idx:idx+8]},
            } for idx, action in enumerate(actions)),
            "laws_are_task_local_and_replaceable": True,
        }
        semantics = {
            "kind": "obstruction_amplification_world",
            "source_sha256": seed,
            "alphabet": alphabet,
            "laws_are_executable_not_prose_only": True,
            "world_can_mutate_its_observation_and_transition_rules_from_failures": True,
            "does_not_claim_ground_truth_beyond_witnesses": True,
        }
        return BornExperience(
            "experience_" + seed[:20],
            row,
            tuple(cases),
            semantics,
            self._state_schema(witnesses),
            {
                "channels": ("state", "history", "last_action", "experience_phase"),
                "observation_order_is_semantically_relevant": True,
                "new_channels_may_be_born_from_failure": True,
            },
            tuple(actions),
            transition_system,
            ("reusable_operation", "new_observation_channel", "new_datatype", "policy_fragment"),
        )

    def step(self, experience: BornExperience, *, state: Mapping[str, Any], history: Iterable[str], action: str) -> dict[str, Any]:
        """Execute one transition of a born micro-world."""
        state2 = dict(state)
        h = list(map(str, history))
        action = str(action)
        specs = {str(x["action"]): dict(x["effect"]) for x in experience.transition_system.get("action_effects", ())}
        effect = specs.get(action, {"kind": "unknown_action", "delta": 0})
        phase = int(state2.get("experience_phase", 0))
        if effect.get("kind") == "phase_shift":
            phase += int(effect.get("delta", 0))
        state2["experience_phase"] = phase
        h.append(action)
        observation_event = f"observe_phase_{phase % max(1, len(experience.action_space) or 1)}"
        h.append(observation_event)
        return {
            "state": state2,
            "history": tuple(h),
            "observation": {
                "experience_phase": phase,
                "last_action": action,
                "observation_event": observation_event,
            },
            "effect": effect,
        }


@dataclass(frozen=True, slots=True)
class HiddenWorld:
    world_id: str
    train: tuple[StrangeWorldCase, ...]
    holdout: tuple[StrangeWorldCase, ...]
    oracle_manifest: dict[str, Any]

    def as_mapping(self) -> dict[str, Any]: return asdict(self)


def _hidden_world(self: ExperienceFactory, seed_material: str | bytes) -> HiddenWorld:
    raw = seed_material if isinstance(seed_material, bytes) else str(seed_material).encode("utf-8")
    digest = hashlib.sha256(raw).digest(); hexd = hashlib.sha256(raw).hexdigest()
    alphabet = ("observe", "touch", "listen", "rotate")
    event = alphabet[digest[0] % len(alphabet)]
    transition = (alphabet[digest[1] % len(alphabet)], alphabet[digest[2] % len(alphabet)])
    tail_event = alphabet[digest[3] % len(alphabet)]
    modulus = 2 + digest[4] % 4
    a = 1 + digest[5] % (modulus + 1); b = 1 + digest[6] % (modulus + 1); c = 1 + digest[7] % (modulus + 1); d = 1 + digest[8] % (modulus + 1)
    actions = tuple(f"act_{i}" for i in range(modulus))

    histories = [()]
    for n in range(1, 8):
        histories.append(tuple(alphabet[(digest[(n + j) % len(digest)] + j) % len(alphabet)] for j in range(n)))
        histories.append(tuple(alphabet[(n * 3 + j * 2 + digest[j % len(digest)]) % len(alphabet)] for j in range(n)))
    histories = list(dict.fromkeys(histories))

    def required(value: int, history: tuple[str, ...]) -> str:
        count = sum(1 for x in history if x == event)
        trans = sum(1 for x, y in zip(history, history[1:]) if (x, y) == transition)
        tail = int(bool(history) and history[-1] == tail_event)
        idx = (a * int(value) + b * count + c * len(history) + d * trans + tail) % modulus
        return actions[idx]

    def cases(values: Iterable[int]) -> tuple[StrangeWorldCase, ...]:
        return tuple(StrangeWorldCase({"value": int(v)}, tuple(h), (int(v),), required(int(v), tuple(h)), "hidden_born_world") for v in values for h in histories)

    manifest = {
        "kind": "generated_hidden_world_oracle", "seed_sha256": hexd, "action_count": modulus,
        "oracle_is_withheld_from_synthesizer": True,
        "law_shape": "generated_composition_of_state_path_and_observation_history",
        "event_alphabet": alphabet,
    }
    return HiddenWorld("hidden_world_" + hexd[:20], cases(range(0, 7)), cases(range(7, 11)), manifest)


ExperienceFactory.birth_hidden_world = _hidden_world
