from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ExactIngressMessage:
    text: str
    raw_bytes: bytes
    raw_sha256: str
    text_sha256: str


def read_exact_message(path: str | Path) -> ExactIngressMessage:
    """Read canonical ingress bytes without newline or Unicode normalization."""
    raw = Path(path).read_bytes()
    text = raw.decode("utf-8", errors="strict")
    return ExactIngressMessage(
        text=text,
        raw_bytes=raw,
        raw_sha256=hashlib.sha256(raw).hexdigest(),
        text_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
    )
