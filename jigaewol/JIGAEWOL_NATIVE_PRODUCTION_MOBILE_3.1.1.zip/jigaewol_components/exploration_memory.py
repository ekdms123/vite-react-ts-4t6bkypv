from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Iterable, Mapping


class ExplorationMemory:
    """Preserve exploration material without promoting speculation to fact."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.scratch = self.root / "scratch"
        self.scratch.mkdir(parents=True, exist_ok=True)
        self.archive_path = self.root / "archive.jsonl"
        self.observed_path = self.root / "observed_claims.jsonl"
        self.stepping_stones_path = self.root / "stepping_stones.jsonl"
        self.archive_path.touch(exist_ok=True)
        self.observed_path.touch(exist_ok=True)
        self.stepping_stones_path.touch(exist_ok=True)

    @staticmethod
    def _sha(value: Any) -> str:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def record_scratch(self, *, run_id: str, operator_id: str, payload: str) -> str:
        row = {"run_id": run_id, "operator_id": operator_id, "payload": str(payload), "created_at": time.time()}
        path = self.scratch / f"{run_id}__{operator_id}.json"
        path.write_text(json.dumps(row, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        return str(path)

    def close_run(
        self,
        *,
        run_id: str,
        accepted_result_ids: Iterable[str],
        speculative_results: Iterable[Mapping[str, Any]] = (),
        reason: str = "",
    ) -> dict[str, Any]:
        files = tuple(sorted(self.scratch.glob(f"{run_id}__*.json")))
        scratch_rows = []
        for path in files:
            try:
                row = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                row = {"path": str(path)}
            scratch_rows.append(row)

        speculative_rows = []
        for raw in speculative_results:
            row = dict(raw.as_mapping()) if hasattr(raw, "as_mapping") and callable(getattr(raw, "as_mapping")) else dict(raw)
            payload = str(row.get("payload") or "").strip()
            if not payload:
                continue
            item = {
                **row,
                "payload": payload,
                "payload_sha256": self._sha(payload),
                "evidence_state": str(row.get("evidence_state") or "speculative"),
                "preservation_reason": "possible_future_reuse",
                "created_at": time.time(),
            }
            speculative_rows.append(item)
            with self.stepping_stones_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(item, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":")) + "\n")

        summary = {
            "run_id": run_id,
            "accepted_result_ids": tuple(accepted_result_ids),
            "speculative_live_ids": tuple(x.get("result_id") for x in speculative_rows),
            "scratch_rows": tuple(scratch_rows),
            "reason": str(reason),
            "closed_at": time.time(),
            "full_scratch_preserved": True,
        }
        with self.archive_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(summary, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":")) + "\n")
        return summary

    def stepping_stones(self, *, limit: int | None = None) -> tuple[dict[str, Any], ...]:
        rows = []
        for line in self.stepping_stones_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        if limit is not None:
            rows = rows[-max(0, int(limit)):]
        return tuple(rows)

    def promote_observed(self, candidate: Mapping[str, Any]) -> bool:
        refs = tuple(str(x) for x in candidate.get("evidence_refs") or () if str(x))
        state = str(candidate.get("evidence_state") or "")
        if state not in {"observed", "probed"} or not refs:
            return False
        with self.observed_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(candidate), ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":")) + "\n")
        return True
