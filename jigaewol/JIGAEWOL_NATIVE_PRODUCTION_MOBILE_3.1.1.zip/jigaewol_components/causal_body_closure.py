from __future__ import annotations

"""Causal closure audit for host actions.

The key distinction is between an unavailable *route* and an unavailable *goal*.
Required work with no direct body must have an executable acquisition/materialization
path.  Semantic host-model requests are tracked separately from external actuators so
one cannot masquerade as the other.
"""

from dataclasses import asdict
from typing import Any, Iterable


def audit_body_closure(actions: Iterable[Any]) -> dict[str, Any]:
    rows = list(actions)
    acquisitions = [
        a for a in rows
        if getattr(a, "capability", "") == "capability:discover_execute"
        and getattr(a, "required", False)
    ]
    executable_acquisitions = [a for a in acquisitions if getattr(a, "selected_executor", "")]
    targeted_ids: set[str] = set()
    for a in acquisitions:
        payload = dict(getattr(a, "payload", {}) or {})
        targeted_ids.update(str(x) for x in payload.get("orphan_action_ids") or () if str(x))

    external_unbound = [
        a for a in rows
        if getattr(a, "required", False)
        and getattr(a, "family", "") != "exploration"
        and getattr(a, "capability", "") != "capability:discover_execute"
        and not getattr(a, "selected_executor", "")
    ]
    acquisition_backed = [a for a in external_unbound if getattr(a, "action_id", "") in targeted_ids and executable_acquisitions]
    orphaned = [a for a in external_unbound if a not in acquisition_backed]
    semantic_unbound = [
        a for a in rows
        if getattr(a, "required", False)
        and getattr(a, "family", "") == "exploration"
        and not getattr(a, "selected_executor", "")
    ]
    stale_revalidation = [a for a in rows if getattr(a, "revalidation_required", False)]

    if orphaned:
        route_state = "orphaned_required_external_action"
    elif acquisition_backed:
        route_state = "materialization_path_bound"
    elif stale_revalidation:
        route_state = "revalidation_path_bound"
    else:
        route_state = "direct_or_no_external_action"

    def compact(a: Any) -> dict[str, Any]:
        return {
            "action_id": str(getattr(a, "action_id", "")),
            "capability": str(getattr(a, "capability", "")),
            "family": str(getattr(a, "family", "")),
            "selected_body_id": str(getattr(a, "selected_body_id", "")),
            "selected_executor": str(getattr(a, "selected_executor", "")),
            "binding_state": str(getattr(a, "binding_state", "")),
            "revalidation_required": bool(getattr(a, "revalidation_required", False)),
        }

    return {
        "schema": "jigaewol_causal_body_closure_v1",
        "route_state": route_state,
        "required_external_direct_unbound": [compact(a) for a in external_unbound],
        "acquisition_backed_unbound": [compact(a) for a in acquisition_backed],
        "orphaned_required_external": [compact(a) for a in orphaned],
        "executable_acquisition_actions": [compact(a) for a in executable_acquisitions],
        "semantic_unbound": [compact(a) for a in semantic_unbound],
        "stale_revalidation_queue": [compact(a) for a in stale_revalidation],
        "missing_body_may_be_final_diagnosis": False,
        "planner_may_claim_external_route_closed": not bool(orphaned),
        "execution_or_effect_proven": False,
        "claim_boundary": "route closure is not execution; host receipts remain mandatory",
    }
