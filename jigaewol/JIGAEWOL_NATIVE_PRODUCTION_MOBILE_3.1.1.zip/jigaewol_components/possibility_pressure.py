from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Mapping

from .semantic_authority import bind_semantic_authority


@dataclass(frozen=True)
class PossibilityPressureVerdict:
    route_expansion_ready: bool
    findings: tuple[str, ...]
    closure_phrases: tuple[str, ...]


class PossibilityPressure:
    """Turn premature global closure language into route-expansion pressure."""

    CLOSURE_PHRASES = (
        r"불가능(?:해|합니다|하다|한)",
        r"할\s*수\s*없(?:어|습니다|다)",
        r"못\s*(?:해|합니다|한다|할)",
        r"안\s*됩(?:니다|니다|돼|된다)",
        r"\bcannot\b", r"\bcan't\b", r"\bnot possible\b", r"\bimpossible\b",
    )
    BOUNDARY_TOPIC = (
        "한계", "제약", "불가능", "못해", "안돼", "안 되", "가능해", "가능하", "can you",
        "possible", "limitation", "constraint", "what can't", "why can't",
    )

    @classmethod
    def evaluate(
        cls,
        *,
        objective: str,
        candidate: str,
        cognitive_os: Mapping[str, Any] | None,
        semantic_authority: Mapping[str, Any] | None = None,
        observed_boundary: bool = False,
    ) -> PossibilityPressureVerdict:
        text = str(candidate or "")
        phrases = tuple(m.group(0) for pat in cls.CLOSURE_PHRASES for m in re.finditer(pat, text, flags=re.IGNORECASE))
        if not phrases:
            return PossibilityPressureVerdict(True, (), ())
        # Merely discussing limits/constraints is not evidence that a global boundary
        # exists.  Closure language is allowed only when a boundary was actually
        # observed/proven by the caller.
        if observed_boundary:
            return PossibilityPressureVerdict(True, (), phrases)
        os_state = dict(cognitive_os or {})
        routes = tuple(os_state.get("routes") or ())
        expandable = [r for r in routes if str(r.get("state") or "untried") == "untried"]
        authority = bind_semantic_authority(objective, semantic_authority)
        frontier_open = bool(authority.get("open_problem_required") or os_state.get("semantic_frontier_open"))
        # Absence of currently known/untried routes is not a proof of global
        # impossibility.  Without observed boundary evidence, closure language must
        # stay non-authoritative even when the present route set is empty.
        findings = ["observed_boundary_required_before_global_closure"]
        if expandable or frontier_open:
            findings.append("expand_routes_before_global_closure")
        return PossibilityPressureVerdict(False, tuple(findings), phrases)
