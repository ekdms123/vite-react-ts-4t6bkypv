from __future__ import annotations

import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
from functools import lru_cache
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class ComputeProfile:
    os: str
    architecture: str
    python: str
    logical_cpus: int | None
    memory_bytes: int | None
    apple_silicon: bool
    torch_present: bool
    cuda_available: bool
    mps_available: bool
    mlx_present: bool
    mlx_lm_present: bool
    ollama_path: str | None
    llama_server_path: str | None
    recommended_local_paths: tuple[str, ...]


class ComputeProfileDetector:
    """Detects available hardware and compute runtimes across platforms (Apple Silicon, CUDA, CPU)."""

    @staticmethod
    def _memory_bytes() -> int | None:
        try:
            pages = os.sysconf("SC_PHYS_PAGES")
            size = os.sysconf("SC_PAGE_SIZE")
            return int(pages) * int(size)
        except (ValueError, OSError, AttributeError):
            return None

    @staticmethod
    @lru_cache(maxsize=1)
    def _torch_accelerators() -> tuple[bool, bool, bool]:
        if importlib.util.find_spec("torch") is None:
            return False, False, False
        code = (
            "import json, torch; "
            "print(json.dumps({'cuda': bool(torch.cuda.is_available()), "
            "'mps': bool(getattr(getattr(torch, 'backends', None), 'mps', None) and torch.backends.mps.is_available())}))"
        )
        try:
            proc = subprocess.run(
                [sys.executable, "-c", code],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if proc.returncode != 0:
                return True, False, False
            payload = json.loads(proc.stdout.strip())
            return True, bool(payload.get("cuda")), bool(payload.get("mps"))
        except (subprocess.TimeoutExpired, Exception):
            return True, False, False

    def detect(self) -> ComputeProfile:
        os_name = platform.system()
        arch = platform.machine()
        apple_silicon = os_name == "Darwin" and arch in {"arm64", "aarch64"}
        torch_present, cuda, mps = self._torch_accelerators()
        mlx_present = importlib.util.find_spec("mlx") is not None
        mlx_lm_present = importlib.util.find_spec("mlx_lm") is not None
        ollama = shutil.which("ollama")
        llama_server = shutil.which("llama-server") or shutil.which("llama_server")
        paths: list[str] = []
        if apple_silicon and mlx_lm_present:
            paths.append("mlx_lm")
        if cuda:
            paths.append("cuda_local_inference")
        if llama_server:
            paths.append("llama.cpp")
        if ollama:
            paths.append("ollama")
        if not paths:
            paths.append("cpu_python")
        return ComputeProfile(
            os=os_name,
            architecture=arch,
            python=sys.version.split()[0],
            logical_cpus=os.cpu_count(),
            memory_bytes=self._memory_bytes(),
            apple_silicon=apple_silicon,
            torch_present=torch_present,
            cuda_available=cuda,
            mps_available=mps,
            mlx_present=mlx_present,
            mlx_lm_present=mlx_lm_present,
            ollama_path=ollama,
            llama_server_path=llama_server,
            recommended_local_paths=tuple(paths),
        )

    def write_report(self, path: Path) -> Path:
        profile = self.detect()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(profile), indent=2), encoding="utf-8")
        return path
