"""Persistent search frontier driven by observed posts, terms, creators and files."""
from __future__ import annotations
import hashlib
import json
import sqlite3
from pathlib import Path
from .search_portfolio_engine import SearchPortfolioEngine

class SearchEvidenceGraph:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True,exist_ok=True)
        self.path = self.root/'search.sqlite3'
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS nodes(id TEXT PRIMARY KEY, goal TEXT, kind TEXT, body TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS edges(goal TEXT, source TEXT, relation TEXT, target TEXT, UNIQUE(goal,source,relation,target))')
            db.execute('CREATE TABLE IF NOT EXISTS frontier(id TEXT PRIMARY KEY, goal TEXT, family TEXT, body TEXT, state TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS observations(id TEXT PRIMARY KEY, goal TEXT, body TEXT)')

    def db(self):
        db = sqlite3.connect(self.path,timeout=30)
        db.execute('PRAGMA journal_mode=WAL')
        return db

    @staticmethod
    def _hash(value):
        return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()

    def observe(self, *, goal, family, action_id, result, frontier_id=''):
        result = dict(result) if isinstance(result,dict) else {'raw_result':result}
        items = result.get('items') or result.get('results') or []
        if isinstance(items,dict):
            items = items.get('items') or items.get('results') or []
        items = [dict(x) for x in items if isinstance(x,dict)]
        with self.db() as db:
            if db.execute('SELECT 1 FROM observations WHERE id=?',(action_id,)).fetchone():
                return self.summary(goal)
            novel = []
            for item in items:
                body = item.get('raw_content') or item.get('content') or item.get('snippet') or item.get('title') or item.get('url')
                node_id = self._hash([goal,body])
                if not db.execute('SELECT 1 FROM nodes WHERE id=?',(node_id,)).fetchone():
                    novel.append(item)
                db.execute('INSERT OR IGNORE INTO nodes VALUES (?,?,?,?)',(node_id,goal,'post',json.dumps(item,ensure_ascii=False,default=str)))
                for relation,key in [('authored_by','creator'),('links_to','url'),('original_artifact','artifact_url'),('contains_claim','claim'),('reverse_media_trace','media_trace')]:
                    if item.get(key):
                        value = item[key]
                        target = self._hash([goal,relation,value])
                        db.execute('INSERT OR IGNORE INTO nodes VALUES (?,?,?,?)',(target,goal,relation,json.dumps(value,ensure_ascii=False,default=str)))
                        db.execute('INSERT OR IGNORE INTO edges VALUES (?,?,?,?)',(goal,node_id,relation,target))
            program = SearchPortfolioEngine.derive_followup_program(novel,family,max_terms=None) if novel else {'observed_terms':[]}
            for term in program.get('observed_terms') or []:
                fid = self._hash([goal,family,str(term).casefold()])
                payload = dict(query=str(term),observed_term=str(term),source_family=family,parent_action_id=action_id,
                               origin_goal_sha256=goal,required=False,
                               frontier_role='observed_followup_opportunity',
                               priority=sum(2 for item in novel if str(term).casefold() in json.dumps(item,ensure_ascii=False).casefold())
                                        +sum(3 for item in novel if item.get('artifact_url') or item.get('creator')),
                               query_program=SearchPortfolioEngine.compile_query_program(str(term),family))
                db.execute('INSERT OR IGNORE INTO frontier VALUES (?,?,?,?,?)',(fid,goal,family,json.dumps(payload,ensure_ascii=False),'pending'))
            if frontier_id:
                db.execute("UPDATE frontier SET state=? WHERE id=? AND goal=?",('observed' if items else 'route_observed_empty',frontier_id,goal))
            observation = {'result':result,'novel_source_count':len(novel),'duplicate_source_count':len(items)-len(novel),'saturated':bool(items and not novel),
                           'route_only_failure':not items,'global_goal_closed':False}
            db.execute('INSERT INTO observations VALUES (?,?,?)',(action_id,goal,json.dumps(observation,ensure_ascii=False,default=str)))
        return self.summary(goal)

    def pending(self, goal):
        with self.db() as db:
            rows=[{'frontier_id':x[0], **json.loads(x[1])} for x in db.execute("SELECT id,body FROM frontier WHERE goal=? AND state='pending' ORDER BY rowid",(goal,))]
        return sorted(rows,key=lambda x:-float(x.get('priority',0)))

    def summary(self, goal):
        with self.db() as db:
            return {'goal_ref':goal,'node_count':db.execute('SELECT count(*) FROM nodes WHERE goal=?',(goal,)).fetchone()[0],
                    'edge_count':db.execute('SELECT count(*) FROM edges WHERE goal=?',(goal,)).fetchone()[0],
                    'pending_required_frontier':sum(x.get('required') is True for x in self.pending(goal)),
                    'pending_opportunities':len(self.pending(goal)), 'durable_path':str(self.path),
                    'source_deduplication':'content_hash','completion_debt':any(x.get('required') is True for x in self.pending(goal)),
                    'goal_closure_is_not_inferred_from_frontier_exhaustion':True}
