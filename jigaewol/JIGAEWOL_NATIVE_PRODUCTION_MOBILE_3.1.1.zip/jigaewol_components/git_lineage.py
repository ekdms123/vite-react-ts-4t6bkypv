from __future__ import annotations

import json
import subprocess

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class LineageNode:
    branch: str
    commit: str
    parents: tuple[str, ...]
    message: str


class GitLineage:
    """Git-backed state lineage tracking: branches represent independent explorations, commits denote verified revisions."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        if not (self.root / ".git").exists():
            self._git("init", "-q")
            self._git("config", "user.email", "jigaewol@local")
            self._git("config", "user.name", "JIGAEWOL")
            (self.root / "lineage.json").write_text(json.dumps({"seed": True}), encoding="utf-8")
            self._git("add", ".")
            self._git("commit", "-qm", "seed")

    def _git(self, *args: str) -> str:
        proc = subprocess.run(
            ["git", *args],
            cwd=self.root,
            text=True,
            capture_output=True,
            check=True,
            timeout=30,
        )
        return proc.stdout.strip()

    def current_branch(self) -> str:
        return self._git("branch", "--show-current")

    def head(self) -> str:
        return self._git("rev-parse", "HEAD")

    def fork(self, branch: str, *, from_ref: str = "HEAD") -> LineageNode:
        parent = self._git("rev-parse", from_ref)
        self._git("branch", str(branch), parent)
        return LineageNode(str(branch), parent, (parent,), "fork")

    def mutate(self, branch: str, *, artifact_name: str, payload: Any, message: str) -> LineageNode:
        self._git("checkout", "-q", str(branch))
        path = self.root / artifact_name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        parent = self.head()
        self._git("add", artifact_name)
        self._git("commit", "-qm", str(message))
        return LineageNode(str(branch), self.head(), (parent,), str(message))

    def graph(self) -> str:
        return self._git("log", "--graph", "--all", "--oneline", "--decorate")

    def merge_into(self, target: str, sources: Iterable[str], *, message: str = "merge cognitive survivors") -> LineageNode:
        self._git("checkout", "-q", str(target))
        parents = [self.head()]
        for source in sources:
            parents.append(self._git("rev-parse", str(source)))
            self._git("merge", "--no-ff", "--no-edit", "-m", str(message), str(source))
        return LineageNode(str(target), self.head(), tuple(parents), str(message))


