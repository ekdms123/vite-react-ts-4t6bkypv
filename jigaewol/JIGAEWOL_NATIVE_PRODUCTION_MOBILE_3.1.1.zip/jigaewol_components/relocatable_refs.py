from __future__ import annotations

from pathlib import Path
from typing import Iterable


def resolve_python_ref(ref: str, *, roots: Iterable[str | Path] = ()) -> Path:
    """Resolve a ``python:`` ref without pinning generated code to one install path.

    New refs may be relative to a supplied state/component root. Older absolute refs
    are accepted when still valid; if they point at a previous extraction root, the
    resolver rebases the stable tail (body_builder/observer_builder/friction_repair/
    mutation_runtime/executable_memory) beneath the current roots.
    """
    value = str(ref or '')
    if not value.startswith('python:'):
        raise ValueError(f'not a python ref: {value}')
    raw = Path(value.split(':', 1)[1])
    if raw.is_file():
        return raw
    roots_t = tuple(Path(r) for r in roots if str(r))
    if not raw.is_absolute():
        for base in roots_t:
            for candidate in (base / raw, base.parent / raw):
                if candidate.is_file():
                    return candidate
    anchors = {'body_builder', 'observer_builder', 'friction_repair', 'mutation_runtime', 'executable_memory'}
    parts = raw.parts
    for i, part in enumerate(parts):
        if part not in anchors:
            continue
        tail = Path(*parts[i:])
        for base in roots_t:
            for candidate in (base / tail, base.parent / tail):
                if candidate.is_file():
                    return candidate
    return raw
