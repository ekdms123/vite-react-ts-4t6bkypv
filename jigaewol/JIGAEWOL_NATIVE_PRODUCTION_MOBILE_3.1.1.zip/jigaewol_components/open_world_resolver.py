from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class LocalOpenWorldCandidate:
    kind: str
    name: str
    ref: str
    score: float
    evidence: dict[str, Any]
    activation_state: str = "primary"


class LocalOpenWorldResolver:
    """Search the whole inventoried local host surface, not a predefined tool catalog."""

    def __init__(self, computer_root: Path) -> None:
        self.root = Path(computer_root)

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return {x for x in re.findall(r"[A-Za-z0-9_.+-]{2,}", str(text).lower())}

    def _all_candidates(self, objective: str, *, include_reserve: bool = True) -> tuple[LocalOpenWorldCandidate, ...]:
        query = self._tokens(objective)
        reports = self.root / "reports"
        rows: list[LocalOpenWorldCandidate] = []
        ep = reports / "path_executables.json"
        if ep.exists():
            for raw in json.loads(ep.read_text(encoding="utf-8")):
                name = str(raw.get("name", "")); tokens = self._tokens(name)
                overlap = len(query & tokens)
                score = overlap / max(1, len(query | tokens)) if query else 0.0
                rows.append(LocalOpenWorldCandidate("path_executable", name, str(raw.get("path", "")), score, {"availability": "observed"}, "primary" if overlap else "exaptive_reserve"))
        mp = reports / "python_modules.json"
        if mp.exists():
            for name in json.loads(mp.read_text(encoding="utf-8")):
                tokens = self._tokens(str(name)); overlap = len(query & tokens)
                score = overlap / max(1, len(query | tokens)) if query else 0.0
                rows.append(LocalOpenWorldCandidate("python_module", str(name), str(name), score, {"availability": "observed_importable_name"}, "primary" if overlap else "exaptive_reserve"))
        rows.sort(key=lambda x: (0 if x.activation_state == "primary" else 1, -x.score, x.kind, x.name))
        if include_reserve:
            return tuple(rows)
        return tuple(x for x in rows if x.activation_state == "primary")

    @staticmethod
    def _canonical_rows(rows: tuple[LocalOpenWorldCandidate, ...]) -> bytes:
        return json.dumps(
            [
                {
                    "kind": x.kind, "name": x.name, "ref": x.ref,
                    "score": x.score, "evidence": x.evidence,
                    "activation_state": x.activation_state,
                }
                for x in rows
            ],
            ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")

    def inventory(self, objective: str, *, include_reserve: bool = True) -> dict[str, Any]:
        """Materialize the complete observed local capability universe.

        The inventory is the semantic universe. Execution pages are merely bounded
        views into it and must never be interpreted as exhaustive.
        """
        rows = self._all_candidates(objective, include_reserve=include_reserve)
        canonical = self._canonical_rows(rows)
        inventory_sha256 = hashlib.sha256(canonical).hexdigest()
        objective_sha256 = hashlib.sha256(str(objective).encode("utf-8")).hexdigest()
        reservoir = self.root / "open_world_candidate_reservoir"
        reservoir.mkdir(parents=True, exist_ok=True)
        path = reservoir / f"{objective_sha256[:16]}_{inventory_sha256[:16]}.json"
        payload = {
            "schema": "jigaewol_local_open_world_reservoir_v1",
            "objective_sha256": objective_sha256,
            "inventory_sha256": inventory_sha256,
            "candidate_count": len(rows),
            "primary_count": sum(1 for x in rows if x.activation_state == "primary"),
            "reserve_count": sum(1 for x in rows if x.activation_state != "primary"),
            "execution_slice_not_semantic_ceiling": True,
            "candidates": json.loads(canonical.decode("utf-8")),
        }
        if not path.exists():
            fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(reservoir))
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                    f.flush(); os.fsync(f.fileno())
                os.replace(tmp, path)
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)
        return {
            "schema": payload["schema"],
            "objective_sha256": objective_sha256,
            "inventory_sha256": inventory_sha256,
            "candidate_count": len(rows),
            "primary_count": payload["primary_count"],
            "reserve_count": payload["reserve_count"],
            "reservoir_ref": str(path),
            "execution_slice_not_semantic_ceiling": True,
        }

    def discover_page(
        self, objective: str, *, cursor: int = 0, page_size: int = 24,
        include_reserve: bool = True,
    ) -> dict[str, Any]:
        if int(cursor) < 0:
            raise ValueError("cursor must be >= 0")
        if int(page_size) <= 0:
            raise ValueError("page_size must be > 0")
        meta = self.inventory(objective, include_reserve=include_reserve)
        payload = json.loads(Path(meta["reservoir_ref"]).read_text(encoding="utf-8"))
        rows = payload.get("candidates", [])
        start = int(cursor); end = min(len(rows), start + int(page_size))
        page_rows = tuple(LocalOpenWorldCandidate(
            kind=str(x["kind"]), name=str(x["name"]), ref=str(x["ref"]),
            score=float(x.get("score", 0.0)), evidence=dict(x.get("evidence", {})),
            activation_state=str(x.get("activation_state", "primary")),
        ) for x in rows[start:end])
        has_more = end < len(rows)
        return {
            **meta,
            "cursor": start,
            "page_size": int(page_size),
            "returned_count": len(page_rows),
            "has_more": has_more,
            "next_cursor": end if has_more else None,
            "exhausted": not has_more,
            "candidates": page_rows,
        }

    def discover(self, objective: str, *, limit: int | None = None, include_reserve: bool = True) -> tuple[LocalOpenWorldCandidate, ...]:
        """Compatibility API. ``limit=None`` returns the complete inventory.

        Runtime hot paths should prefer :meth:`discover_page` so a resource slice is
        never confused with the full capability universe.
        """
        rows = self._all_candidates(objective, include_reserve=include_reserve)
        if limit is None:
            return rows
        return rows[:max(0, int(limit))]
