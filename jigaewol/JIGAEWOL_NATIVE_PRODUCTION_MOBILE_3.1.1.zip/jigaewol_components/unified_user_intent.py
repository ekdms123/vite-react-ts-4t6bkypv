from __future__ import annotations

"""Unified user-intent decision interface.

This module gives JIGAEWOL components one immutable semantic anchor: the exact
user message bytes. Component validators remain independent, but their verdicts
are scoped to component-local claims (integrity, execution evidence, forensic
findings, invariant experiments, etc.); they cannot silently rewrite the user
objective into a different canonical intent.
"""

from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
from typing import Any, Mapping, Sequence

from .source_segmentation import trimmed_source_spans


SCHEMA = "jigaewol_unified_user_intent_v1"
DECISION_PRIORITY = (
    "exact_user_message",
    "explicit_user_clauses",
    "independent_component_validation",
    "observed_execution_evidence",
    "derived_search_hypotheses",
)



def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n").encode("utf-8")
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    tmp_path = Path(tmp)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(raw)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, path)
    finally:
        tmp_path.unlink(missing_ok=True)


def _explicit_clause_spans(text: str, whole_sha256: str = "") -> tuple[dict[str, Any], ...]:
    # Keep clauses source-grounded: split only on visible sentence/newline boundaries,
    # and store hashes/spans instead of duplicating plaintext into governance state.
    rows: list[dict[str, Any]] = []
    stripped = text.strip()
    if stripped:
        # Common fast path: a single clause with only terminal punctuation. Reuse the
        # already-computed whole-message SHA when trimming did not change the source.
        body = stripped.rstrip(".!?。！？")
        if "\n" not in stripped and "\r" not in stripped and not any(ch in body for ch in ".!?。！？"):
            start = len(text) - len(text.lstrip())
            digest = whole_sha256 if stripped == text and len(whole_sha256) == 64 else _sha(stripped.encode("utf-8"))
            return ({
                "index": 0, "source_start": start, "source_end": start + len(stripped),
                "clause_sha256": digest, "explicit": True,
            },)
    for start, end in trimmed_source_spans(text):
        clause = text[start:end]
        rows.append({
            "index": len(rows),
            "source_start": start,
            "source_end": end,
            "clause_sha256": _sha(clause.encode("utf-8")),
            "explicit": True,
        })
    if not rows and text:
        rows.append({
            "index": 0,
            "source_start": 0,
            "source_end": len(text),
            "clause_sha256": _sha(text.encode("utf-8")),
            "explicit": True,
        })
    return tuple(rows)


@dataclass(frozen=True, slots=True)
class UnifiedIntentEnvelope:
    exact_user_message_sha256: str
    raw_byte_count: int
    utf8_text_length: int
    explicit_clause_spans: tuple[dict[str, Any], ...]
    canonical_goal_id: str
    sequence: int = 0
    schema: str = SCHEMA

    def as_mapping(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "single_source_of_truth": "exact_user_message_bytes",
            "semantic_final_decision_authority": "explicit_user_intent",
            "decision_priority": DECISION_PRIORITY,
            "independent_validation_preserved": True,
            "validator_authority_scope": "component_local_claims_only",
            "validators_may_rewrite_canonical_intent": False,
            "derived_hypotheses_may_expand_routes": True,
            "derived_hypotheses_may_replace_explicit_clauses": False,
            "execution_evidence_may_close_only_proven_effects": True,
        }


@dataclass(frozen=True, slots=True)
class ComponentIntentBinding:
    component: str
    exact_user_message_sha256: str
    canonical_goal_id: str
    validation_passed: bool
    validation_scope: str
    evidence_refs: tuple[str, ...] = ()
    details: Mapping[str, Any] | None = None

    def as_mapping(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "single_source_of_truth": "exact_user_message_bytes",
            "semantic_decision_authority": "explicit_user_intent",
            "component_may_rewrite_canonical_intent": False,
            "independent_validation_preserved": True,
        }


def build_unified_intent_envelope(
    raw_message_bytes: bytes, *, sequence: int = 0, _precomputed_sha256: str = "", _decoded_text: str | None = None
) -> UnifiedIntentEnvelope:
    raw = bytes(raw_message_bytes)
    text = str(_decoded_text) if _decoded_text is not None else raw.decode("utf-8", errors="strict")
    message_sha = str(_precomputed_sha256 or "").strip().lower()
    if not message_sha:
        message_sha = _sha(raw)
    elif len(message_sha) != 64:
        raise ValueError("_precomputed_sha256 must be a sha256 hex digest")
    return UnifiedIntentEnvelope(
        exact_user_message_sha256=message_sha,
        raw_byte_count=len(raw),
        utf8_text_length=len(text),
        explicit_clause_spans=_explicit_clause_spans(text, message_sha),
        canonical_goal_id="user_goal_" + message_sha[:24],
        sequence=int(sequence),
    )


def reference_for_sha(
    message_sha256: str,
    *,
    component: str,
    validation_passed: bool = True,
    validation_scope: str = "semantic_binding",
    evidence_refs: Sequence[str] = (),
    details: Mapping[str, Any] | None = None,
) -> ComponentIntentBinding:
    digest = str(message_sha256 or "").strip().lower()
    if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise ValueError("exact user message sha256 is required for unified intent binding")
    return ComponentIntentBinding(
        component=str(component),
        exact_user_message_sha256=digest,
        canonical_goal_id="user_goal_" + digest[:24],
        validation_passed=bool(validation_passed),
        validation_scope=str(validation_scope),
        evidence_refs=tuple(str(x) for x in evidence_refs if str(x)),
        details=dict(details or {}),
    )


class UnifiedIntentKernel:
    """Persist one semantic envelope and independent component validation bindings."""

    def __init__(self, state_root: str | Path) -> None:
        self.root = Path(state_root) / "unified_user_intent"
        self.envelopes = self.root / "envelopes"
        self.validations = self.root / "component_validations.jsonl"
        self.root.mkdir(parents=True, exist_ok=True)

    def persist(
        self,
        envelope: UnifiedIntentEnvelope,
        *,
        source_ref: str = "",
        component: str = "gateway",
        validation_passed: bool = True,
        validation_scope: str = "exact_message_integrity",
        evidence_refs: Sequence[str] = (),
        details: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = envelope.as_mapping()
        payload.update({
            "source_ref": str(source_ref),
            "persisted_at": time.time(),
        })
        path = self.envelopes / f"{envelope.exact_user_message_sha256}.json"
        if path.exists():
            existing = json.loads(path.read_text(encoding="utf-8"))
            if str(existing.get("exact_user_message_sha256")) != envelope.exact_user_message_sha256:
                raise RuntimeError("unified intent envelope collision")
            # Preserve the first semantic envelope; only fill a missing source ref.
            if not existing.get("source_ref") and source_ref:
                existing["source_ref"] = str(source_ref)
                _atomic_json(path, existing)
            payload = existing
        else:
            _atomic_json(path, payload)

        binding = reference_for_sha(
            envelope.exact_user_message_sha256,
            component=component,
            validation_passed=validation_passed,
            validation_scope=validation_scope,
            evidence_refs=evidence_refs,
            details=details,
        ).as_mapping()
        binding["observed_at"] = time.time()
        self.validations.parent.mkdir(parents=True, exist_ok=True)
        with self.validations.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(binding, ensure_ascii=False, sort_keys=True, default=str) + "\n")
            fh.flush()
        return {
            "envelope": payload,
            "envelope_path": str(path),
            "component_binding": binding,
        }

    def bind_sha(
        self,
        message_sha256: str,
        *,
        component: str,
        validation_passed: bool,
        validation_scope: str,
        evidence_refs: Sequence[str] = (),
        details: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        binding = reference_for_sha(
            message_sha256,
            component=component,
            validation_passed=validation_passed,
            validation_scope=validation_scope,
            evidence_refs=evidence_refs,
            details=details,
        ).as_mapping()
        binding["observed_at"] = time.time()
        self.validations.parent.mkdir(parents=True, exist_ok=True)
        with self.validations.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(binding, ensure_ascii=False, sort_keys=True, default=str) + "\n")
            fh.flush()
        return binding
