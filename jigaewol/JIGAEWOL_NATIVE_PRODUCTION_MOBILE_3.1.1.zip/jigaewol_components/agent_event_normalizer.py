from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class AgentEvent:
    provider_id: str
    kind: str
    session_id: str
    status: str
    text: str = ""
    label: str = ""
    tool_call_id: str = ""
    raw_type: str = ""
    raw_sha256: str = ""
    observed_at: float = 0.0

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


def _sha(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()


def _text_blocks(content: Any) -> list[str]:
    if isinstance(content, str):
        return [content]
    out: list[str] = []
    if isinstance(content, list):
        for block in content:
            if isinstance(block, Mapping) and block.get("type") == "text" and isinstance(block.get("text"), str):
                out.append(str(block["text"]))
    return out


class AgentEventNormalizer:
    """Normalize provider JSONL without pretending unknown shapes are understood."""

    def parse_line(self, provider_id: str, raw: str) -> tuple[AgentEvent, ...]:
        provider_id = str(provider_id)
        try:
            row = json.loads(raw)
        except json.JSONDecodeError:
            return (AgentEvent(provider_id, "error", "", "invalid_json", text=raw, raw_type="invalid_json", raw_sha256=_sha(raw), observed_at=time.time()),)
        if not isinstance(row, Mapping):
            return ()
        if provider_id == "codex":
            return self._codex(row, raw)
        if provider_id == "claude":
            return self._claude(row, raw)
        return (AgentEvent(provider_id, "raw_event", str(row.get("session_id") or ""), "observed", raw_type=str(row.get("type") or ""), raw_sha256=_sha(raw), observed_at=time.time()),)

    def _event(self, provider: str, row: Mapping[str, Any], raw: str, kind: str, status: str, **kwargs: Any) -> AgentEvent:
        return AgentEvent(provider, kind, str(kwargs.pop("session_id", row.get("session_id") or "")), status, raw_type=str(row.get("type") or ""), raw_sha256=_sha(raw), observed_at=time.time(), **kwargs)

    def _codex(self, row: Mapping[str, Any], raw: str) -> tuple[AgentEvent, ...]:
        typ = str(row.get("type") or "")
        session_id = str(row.get("session_id") or row.get("thread_id") or "")
        if typ in {"turn.started", "turn.created"}:
            return (self._event("codex", row, raw, "turn_start", "running", session_id=session_id),)
        if typ == "turn.completed":
            return (self._event("codex", row, raw, "turn_end", "succeeded", session_id=session_id),)
        if typ in {"turn.failed", "turn.cancelled"}:
            return (self._event("codex", row, raw, "error" if typ == "turn.failed" else "turn_end", "failed" if typ == "turn.failed" else "cancelled", session_id=session_id, text=str(row.get("error") or "")),)
        if typ in {"item.started", "item.completed"}:
            item = row.get("item") if isinstance(row.get("item"), Mapping) else {}
            item_type = str(item.get("type") or "")
            status = "completed" if typ.endswith("completed") else "running"
            if item_type == "command_execution":
                command = item.get("command")
                if isinstance(command, list): command = " ".join(map(str, command))
                return (self._event("codex", row, raw, "tool_call", status, session_id=session_id, label=str(command or "command_execution"), tool_call_id=str(item.get("id") or "")),)
            if item_type in {"agent_message", "message"}:
                text = str(item.get("text") or item.get("content") or "")
                return (self._event("codex", row, raw, "assistant_text", status, session_id=session_id, text=text),)
            return (self._event("codex", row, raw, "activity", status, session_id=session_id, label=item_type),)
        if typ in {"error", "stream_error"}:
            return (self._event("codex", row, raw, "error", "failed", session_id=session_id, text=str(row.get("message") or row.get("error") or "")),)
        return (self._event("codex", row, raw, "raw_event", "observed", session_id=session_id),)

    def normalize_host_agent_result(self, provider_id: str, result: Mapping[str, Any]) -> tuple[AgentEvent, ...]:
        """Normalize a closed-loop host-agent result envelope after the host action returns.

        This does not infer cognition from arbitrary tool results; callers must use it only for
        host surfaces already classified as agent-backed.
        """
        provider_id = str(provider_id)
        raw = json.dumps(dict(result), ensure_ascii=False, sort_keys=True, default=str)
        session_id = str(result.get("threadId") or result.get("thread_id") or result.get("session_id") or "")
        now = time.time(); out: list[AgentEvent] = []
        if session_id:
            out.append(AgentEvent(provider_id,"session_init",session_id,"running",raw_type="host_agent_result",raw_sha256=_sha(raw),observed_at=now))
        calls = result.get("toolCalls") if isinstance(result.get("toolCalls"), list) else result.get("tool_calls")
        if isinstance(calls, list):
            for idx, call in enumerate(calls):
                if not isinstance(call, Mapping): continue
                call_id = str(call.get("id") or call.get("call_id") or f"tool_{idx}")
                label = str(call.get("toolName") or call.get("tool_name") or call.get("name") or "tool")
                out.append(AgentEvent(provider_id,"tool_call",session_id,"completed" if not call.get("isError") else "failed",label=label,tool_call_id=call_id,raw_type="host_agent_tool",raw_sha256=_sha(raw+f":call:{idx}"),observed_at=now))
                if "result" in call:
                    text=json.dumps(call.get("result"),ensure_ascii=False,sort_keys=True,default=str)
                    out.append(AgentEvent(provider_id,"tool_result",session_id,"failed" if call.get("isError") else "observed",text=text,tool_call_id=call_id,raw_type="host_agent_tool_result",raw_sha256=_sha(raw+f":result:{idx}"),observed_at=now))
        response = result.get("response") or result.get("result") or result.get("output")
        if response is None and result.get("status") == "completed" and "data" in result:
            response = result.get("data")
        if isinstance(response, str) and response:
            out.append(AgentEvent(provider_id,"assistant_text",session_id,"observed",text=response,raw_type="host_agent_response",raw_sha256=_sha(raw+":response"),observed_at=now))
        elif isinstance(response, (Mapping, list)):
            text=json.dumps(response,ensure_ascii=False,sort_keys=True,default=str)
            out.append(AgentEvent(provider_id,"assistant_text",session_id,"observed",text=text,raw_type="host_agent_structured_response",raw_sha256=_sha(raw+":response"),observed_at=now))
        failed = bool(result.get("isError") or result.get("error") or str(result.get("status") or "").casefold()=="failed")
        out.append(AgentEvent(provider_id,"error" if failed else "turn_end",session_id,"failed" if failed else "succeeded",text=str(result.get("error") or ""),raw_type="host_agent_terminal",raw_sha256=_sha(raw+":terminal"),observed_at=now))
        return tuple(out)

    def _claude(self, row: Mapping[str, Any], raw: str) -> tuple[AgentEvent, ...]:
        typ = str(row.get("type") or "")
        subtype = str(row.get("subtype") or "")
        session_id = str(row.get("session_id") or "")
        if typ == "system" and subtype == "init":
            return (self._event("claude", row, raw, "session_init", "running", session_id=session_id),)
        if typ == "result":
            failed = bool(row.get("is_error")) or subtype not in {"", "success"}
            return (self._event("claude", row, raw, "turn_end" if not failed else "error", "failed" if failed else "succeeded", session_id=session_id, text=str(row.get("result") or row.get("error") or "")),)
        message = row.get("message") if isinstance(row.get("message"), Mapping) else {}
        content = message.get("content")
        events: list[AgentEvent] = []
        if typ == "assistant":
            for text in _text_blocks(content):
                events.append(self._event("claude", row, raw, "assistant_text", "observed", session_id=session_id, text=text))
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, Mapping) and block.get("type") == "tool_use":
                        events.append(self._event("claude", row, raw, "tool_call", "running", session_id=session_id, label=str(block.get("name") or "tool"), tool_call_id=str(block.get("id") or "")))
        elif typ == "user" and isinstance(content, list):
            for block in content:
                if isinstance(block, Mapping) and block.get("type") == "tool_result":
                    text = block.get("content")
                    if not isinstance(text, str): text = json.dumps(text, ensure_ascii=False, sort_keys=True, default=str)
                    events.append(self._event("claude", row, raw, "tool_result", "observed", session_id=session_id, text=text, tool_call_id=str(block.get("tool_use_id") or "")))
        if events:
            return tuple(events)
        return (self._event("claude", row, raw, "raw_event", "observed", session_id=session_id),)


class AgentEventJournal:
    FORMAT = "jigaewol_agent_event_journal_v1"

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve(); self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "events.jsonl"

    def append(self, event: AgentEvent) -> dict[str, Any]:
        row = {"format": self.FORMAT, **event.as_mapping()}
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        return row

    def ingest_jsonl(self, provider_id: str, lines: Iterable[str], normalizer: AgentEventNormalizer | None = None) -> tuple[dict[str, Any], ...]:
        norm = normalizer or AgentEventNormalizer(); out=[]
        for raw in lines:
            if not str(raw).strip(): continue
            for event in norm.parse_line(provider_id, str(raw)):
                out.append(self.append(event))
        return tuple(out)

    def session_summary(self, provider_id: str, session_id: str) -> dict[str, Any]:
        rows=[]
        if self.path.is_file():
            for raw in self.path.read_text(encoding="utf-8").splitlines():
                if not raw.strip(): continue
                row=json.loads(raw)
                if row.get("provider_id")==provider_id and row.get("session_id")==session_id: rows.append(row)
        kinds=[str(x.get("kind") or "") for x in rows]
        terminal=[x for x in rows if x.get("kind") in {"turn_end","error"} and x.get("status") in {"succeeded","failed","cancelled"}]
        return {
            "provider_id":provider_id,"session_id":session_id,"event_count":len(rows),"event_kinds":kinds,
            "session_observed": bool(session_id and rows),
            "tool_call_count": sum(1 for x in rows if x.get("kind")=="tool_call"),
            "terminal_observed": bool(terminal),
            "terminal_status": str(terminal[-1].get("status") or "") if terminal else "",
            "closed_loop_result_observed": any(x.get("kind")=="turn_end" and x.get("status")=="succeeded" for x in rows),
        }
