"""Current authenticated chat model continuation, bound to exact canonical input.

The host returns this payload as its tool result to its existing model. Completion
ingests that model's exact outgoing response and real host observations. No model
endpoint, credentials, fabricated callback, or independent platform event is used.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Mapping

from .frontier_cognition import FrontierCognition
from .response_sink import ResponseCAS
from .snapshot_store import load_snapshot
from .turn_production import TurnProduction


def _digest(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def _atomic(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name, dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, default=str)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


class NativeHostContinuation:
    """Canonical input and outgoing response rendezvous for an existing chat host."""

    def __init__(self, state_root: str | Path, *, session: str = 'mobile_chat'):
        self.state_root = Path(state_root).resolve()
        self.session = str(session)
        self.root = self.state_root / 'native_host_continuation'

    def _canonical_observation(self, observation: Mapping[str, Any], *,
                               release_turn_id: str, original_text: str) -> dict[str, Any]:
        """Bind missing transport metadata only to the exact persisted request.

        Older host dispatch receipts omitted request_sha256 while retaining the
        actually called tool and argument digest. Recover that transport field
        from its canonical action after checking its entire hashed request, turn,
        original source and actual call arguments. A supplied mismatch is rejected.
        """
        from .canonical_host_bridge import CanonicalHostBridge

        item = dict(observation)
        action_id = str(item.get('action_id') or '').strip()
        if not action_id:
            return item
        bridge = CanonicalHostBridge(self.state_root / 'canonical_host_bridge')
        action = bridge._read().get('actions', {}).get(action_id)
        if not action or action.get('release_turn_id') != release_turn_id:
            raise PermissionError('host observation action belongs to another turn')
        payload = dict(action.get('payload') or {})
        source_sha = _digest(original_text)
        material = {key: action[key] for key in (
            'release_turn_id', 'capability', 'family', 'preferred_executors',
            'payload', 'required', 'zero_cost_only')}
        request_sha = str(action.get('request_sha256') or '')
        if bridge._sha(material) != request_sha:
            raise PermissionError('canonical host request payload hash mismatch')
        provided_sha = str(item.get('request_sha256') or '')
        if provided_sha and provided_sha != request_sha:
            raise PermissionError('host observation request hash mismatch')
        tool = str(payload.get('host_tool_name') or '')
        if not tool:
            # Other existing canonical action families (including image actions)
            # carry their own original-source contracts. Keep those routes and
            # their release-runtime guards, but never infer a missing request hash
            # from an observation without the live-dispatch exact-call contract.
            if not provided_sha:
                raise PermissionError('host observation requires canonical request hash')
            contract_sha = str(payload.get('exact_user_message_sha256') or payload.get('requirement_message_sha256') or '')
            if contract_sha and contract_sha != source_sha:
                raise PermissionError('host observation action original source mismatch')
            item.update(source_sha256=source_sha, release_turn_id=release_turn_id,
                        capability=action.get('capability', ''))
            return item
        if (payload.get('exact_user_message_sha256') != source_sha
                or payload.get('objective') != original_text
                or dict(payload.get('user_authority') or {}).get('current_source_sha256') != source_sha):
            raise PermissionError('host observation action original source mismatch')
        called_tool = str(item.get('resolved_tool') or item.get('tool') or '')
        if not tool or called_tool != tool:
            raise PermissionError('host observation called tool mismatch')
        args = payload.get('host_tool_args')
        if not isinstance(args, dict):
            raise PermissionError('canonical host tool arguments missing')
        args_sha = bridge._sha(args)
        if (payload.get('host_tool_args_sha256') != args_sha
                or item.get('args_sha256') != args_sha):
            raise PermissionError('host observation argument hash mismatch')
        if 'args' in item and (not isinstance(item['args'], dict) or bridge._sha(item['args']) != args_sha):
            raise PermissionError('host observation actual arguments mismatch')
        item.update(request_sha256=request_sha, source_sha256=source_sha,
                    release_turn_id=release_turn_id, capability=action.get('capability', ''))
        item['canonical_request_binding'] = {
            'action_id': action_id, 'request_sha256': request_sha,
            'source_sha256': source_sha, 'args_sha256': args_sha,
            'called_tool': called_tool,
            'transport_request_sha256_recovered': not bool(provided_sha),
        }
        return item

    def _update_continuity(self, row: Mapping[str, Any], snapshot: Mapping[str, Any]) -> None:
        """Carry the observed turn forward without replacing inherited context."""
        path = self.state_root / 'session_continuity.json'
        continuity = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {}
        if continuity.get('session', self.session) != self.session:
            raise ValueError('session continuity belongs to another session')
        history = list(continuity.get('observed_turn_history') or [])
        if not history and continuity.get('release_turn_id') and continuity.get('source_sha256'):
            history.append({key: continuity[key] for key in (
                'release_turn_id', 'source_sha256', 'source_exact_text', 'recorded_at') if key in continuity})
        finalizer = dict(row.get('finalizer_receipt') or {})
        current_open = {
            'current_turn_goal_completed': row.get('current_turn_goal_completed') is True,
            'continuation_state': row.get('state'),
            'requirement_missing_ids': list(finalizer.get('requirement_missing_ids') or []),
            'objective_completion_unresolved_goal_refs': list(
                finalizer.get('objective_completion_unresolved_goal_refs') or []),
            'finalizer_missing': list(finalizer.get('missing') or []),
            'open_execution_state': dict(snapshot.get('open_execution_state') or {}),
            'canonical_turn_snapshot': str(self.state_root / 'core_turns' / (str(row['release_turn_id']) + '.json')),
            'observed_host_failures': list(row.get('observed_host_failures') or []),
        }
        observed = {key: row[key] for key in (
            'release_turn_id', 'source_sha256', 'source_exact_text', 'state', 'host_event_id',
            'response_sha256', 'response_byte_count', 'response_blob', 'response_archive',
            'host_observations_file', 'bound_host_evidence', 'finalizer_receipt',
            'sequencing_closure', 'completion_error', 'current_turn_goal_completed') if key in row}
        observed['current_open_work'] = current_open
        observed['record_path'] = str(self.root / 'turns' / (str(row['release_turn_id']) + '.json'))
        history = [item for item in history if item.get('release_turn_id') != row['release_turn_id']]
        history.append(observed)
        continuity.update(
            schema=continuity.get('schema', 'jigaewol_session_continuity_v1'),
            session=self.session, effective_state_root=str(self.state_root),
            source_exact_text=row['source_exact_text'], source_sha256=row['source_sha256'],
            release_turn_id=row['release_turn_id'], native_continuation_state=row['state'],
            current_host_model_response_observed=bool(row.get('response_sha256')),
            current_model_response={'sha256': row.get('response_sha256'),
                                    'byte_count': row.get('response_byte_count'),
                                    'cas_file': row.get('response_blob'),
                                    'archive': row.get('response_archive')},
            actual_host_observations_file=row.get('host_observations_file'),
            actual_bound_host_evidence=list(row.get('bound_host_evidence') or []),
            current_finalizer_receipt=finalizer, current_open_work=current_open,
            observed_turn_history=history, updated_at=time.time(),
            current_explicit_user_source_is_authority=True)
        _atomic(path, continuity)

    def begin(self, original_text: str, gateway_payload: Mapping[str, Any], *,
              release_turn_id: str, host_event_id: str) -> dict[str, Any]:
        if not original_text:
            raise ValueError('exact original user message required')
        snapshot = load_snapshot(self.state_root / 'core_turns' / (release_turn_id + '.json'))
        sha = _digest(original_text)
        if snapshot.get('command_sha256') != sha:
            raise ValueError('native continuation canonical source mismatch')
        continuity_file = self.state_root / 'session_continuity.json'
        continuity = json.loads(continuity_file.read_text(encoding='utf-8')) if continuity_file.is_file() else {}
        value = {
            'schema': 'jigaewol_native_host_continuation_v1',
            'state': 'ready_for_current_host_model',
            'session': self.session,
            'release_turn_id': release_turn_id,
            'host_event_id': host_event_id,
            'source_sha256': sha,
            'source_exact_text': original_text,
            'source_byte_count': len(original_text.encode('utf-8')),
            'current_host_model_route': 'canonical_tool_result_to_existing_chat_model',
            'model_api_required': False,
            'user_terminal_or_file_operation_required': False,
            'python_model_callback_invoked': False,
            'independent_platform_message_event_registered': False,
            'cognitive_payload': dict(gateway_payload.get('cognitive_frontier') or {}),
            'canonical_requirement_contract': dict(snapshot.get('requirement_contract') or {}),
            'continuity_context': continuity,
            'continuity_is_additive': True,
            'host_contract': {
                'source_authority': 'entire exact current user message',
                'execute_authorized_work': True,
                'preserve_existing_functions_and_full_requested_goal': True,
                'return_exact_outgoing_response_to_completion_lane': True,
                'preserve_actual_host_observations': True,
                'completion_command': 'tools/jigaewol_native_continuation.py',
            },
            'created_at': time.time(),
        }
        production=TurnProduction(self.state_root/'turn_production')
        value['production_request']=production.begin(original_text,release_turn_id)
        value['host_contract']['production_entrypoint']='tools/jigaewol_produce.py'
        value['host_contract']['produce_execute_compare_and_learn']=True
        path = self.root / 'turns' / (release_turn_id + '.json')
        if path.exists():
            previous = json.loads(path.read_text(encoding='utf-8'))
            if previous.get('source_sha256') != sha or previous.get('session') != self.session:
                raise ValueError('native continuation turn identity conflict')
            if previous.get('state') in ('response_observed', 'completed', 'continued_open'):
                return {**previous, 'record_path': str(path)}
        _atomic(path, value)
        return {**value, 'record_path': str(path)}

    def complete(self, *, release_turn_id: str, original_text: str, response_text: str,
                 observations: list[dict[str, Any]] | None = None,
                 requirement_manifest: dict[str, Any] | None = None,
                 control_checkpoint_id: str = '', generation_source: str = 'current_host_model_tool_continuation',
                 python_model_callback_invoked: bool = False) -> dict[str, Any]:
        from jigaewol_core.release_runtime import CanonicalReleaseRuntime

        path = self.root / 'turns' / (release_turn_id + '.json')
        row = json.loads(path.read_text(encoding='utf-8'))
        sha, response_sha = _digest(original_text), _digest(response_text)
        if row.get('session') != self.session or row.get('release_turn_id') != release_turn_id:
            raise ValueError('native continuation session or turn mismatch')
        if row.get('source_sha256') != sha or row.get('source_exact_text') != original_text:
            raise ValueError('native continuation exact source mismatch')
        if not response_text:
            raise ValueError('exact outgoing host response required')
        if row.get('response_sha256') and row['response_sha256'] != response_sha:
            raise ValueError('native continuation already bound to a different response')
        if row.get('state') == 'completed':
            return {**row, 'record_path': str(path)}
        snapshot = load_snapshot(self.state_root / 'core_turns' / (release_turn_id + '.json'))
        if snapshot.get('command_sha256') != sha:
            raise ValueError('canonical turn no longer matches the original message')

        # Save the entire host generation before finalization; byte identity remains
        # separate from semantic delivery completion and all unfinished work survives.
        archive = FrontierCognition(self.state_root).observe(
            original_text, response_text, host_event_id=str(row['host_event_id']),
            generation_source=generation_source)
        cas_sha, byte_count, blob_path = ResponseCAS(self.root / 'responses').put_text(
            response_text, expected_sha256=response_sha)
        runtime = CanonicalReleaseRuntime(self.state_root, session_id=self.session)
        bound, observed_failures = [], []
        observation_path = self.root / 'observations' / (release_turn_id + '.json')
        observations = observations or []
        for observation in observations:
            if observation.get('release_turn_id', release_turn_id) != release_turn_id:
                raise ValueError('host observation belongs to another turn')
            if observation.get('source_sha256', sha) != sha:
                raise ValueError('host observation belongs to another original message')
            if observation.get('actual_host_call') is not True:
                raise ValueError('host observation requires actual_host_call=true')
        _atomic(observation_path, {'source_sha256': sha, 'release_turn_id': release_turn_id,
                                  'observations': observations})
        row.update(state='response_observed', response_sha256=response_sha,
                   response_byte_count=byte_count, response_blob=str(blob_path),
                   response_archive=archive, host_observations_file=str(observation_path),
                   response_observed_at=time.time(), current_turn_goal_completed=False)
        _atomic(path, row)
        self._update_continuity(row, snapshot)
        try:
            observations = [self._canonical_observation(
                item, release_turn_id=release_turn_id, original_text=original_text) for item in observations]
        except (ValueError, PermissionError, KeyError) as exc:
            row['completion_error'] = {'type': type(exc).__name__, 'message': str(exc)}
            _atomic(path, row)
            self._update_continuity(row, snapshot)
            raise
        _atomic(observation_path, {'source_sha256': sha, 'release_turn_id': release_turn_id,
                                  'observations': observations})
        existing = {item.get('origin_ref') for item in row.get('bound_host_evidence', [])}
        for observation in observations:
            if observation.get('success') is not True or observation.get('is_error') is True:
                observed_failures.append(observation)
                failure_path = self.state_root / 'failure_truth.jsonl'
                with failure_path.open('a', encoding='utf-8') as failures:
                    failures.write(json.dumps({'time': time.time(), 'component': 'native_host_continuation',
                                               'event': 'actual_host_call_failure', 'release_turn_id': release_turn_id,
                                               'source_sha256': sha, 'observation': observation},
                                              ensure_ascii=False, default=str) + '\n')
                continue
            origin = str(observation.get('origin_ref') or '').strip()
            if not origin:
                raise ValueError('successful host observation requires its origin_ref')
            if origin in existing:
                continue
            evidence = dict(observation)
            evidence.update(provider=str(observation.get('provider') or 'current_chat_host'),
                            operation=str(observation.get('operation') or observation.get('tool') or 'host_tool'),
                            success=True, origin_ref=origin)
            bound.append({**runtime.bind_external_host_execution(release_turn_id, evidence),
                          **{key: evidence[key] for key in ('action_id', 'request_sha256', 'source_sha256',
                                                           'args_sha256', 'canonical_request_binding') if key in evidence}})
        row.update(state='response_observed', response_sha256=response_sha,
                   response_byte_count=byte_count, response_blob=str(blob_path),
                   response_archive=archive, host_observations_file=str(observation_path),
                   bound_host_evidence=[*row.get('bound_host_evidence', []), *bound],
                   observed_host_failures=observed_failures, response_observed_at=time.time())
        _atomic(path, row)
        self._update_continuity(row, snapshot)
        finalizer = runtime.finalize_canonical_turn(
            release_turn_id, ingress_verified=True,
            control_checkpoint_id=control_checkpoint_id or str(snapshot.get('control_checkpoint_id') or ''),
            final_response_sha256=cas_sha, expected_response_sha256=response_sha,
            final_response_text=response_text, requirement_manifest=requirement_manifest)
        completed = (finalizer.get('final_response_allowed') is True
                     and finalizer.get('application_state') == 'applied_full')
        closure = None
        if not completed and finalizer.get('progress_response_allowed') is True and snapshot.get('gateway_turn_id'):
            closure = runtime.finalizer.continue_unfinalized_gateway_turn(
                gateway_turn_id=str(snapshot['gateway_turn_id']),
                gateway_sequence=int(snapshot['gateway_sequence']),
                gateway_token_sha256=str(snapshot['gateway_token_sha256']),
                gateway_scope_sha256=str(snapshot.get('gateway_scope_sha256') or ''),
                reason='observed native host response archived; remaining user work continues',
                continuation_origin_ref='native-host-response:' + response_sha)
        row.pop('completion_error', None)
        row.update(state='completed' if completed else ('continued_open' if closure else 'response_observed'),
                   current_host_model_response_observed=True,
                   python_model_callback_invoked=python_model_callback_invoked,
                   generation_source=generation_source,
                   current_turn_goal_completed=completed,
                   independent_platform_message_event_registered=False,
                   finalizer_receipt=finalizer, sequencing_closure=closure,
                   outgoing_response_sha256=response_sha,
                   outgoing_response_file=str(blob_path),
                   updated_at=time.time())
        production_request=row.get('production_request') or {}
        task_id=dict(production_request.get('task') or {}).get('task_id')
        if task_id:
            row['production_state']=TurnProduction(self.state_root/'turn_production').note_response(
                task_id,response_text,goal_completed=completed,
                remaining_work=finalizer.get('objective_completion_unresolved_goal_refs') or finalizer.get('requirement_missing_ids') or [])
        _atomic(path, row)
        self._update_continuity(row, snapshot)
        return {**row, 'record_path': str(path)}
