from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .execution_plane import ExecutionReceipt
from .registry_paths import rebase_project_paths
from .host_identity import current_host_fingerprint


class CapabilityRegistry:
    """Dynamic capability registry supporting progressive execution verification.

    Capabilities can be discovered and marked as available before execution.
    The 'active' state is conferred upon receiving a verified successful execution receipt.
    """

    def __init__(self, registry_path: Path, project_root: Path) -> None:
        self.path = registry_path
        self.project_root = project_root.resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write(self._empty())
        else:
            data = self._read_raw()
            changed = self._normalize(data)
            changed = rebase_project_paths(data, self.project_root) or changed
            changed = self._reconcile_host_scoped(data) or changed
            if changed:
                self._write(data)

    @staticmethod
    def _empty() -> dict[str, Any]:
        return {
            "available": [],
            "active": [],
            "lifecycle": {},
            "external": {},
        }

    def _read_raw(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _normalize(self, data: dict[str, Any]) -> bool:
        changed = False
        if "available" not in data:
            data["available"] = sorted(set(data.get("active", [])))
            data["active"] = []
            changed = True
        if "active" not in data:
            data["active"] = []
            changed = True
        if "lifecycle" not in data:
            data["lifecycle"] = {}
            changed = True
        if "external" not in data:
            data["external"] = {}
            changed = True

        active = set(data.get("active", []))
        for capability_id in data.get("available", []):
            if capability_id not in data["lifecycle"]:
                data["lifecycle"][capability_id] = {
                    "state": "available",
                    "facts": ["available"],
                    "attempts": [],
                }
                changed = True
            lifecycle = data["lifecycle"][capability_id]
            facts = set(lifecycle.get("facts", []))
            facts.add("available")
            if capability_id in active:
                facts.update(("executed_successfully", "active"))
            normalized_facts = sorted(facts)
            if lifecycle.get("facts") != normalized_facts:
                lifecycle["facts"] = normalized_facts
                changed = True
        return changed

    def _reconcile_host_scoped(self, data: dict[str, Any]) -> bool:
        """Synchronize execution status with current host environment safely."""
        changed = False
        current = current_host_fingerprint()
        active = set(data.get("active", []))
        for capability_id, lifecycle in data.get("lifecycle", {}).items():
            if not isinstance(lifecycle, dict):
                continue
            binding = lifecycle.get("binding")
            if not isinstance(binding, dict) or binding.get("scope") != "host_local":
                continue
            bound_host = binding.get("host_fingerprint")
            if not bound_host or bound_host == current:
                continue
            if capability_id in active:
                active.remove(capability_id)
                changed = True
            facts = set(lifecycle.get("facts", []))
            if "active" in facts:
                facts.remove("active")
                changed = True
            if "executed_successfully" in facts:
                facts.remove("executed_successfully")
                facts.add("historical_host_success")
                changed = True
            lifecycle["facts"] = sorted(facts)
            lifecycle["state"] = "available"
            lifecycle["host_refresh"] = {
                "from": str(bound_host),
                "to": current,
                "status": "reprobe_ready",
            }
        if changed:
            data["active"] = sorted(active)
        return changed

    def read(self) -> dict[str, Any]:
        data = self._read_raw()
        if self._normalize(data):
            self._write(data)
        return data

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def declare_available(
        self,
        capability_id: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        data = self.read()
        available = set(data.get("available", []))
        newly_available = capability_id not in available
        available.add(capability_id)
        data["available"] = sorted(available)
        lifecycle = data.setdefault("lifecycle", {}).setdefault(
            capability_id, {"state": "available", "facts": [], "attempts": []}
        )
        facts = set(lifecycle.setdefault("facts", []))
        facts.add("available")
        lifecycle["facts"] = sorted(facts)
        if capability_id not in set(data.get("active", [])):
            lifecycle["state"] = "available"
        if metadata is not None:
            lifecycle["binding"] = metadata
        self._write(data)
        return newly_available

    def record_selected(self, capability_id: str, *, trigger_id: str) -> None:
        data = self.read()
        available = set(data.get("available", []))
        available.add(capability_id)
        data["available"] = sorted(available)
        lifecycle = data.setdefault("lifecycle", {}).setdefault(
            capability_id, {"state": "available", "facts": [], "attempts": []}
        )
        facts = set(lifecycle.setdefault("facts", []))
        facts.update(("available", "selected"))
        lifecycle["facts"] = sorted(facts)
        if capability_id not in set(data.get("active", [])):
            lifecycle["state"] = "selected"
        lifecycle["last_trigger_id"] = trigger_id
        self._write(data)

    def record_execution(
        self,
        capability_id: str,
        receipt: ExecutionReceipt,
        *,
        trigger_id: str | None = None,
    ) -> bool:
        data = self.read()
        available = set(data.get("available", []))
        available.add(capability_id)
        data["available"] = sorted(available)

        active = set(data.get("active", []))
        was_active = capability_id in active
        succeeded = receipt.exit_code == 0
        if succeeded:
            active.add(capability_id)
        data["active"] = sorted(active)

        lifecycle = data.setdefault("lifecycle", {}).setdefault(
            capability_id, {"state": "available", "facts": [], "attempts": []}
        )
        facts = set(lifecycle.setdefault("facts", []))
        facts.update(("available", "attempted"))
        if succeeded:
            facts.update(("executed_successfully", "active"))
        lifecycle["facts"] = sorted(facts)
        attempt = {
            "receipt_id": receipt.receipt_id,
            "exit_code": receipt.exit_code,
            "request_sha256": receipt.request_sha256,
            "result_sha256": receipt.result_sha256,
        }
        if trigger_id is not None:
            attempt["trigger_id"] = trigger_id
            lifecycle["last_trigger_id"] = trigger_id
        lifecycle.setdefault("attempts", []).append(attempt)
        lifecycle["last_receipt_id"] = receipt.receipt_id
        lifecycle["last_exit_code"] = receipt.exit_code
        lifecycle["last_attempt_status"] = "success" if succeeded else "nonzero"
        lifecycle["state"] = "active" if capability_id in active else "attempted"
        self._write(data)
        return succeeded and not was_active

    def record_exception(
        self,
        capability_id: str,
        *,
        trigger_id: str,
        exception: BaseException,
    ) -> None:
        data = self.read()
        available = set(data.get("available", []))
        available.add(capability_id)
        data["available"] = sorted(available)
        lifecycle = data.setdefault("lifecycle", {}).setdefault(
            capability_id, {"state": "available", "facts": [], "attempts": []}
        )
        facts = set(lifecycle.setdefault("facts", []))
        facts.update(("available", "attempted"))
        lifecycle["facts"] = sorted(facts)
        lifecycle.setdefault("attempts", []).append(
            {
                "trigger_id": trigger_id,
                "exception_type": type(exception).__name__,
                "exception": str(exception),
            }
        )
        lifecycle["last_trigger_id"] = trigger_id
        lifecycle["last_attempt_status"] = "exception"
        lifecycle["state"] = (
            "active" if capability_id in set(data.get("active", [])) else "attempted"
        )
        self._write(data)

    def record_host_evidence(
        self,
        capability_id: str,
        *,
        evidence: dict[str, Any],
        callable: bool,
        executed: bool,
        success: bool,
    ) -> bool:
        data = self.read()
        available = set(data.get("available", []))
        available.add(capability_id)
        data["available"] = sorted(available)

        active = set(data.get("active", []))
        was_active = capability_id in active
        lifecycle = data.setdefault("lifecycle", {}).setdefault(
            capability_id, {"state": "available", "facts": [], "attempts": []}
        )
        facts = set(lifecycle.setdefault("facts", []))
        facts.add("available")
        if callable:
            facts.add("callable")
        if executed:
            facts.add("attempted")
        if executed and success:
            facts.update(("executed_successfully", "active"))
            active.add(capability_id)
            lifecycle["state"] = "active"
            lifecycle["last_attempt_status"] = "success"
        elif executed:
            lifecycle["state"] = "active" if capability_id in active else "attempted"
            lifecycle["last_attempt_status"] = "nonzero"
        elif callable:
            lifecycle["state"] = "active" if capability_id in active else "callable"
        else:
            lifecycle["state"] = "available"
        lifecycle["facts"] = sorted(facts)
        lifecycle.setdefault("host_evidence", []).append(evidence)
        data["active"] = sorted(active)
        self._write(data)
        return (capability_id in active) and not was_active

    def lifecycle_state(self, capability_id: str) -> str | None:
        data = self.read()
        entry = data.get("lifecycle", {}).get(capability_id)
        if not isinstance(entry, dict):
            return None
        value = entry.get("state")
        return str(value) if value is not None else None

    def lifecycle_facts(self, capability_id: str) -> tuple[str, ...]:
        data = self.read()
        entry = data.get("lifecycle", {}).get(capability_id)
        if not isinstance(entry, dict):
            return ()
        return tuple(sorted(str(x) for x in entry.get("facts", [])))

    def set_external(self, capability_id: str, metadata: dict[str, Any]) -> bool:
        data = self.read()
        previous = data.setdefault("external", {}).get(capability_id)
        data["external"][capability_id] = metadata
        self._write(data)
        return previous != metadata
