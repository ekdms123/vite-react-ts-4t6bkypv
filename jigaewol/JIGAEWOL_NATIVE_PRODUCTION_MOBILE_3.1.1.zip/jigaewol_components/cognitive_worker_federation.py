from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .host_action_truth import capabilities_proven_by_action, worker_truth_from_host_action


def _key(value: str) -> str:
    return str(value or "").strip().casefold().replace("-", "_").replace(" ", "_")


def _scope_from_capability(capability: str) -> str:
    prefix = "cognition:domain_delegate_"
    text = str(capability or "").strip()
    return text[len(prefix):] if text.startswith(prefix) else ""


@dataclass(frozen=True)
class CognitiveWorkerEndpoint:
    provider_id: str
    action: str
    scope: str
    execution_kind: str
    state: str
    liveness: str
    observed_at: float
    evidence_ref: str
    context_ref: str
    provider_ref: str
    independent_cognitive_worker: bool
    closed_loop_agent_worker: bool
    current_callable: bool
    current_closed_loop: bool
    latest_observation_success: bool
    last_failure_at: float


@dataclass(frozen=True)
class FederationRoute:
    requested_scope: str
    state: str
    provider_id: str = ""
    action: str = ""
    liveness: str = ""
    independent_cognitive_worker: bool = False
    closed_loop_agent_worker: bool = False
    evidence_ref: str = ""
    reason: str = ""


class CognitiveWorkerFederation:
    """Truth-preserving router over independently observed cognitive workers.

    ``single_general_worker_proven`` means one observed worker itself proved a
    general-delegation capability and a closed result-return loop.
    ``federated_general_delegate_ready`` instead means JIGAEWOL can route across
    multiple fresh domain workers.  The latter is useful general orchestration, but
    it is never promoted into a fictitious single general-purpose model worker.
    """

    FORMAT = "jigaewol_cognitive_worker_federation_v1"

    def __init__(self, root: str | Path, *, max_age_seconds: float | None = None) -> None:
        self.root = Path(root).resolve()
        self.state_path = self.root / "host_surface" / "action_truth_state.json"
        if max_age_seconds is None:
            max_age_seconds = float(os.environ.get("JIGAEWOL_HOST_SURFACE_MAX_AGE_S", "1800"))
        self.max_age_seconds = float(max_age_seconds)

    def _state(self) -> dict[str, Any]:
        if not self.state_path.is_file():
            return {"actions": {}}
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("worker federation state must be a JSON object")
            actions = data.setdefault("actions", {})
            if not isinstance(actions, dict):
                raise TypeError("worker federation actions must be a JSON object")
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            failure_path = self.state_path.parent / "cognitive_worker_failures.jsonl"
            row = {
                "kind": "worker_state_corrupt",
                "source": str(self.state_path),
                "error_type": type(exc).__name__,
                "error": str(exc),
                "created_at": time.time(),
            }
            with failure_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")
            raise RuntimeError(f"worker federation state unreadable or corrupt: {exc}") from exc
        return data

    def endpoints(self, *, now: float | None = None) -> tuple[CognitiveWorkerEndpoint, ...]:
        ts = time.time() if now is None else float(now)
        rows: list[CognitiveWorkerEndpoint] = []
        for composite_key, raw in sorted((self._state().get("actions") or {}).items()):
            if not isinstance(raw, dict) or ":" not in str(composite_key):
                continue
            provider_id, action = str(composite_key).split(":", 1)
            success = raw.get("last_success")
            if not isinstance(success, dict) or success.get("success") is not True:
                continue
            truth = worker_truth_from_host_action(provider_id, action, success)
            caps = capabilities_proven_by_action(provider_id, action)
            scopes = tuple(dict.fromkeys(x for x in (_scope_from_capability(c) for c in caps) if x))
            general = "cognition:general_delegate" in caps
            if not truth.independent_cognitive_worker or (not scopes and not general):
                continue
            observed_at = float(success.get("observed_at") or 0.0)
            failure = raw.get("last_failure") if isinstance(raw.get("last_failure"), dict) else {}
            failure_at = float(failure.get("observed_at") or 0.0)
            latest_success = not (failure_at > observed_at)
            fresh = bool(observed_at and ts - observed_at <= self.max_age_seconds)
            current = bool(fresh and latest_success)
            if not latest_success:
                liveness = "latest_probe_failed"
                endpoint_state = "observed_failure_after_success"
            else:
                liveness = "fresh" if fresh else "stale_reprobe_required"
                endpoint_state = "callable" if fresh else "stale_revalidation_required"
            for scope in scopes or ("general",):
                rows.append(CognitiveWorkerEndpoint(
                    provider_id=_key(provider_id),
                    action=_key(action),
                    scope=scope,
                    execution_kind=truth.execution_kind,
                    state=endpoint_state,
                    liveness=liveness,
                    observed_at=observed_at,
                    evidence_ref=str(success.get("evidence_ref") or success.get("observation_id") or ""),
                    context_ref=truth.context_ref,
                    provider_ref=truth.provider_ref,
                    independent_cognitive_worker=truth.independent_cognitive_worker,
                    closed_loop_agent_worker=truth.closed_loop_agent_worker,
                    current_callable=bool(current and truth.independent_cognitive_worker),
                    current_closed_loop=bool(current and truth.closed_loop_agent_worker),
                    latest_observation_success=latest_success,
                    last_failure_at=failure_at,
                ))
        return tuple(rows)

    @staticmethod
    def _route_rank(endpoint: CognitiveWorkerEndpoint, *, require_closed_loop: bool) -> tuple[int, int, float, str, str]:
        if require_closed_loop:
            primary = 2 if endpoint.current_closed_loop else 0
        else:
            primary = 2 if endpoint.current_closed_loop else 1 if endpoint.current_callable else 0
        historical = 1 if endpoint.closed_loop_agent_worker else 0
        return (primary, historical, endpoint.observed_at, endpoint.provider_id, endpoint.action)

    def route(self, scope: str, *, require_closed_loop: bool = True, now: float | None = None) -> FederationRoute:
        target = _key(scope)
        candidates = [x for x in self.endpoints(now=now) if _key(x.scope) in {target, "general"}]
        if not candidates:
            return FederationRoute(
                requested_scope=target,
                state="unavailable",
                reason="no independently observed cognitive worker proves this scope",
            )
        candidates.sort(key=lambda x: self._route_rank(x, require_closed_loop=require_closed_loop), reverse=True)
        best = candidates[0]
        if require_closed_loop and best.current_closed_loop:
            state = "ready_closed_loop"
            reason = "fresh independent worker with observed result-return path"
        elif not require_closed_loop and best.current_callable:
            state = "ready_independent"
            reason = "fresh independent cognitive worker; result-return closure not yet proven"
        elif best.liveness == "latest_probe_failed":
            state = "latest_probe_failed"
            reason = "historical worker success is retained, but a newer execution probe failed"
        elif best.liveness != "fresh":
            state = "reprobe_required"
            reason = "historical worker proof retained but current liveness expired"
        elif require_closed_loop and best.independent_cognitive_worker:
            state = "result_return_unproven"
            reason = "independent cognitive execution observed but closed-loop return path is not proven"
        else:
            state = "unavailable"
            reason = "worker does not satisfy requested truth level"
        return FederationRoute(
            requested_scope=target,
            state=state,
            provider_id=best.provider_id,
            action=best.action,
            liveness=best.liveness,
            independent_cognitive_worker=best.independent_cognitive_worker,
            closed_loop_agent_worker=best.closed_loop_agent_worker,
            evidence_ref=best.evidence_ref,
            reason=reason,
        )

    def plan(self, scopes: Iterable[str], *, require_closed_loop: bool = True, now: float | None = None) -> tuple[FederationRoute, ...]:
        ordered = tuple(dict.fromkeys(_key(x) for x in scopes if _key(x)))
        return tuple(self.route(scope, require_closed_loop=require_closed_loop, now=now) for scope in ordered)

    def as_mapping(self, *, now: float | None = None) -> dict[str, Any]:
        endpoints = self.endpoints(now=now)
        historical_scopes = sorted({x.scope for x in endpoints})
        callable_scopes = sorted({x.scope for x in endpoints if x.current_callable})
        closed_loop_scopes = sorted({x.scope for x in endpoints if x.current_closed_loop})
        single_general = any(x.scope == "general" and x.current_closed_loop for x in endpoints)
        federated_ready = len(set(callable_scopes) - {"general"}) >= 2
        return {
            "format": self.FORMAT,
            "max_age_seconds": self.max_age_seconds,
            "endpoint_count": len(endpoints),
            "historical_scopes": historical_scopes,
            "current_callable_scopes": callable_scopes,
            "current_closed_loop_scopes": closed_loop_scopes,
            "single_general_worker_proven": single_general,
            "federated_general_delegate_ready": federated_ready,
            "federated_general_delegate_is_single_worker": False,
            "endpoints": [asdict(x) for x in endpoints],
            "truth_rule": (
                "single general worker requires one fresh independently observed general-delegate worker with closed-loop result return; "
                "multi-domain federation is orchestration coverage only"
            ),
        }
