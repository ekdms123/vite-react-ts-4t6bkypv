"""Selected donor components from the user-provided USAGI V4.0 archive."""
