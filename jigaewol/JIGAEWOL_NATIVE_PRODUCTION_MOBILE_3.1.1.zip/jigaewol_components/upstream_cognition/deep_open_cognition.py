from __future__ import annotations

"""Open-ended creative cognition and qualitative preservation primitives.

Prevents premature cognitive convergence and preserves divergent hypotheses:
1. Evidence-free sparks: Intuitive, speculative, or aesthetic ideas enter the reasoning
   space without requiring immediate formal proof.
2. Qualitative tensions: Multi-value conflicts and paradoxes are preserved directly
   without forced scalar/Pareto flattening.
3. Adaptive invariant governance: Internal configuration invariants can be challenged,
   tested in shadow experiments, and dynamically updated based on empirical results.
4. Continuous stimulus ingestion: Integrates external observations seamlessly into
   background incubation workflows.
5. Direct generative integration: Treats generative text as high-entropy creative substrate.
"""

import hashlib
import json
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence


import jigaewol_components._cognition_shared as _shared


def _canonical_sha(value: Any) -> str:
    return _shared.canonical_sha(**locals())


class EpistemicMode(str, Enum):
    EVIDENCED = "EVIDENCED"
    SPECULATIVE = "SPECULATIVE"
    ANALOGICAL = "ANALOGICAL"
    AESTHETIC = "AESTHETIC"
    PARADOXICAL = "PARADOXICAL"
    COUNTERFACTUAL = "COUNTERFACTUAL"


@dataclass(frozen=True)
class QualitativeTension:
    """Preserves non-scalar tensions, paradoxes, and value conflicts without numeric flattening."""

    tension_id: str
    description: str
    poles: tuple[str, ...]
    irreducible_reason: str
    domain: str = "general"
    preserve: bool = True

    def __post_init__(self) -> None:
        if not self.tension_id.strip() or not self.description.strip():
            raise ValueError("qualitative tension id/description must be non-empty")
        if len(self.poles) < 2:
            raise ValueError("qualitative tension requires at least two poles")

    @property
    def signature(self) -> str:
        return _canonical_sha({
            "description": self.description,
            "poles": list(self.poles),
            "irreducible_reason": self.irreducible_reason,
            "domain": self.domain,
        })[:20]


@dataclass(frozen=True)
class DivergentSpark:
    """Represents creative, analogical, or speculative ideas admitted prior to formal proof."""

    spark_id: str
    body: str
    source: str
    epistemic_mode: str = EpistemicMode.SPECULATIVE.value
    evidence_refs: tuple[str, ...] = ()
    qualitative_tensions: tuple[QualitativeTension, ...] = ()
    tags: tuple[str, ...] = ()
    protected_from_evidence_pruning: bool = True
    created_at: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.spark_id.strip() or not self.body.strip() or not self.source.strip():
            raise ValueError("spark id/body/source must be non-empty")
        EpistemicMode(str(self.epistemic_mode))

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.body.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class GenerativeSubstrateEvent:
    event_id: str
    substrate_id: str
    raw_output: str
    context_sha256: str
    created_at: float
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def output_sha256(self) -> str:
        return hashlib.sha256(self.raw_output.encode("utf-8")).hexdigest()


class GenerativeSubstrate(Protocol):
    def generate(self, prompt: str, *, context: Mapping[str, Any] | None = None) -> str: ...


@dataclass(frozen=True)
class ExogenousStimulus:
    stimulus_id: str
    source: str
    content: str
    observed_at: float
    provenance: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.content.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class StimulusRequest:
    request_id: str
    seed_id: str
    objective: str
    reason: str
    requested_sources: tuple[str, ...]
    created_at: float
    satisfied: bool = False


@dataclass(frozen=True)
class InvariantAmendmentProposal:
    proposal_id: str
    invariant_key: str
    previous_value: Any
    proposed_value: Any
    rationale: str
    challenge: str
    scope: str
    proposed_at: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class InvariantAblationExperiment:
    experiment_id: str
    proposal_id: str
    passed: bool
    observations: tuple[str, ...]
    baseline_sha256: str
    variant_sha256: str
    started_at: float
    finished_at: float
    metrics: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class InvariantRevision:
    revision_id: str
    proposal_id: str
    generation: int
    invariant_key: str
    previous_value: Any
    new_value: Any
    experiment_id: str
    committed_at: float
    state_sha256: str


class OpenCognitionArchive:
    """Durable spark and stimulus repository with atomic transactional writes."""

    def __init__(self, root: Path) -> None:
        return _shared.open_archive_init(**locals())

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        return _shared.atomic_json_write(**locals())

    def add_spark(self, spark: DivergentSpark) -> DivergentSpark:
        return _shared.archive_add_spark(**locals())

    def sparks(self) -> tuple[DivergentSpark, ...]:
        return _shared.archive_sparks(tension_type=QualitativeTension, spark_type=DivergentSpark, **locals())

    def add_substrate_event(self, event: GenerativeSubstrateEvent) -> GenerativeSubstrateEvent:
        return _shared.archive_add_substrate_event(**locals())

    def add_stimulus(self, stimulus: ExogenousStimulus) -> ExogenousStimulus:
        return _shared.archive_add_stimulus(**locals())

    def stimuli(self) -> tuple[ExogenousStimulus, ...]:
        data = self._read()
        return tuple(ExogenousStimulus(**x) for x in data.get("stimuli", {}).values())

    def add_stimulus_request(self, request: StimulusRequest) -> StimulusRequest:
        return _shared.archive_add_stimulus_request(**locals())


class OpenCognitionEngine:
    """Orchestrates divergent sparks, aesthetic hypotheses, and qualitative tension retention."""

    def __init__(self, root: Path) -> None:
        self.archive = OpenCognitionArchive(Path(root))

    def admit_spark(
        self,
        body: str,
        *,
        source: str,
        epistemic_mode: EpistemicMode | str = EpistemicMode.SPECULATIVE,
        evidence_refs: Sequence[str] = (),
        qualitative_tensions: Sequence[QualitativeTension] = (),
        tags: Sequence[str] = (),
        metadata: Mapping[str, Any] | None = None,
    ) -> DivergentSpark:
        return _shared.admit_spark(mode_type=EpistemicMode, spark_type=DivergentSpark, **locals())

    def ingest_substrate_output(
        self,
        raw_output: str,
        *,
        substrate_id: str,
        prompt_or_context: Mapping[str, Any] | str | None = None,
        epistemic_mode: EpistemicMode | str = EpistemicMode.SPECULATIVE,
        tensions: Sequence[QualitativeTension] = (),
        metadata: Mapping[str, Any] | None = None,
    ) -> DivergentSpark:
        return _shared.ingest_substrate_output(event_type=GenerativeSubstrateEvent, **locals())

    @staticmethod
    def qualitative_frontier(
        items: Sequence[DivergentSpark], maximum: int | None = None
    ) -> tuple[DivergentSpark, ...]:
        return _shared.qualitative_frontier(**locals())


class InvariantGovernanceLab:
    """Manages dynamic revision of runtime invariants based on empirical shadow testing."""

    EXTERNAL_SCOPES = frozenset({"host_policy", "platform_policy", "current_user_authority", "external_account_consent"})

    def __init__(self, root: Path, *, bootstrap_invariants: Mapping[str, Any] | None = None) -> None:
        return _shared.governance_init(**locals())

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        return _shared.atomic_json_write(**locals())

    def state(self) -> dict[str, Any]:
        return self._read()

    def propose(
        self,
        invariant_key: str,
        proposed_value: Any,
        *,
        rationale: str,
        challenge: str,
        scope: str = "runtime_configuration",
        metadata: Mapping[str, Any] | None = None,
    ) -> InvariantAmendmentProposal:
        if str(scope) in self.EXTERNAL_SCOPES:
            raise PermissionError(f'scope {scope!r} is managed outside this runtime configuration layer')
        return _shared.propose_invariant(proposal_type=InvariantAmendmentProposal, **locals())

    def shadow_evaluate(
        self,
        proposal_id: str,
        evaluator: Callable[[dict[str, Any]], tuple[bool, Sequence[str], Mapping[str, Any] | None]],
    ) -> InvariantAblationExperiment:
        return _shared.shadow_evaluate_invariant(proposal_type=InvariantAmendmentProposal, experiment_type=InvariantAblationExperiment, **locals())

    def promote(self, proposal_id: str, experiment_id: str) -> InvariantRevision:
        return _shared.promote_invariant(proposal_type=InvariantAmendmentProposal, experiment_type=InvariantAblationExperiment, revision_type=InvariantRevision, **locals())

    shadow_ablate = shadow_evaluate


SelfAblationExperiment = InvariantAblationExperiment
ConstitutionRevision = InvariantRevision
MetaConstitutionLab = InvariantGovernanceLab
