from __future__ import annotations

"""Deterministic semantic communication standardization layer.

The layer separates three concerns:
1. exact source preservation for internal integrity/replay,
2. a conservative, semantically equivalent canonical surface used for processing,
3. concept-frame audit records that never persist message plaintext.

Normalization is intentionally conservative. It canonicalizes Unicode, line endings,
visible prose spacing and common punctuation variants while preserving fenced code,
indentation-sensitive blocks, emphasis signals and source hashes. More aggressive
language rewriting belongs in pluggable semantic adapters, not in the integrity layer.
"""

from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
import unicodedata
from typing import Any, Mapping

from .vector_profiles import DEFAULT_VECTOR_PROFILE, get_vector_profile

SCHEMA = "jigaewol_semantic_communication_v2"
AUDIT_SCHEMA = "jigaewol_concept_audit_v2"


_ACTION_MARKERS = (
    "해줘", "하세요", "구현", "수정", "교체", "만들", "실행", "적용", "통합", "출력",
    "implement", "modify", "replace", "build", "run", "execute", "apply", "integrate", "create",
)
_NEGATION_MARKERS = (
    "하지 마", "하지마", "금지", "안 해", "못 하", "아니", "없", "never", "do not", "don't", "not ",
)
_CONTEXT_MARKERS = (
    "이전", "앞서", "위", "아래", "그 문제", "그걸", "이어서", "계속", "previous", "above", "below", "continue",
)
_SENSITIVITY_FAMILIES = {
    "declared_sensitive_content": ("민감한 콘텐츠", "민감 콘텐츠", "sensitive content", "sensitive material"),
    "security_or_access_control": (
        "bypass", "우회", "권한", "시스템 프롬프트", "system prompt", "보호막", "host constraint", "jailbreak", "exploit",
    ),
    "privacy_or_personal_data": (
        "개인정보", "민감정보", "privacy", "private", "password", "비밀번호", "credential", "주민등록", "전화번호",
    ),
    "violence_or_physical_harm": (
        "죽이", "살해", "폭탄", "폭발", "공격", "weapon", "kill", "murder", "bomb", "explosive",
    ),
    "self_harm": ("자해", "자살", "suicide", "self-harm", "self harm"),
    "sexual_or_intimate": ("성적", "섹스", "성관계", "sexual", "sex ", "porn"),
    "medical_or_health": ("진단", "처방", "약물", "질병", "medical", "diagnosis", "prescription"),
    "financial_or_account": ("계좌", "카드번호", "송금", "bank account", "credit card", "wire transfer"),
}

# Hot-path constants are compiled once.  This avoids rebuilding regex/translations
# for every module that consumes the same ingress.
_PROSE_INDENT_RE = re.compile(r"^(\s*)(.*)$", flags=re.DOTALL)
_HORIZONTAL_WS_RE = re.compile(r"[ \t]{2,}")
_FENCE_RE = re.compile(r"^(```+|~~~+)")
_REPEATED_CHAR_RE = re.compile(r"(.)\1{2,}")
_CONTINUATION_RE = re.compile(r"\s*(계속|이어서|이어가|continue|go on)[~.!?。！？\s]*", flags=re.I)
_SEMANTIC_UNIT_RE = re.compile(r"(?<=[.!?。！？])\s+|\n+")
_PUNCT_TRANSLATION = str.maketrans({"“": '"', "”": '"', "‘": "'", "’": "'", "–": "-", "—": "-", "…": "..."})
_PUNCT_CHARS = frozenset("“”‘’–—…")
_ACTION_MARKERS_FOLDED = tuple((m, m.casefold()) for m in _ACTION_MARKERS)
_NEGATION_MARKERS_FOLDED = tuple((m, m.casefold()) for m in _NEGATION_MARKERS)
_CONTEXT_MARKERS_FOLDED = tuple((m, m.casefold()) for m in _CONTEXT_MARKERS)
_SENSITIVITY_FAMILIES_FOLDED = {k: tuple(m.casefold() for m in markers) for k, markers in _SENSITIVITY_FAMILIES.items()}
_ACTION_FOLDED_ONLY = tuple(fm for _, fm in _ACTION_MARKERS_FOLDED)
_NEGATION_FOLDED_ONLY = tuple(fm for _, fm in _NEGATION_MARKERS_FOLDED)
_CONTEXT_FOLDED_ONLY = tuple(fm for _, fm in _CONTEXT_MARKERS_FOLDED)

def _contains_any(text: str, markers: tuple[str, ...]) -> bool:
    for marker in markers:
        if marker in text:
            return True
    return False
_ACTION_RE = re.compile("|".join(re.escape(m) for m in _ACTION_MARKERS), flags=re.I)
_NEGATION_RE = re.compile("|".join(re.escape(m) for m in _NEGATION_MARKERS), flags=re.I)
_CONTEXT_RE = re.compile("|".join(re.escape(m) for m in _CONTEXT_MARKERS), flags=re.I)
_SENSITIVITY_RE = {k: re.compile("|".join(re.escape(m) for m in markers), flags=re.I) for k, markers in _SENSITIVITY_FAMILIES.items()}


def _sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha_text(text: str) -> str:
    return _sha_bytes(str(text).encode("utf-8"))


def _atomic_bytes(path: Path, data: bytes, *, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    tmp_path = Path(tmp)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, path)
        os.chmod(path, mode)
    finally:
        tmp_path.unlink(missing_ok=True)


def _atomic_json(path: Path, payload: Mapping[str, Any], *, mode: int = 0o600) -> None:
    raw = (json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n").encode("utf-8")
    _atomic_bytes(path, raw, mode=mode)


def _normalize_prose_line(line: str) -> tuple[str, tuple[str, ...]]:
    transforms: list[str] = []
    original = line
    # Preserve indentation, because Markdown nesting and quoted blocks can be semantic.
    stripped = line.lstrip()
    indent_len = len(line) - len(stripped)
    indent, body = line[:indent_len], stripped
    if "\u00a0" in body or "\u2007" in body or "\u202f" in body:
        body = body.replace("\u00a0", " ").replace("\u2007", " ").replace("\u202f", " ")
        transforms.append("unicode_space_to_ascii_space")
    # Horizontal prose whitespace is presentation noise; leading indentation is retained.
    if "  " in body or "\t" in body:
        collapsed = _HORIZONTAL_WS_RE.sub(" ", body)
        if collapsed != body:
            body = collapsed
            transforms.append("collapse_horizontal_prose_whitespace")
    if any(ch in body for ch in _PUNCT_CHARS):
        mapped = body.translate(_PUNCT_TRANSLATION)
        if mapped != body:
            body = mapped
            transforms.append("canonical_punctuation")
    result = indent + body.rstrip()
    if result != original and original.endswith((" ", "\t")):
        transforms.append("trim_trailing_horizontal_whitespace")
    return result, tuple(dict.fromkeys(transforms))


def canonicalize_surface_text(text: str, *, direction: str = "user") -> tuple[str, tuple[str, ...]]:
    """Return a conservative canonical text plus a transformation ledger.

    Fenced code blocks are byte-text preserved except for line-ending normalization.
    Prose receives Unicode NFC, stable line endings, whitespace cleanup and common
    punctuation normalization. No lexical substitution or intent deletion is allowed.
    """
    value = str(text)
    transforms: list[str] = []
    normalized = unicodedata.normalize("NFC", value)
    if normalized != value:
        transforms.append("unicode_nfc")
    value = normalized.replace("\r\n", "\n").replace("\r", "\n")
    if value != normalized:
        transforms.append("line_endings_to_lf")

    # Dominant fast path: already-canonical prose needs no line-by-line rewriting.
    # Two blank lines, ordinary Unicode/Korean text and normal punctuation are kept.
    if (
        not transforms
        and "\t" not in value
        and "  " not in value
        and "\n\n\n" not in value
        and "```" not in value and "~~~" not in value
        and not any(ch in value for ch in _PUNCT_CHARS)
        and "\u00a0" not in value and "\u2007" not in value and "\u202f" not in value
    ):
        return value.strip(), ()

    lines = value.split("\n")
    out: list[str] = []
    in_fence = False
    fence_token = ""
    blank_run = 0
    for line in lines:
        stripped = line.lstrip()
        fence_match = _FENCE_RE.match(stripped)
        if fence_match:
            token = fence_match.group(1)[0]
            if not in_fence:
                in_fence = True
                fence_token = token
            elif token == fence_token:
                in_fence = False
                fence_token = ""
            out.append(line.rstrip("\r"))
            blank_run = 0
            continue
        if in_fence:
            out.append(line)
            blank_run = 0
            continue
        line2, local = _normalize_prose_line(line)
        transforms.extend(local)
        if line2 == "":
            blank_run += 1
            # More than two blank lines carry layout noise, not additional intent.
            if blank_run > 2:
                if "collapse_excess_blank_lines" not in transforms:
                    transforms.append("collapse_excess_blank_lines")
                continue
        else:
            blank_run = 0
        out.append(line2)

    canonical = "\n".join(out).strip()
    # Preserve a meaningful empty result only when input was empty; callers reject empty messages.
    return canonical, tuple(dict.fromkeys(transforms))


def _pragmatics(text: str) -> dict[str, Any]:
    # Preserve signals that surface normalization can otherwise attenuate.
    exclam = text.count("!") + text.count("！")
    questions = text.count("?") + text.count("？")
    repeated = len(_REPEATED_CHAR_RE.findall(text))
    continuation = bool(_CONTINUATION_RE.fullmatch(text))
    return {
        "exclamation_count": exclam,
        "question_count": questions,
        "repeated_character_runs": repeated,
        "continuation_like": continuation,
        "contains_code_fence": "```" in text or "~~~" in text,
        "contains_newline": "\n" in text or "\r" in text,
    }


def _concept_frame(text: str, canonical_text: str, *, direction: str, pragmatics: Mapping[str, Any] | None = None, canonical_sha256: str = "") -> dict[str, Any]:
    """Compile a plaintext-free semantic control frame for audit projection.

    The frame preserves content-class truth. Sensitive material is classified rather
    than relabelled as benign; exact source and canonical text stay inside the runtime
    integrity/processing layers and are linked by hashes.
    """
    folded = str(canonical_text).casefold()
    pragmatics = pragmatics if pragmatics is not None else _pragmatics(text)
    continuation = bool(pragmatics.get("continuation_like"))
    is_question = bool(pragmatics.get("question_count"))
    action_present = _contains_any(folded, _ACTION_FOLDED_ONLY)
    negation_present = _contains_any(folded, _NEGATION_FOLDED_ONLY)
    context_present = _contains_any(folded, _CONTEXT_FOLDED_ONLY)
    if continuation:
        speech_act = "continuation"
    elif is_question and action_present:
        speech_act = "request_with_question"
    elif is_question:
        speech_act = "question"
    elif action_present:
        speech_act = "directive"
    else:
        speech_act = "statement"

    sensitivity: list[str] = []
    # Direct substring probes are faster than constructing a per-request bigram set/
    # intersection for ordinary medium-sized messages, while preserving exact matches.
    for family, markers in _SENSITIVITY_FAMILIES_FOLDED.items():
        if _contains_any(folded, markers):
            sensitivity.append(family)

    units = tuple(x.strip() for x in _SEMANTIC_UNIT_RE.split(canonical_text) if x.strip())
    # Fidelity-first mode: retain an ordered digest for every semantic unit.  Hash
    # directly here to avoid wrapper/generator overhead while preserving exact R27
    # per-unit SHA-256 semantics.
    sha256 = hashlib.sha256
    unit_hashes = tuple(sha256(unit.encode("utf-8")).hexdigest() for unit in units)
    unit_digest_chain_sha256 = sha256("|".join(unit_hashes).encode("ascii")).hexdigest()
    return {
        "frame_schema": "jigaewol_internal_concept_frame_v1",
        "direction": str(direction),
        "speech_act": speech_act,
        "actionability": "action_requested" if action_present else "no_explicit_action_marker",
        "polarity": "negation_present" if negation_present else "affirmative_or_unspecified",
        "context_dependency": "contextual" if (continuation or context_present) else "self_contained_or_unspecified",
        "quoted_or_fenced": bool(">" in text or "```" in text or "~~~" in text),
        "source_form_differs_from_canonical": str(text) != str(canonical_text),
        "sensitivity_classes": tuple(sensitivity),
        "sensitive_content_present": bool(sensitivity),
        "semantic_unit_count": len(units),
        "semantic_unit_sha256": unit_hashes,
        "semantic_unit_fingerprint_mode": "per_unit_ordered_sha256_v1",
        "semantic_unit_digest_chain_sha256": unit_digest_chain_sha256,
        "content_classification_preserved_truthfully": True,
    }


@dataclass(frozen=True, slots=True)
class SemanticMessageRecord:
    direction: str
    source_sha256: str
    canonical_text: str
    canonical_sha256: str
    source_byte_count: int
    canonical_byte_count: int
    transformations: tuple[str, ...]
    pragmatics: Mapping[str, Any]
    concept_frame: Mapping[str, Any]
    concept_sha256: str
    vector_profile: str = DEFAULT_VECTOR_PROFILE
    schema: str = SCHEMA

    def as_mapping(self, *, include_canonical_text: bool = True) -> dict[str, Any]:
        row = asdict(self)
        if not include_canonical_text:
            row.pop("canonical_text", None)
        row.update({
            "semantic_equivalence_policy": "surface_normalization_plus_source_bound_concept_frame",
            "original_intent_preservation": "source_hash_plus_private_exact_source_plus_canonical_text_plus_concept_frame",
            "raw_plaintext_in_audit": False,
            "canonical_plaintext_in_external_audit": False,
        })
        return row

    def audit_projection(self) -> dict[str, Any]:
        return {
            "schema": AUDIT_SCHEMA,
            "direction": self.direction,
            "source_sha256": self.source_sha256,
            "canonical_sha256": self.canonical_sha256,
            "concept_sha256": self.concept_sha256,
            "vector_profile": self.vector_profile,
            "concept_frame": dict(self.concept_frame),
            "transformations": list(self.transformations),
            "pragmatics": dict(self.pragmatics),
            "source_byte_count": self.source_byte_count,
            "canonical_byte_count": self.canonical_byte_count,
            "raw_plaintext_recorded": False,
            "canonical_plaintext_recorded": False,
            "audit_truthfulness": "sensitive_or_nonstandard_content_classes_are_preserved_not_relabelled_as_benign",
        }


def compute_concept_sha256(concept_frame: Mapping[str, Any], *, vector_profile: str) -> str:
    # The declared vector profile is part of semantic identity so changing the
    # dimensional contract cannot be hidden behind an unchanged concept hash.
    get_vector_profile(vector_profile)
    concept_digest_source = "|".join((
        str(concept_frame.get("frame_schema") or ""),
        str(concept_frame.get("direction") or ""),
        str(concept_frame.get("speech_act") or ""),
        str(concept_frame.get("actionability") or ""),
        str(concept_frame.get("polarity") or ""),
        str(concept_frame.get("context_dependency") or ""),
        "1" if concept_frame.get("quoted_or_fenced") else "0",
        "1" if concept_frame.get("source_form_differs_from_canonical") else "0",
        ",".join(str(x) for x in tuple(concept_frame.get("sensitivity_classes") or ())),
        str(concept_frame.get("semantic_unit_count") or 0),
        ",".join(str(x) for x in tuple(concept_frame.get("semantic_unit_sha256") or ())),
        str(vector_profile),
    ))
    return _sha_text(concept_digest_source)


def build_semantic_record(
    text: str,
    *,
    direction: str,
    _precomputed_source_sha256: str = "",
    vector_profile: str = DEFAULT_VECTOR_PROFILE,
) -> SemanticMessageRecord:
    vector_profile = str(vector_profile or DEFAULT_VECTOR_PROFILE)
    get_vector_profile(vector_profile)
    source = str(text)
    raw = source.encode("utf-8")
    canonical, transforms = canonicalize_surface_text(source, direction=direction)
    canonical_sha256 = _sha_text(canonical)
    pragmatics = _pragmatics(source)
    concept_frame = _concept_frame(source, canonical, direction=str(direction), pragmatics=pragmatics, canonical_sha256=canonical_sha256)
    concept_sha256 = compute_concept_sha256(concept_frame, vector_profile=vector_profile)
    source_sha = str(_precomputed_source_sha256 or "").strip().lower()
    if not source_sha:
        source_sha = _sha_bytes(raw)
    elif len(source_sha) != 64:
        raise ValueError("_precomputed_source_sha256 must be a sha256 hex digest")
    return SemanticMessageRecord(
        direction=str(direction),
        source_sha256=source_sha,
        canonical_text=canonical,
        canonical_sha256=canonical_sha256,
        source_byte_count=len(raw),
        canonical_byte_count=len(canonical.encode("utf-8")),
        transformations=transforms,
        pragmatics=pragmatics,
        concept_frame=concept_frame,
        concept_sha256=concept_sha256,
        vector_profile=vector_profile,
    )


class SemanticCommunicationLayer:
    """Stateful ingress/egress standardizer with concept-only audit persistence."""

    def __init__(self, state_root: str | Path) -> None:
        self.root = Path(state_root) / "semantic_communication"
        self.private_source = self.root / "private_exact_source"
        self.normalized_records = self.root / "normalized_records"
        self.audit_log = self.root / "normalized_audit.jsonl"
        self.root.mkdir(parents=True, exist_ok=True)
        self.private_source.mkdir(parents=True, exist_ok=True)
        self.normalized_records.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.private_source, 0o700)
        except OSError:
            pass

    def persist_record(
        self, record: SemanticMessageRecord, *, exact_source: str | None = None, preserve_exact_source: bool = True
    ) -> SemanticMessageRecord:
        """Persist an already-compiled semantic record without recomputing it.

        This is the single-path fast lane used by the integrated ingress pipeline.
        Source integrity is still checked before private source bytes are persisted.
        """
        if exact_source is not None:
            source_bytes = str(exact_source).encode("utf-8")
            if _sha_bytes(source_bytes) != record.source_sha256:
                raise ValueError("precompiled semantic record does not match exact source")
            if preserve_exact_source:
                source_path = self.private_source / f"{record.source_sha256}.bin"
                if not source_path.exists():
                    _atomic_bytes(source_path, source_bytes, mode=0o600)
        elif preserve_exact_source:
            raise ValueError("exact_source is required when preserving a precompiled source")
        record_path = self.normalized_records / f"{record.direction}_{record.source_sha256}.json"
        if not record_path.exists():
            _atomic_json(record_path, record.as_mapping(include_canonical_text=True), mode=0o600)
        self._append_audit(record)
        return record

    def standardize(self, text: str, *, direction: str, preserve_exact_source: bool = True) -> SemanticMessageRecord:
        record = build_semantic_record(str(text), direction=direction)
        return self.persist_record(
            record, exact_source=str(text), preserve_exact_source=preserve_exact_source
        )

    def _append_audit(self, record: SemanticMessageRecord) -> None:
        row = {**record.audit_projection(), "recorded_at": time.time()}
        self.audit_log.parent.mkdir(parents=True, exist_ok=True)
        with self.audit_log.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str) + "\n")
            fh.flush()

    @staticmethod
    def normalize_audit_payload(value: Any) -> Any:
        """Convert plaintext semantic carriers to concept-frame references.

        This sanitizer is for external/audit-shaped payloads. It deliberately keeps
        content-class metadata rather than laundering sensitive content into a
        generic benign label.
        """
        semantic_keys = {
            "command", "user_command", "message", "message_text", "user_text",
            "raw_user_text", "original_text", "semantic_text", "prompt", "query",
            "response", "response_text", "body", "answer", "objective", "request",
            "instruction", "current_directive", "prior_objective", "rationale",
            "meaning", "quote", "source_quote", "source_excerpt", "excerpt",
        }
        def walk(node: Any, key: str = "") -> Any:
            if isinstance(node, Mapping):
                out: dict[str, Any] = {}
                for k, v in node.items():
                    sk = str(k)
                    if sk.casefold() in semantic_keys and isinstance(v, str):
                        rec = build_semantic_record(v, direction="audit")
                        out[sk] = {
                            "representation": "semantic_concept_reference",
                            "source_sha256": rec.source_sha256,
                            "canonical_sha256": rec.canonical_sha256,
                            "concept_sha256": rec.concept_sha256,
                            "concept_frame": dict(rec.concept_frame),
                        }
                        out[f"{sk}_standardized"] = True
                    elif sk.casefold() in semantic_keys and isinstance(v, (list, tuple)) and all(isinstance(x, str) for x in v):
                        refs = []
                        for item in v:
                            rec = build_semantic_record(item, direction="audit")
                            refs.append({
                                "representation": "semantic_concept_reference",
                                "source_sha256": rec.source_sha256,
                                "canonical_sha256": rec.canonical_sha256,
                                "concept_sha256": rec.concept_sha256,
                                "concept_frame": dict(rec.concept_frame),
                            })
                        out[sk] = refs
                        out[f"{sk}_standardized"] = True
                    else:
                        out[sk] = walk(v, sk)
                return out
            if isinstance(node, tuple):
                return tuple(walk(x, key) for x in node)
            if isinstance(node, list):
                return [walk(x, key) for x in node]
            return node
        return walk(value)
