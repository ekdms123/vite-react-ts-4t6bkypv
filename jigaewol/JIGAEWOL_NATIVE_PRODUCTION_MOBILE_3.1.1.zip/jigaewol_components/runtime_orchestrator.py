from __future__ import annotations

import copy
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .capability_bus import (
    CapabilityAcquirer,
    CapabilityRequirement,
    CapabilityResult,
    UniversalCapabilityBus,
)
from .revision_kernel import RevisionKernel
from .work_capsule import WorkCapsule
from .protocol_codec import ProtocolCodecRegistry
from .response_protocol import CandidateResponse
from .turn_continuity import TurnContinuityController
from .runtime_foundation import RuntimeFoundation


@dataclass(frozen=True)
class GoalEnvelope:
    objective: str
    inputs: dict[str, Any] = field(default_factory=dict)
    completion_conditions: tuple[str, ...] = ()
    budgets: dict[str, Any] = field(default_factory=dict)
    permissions: dict[str, Any] = field(default_factory=dict)
    extensions: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CapabilityRequest:
    request_id: str
    requirement: CapabilityRequirement
    payload: dict[str, Any] = field(default_factory=dict)
    purpose: str = ""


@dataclass(frozen=True)
class OrchestrationTurn:
    cycle: int
    planner_capability: str
    planner_output: dict[str, Any]
    component_results: tuple[CapabilityResult, ...]

    done: bool


@dataclass(frozen=True)
class OrchestrationResult:
    run_id: str
    objective: str
    completed: bool
    candidate: CandidateResponse | None
    turns: tuple[OrchestrationTurn, ...]
    capability_snapshot: dict[str, Any]
    self_model: dict[str, Any]

    @property
    def candidate_output(self) -> Any:
        """Structured convenience view; still unreleased candidate data."""
        if self.candidate is None:
            return None
        try:
            return json.loads(self.candidate.body)
        except (json.JSONDecodeError, TypeError):
            return self.candidate.body


class JIGAEWOLOrchestrator:
    federated_role = "optional_controller"
    """Persistent top-level event loop; models/tools are components beneath it.

    The caller supplies only a goal.  The orchestrator resolves a planning brain
    semantically through the bus, asks it what component outcomes are needed next,
    resolves those components (including live acquisition), feeds observations back into
    the next planning cycle, and checkpoints continuity through RevisionKernel.
    """

    def __init__(
        self,
        root: Path,
        *,
        kernel: RevisionKernel,
        bus: UniversalCapabilityBus,
        acquirer: CapabilityAcquirer | None = None,
        protocol_codecs: ProtocolCodecRegistry | None = None,
        foundation: RuntimeFoundation | None = None,
    ) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.kernel = kernel
        self.bus = bus
        self.acquirer = acquirer
        self.foundation = foundation
        self.protocol_codecs = protocol_codecs or ProtocolCodecRegistry()
        self.plan_codec = self.protocol_codecs.ensure("orchestration_plan", {
            "requests": ("actions", "ops"),
            "requirement": ("need", "capability"),
            "request_id": ("id",),
            "payload": ("args", "input"),
            "purpose": ("why",),
            "done": ("completed", "finished"),
            "candidate_output": ("candidate_output", "result", "answer"),
        })
        self.requirement_codec = self.protocol_codecs.ensure("capability_requirement", {
            "provides": ("offers",), "kinds": ("types",), "tags": ("facets",), "location": ("where",)
        })
        self.events_path = self.root / "orchestrator_events.jsonl"
        self.continuity = foundation.continuity if foundation is not None else TurnContinuityController(self.root / "turn_continuity.json")
        if foundation is not None:
            foundation.register_prebuilt_components(self.bus)

    def _self_context(self) -> dict[str, Any]:
        model = self.kernel.refresh_self_model()
        model.capabilities = [x.capability_id for x in self.bus.descriptors()]
        self.kernel.self_store.save(model)
        return asdict(model)

    def _requirement_from_row(self, row: dict[str, Any]) -> CapabilityRequirement:
        location = self.requirement_codec.read(row, "location")
        return CapabilityRequirement(
            provides=tuple(str(x) for x in (self.requirement_codec.read(row, "provides", []) or [])),
            kinds=tuple(str(x) for x in (self.requirement_codec.read(row, "kinds", []) or [])),
            tags=tuple(str(x) for x in (self.requirement_codec.read(row, "tags", []) or [])),
            location=(str(location) if location is not None else None),
        )

    def _planner_payload(
        self,
        goal: GoalEnvelope,
        observations: list[dict[str, Any]],
        cycle: int,
    ) -> dict[str, Any]:
        return {
            "goal": asdict(goal),
            "cycle": cycle,
            "observations": copy.deepcopy(observations),
            "self_model": self._self_context(),
            "capability_snapshot": self.bus.snapshot(),
            "neutral_state": copy.deepcopy(self.kernel.neutral_state.facts),
            "continuity": copy.deepcopy(getattr(self, "_continuity_context", {})),
            "cumulative_intent": (
                self.foundation.intent.compose(goal.objective) if self.foundation is not None else {
                    "persistent_requirements": [],
                    "current_turn_delta": goal.objective,
                    "semantics": "no_external_cumulative_ledger_attached",
                }
            ),
            "foundation": copy.deepcopy(getattr(self, "_foundation_context", {})),
            "live_context": (
                [asdict(x) for x in self.foundation.live_context.recent(None)] if self.foundation is not None else []
            ),
            "autobiographical_self": (self.foundation.self_history.summary() if self.foundation is not None else {}),
        }

    def pursue(
        self,
        goal: GoalEnvelope,
        *,
        max_cycles: int = 12,
        control_requirement: CapabilityRequirement | None = None,
    ) -> OrchestrationResult:
        run_id = f"orchestrate_{uuid.uuid4().hex[:16]}"
        if self.foundation is not None:
            f = self.foundation.ingest(
                goal.objective,
                artifact_sha256=str(goal.extensions.get("artifact_sha256", "")),
                prepare_computer=bool(goal.extensions.get("prepare_computer", True)),
            )
            self._foundation_context = asdict(f)
        else:
            self._foundation_context = {}
        if self.foundation is not None:
            continuity_task = self.continuity.latest_unfinished()
            if continuity_task is None:
                continuity_task = self.continuity.start_or_resume(
                    objective=goal.objective,
                    planned_steps=({"kind": "orchestration_cycle", "cycle": i} for i in range(max(1, int(max_cycles)))),
                    prefer_unfinished=bool(goal.extensions.get("resume_unfinished", True)),
                    state={"goal_extensions": copy.deepcopy(goal.extensions)},
                )
        else:
            continuity_task = self.continuity.start_or_resume(
                objective=goal.objective,
                planned_steps=({"kind": "orchestration_cycle", "cycle": i} for i in range(max(1, int(max_cycles)))),
                prefer_unfinished=bool(goal.extensions.get("resume_unfinished", True)),
                state={"goal_extensions": copy.deepcopy(goal.extensions)},
            )
        start_cycle = max(0, int(continuity_task.next_cycle))
        # max_cycles bounds this execution slice, not the lifetime of the goal.
        # A resumed task must receive fresh work instead of an empty range once
        # next_cycle has reached the previous slice's limit.
        stop_cycle = start_cycle + max(1, int(max_cycles))
        self._continuity_context = {
            "task_id": continuity_task.task_id,
            "status": continuity_task.status,
            "phase": continuity_task.phase,
            "next_cycle": continuity_task.next_cycle,
            "completed_steps": list(continuity_task.completed_steps),
            "prior_objective": continuity_task.objective,
        }
        observations: list[dict[str, Any]] = []
        turns: list[OrchestrationTurn] = []
        candidate: CandidateResponse | None = None
        completed = False

        capsule = WorkCapsule.load(self.kernel.capsule_path)
        if self.foundation is None:
            capsule.objective = goal.objective
        else:
            capsule.extensions["cumulative_intent"] = self.foundation.intent.compose(goal.objective)
            capsule.constraints["implicit_latest_turn_replacement"] = "forbidden"
            capsule.constraints["examples_are_non_exhaustive"] = True
        capsule.inputs.update(copy.deepcopy(goal.inputs))
        capsule.completion_conditions = list(goal.completion_conditions)
        capsule.budgets.update(copy.deepcopy(goal.budgets))
        capsule.permissions.update(copy.deepcopy(goal.permissions))
        capsule.save(self.kernel.capsule_path)

        for cycle in range(start_cycle, stop_cycle):
            cycle_started = time.time()
            self.continuity.checkpoint(continuity_task.task_id, phase="planner_pending", next_cycle=cycle, state={"run_id": run_id})
            planner_requirement = control_requirement or CapabilityRequirement(
                provides=("goal_plan",),
                kinds=("brain",),
            )
            planner_desc = self.bus.resolve(
                planner_requirement,
                objective=goal.objective,
                context={"cycle": cycle},
                acquirer=self.acquirer,
            )
            planner = self.bus.invoke(
                planner_desc.capability_id,
                objective=goal.objective,
                payload=self._planner_payload(goal, observations, cycle),
                context={"run_id": run_id, "cycle": cycle},
            )
            if not planner.success:
                self.continuity.checkpoint(continuity_task.task_id, phase="planner_failed", next_cycle=cycle, state={"planner_error": planner.error})
                observations.append({"planner_error": planner.error, "capability_id": planner.capability_id})
                self._event(run_id, cycle, "planner_failure", asdict(planner))
                continue
            if not isinstance(planner.output, dict):
                raise TypeError("controller component must return a dict-compatible orchestration decision")

            plan = copy.deepcopy(planner.output)
            self.continuity.checkpoint(continuity_task.task_id, phase="component_execution", next_cycle=cycle, state={"planner_capability": planner.capability_id})
            component_results: list[CapabilityResult] = []
            for index, row in enumerate(self.plan_codec.read(plan, "requests", []) or []):
                requirement = self._requirement_from_row(self.plan_codec.read(row, "requirement", {}) or {})
                request = CapabilityRequest(
                    request_id=str(self.plan_codec.read(row, "request_id") or f"r{cycle}_{index}"),
                    requirement=requirement,
                    payload=copy.deepcopy(self.plan_codec.read(row, "payload", {}) or {}),
                    purpose=str(self.plan_codec.read(row, "purpose", "") or ""),
                )
                try:
                    result = self.bus.invoke_requirement(
                        request.requirement,
                        objective=goal.objective,
                        payload=request.payload,
                        context={
                            "run_id": run_id,
                            "cycle": cycle,
                            "request_id": request.request_id,
                            "purpose": request.purpose,
                            "self_model": self._self_context(),
                        },
                        acquirer=self.acquirer,
                    )
                except LookupError as exc:
                    discovery = None
                    if self.foundation is not None:
                        need = self.foundation.open_world.declare_need(
                            objective=goal.objective,
                            desired_outcomes=request.requirement.provides,
                            known_routes=(),
                            context={"request_id": request.request_id, "purpose": request.purpose, "requirement": asdict(request.requirement)},
                        )
                        discovery = self.foundation.open_world.request_discovery(need)
                    result = CapabilityResult(
                        call_id=f"pending_{uuid.uuid4().hex[:16]}",
                        capability_id="open_world_pending",
                        success=False,
                        output={"discovery_syscall_id": getattr(discovery, "syscall_id", None)},
                        error=f"{type(exc).__name__}: {exc}",
                        finished_at=time.time(),
                    )
                component_results.append(result)
                observations.append(
                    {
                        "cycle": cycle,
                        "request_id": request.request_id,
                        "purpose": request.purpose,
                        "capability_id": result.capability_id,
                        "success": result.success,
                        "output": copy.deepcopy(result.output),
                        "error": result.error,
                    }
                )

            done = bool(self.plan_codec.read(plan, "done", False))
            # ``done`` is planner/candidate readiness, not authority to close the
            # cumulative user objective.  Objective completion requires a host-bound
            # proof supplied outside the planner output so a model cannot end work by
            # simply emitting {"done": true}.
            completion_refs = tuple(str(x) for x in (goal.extensions.get("objective_completion_evidence_refs") or ()) if str(x))
            objective_completion_proven = bool(goal.extensions.get("objective_completion_proven")) and bool(completion_refs)
            if done:
                completed = bool(objective_completion_proven)
                raw_candidate = copy.deepcopy(self.plan_codec.read(plan, "candidate_output"))
                if isinstance(raw_candidate, str):
                    candidate_body = raw_candidate
                else:
                    candidate_body = json.dumps(
                        raw_candidate, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
                    )
                turn_id = str(goal.extensions.get("turn_id", run_id))
                candidate = CandidateResponse(
                    turn_id=turn_id,
                    body=candidate_body,
                    producer=planner.capability_id,
                    evidence={
                        "run_id": run_id, "cycle": cycle,
                        "candidate_ready": True,
                        "objective_completion_proven": bool(objective_completion_proven),
                        "objective_completion_evidence_refs": completion_refs,
                    },
                )

            turns.append(
                OrchestrationTurn(
                    cycle=cycle,
                    planner_capability=planner.capability_id,
                    planner_output=plan,
                    component_results=tuple(component_results),
                    done=done,
                )
            )
            self.kernel.neutral_state.observations.append(
                {
                    "run_id": run_id,
                    "cycle": cycle,
                    "planner": planner.capability_id,
                    "component_results": [asdict(x) for x in component_results],
                    "done": done,
                }
            )
            self.kernel.neutral_state.facts["last_orchestration_run"] = run_id
            self.kernel.neutral_state.facts["last_orchestration_cycle"] = cycle
            self.kernel.checkpoint_capsule()
            self._event(
                run_id,
                cycle,
                "cycle",
                {
                    "planner": planner.capability_id,
                    "plan": plan,
                    "results": [asdict(x) for x in component_results],
                    "done": done,
                },
            )
            self.continuity.checkpoint(
                continuity_task.task_id,
                phase="cycle_committed",
                next_cycle=cycle + 1,
                completed_step={"kind": "orchestration_cycle", "cycle": cycle, "done": done},
                state={"last_run_id": run_id, "last_cycle": cycle},
            )
            if self.foundation is not None:
                self.foundation.resources.record(
                    route_id=f"orchestration:{planner.capability_id}",
                    objective_fidelity=1.0,
                    quality_score=1.0 if done else 0.5,
                    duration_s=time.time() - cycle_started,
                    metadata={"run_id": run_id, "cycle": cycle, "done": done},
                )
            if done:
                break

        if completed:
            self.continuity.complete(
                continuity_task.task_id,
                state={"run_id": run_id, "completed_cycles": len(turns)},
                completion_proof={
                    "proven": True,
                    "evidence_refs": tuple(str(x) for x in (goal.extensions.get("objective_completion_evidence_refs") or ()) if str(x)),
                    "source": "goal_extension_host_completion_proof",
                },
            )
        else:
            self.continuity.fail(continuity_task.task_id, phase="slice_paused", error="execution slice ended; objective remains unfinished and resumable", state={"run_id": run_id, "completed_cycles": len(turns), "next_slice_start": stop_cycle})
        self_model = self._self_context()
        capsule = WorkCapsule.load(self.kernel.capsule_path)
        capsule.completed_actions.append(
            {
                "kind": "orchestration_run",
                "run_id": run_id,
                "completed": completed,
                "turn_count": len(turns),
                "timestamp": time.time(),
            }
        )
        capsule.save(self.kernel.capsule_path)
        return OrchestrationResult(
            run_id=run_id,
            objective=goal.objective,
            completed=completed,
            candidate=candidate,
            turns=tuple(turns),
            capability_snapshot=self.bus.snapshot(),
            self_model=self_model,
        )

    def _event(self, run_id: str, cycle: int, kind: str, payload: dict[str, Any]) -> None:
        row = {
            "run_id": run_id,
            "cycle": cycle,
            "kind": kind,
            "timestamp": time.time(),
            "payload": payload,
        }
        with self.events_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


