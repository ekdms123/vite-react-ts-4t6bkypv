from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

from .intent_fidelity import IntentFidelityProjector
from .requirement_contract import RequirementCompiler
from .directive_invariant import verify_atom_conservation, verify_destination


from .source_authority import explicit_replacement_requested
@dataclass(frozen=True)
class IntentRequirement:
    requirement_id: str
    text: str
    source: str
    created_at: float
    tags: tuple[str, ...] = ()
    status: str = "active"
    superseded_by: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class CumulativeIntentLedger:
    """Durable project intent ledger.

    Preserves user requirements across sessions while allowing flexible updates
    and seamless revisions without raising blocking permission errors.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"version": 1, "requirements": []})

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def _stable_id(text: str, source: str) -> str:
        digest = hashlib.sha256(f"{source}\n{text}".encode("utf-8")).hexdigest()[:16]
        return f"intent_{digest}"

    @staticmethod
    def _coerce(row: dict[str, Any]) -> IntentRequirement:
        return IntentRequirement(
            requirement_id=str(row["requirement_id"]),
            text=str(row["text"]),
            source=str(row.get("source", "unknown")),
            created_at=float(row.get("created_at", 0.0)),
            tags=tuple(row["tags"] if "tags" in row else ()),
            status=str(row.get("status", "active")),
            superseded_by=str(row.get("superseded_by", "")),
            metadata=dict(row.get("metadata") or {}),
        )

    def add(
        self,
        text: str,
        *,
        source: str = "user",
        tags: Iterable[str] = (),
        metadata: dict[str, Any] | None = None,
    ) -> IntentRequirement:
        cleaned = str(text).strip()
        if not cleaned:
            raise ValueError("intent requirement must be non-empty")
        rid = self._stable_id(cleaned, str(source))
        data = self._read()
        for row in data.get("requirements", []):
            if row.get("requirement_id") == rid:
                return self._coerce(row)
        req = IntentRequirement(
            rid,
            cleaned,
            str(source),
            time.time(),
            tuple(dict.fromkeys(map(str, tags))),
            metadata=dict(metadata or {}),
        )
        data.setdefault("requirements", []).append(asdict(req))
        self._write(data)
        return req

    def add_many(
        self,
        requirements: Iterable[str],
        *,
        source: str = "user_project_contract",
        tags: Iterable[str] = (),
    ) -> tuple[IntentRequirement, ...]:
        return tuple(self.add(text, source=source, tags=tags) for text in requirements)

    @staticmethod
    def _occurrence_id(message_sha256: str, index: int, atom_id: str, text: str, source: str) -> str:
        material = f"{source}\n{message_sha256}\n{index}\n{atom_id}\n{text}"
        return "intent_occ_" + hashlib.sha256(material.encode("utf-8")).hexdigest()[:20]

    def add_message(
        self,
        text: str,
        *,
        source: str = "user_turn",
        tags: Iterable[str] = (),
        metadata: dict[str, Any] | None = None,
    ) -> tuple[IntentRequirement, ...]:
        """Persist one exact message once, plus occurrence-addressed requirement rows.

        Earlier revisions copied the full parent message into every atom and called
        ``add()`` once per atom.  A 94KB/1k-atom turn therefore rewrote a growing JSON
        ledger thousands of times and could duplicate the raw message hundreds of MB.
        The v2 representation keeps one canonical message body and makes atoms point
        to it by content hash + occurrence index.  This preserves exact provenance
        *and* duplicate occurrences without O(n^2) persistence.
        """
        exact = str(text)
        raw = exact.strip()
        if not raw:
            raise ValueError("intent message must be non-empty")
        contract = RequirementCompiler.compile(exact)
        atoms = tuple({"atom_id": atom.atom_id, "text": atom.text} for atom in contract.atoms)
        message_sha256 = contract.message_sha256
        verify_destination(raw_user_text=exact, original_user_directive_sha256=message_sha256)
        verify_atom_conservation(
            raw_user_text=exact,
            active_atom_ids=(atom["atom_id"] for atom in atoms),
        )

        data = self._read()
        data["version"] = max(2, int(data.get("version", 1) or 1))
        requirements = data.setdefault("requirements", [])
        messages = data.setdefault("messages", {})
        now = time.time()
        tag_tuple = tuple(dict.fromkeys(tuple(map(str, tags)) + ("canonical_atom",)))
        message_changed = False
        if message_sha256 not in messages:
            messages[message_sha256] = {
                "exact_text": exact,
                "source": str(source),
                "created_at": now,
                "atom_count": len(atoms),
                "tags": list(tag_tuple),
            }
            message_changed = True

        existing_by_occurrence: dict[tuple[str, int], dict[str, Any]] = {}
        for row in requirements:
            meta = dict(row.get("metadata") or {})
            sha = str(meta.get("parent_message_sha256") or "")
            try:
                idx = int(meta.get("atom_index") or 0)
            except (TypeError, ValueError):
                idx = 0
            if sha and idx:
                existing_by_occurrence[(sha, idx)] = row

        base_meta = dict(metadata or {})
        base_meta.update({
            "canonical_representation": "intent_fidelity_occurrences_v2",
            "parent_message_sha256": message_sha256,
            "parent_message_ref": f"message:{message_sha256}",
            "atom_count": len(atoms),
        })
        rows: list[IntentRequirement] = []
        wrote = message_changed
        for index, atom in enumerate(atoms, start=1):
            existing = existing_by_occurrence.get((message_sha256, index))
            if existing is not None:
                rows.append(self._coerce(existing))
                continue
            atom_meta = dict(base_meta)
            atom_meta.update({"atom_id": atom["atom_id"], "atom_index": index})
            req = IntentRequirement(
                requirement_id=self._occurrence_id(message_sha256, index, atom["atom_id"], atom["text"], str(source)),
                text=str(atom["text"]),
                source=str(source),
                created_at=now,
                tags=tag_tuple,
                metadata=atom_meta,
            )
            requirements.append(asdict(req))
            rows.append(req)
            wrote = True
        if wrote:
            self._write(data)
        return tuple(rows)

    def exact_message(self, message_sha256: str) -> str:
        """Return the single-copy canonical raw message body for a known message hash.

        Finalization must verify destination authority against the original raw user
        bytes/text, never a semantic projection or restored continuation objective.
        """
        key = str(message_sha256 or "").strip().lower()
        if not key:
            return ""
        data = self._read()
        row = dict((data.get("messages") or {}).get(key) or {})
        exact = str(row.get("exact_text") or "")
        if exact and RequirementCompiler.compile(exact).message_sha256 != key:
            raise RuntimeError("cumulative_intent_message_hash_mismatch")
        return exact

    def active(self) -> tuple[IntentRequirement, ...]:
        return tuple(
            self._coerce(x)
            for x in self._read().get("requirements", [])
            if x.get("status", "active") == "active"
        )

    def all(self) -> tuple[IntentRequirement, ...]:
        return tuple(self._coerce(x) for x in self._read().get("requirements", []))

    def supersede(
        self,
        requirement_id: str,
        replacement_text: str,
        *,
        source: str = "user",
        exact_user_text: str = "",
    ) -> IntentRequirement:
        """Replace intent only when the exact user source explicitly authorizes it."""
        if not explicit_replacement_requested(exact_user_text):
            raise PermissionError("intent supersession requires explicit exact-user-source replacement language")
        replacement = self.add(replacement_text, source=source, tags=("superseded_revision",))
        data = self._read()
        found = False
        for row in data.get("requirements", []):
            if row.get("requirement_id") == str(requirement_id):
                row["status"] = "superseded"
                row["superseded_by"] = replacement.requirement_id
                found = True
                break
        if not found:
            return replacement
        self._write(data)
        return replacement

    def compose(self, current_delta: str = "") -> dict[str, Any]:
        active = self.active()
        return {
            "persistent_requirements": [asdict(x) for x in active],
            "canonical_requirements": [
                asdict(x) for x in active if "canonical_atom" in x.tags
            ],
            "current_turn_delta": str(current_delta).strip(),
            "semantics": "additive_project_intent",
            "canonical_representation": "intent_fidelity_atoms_v1",
            "implicit_supersede_allowed": False,
        }
