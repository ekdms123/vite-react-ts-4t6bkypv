from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Callable, Protocol

from .protocol_codec import ProtocolCodecRegistry
from .capability_bus import (
    CapabilityDescriptor,
    CapabilityInvocation,
    CapabilityComponent,
    CapabilityResult,
    UniversalCapabilityBus,
)


@dataclass(frozen=True)
class ModelTurn:
    role: str
    content: Any


@dataclass(frozen=True)
class ModelRequest:
    objective: str
    messages: tuple[ModelTurn, ...] = ()
    context: dict[str, Any] = field(default_factory=dict)
    response_contract: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ModelResponse:
    content: Any
    model_id: str
    metadata: dict[str, Any] = field(default_factory=dict)


class ModelProvider(Protocol):
    def __call__(self, request: ModelRequest) -> ModelResponse | Any: ...


class ModelComponentAdapter:
    """Exposes model/inference providers as modular capability components.

    Enables pluggable model inference without hardcoding provider assumptions.
    """

    def __init__(
        self,
        *,
        capability_id: str,
        provider: ModelProvider,
        model_id: str,
        provides: tuple[str, ...] = ("model_inference",),
        tags: tuple[str, ...] = ("replaceable_model",),
        location: str = "external",
        priority: float = 0.0,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.capability_id = capability_id
        self.provider = provider
        self.model_id = model_id
        self.provides = provides
        self.tags = tags
        self.location = location
        self.priority = priority
        self.metadata = dict(metadata or {})
        self.protocol = ProtocolCodecRegistry().ensure("model_component", {
            "messages": ("turns",), "role": ("speaker",), "content": ("value",),
            "context": ("state",), "response_contract": ("contract",)
        })

    def as_component(self) -> CapabilityComponent:
        descriptor = CapabilityDescriptor(
            self.capability_id,
            "model",
            self.provides,
            accepts=("model_request",),
            tags=self.tags,
            location=self.location,
            priority=self.priority,
            metadata={
                "model_id": self.model_id,
                "role": "cognitive_inference_component",
                **self.metadata,
            },
        )

        def handler(call: CapabilityInvocation) -> CapabilityResult:
            rows = self.protocol.read(call.payload, "messages", ()) or ()
            messages = tuple(
                ModelTurn(str(self.protocol.read(row, "role", "user")), copy.deepcopy(self.protocol.read(row, "content")))
                for row in rows
            )
            request = ModelRequest(
                objective=call.objective,
                messages=messages,
                context=copy.deepcopy(self.protocol.read(call.payload, "context", {}) or {}),
                response_contract=copy.deepcopy(self.protocol.read(call.payload, "response_contract", {}) or {}),
            )
            value = self.provider(request)
            response = value if isinstance(value, ModelResponse) else ModelResponse(value, self.model_id)
            return CapabilityResult(
                call_id=call.call_id,
                capability_id=call.capability_id,
                success=True,
                output={
                    "content": copy.deepcopy(response.content),
                    "model_id": response.model_id,
                    "metadata": copy.deepcopy(response.metadata),
                },
            )

        return CapabilityComponent(descriptor, handler)


class ModelBackedController:
    """Control component delegating orchestration steps to a selected model component."""

    def __init__(
        self,
        *,
        capability_id: str,
        bus: UniversalCapabilityBus,
        model_requirement: Any,
        prompt_builder: Callable[[CapabilityInvocation], tuple[dict[str, Any], ...]],
        parser: Callable[[Any, CapabilityInvocation], Any] | None = None,
        priority: float = 0.0,
        tags: tuple[str, ...] = ("model_backed_control",),
    ) -> None:
        self.capability_id = capability_id
        self.bus = bus
        self.model_requirement = model_requirement
        self.prompt_builder = prompt_builder
        self.parser = parser or (lambda value, _call: value)
        self.priority = priority
        self.tags = tags
        self.protocol = ProtocolCodecRegistry().ensure("model_backed_control", {"content": ("value",)})

    def as_component(self) -> CapabilityComponent:
        descriptor = CapabilityDescriptor(
            self.capability_id,
            "control",
            ("orchestration_control",),
            tags=self.tags,
            priority=self.priority,
            metadata={"role": "model_orchestration_controller"},
        )

        def handler(call: CapabilityInvocation) -> CapabilityResult:
            model_result = self.bus.invoke_requirement(
                self.model_requirement,
                objective=call.objective,
                payload={
                    "messages": list(self.prompt_builder(call)),
                    "context": {
                        "controller_capability": self.capability_id,
                        "jigaewol_payload": copy.deepcopy(call.payload),
                    },
                    "response_contract": {
                        "kind": "orchestration_decision",
                    },
                },
                context=copy.deepcopy(call.context),
            )
            if not model_result.success:
                return CapabilityResult(
                    call_id=call.call_id,
                    capability_id=call.capability_id,
                    success=False,
                    output=None,
                    error=model_result.error,
                )
            content = self.protocol.read(model_result.output, "content") if isinstance(model_result.output, dict) else model_result.output
            return CapabilityResult(
                call_id=call.call_id,
                capability_id=call.capability_id,
                success=True,
                output=self.parser(content, call),
                observations=(
                    {
                        "model_capability_id": model_result.capability_id,
                        "model_output": copy.deepcopy(model_result.output),
                    },
                ),
            )

        return CapabilityComponent(descriptor, handler)


