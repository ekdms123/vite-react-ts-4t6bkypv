"""Source-preserving revisions shared by code, prose, search reports and design."""
from __future__ import annotations
import hashlib

def apply_edits(source_text, edits):
    result=str(source_text);applied=[]
    for edit in edits:
        before=str(edit['before']);after=str(edit['after'])
        if not before:raise ValueError('revision requires an exact source anchor')
        if 'start' in edit:
            position=int(edit['start'])
            if result[position:position+len(before)]!=before:raise ValueError('revision anchor changed')
        else:
            if result.count(before)!=1:raise ValueError('revision anchor must identify one source span')
            position=result.index(before)
        result=result[:position]+after+result[position+len(before):]
        applied.append({'before':before,'after':after,'start':position})
    return {'body':result,'applied_edits':applied,
            'source_sha256':hashlib.sha256(str(source_text).encode()).hexdigest(),
            'result_sha256':hashlib.sha256(result.encode()).hexdigest()}
