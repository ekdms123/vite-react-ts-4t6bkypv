from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class BodyEvidence:
    body_id: str
    kind: str
    executor: str
    state: str
    evidence_strength: float
    capabilities: tuple[str, ...]
    evidence: dict[str, Any] = field(default_factory=dict)
    observed_at: float = 0.0


class ExternalBodyRegistry:
    """Evidence-first registry for distributed execution bodies.

    Maintains open state definitions and measures execution validity through
    verifiable empirical strength without artificial taxonomic ceilings.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({"bodies": {}})

    def _read(self) -> dict[str, Any]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def upsert(
        self,
        body_id: str,
        *,
        kind: str,
        executor: str,
        state: str,
        capabilities: tuple[str, ...] | list[str],
        evidence: dict[str, Any] | None = None,
        evidence_strength: float = 0.0,
    ) -> BodyEvidence:
        row = BodyEvidence(
            body_id=str(body_id),
            kind=str(kind),
            executor=str(executor),
            state=str(state),
            evidence_strength=float(evidence_strength),
            capabilities=tuple(dict.fromkeys(str(x) for x in capabilities)),
            evidence=dict(evidence or {}),
            observed_at=time.time(),
        )
        data = self._read()
        previous = data.setdefault("bodies", {}).get(row.body_id)
        if previous is not None and row.evidence_strength < float(previous.get("evidence_strength", 0.0)):
            raise ValueError("body evidence strength cannot be degraded without newer verification")
        data["bodies"][row.body_id] = asdict(row)
        self._write(data)
        return row

    def get(self, body_id: str) -> BodyEvidence | None:
        row = self._read().get("bodies", {}).get(body_id)
        return BodyEvidence(**row) if row else None

    def bodies(self) -> tuple[BodyEvidence, ...]:
        return tuple(BodyEvidence(**x) for x in self._read().get("bodies", {}).values())

    def available_for(self, capability: str, *, minimum_evidence_strength: float = 0.5) -> tuple[BodyEvidence, ...]:
        return tuple(
            x for x in self.bodies()
            if capability in x.capabilities and x.evidence_strength >= float(minimum_evidence_strength)
        )
