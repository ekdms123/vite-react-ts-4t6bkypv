from __future__ import annotations

import hashlib
import json
import sqlite3
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha(value: Any) -> str:
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class DurableRun:
    run_id: str
    objective: str
    worker_ref: str
    status: str
    created_at: float
    updated_at: float
    terminal_kind: str = ""
    terminal_result_sha256: str = ""
    lease_owner: str = ""
    lease_expires_at: float = 0.0
    metadata: dict[str, Any] | None = None

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RunEvent:
    run_id: str
    sequence: int
    kind: str
    payload: Any
    evidence_refs: tuple[str, ...]
    idempotency_key: str
    observed_at: float
    payload_sha256: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RunConsumerState:
    run_id: str
    consumer_id: str
    accepted_sequence: int
    reconnect_attempt: int
    terminal_seen: bool
    updated_at: float

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ConsumerAcceptResult:
    state: RunConsumerState
    accepted: bool
    duplicate: bool
    event: RunEvent | None

    def as_mapping(self) -> dict[str, Any]:
        out = asdict(self)
        out["event"] = self.event.as_mapping() if self.event is not None else None
        return out


@dataclass(frozen=True)
class ReplayPage:
    run_id: str
    cursor: int
    next_cursor: int
    latest_sequence: int
    events: tuple[RunEvent, ...]
    has_more: bool
    terminal: bool
    terminal_kind: str
    cursor_ahead: bool
    gap_detected: bool

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class DurableRunLedger:
    """Durable ordered run/event protocol for reconnectable long-running work.

    The ledger is intentionally small and host-neutral. WorkProgram/CausalJournal
    remain the task/causal truth; this class only supplies a durable run identity,
    ordered observable events, bounded replay, lease ownership, and exactly one
    terminal outcome. It lives under RuntimeFoundation's persistent root, outside
    disposable ZIP extractions.
    """

    FORMAT = "jigaewol_durable_run_v1"
    TERMINAL_KINDS = frozenset({"succeeded", "failed", "cancelled"})

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "runs.sqlite3"
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path, timeout=30.0, isolation_level=None)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=FULL")
        con.execute("PRAGMA foreign_keys=ON")
        return con

    def _init_db(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta(
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS runs(
                    run_id TEXT PRIMARY KEY,
                    objective TEXT NOT NULL,
                    worker_ref TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    terminal_kind TEXT NOT NULL DEFAULT '',
                    terminal_result_sha256 TEXT NOT NULL DEFAULT '',
                    lease_owner TEXT NOT NULL DEFAULT '',
                    lease_expires_at REAL NOT NULL DEFAULT 0,
                    metadata_json TEXT NOT NULL DEFAULT '{}'
                );
                CREATE TABLE IF NOT EXISTS events(
                    run_id TEXT NOT NULL,
                    sequence INTEGER NOT NULL,
                    kind TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    evidence_refs_json TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    observed_at REAL NOT NULL,
                    payload_sha256 TEXT NOT NULL,
                    PRIMARY KEY(run_id, sequence),
                    UNIQUE(run_id, idempotency_key),
                    FOREIGN KEY(run_id) REFERENCES runs(run_id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_events_run_seq ON events(run_id, sequence);
                CREATE TABLE IF NOT EXISTS consumers(
                    run_id TEXT NOT NULL,
                    consumer_id TEXT NOT NULL,
                    accepted_sequence INTEGER NOT NULL DEFAULT 0,
                    reconnect_attempt INTEGER NOT NULL DEFAULT 0,
                    terminal_seen INTEGER NOT NULL DEFAULT 0,
                    updated_at REAL NOT NULL,
                    PRIMARY KEY(run_id, consumer_id),
                    FOREIGN KEY(run_id) REFERENCES runs(run_id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS delivery_failures(
                    run_id TEXT NOT NULL,
                    consumer_id TEXT NOT NULL,
                    sequence INTEGER NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT NOT NULL DEFAULT '',
                    evidence_refs_json TEXT NOT NULL DEFAULT '[]',
                    dead_lettered INTEGER NOT NULL DEFAULT 0,
                    updated_at REAL NOT NULL,
                    PRIMARY KEY(run_id, consumer_id, sequence),
                    FOREIGN KEY(run_id) REFERENCES runs(run_id) ON DELETE CASCADE
                );
                """
            )
            columns={str(row[1]) for row in con.execute("PRAGMA table_info(delivery_failures)").fetchall()}
            if "evidence_refs_json" not in columns:
                con.execute("ALTER TABLE delivery_failures ADD COLUMN evidence_refs_json TEXT NOT NULL DEFAULT '[]'")
            con.execute(
                "INSERT INTO meta(key,value) VALUES('format',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (self.FORMAT,),
            )

    @staticmethod
    def _refs(values: Iterable[str]) -> tuple[str, ...]:
        return tuple(dict.fromkeys(str(x) for x in values if str(x).strip()))

    @staticmethod
    def _row_to_run(row: sqlite3.Row) -> DurableRun:
        return DurableRun(
            run_id=str(row["run_id"]),
            objective=str(row["objective"]),
            worker_ref=str(row["worker_ref"]),
            status=str(row["status"]),
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
            terminal_kind=str(row["terminal_kind"]),
            terminal_result_sha256=str(row["terminal_result_sha256"]),
            lease_owner=str(row["lease_owner"]),
            lease_expires_at=float(row["lease_expires_at"]),
            metadata=dict(json.loads(str(row["metadata_json"]) or "{}")),
        )

    @staticmethod
    def _row_to_event(row: sqlite3.Row) -> RunEvent:
        return RunEvent(
            run_id=str(row["run_id"]),
            sequence=int(row["sequence"]),
            kind=str(row["kind"]),
            payload=json.loads(str(row["payload_json"])),
            evidence_refs=tuple(json.loads(str(row["evidence_refs_json"]))),
            idempotency_key=str(row["idempotency_key"]),
            observed_at=float(row["observed_at"]),
            payload_sha256=str(row["payload_sha256"]),
        )

    @staticmethod
    def _row_to_consumer(row: sqlite3.Row) -> RunConsumerState:
        return RunConsumerState(
            run_id=str(row["run_id"]),
            consumer_id=str(row["consumer_id"]),
            accepted_sequence=int(row["accepted_sequence"]),
            reconnect_attempt=int(row["reconnect_attempt"]),
            terminal_seen=bool(int(row["terminal_seen"])),
            updated_at=float(row["updated_at"]),
        )

    def create_run(
        self,
        *,
        objective: str,
        worker_ref: str = "",
        metadata: Mapping[str, Any] | None = None,
        run_id: str | None = None,
    ) -> DurableRun:
        objective = str(objective).strip()
        if not objective:
            raise ValueError("objective must be non-empty")
        rid = str(run_id or ("run_" + uuid.uuid4().hex[:20]))
        now = time.time()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            exists = con.execute("SELECT * FROM runs WHERE run_id=?", (rid,)).fetchone()
            if exists is not None:
                current = self._row_to_run(exists)
                if current.objective != objective or current.worker_ref != str(worker_ref):
                    con.execute("ROLLBACK")
                    raise ValueError("run_id already exists with different identity")
                con.execute("COMMIT")
                return current
            con.execute(
                "INSERT INTO runs(run_id,objective,worker_ref,status,created_at,updated_at,metadata_json) VALUES(?,?,?,?,?,?,?)",
                (rid, objective, str(worker_ref), "running", now, now, _json(dict(metadata or {}))),
            )
            con.execute("COMMIT")
        return self.get(rid)

    def get(self, run_id: str) -> DurableRun:
        with self._connect() as con:
            row = con.execute("SELECT * FROM runs WHERE run_id=?", (str(run_id),)).fetchone()
        if row is None:
            raise KeyError(run_id)
        return self._row_to_run(row)

    def append_event(
        self,
        run_id: str,
        *,
        kind: str,
        payload: Any,
        evidence_refs: Iterable[str] = (),
        idempotency_key: str = "",
        observed_at: float | None = None,
    ) -> RunEvent:
        rid = str(run_id)
        kind = str(kind).strip()
        if not kind:
            raise ValueError("event kind must be non-empty")
        refs = self._refs(evidence_refs)
        payload_sha = _sha(payload)
        idem = str(idempotency_key).strip() or _sha({"kind": kind, "payload_sha256": payload_sha, "evidence_refs": refs})
        now = float(observed_at if observed_at is not None else time.time())
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            run = con.execute("SELECT * FROM runs WHERE run_id=?", (rid,)).fetchone()
            if run is None:
                con.execute("ROLLBACK")
                raise KeyError(run_id)
            if str(run["terminal_kind"]):
                con.execute("ROLLBACK")
                raise RuntimeError("terminal run cannot accept new events")
            prior = con.execute("SELECT * FROM events WHERE run_id=? AND idempotency_key=?", (rid, idem)).fetchone()
            if prior is not None:
                con.execute("COMMIT")
                return self._row_to_event(prior)
            seq = int(con.execute("SELECT COALESCE(MAX(sequence),0)+1 FROM events WHERE run_id=?", (rid,)).fetchone()[0])
            con.execute(
                "INSERT INTO events(run_id,sequence,kind,payload_json,evidence_refs_json,idempotency_key,observed_at,payload_sha256) VALUES(?,?,?,?,?,?,?,?)",
                (rid, seq, kind, _json(payload), _json(refs), idem, now, payload_sha),
            )
            con.execute("UPDATE runs SET updated_at=? WHERE run_id=?", (now, rid))
            row = con.execute("SELECT * FROM events WHERE run_id=? AND sequence=?", (rid, seq)).fetchone()
            con.execute("COMMIT")
        if row is None:
            raise RuntimeError("durable run invariant failed: committed event row missing")
        return self._row_to_event(row)

    def terminate(
        self,
        run_id: str,
        *,
        terminal_kind: str,
        result: Any,
        evidence_refs: Iterable[str],
        idempotency_key: str = "",
    ) -> RunEvent:
        rid = str(run_id)
        terminal_kind = str(terminal_kind)
        if terminal_kind not in self.TERMINAL_KINDS:
            raise ValueError("unsupported terminal kind")
        refs = self._refs(evidence_refs)
        if not refs:
            raise ValueError("terminal outcome requires evidence refs")
        result_sha = _sha(result)
        idem = str(idempotency_key).strip() or f"terminal:{terminal_kind}:{result_sha}"
        now = time.time()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            run = con.execute("SELECT * FROM runs WHERE run_id=?", (rid,)).fetchone()
            if run is None:
                con.execute("ROLLBACK")
                raise KeyError(run_id)
            prior = con.execute("SELECT * FROM events WHERE run_id=? AND idempotency_key=?", (rid, idem)).fetchone()
            existing_kind = str(run["terminal_kind"])
            if existing_kind:
                if prior is not None and existing_kind == terminal_kind and str(run["terminal_result_sha256"]) == result_sha:
                    con.execute("COMMIT")
                    return self._row_to_event(prior)
                con.execute("ROLLBACK")
                raise RuntimeError("run already has a terminal outcome")
            seq = int(con.execute("SELECT COALESCE(MAX(sequence),0)+1 FROM events WHERE run_id=?", (rid,)).fetchone()[0])
            payload = {"terminal_kind": terminal_kind, "result": result}
            con.execute(
                "INSERT INTO events(run_id,sequence,kind,payload_json,evidence_refs_json,idempotency_key,observed_at,payload_sha256) VALUES(?,?,?,?,?,?,?,?)",
                (rid, seq, "terminal", _json(payload), _json(refs), idem, now, _sha(payload)),
            )
            con.execute(
                "UPDATE runs SET status='terminal',terminal_kind=?,terminal_result_sha256=?,lease_owner='',lease_expires_at=0,updated_at=? WHERE run_id=?",
                (terminal_kind, result_sha, now, rid),
            )
            row = con.execute("SELECT * FROM events WHERE run_id=? AND sequence=?", (rid, seq)).fetchone()
            con.execute("COMMIT")
        if row is None:
            raise RuntimeError("durable run invariant failed: committed event row missing")
        return self._row_to_event(row)

    def replay(self, run_id: str, *, cursor: int = 0, limit: int = 100) -> ReplayPage:
        rid = str(run_id)
        cursor = int(cursor)
        limit = max(1, min(int(limit), 1000))
        run = self.get(rid)
        with self._connect() as con:
            latest = int(con.execute("SELECT COALESCE(MAX(sequence),0) FROM events WHERE run_id=?", (rid,)).fetchone()[0])
            earliest = int(con.execute("SELECT COALESCE(MIN(sequence),0) FROM events WHERE run_id=?", (rid,)).fetchone()[0])
            rows = con.execute(
                "SELECT * FROM events WHERE run_id=? AND sequence>? ORDER BY sequence ASC LIMIT ?",
                (rid, cursor, limit),
            ).fetchall()
        events = tuple(self._row_to_event(x) for x in rows)
        next_cursor = events[-1].sequence if events else min(max(cursor, 0), latest)
        cursor_ahead = cursor > latest
        gap = bool(earliest and cursor < earliest - 1)
        return ReplayPage(
            run_id=rid,
            cursor=cursor,
            next_cursor=next_cursor,
            latest_sequence=latest,
            events=events,
            has_more=bool(next_cursor < latest),
            terminal=bool(run.terminal_kind),
            terminal_kind=run.terminal_kind,
            cursor_ahead=cursor_ahead,
            gap_detected=gap,
        )

    def acquire_lease(self, run_id: str, *, owner: str, ttl_s: float = 60.0) -> DurableRun:
        rid = str(run_id); owner = str(owner).strip(); ttl_s = float(ttl_s)
        if not owner or ttl_s <= 0:
            raise ValueError("lease requires owner and positive ttl")
        now = time.time(); expires = now + ttl_s
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT * FROM runs WHERE run_id=?", (rid,)).fetchone()
            if row is None:
                con.execute("ROLLBACK"); raise KeyError(run_id)
            if str(row["terminal_kind"]):
                con.execute("ROLLBACK"); raise RuntimeError("terminal run cannot be leased")
            current_owner = str(row["lease_owner"]); current_exp = float(row["lease_expires_at"])
            if current_owner and current_owner != owner and current_exp > now:
                con.execute("ROLLBACK"); raise RuntimeError("run lease is held by another live owner")
            con.execute("UPDATE runs SET lease_owner=?,lease_expires_at=?,updated_at=? WHERE run_id=?", (owner, expires, now, rid))
            con.execute("COMMIT")
        return self.get(rid)

    def heartbeat(self, run_id: str, *, owner: str, ttl_s: float = 60.0) -> DurableRun:
        rid = str(run_id); owner = str(owner).strip(); ttl_s = float(ttl_s)
        now = time.time(); expires = now + ttl_s
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT * FROM runs WHERE run_id=?", (rid,)).fetchone()
            if row is None:
                con.execute("ROLLBACK"); raise KeyError(run_id)
            if str(row["terminal_kind"]):
                con.execute("ROLLBACK"); raise RuntimeError("terminal run cannot heartbeat")
            if str(row["lease_owner"]) != owner:
                con.execute("ROLLBACK"); raise RuntimeError("heartbeat owner does not hold run lease")
            if float(row["lease_expires_at"]) <= now:
                con.execute("ROLLBACK"); raise RuntimeError("run lease has expired")
            con.execute("UPDATE runs SET lease_expires_at=?,updated_at=? WHERE run_id=?", (expires, now, rid))
            con.execute("COMMIT")
        return self.get(rid)

    def recover_lease(
        self, run_id: str, *, new_owner: str, ttl_s: float = 60.0,
        expected_previous_owner: str = "", evidence_refs: Iterable[str] = (),
    ) -> RunEvent:
        """Explicitly recover an expired lease and journal the ownership handoff.

        Ordinary acquire_lease keeps backward-compatible takeover semantics after
        expiry.  This method is the auditable recovery path for long-running work:
        it refuses a live lease, optionally checks the previous owner identity,
        and records a durable lease_recovered event in the same transaction as the
        owner swap.
        """
        rid = str(run_id); owner = str(new_owner).strip(); ttl_s = float(ttl_s)
        expected = str(expected_previous_owner).strip()
        if not owner or ttl_s <= 0:
            raise ValueError("lease recovery requires new_owner and positive ttl")
        refs = self._refs(evidence_refs)
        now = time.time(); expires = now + ttl_s
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT * FROM runs WHERE run_id=?", (rid,)).fetchone()
            if row is None:
                con.execute("ROLLBACK"); raise KeyError(run_id)
            if str(row["terminal_kind"]):
                con.execute("ROLLBACK"); raise RuntimeError("terminal run cannot be recovered")
            previous_owner = str(row["lease_owner"])
            previous_expiry = float(row["lease_expires_at"])
            if not previous_owner:
                con.execute("ROLLBACK"); raise RuntimeError("run has no prior lease to recover")
            if previous_expiry > now:
                con.execute("ROLLBACK"); raise RuntimeError("run lease is still live")
            if expected and previous_owner != expected:
                con.execute("ROLLBACK"); raise RuntimeError("previous lease owner mismatch")
            payload = {
                "previous_owner": previous_owner,
                "new_owner": owner,
                "previous_lease_expires_at": previous_expiry,
                "recovered_at": now,
                "new_lease_expires_at": expires,
            }
            idem = f"lease-recovered:{previous_owner}:{owner}:{previous_expiry:.6f}"
            prior = con.execute("SELECT * FROM events WHERE run_id=? AND idempotency_key=?", (rid, idem)).fetchone()
            if prior is not None:
                con.execute("COMMIT")
                return self._row_to_event(prior)
            seq = int(con.execute("SELECT COALESCE(MAX(sequence),0)+1 FROM events WHERE run_id=?", (rid,)).fetchone()[0])
            con.execute(
                "INSERT INTO events(run_id,sequence,kind,payload_json,evidence_refs_json,idempotency_key,observed_at,payload_sha256) VALUES(?,?,?,?,?,?,?,?)",
                (rid, seq, "lease_recovered", _json(payload), _json(refs), idem, now, _sha(payload)),
            )
            con.execute(
                "UPDATE runs SET lease_owner=?,lease_expires_at=?,updated_at=? WHERE run_id=?",
                (owner, expires, now, rid),
            )
            out = con.execute("SELECT * FROM events WHERE run_id=? AND sequence=?", (rid, seq)).fetchone()
            con.execute("COMMIT")
        if out is None:
            raise RuntimeError("durable run invariant failed: committed recovery event row missing")
        return self._row_to_event(out)

    def ensure_consumer(
        self, run_id: str, *, consumer_id: str, accepted_sequence: int = 0
    ) -> RunConsumerState:
        rid = str(run_id); cid = str(consumer_id).strip(); accepted = max(0, int(accepted_sequence))
        if not cid:
            raise ValueError("consumer_id must be non-empty")
        run = self.get(rid)
        with self._connect() as con:
            latest = int(con.execute("SELECT COALESCE(MAX(sequence),0) FROM events WHERE run_id=?", (rid,)).fetchone()[0])
            if accepted > latest:
                raise ValueError("consumer cursor cannot be ahead of durable run")
            now = time.time()
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT * FROM consumers WHERE run_id=? AND consumer_id=?", (rid, cid)).fetchone()
            if row is None:
                con.execute(
                    "INSERT INTO consumers(run_id,consumer_id,accepted_sequence,reconnect_attempt,terminal_seen,updated_at) VALUES(?,?,?,?,?,?)",
                    (rid, cid, accepted, 0, 1 if (run.terminal_kind and accepted >= latest) else 0, now),
                )
            elif accepted > int(row["accepted_sequence"]):
                # Importing a legacy cursor may advance once, but never regress an existing durable consumer.
                con.execute(
                    "UPDATE consumers SET accepted_sequence=?,reconnect_attempt=0,terminal_seen=?,updated_at=? WHERE run_id=? AND consumer_id=?",
                    (accepted, 1 if (run.terminal_kind and accepted >= latest) else int(row["terminal_seen"]), now, rid, cid),
                )
            out = con.execute("SELECT * FROM consumers WHERE run_id=? AND consumer_id=?", (rid, cid)).fetchone()
            con.execute("COMMIT")
        if out is None:
            raise RuntimeError("durable run invariant failed: committed consumer row missing")
        return self._row_to_consumer(out)

    def get_consumer(self, run_id: str, *, consumer_id: str) -> RunConsumerState:
        with self._connect() as con:
            row = con.execute("SELECT * FROM consumers WHERE run_id=? AND consumer_id=?", (str(run_id), str(consumer_id))).fetchone()
        if row is None:
            raise KeyError((run_id, consumer_id))
        return self._row_to_consumer(row)

    def accept_consumer_event(
        self, run_id: str, *, consumer_id: str, sequence: int
    ) -> ConsumerAcceptResult:
        rid = str(run_id); cid = str(consumer_id).strip(); seq = int(sequence)
        if not cid or seq <= 0:
            raise ValueError("accept requires consumer_id and positive sequence")
        self.ensure_consumer(rid, consumer_id=cid, accepted_sequence=0)
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            state_row = con.execute("SELECT * FROM consumers WHERE run_id=? AND consumer_id=?", (rid, cid)).fetchone()
            if state_row is None:
                con.execute("ROLLBACK")
                raise RuntimeError("durable run invariant failed: ensured consumer row missing")
            accepted = int(state_row["accepted_sequence"])
            if seq <= accepted:
                event_row = con.execute("SELECT * FROM events WHERE run_id=? AND sequence=?", (rid, seq)).fetchone()
                con.execute("COMMIT")
                return ConsumerAcceptResult(self._row_to_consumer(state_row), False, True, self._row_to_event(event_row) if event_row else None)
            if bool(int(state_row["terminal_seen"])):
                con.execute("ROLLBACK")
                raise RuntimeError("consumer already accepted terminal event")
            if seq != accepted + 1:
                con.execute("ROLLBACK")
                raise RuntimeError(f"consumer sequence gap: expected {accepted + 1}, got {seq}")
            event_row = con.execute("SELECT * FROM events WHERE run_id=? AND sequence=?", (rid, seq)).fetchone()
            if event_row is None:
                con.execute("ROLLBACK")
                raise RuntimeError("consumer cannot accept an event that does not exist")
            event = self._row_to_event(event_row)
            terminal_seen = 1 if event.kind == "terminal" else 0
            now = time.time()
            con.execute(
                "UPDATE consumers SET accepted_sequence=?,reconnect_attempt=0,terminal_seen=?,updated_at=? WHERE run_id=? AND consumer_id=?",
                (seq, terminal_seen, now, rid, cid),
            )
            con.execute("DELETE FROM delivery_failures WHERE run_id=? AND consumer_id=? AND sequence=?", (rid, cid, seq))
            out = con.execute("SELECT * FROM consumers WHERE run_id=? AND consumer_id=?", (rid, cid)).fetchone()
            con.execute("COMMIT")
        if out is None:
            raise RuntimeError("durable run invariant failed: accepted consumer row missing")
        return ConsumerAcceptResult(self._row_to_consumer(out), True, False, event)

    def record_reconnect_failure(self, run_id: str, *, consumer_id: str) -> RunConsumerState:
        rid = str(run_id); cid = str(consumer_id).strip()
        self.ensure_consumer(rid, consumer_id=cid, accepted_sequence=0)
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            con.execute(
                "UPDATE consumers SET reconnect_attempt=reconnect_attempt+1,updated_at=? WHERE run_id=? AND consumer_id=?",
                (time.time(), rid, cid),
            )
            row = con.execute("SELECT * FROM consumers WHERE run_id=? AND consumer_id=?", (rid, cid)).fetchone()
            con.execute("COMMIT")
        if row is None:
            raise RuntimeError("durable run invariant failed: reconnect consumer row missing")
        return self._row_to_consumer(row)

    def consumer_reconnect_plan(
        self, run_id: str, *, consumer_id: str, max_attempts: int = 5,
        base_delay_s: float = 0.5, max_delay_s: float = 8.0,
    ) -> dict[str, Any]:
        state = self.ensure_consumer(run_id, consumer_id=consumer_id, accepted_sequence=0)
        plan = self.reconnect_plan(
            run_id, cursor=state.accepted_sequence, attempt=state.reconnect_attempt,
            max_attempts=max_attempts, base_delay_s=base_delay_s, max_delay_s=max_delay_s,
        )
        return {**plan, "consumer_id": state.consumer_id, "accepted_sequence": state.accepted_sequence}

    def record_delivery_failure(
        self, run_id: str, *, consumer_id: str, sequence: int, error: str,
        evidence_refs: Iterable[str] = (), max_attempts: int = 3,
    ) -> dict[str, Any]:
        rid = str(run_id); cid = str(consumer_id).strip(); seq = int(sequence); max_attempts=max(1,int(max_attempts))
        state = self.ensure_consumer(rid, consumer_id=cid, accepted_sequence=0)
        if seq != state.accepted_sequence + 1:
            raise RuntimeError("delivery failure can only be recorded for the next unaccepted event")
        with self._connect() as con:
            if con.execute("SELECT 1 FROM events WHERE run_id=? AND sequence=?", (rid, seq)).fetchone() is None:
                raise RuntimeError("delivery failure target event does not exist")
            now=time.time(); con.execute("BEGIN IMMEDIATE")
            row=con.execute("SELECT * FROM delivery_failures WHERE run_id=? AND consumer_id=? AND sequence=?",(rid,cid,seq)).fetchone()
            attempts=(int(row["attempts"]) if row else 0)+1
            was_dead=bool(int(row["dead_lettered"])) if row else False
            dead=was_dead or attempts>=max_attempts
            refs=self._refs(evidence_refs)
            con.execute(
                "INSERT INTO delivery_failures(run_id,consumer_id,sequence,attempts,last_error,evidence_refs_json,dead_lettered,updated_at) VALUES(?,?,?,?,?,?,?,?) "
                "ON CONFLICT(run_id,consumer_id,sequence) DO UPDATE SET attempts=excluded.attempts,last_error=excluded.last_error,evidence_refs_json=excluded.evidence_refs_json,dead_lettered=excluded.dead_lettered,updated_at=excluded.updated_at",
                (rid,cid,seq,attempts,str(error),_json(refs),1 if dead else 0,now),
            )
            con.execute("COMMIT")
        dead_event=None
        run=self.get(rid)
        if dead and not was_dead and not run.terminal_kind:
            dead_event=self.append_event(
                rid, kind="consumer_dead_letter",
                payload={"consumer_id":cid,"target_sequence":seq,"attempts":attempts,"last_error":str(error)},
                evidence_refs=evidence_refs, idempotency_key=f"dead-letter:{cid}:{seq}",
            )
        return {
            "run_id":rid,"consumer_id":cid,"sequence":seq,"attempts":attempts,
            "dead_lettered":dead,"requires_manual_recovery":dead,
            "evidence_refs":list(self._refs(evidence_refs)),
            "terminal_run":bool(run.terminal_kind),
            "dead_letter_event":dead_event.as_mapping() if dead_event is not None else None,
        }

    def reconnect_plan(
        self, run_id: str, *, cursor: int = 0, attempt: int = 0,
        max_attempts: int = 5, base_delay_s: float = 0.5, max_delay_s: float = 8.0,
    ) -> dict[str, Any]:
        """Return a bounded reconnect decision without pretending missing events arrived."""
        cursor = int(cursor); attempt = max(0, int(attempt)); max_attempts = max(1, int(max_attempts))
        page = self.replay(run_id, cursor=cursor, limit=1)
        if page.cursor_ahead or page.gap_detected:
            return {
                "run_id": str(run_id), "retry": False, "reload_durable_state": True,
                "reason": "cursor_invalid_or_replay_gap", "after_sequence": cursor,
                "latest_sequence": page.latest_sequence, "attempt": attempt, "delay_s": 0.0,
            }
        if page.terminal:
            return {
                "run_id": str(run_id), "retry": False, "reload_durable_state": False,
                "reason": "terminal", "terminal_kind": page.terminal_kind,
                "after_sequence": cursor, "latest_sequence": page.latest_sequence,
                "attempt": attempt, "delay_s": 0.0,
            }
        if attempt >= max_attempts:
            return {
                "run_id": str(run_id), "retry": False, "reload_durable_state": True,
                "reason": "retry_budget_exhausted", "after_sequence": cursor,
                "latest_sequence": page.latest_sequence, "attempt": attempt, "delay_s": 0.0,
            }
        delay = min(float(max_delay_s), float(base_delay_s) * (2 ** attempt))
        return {
            "run_id": str(run_id), "retry": True, "reload_durable_state": False,
            "reason": "reconnect", "after_sequence": cursor, "latest_sequence": page.latest_sequence,
            "attempt": attempt, "next_attempt": attempt + 1, "delay_s": delay,
        }

    def release_lease(self, run_id: str, *, owner: str) -> DurableRun:
        rid = str(run_id); owner = str(owner).strip()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT * FROM runs WHERE run_id=?", (rid,)).fetchone()
            if row is None:
                con.execute("ROLLBACK"); raise KeyError(run_id)
            if str(row["lease_owner"]) not in {"", owner}:
                con.execute("ROLLBACK"); raise RuntimeError("lease is owned by another worker")
            con.execute("UPDATE runs SET lease_owner='',lease_expires_at=0,updated_at=? WHERE run_id=?", (time.time(), rid))
            con.execute("COMMIT")
        return self.get(rid)

    def recoverable(self, run_id: str, *, now: float | None = None) -> bool:
        run = self.get(run_id)
        if run.terminal_kind:
            return False
        at = float(now if now is not None else time.time())
        return bool(not run.lease_owner or run.lease_expires_at <= at)

    def list_runs(self, *, status: str | None = None, limit: int = 100) -> tuple[DurableRun, ...]:
        limit = max(1, min(int(limit), 1000))
        sql = "SELECT * FROM runs"
        args: list[Any] = []
        if status is not None:
            sql += " WHERE status=?"; args.append(str(status))
        sql += " ORDER BY updated_at DESC LIMIT ?"; args.append(limit)
        with self._connect() as con:
            rows = con.execute(sql, tuple(args)).fetchall()
        return tuple(self._row_to_run(x) for x in rows)
