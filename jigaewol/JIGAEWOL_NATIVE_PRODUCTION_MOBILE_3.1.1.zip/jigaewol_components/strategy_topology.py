from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .requirement_contract import RequirementCompiler, RequirementContract
from .semantic_authority import bind_semantic_authority


@dataclass(frozen=True)
class StrategyTopology:
    complexity: float
    uncertainty: float
    execution_pressure: float
    discovery_pressure: float
    divergence_pressure: float
    selected: tuple[str, ...]
    reasons: tuple[str, ...]
    divergence_tier: int = 1
    divergence_mode: str = "bounded"

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class StrategyTopologySelector:
    """Selects cognitive/search strategies from problem topology, not only magic words."""

    @staticmethod
    def select(
        message: str,
        contract: RequirementContract,
        *,
        search_required: bool,
        external_capability_required: bool,
        signed_in_browser_preferred: bool,
        deep_reasoning_required: bool | None,
        semantic_authority: Mapping[str, Any] | None = None,
    ) -> StrategyTopology:
        authority = bind_semantic_authority(message, semantic_authority)
        if authority:
            # Downstream semantic classification may widen routing requirements, never
            # lower requirements already established by an upstream/source-grounded
            # stage.  False/absent classifier output is not cancellation authority.
            search_required = bool(search_required or authority.get("search_required"))
            external_capability_required = bool(
                external_capability_required or authority.get("external_capability_required")
            )
            signed_in_browser_preferred = bool(
                signed_in_browser_preferred or authority.get("signed_in_browser_preferred")
            )
            deep_reasoning_required = bool(
                deep_reasoning_required or str(authority.get("effective_depth") or "") == "deep"
            )
        atoms = contract.atoms
        current_atoms = tuple(atoms)  # standing scope never removes user requirements from live planning
        kinds = {a.kind for a in current_atoms}
        length = len(str(message))
        constraint_count = sum(a.kind == "constraint" for a in current_atoms)
        action_count = sum(a.kind == "action" for a in current_atoms)
        question_count = sum(a.kind == "question" for a in current_atoms)
        current_text = "\n".join(a.text for a in current_atoms)
        low = current_text.casefold()
        architecture_signal = any(x in low for x in ("구조", "설계", "조합", "통합", "아키텍처", "architecture", "compose", "system"))
        preservation_signal = any(x in low for x in ("유지", "보존", "다운그레이드", "동시에", "하면서", "preserve", "without losing", "non-downgrade"))
        multi_route_signal = any(x in low for x in ("여러", "다중", "경로", "route", "body", "multi-", "federat"))
        system_tension = sum((architecture_signal, preservation_signal, multi_route_signal))
        topology_bonus = 0.28 if system_tension >= 2 else (0.12 if system_tension == 1 else 0.0)
        complexity = min(1.0, len(atoms) / 10 + len(kinds) / 8 + min(length, 2400) / 6000 + topology_bonus)
        uncertainty = min(1.0, question_count / 4 + (0.20 if "preference" in kinds else 0.0) + (0.15 if len(atoms) >= 6 else 0.0))
        authority_execution = bool(authority.get("execution_experiment_required")) if authority else False
        execution = min(
            1.0,
            action_count / 4
            + (0.60 if authority_execution else 0.0)
            + (0.45 if external_capability_required else 0.0)
            + (0.25 if signed_in_browser_preferred else 0.0),
        )
        discovery = min(1.0, (0.55 if search_required else 0.0) + uncertainty * 0.45 + (0.2 if signed_in_browser_preferred else 0.0))

        # Scores remain diagnostics only. They never grant permission to think,
        # search, execute, or diverge. Selection follows explicit task structure.
        open_signal = any(x in low for x in ("다른 방식", "새 방법", "가정", "전제", "반례", "창의", "alternative", "counterexample", "reframe", "invent"))
        authority_representation = bool(authority.get("representation_search_required")) if authority else False
        authority_open_horizon = bool(
            authority.get("frontier_exploration_required") or authority.get("possibility_space_open")
        ) if authority else False
        comparison_signal = authority_representation or authority_open_horizon or question_count > 1 or constraint_count >= 2 or system_tension >= 2 or open_signal
        divergence = float(bool(comparison_signal))
        asks_for_something = bool(current_atoms) or any(marker in low for marker in RequirementCompiler.ACTION_MARKERS)
        divergence_tier = 0 if not asks_for_something else (3 if authority_open_horizon else (2 if comparison_signal else 1))
        divergence_mode = "open_ended" if authority_open_horizon else "bounded"

        selected: list[str] = ["direct_solution"]
        reasons: list[str] = []
        if comparison_signal or (bool(deep_reasoning_required) and action_count > 0):
            selected.append("representation_tournament")
            reasons.append(
                "deep_action_keeps_representation_search_alive"
                if bool(deep_reasoning_required) and action_count > 0 and not comparison_signal
                else "task_structure_supports_materially_different_representations"
            )
        if constraint_count >= 2:
            selected.append("constraint_satisfaction_pass")
            reasons.append("simultaneous_constraints")
        if search_required or signed_in_browser_preferred:
            selected.append("research_mesh")
            reasons.append("current_turn_requests_information_discovery")
        executable_markers = ("실행", "구현", "테스트", "설치", "연결", "run", "execute", "build", "implement")
        meta_execution_cues = ("경로", "단어", "개념", "의미", "여부", "분석", "설명", "왜", "문구", "표현")
        execution_action = any(
            a.kind == "action"
            and any(marker in a.text.casefold() for marker in executable_markers)
            and not any(cue in a.text.casefold() for cue in meta_execution_cues)
            for a in atoms
        )
        execution_signal = (
            bool(authority.get("execution_experiment_required"))
            if authority
            else (external_capability_required or action_count >= 2 or execution_action)
        )
        if execution_signal:
            selected.append("execution_experiment_loop")
            reasons.append("current_turn_benefits_from_observed_execution")
        if comparison_signal and system_tension >= 2:
            selected.append("divergent_worlds")
        if len(atoms) >= 2:
            selected.append("requirement_coverage_gate")
        return StrategyTopology(
            complexity, uncertainty, execution, discovery, divergence,
            tuple(dict.fromkeys(selected)), tuple(reasons), divergence_tier, divergence_mode
        )
