from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass, replace
from typing import Any, Iterable, Mapping


@dataclass(frozen=True)
class PossibilityPlan:
    objective: str
    phases: tuple[str, ...]
    phase_graph: dict[str, tuple[str, ...]]
    active_phase: str
    missing_traits: tuple[str, ...]
    recurring_signals: tuple[str, ...]
    architecture_replacement_pressure: int
    capability_expansion_pressure: int
    representation_expansion_pressure: int
    truth_posture: str = "evidence_labeled"
    completion_posture: str = "material_user_outcome"

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


PHASES = (
    "reinterpret_representation",
    "reuse_current_capabilities",
    "compose_capabilities",
    "discover_external_body",
    "acquire_or_build_capability",
    "change_execution_substrate",
    "rewrite_obstructing_runtime_structure",
)

# Compatibility order remains available, but scheduling is now represented as an
# extensible graph. New phase nodes can be added without changing an enum.
DEFAULT_PHASE_GRAPH: dict[str, tuple[str, ...]] = {
    "reinterpret_representation": ("reuse_current_capabilities", "compose_capabilities"),
    "reuse_current_capabilities": ("compose_capabilities", "discover_external_body"),
    "compose_capabilities": ("discover_external_body", "acquire_or_build_capability"),
    "discover_external_body": ("acquire_or_build_capability", "change_execution_substrate"),
    "acquire_or_build_capability": ("change_execution_substrate", "rewrite_obstructing_runtime_structure"),
    "change_execution_substrate": ("rewrite_obstructing_runtime_structure",),
    "rewrite_obstructing_runtime_structure": (),
}


class PossibilityEngine:
    """Deterministic expansion pressure for unresolved user work.

    The engine never certifies a speculative route as successful. Its job is to keep
    producing the next class of route while the truth ledger independently records what
    was actually observed.
    """

    @classmethod
    def compile(
        cls,
        objective: str,
        *,
        missing_traits: Iterable[str] = (),
        recurring_signals: Iterable[Mapping[str, Any] | str] = (),
        representation_requested: bool = False,
    ) -> PossibilityPlan:
        missing = tuple(dict.fromkeys(str(x) for x in missing_traits if str(x).strip()))
        recurring = []
        for row in recurring_signals:
            if isinstance(row, Mapping):
                value = row.get("family") or row.get("invariant_id") or row.get("trigger_excerpt") or row
            else:
                value = row
            text = str(value).strip()
            if text:
                recurring.append(text)
        recurring_t = tuple(dict.fromkeys(recurring))
        representation_pressure = 1 + int(bool(representation_requested)) + min(3, len(recurring_t))
        capability_pressure = len(missing) + min(3, len(recurring_t))
        architecture_pressure = min(9, len(recurring_t) * 2 + int(bool(missing)))
        active = "reinterpret_representation" if representation_pressure else "reuse_current_capabilities"
        return PossibilityPlan(
            objective=str(objective),
            phases=PHASES,
            phase_graph=dict(DEFAULT_PHASE_GRAPH),
            active_phase=active,
            missing_traits=missing,
            recurring_signals=recurring_t,
            architecture_replacement_pressure=architecture_pressure,
            capability_expansion_pressure=capability_pressure,
            representation_expansion_pressure=representation_pressure,
        )


    @staticmethod
    def register_phase(
        plan: Mapping[str, Any] | PossibilityPlan,
        *,
        phase_id: str,
        after: Iterable[str] = (),
        before: Iterable[str] = (),
        make_active: bool = False,
    ) -> dict[str, Any]:
        """Extend the live possibility graph without editing a closed phase enum."""
        row = plan.as_mapping() if isinstance(plan, PossibilityPlan) else deepcopy(dict(plan or {}))
        phase = str(phase_id).strip()
        if not phase:
            raise ValueError("phase_id is required")
        phases = list(row.get("phases") or PHASES)
        if phase not in phases:
            phases.append(phase)
        graph = {str(k): tuple(map(str, v or ())) for k, v in dict(row.get("phase_graph") or DEFAULT_PHASE_GRAPH).items()}
        graph.setdefault(phase, ())
        for parent in tuple(map(str, after)):
            graph.setdefault(parent, ())
            graph[parent] = tuple(dict.fromkeys((*graph[parent], phase)))
        for child in tuple(map(str, before)):
            graph[phase] = tuple(dict.fromkeys((*graph.get(phase, ()), child)))
            graph.setdefault(child, ())
        row["phases"] = tuple(phases)
        row["phase_graph"] = graph
        if make_active:
            row["active_phase"] = phase
        row["graph_extended"] = True
        row["registered_phase"] = phase
        return row

    @staticmethod
    def raise_after_route_stall(plan: Mapping[str, Any] | PossibilityPlan, *, route_id: str = "") -> dict[str, Any]:
        row = plan.as_mapping() if isinstance(plan, PossibilityPlan) else deepcopy(dict(plan or {}))
        phases = tuple(row.get("phases") or PHASES)
        graph = dict(row.get("phase_graph") or DEFAULT_PHASE_GRAPH)
        active = str(row.get("active_phase") or phases[0])
        successors = tuple(graph.get(active) or ())
        if successors:
            row["active_phase"] = str(successors[0])
        else:
            try:
                index = phases.index(active)
            except ValueError:
                index = 0
            row["active_phase"] = phases[min(index + 1, len(phases) - 1)]
        row["phase_graph"] = graph
        row["architecture_replacement_pressure"] = min(9, int(row.get("architecture_replacement_pressure") or 0) + 1)
        row["capability_expansion_pressure"] = int(row.get("capability_expansion_pressure") or 0) + 1
        row["last_stalled_route"] = str(route_id or "")
        row["next_move"] = row["active_phase"]
        return row
