from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping


def _sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class OperatorSpec:
    operator_id: str
    schema: dict[str, Any]
    adapter_ref: str
    representation_ref: str
    lineage_refs: tuple[str, ...] = ()
    adapter_program: dict[str, Any] | None = None

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class OperatorBuilder:
    """Registry for arbitrary task-local operator schemas and executable adapters."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "operators.json"
        self._adapters: dict[str, Callable[[Mapping[str, Any]], Any]] = {}
        if not self.path.exists():
            self.path.write_text("{}\n", encoding="utf-8")

    def propose(
        self,
        *,
        representation_ref: str,
        purpose: str,
        schema: Mapping[str, Any] | None = None,
        adapter_program: Mapping[str, Any] | None = None,
    ) -> OperatorSpec:
        schema_row = dict(schema or {
            "input": {"state": "mapping", "goal_refs": "list[str]"},
            "output": {"state_delta": "mapping", "evidence_refs": "list[str]"},
            "purpose": str(purpose),
            "open_schema": True,
        })
        oid = "operator_" + _sha({"rep": representation_ref, "purpose": purpose, "schema": schema_row, "adapter_program": adapter_program})[:20]
        program = dict(adapter_program or {
            "kind": "generated_operation_sequence_v2",
            "operations": (
                {"op": "set", "path": "operator_applied", "value": oid},
                {"op": "set", "path": "representation_ref", "value": str(representation_ref)},
            ),
        })
        program.setdefault("operator_id", oid)
        program.setdefault("representation_ref", str(representation_ref))
        return OperatorSpec(
            oid, schema_row, f"adapter:{oid}", str(representation_ref),
            (str(representation_ref),), program,
        )

    def register_schema(self, spec: OperatorSpec, adapter: Callable[[Mapping[str, Any]], Any] | None = None) -> OperatorSpec:
        data = self.snapshot()
        data[spec.operator_id] = spec.as_mapping()
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, default=str) + "\n", encoding="utf-8")
        tmp.replace(self.path)
        if adapter is not None:
            self._adapters[spec.operator_id] = adapter
        return spec

    @staticmethod
    def _execute_operations(payload: Mapping[str, Any], operations: tuple[Mapping[str, Any], ...] | list[Mapping[str, Any]]) -> dict[str, Any]:
        state = dict(payload)
        for op0 in operations:
            op = dict(op0)
            kind = str(op.get("op") or "")
            path = str(op.get("path") or "")
            if kind == "set" and path:
                state[path] = op.get("value")
            elif kind == "merge" and path:
                current = dict(state.get(path) or {})
                current.update(dict(op.get("value") or {}))
                state[path] = current
            elif kind == "append" and path:
                current = list(state.get(path) or [])
                current.append(op.get("value"))
                state[path] = current
            elif kind == "copy" and path:
                source_path = str(op.get("from") or "")
                state[path] = state.get(source_path)
            else:
                raise RuntimeError(f"unsupported generated operator instruction: {kind}:{path}")
        return state

    def materialize(self, operator_id: str, payload: Mapping[str, Any]) -> Any:
        registry = self.snapshot()
        if operator_id not in registry:
            raise KeyError(f"unknown operator: {operator_id}")
        adapter = self._adapters.get(operator_id)
        if adapter is not None:
            return adapter(dict(payload))
        stored = dict(registry[operator_id])
        program = dict(stored.get("adapter_program") or {})
        kind = str(program.get("kind") or "")
        if kind == "declarative_state_transform":
            state = dict(payload)
            state.update(dict(program.get("append") or {}))
        elif kind == "generated_operation_sequence_v2":
            state = self._execute_operations(payload, list(program.get("operations") or ()))
        else:
            raise RuntimeError(f"operator has no executable adapter program: {operator_id}")
        return {
            "operator_id": operator_id,
            "representation_ref": str(stored.get("representation_ref") or ""),
            "state_delta": state,
            "evidence_refs": tuple(map(str, stored.get("lineage_refs") or ())),
            "adapter": "persisted_generated_adapter",
        }

    def snapshot(self) -> dict[str, Any]:
        failure_path = self.root / "operator_registry_failures.jsonl"

        def record_failure(kind: str, error: BaseException, *, quarantine: Path | None = None) -> None:
            row = {
                "kind": str(kind),
                "source": str(self.path),
                "error_type": type(error).__name__,
                "error": str(error),
                "quarantine": str(quarantine or ""),
                "created_at": time.time(),
            }
            with failure_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")

        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise TypeError("operator registry must be a JSON object")
            return data
        except OSError as exc:
            record_failure("operator_registry_read_failed", exc)
            raise RuntimeError(f"operator registry read failed: {exc}") from exc
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            quarantine = self.path.with_name(
                f"{self.path.stem}.corrupt.{time.time_ns()}{self.path.suffix}"
            )
            try:
                self.path.replace(quarantine)
            except OSError as move_error:
                record_failure("operator_registry_quarantine_failed", move_error)
                quarantine = self.path
            record_failure("operator_registry_corrupt", exc, quarantine=quarantine)
            raise RuntimeError(f"operator registry corrupt: {exc}") from exc
