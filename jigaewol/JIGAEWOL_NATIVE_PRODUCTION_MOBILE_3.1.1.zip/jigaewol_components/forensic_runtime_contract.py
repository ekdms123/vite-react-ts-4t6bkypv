from __future__ import annotations

"""Machine-readable recurrence contract distilled from the full Jigaewol forensic audit.

The list is intentionally explicit: diagnoses are not considered "fixed" merely
because a document remembers them.  Each item says whether the current runtime treats
it as a hard invariant, a runtime diagnostic, or a host-boundary debt that must never
be misreported as solved.
"""

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from jigaewol_components.unified_user_intent import reference_for_sha


@dataclass(frozen=True, slots=True)
class ForensicInvariant:
    code: str
    category: str
    mode: str
    rule: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class ForensicRuntimeContract:
    # Hard invariants only count as executable when a deterministic hot-path gate owns
    # the decision.  The map is deliberately explicit so a prose rule cannot masquerade
    # as enforcement merely because it is present in context.
    EXECUTABLE_ENFORCEMENT: dict[str, str] = {
        "F08": "authority_guard.source_continuation_evidence",
        "F09": "open_ended_execution.source_activated_frontier",
        "F10": "authority_guard.source_bound_objective",
        "F11": "authority_guard.require_exact_destination",
        "F12": "authority_guard.source_bound_objective",
        "F13": "authority_guard.source_bound_objective",
        "F14": "authority_guard.source_bound_objective",
        "F15": "authority_guard.source_bound_objective",
        "F16": "possibility_pressure.observed_boundary_gate",
        "F17": "exploration_escalation.non_closing_scheduler_state",
        "F27": "canonical_finalizer.objective_and_receipt_gate",
        "F28": "execution_receipt_ledger.observed_effect_gate",
        "F39": "runtime.prepare_finalization.coverage_completion_split",
        "F43": "causal_loop.strong_canonical_finalizer",
        "F44": "authority_guard.source_continuation_evidence",
    }

    INVARIANTS: tuple[ForensicInvariant, ...] = (
        ForensicInvariant("F01", "directive", "hard", "exact destination hash is independently rechecked"),
        ForensicInvariant("F02", "directive", "hard", "canonical requirement occurrences are conserved or explicitly deferred/superseded by user"),
        ForensicInvariant("F03", "directive", "hard", "duplicate wording remains distinguishable at proof-obligation occurrence level"),
        ForensicInvariant("F04", "semantics", "hard", "historical reports are not immediate actuator commands"),
        ForensicInvariant("F05", "semantics", "hard", "quoted/reference material is not immediate actuator command"),
        ForensicInvariant("F06", "semantics", "hard", "hypothetical examples are not immediate actuator commands"),
        ForensicInvariant("F07", "semantics", "hard", "standing user policy remains action-relevant without deleting raw wording"),
        ForensicInvariant("F08", "continuity", "hard", "bare continuation binds raw message and restored semantic objective as separate authorities"),
        ForensicInvariant("F09", "continuity", "hard", "continuation may resume only the active unfinished workstream"),
        ForensicInvariant("F10", "goal", "hard", "project north star may augment but never replace current exact directive"),
        ForensicInvariant("F11", "goal", "hard", "effective objective is a projection and cannot rewrite canonical destination"),
        ForensicInvariant("F12", "goal", "hard", "route failure cannot shrink the goal"),
        ForensicInvariant("F13", "goal", "hard", "verifier output cannot rewrite destination"),
        ForensicInvariant("F14", "goal", "hard", "resource budget cannot rewrite destination"),
        ForensicInvariant("F15", "goal", "hard", "model capability estimates are not semantic goal ceilings"),
        ForensicInvariant("F16", "closure", "hard", "global impossibility claims require evidence rather than untried-route absence"),
        ForensicInvariant("F17", "closure", "hard", "open possibility state stays open until evidence/user closure"),
        ForensicInvariant("F18", "cognition", "hard", "active representation tournament materializes a non-baseline representation"),
        ForensicInvariant("F19", "cognition", "hard", "representation worlds are causally exposed to canonical final generation"),
        ForensicInvariant("F20", "cognition", "hard", "multi-world portfolio/synthesis is on the canonical path when activated"),
        ForensicInvariant("F21", "cognition", "hard", "semantic verification defect can trigger bounded revision rather than terminal creative death"),
        ForensicInvariant("F22", "cognition", "hard", "speculative stepping stones may survive without current-turn promotion"),
        ForensicInvariant("F23", "cognition", "hard", "strange/exaptive routes are reserve possibilities rather than score-zero deletion"),
        ForensicInvariant("F24", "cognition", "hard", "ranking/scheduling is not ontology deletion"),
        ForensicInvariant("F25", "body", "diagnostic", "host surface binding debt is explicit"),
        ForensicInvariant("F26", "body", "diagnostic", "installed but uninjected body is not declared unavailable"),
        ForensicInvariant("F27", "execution", "hard", "actual execution claims require observed execution receipt"),
        ForensicInvariant("F28", "execution", "hard", "source inspection/callability/plan are not execution"),
        ForensicInvariant("F29", "acquisition", "diagnostic", "provider connection requirements are recorded when observed and remain descriptive execution context"),
        ForensicInvariant("F30", "acquisition", "diagnostic", "source inspection records provenance and execution facts but does not erase the user capability goal"),
        ForensicInvariant("F31", "acquisition", "diagnostic", "local isolated execution does not overclaim kernel/network/microVM isolation"),
        ForensicInvariant("F32", "perception", "hard", "signed-in perception is distinct from public web search"),
        ForensicInvariant("F33", "search", "hard", "native slang/meme/community language remains legal query material"),
        ForensicInvariant("F34", "search", "diagnostic", "creator/hunt frontier persists across blocked or incomplete lanes"),
        ForensicInvariant("F35", "search", "hard", "blocked lane becomes open debt rather than silent exclusion"),
        ForensicInvariant("F36", "privacy", "hard", "runtime-owned privacy redaction is recursive across nested host payloads"),
        ForensicInvariant("F37", "privacy", "diagnostic", "runtime privacy claims are limited to runtime-owned persistence and transport; host visibility is never falsely described"),
        ForensicInvariant("F38", "privacy", "hard", "avoidably duplicated plaintext is minimized in audit/host transport"),
        ForensicInvariant("F39", "coverage", "hard", "atom accounting is separate from semantic response coverage"),
        ForensicInvariant("F40", "optimizer", "hard", "intent preservation is feasibility condition, not a tradeable score"),
        ForensicInvariant("F41", "optimizer", "hard", "proof defect preserves runtime_optimizer role and useful gains"),
        ForensicInvariant("F42", "optimizer", "hard", "proof mutation/non-vacuity checks reject decorative witnesses"),
        ForensicInvariant("F43", "lifecycle", "hard", "canonical finalizer chain records predecessor continuity"),
        ForensicInvariant("F44", "lifecycle", "hard", "new exact message preserves unfinished user work unless cancellation is explicit"),
        ForensicInvariant("F45", "lifecycle", "host_boundary_debt", "platform-native pre-message/final-response hooks are not owned by ZIP; outer harness must invoke gateway/finalizer"),
        ForensicInvariant("F46", "performance", "hard", "compact handoff uses bounded projections rather than duplicating canonical bodies"),
        ForensicInvariant("F47", "performance", "hard", "context compaction avoids per-row full JSON reserialization quadratic behavior"),
        ForensicInvariant("F48", "audit", "hard", "open-world source audit covers jigaewol_runtime, jigaewol_core, and jigaewol_components"),
        ForensicInvariant("F49", "performance", "hard", "final generation receives deduplicated requirement/cognition projections while canonical state remains lossless"),
        ForensicInvariant("F50", "cognition", "hard", "ephemeral axiom-breaking worlds are causally injected into canonical GenerationRequest when activated"),
    )

    @classmethod
    def mapping(cls, *, semantic_authority: Mapping[str, Any] | None = None, ephemeral_universe: Mapping[str, Any] | None = None) -> dict[str, Any]:
        rows = tuple(x.as_mapping() for x in cls.INVARIANTS)
        encoded = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        authority = dict(semantic_authority or {})
        universe = dict(ephemeral_universe or {})
        authority_sha = str(authority.get("message_sha256") or authority.get("exact_user_message_sha256") or "")
        unified_binding = None
        if len(authority_sha) == 64:
            unified_binding = reference_for_sha(
                authority_sha, component="forensic", validation_passed=True,
                validation_scope="forensic_invariant_evaluation",
                details={"invariant_count": len(rows)},
            ).as_mapping()
        return {
            "schema": "jigaewol_forensic_runtime_contract_v1",
            "invariant_count": len(rows),
            "invariants": rows,
            "invariants_sha256": hashlib.sha256(encoded.encode("utf-8")).hexdigest(),
            "hard_invariant_count": sum(x.mode == "hard" for x in cls.INVARIANTS),
            "diagnostic_or_host_boundary_count": sum(x.mode != "hard" for x in cls.INVARIANTS),
            "semantic_scope_bound": bool(authority.get("discourse_scope")),
            "ephemeral_universe_bound": bool(universe.get("active")),
            "diagnosis_memory_is_not_enforcement": True,
            "executable_enforcement": dict(cls.EXECUTABLE_ENFORCEMENT),
            "executable_enforcement_codes": tuple(sorted(cls.EXECUTABLE_ENFORCEMENT)),
            "executable_enforcement_count": len(cls.EXECUTABLE_ENFORCEMENT),
            "unenforced_hard_invariants_may_not_be_claimed_enforced": True,
            "contract_must_remain_on_hot_path": True,
            "host_boundary_debt_must_not_be_reported_as_solved": True,
            "unified_intent": unified_binding,
            "single_source_of_truth": "exact_user_message_bytes",
        }
