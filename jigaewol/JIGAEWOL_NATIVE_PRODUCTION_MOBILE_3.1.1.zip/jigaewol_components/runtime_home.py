from __future__ import annotations

import os
import re
import json
import tempfile
from pathlib import Path


_PROCESS_HOME: Path | None = None


def _safe(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value)).strip("._") or "runtime"


def resolve_runtime_home(*, runtime_identity: str = "JIGAEWOL", explicit_root: str | Path | None = None) -> Path:
    """Resolve an explicitly selected home, or temporary state for this process.

    explicit_root wins, then JIGAEWOL_RUNTIME_HOME. With neither supplied, no
    previous chat's host directory is loaded. Chat entrypoints select their own
    state home so subsequent processes in that chat can retain observations.
    """
    global _PROCESS_HOME
    if explicit_root is not None:
        root = Path(explicit_root).expanduser().resolve()
    elif os.environ.get("JIGAEWOL_RUNTIME_HOME"):
        root = Path(os.environ["JIGAEWOL_RUNTIME_HOME"]).expanduser().resolve() / _safe(runtime_identity)
    else:
        if _PROCESS_HOME is None:
            _PROCESS_HOME = Path(tempfile.mkdtemp(prefix="jigaewol-process-state-"))
        root = _PROCESS_HOME / _safe(runtime_identity)
    root.mkdir(parents=True, exist_ok=True)
    return root


def resolve_chat_runtime_home(
    state_root: str | Path, *, runtime_identity: str = "JIGAEWOL",
    runtime_home: str | Path | None = None,
) -> Path:
    """Keep chat receipts in its chosen state; shared homes require explicit selection.

    The optional home is recorded in that state so later CLI processes use the
    same deliberately selected home. An inherited environment variable alone
    cannot import another chat's host observations into this state.
    """
    state = Path(state_root).expanduser().resolve()
    binding = state / "runtime_home_binding.json"
    if runtime_home is not None:
        base = Path(runtime_home).expanduser().resolve()
        state.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix='.runtime-home-', dir=str(state))
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                json.dump({"runtime_home": str(base), "selection": "explicit"}, handle)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, binding)
        finally:
            Path(temporary).unlink(missing_ok=True)
    elif binding.is_file():
        saved = json.loads(binding.read_text(encoding="utf-8"))
        if saved.get("selection") != "explicit" or not saved.get("runtime_home"):
            raise ValueError("invalid explicit chat runtime-home binding")
        base = Path(saved["runtime_home"]).expanduser().resolve()
    else:
        base = state / "home"
    return resolve_runtime_home(runtime_identity=runtime_identity, explicit_root=base / _safe(runtime_identity))
