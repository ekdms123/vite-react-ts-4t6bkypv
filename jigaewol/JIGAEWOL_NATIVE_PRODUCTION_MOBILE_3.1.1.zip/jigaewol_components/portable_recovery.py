from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Mapping


FORMAT = "jigaewol_portable_recovery_v1"
CAPSULE_NAME = "PORTABLE_RECOVERY_CAPSULE.json"


def _sha(data: Any) -> str:
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _summarize_runs(state_root: Path) -> list[dict[str, Any]]:
    """Best-effort run summary; never copies raw event payloads into a release."""
    db = state_root / "durable_runs" / "runs.sqlite3"
    if not db.is_file():
        return []
    import sqlite3

    out: list[dict[str, Any]] = []
    con = None
    try:
        con = sqlite3.connect(str(db))
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT r.run_id, r.worker_ref, r.status, r.terminal_kind, r.lease_owner, r.lease_expires_at, "
            "COALESCE((SELECT MAX(e.sequence) FROM events e WHERE e.run_id=r.run_id), 0) AS latest_sequence "
            "FROM runs r ORDER BY r.updated_at DESC LIMIT 8"
        ).fetchall()
        for row in rows:
            d = dict(row)
            out.append({
                "run_id": str(d.get("run_id") or ""),
                "worker_ref": str(d.get("worker_ref") or ""),
                "status": str(d.get("status") or ""),
                "terminal_kind": str(d.get("terminal_kind") or ""),
                "latest_sequence": max(0, int(d.get("latest_sequence") or 0)),
                "lease_owner": str(d.get("lease_owner") or ""),
                "lease_expires_at": float(d.get("lease_expires_at") or 0.0),
            })
    except (sqlite3.Error, OSError, TypeError, ValueError) as exc:
        return [{
            "run_id": "", "worker_ref": "portable_recovery",
            "status": "RECOVERY_SUMMARY_READ_FAILED", "terminal_kind": type(exc).__name__,
            "latest_sequence": 0, "lease_owner": "", "lease_expires_at": 0.0,
            "failure_detail": str(exc)[:500],
        }]
    finally:
        if con is not None:
            try:
                con.close()
            except sqlite3.Error:
                # Closing a failed read-only summary connection cannot affect recovery state.
                pass
    return out


def _durable_cursor(rows: list[dict[str, Any]]) -> int:
    cursor = 0
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        try:
            cursor = max(cursor, int(row.get("latest_sequence") or 0))
        except (TypeError, ValueError):
            continue
    return cursor


def _merge_durable_runs(current: list[dict[str, Any]], inherited: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Merge sanitized run cursors without treating an absent local DB as rollback evidence."""
    merged: dict[str, dict[str, Any]] = {}
    anonymous: list[dict[str, Any]] = []
    for source, inherited_flag in ((inherited, True), (current, False)):
        for raw in source:
            if not isinstance(raw, Mapping):
                continue
            row = dict(raw)
            run_id = str(row.get("run_id") or "")
            if not run_id:
                row["inherited_recovery_hint"] = inherited_flag
                anonymous.append(row)
                continue
            existing = merged.get(run_id)
            if existing is None or int(row.get("latest_sequence") or 0) >= int(existing.get("latest_sequence") or 0):
                row["inherited_recovery_hint"] = inherited_flag
                merged[run_id] = row
    return sorted(merged.values(), key=lambda row: (str(row.get("run_id") or ""), int(row.get("latest_sequence") or 0))) + anonymous


def _summarize_agent_cli(runtime_home: Path) -> dict[str, Any]:
    candidates = [
        runtime_home / "agent_cli_registry" / "probes.json",
        runtime_home / "agent_cli" / "probes.json",
        runtime_home / "agent_cli" / "probe_ledger.json",
        runtime_home / "agent_cli" / "catalog.json",
    ]
    for path in candidates:
        data = _read_json(path)
        if data is not None:
            return {"source": path.name, "digest": _sha(data), "present": True}
    return {"present": False}


def _summarize_host_truth(runtime_home: Path) -> dict[str, Any]:
    for path in [
        runtime_home / "host_surface" / "action_truth.jsonl",
        runtime_home / "host_action_truth" / "observations.jsonl",
        runtime_home / "host_action_truth" / "ledger.json",
    ]:
        if not path.is_file():
            continue
        raw = path.read_bytes()
        return {
            "present": True,
            "source": path.name,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
        }
    return {"present": False}


def _summarize_agent_events(runtime_home: Path) -> dict[str, Any]:
    path = runtime_home / "agent_events" / "events.jsonl"
    if not path.is_file():
        return {"present": False}
    count = 0; sessions: set[str] = set(); providers: set[str] = set(); terminal = 0
    try:
        for raw in path.read_text(encoding="utf-8").splitlines():
            if not raw.strip(): continue
            row=json.loads(raw); count += 1
            if row.get("session_id"): sessions.add(str(row["session_id"]))
            if row.get("provider_id"): providers.add(str(row["provider_id"]))
            if row.get("kind") in {"turn_end","error"}: terminal += 1
    except Exception:
        return {"present": True, "unreadable": True}
    return {"present": True, "event_count": count, "session_count": len(sessions), "providers": sorted(providers), "terminal_event_count": terminal, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def _summarize_agent_worktrees(runtime_home: Path) -> dict[str, Any]:
    path = runtime_home / "agent_worktrees" / "worktrees.json"
    data = _read_json(path)
    if not isinstance(data, dict):
        return {"present": False}
    records = data.get("records") if isinstance(data.get("records"), dict) else {}
    states: dict[str, int] = {}
    for row in records.values():
        if isinstance(row, dict):
            key=str(row.get("state") or "unknown"); states[key]=states.get(key,0)+1
    return {"present": True, "record_count": len(records), "state_counts": states, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def build_capsule(
    *,
    artifact_root: str | Path,
    state_root: str | Path,
    runtime_home: str | Path | None = None,
    checkpoint_name: str = "",
    checkpoint_zip_sha256: str = "",
    ledger_ref: str = "",
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    artifact_root = Path(artifact_root).resolve()
    state_root = Path(state_root).resolve()
    runtime_home_path = Path(runtime_home).resolve() if runtime_home else state_root
    artifact = _read_json(artifact_root / "CANONICAL_ARTIFACT.json") or {}
    epoch = _read_json(state_root / "state_epoch.json") or {}
    run_state_root = state_root if (state_root / "durable_runs" / "runs.sqlite3").is_file() else runtime_home_path
    live_durable_runs = _summarize_runs(run_state_root)
    inherited_capsule_sha256 = ""
    inherited_durable_runs: list[dict[str, Any]] = []
    try:
        active = resolve_active_capsule(state_root, repair_pointer=False)
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        active = {"present": False}
    if active.get("present"):
        active_capsule = active.get("capsule") if isinstance(active.get("capsule"), Mapping) else {}
        prior_rows = active_capsule.get("durable_runs") if isinstance(active_capsule.get("durable_runs"), list) else []
        if _durable_cursor(prior_rows) > _durable_cursor(live_durable_runs):
            inherited_durable_runs = [dict(row) for row in prior_rows if isinstance(row, Mapping)]
            inherited_capsule_sha256 = str(active_capsule.get("capsule_sha256") or "")
    durable_runs = _merge_durable_runs(live_durable_runs, inherited_durable_runs)
    merged_extra = dict(extra or {})
    if inherited_capsule_sha256:
        merged_extra.update({
            "durable_run_cursor_inherited": True,
            "inherited_recovery_capsule_sha256": inherited_capsule_sha256,
            "inherited_cursor": _durable_cursor(inherited_durable_runs),
            "live_cursor": _durable_cursor(live_durable_runs),
        })
    capsule = {
        "format": FORMAT,
        "generated_at": time.time(),
        "artifact_content_set_sha256": str(
            artifact.get("active_content_set_sha256") or artifact.get("content_set_sha256") or ""
        ),
        "source_state_epoch": {
            "epoch_id": str(epoch.get("epoch_id") or ""),
            "continuity_state": str(epoch.get("continuity_state") or ""),
        },
        "checkpoint": {
            "name": str(checkpoint_name),
            "zip_sha256": str(checkpoint_zip_sha256),
        },
        "durable_runs": durable_runs,
        "host_action_truth": _summarize_host_truth(runtime_home_path),
        "agent_cli_probe": _summarize_agent_cli(runtime_home_path),
        "agent_events": _summarize_agent_events(runtime_home_path),
        "agent_worktrees": _summarize_agent_worktrees(runtime_home_path),
        "ledger_ref": str(ledger_ref),
        "claim_boundary": (
            "portable capsule is a sanitized continuity hint, not a replacement for raw mutable state, "
            "credentials, transcripts, or execution receipts"
        ),
        "extra": merged_extra,
    }
    capsule["capsule_sha256"] = _sha({k: v for k, v in capsule.items() if k != "capsule_sha256"})
    return capsule


def write_capsule(path: str | Path, capsule: Mapping[str, Any]) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(dict(capsule), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)
    return path


def validate_capsule(capsule: Mapping[str, Any]) -> dict[str, Any]:
    if str(capsule.get("format") or "") != FORMAT:
        raise ValueError("portable recovery capsule format mismatch")
    expected = str(capsule.get("capsule_sha256") or "")
    actual = _sha({k: v for k, v in capsule.items() if k != "capsule_sha256"})
    if not expected or expected != actual:
        raise ValueError("portable recovery capsule digest mismatch")
    return dict(capsule)


def _freshness(capsule: Mapping[str, Any]) -> dict[str, Any]:
    latest_sequence = 0
    for row in capsule.get("durable_runs") or ():
        if isinstance(row, Mapping):
            try:
                latest_sequence = max(latest_sequence, int(row.get("latest_sequence") or 0))
            except (TypeError, ValueError):
                pass
    try:
        generated_at = float(capsule.get("generated_at") or 0.0)
    except (TypeError, ValueError):
        generated_at = 0.0
    checkpoint = capsule.get("checkpoint") if isinstance(capsule.get("checkpoint"), Mapping) else {}
    return {
        "latest_sequence": latest_sequence,
        "generated_at": generated_at,
        "checkpoint_name": str(checkpoint.get("name") or ""),
        "artifact_content_set_sha256": str(capsule.get("artifact_content_set_sha256") or ""),
    }


def _freshness_key(capsule: Mapping[str, Any]) -> tuple[int, float, str, str]:
    row = _freshness(capsule)
    return (
        int(row["latest_sequence"]),
        float(row["generated_at"]),
        str(row["checkpoint_name"]),
        str(row["artifact_content_set_sha256"]),
    )


def _record_digest(record: Mapping[str, Any], digest_field: str) -> str:
    return _sha({k: v for k, v in record.items() if k != digest_field})


def _validate_record(record: Mapping[str, Any], *, fmt: str, digest_field: str) -> dict[str, Any]:
    if str(record.get("format") or "") != fmt:
        raise ValueError(f"{fmt} format mismatch")
    expected = str(record.get(digest_field) or "")
    actual = _record_digest(record, digest_field)
    if not expected or expected != actual:
        raise ValueError(f"{fmt} digest mismatch")
    return dict(record)


def _recovery_root(state_root: Path) -> Path:
    return state_root / "recovery"


def _record_recovery_resolution_failure(state_root: Path, *, stage: str, error: BaseException) -> None:
    """Persist recovery-resolution failures without swallowing them into silent fallback."""
    root = _recovery_root(Path(state_root).resolve())
    root.mkdir(parents=True, exist_ok=True)
    path = root / "resolution_failures.jsonl"
    row = {
        "at": time.time(),
        "stage": str(stage),
        "error_type": type(error).__name__,
        "error": str(error)[:500],
    }
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def _capsule_store_path(state_root: Path, digest: str) -> Path:
    return _recovery_root(state_root) / "capsules" / f"{digest}.json"


def _promotion_dir(state_root: Path) -> Path:
    return _recovery_root(state_root) / "promotions"


def _pointer_path(state_root: Path) -> Path:
    return _recovery_root(state_root) / "active_recovery_pointer.json"


def _atomic_json(path: Path, data: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(dict(data), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def _archive_capsule(state_root: Path, capsule: Mapping[str, Any], source_bytes: bytes | None = None) -> Path:
    validated = validate_capsule(capsule)
    digest = str(validated["capsule_sha256"])
    path = _capsule_store_path(state_root, digest)
    if path.exists():
        existing = validate_capsule(_read_json(path) or {})
        if str(existing.get("capsule_sha256") or "") != digest:
            raise ValueError("recovery capsule store digest collision")
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    if source_bytes is not None:
        try:
            source_obj = validate_capsule(json.loads(source_bytes.decode("utf-8")))
        except Exception:
            source_obj = None
        if source_obj and str(source_obj.get("capsule_sha256") or "") == digest:
            tmp = path.with_suffix(".tmp")
            tmp.write_bytes(source_bytes)
            tmp.replace(path)
            return path
    return write_capsule(path, validated)


def _promotion_files(state_root: Path) -> list[Path]:
    root = _promotion_dir(state_root)
    if not root.is_dir():
        return []
    return sorted(
        (p for p in root.glob("*.json") if p.is_file()),
        key=lambda p: p.name,
    )


def _valid_promotion(state_root: Path, path: Path) -> tuple[dict[str, Any], Path, dict[str, Any]] | None:
    try:
        row = _validate_record(
            _read_json(path) or {},
            fmt="jigaewol_recovery_promotion_v1",
            digest_field="promotion_sha256",
        )
        digest = str(row.get("candidate_capsule_sha256") or "")
        capsule_path = _capsule_store_path(state_root, digest)
        capsule = validate_capsule(_read_json(capsule_path) or {})
        if str(capsule.get("capsule_sha256") or "") != digest:
            raise ValueError("promotion candidate capsule digest mismatch")
        return row, capsule_path, capsule
    except Exception as exc:
        _record_recovery_resolution_failure(
            state_root, stage=f"promotion:{path.name}", error=exc
        )
        return None


def _make_pointer(*, promotion: Mapping[str, Any], capsule_path: Path, capsule: Mapping[str, Any], state_root: Path) -> dict[str, Any]:
    pointer = {
        "format": "jigaewol_active_recovery_pointer_v1",
        "promotion_sequence": int(promotion.get("sequence") or 0),
        "capsule_sha256": str(capsule.get("capsule_sha256") or ""),
        "capsule_path": str(capsule_path.relative_to(_recovery_root(state_root))),
        "checkpoint": dict(capsule.get("checkpoint") or {}),
        "freshness": _freshness(capsule),
        "updated_at": time.time(),
    }
    pointer["pointer_sha256"] = _record_digest(pointer, "pointer_sha256")
    return pointer


def resolve_active_capsule(state_root: str | Path, *, repair_pointer: bool = True) -> dict[str, Any]:
    """Resolve the newest validated recovery capsule without trusting a lone pointer.

    Authority order is: valid pointer -> last valid committed promotion -> best archived
    capsule -> immutable legacy capsule. A damaged/interrupted pointer therefore cannot
    erase the last committed recovery state.
    """
    state_root = Path(state_root).resolve()
    pointer_path = _pointer_path(state_root)
    if pointer_path.is_file():
        try:
            pointer = _validate_record(
                _read_json(pointer_path) or {},
                fmt="jigaewol_active_recovery_pointer_v1",
                digest_field="pointer_sha256",
            )
            digest = str(pointer.get("capsule_sha256") or "")
            capsule_path = _capsule_store_path(state_root, digest)
            capsule = validate_capsule(_read_json(capsule_path) or {})
            if str(capsule.get("capsule_sha256") or "") == digest:
                return {
                    "present": True,
                    "source": "pointer",
                    "path": str(capsule_path),
                    "capsule": capsule,
                    "pointer": pointer,
                }
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            _record_recovery_resolution_failure(state_root, stage="active_pointer", error=exc)

    # A promotion is committed before the pointer. Recover the greatest valid sequence.
    best: tuple[int, dict[str, Any], Path, dict[str, Any]] | None = None
    for path in _promotion_files(state_root):
        valid = _valid_promotion(state_root, path)
        if not valid:
            continue
        row, capsule_path, capsule = valid
        seq = int(row.get("sequence") or 0)
        if best is None or seq > best[0]:
            best = (seq, row, capsule_path, capsule)
    if best is not None:
        _, promotion, capsule_path, capsule = best
        pointer = _make_pointer(
            promotion=promotion, capsule_path=capsule_path, capsule=capsule, state_root=state_root
        )
        if repair_pointer:
            _atomic_json(pointer_path, pointer)
        return {
            "present": True,
            "source": "promotion_recovery",
            "path": str(capsule_path),
            "capsule": capsule,
            "pointer": pointer,
        }

    # Older state roots may predate promotion history. Archive all valid candidates and
    # choose by durable sequence first, then generation time. This does not rewrite the
    # legacy portable_capsule.json.
    candidates: list[tuple[tuple[int, float, str, str], Path, dict[str, Any]]] = []
    store = _recovery_root(state_root) / "capsules"
    if store.is_dir():
        for path in store.glob("*.json"):
            try:
                capsule = validate_capsule(_read_json(path) or {})
            except Exception as exc:
                _record_recovery_resolution_failure(
                    state_root, stage=f"archived_capsule:{path.name}", error=exc
                )
                continue
            candidates.append((_freshness_key(capsule), path, capsule))
    legacy = _recovery_root(state_root) / "portable_capsule.json"
    if legacy.is_file():
        try:
            capsule = validate_capsule(_read_json(legacy) or {})
            archived = _archive_capsule(state_root, capsule, legacy.read_bytes())
            candidates.append((_freshness_key(capsule), archived, capsule))
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            _record_recovery_resolution_failure(state_root, stage="legacy_capsule", error=exc)
    if candidates:
        _, capsule_path, capsule = max(candidates, key=lambda row: row[0])
        return {
            "present": True,
            "source": "archive_or_legacy",
            "path": str(capsule_path),
            "capsule": capsule,
            "pointer": {},
        }
    return {"present": False, "source": "none", "path": "", "capsule": {}, "pointer": {}}


def promote_capsule(
    state_root: str | Path,
    capsule: Mapping[str, Any],
    *,
    source_ref: str = "",
    source_bytes: bytes | None = None,
) -> dict[str, Any]:
    state_root = Path(state_root).resolve()
    recovery_root = _recovery_root(state_root)
    recovery_root.mkdir(parents=True, exist_ok=True)
    candidate = validate_capsule(capsule)
    candidate_digest = str(candidate["capsule_sha256"])
    # Resolve existing authority before archiving the candidate, otherwise the mere
    # presence of an unpromoted capsule could accidentally make it authoritative.
    current = resolve_active_capsule(state_root)
    current_capsule = current.get("capsule") if current.get("present") else None
    candidate_path = _archive_capsule(state_root, candidate, source_bytes)

    # Preserve the original compatibility capsule forever once created.
    legacy = recovery_root / "portable_capsule.json"
    legacy_seeded = False
    if not legacy.exists():
        if source_bytes is not None:
            legacy.write_bytes(source_bytes)
        else:
            write_capsule(legacy, candidate)
        legacy_seeded = True

    current_digest = str((current_capsule or {}).get("capsule_sha256") or "")
    if current_digest == candidate_digest:
        return {
            "seeded": legacy_seeded,
            "promoted": False,
            "reason": "already_active",
            "capsule_sha256": candidate_digest,
            "active_capsule_sha256": candidate_digest,
            "legacy_capsule_preserved": True,
            "promotion_sequence": int((current.get("pointer") or {}).get("promotion_sequence") or 0),
        }

    if current_capsule is not None and _freshness_key(candidate) <= _freshness_key(current_capsule):
        return {
            "seeded": legacy_seeded,
            "promoted": False,
            "reason": "older_checkpoint_rejected",
            "capsule_sha256": candidate_digest,
            "active_capsule_sha256": current_digest,
            "legacy_capsule_preserved": True,
            "candidate_freshness": _freshness(candidate),
            "active_freshness": _freshness(current_capsule),
        }

    valid_sequences = []
    for path in _promotion_files(state_root):
        valid = _valid_promotion(state_root, path)
        if valid:
            valid_sequences.append(int(valid[0].get("sequence") or 0))
    sequence = (max(valid_sequences) if valid_sequences else 0) + 1
    promotion = {
        "format": "jigaewol_recovery_promotion_v1",
        "sequence": sequence,
        "previous_capsule_sha256": current_digest,
        "candidate_capsule_sha256": candidate_digest,
        "candidate_freshness": _freshness(candidate),
        "source_ref": str(source_ref),
        "promoted_at": time.time(),
    }
    promotion["promotion_sha256"] = _record_digest(promotion, "promotion_sha256")
    promotion_path = _promotion_dir(state_root) / f"{sequence:020d}.json"
    _atomic_json(promotion_path, promotion)
    pointer = _make_pointer(
        promotion=promotion, capsule_path=candidate_path, capsule=candidate, state_root=state_root
    )
    _atomic_json(_pointer_path(state_root), pointer)
    return {
        "seeded": legacy_seeded,
        "promoted": True,
        "reason": "newer_checkpoint_promoted",
        "capsule_sha256": candidate_digest,
        "active_capsule_sha256": candidate_digest,
        "legacy_capsule_preserved": True,
        "promotion_sequence": sequence,
        "pointer": pointer,
    }


def seed_state_from_artifact(artifact_root: str | Path, state_root: str | Path) -> dict[str, Any]:
    artifact_root = Path(artifact_root).resolve()
    state_root = Path(state_root).resolve()
    source = artifact_root / CAPSULE_NAME
    if not source.is_file():
        active = resolve_active_capsule(state_root)
        return {
            "seeded": False,
            "promoted": False,
            "reason": "artifact_has_no_capsule",
            "active_capsule_sha256": str((active.get("capsule") or {}).get("capsule_sha256") or ""),
        }
    source_bytes = source.read_bytes()
    data = validate_capsule(json.loads(source_bytes.decode("utf-8")))
    result = promote_capsule(
        state_root,
        data,
        source_ref=str(source),
        source_bytes=source_bytes,
    )
    receipt = _recovery_root(state_root) / "portable_capsule_import.json"
    rec = {
        "format": "jigaewol_portable_recovery_import_v2",
        **result,
        "artifact_content_set_sha256": str(data.get("artifact_content_set_sha256") or ""),
        "imported_at": time.time(),
        "source": str(source),
    }
    _atomic_json(receipt, rec)
    return rec
