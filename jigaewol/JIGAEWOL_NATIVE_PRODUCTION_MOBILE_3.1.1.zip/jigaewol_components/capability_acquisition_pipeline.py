from __future__ import annotations

"""Durable acquisition pipeline from host-fetched source bytes to proven capability.

The pipeline deliberately keeps discovery, authorization, source identity, rights,
static inspection, isolated execution, and integration as separate truth states.
It accepts source bytes only through an explicit host bundle; it never treats a
README, repository name, or discovery result as execution evidence.
"""

from pathlib import Path
from typing import Any, Iterable, Mapping

from jigaewol_runtime.capabilities.acquisition import AcquisitionLedger
from .quarantine_materializer import QuarantineMaterializer


class CapabilityAcquisitionPipeline:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.ledger = AcquisitionLedger(self.root / "acquisition_ledger.json")
        self.quarantine = QuarantineMaterializer(self.root / "quarantine")

    def acquire_host_bundle(
        self,
        *,
        need: str,
        source_ref: str,
        source_kind: str,
        capability_claims: Iterable[str],
        bundle: Mapping[str, Any],
        probe_argv: Iterable[str],
        expected_stdout_contains: str,
        capability_id: str,
        scope: str,
        authorization_ref: str,
        network_needed: bool = False,
    ) -> dict[str, Any]:
        claims = tuple(str(x) for x in capability_claims if str(x).strip())
        candidate_id = self.ledger.discover(
            need=need,
            source_type=source_kind,
            source_ref=source_ref,
            metadata={
                "capability_claims": list(claims),
                "source_bundle_required": True,
                "connection_required": False,
                "documentation_is_not_execution": True,
            },
        )
        self.ledger.authorize(candidate_id, authorization_ref=authorization_ref, scope=scope)

        receipt = self.quarantine.inspect_host_bundle(bundle)
        inspection = {
            "source_identity_verified": bool(receipt.source_identity_verified),
            "license_id": receipt.license_id,
            "license_verified": bool(receipt.license_verified),
            "local_execution_allowed": bool(receipt.local_execution_allowed),
            "network_namespace_proven": bool(receipt.network_namespace_proven),
            "static_findings": [x.__dict__ for x in receipt.static_findings],
            "quarantine_receipt_id": receipt.receipt_id,
            "connection_required": False,
        }
        self.ledger.inspect(candidate_id, findings=inspection)
        self.ledger.set_connection_requirement(candidate_id, connection_required=False)

        if not receipt.local_execution_allowed:
            self.ledger.block(
                candidate_id,
                stage="source_inspection",
                reason="identity/license/static inspection did not admit local execution",
                evidence_ref=f"quarantine:{receipt.receipt_id}",
            )
            self.ledger.keep_goal_open(candidate_id, reason="candidate retained for stronger isolated executor or alternate donor")
            return {
                "candidate_id": candidate_id,
                "state": "inspection_blocked_open",
                "inspection": inspection,
                "execution": None,
                "promotion": None,
            }

        self.ledger.install(candidate_id, evidence_ref=f"quarantine:{receipt.receipt_id}")
        self.ledger.connect(candidate_id, evidence_ref=f"local-isolated:{receipt.receipt_id}")
        self.ledger.mark_callable(candidate_id, callable_now=True, evidence_ref=f"isolated-workspace:{receipt.workspace}")

        execution = self.quarantine.execute_probe(
            receipt.receipt_id,
            tuple(str(x) for x in probe_argv),
            expected_stdout_contains=str(expected_stdout_contains or ""),
            network_needed=bool(network_needed),
        )
        promotion = self.quarantine.promote(
            receipt.receipt_id,
            execution,
            effect=f"capability:{capability_id}",
        )
        if not execution.success:
            self.ledger.block(
                candidate_id,
                stage="execute_probe",
                reason="task-specific smoke probe did not produce required observed success",
                evidence_ref=f"quarantine-exec:{execution.execution_id}",
            )
            self.ledger.keep_goal_open(candidate_id, reason="probe failure is route evidence, not capability impossibility")
            return {
                "candidate_id": candidate_id,
                "state": "probe_failed_open",
                "inspection": inspection,
                "execution": execution.as_mapping(),
                "promotion": promotion,
            }

        self.ledger.record_execution(
            candidate_id,
            result=execution.as_mapping(),
            origin_ref=f"quarantine-exec:{execution.execution_id}",
        )
        self.ledger.integrate(candidate_id, capability_id=capability_id, scope=scope)
        return {
            "candidate_id": candidate_id,
            "state": "integrated",
            "inspection": inspection,
            "execution": execution.as_mapping(),
            "promotion": promotion,
            "capability_id": capability_id,
            "scope": scope,
        }

    def acquire_host_native_capability(
        self,
        *,
        need: str,
        source_ref: str,
        source_kind: str,
        capability_claims: Iterable[str],
        capability_id: str,
        scope: str,
        authorization_ref: str,
        host_observation: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Integrate an already host-exposed plugin/tool only from observed lifecycle truth.

        Discovery metadata never upgrades itself to installation/callability.  The host
        observation must explicitly carry those states and an observed successful action
        before the capability becomes integrated.
        """
        obs = dict(host_observation or {})
        claims = tuple(str(x) for x in capability_claims if str(x).strip())
        candidate_id = self.ledger.discover(
            need=need,
            source_type=source_kind,
            source_ref=source_ref,
            metadata={
                "capability_claims": list(claims),
                "connection_required": bool(obs.get("connection_required", False)),
                "host_native": True,
                "documentation_is_not_execution": True,
            },
        )
        self.ledger.authorize(candidate_id, authorization_ref=authorization_ref, scope=scope)
        evidence_ref = str(obs.get("evidence_ref") or "").strip()
        self.ledger.inspect(candidate_id, findings={
            "host_native": True,
            "installed_observed": obs.get("installed") is True,
            "connected_observed": obs.get("connected") is True,
            "callable_observed": obs.get("callable") is True,
            "connection_required": bool(obs.get("connection_required", False)),
            "evidence_ref": evidence_ref,
        })
        self.ledger.set_connection_requirement(
            candidate_id, connection_required=bool(obs.get("connection_required", False))
        )
        if obs.get("installed") is not True:
            self.ledger.block(candidate_id, stage="install", reason="host has not confirmed installation", evidence_ref=evidence_ref or None)
            self.ledger.keep_goal_open(candidate_id, reason="candidate awaits real host installation/connection")
            return {"candidate_id": candidate_id, "state": "installation_required_open"}
        self.ledger.install(candidate_id, evidence_ref=evidence_ref or "host-observed-installation")
        if obs.get("connection_required") is True and obs.get("connected") is not True:
            self.ledger.block(candidate_id, stage="connect", reason="host connection not observed", evidence_ref=evidence_ref or None)
            self.ledger.keep_goal_open(candidate_id, reason="candidate awaits observed host connection")
            return {"candidate_id": candidate_id, "state": "connection_required_open"}
        self.ledger.connect(candidate_id, evidence_ref=evidence_ref or "host-observed-connection-not-required")
        callable_now = obs.get("callable") is True
        self.ledger.mark_callable(candidate_id, callable_now=callable_now, evidence_ref=evidence_ref or "host-callability-observation")
        if not callable_now:
            self.ledger.block(candidate_id, stage="probe_callable", reason="host did not report current callability", evidence_ref=evidence_ref or None)
            self.ledger.keep_goal_open(candidate_id, reason="candidate remains open until callability changes")
            return {"candidate_id": candidate_id, "state": "not_callable_open"}
        execution = obs.get("execution") if isinstance(obs.get("execution"), Mapping) else {}
        if execution.get("success") is not True:
            self.ledger.block(candidate_id, stage="execute_probe", reason="observed successful host execution is required", evidence_ref=str(execution.get("origin_ref") or evidence_ref or "") or None)
            self.ledger.keep_goal_open(candidate_id, reason="callable tool remains candidate until task-specific execution succeeds")
            return {"candidate_id": candidate_id, "state": "execution_required_open"}
        self.ledger.record_execution(
            candidate_id,
            result=dict(execution.get("result") or {}),
            origin_ref=str(execution.get("origin_ref") or evidence_ref or "host-execution"),
        )
        self.ledger.integrate(candidate_id, capability_id=capability_id, scope=scope)
        return {"candidate_id": candidate_id, "state": "integrated", "capability_id": capability_id, "scope": scope}

