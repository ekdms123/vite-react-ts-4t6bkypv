from __future__ import annotations

import hashlib
import importlib.util
import json
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

UPSTREAM_BLOB_SHA = "a744f0d2624e5f244927a2a03d66f41b56f94f85"


def git_blob_sha(data: bytes) -> str:
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


@dataclass(frozen=True)
class GenericAgentSourceProbe:
    local_git_blob_sha: str
    upstream_git_blob_sha: str
    byte_exact: bool
    loop_executed: bool
    result: str


def probe_generic_agent_source_loop(vendor_root: Path) -> GenericAgentSourceProbe:
    path = Path(vendor_root) / "agent_loop.py"
    data = path.read_bytes()
    local = git_blob_sha(data)
    spec = importlib.util.spec_from_file_location("jigaewol_vendor_generic_agent_loop", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load upstream source")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    class Fn:
        name = "finish"
        arguments = "{}"

    class Tool:
        id = "t1"
        function = Fn()

    class Resp:
        content = ""
        tool_calls = [Tool()]

    class Client:
        last_tools = ""

        def chat(self, **kwargs):
            if False:
                yield None
            return Resp()

    class Handler(mod.BaseHandler):
        def __init__(self):
            self.parent = SimpleNamespace(task_dir=None)
            self._done_hooks = []

        def do_finish(self, args, response):
            return mod.StepOutcome("source-loop-ok", should_exit=True)

    gen = mod.agent_runner_loop(Client(), "system", "user", Handler(), [], max_turns=2, verbose=False)
    result = None
    try:
        while True:
            next(gen)
    except StopIteration as exc:
        result = exc.value

    ok = isinstance(result, dict) and result.get("result") == "EXITED" and result.get("data") == "source-loop-ok"
    return GenericAgentSourceProbe(
        local,
        UPSTREAM_BLOB_SHA,
        local == UPSTREAM_BLOB_SHA,
        ok,
        json.dumps(result, ensure_ascii=False),
    )


