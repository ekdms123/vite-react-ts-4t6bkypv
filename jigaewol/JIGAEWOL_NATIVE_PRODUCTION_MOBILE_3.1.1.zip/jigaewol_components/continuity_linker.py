from __future__ import annotations

"""Cross-turn continuity as source-grounded graph edges."""

import hashlib
from dataclasses import dataclass

from .source_directive_compiler import ClauseGraph, DirectiveClause


@dataclass(frozen=True)
class ContinuityEdge:
    edge_id: str
    source_clause_id: str
    target_clause_id: str
    relation: str
    grounding: str = "explicit_source"


@dataclass(frozen=True)
class AuthorityNode:
    clause: DirectiveClause
    active: bool
    superseded_by: str = ""

    @property
    def clause_id(self) -> str:
        return self.clause.clause_id

    @property
    def turn_id(self) -> str:
        return self.clause.turn_id


@dataclass(frozen=True)
class AuthorityGraph:
    graph_id: str
    previous_graph_id: str
    current_graph_id: str
    nodes: tuple[AuthorityNode, ...]
    edges: tuple[ContinuityEdge, ...]

    @property
    def active_clauses(self) -> tuple[DirectiveClause, ...]:
        return tuple(n.clause for n in self.nodes if n.active)


def _edge_id(source: str, relation: str, target: str) -> str:
    payload = f"{source}:{relation}:{target}".encode("utf-8")
    return "edge_" + hashlib.sha256(payload).hexdigest()[:16]


def _tokens(text: str) -> set[str]:
    return {part.strip('.,!?~…()[]{}\"\'') for part in text.casefold().split() if len(part.strip('.,!?~…()[]{}\"\'')) > 1}


class ContinuityLinker:
    """Resolve cross-turn references without recreating a separate continuity classifier.

    The compiler owns source/discourse interpretation.  This linker only creates graph
    relationships and resolves conflicts in the same target/effect neighborhood.
    """

    def _best_previous(self, current: DirectiveClause, previous: tuple[DirectiveClause, ...]) -> DirectiveClause | None:
        if not previous:
            return None
        cur_tokens = _tokens(current.target + " " + current.source_text)
        ranked = []
        for index, clause in enumerate(previous):
            prev_tokens = _tokens(clause.target + " " + clause.source_text)
            overlap = len(cur_tokens & prev_tokens)
            ranked.append((overlap, index, clause))
        ranked.sort(key=lambda row: (row[0], row[1]), reverse=True)
        return ranked[0][2]

    def link(self, *, previous: ClauseGraph | None, current: ClauseGraph) -> AuthorityGraph:
        # Previous continuity state may contain an exact prior directive or a durable
        # task objective summary. Both are legitimate antecedents; authority of the
        # current turn still comes only from current source clauses.
        prev_clauses = tuple(
            c for c in (previous.clauses if previous is not None else ())
            if not c.quoted and not c.hypothetical
        )
        active: dict[str, bool] = {c.clause_id: True for c in prev_clauses}
        superseded_by: dict[str, str] = {}
        edges: list[ContinuityEdge] = []

        for clause in current.clauses:
            if clause.quoted:
                continue
            relation_hint = clause.discourse_relation
            has_reference = clause.reference_kind != "none" or relation_hint in {"corrects", "cancels"}
            if not has_reference:
                continue
            target = self._best_previous(clause, prev_clauses)
            if target is None:
                continue
            if relation_hint == "cancels":
                relation = "CANCELS"
                active[target.clause_id] = False
                superseded_by[target.clause_id] = clause.clause_id
            elif relation_hint == "corrects":
                relation = "CORRECTS"
                active[target.clause_id] = False
                superseded_by[target.clause_id] = clause.clause_id
            else:
                relation = "CONTINUES"
            edges.append(ContinuityEdge(
                edge_id=_edge_id(clause.clause_id, relation, target.clause_id),
                source_clause_id=clause.clause_id,
                target_clause_id=target.clause_id,
                relation=relation,
            ))

        nodes: list[AuthorityNode] = [
            AuthorityNode(c, active=active.get(c.clause_id, True), superseded_by=superseded_by.get(c.clause_id, ""))
            for c in prev_clauses
        ]
        nodes.extend(AuthorityNode(c, active=c.authoritative) for c in current.clauses if c.authoritative)
        material = ":".join([previous.graph_id if previous else "genesis", current.graph_id, *(e.edge_id for e in edges)])
        return AuthorityGraph(
            graph_id="authority_graph_" + hashlib.sha256(material.encode("utf-8")).hexdigest()[:20],
            previous_graph_id=previous.graph_id if previous else "",
            current_graph_id=current.graph_id,
            nodes=tuple(nodes),
            edges=tuple(edges),
        )
