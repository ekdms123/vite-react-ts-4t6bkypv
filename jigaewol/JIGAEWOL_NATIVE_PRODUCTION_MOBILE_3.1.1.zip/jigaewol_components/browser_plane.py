from __future__ import annotations

import hashlib
import json
import shutil
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class BrowserReceipt:
    receipt_id: str
    url: str
    final_url: str
    title: str
    text_sha256: str
    text_excerpt: str
    screenshot_path: str | None
    started_at: float
    finished_at: float


@dataclass(frozen=True)
class BrowserSnapshot:
    sequence: int
    url: str
    title: str
    text_sha256: str
    text_excerpt: str
    changed_from_previous: bool
    observed_at: float


@dataclass(frozen=True)
class BrowserPerceptionReceipt:
    receipt_id: str
    source: str
    snapshots: tuple[BrowserSnapshot, ...]
    change_count: int
    started_at: float
    finished_at: float


@dataclass(frozen=True)
class BrowserObservation:
    observation_id: str
    url: str
    title: str
    text_sha256: str
    changed_from_previous: bool
    event_count: int
    text_excerpt: str
    observed_at: float


class BrowserPlane:
    """Local Chromium body with persistent profile and temporal perception support."""

    RECEIPT_DIR = ".browser_receipts"
    PROFILE_DIR = ".browser_profile"

    def __init__(self, workspace_root: str | Path) -> None:
        self.root = Path(workspace_root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.receipt_dir = self.root / self.RECEIPT_DIR
        self.receipt_dir.mkdir(exist_ok=True)
        self.profile_dir = self.root / self.PROFILE_DIR
        self.profile_dir.mkdir(exist_ok=True)

    def _launch_persistent(self, p, *, headless: bool = True):
        executable = shutil.which("chromium") or shutil.which("chromium-browser")
        kwargs = {
            "user_data_dir": str(self.profile_dir),
            "headless": headless,
            "timeout": 15_000,
            "args": ["--no-first-run", "--no-default-browser-check"],
        }
        if executable is not None:
            kwargs["executable_path"] = executable
        return p.chromium.launch_persistent_context(**kwargs)

    @staticmethod
    def _launch_browser(p, *, headless: bool = True):
        executable = shutil.which("chromium") or shutil.which("chromium-browser")
        kwargs = {
            "headless": headless,
            "timeout": 15_000,
            "args": ["--no-first-run", "--no-default-browser-check"],
        }
        if executable is not None:
            kwargs["executable_path"] = executable
        return p.chromium.launch(**kwargs)

    def _write_receipt(self, receipt: BrowserReceipt) -> None:
        (self.receipt_dir / f"{receipt.receipt_id}.json").write_text(
            json.dumps(asdict(receipt), ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def visit(self, url: str, *, screenshot: bool = True, timeout_ms: int = 30_000, headless: bool = True) -> BrowserReceipt:
        from playwright.sync_api import sync_playwright
        started = time.time(); screenshot_path: Path | None = None
        with sync_playwright() as p:
            context = self._launch_persistent(p, headless=headless)
            try:
                page = context.pages[0] if context.pages else context.new_page()
                page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
                title = page.title(); final_url = page.url; text = page.locator("body").inner_text(timeout=timeout_ms)
                receipt_id = f"browser_{uuid.uuid4().hex[:16]}"
                if screenshot:
                    screenshot_path = self.receipt_dir / f"{receipt_id}.png"
                    page.screenshot(path=str(screenshot_path), full_page=True)
            finally:
                context.close()
        receipt = BrowserReceipt(receipt_id, url, final_url, title, hashlib.sha256(text.encode()).hexdigest(), text, str(screenshot_path) if screenshot_path else None, started, time.time())
        self._write_receipt(receipt); return receipt

    def render_html(self, html: str, *, screenshot: bool = True, headless: bool = True) -> BrowserReceipt:
        from playwright.sync_api import sync_playwright
        started = time.time(); screenshot_path: Path | None = None
        with sync_playwright() as p:
            browser = self._launch_browser(p, headless=headless); context = browser.new_context()
            try:
                page = context.new_page(); page.set_content(html, wait_until="domcontentloaded")
                title = page.title(); final_url = page.url; text = page.locator("body").inner_text(); receipt_id = f"browser_{uuid.uuid4().hex[:16]}"
                if screenshot:
                    screenshot_path = self.receipt_dir / f"{receipt_id}.png"; page.screenshot(path=str(screenshot_path), full_page=True)
            finally:
                context.close(); browser.close()
        receipt = BrowserReceipt(receipt_id, "about:blank#rendered-html", final_url, title, hashlib.sha256(text.encode()).hexdigest(), text, str(screenshot_path) if screenshot_path else None, started, time.time())
        self._write_receipt(receipt); return receipt

    def observe(self, url: str, *, cycles: int = 4, interval_s: float = 0.25, timeout_ms: int = 30_000, headless: bool = True, reload_each_cycle: bool = False) -> BrowserPerceptionReceipt:
        from playwright.sync_api import sync_playwright
        started=time.time(); snapshots=[]; previous=None
        with sync_playwright() as p:
            context=self._launch_persistent(p,headless=headless)
            try:
                page=context.pages[0] if context.pages else context.new_page(); page.goto(url,wait_until="domcontentloaded",timeout=timeout_ms)
                for i in range(max(1,int(cycles))):
                    if i and reload_each_cycle: page.reload(wait_until="domcontentloaded",timeout=timeout_ms)
                    if i: page.wait_for_timeout(max(0,int(interval_s*1000)))
                    text=page.locator("body").inner_text(timeout=timeout_ms); digest=hashlib.sha256(text.encode()).hexdigest()
                    snapshots.append(BrowserSnapshot(i,page.url,page.title(),digest,text,previous is not None and digest!=previous,time.time())); previous=digest
            finally: context.close()
        receipt=BrowserPerceptionReceipt(f"perception_{uuid.uuid4().hex[:16]}",str(url),tuple(snapshots),sum(x.changed_from_previous for x in snapshots),started,time.time())
        (self.receipt_dir/f"{receipt.receipt_id}.json").write_text(json.dumps({**asdict(receipt),"snapshots":[asdict(x) for x in receipt.snapshots]},ensure_ascii=False,indent=2),encoding="utf-8")
        return receipt

    def observe_html(self, html: str, *, cycles: int = 4, interval_s: float = 0.2, headless: bool = True) -> BrowserPerceptionReceipt:
        from playwright.sync_api import sync_playwright
        started=time.time(); snapshots=[]; previous=None
        with sync_playwright() as p:
            browser=self._launch_browser(p,headless=headless); context=browser.new_context()
            try:
                page=context.new_page(); page.set_content(html,wait_until="domcontentloaded")
                for i in range(max(1,int(cycles))):
                    if i: page.wait_for_timeout(max(0,int(interval_s*1000)))
                    text=page.locator("body").inner_text(); digest=hashlib.sha256(text.encode()).hexdigest()
                    snapshots.append(BrowserSnapshot(i,page.url,page.title(),digest,text,previous is not None and digest!=previous,time.time())); previous=digest
            finally: context.close(); browser.close()
        receipt=BrowserPerceptionReceipt(f"perception_{uuid.uuid4().hex[:16]}","inline_html",tuple(snapshots),sum(x.changed_from_previous for x in snapshots),started,time.time())
        (self.receipt_dir/f"{receipt.receipt_id}.json").write_text(json.dumps({**asdict(receipt),"snapshots":[asdict(x) for x in receipt.snapshots]},ensure_ascii=False,indent=2),encoding="utf-8")
        return receipt

    def snapshot_cdp(self, cdp_url: str, *, timeout_ms: int = 30_000) -> BrowserReceipt:
        from playwright.sync_api import sync_playwright
        started=time.time()
        with sync_playwright() as p:
            browser=p.chromium.connect_over_cdp(cdp_url,timeout=timeout_ms)
            try:
                contexts=browser.contexts
                if not contexts: raise RuntimeError("CDP browser has no context")
                pages=contexts[0].pages
                if not pages: raise RuntimeError("CDP browser has no page")
                page=pages[0]; text=page.locator("body").inner_text(timeout=timeout_ms); receipt_id=f"browser_{uuid.uuid4().hex[:16]}"; title=page.title(); final_url=page.url
            finally:
                browser.close()
        receipt=BrowserReceipt(receipt_id,cdp_url,final_url,title,hashlib.sha256(text.encode()).hexdigest(),text,None,started,time.time())
        self._write_receipt(receipt); return receipt

    def open_session(self, *, headless: bool = True, cdp_endpoint: str | None = None) -> "PersistentBrowserSession":
        return PersistentBrowserSession(self, headless=headless, cdp_endpoint=cdp_endpoint)


class PersistentBrowserSession:
    """Long-lived perception/action session with dedicated profile or existing CDP body."""
    def __init__(self, plane: BrowserPlane, *, headless: bool = True, cdp_endpoint: str | None = None) -> None:
        from playwright.sync_api import sync_playwright
        self.plane=plane; self._pw=sync_playwright().start(); self._events=[]; self._last_hash=None
        if cdp_endpoint:
            self.browser=self._pw.chromium.connect_over_cdp(cdp_endpoint); contexts=self.browser.contexts; self.context=contexts[0] if contexts else self.browser.new_context()
        else:
            self.browser=None; self.context=self.plane._launch_persistent(self._pw,headless=headless)
        self.page=self.context.pages[0] if self.context.pages else self.context.new_page()
        self.page.on('console',lambda msg:self._events.append({'kind':'console','text':msg.text,'at':time.time()}))
        self.page.on('framenavigated',lambda frame:self._events.append({'kind':'navigation','url':frame.url,'at':time.time()}))

    def navigate(self,url: str,*,timeout_ms: int=30000)->BrowserObservation:
        self.page.goto(str(url),wait_until='domcontentloaded',timeout=timeout_ms); return self.observe()
    def set_content(self,html: str)->BrowserObservation:
        self.page.set_content(str(html),wait_until='domcontentloaded'); return self.observe()
    def observe(self)->BrowserObservation:
        text=self.page.locator('body').inner_text(); digest=hashlib.sha256(text.encode()).hexdigest(); changed=self._last_hash is not None and digest!=self._last_hash; self._last_hash=digest
        row=BrowserObservation(f'observe_{uuid.uuid4().hex[:16]}',self.page.url,self.page.title(),digest,changed,len(self._events),text,time.time())
        event_dir=self.plane.root/'.browser_events'; event_dir.mkdir(exist_ok=True); (event_dir/f'{row.observation_id}.json').write_text(json.dumps({'observation':asdict(row),'events':self._events},ensure_ascii=False,indent=2),encoding='utf-8'); return row
    def close(self)->None:
        try: self.context.close()
        finally:
            try:
                if self.browser is not None: self.browser.close()
            finally: self._pw.stop()
    def __enter__(self): return self
    def __exit__(self,exc_type,exc,tb): self.close()
