from __future__ import annotations

"""Cross-component consistency attestation without relaxing directive invariants.

This module is intentionally observational.  It does not rewrite user text, accept
alternate destination hashes, or bypass ``directive_invariant`` failures.  It binds
three already-existing views of a turn to the same exact source event:

* exact user-message bytes,
* the unified-user-intent envelope,
* the semantic-communication record.

A hash conflict is classified as a continuity-guard rejection and remains a rejection.
"""

from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import time
from typing import Any, Mapping

from .directive_invariant import DirectiveInvariantError, verify_destination
from .unified_user_intent import _atomic_json


SCHEMA = "jigaewol_continuity_consistency_v1"


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True, slots=True)
class ContinuityConsistencyAttestation:
    exact_message_sha256: str
    unified_intent_sha256: str
    semantic_source_sha256: str
    semantic_canonical_sha256: str
    semantic_canonical_recomputed_sha256: str
    directive_destination_verified: bool
    unified_intent_bound: bool
    semantic_source_bound: bool
    semantic_canonical_self_consistent: bool
    all_consistent: bool
    schema: str = SCHEMA

    def as_mapping(self) -> dict[str, Any]:
        return {
            **asdict(self),
            "directive_invariant_role": "continuity_stability_guard",
            "directive_invariant_bypass_permitted": False,
            "hash_conflict_semantics": "guard_rejection_not_bug_and_not_success",
            "source_rewrite_permitted": False,
            "semantic_normalization_may_replace_source_authority": False,
            "independent_validation_preserved": True,
        }


def attest_source_consistency(
    raw_message_bytes: bytes,
    *,
    unified_intent: Mapping[str, Any],
    semantic_record: Mapping[str, Any],
) -> ContinuityConsistencyAttestation:
    raw = bytes(raw_message_bytes)
    text = raw.decode("utf-8", errors="strict")
    exact_sha = _sha(raw)

    # This call deliberately preserves the existing hard invariant.  If exact source
    # and destination diverge, the original DirectiveInvariantError is allowed to
    # propagate; no alternate hash is accepted here.
    verify_destination(raw_user_text=text, original_user_directive_sha256=exact_sha)

    unified_sha = str(unified_intent.get("exact_user_message_sha256") or "").strip().lower()
    semantic_source_sha = str(semantic_record.get("source_sha256") or "").strip().lower()
    canonical_text = str(semantic_record.get("canonical_text") or "")
    canonical_sha = str(semantic_record.get("canonical_sha256") or "").strip().lower()
    canonical_recomputed = hashlib.sha256(canonical_text.encode("utf-8")).hexdigest()

    unified_ok = unified_sha == exact_sha
    semantic_source_ok = semantic_source_sha == exact_sha
    canonical_ok = bool(canonical_sha) and canonical_sha == canonical_recomputed
    all_ok = unified_ok and semantic_source_ok and canonical_ok
    if not all_ok:
        problems: list[str] = []
        if not unified_ok:
            problems.append(f"unified_intent_sha_mismatch:{unified_sha}:{exact_sha}")
        if not semantic_source_ok:
            problems.append(f"semantic_source_sha_mismatch:{semantic_source_sha}:{exact_sha}")
        if not canonical_ok:
            problems.append(f"semantic_canonical_sha_mismatch:{canonical_sha}:{canonical_recomputed}")
        raise DirectiveInvariantError("continuity_consistency_violation:" + "|".join(problems))

    return ContinuityConsistencyAttestation(
        exact_message_sha256=exact_sha,
        unified_intent_sha256=unified_sha,
        semantic_source_sha256=semantic_source_sha,
        semantic_canonical_sha256=canonical_sha,
        semantic_canonical_recomputed_sha256=canonical_recomputed,
        directive_destination_verified=True,
        unified_intent_bound=unified_ok,
        semantic_source_bound=semantic_source_ok,
        semantic_canonical_self_consistent=canonical_ok,
        all_consistent=all_ok,
    )


def classify_directive_hash_conflict(*, raw_user_text: str, expected_sha256: str) -> dict[str, Any]:
    """Describe a directive hash conflict without suppressing or repairing it.

    This helper is diagnostic only.  A mismatch remains a rejected continuity check.
    """
    actual = hashlib.sha256(str(raw_user_text).encode("utf-8")).hexdigest()
    expected = str(expected_sha256 or "").strip().lower()
    matched = bool(expected) and expected == actual
    return {
        "schema": "jigaewol_directive_hash_conflict_classification_v1",
        "expected_sha256": expected,
        "actual_sha256": actual,
        "matched": matched,
        "classification": "continuity_verified" if matched else "continuity_guard_rejection",
        "bug_classification": False,
        "bypass_permitted": False,
        "replacement_hash_synthesized": False,
    }


class ContinuityConsistencyLedger:
    """Persist read-only consistency attestations for later forensic comparison."""

    def __init__(self, state_root: str | Path) -> None:
        self.root = Path(state_root) / "continuity_consistency"
        self.records = self.root / "records"
        self.events = self.root / "events.jsonl"
        self.root.mkdir(parents=True, exist_ok=True)
        self.records.mkdir(parents=True, exist_ok=True)

    def record(self, attestation: ContinuityConsistencyAttestation, *, gateway_turn_id: str = "") -> dict[str, Any]:
        row = {
            **attestation.as_mapping(),
            "gateway_turn_id": str(gateway_turn_id or ""),
            "recorded_at": time.time(),
        }
        path = self.records / f"{attestation.exact_message_sha256}.json"
        _atomic_json(path, row)
        with self.events.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, default=str) + "\n")
            fh.flush()
        return {"record": row, "path": str(path)}
