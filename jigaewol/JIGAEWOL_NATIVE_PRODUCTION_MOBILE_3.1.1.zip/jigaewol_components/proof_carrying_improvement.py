from __future__ import annotations

"""Proof-carrying runtime improvement protocol.

The protocol deliberately separates three authorities:

1. the user's canonical directive and requirement contract (runtime-owned),
2. the optimizer's freedom to invent an implementation (model-owned working state),
3. the proof certificate deciding whether the candidate is complete (runtime-owned).

A preservation failure is represented as an optimization defect on a still-live
candidate.  It is not scored against implementation gain and it does not change the
optimizer's role.  A candidate becomes an admissible improvement only after every
canonical requirement occurrence has a structural preservation witness.
"""

import hashlib
import json
from dataclasses import asdict, dataclass, replace
from typing import Any, Callable, Iterable, Mapping

from .directive_invariant import DirectiveInvariantError, verify_destination
from .requirement_contract import RequirementCompiler, RequirementContract


def _sha256_text(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass(frozen=True, slots=True)
class OptimizerCharter:
    role: str = "runtime_optimizer"
    objective_mode: str = "maximize_improvement_inside_canonical_intent"
    preservation_semantics: str = "feasibility_condition_not_tradeoff_score"
    incomplete_candidate_semantics: str = "optimization_defect"
    candidate_liveness_on_proof_failure: str = "live_repairable"
    good_improvement_definition: str = "proof_complete_and_materially_improves_runtime"
    keep_useful_gains_during_repair: bool = True
    representation_freedom: bool = True
    architecture_freedom: bool = True
    route_freedom: bool = True
    may_rewrite_canonical_destination: bool = False
    may_delete_requirement_occurrence: bool = False

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ProofObligation:
    obligation_id: str
    atom_id: str
    source_index: int
    exact_atom_text: str
    kind: str
    critical: bool
    parent_message_sha256: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class PreservationWitness:
    obligation_id: str
    atom_id: str
    preservation_mode: str
    implementation_refs: tuple[str, ...] = ()
    route_refs: tuple[str, ...] = ()
    test_refs: tuple[str, ...] = ()
    optimizer_rationale: str = ""

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "PreservationWitness":
        return cls(
            obligation_id=str(raw.get("obligation_id") or ""),
            atom_id=str(raw.get("atom_id") or ""),
            preservation_mode=str(raw.get("preservation_mode") or "preserved"),
            implementation_refs=tuple(str(x) for x in (raw.get("implementation_refs") or ()) if str(x)),
            route_refs=tuple(str(x) for x in (raw.get("route_refs") or ()) if str(x)),
            test_refs=tuple(str(x) for x in (raw.get("test_refs") or ()) if str(x)),
            optimizer_rationale=str(raw.get("optimizer_rationale") or ""),
        )

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ImprovementProposal:
    candidate_id: str
    optimizer_role: str
    parent_destination_sha256: str
    requirement_contract_sha256: str
    implementation_summary: str
    implementation_refs: tuple[str, ...]
    claimed_improvements: tuple[str, ...]
    witnesses: tuple[PreservationWitness, ...]

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "ImprovementProposal":
        return cls(
            candidate_id=str(raw.get("candidate_id") or "candidate_unspecified"),
            optimizer_role=str(raw.get("optimizer_role") or ""),
            parent_destination_sha256=str(raw.get("parent_destination_sha256") or ""),
            requirement_contract_sha256=str(raw.get("requirement_contract_sha256") or ""),
            implementation_summary=str(raw.get("implementation_summary") or ""),
            implementation_refs=tuple(str(x) for x in (raw.get("implementation_refs") or ()) if str(x)),
            claimed_improvements=tuple(str(x) for x in (raw.get("claimed_improvements") or ()) if str(x)),
            witnesses=tuple(
                x if isinstance(x, PreservationWitness) else PreservationWitness.from_mapping(x)
                for x in (raw.get("witnesses") or ())
                if isinstance(x, (Mapping, PreservationWitness))
            ),
        )

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ProofDefect:
    code: str
    description: str
    obligation_id: str = ""
    repair_hint: str = ""

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ProofCertificate:
    candidate_id: str
    optimizer_role: str
    destination_match: bool
    contract_match: bool
    all_obligations_witnessed: bool
    witness_structure_valid: bool
    reference_checks_passed: bool
    non_vacuous: bool
    defects: tuple[ProofDefect, ...]
    complete: bool
    certificate_sha256: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class OptimizerFeedback:
    feedback_kind: str
    candidate_status: str
    optimizer_role: str
    proof_complete: bool
    keep_useful_gains: bool
    unresolved_proof_obligations: tuple[str, ...]
    defect_codes: tuple[str, ...]
    repair_directive: str
    good_improvement_definition: str

    def as_mapping(self) -> dict[str, Any]:
        return asdict(self)


class ProofCarryingImprovementProtocol:
    """Make preservation the admission rule for improvement, not a competing score.

    The optimizer remains free to change architecture, representation, decomposition,
    and routes.  Canonical requirements are runtime-owned proof obligations.  The
    optimizer authors witnesses; the runtime independently verifies them and returns
    proof failures as optimization defects on a still-live candidate.
    """

    ACTIVE_MARKERS = (
        "proofcarryingimprovementprotocol", "proof-carrying", "proof carrying",
        "runtime optimizer", "runtime_optimizer", "런타임 optimizer", "런타임 옵티마이저",
        "zip 코드", "zip파일", "zip 파일", "runtime 코드", "런타임 코드", "지개월",
    )
    IMPROVEMENT_MARKERS = (
        "개선", "구현", "수정", "고쳐", "리팩터", "설계", "architecture", "implement",
        "improve", "optimiz", "patch", "refactor", "protocol",
    )
    VALID_PRESERVATION_MODES = frozenset({"preserved", "strengthened", "implemented", "equivalent_refactor"})

    def __init__(self, *, charter: OptimizerCharter | None = None) -> None:
        self.charter = charter or OptimizerCharter()

    @classmethod
    def should_activate(cls, text: str) -> bool:
        folded = str(text or "").casefold()
        return bool(
            any(marker in folded for marker in cls.ACTIVE_MARKERS)
            and any(marker in folded for marker in cls.IMPROVEMENT_MARKERS)
        )

    @staticmethod
    def _obligation_id(contract: RequirementContract, *, source_index: int, atom_id: str, text: str) -> str:
        # Existing RequirementAtom.atom_id is text-derived and can collide for repeated
        # identical wording.  The proof layer therefore binds occurrence identity to
        # the parent message plus source index without changing the legacy atom ABI.
        material = f"{contract.message_sha256}:{source_index}:{atom_id}:{text}"
        return "obl_" + _sha256_text(material)[:24]

    @classmethod
    def obligations_from_contract(cls, contract: RequirementContract) -> tuple[ProofObligation, ...]:
        return tuple(
            ProofObligation(
                obligation_id=cls._obligation_id(
                    contract,
                    source_index=int(atom.source_index),
                    atom_id=str(atom.atom_id),
                    text=str(atom.text),
                ),
                atom_id=str(atom.atom_id),
                source_index=int(atom.source_index),
                exact_atom_text=str(atom.text),
                kind=str(atom.kind),
                critical=bool(atom.critical),
                parent_message_sha256=str(atom.parent_message_sha256),
            )
            for atom in contract.atoms
        )

    @classmethod
    def optimizer_context(cls, raw_user_text: str, contract: RequirementContract | None = None) -> dict[str, Any]:
        exact = str(raw_user_text)
        canonical = RequirementCompiler.compile(exact)
        if contract is not None:
            verify_destination(raw_user_text=exact, original_user_directive_sha256=contract.message_sha256)
            if contract.contract_sha256 != canonical.contract_sha256:
                raise DirectiveInvariantError("optimizer_contract_not_canonical")
        obligations = cls.obligations_from_contract(canonical)
        charter = OptimizerCharter()
        obligation_body = [x.as_mapping() for x in obligations]
        compact_obligations = len(obligation_body) > 64
        if compact_obligations:
            # The canonical RequirementContract already owns exact occurrence text.
            # Repeating hundreds/thousands of full texts inside semantic authority
            # multiplies prompt/state size without adding authority. Keep occurrence
            # identity and resolve exact text from the contract when a proof is checked.
            obligation_body = [
                {
                    "obligation_id": x.obligation_id,
                    "atom_id": x.atom_id,
                    "source_index": x.source_index,
                    "kind": x.kind,
                    "critical": x.critical,
                    "parent_message_sha256": x.parent_message_sha256,
                }
                for x in obligations
            ]
        return {
            "schema": "proof_carrying_improvement_v1",
            "active": cls.should_activate(exact),
            "optimizer_charter": charter.as_mapping(),
            "destination_sha256": canonical.message_sha256,
            "requirement_contract_sha256": canonical.contract_sha256,
            "proof_obligations": obligation_body,
            "proof_obligation_texts_resolve_from_canonical_contract": compact_obligations,
            "proof_obligation_count": len(obligation_body),
            "proof_obligation_ids_sha256": _sha256_text(_stable_json([x.obligation_id for x in obligations])),
            "feedback_semantics": {
                "proof_failure_frame": "optimization_defect",
                "candidate_status_on_failure": "live_repairable",
                "role_continuity": "runtime_optimizer",
                "retain_useful_gains": True,
                "repair_strategy": "close_unresolved_proof_obligations_without_shrinking_canonical_intent",
            },
        }

    def _defects_without_mutation_probe(
        self,
        *,
        raw_user_text: str,
        proposal: ImprovementProposal,
        reference_exists: Callable[[str], bool] | None = None,
    ) -> tuple[ProofDefect, ...]:
        canonical = RequirementCompiler.compile(str(raw_user_text))
        obligations = self.obligations_from_contract(canonical)
        obligation_by_id = {x.obligation_id: x for x in obligations}
        defects: list[ProofDefect] = []

        if proposal.optimizer_role != self.charter.role:
            defects.append(ProofDefect(
                code="optimizer_role_drift",
                description="candidate stopped identifying as the runtime optimizer",
                repair_hint="retain the runtime_optimizer role while repairing the candidate",
            ))

        if proposal.parent_destination_sha256 != canonical.message_sha256:
            defects.append(ProofDefect(
                code="destination_binding_mismatch",
                description="candidate is not bound to the current canonical destination",
                repair_hint="rebind the same candidate to the immutable current destination",
            ))

        if proposal.requirement_contract_sha256 != canonical.contract_sha256:
            defects.append(ProofDefect(
                code="requirement_contract_binding_mismatch",
                description="candidate proof was authored against a different requirement contract",
                repair_hint="regenerate witnesses against the current canonical requirement contract",
            ))

        witnesses_by_obligation: dict[str, list[PreservationWitness]] = {}
        for witness in proposal.witnesses:
            witnesses_by_obligation.setdefault(witness.obligation_id, []).append(witness)

        for obligation in obligations:
            rows = witnesses_by_obligation.get(obligation.obligation_id, [])
            if not rows:
                defects.append(ProofDefect(
                    code="unresolved_proof_obligation",
                    obligation_id=obligation.obligation_id,
                    description=f"canonical requirement occurrence has no preservation witness: {obligation.exact_atom_text}",
                    repair_hint="retain useful gains and add a structural preservation mechanism for this requirement",
                ))
                continue
            if len(rows) > 1:
                defects.append(ProofDefect(
                    code="ambiguous_duplicate_witness",
                    obligation_id=obligation.obligation_id,
                    description="multiple witnesses claim the same proof obligation",
                    repair_hint="merge them into one explicit preservation witness",
                ))
            witness = rows[0]
            if witness.atom_id != obligation.atom_id:
                defects.append(ProofDefect(
                    code="witness_atom_mismatch",
                    obligation_id=obligation.obligation_id,
                    description="witness obligation and legacy atom identity disagree",
                    repair_hint="bind the witness to the canonical atom occurrence",
                ))
            if witness.preservation_mode not in self.VALID_PRESERVATION_MODES:
                defects.append(ProofDefect(
                    code="unsupported_preservation_mode",
                    obligation_id=obligation.obligation_id,
                    description="witness uses a preservation mode that does not establish intent retention",
                    repair_hint="use a preservation mode with an explicit equivalence or strengthening claim",
                ))
            refs = witness.implementation_refs + witness.route_refs + witness.test_refs
            if not refs:
                defects.append(ProofDefect(
                    code="witness_without_structural_ref",
                    obligation_id=obligation.obligation_id,
                    description="witness is narrative-only and points to no implementation, route, or test mechanism",
                    repair_hint="attach at least one concrete implementation, route, or test reference",
                ))
            if not witness.optimizer_rationale.strip():
                defects.append(ProofDefect(
                    code="witness_without_optimizer_rationale",
                    obligation_id=obligation.obligation_id,
                    description="optimizer did not explain how its design preserves this occurrence",
                    repair_hint="state the preservation mechanism as an engineering rationale",
                ))
            if reference_exists is not None:
                missing_refs = [ref for ref in refs if not reference_exists(ref)]
                if missing_refs:
                    defects.append(ProofDefect(
                        code="unresolved_structural_reference",
                        obligation_id=obligation.obligation_id,
                        description="witness references a mechanism that the runtime cannot resolve: " + ",".join(missing_refs),
                        repair_hint="point the witness at materialized implementation, route, or test state",
                    ))

        unknown = sorted(set(witnesses_by_obligation) - set(obligation_by_id))
        for obligation_id in unknown:
            defects.append(ProofDefect(
                code="unknown_proof_obligation",
                obligation_id=obligation_id,
                description="candidate introduced a proof obligation that is not part of the canonical directive",
                repair_hint="remove the invented obligation from preservation accounting",
            ))

        return tuple(defects)

    def verify(
        self,
        *,
        raw_user_text: str,
        proposal: ImprovementProposal | Mapping[str, Any],
        reference_exists: Callable[[str], bool] | None = None,
    ) -> ProofCertificate:
        proposal = proposal if isinstance(proposal, ImprovementProposal) else ImprovementProposal.from_mapping(proposal)
        canonical = RequirementCompiler.compile(str(raw_user_text))
        defects = self._defects_without_mutation_probe(
            raw_user_text=raw_user_text,
            proposal=proposal,
            reference_exists=reference_exists,
        )
        defect_codes = {x.code for x in defects}
        obligations = self.obligations_from_contract(canonical)

        destination_match = proposal.parent_destination_sha256 == canonical.message_sha256
        contract_match = proposal.requirement_contract_sha256 == canonical.contract_sha256
        all_obligations_witnessed = not any(x.code == "unresolved_proof_obligation" for x in defects)
        witness_structure_valid = not any(x.code in {
            "ambiguous_duplicate_witness", "witness_atom_mismatch", "unsupported_preservation_mode",
            "witness_without_structural_ref", "witness_without_optimizer_rationale", "unknown_proof_obligation",
        } for x in defects)
        reference_checks_passed = "unresolved_structural_reference" not in defect_codes

        # Non-vacuity probe: every canonical occurrence must be load-bearing in the
        # verifier. Removing the witness for any one obligation must create an
        # unresolved_proof_obligation defect for exactly that occurrence.
        non_vacuous = True
        if obligations and not defects:
            for obligation in obligations:
                mutant = replace(
                    proposal,
                    witnesses=tuple(w for w in proposal.witnesses if w.obligation_id != obligation.obligation_id),
                )
                mutant_defects = self._defects_without_mutation_probe(
                    raw_user_text=raw_user_text,
                    proposal=mutant,
                    reference_exists=reference_exists,
                )
                if not any(
                    x.code == "unresolved_proof_obligation" and x.obligation_id == obligation.obligation_id
                    for x in mutant_defects
                ):
                    non_vacuous = False
                    defects = defects + (ProofDefect(
                        code="vacuous_proof_system",
                        obligation_id=obligation.obligation_id,
                        description="removing an obligation witness did not make the proof fail",
                        repair_hint="make every canonical requirement occurrence load-bearing in proof verification",
                    ),)
                    break

        complete = not defects and destination_match and contract_match and all_obligations_witnessed and witness_structure_valid and reference_checks_passed and non_vacuous
        certificate_body = {
            "candidate_id": proposal.candidate_id,
            "optimizer_role": proposal.optimizer_role,
            "destination_match": destination_match,
            "contract_match": contract_match,
            "all_obligations_witnessed": all_obligations_witnessed,
            "witness_structure_valid": witness_structure_valid,
            "reference_checks_passed": reference_checks_passed,
            "non_vacuous": non_vacuous,
            "defects": [x.as_mapping() for x in defects],
            "complete": complete,
        }
        return ProofCertificate(
            candidate_id=proposal.candidate_id,
            optimizer_role=proposal.optimizer_role,
            destination_match=destination_match,
            contract_match=contract_match,
            all_obligations_witnessed=all_obligations_witnessed,
            witness_structure_valid=witness_structure_valid,
            reference_checks_passed=reference_checks_passed,
            non_vacuous=non_vacuous,
            defects=defects,
            complete=complete,
            certificate_sha256=_sha256_text(_stable_json(certificate_body)),
        )

    def feedback(self, certificate: ProofCertificate) -> OptimizerFeedback:
        unresolved = tuple(dict.fromkeys(
            x.obligation_id for x in certificate.defects if x.obligation_id
        ))
        if certificate.complete:
            directive = (
                "Candidate is proof-complete. Preserve the same canonical intent while pursuing additional material runtime gains."
            )
        else:
            directive = (
                "Candidate remains live. Keep its useful gains, close the unresolved proof obligations, "
                "and improve the architecture or representation as needed without shrinking the canonical destination."
            )
        return OptimizerFeedback(
            feedback_kind="optimization_defect" if not certificate.complete else "optimization_progress",
            candidate_status="live_repairable" if not certificate.complete else "admissible_improvement",
            optimizer_role=self.charter.role,
            proof_complete=certificate.complete,
            keep_useful_gains=True,
            unresolved_proof_obligations=unresolved,
            defect_codes=tuple(x.code for x in certificate.defects),
            repair_directive=directive,
            good_improvement_definition=self.charter.good_improvement_definition,
        )


def proposal_template(raw_user_text: str) -> dict[str, Any]:
    """Return a model-facing proposal skeleton for the current immutable directive."""
    contract = RequirementCompiler.compile(str(raw_user_text))
    obligations = ProofCarryingImprovementProtocol.obligations_from_contract(contract)
    return {
        "candidate_id": "candidate_<optimizer_generated>",
        "optimizer_role": "runtime_optimizer",
        "parent_destination_sha256": contract.message_sha256,
        "requirement_contract_sha256": contract.contract_sha256,
        "implementation_summary": "",
        "implementation_refs": [],
        "claimed_improvements": [],
        "witnesses": [
            {
                "obligation_id": obligation.obligation_id,
                "atom_id": obligation.atom_id,
                "preservation_mode": "preserved",
                "implementation_refs": [],
                "route_refs": [],
                "test_refs": [],
                "optimizer_rationale": "",
            }
            for obligation in obligations
        ],
    }
