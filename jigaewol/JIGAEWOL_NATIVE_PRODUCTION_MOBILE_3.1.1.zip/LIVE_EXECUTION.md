# JIGAEWOL live host execution lane — 2026-10-09

Original architecture remains `user > canonical ZIP ingress > JIGAEWOL model/host actions`.

## One-turn pipeline (no more passive manifest-only steps)

```
python tools/jigaewol_turn_pipeline.py --message-file /path/to/exact_utf8_source.txt --root /path/to/state --capabilities-json /path/to/callable_host_surface.json
```

1. `jigaewol_gateway.py` consumes the exact source bytes and persists source-bound canonical release turn evidence.
2. `tools/jigaewol_live_dispatch.py` verifies the source hash against the canonical core-turn snapshot and creates concrete host tool jobs in the existing `CanonicalHostBridge`.
3. `next_host_actions.js` is a *runnable* function-code host dispatch body. A ChatGPT host with access to `tools`/`ALL_TOOLS` executes it via `functions.exec` using actual installed/connected plugins. The JavaScript does not execute itself in local Python/Node.
4. Save the resulting `observations` JSON and run:

```
python tools/jigaewol_live_dispatch.py --root /path/to/state ingest --batch-file /path/to/state/live_dispatch/active_batch.json --observations-file /path/to/observations.json
```

The existing `CanonicalHostBridge` records successful observed calls. Failures remain visible, as do missing host bindings. A discovered plugin or skill is not reported as executed.

## Open-ended tools and free open source

Built-in discover/action lanes cover GitHub repo search, GitHub raw file retrieval, Reddit/community search, plugin discovery, Context7 documentation, installed skills discovery and Firecrawl web search. Any available host tool can be registered without replacing the ontology: `enqueue-json` with a JSON array of `tool`, `args`, `read_only`, and optional `family`, `capability`, `label`, `cost_status`.

Read-only calls are allowed using observed host permissions. Writes and unknown actions require explicit approved effects. A missing connector must be offered for user approval; status `installed` alone does not prove callable. Prefer actually free/no-new-charge sources; commercial provider credits may carry an unverified cost and must not be marked free automatically. Previously declined plugins remain excluded.

## OSS real execution example

Using the connected GitHub tool, `pypa/sampleproject` `src/sample/simple.py` and `LICENSE.txt` were retrieved with exact Git blob SHA-1 values, then verified by `QuarantineMaterializer`. A local process executed the public MIT sample with `add_one(41) == 42`, exit status 0, followed by a `proven_donor_body` scoped promotion. The source/receipt is in `/mnt/data/jigaewol_active_state/open_source_acquisition/pypa_sampleproject` in the active turn's state. This is a real small example, not proof that arbitrary unknown repository code is safe.

## Distinctions retained

ChatGPT does not automatically run this local Python on every message unless the actual host registers a message callback. Host-facing plugin calls require the host adapter; local Python cannot import the host's OAuth plugin connections. The bridge is runnable and tested when invoked, but the host-level every-turn callback remains an integration task.

## Zero-spend free mesh (2026-10-09)

`python tools/jigaewol_free_mesh.py --root <state>/free_mesh submit --kind sha256 --payload-json '{"text":"hello"}'`
then `python tools/jigaewol_free_mesh.py --root <state>/free_mesh drain`, then `status`.

This is a real, offline SQLite WAL queue (digest deduplication, checkpoint/recovery, FTS5 corpus index, multilingual
community query mutation, JSON computation). The task count has no artificial paywall; finite CPU/storage and
ChatGPT limits still apply. The canonical host batch uses a second cost admission check before emitting runnable
host code; unknown-credit providers (including Firecrawl/TinyFish/Exa) are deferred, never called automatically.
For blocked lanes it records scope-qualified free fallbacks, not false equivalence with Reddit/general web.

The route is `user exact bytes > canonical ingress > policy-checked host actions + offline durable work > observed results`.
Automatic chat-host ingress callback remains unregistered and is not claimed.
