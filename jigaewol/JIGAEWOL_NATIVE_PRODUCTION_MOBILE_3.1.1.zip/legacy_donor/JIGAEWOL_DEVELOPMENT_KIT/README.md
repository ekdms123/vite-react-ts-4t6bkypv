# JIGAEWOL development kit

현재 실행 코드, 개발 진입점 10개, 라이선스와 출처가 붙은 공개 스킬 158개, 실제 HTTP/MCP 회귀 테스트를 함께 옮기는 배포본이다. 개인 Notion 본문과 계정 키는 기존 작업 공간에 보관된다. 이 ZIP의 로컬 검색 색인은 공개 스킬만으로 복원한다.

실행해 확인한 환경은 Python 3.12와 Node.js 24이다. 별도 서비스 가입이나 서버 생성 없이 로컬에서 실행한다. Python·Node 의존성은 동봉한 두 lockfile에 고정되어 있다.

1. ZIP을 풀고 같은 폴더에서 `python setup.py --runtime-zip ../JIGAEWOL_RUNTIME_FINAL.zip`을 실행한다. 실제 파일명으로 경로를 바꾼다. 기본 소스 경로는 시스템 임시 디렉터리의 `jigaewol-<ZIP hash>`이며 `--runtime-root`로 직접 선택할 수 있다. 봉인된 모든 파일의 바이트를 다시 확인한다.
2. 처음 설치하는 컴퓨터는 같은 명령에 `--install`을 추가한다. Python wheel과 `npm ci --ignore-scripts`를 사용한다. 이미 의존성이 있는 현재 작업 공간은 재설치하지 않아도 된다.
3. `python start_bridge.py`를 실행하면 로컬 HTTP 8767, MCP 8768 포트를 함께 연다. 연결할 HTTPS 주소가 준비되어 있으면 `--public-url https://YOUR_ADDRESS`를 지정한다. 연결·OAuth 안내는 `mobile-bridge/README.md`를 따른다. 실제 owner key 파일은 `.local/mobile-state`에 생성되며 ZIP에는 포함되어 있지 않다.
4. `npm test`는 현재 MCP, HTTP/실행 영수증, 다중 경로 검색 테스트를 실행한다. 복원한 환경에서 `JIGAEWOL_TEST_SOURCE_CONFIG`를 `runtime/session/source.json`의 절대 경로로, `JIGAEWOL_TEST_INGRESS_ADAPTER`를 `runtime/session/ingress.py`의 절대 경로로 지정한다. `JIGAEWOL_TEST_PYTHON`은 별도 Python 환경이 필요할 때 지정한다.

`python scripts/search_library.py deep-research --kind skill`로 공개 색인을 검색한다. `scripts/deep_find.py`는 사용자 원문 파일, 검색어 파일과 출력 경로를 받아 실제 공개 검색 결과와 HTTP 실패를 저장한다. 라이브러리 자료는 필요한 항목만 읽고 해당 작업에서 사용하는 명령과 의존성을 선택한다.

`plugin/skills`에 `/dev-ready`, `/dev-spec`, `/dev-build`, `/dev-debug`, `/dev-test`, `/dev-review`, `/dev-security`, `/dev-docs`, `/dev-release`, `/dev-find`가 있다. 호스트의 로컬 플러그인 등록은 이 `plugin` 폴더를 기준으로 진행한다. 각 진입점은 `<KIT_ROOT>/plugin/skills`에서 읽고 실제 명령·결과에 연결한다. 코드의 HTTP/MCP 연결과 호스트의 플러그인 메뉴 등록은 각각 확인한다.

`runtime/session/ingress.py`는 매 사용자 메시지의 UTF-8 파일을 받아 ZIP canonical ingress를 실행하고 결과 파일과 release turn을 반환한다. `runtime/source.sample.json`은 경로 필드의 예시이며, 실제 현재 설정은 `setup.py`가 `runtime/session/source.json`에 만든다. 개인 대화 원문, 이전 HMAC 키, 로그인 세션, 실행 중인 서버 데이터는 복사하지 않는다.

Playwright 브라우저 기능이 필요한 새 컴퓨터는 설치 후 `node_modules/.bin/playwright install chromium`을 실행한다. 기본 테스트에는 외부 계정이나 브라우저 다운로드가 필요하지 않다.

`PORTABLE_MANIFEST.json`에는 배포 파일의 크기와 SHA-256을 기록한다. 공개 스킬의 원문 hash, GitHub 주소, commit, 원문 경로, 해당 라이선스는 `skill-registry.json`과 `library/licenses/INDEX.json`(라이선스 원문 ↔ 스킬 폴더)에 있다. 외부 스킬을 포함했다는 사실과 그 외부 제공자에 로그인해 실행했다는 사실은 영수증에 구분해 남긴다.

## Authority/ingress portability patch
- `setup.py --runtime-zip ...` keeps that exact user-selected runtime ZIP as canonical authority; retired R33 is recorded as provenance only; recovery uses the current user-selected ZIP.
- `--host-declarations` imports actually observed host schemas after validation; no bundled declaration claims future callability.
- ingress supports lossless capture manifests and atomic/compact gateway handoff so interrupted execution does not publish an empty final JSON payload.
